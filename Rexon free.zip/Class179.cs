using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Ghost", "Rig", "Left secondary to freeze rig.", false, 1, ModType.const_0, false)]
internal class Class179 : MonoBehaviour
{
	private static bool bool_0;

	private bool bool_1;

	private bool bool_2;

	private GameObject gameObject_0;

	private GameObject gameObject_1;

	private bool bool_3;

	private float float_0;

	private static Class179 class179_0;

	private static bool bool_4;

	private static int int_0;

	private static float float_1;

	private static double double_0;

	private static float float_2;

	private static IntPtr[] CreateActContextParametersSourceSkipVerification;

	private static IntPtr[] PInvokeMapSystemAlarmCallback;

	private static IntPtr[] StaticIndexRangePartitionerEnumEqualityComparer;

	private static IntPtr[] AuthenticationMethodDetail;

	private static IntPtr[] TBStrIsReEntrant;

	private static IntPtr[] getIsSecurityTransparentGetDefaultReader;

	private static IntPtr[] getHasInfoSetEnvironmentVariable;

	private static IntPtr[] GetTypeArrayTypeKind;

	private static IntPtr[] GetDefaultWritergetSize;

	private static IntPtr[] getDefaultInternalActivationContextHelper;

	private static IntPtr[] ToEvenOSPlatform;

	private static IntPtr[] setLockedsetDisallowApplicationBaseProbing;

	private static IntPtr[] ExpirationSEPEnd;

	public unsafe static bool IsActive
	{
		get
		{
			int num = 63;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							num = 49;
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StandardBiasVTSTREAMEDOBJECT.BaseChannelWithPropertiessetInitLocals);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 97;
																while (true)
																{
																	IL_0364:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0344:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_0334:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_0324:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_0317:
																										if (6 < b)
																										{
																											while (7 >= b)
																											{
																												while (7 <= b)
																												{
																													while (true)
																													{
																														IL_02b5:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														while (true)
																														{
																															IL_0296:
																															array[num6 - 2] = 0;
																															num = 157;
																															while (true)
																															{
																																if (num != 157)
																																{
																																	if (num != 1138)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 69:
																																		goto IL_0296;
																																	case 10:
																																	case 87:
																																		goto IL_02b5;
																																	case 117:
																																		goto IL_02f7;
																																	case 39:
																																		goto IL_0307;
																																	case 26:
																																	case 68:
																																		goto IL_0317;
																																	case 43:
																																	case 99:
																																		goto IL_0324;
																																	case 105:
																																		goto IL_0334;
																																	case 52:
																																		goto IL_0344;
																																	case 80:
																																		goto IL_0354;
																																	case 97:
																																		goto IL_0364;
																																	case 25:
																																		goto end_IL_0283;
																																	case 96:
																																	case 137:
																																		goto end_IL_0374;
																																	case 59:
																																		goto IL_0398;
																																	case 38:
																																		goto IL_03a3;
																																	case 15:
																																	case 60:
																																		goto IL_03bc;
																																	case 9:
																																		goto IL_03fc;
																																	case 57:
																																		goto IL_0410;
																																	case 67:
																																		goto IL_0423;
																																	case 122:
																																	case 144:
																																		goto IL_0431;
																																	case 72:
																																		goto IL_0471;
																																	case 6:
																																		goto IL_0485;
																																	case 134:
																																		goto IL_04ab;
																																	case 85:
																																	case 89:
																																		goto IL_04b6;
																																	case 106:
																																		goto IL_04c4;
																																	case 112:
																																		goto IL_04f0;
																																	case 18:
																																		goto IL_04fa;
																																	case 148:
																																		goto IL_0508;
																																	case 92:
																																		goto IL_051b;
																																	case 32:
																																		goto IL_0529;
																																	case 16:
																																	case 36:
																																		goto IL_0534;
																																	case 94:
																																		goto IL_0542;
																																	case 35:
																																	case 111:
																																		goto IL_0555;
																																	case 66:
																																		goto IL_0595;
																																	case 124:
																																		goto IL_05a9;
																																	case 61:
																																		goto IL_05bc;
																																	case 13:
																																		goto IL_05ca;
																																	case 2:
																																	case 110:
																																		goto IL_05d8;
																																	case 90:
																																		goto IL_0601;
																																	case 20:
																																		goto IL_0618;
																																	case 23:
																																	case 65:
																																		goto IL_0634;
																																	case 135:
																																		goto IL_0647;
																																	case 4:
																																	case 86:
																																		goto IL_0655;
																																	case 30:
																																	case 34:
																																		goto IL_0660;
																																	case 129:
																																		goto IL_066e;
																																	case 104:
																																	case 149:
																																		goto IL_067c;
																																	case 50:
																																		goto IL_06a1;
																																	case 14:
																																	case 24:
																																		goto IL_06b5;
																																	case 113:
																																		goto IL_06d9;
																																	case 0:
																																		goto IL_06e7;
																																	case 22:
																																		goto IL_06f5;
																																	case 127:
																																		goto IL_0708;
																																	case 78:
																																		goto IL_0716;
																																	case 114:
																																	case 131:
																																		goto IL_072f;
																																	case 17:
																																		goto IL_0747;
																																	case 1:
																																	case 120:
																																		goto IL_0755;
																																	case 28:
																																		goto IL_076c;
																																	case 55:
																																	case 116:
																																		goto IL_0777;
																																	case 145:
																																		goto IL_07d9;
																																	case 95:
																																		goto IL_07ec;
																																	case 37:
																																		goto IL_07fa;
																																	case 33:
																																	case 46:
																																		goto IL_0808;
																																	case 142:
																																		goto IL_0848;
																																	case 103:
																																		goto IL_085c;
																																	case 84:
																																		goto IL_086f;
																																	case 74:
																																		goto IL_0885;
																																	case 109:
																																	case 150:
																																		goto IL_0895;
																																	case 93:
																																		goto IL_08ae;
																																	case 54:
																																		goto IL_08bc;
																																	case 128:
																																		goto IL_08ca;
																																	case 3:
																																	case 8:
																																	case 11:
																																	case 12:
																																	case 27:
																																	case 29:
																																	case 42:
																																	case 45:
																																	case 47:
																																	case 48:
																																	case 51:
																																	case 58:
																																	case 64:
																																	case 71:
																																	case 75:
																																	case 76:
																																	case 79:
																																	case 91:
																																	case 102:
																																	case 107:
																																	case 108:
																																	case 123:
																																	case 125:
																																	case 130:
																																	case 132:
																																	case 139:
																																	case 140:
																																	case 143:
																																	case 146:
																																		goto end_IL_02f7;
																																	case 141:
																																		goto IL_08fc;
																																	case 136:
																																		goto IL_0913;
																																	case 53:
																																		goto IL_092a;
																																	case 5:
																																	case 7:
																																	case 19:
																																	case 21:
																																	case 41:
																																	case 44:
																																	case 56:
																																	case 70:
																																	case 77:
																																	case 81:
																																	case 82:
																																	case 83:
																																	case 98:
																																	case 101:
																																	case 115:
																																	case 119:
																																	case 121:
																																	case 126:
																																		goto end_IL_038d;
																																	case 31:
																																		goto end_IL_0938;
																																	case 100:
																																		goto end_IL_094b;
																																	case 40:
																																		goto end_IL_0955;
																																	case 73:
																																	case 147:
																																		goto end_IL_0960;
																																	case 49:
																																		goto end_IL_0970;
																																	case 138:
																																		goto end_IL_0980;
																																	case 88:
																																		goto end_IL_0990;
																																	case 62:
																																		goto end_IL_09a9;
																																	case 63:
																																		goto end_IL_09b9;
																																	case 118:
																																	case 133:
																																		goto IL_09d4;
																																	}
																																	continue;
																																}
																																num6--;
																																goto end_IL_038d;
																																continue;
																																end_IL_0283:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_0364;
																													continue;
																													end_IL_02f7:
																													break;
																													IL_02f7:;
																												}
																												break;
																												IL_0307:;
																											}
																											break;
																										}
																										goto IL_0398;
																										IL_03fc:
																										array[num6 - 2] = 0;
																										goto IL_0410;
																										IL_0398:
																										if (6 > b)
																										{
																											goto IL_03a3;
																										}
																										goto IL_03bc;
																										IL_03a3:
																										if (5 < b)
																										{
																											break;
																										}
																										num = 67;
																										goto IL_0423;
																										IL_0410:
																										num6--;
																										goto end_IL_038d;
																										IL_0423:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_0431;
																										IL_0431:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0471;
																										IL_0471:
																										array[num6 - 2] = 0;
																										goto IL_0485;
																										IL_0485:
																										num6--;
																										goto end_IL_038d;
																										IL_03bc:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_03fc;
																									}
																									break;
																								}
																								goto IL_04ab;
																								IL_0618:
																								num6--;
																								num = 121;
																								goto end_IL_038d;
																								IL_04ab:
																								if (4 <= b)
																								{
																									goto IL_04b6;
																								}
																								goto IL_051b;
																								IL_04b6:
																								array[num6] = 0;
																								goto IL_04c4;
																								IL_04c4:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								num = 112;
																								goto IL_04f0;
																								IL_04f0:
																								array2[num6] = null;
																								goto IL_04fa;
																								IL_04fa:
																								num6++;
																								goto IL_0508;
																								IL_0508:
																								ptr2 += 8;
																								goto end_IL_038d;
																								IL_051b:
																								if (2 >= b)
																								{
																									goto IL_0529;
																								}
																								goto IL_05bc;
																								IL_0529:
																								if (2 > b)
																								{
																									goto IL_0534;
																								}
																								goto IL_0555;
																								IL_0534:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0542;
																								IL_0542:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0555:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0595;
																								IL_0595:
																								array[num6 - 2] = 0;
																								goto IL_05a9;
																								IL_05a9:
																								num6--;
																								goto end_IL_038d;
																								IL_05bc:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_05ca;
																								IL_05ca:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_05d8;
																								IL_05d8:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0601;
																								IL_0601:
																								ptr2 += 8;
																								num = 20;
																								goto IL_0618;
																							}
																							break;
																						}
																						goto IL_0634;
																						IL_0634:
																						num6--;
																						goto end_IL_038d;
																					}
																					break;
																				}
																				goto IL_0647;
																				IL_0885:
																				if (11 > b)
																				{
																					break;
																				}
																				goto end_IL_038d;
																				IL_0647:
																				if (12 < b)
																				{
																					goto IL_0655;
																				}
																				goto IL_0747;
																				IL_0655:
																				if (14 < b)
																				{
																					goto IL_0660;
																				}
																				goto IL_06a1;
																				IL_0660:
																				if (15 < b)
																				{
																					break;
																				}
																				goto IL_066e;
																				IL_066e:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_067c;
																				IL_067c:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				num = 101;
																				goto end_IL_038d;
																				IL_06a1:
																				if (14 <= b)
																				{
																					num = 14;
																					goto IL_06b5;
																				}
																				goto IL_0708;
																				IL_0895:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_08ae;
																				IL_06b5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)CreateActContextParametersSourceSkipVerification[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_06d9;
																				IL_06d9:
																				array[num6] = 0;
																				goto IL_06e7;
																				IL_06e7:
																				num6++;
																				goto IL_06f5;
																				IL_06f5:
																				ptr2 += 8;
																				goto end_IL_038d;
																				IL_0708:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_0716;
																				IL_0716:
																				if (13 > b)
																				{
																					num = 125;
																					break;
																				}
																				goto IL_072f;
																				IL_08ae:
																				array[num6] = 1;
																				goto IL_08bc;
																				IL_072f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_038d;
																				IL_0747:
																				if (12 > b)
																				{
																					goto IL_0755;
																				}
																				goto IL_0895;
																				IL_0755:
																				if (10 >= b)
																				{
																					num = 28;
																					goto IL_076c;
																				}
																				goto IL_086f;
																				IL_08bc:
																				num6++;
																				goto IL_08ca;
																				IL_076c:
																				if (10 <= b)
																				{
																					goto IL_0777;
																				}
																				goto IL_07ec;
																				IL_0777:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_07d9;
																				IL_07d9:
																				num6 -= 2;
																				goto end_IL_038d;
																				IL_07ec:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_07fa;
																				IL_07fa:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0808;
																				IL_0808:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0848;
																				IL_0848:
																				array[num6 - 2] = 0;
																				goto IL_085c;
																				IL_085c:
																				num6--;
																				goto end_IL_038d;
																				IL_086f:
																				if (11 < b)
																				{
																					num = 108;
																					break;
																				}
																				goto IL_0885;
																				IL_08ca:
																				ptr2 += 16;
																				num = 119;
																				goto end_IL_038d;
																			}
																			break;
																			IL_0354:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_08fc;
																	IL_092a:
																	ptr2 += 8;
																	goto end_IL_038d;
																	IL_0913:
																	num6++;
																	num = 53;
																	goto IL_092a;
																	IL_08fc:
																	array[num6] = 0;
																	num = 136;
																	goto IL_0913;
																	continue;
																	end_IL_0364:
																	break;
																}
																continue;
																end_IL_0374:
																break;
															}
															continue;
															end_IL_038d:
															break;
														}
														continue;
													}
													goto IL_09d4;
													IL_09d4:
													return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
													continue;
													end_IL_0938:
													break;
												}
												continue;
												end_IL_094b:
												break;
											}
											continue;
											end_IL_0955:
											break;
										}
										continue;
										end_IL_0960:
										break;
									}
									continue;
									end_IL_0970:
									break;
								}
								continue;
								end_IL_0980:
								break;
							}
							continue;
							end_IL_0990:
							break;
						}
						continue;
						end_IL_09a9:
						break;
					}
					continue;
					end_IL_09b9:
					break;
				}
			}
		}
		private set
		{
			int num = 35;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								num = 104;
								while (true)
								{
									sbyte[] array3 = new sbyte[1];
									while (true)
									{
										int[] array4 = new int[6];
										while (true)
										{
											long[] array5 = new long[3];
											while (true)
											{
												array3[0] = (value ? ((sbyte)1) : ((sbyte)0));
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InsertAceFastResourceComparer.UrlValueGetTypeFromAssembly);
													num = 9;
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0308:
																		if (b >= 1)
																		{
																			while (b <= 17)
																			{
																				num = 178;
																				while (true)
																				{
																					if (num != 178)
																					{
																						if (num != 1159)
																						{
																							goto IL_03d8;
																						}
																						switch (num)
																						{
																						case 43:
																							goto end_IL_02e5;
																						case 167:
																							goto IL_0308;
																						case 108:
																							goto end_IL_0308;
																						case 49:
																						case 91:
																							goto end_IL_0318;
																						case 76:
																						case 162:
																							goto IL_0341;
																						case 59:
																						case 60:
																							goto IL_034f;
																						case 53:
																						case 77:
																							goto IL_035a;
																						case 7:
																						case 156:
																							goto IL_0365;
																						case 160:
																							goto IL_0373;
																						case 20:
																						case 140:
																							goto IL_0381;
																						case 171:
																							goto IL_039d;
																						case 17:
																						case 105:
																							goto IL_03ab;
																						case 110:
																							goto IL_03c5;
																						case 155:
																							goto IL_03d8;
																						case 50:
																							goto IL_03e3;
																						case 168:
																							goto IL_03f1;
																						case 32:
																						case 145:
																							goto IL_03fc;
																						case 88:
																						case 159:
																							goto IL_0422;
																						case 151:
																							goto IL_044e;
																						case 116:
																							goto IL_045c;
																						case 69:
																							goto IL_0473;
																						case 169:
																							goto IL_0486;
																						case 54:
																							goto IL_0494;
																						case 112:
																						case 143:
																							goto IL_049f;
																						case 128:
																							goto IL_04ad;
																						case 33:
																							goto IL_04c0;
																						case 111:
																						case 139:
																							goto IL_04ce;
																						case 120:
																							goto IL_04e2;
																						case 67:
																							goto IL_053f;
																						case 90:
																							goto IL_054d;
																						case 85:
																							goto IL_0569;
																						case 24:
																							goto IL_0577;
																						case 39:
																						case 118:
																							goto IL_0585;
																						case 164:
																							goto IL_05e7;
																						case 57:
																						case 74:
																							goto IL_0603;
																						case 13:
																							goto IL_061c;
																						case 132:
																							goto IL_062a;
																						case 158:
																							goto IL_0641;
																						case 44:
																							goto IL_0654;
																						case 56:
																						case 114:
																							goto IL_0662;
																						case 0:
																							goto IL_0670;
																						case 36:
																						case 161:
																							goto IL_067e;
																						case 86:
																							goto IL_068c;
																						case 38:
																							goto IL_0697;
																						case 122:
																							goto IL_06a5;
																						case 21:
																						case 125:
																							goto IL_06c1;
																						case 83:
																							goto IL_0701;
																						case 42:
																							goto IL_0715;
																						case 65:
																							goto IL_0728;
																						case 115:
																							goto IL_0736;
																						case 10:
																						case 94:
																							goto IL_074d;
																						case 12:
																							goto IL_0776;
																						case 124:
																							goto IL_0784;
																						case 89:
																						case 153:
																							goto IL_0797;
																						case 121:
																							goto IL_07a5;
																						case 16:
																							goto IL_07c8;
																						case 87:
																							goto IL_07d2;
																						case 97:
																							goto IL_07e0;
																						case 61:
																							goto IL_07f3;
																						case 1:
																							goto IL_0801;
																						case 100:
																							goto IL_080c;
																						case 26:
																						case 102:
																							goto IL_081a;
																						case 99:
																							goto IL_085a;
																						case 30:
																							goto IL_086e;
																						case 147:
																							goto IL_0881;
																						case 8:
																							goto IL_088f;
																						case 72:
																						case 152:
																							goto IL_089d;
																						case 141:
																							goto IL_08b0;
																						case 6:
																						case 149:
																							goto IL_08be;
																						case 103:
																							goto IL_08cc;
																						case 58:
																						case 106:
																							goto IL_08da;
																						case 29:
																							goto IL_091a;
																						case 48:
																							goto IL_092e;
																						case 3:
																						case 80:
																							goto IL_0941;
																						case 117:
																							goto IL_0981;
																						case 113:
																							goto IL_0995;
																						case 19:
																						case 81:
																							goto IL_09a8;
																						case 96:
																							goto IL_09e8;
																						case 129:
																							goto IL_0a05;
																						case 2:
																						case 18:
																						case 22:
																						case 25:
																						case 28:
																						case 31:
																						case 40:
																						case 46:
																						case 47:
																						case 51:
																						case 66:
																						case 70:
																						case 73:
																						case 75:
																						case 93:
																						case 95:
																						case 101:
																						case 107:
																						case 119:
																						case 123:
																						case 131:
																						case 133:
																						case 135:
																						case 136:
																						case 137:
																						case 138:
																						case 142:
																						case 146:
																						case 148:
																						case 157:
																						case 165:
																						case 170:
																							goto end_IL_02f5;
																						case 68:
																							goto IL_0a2e;
																						case 4:
																							goto IL_0a3c;
																						case 71:
																							goto IL_0a4a;
																						case 11:
																						case 14:
																						case 15:
																						case 23:
																						case 27:
																						case 37:
																						case 41:
																						case 45:
																						case 62:
																						case 63:
																						case 64:
																						case 78:
																						case 79:
																						case 82:
																						case 84:
																						case 127:
																						case 134:
																						case 150:
																						case 154:
																						case 166:
																							goto end_IL_0328;
																						case 9:
																							goto end_IL_0a58;
																						case 5:
																							goto end_IL_0a6b;
																						case 130:
																							goto end_IL_0a75;
																						case 109:
																							goto end_IL_0a89;
																						case 92:
																							goto end_IL_0a9e;
																						case 104:
																						case 126:
																							goto end_IL_0aae;
																						case 144:
																							goto end_IL_0abe;
																						case 52:
																							goto end_IL_0ace;
																						case 163:
																							goto end_IL_0ae7;
																						case 34:
																							goto end_IL_0af7;
																						case 35:
																							goto end_IL_0b07;
																						case 55:
																						case 98:
																							return;
																						}
																						continue;
																					}
																					if (9 < b)
																					{
																						goto IL_0341;
																					}
																					goto IL_0654;
																					IL_092e:
																					num6--;
																					goto end_IL_0328;
																					IL_0981:
																					array[num6 - 2] = 0;
																					goto IL_0995;
																					IL_0941:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0981;
																					IL_0341:
																					if (13 < b)
																					{
																						goto IL_034f;
																					}
																					goto IL_0486;
																					IL_034f:
																					if (15 < b)
																					{
																						goto IL_035a;
																					}
																					goto IL_03d8;
																					IL_035a:
																					if (16 < b)
																					{
																						goto IL_0365;
																					}
																					goto IL_039d;
																					IL_0365:
																					if (17 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_0373;
																					IL_0373:
																					if (17 > b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_0381;
																					IL_0381:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_0328;
																					IL_039d:
																					if (16 > b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_03ab;
																					IL_03ab:
																					bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) != 0;
																					goto IL_03c5;
																					IL_03c5:
																					num6--;
																					goto end_IL_0328;
																					IL_03d8:
																					if (15 > b)
																					{
																						goto IL_03e3;
																					}
																					goto IL_0422;
																					IL_03e3:
																					if (14 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_03f1;
																					IL_03f1:
																					if (14 > b)
																					{
																						num = 137;
																						goto end_IL_02f5;
																					}
																					goto IL_03fc;
																					IL_03fc:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0328;
																					IL_0995:
																					num6--;
																					goto end_IL_0328;
																					IL_0422:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array3[*(int*)(ptr2 + num3)];
																					num = 151;
																					goto IL_044e;
																					IL_044e:
																					array[num6] = 0;
																					goto IL_045c;
																					IL_045c:
																					num6++;
																					num = 69;
																					goto IL_0473;
																					IL_0473:
																					ptr2 += 8;
																					goto end_IL_0328;
																					IL_0486:
																					if (13 > b)
																					{
																						goto IL_0494;
																					}
																					num = 74;
																					goto IL_0603;
																					IL_0494:
																					if (11 < b)
																					{
																						goto IL_049f;
																					}
																					goto IL_04c0;
																					IL_049f:
																					if (12 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_04ad;
																					IL_04ad:
																					if (12 <= b)
																					{
																						goto end_IL_0328;
																					}
																					goto end_IL_02f5;
																					IL_04c0:
																					if (11 <= b)
																					{
																						goto IL_04ce;
																					}
																					goto IL_0569;
																					IL_04ce:
																					array[num6 - 2] = 0;
																					goto IL_04e2;
																					IL_04e2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<int, int, int>)PInvokeMapSystemAlarmCallback[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					num = 67;
																					goto IL_053f;
																					IL_053f:
																					num6--;
																					goto IL_054d;
																					IL_054d:
																					ptr2 += 8;
																					num = 15;
																					goto end_IL_0328;
																					IL_0569:
																					if (10 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_0577;
																					IL_0577:
																					if (10 > b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_0585;
																					IL_0585:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_05e7;
																					IL_05e7:
																					num6 -= 2;
																					goto end_IL_0328;
																					IL_09a8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_09e8;
																					IL_0603:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																					goto IL_061c;
																					IL_061c:
																					array[num6] = 1;
																					goto IL_062a;
																					IL_062a:
																					num6++;
																					num = 158;
																					goto IL_0641;
																					IL_0641:
																					ptr2 += 16;
																					goto end_IL_0328;
																					IL_0654:
																					if (9 > b)
																					{
																						goto IL_0662;
																					}
																					goto IL_09a8;
																					IL_0662:
																					if (4 >= b)
																					{
																						goto IL_0670;
																					}
																					goto IL_07f3;
																					IL_0670:
																					if (4 > b)
																					{
																						goto IL_067e;
																					}
																					goto IL_0797;
																					IL_067e:
																					if (2 >= b)
																					{
																						goto IL_068c;
																					}
																					goto IL_0728;
																					IL_068c:
																					if (2 > b)
																					{
																						goto IL_0697;
																					}
																					num = 125;
																					goto IL_06c1;
																					IL_0697:
																					if (1 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_06a5;
																					IL_06a5:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_02f5;
																					IL_09e8:
																					array[num6 - 2] = 0;
																					num = 129;
																					goto IL_0a05;
																					IL_06c1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0701;
																					IL_0701:
																					array[num6 - 2] = 0;
																					goto IL_0715;
																					IL_0715:
																					num6--;
																					goto end_IL_0328;
																					IL_0728:
																					if (3 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_0736;
																					IL_0736:
																					if (3 > b)
																					{
																						goto end_IL_02f5;
																					}
																					num = 94;
																					goto IL_074d;
																					IL_0a05:
																					num6--;
																					goto end_IL_0328;
																					IL_074d:
																					ref int reference = ref array4[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_0776;
																					IL_0776:
																					ptr2 += 8;
																					goto IL_0784;
																					IL_0784:
																					num6--;
																					goto end_IL_0328;
																					IL_0797:
																					array[num6] = 0;
																					goto IL_07a5;
																					IL_07a5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																					goto IL_07c8;
																					IL_07c8:
																					array2[num6] = null;
																					goto IL_07d2;
																					IL_07d2:
																					num6++;
																					goto IL_07e0;
																					IL_07e0:
																					ptr2 += 8;
																					goto end_IL_0328;
																					IL_07f3:
																					if (6 < b)
																					{
																						goto IL_0801;
																					}
																					goto IL_08b0;
																					IL_0801:
																					if (7 >= b)
																					{
																						goto IL_080c;
																					}
																					goto IL_0881;
																					IL_080c:
																					if (7 > b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_081a;
																					IL_081a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_085a;
																					IL_085a:
																					array[num6 - 2] = 0;
																					goto IL_086e;
																					IL_086e:
																					num6--;
																					goto end_IL_0328;
																					IL_0881:
																					if (8 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_088f;
																					IL_088f:
																					if (8 > b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_089d;
																					IL_089d:
																					num6--;
																					goto end_IL_0328;
																					IL_08b0:
																					if (6 > b)
																					{
																						goto IL_08be;
																					}
																					goto IL_0941;
																					IL_08be:
																					if (5 < b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_08cc;
																					IL_08cc:
																					if (5 > b)
																					{
																						goto end_IL_02f5;
																					}
																					goto IL_08da;
																					IL_08da:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																					goto IL_091a;
																					IL_091a:
																					array[num6 - 2] = 0;
																					goto IL_092e;
																					continue;
																					end_IL_02e5:
																					break;
																				}
																				continue;
																				end_IL_02f5:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0a2e;
																		IL_0a4a:
																		ptr2 += 8;
																		goto end_IL_0328;
																		IL_0a3c:
																		num6++;
																		goto IL_0a4a;
																		IL_0a2e:
																		array[num6] = 0;
																		goto IL_0a3c;
																		continue;
																		end_IL_0308:
																		break;
																	}
																	continue;
																	end_IL_0318:
																	break;
																}
																continue;
																end_IL_0328:
																break;
															}
															continue;
															end_IL_0a58:
															break;
														}
														continue;
														end_IL_0a6b:
														break;
													}
													continue;
													end_IL_0a75:
													break;
												}
												continue;
												end_IL_0a89:
												break;
											}
											continue;
											end_IL_0a9e:
											break;
										}
										continue;
										end_IL_0aae:
										break;
									}
									continue;
									end_IL_0abe:
									break;
								}
								continue;
								end_IL_0ace:
								break;
							}
							continue;
							end_IL_0ae7:
							break;
						}
						continue;
						end_IL_0af7:
						break;
					}
					continue;
					end_IL_0b07:
					break;
				}
			}
		}
	}

	private unsafe void OnEnable()
	{
		int num = 169;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TripleDESGetFile.WriteThroughCngAlgorithmID);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														IL_0485:
														byte b = *ptr2;
														while (true)
														{
															IL_0475:
															ptr2++;
															while (true)
															{
																IL_0465:
																if (b >= 1)
																{
																	while (b <= 21)
																	{
																		while (true)
																		{
																			IL_0445:
																			if (11 >= b)
																			{
																				while (11 > b)
																				{
																					while (true)
																					{
																						IL_0425:
																						if (5 >= b)
																						{
																							while (true)
																							{
																								IL_0415:
																								if (5 > b)
																								{
																									while (true)
																									{
																										IL_0405:
																										if (2 < b)
																										{
																											while (true)
																											{
																												IL_03f5:
																												if (3 < b)
																												{
																													while (4 >= b)
																													{
																														while (4 <= b)
																														{
																															num = 188;
																															while (true)
																															{
																																IL_03c2:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_039d:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																	while (true)
																																	{
																																		IL_0391:
																																		array2[num5] = null;
																																		while (true)
																																		{
																																			IL_0381:
																																			num5++;
																																			while (true)
																																			{
																																				IL_0368:
																																				ptr2 += 8;
																																				num = 206;
																																				while (num != 206)
																																				{
																																					if (num != 1187)
																																					{
																																						goto IL_063a;
																																					}
																																					switch (num)
																																					{
																																					case 104:
																																						goto IL_0368;
																																					case 146:
																																						goto IL_0381;
																																					case 15:
																																						goto IL_0391;
																																					case 180:
																																						goto IL_039d;
																																					case 145:
																																					case 188:
																																						goto IL_03c2;
																																					case 93:
																																						goto IL_03d2;
																																					case 99:
																																						goto IL_03e5;
																																					case 44:
																																					case 139:
																																						goto IL_03f5;
																																					case 26:
																																						goto IL_0405;
																																					case 152:
																																						goto IL_0415;
																																					case 120:
																																					case 172:
																																						goto IL_0425;
																																					case 192:
																																						goto IL_0435;
																																					case 160:
																																						goto IL_0445;
																																					case 191:
																																						goto IL_0455;
																																					case 176:
																																						goto IL_0465;
																																					case 113:
																																						goto IL_0475;
																																					case 49:
																																					case 171:
																																						goto IL_0485;
																																					case 165:
																																						goto IL_0490;
																																					case 115:
																																					case 117:
																																						goto IL_049e;
																																					case 30:
																																						goto IL_04d0;
																																					case 21:
																																						goto IL_04de;
																																					case 78:
																																					case 181:
																																						goto IL_04f1;
																																					case 77:
																																					case 90:
																																						goto IL_04ff;
																																					case 95:
																																						goto IL_050a;
																																					case 123:
																																						goto IL_0515;
																																					case 51:
																																					case 119:
																																						goto IL_0523;
																																					case 131:
																																						goto IL_053f;
																																					case 88:
																																						goto IL_054d;
																																					case 50:
																																						goto IL_0560;
																																					case 87:
																																					case 174:
																																						goto IL_056b;
																																					case 38:
																																						goto IL_0599;
																																					case 108:
																																					case 142:
																																						goto IL_05b5;
																																					case 27:
																																					case 136:
																																						goto IL_05c3;
																																					case 159:
																																						goto IL_05d1;
																																					case 16:
																																					case 73:
																																						goto IL_05df;
																																					case 111:
																																						goto IL_063a;
																																					case 34:
																																						goto IL_064d;
																																					case 47:
																																					case 153:
																																						goto IL_065b;
																																					case 92:
																																						goto IL_0699;
																																					case 58:
																																						goto IL_06ad;
																																					case 128:
																																						goto IL_06c0;
																																					case 105:
																																					case 122:
																																						goto IL_06ce;
																																					case 75:
																																						goto IL_06d9;
																																					case 48:
																																					case 52:
																																						goto IL_06e7;
																																					case 72:
																																						goto IL_0700;
																																					case 8:
																																						goto IL_071c;
																																					case 42:
																																						goto IL_0727;
																																					case 170:
																																						goto IL_073a;
																																					case 9:
																																						goto IL_0748;
																																					case 4:
																																					case 107:
																																						goto IL_0756;
																																					case 118:
																																						goto IL_0797;
																																					case 40:
																																						goto IL_07ab;
																																					case 25:
																																					case 121:
																																						goto IL_07be;
																																					case 167:
																																						goto IL_07ec;
																																					case 37:
																																					case 186:
																																						goto IL_07ff;
																																					case 17:
																																						goto IL_083f;
																																					case 85:
																																						goto IL_0853;
																																					case 164:
																																					case 193:
																																						goto IL_0866;
																																					case 80:
																																						goto IL_0874;
																																					case 61:
																																						goto IL_0898;
																																					case 18:
																																						goto IL_08a6;
																																					case 39:
																																					case 198:
																																						goto IL_08b9;
																																					case 103:
																																						goto IL_08c7;
																																					case 112:
																																					case 148:
																																						goto IL_08d5;
																																					case 79:
																																						goto IL_08ed;
																																					case 82:
																																						goto IL_08fb;
																																					case 32:
																																						goto IL_0909;
																																					case 54:
																																						goto IL_091c;
																																					case 43:
																																					case 70:
																																						goto IL_0927;
																																					case 12:
																																						goto IL_0967;
																																					case 182:
																																						goto IL_097b;
																																					case 129:
																																						goto IL_098e;
																																					case 59:
																																						goto IL_099c;
																																					case 66:
																																					case 137:
																																						goto IL_09aa;
																																					case 22:
																																						goto IL_09c3;
																																					case 23:
																																						goto IL_09da;
																																					case 163:
																																						goto IL_09e8;
																																					case 102:
																																						goto IL_0a04;
																																					case 140:
																																						goto IL_0a12;
																																					case 109:
																																					case 126:
																																						goto IL_0a1d;
																																					case 35:
																																						goto IL_0a30;
																																					case 29:
																																						goto IL_0a3b;
																																					case 0:
																																					case 197:
																																						goto IL_0a49;
																																					case 11:
																																						goto IL_0a92;
																																					case 67:
																																						goto IL_0aa6;
																																					case 116:
																																						goto IL_0ab9;
																																					case 69:
																																						goto IL_0ac7;
																																					case 55:
																																					case 124:
																																						goto IL_0ad5;
																																					case 178:
																																						goto IL_0b15;
																																					case 28:
																																						goto IL_0b32;
																																					case 161:
																																						goto IL_0b45;
																																					case 158:
																																					case 190:
																																						goto IL_0b53;
																																					case 144:
																																						goto IL_0b61;
																																					case 2:
																																					case 162:
																																						goto IL_0b6f;
																																					case 64:
																																						goto IL_0bd1;
																																					case 62:
																																						goto IL_0be4;
																																					case 41:
																																					case 189:
																																						goto IL_0bef;
																																					case 155:
																																						goto IL_0c38;
																																					case 83:
																																						goto IL_0c4c;
																																					case 1:
																																					case 3:
																																					case 5:
																																					case 7:
																																					case 10:
																																					case 20:
																																					case 31:
																																					case 36:
																																					case 53:
																																					case 56:
																																					case 57:
																																					case 60:
																																					case 65:
																																					case 68:
																																					case 76:
																																					case 81:
																																					case 86:
																																					case 89:
																																					case 91:
																																					case 96:
																																					case 106:
																																					case 110:
																																					case 130:
																																					case 133:
																																					case 134:
																																					case 141:
																																					case 143:
																																					case 149:
																																					case 156:
																																					case 157:
																																					case 173:
																																					case 183:
																																					case 184:
																																					case 187:
																																					case 195:
																																						goto end_IL_03d2;
																																					case 6:
																																					case 13:
																																					case 19:
																																					case 24:
																																					case 33:
																																					case 63:
																																					case 71:
																																					case 84:
																																					case 94:
																																					case 100:
																																					case 101:
																																					case 114:
																																					case 125:
																																					case 127:
																																					case 132:
																																					case 135:
																																					case 138:
																																					case 147:
																																					case 175:
																																					case 179:
																																					case 194:
																																					case 196:
																																					case 199:
																																						goto end_IL_0355;
																																					case 185:
																																						goto end_IL_0c6f;
																																					case 74:
																																						goto end_IL_0c82;
																																					case 154:
																																						goto end_IL_0c8c;
																																					case 166:
																																						goto end_IL_0c97;
																																					case 45:
																																						goto end_IL_0ca7;
																																					case 97:
																																					case 98:
																																						goto end_IL_0cb7;
																																					case 150:
																																						goto end_IL_0cc7;
																																					case 14:
																																					case 151:
																																						goto end_IL_0cd7;
																																					case 168:
																																						goto end_IL_0ce7;
																																					case 169:
																																						goto end_IL_0cf7;
																																					case 46:
																																					case 177:
																																						return;
																																					}
																																					continue;
																																					end_IL_0355:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_0435;
																															continue;
																															end_IL_03d2:
																															break;
																															IL_03d2:;
																														}
																														break;
																														IL_03e5:;
																													}
																													break;
																												}
																												goto IL_0490;
																												IL_04de:
																												num5--;
																												goto end_IL_0435;
																												IL_0490:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_049e;
																												IL_049e:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 30;
																												goto IL_04d0;
																												IL_04d0:
																												ptr2 += 8;
																												goto IL_04de;
																											}
																											break;
																										}
																										goto IL_091c;
																										IL_09e8:
																										ptr2 += 8;
																										num = 199;
																										goto end_IL_0435;
																										IL_091c:
																										if (2 <= b)
																										{
																											goto IL_0927;
																										}
																										goto IL_098e;
																										IL_0927:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0967;
																										IL_0967:
																										array[num5 - 2] = 0;
																										goto IL_097b;
																										IL_097b:
																										num5--;
																										goto end_IL_0435;
																										IL_098e:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_099c;
																										IL_099c:
																										if (1 > b)
																										{
																											break;
																										}
																										goto IL_09aa;
																										IL_09aa:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_09c3;
																										IL_09c3:
																										array[num5] = 0;
																										num = 23;
																										goto IL_09da;
																										IL_09da:
																										num5++;
																										goto IL_09e8;
																									}
																									break;
																								}
																								goto IL_07ff;
																								IL_0853:
																								num5--;
																								goto end_IL_0435;
																								IL_07ff:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_083f;
																								IL_083f:
																								array[num5 - 2] = 0;
																								goto IL_0853;
																							}
																							break;
																						}
																						goto IL_0a04;
																						IL_0c4c:
																						num5--;
																						goto end_IL_0435;
																						IL_0a04:
																						if (8 >= b)
																						{
																							goto IL_0a12;
																						}
																						goto IL_0b45;
																						IL_0a12:
																						if (8 <= b)
																						{
																							goto IL_0a1d;
																						}
																						goto IL_0a30;
																						IL_0a1d:
																						num5--;
																						goto end_IL_0435;
																						IL_0a30:
																						if (6 >= b)
																						{
																							goto IL_0a3b;
																						}
																						goto IL_0ab9;
																						IL_0a3b:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0a49;
																						IL_0a49:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 11;
																						goto IL_0a92;
																						IL_0a92:
																						array[num5 - 2] = 0;
																						goto IL_0aa6;
																						IL_0aa6:
																						num5--;
																						goto end_IL_0435;
																						IL_0ab9:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0ac7;
																						IL_0ac7:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0ad5;
																						IL_0ad5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0b15;
																						IL_0b15:
																						array[num5 - 2] = 0;
																						num = 28;
																						goto IL_0b32;
																						IL_0b32:
																						num5--;
																						goto end_IL_0435;
																						IL_0b45:
																						if (9 < b)
																						{
																							goto IL_0b53;
																						}
																						goto IL_0be4;
																						IL_0b53:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0b61;
																						IL_0b61:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0b6f;
																						IL_0b6f:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0bd1;
																						IL_0bd1:
																						num5 -= 2;
																						goto end_IL_0435;
																						IL_0be4:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0bef;
																						IL_0bef:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 155;
																						goto IL_0c38;
																						IL_0c38:
																						array[num5 - 2] = 0;
																						goto IL_0c4c;
																					}
																					goto end_IL_0455;
																					continue;
																					end_IL_0435:
																					break;
																					IL_0435:;
																				}
																				break;
																			}
																			goto IL_04f1;
																			IL_07be:
																			((Class179)array2[num5 - 2]).bool_3 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_07ec;
																			IL_04f1:
																			if (16 < b)
																			{
																				goto IL_04ff;
																			}
																			goto IL_06c0;
																			IL_04ff:
																			if (19 < b)
																			{
																				goto IL_050a;
																			}
																			goto IL_0560;
																			IL_050a:
																			if (20 >= b)
																			{
																				goto IL_0515;
																			}
																			goto IL_053f;
																			IL_0515:
																			if (20 > b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_0523;
																			IL_0523:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_053f:
																			if (21 < b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_054d;
																			IL_054d:
																			if (21 <= b)
																			{
																			}
																			goto end_IL_0455;
																			IL_0560:
																			if (19 <= b)
																			{
																				goto IL_056b;
																			}
																			num = 142;
																			goto IL_05b5;
																			IL_056b:
																			((Class179)array2[num5 - 2]).bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			goto IL_0599;
																			IL_0599:
																			num5 -= 2;
																			break;
																			IL_07ec:
																			num5 -= 2;
																			break;
																			IL_05b5:
																			if (17 < b)
																			{
																				goto IL_05c3;
																			}
																			goto IL_064d;
																			IL_05c3:
																			if (18 < b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_05d1;
																			IL_05d1:
																			if (18 > b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_05df;
																			IL_05df:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 111;
																			goto IL_063a;
																			IL_063a:
																			num5--;
																			break;
																			IL_064d:
																			if (17 > b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_065b;
																			IL_065b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<Class179, bool>)AuthenticationMethodDetail[*(int*)(ptr2 + num3)])((Class179)array2[num5 - 1]) ? 1 : 0);
																			goto IL_0699;
																			IL_0699:
																			array[num5 - 1] = 0;
																			goto IL_06ad;
																			IL_06ad:
																			ptr2 += 8;
																			break;
																			IL_06c0:
																			if (16 > b)
																			{
																				goto IL_06ce;
																			}
																			goto IL_07be;
																			IL_06ce:
																			if (13 >= b)
																			{
																				goto IL_06d9;
																			}
																			goto IL_071c;
																			IL_06d9:
																			if (13 <= b)
																			{
																				goto IL_06e7;
																			}
																			goto IL_08b9;
																			IL_06e7:
																			class179_0 = (Class179)array2[num5 - 1];
																			goto IL_0700;
																			IL_0700:
																			num5--;
																			num = 114;
																			break;
																			IL_08b9:
																			if (12 < b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_08c7;
																			IL_08c7:
																			if (12 > b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_08d5;
																			IL_08d5:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_08ed;
																			IL_08ed:
																			array[num5] = 5;
																			goto IL_08fb;
																			IL_08fb:
																			num5++;
																			goto IL_0909;
																			IL_0909:
																			ptr2 += 8;
																			break;
																			IL_071c:
																			if (14 >= b)
																			{
																				goto IL_0727;
																			}
																			goto IL_073a;
																			IL_0727:
																			if (14 > b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_0866;
																			IL_0866:
																			array[num5] = 0;
																			goto IL_0874;
																			IL_0874:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)AuthenticationMethodDetail[*(int*)(ptr2 + num3)])() ? 1 : 0);
																			goto IL_0898;
																			IL_0898:
																			num5++;
																			goto IL_08a6;
																			IL_08a6:
																			ptr2 += 8;
																			break;
																			IL_073a:
																			if (15 < b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_0748;
																			IL_0748:
																			if (15 > b)
																			{
																				goto end_IL_0455;
																			}
																			goto IL_0756;
																			IL_0756:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0);
																			goto IL_0797;
																			IL_0797:
																			array[num5 - 2] = 0;
																			goto IL_07ab;
																			IL_07ab:
																			num5--;
																			break;
																		}
																		goto end_IL_0465;
																		continue;
																		end_IL_0455:
																		break;
																		IL_0455:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0465:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_0c6f:
													break;
												}
												continue;
												end_IL_0c82:
												break;
											}
											continue;
											end_IL_0c8c:
											break;
										}
										continue;
										end_IL_0c97:
										break;
									}
									continue;
									end_IL_0ca7:
									break;
								}
								continue;
								end_IL_0cb7:
								break;
							}
							continue;
							end_IL_0cc7:
							break;
						}
						continue;
						end_IL_0cd7:
						break;
					}
					continue;
					end_IL_0ce7:
					break;
				}
				continue;
				end_IL_0cf7:
				break;
			}
		}
	}

	private static ControllerInputPoller setNextFor()
	{
		return ControllerInputPoller.instance;
	}

	private unsafe static int smethod_0()
	{
		int num = 138;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 145;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetSafeWaitHandleReadAndExecute.SetSecurityDescriptorSddlFormAnsiClass);
										num = 84;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 2;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 172;
																while (true)
																{
																	if (num != 172)
																	{
																		if (num == 1153)
																		{
																			switch (num)
																			{
																			case 136:
																				goto end_IL_02bf;
																			case 2:
																				goto end_IL_02cf;
																			case 41:
																				goto end_IL_02e8;
																			case 44:
																				goto IL_030c;
																			case 38:
																				goto IL_031a;
																			case 140:
																				goto IL_0328;
																			case 69:
																				goto IL_0336;
																			case 153:
																				goto IL_0344;
																			case 77:
																			case 80:
																				goto IL_0352;
																			case 25:
																			case 104:
																				goto IL_035d;
																			case 60:
																				goto IL_036b;
																			case 114:
																			case 150:
																				goto IL_0379;
																			case 21:
																				goto IL_03a2;
																			case 58:
																				goto IL_03bb;
																			case 24:
																			case 105:
																				goto IL_03c6;
																			case 53:
																				goto IL_03d4;
																			case 8:
																			case 100:
																				goto IL_03e2;
																			case 43:
																				goto IL_03fb;
																			case 93:
																				goto IL_0409;
																			case 97:
																				goto IL_0417;
																			case 55:
																			case 159:
																				goto IL_042a;
																			case 83:
																				goto IL_046a;
																			case 46:
																				goto IL_047e;
																			case 117:
																			case 162:
																				goto IL_0491;
																			case 124:
																				goto IL_04af;
																			case 128:
																				goto IL_04bd;
																			case 47:
																				goto IL_04d0;
																			case 121:
																			case 156:
																				goto IL_04de;
																			case 73:
																				goto IL_04e9;
																			case 5:
																			case 17:
																				goto IL_04f7;
																			case 127:
																				goto IL_0520;
																			case 37:
																				goto IL_052e;
																			case 141:
																				goto IL_054a;
																			case 154:
																				goto IL_0558;
																			case 34:
																			case 40:
																				goto IL_0566;
																			case 160:
																				goto IL_057e;
																			case 75:
																			case 130:
																				goto IL_0589;
																			case 92:
																				goto IL_0597;
																			case 3:
																			case 139:
																				goto IL_05a5;
																			case 155:
																				goto IL_05b3;
																			case 118:
																				goto IL_05cb;
																			case 45:
																				goto IL_05e2;
																			case 142:
																			case 157:
																				goto IL_05f5;
																			case 50:
																				goto IL_0634;
																			case 6:
																			case 152:
																				goto IL_0659;
																			case 20:
																				goto IL_0667;
																			case 16:
																			case 27:
																				goto IL_0672;
																			case 96:
																			case 144:
																				goto IL_067d;
																			case 15:
																				goto IL_068b;
																			case 4:
																				goto IL_06a7;
																			case 120:
																			case 143:
																				goto IL_06b5;
																			case 164:
																				goto IL_06d1;
																			case 29:
																			case 161:
																				goto IL_06dc;
																			case 39:
																				goto IL_06ef;
																			case 72:
																				goto IL_06fd;
																			case 48:
																			case 51:
																				goto IL_070b;
																			case 42:
																				goto IL_071f;
																			case 90:
																				goto IL_0773;
																			case 66:
																				goto IL_0781;
																			case 163:
																				goto IL_079d;
																			case 1:
																			case 119:
																				goto IL_07ab;
																			case 18:
																			case 59:
																				goto IL_07b9;
																			case 149:
																				goto IL_07c7;
																			case 19:
																			case 158:
																				goto IL_07d5;
																			case 134:
																				goto IL_0815;
																			case 151:
																				goto IL_0829;
																			case 65:
																				goto IL_083c;
																			case 103:
																				goto IL_0847;
																			case 91:
																				goto IL_0855;
																			case 63:
																			case 67:
																				goto IL_0863;
																			case 79:
																				goto IL_0871;
																			case 52:
																				goto IL_0894;
																			case 133:
																				goto IL_089e;
																			case 10:
																				goto IL_08ac;
																			case 94:
																			case 108:
																				goto IL_08bf;
																			case 99:
																				goto IL_0903;
																			case 107:
																				goto IL_0917;
																			case 36:
																			case 54:
																				goto IL_092a;
																			case 57:
																				goto IL_098c;
																			case 0:
																			case 7:
																			case 11:
																			case 22:
																			case 23:
																			case 26:
																			case 28:
																			case 33:
																			case 35:
																			case 61:
																			case 64:
																			case 70:
																			case 71:
																			case 74:
																			case 76:
																			case 78:
																			case 81:
																			case 86:
																			case 87:
																			case 88:
																			case 95:
																			case 98:
																			case 109:
																			case 111:
																			case 113:
																			case 116:
																			case 123:
																			case 125:
																			case 132:
																				goto IL_099c;
																			case 9:
																			case 12:
																			case 13:
																			case 30:
																			case 31:
																			case 32:
																			case 49:
																			case 62:
																			case 68:
																			case 82:
																			case 85:
																			case 101:
																			case 110:
																			case 122:
																			case 126:
																			case 129:
																			case 131:
																			case 135:
																			case 148:
																			case 165:
																				goto end_IL_02f3;
																			case 84:
																				goto end_IL_09af;
																			case 145:
																				goto end_IL_09c2;
																			case 56:
																				goto end_IL_09cc;
																			case 147:
																				goto end_IL_09e0;
																			case 14:
																			case 89:
																				goto end_IL_09f9;
																			case 115:
																				goto end_IL_0a09;
																			case 106:
																			case 146:
																				goto end_IL_0a19;
																			case 137:
																				goto end_IL_0a29;
																			case 138:
																				goto end_IL_0a39;
																			case 102:
																			case 112:
																				goto IL_0a54;
																			}
																			continue;
																		}
																	}
																	else if (b >= 1)
																	{
																		goto IL_030c;
																	}
																	goto IL_099c;
																	IL_08bf:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																	goto IL_0903;
																	IL_0917:
																	num5--;
																	goto end_IL_02f3;
																	IL_0903:
																	array[num5 - 2] = 0;
																	goto IL_0917;
																	IL_030c:
																	if (b <= 17)
																	{
																		goto IL_031a;
																	}
																	goto IL_099c;
																	IL_031a:
																	if (9 >= b)
																	{
																		goto IL_0328;
																	}
																	num = 152;
																	goto IL_0659;
																	IL_0328:
																	if (9 <= b)
																	{
																		goto end_IL_02f3;
																	}
																	goto IL_0336;
																	IL_0336:
																	if (4 >= b)
																	{
																		goto IL_0344;
																	}
																	goto IL_04d0;
																	IL_0344:
																	if (4 > b)
																	{
																		goto IL_0352;
																	}
																	goto IL_0491;
																	IL_0352:
																	if (2 < b)
																	{
																		goto IL_035d;
																	}
																	goto IL_03bb;
																	IL_035d:
																	if (3 >= b)
																	{
																		goto IL_036b;
																	}
																	goto IL_099c;
																	IL_036b:
																	if (3 <= b)
																	{
																		goto IL_0379;
																	}
																	goto IL_099c;
																	IL_0379:
																	array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																	goto IL_03a2;
																	IL_03a2:
																	array[num5 - 1] = 5;
																	goto end_IL_02f3;
																	IL_03bb:
																	if (2 > b)
																	{
																		goto IL_03c6;
																	}
																	goto IL_042a;
																	IL_03c6:
																	if (1 >= b)
																	{
																		goto IL_03d4;
																	}
																	goto IL_099c;
																	IL_03d4:
																	if (1 <= b)
																	{
																		goto IL_03e2;
																	}
																	goto IL_099c;
																	IL_03e2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_03fb;
																	IL_03fb:
																	array[num5] = 0;
																	goto IL_0409;
																	IL_0409:
																	num5++;
																	goto IL_0417;
																	IL_0417:
																	ptr2 += 8;
																	goto end_IL_02f3;
																	IL_042a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_046a;
																	IL_046a:
																	array[num5 - 2] = 0;
																	goto IL_047e;
																	IL_047e:
																	num5--;
																	goto end_IL_02f3;
																	IL_0491:
																	array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																	goto IL_04af;
																	IL_04af:
																	ptr2 += 8;
																	goto IL_04bd;
																	IL_04bd:
																	num5--;
																	goto end_IL_02f3;
																	IL_04d0:
																	if (6 < b)
																	{
																		goto IL_04de;
																	}
																	goto IL_057e;
																	IL_04de:
																	if (7 >= b)
																	{
																		goto IL_04e9;
																	}
																	goto IL_054a;
																	IL_04e9:
																	if (7 <= b)
																	{
																		goto IL_04f7;
																	}
																	goto IL_099c;
																	IL_04f7:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0520;
																	IL_0520:
																	ptr2 += 8;
																	goto IL_052e;
																	IL_052e:
																	num5--;
																	num = 126;
																	goto end_IL_02f3;
																	IL_054a:
																	if (8 >= b)
																	{
																		goto IL_0558;
																	}
																	goto IL_099c;
																	IL_0558:
																	if (8 <= b)
																	{
																		goto IL_0566;
																	}
																	goto IL_099c;
																	IL_0566:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02f3;
																	IL_057e:
																	if (6 > b)
																	{
																		goto IL_0589;
																	}
																	goto IL_05f5;
																	IL_0589:
																	if (5 >= b)
																	{
																		goto IL_0597;
																	}
																	goto IL_099c;
																	IL_0597:
																	if (5 <= b)
																	{
																		goto IL_05a5;
																	}
																	goto IL_099c;
																	IL_05a5:
																	array[num5] = 5;
																	goto IL_05b3;
																	IL_05b3:
																	array2[num5] = array5[*(int*)(ptr2 + num3)];
																	goto IL_05cb;
																	IL_05cb:
																	num5++;
																	num = 45;
																	goto IL_05e2;
																	IL_05e2:
																	ptr2 += 8;
																	goto end_IL_02f3;
																	IL_05f5:
																	((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0634;
																	IL_0634:
																	num5 -= 3;
																	num = 101;
																	goto end_IL_02f3;
																	IL_092a:
																	ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																	goto IL_098c;
																	IL_0659:
																	if (13 < b)
																	{
																		goto IL_0667;
																	}
																	num = 163;
																	goto IL_079d;
																	IL_0667:
																	if (15 < b)
																	{
																		goto IL_0672;
																	}
																	goto IL_06d1;
																	IL_0672:
																	if (16 < b)
																	{
																		goto IL_067d;
																	}
																	goto IL_06a7;
																	IL_067d:
																	if (17 >= b)
																	{
																		goto IL_068b;
																	}
																	goto IL_099c;
																	IL_068b:
																	if (17 <= b)
																	{
																		num = 113;
																	}
																	goto IL_099c;
																	IL_099c:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02f3;
																	IL_06a7:
																	if (16 <= b)
																	{
																		goto IL_06b5;
																	}
																	goto IL_099c;
																	IL_06b5:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_02f3;
																	IL_06d1:
																	if (15 <= b)
																	{
																		goto IL_06dc;
																	}
																	goto IL_06ef;
																	IL_06dc:
																	num5--;
																	goto end_IL_02f3;
																	IL_06ef:
																	if (14 >= b)
																	{
																		goto IL_06fd;
																	}
																	goto IL_099c;
																	IL_06fd:
																	if (14 <= b)
																	{
																		goto IL_070b;
																	}
																	goto IL_099c;
																	IL_070b:
																	array[num5 - 2] = 0;
																	goto IL_071f;
																	IL_071f:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)ExpirationSEPEnd[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																	goto IL_0773;
																	IL_0773:
																	num5--;
																	goto IL_0781;
																	IL_0781:
																	ptr2 += 8;
																	goto end_IL_02f3;
																	IL_098c:
																	num5 -= 2;
																	goto end_IL_02f3;
																	IL_079d:
																	if (13 > b)
																	{
																		goto IL_07ab;
																	}
																	goto IL_092a;
																	IL_07ab:
																	if (11 < b)
																	{
																		goto IL_07b9;
																	}
																	goto IL_083c;
																	IL_07b9:
																	if (12 >= b)
																	{
																		goto IL_07c7;
																	}
																	goto IL_099c;
																	IL_07c7:
																	if (12 <= b)
																	{
																		goto IL_07d5;
																	}
																	goto IL_099c;
																	IL_07d5:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0815;
																	IL_0815:
																	array[num5 - 2] = 0;
																	goto IL_0829;
																	IL_0829:
																	num5--;
																	goto end_IL_02f3;
																	IL_083c:
																	if (11 > b)
																	{
																		goto IL_0847;
																	}
																	goto IL_08bf;
																	IL_0847:
																	if (10 >= b)
																	{
																		goto IL_0855;
																	}
																	goto IL_099c;
																	IL_0855:
																	if (10 <= b)
																	{
																		goto IL_0863;
																	}
																	goto IL_099c;
																	IL_0863:
																	array[num5] = 0;
																	goto IL_0871;
																	IL_0871:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0894;
																	IL_0894:
																	array2[num5] = null;
																	goto IL_089e;
																	IL_089e:
																	num5++;
																	goto IL_08ac;
																	IL_08ac:
																	ptr2 += 8;
																	goto end_IL_02f3;
																	continue;
																	end_IL_02bf:
																	break;
																}
																continue;
																end_IL_02cf:
																break;
															}
															continue;
															end_IL_02e8:
															break;
														}
														continue;
														end_IL_02f3:
														break;
													}
													continue;
												}
												goto IL_0a54;
												IL_0a54:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09af:
												break;
											}
											continue;
											end_IL_09c2:
											break;
										}
										continue;
										end_IL_09cc:
										break;
									}
									continue;
									end_IL_09e0:
									break;
								}
								continue;
								end_IL_09f9:
								break;
							}
							continue;
							end_IL_0a09:
							break;
						}
						continue;
						end_IL_0a19:
						break;
					}
					continue;
					end_IL_0a29:
					break;
				}
				continue;
				end_IL_0a39:
				break;
			}
		}
	}

	private unsafe Color method_0()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_05d3, IL_05e6, IL_0653, IL_0663, IL_0673, IL_0683, IL_0690, IL_06a3, IL_06b3, IL_06c3, IL_06ce, IL_06de, IL_06ee, IL_0701, IL_070f, IL_071a, IL_0725, IL_0733, IL_0741, IL_074f, IL_075d, IL_076b, IL_0793, IL_079c, IL_07aa, IL_07ba, IL_07ca, IL_07d8, IL_07f1, IL_07ff, IL_080d, IL_0820, IL_082e, IL_083c, IL_084a, IL_085e, IL_089f, IL_08a9, IL_08bc, IL_08cf, IL_08f8, IL_0906, IL_0919, IL_0924, IL_0938, IL_098f, IL_099d, IL_09a8, IL_09b6, IL_09ca, IL_0a09, IL_0a1c, IL_0a2a, IL_0a38, IL_0a46, IL_0a69, IL_0aae, IL_0ac1, IL_0acc, IL_0ada, IL_0ae8, IL_0b0b, IL_0b22, IL_0b35, IL_0b45, IL_0b58, IL_0b6b, IL_0b7e, IL_0bbf, IL_0bd3, IL_0be6, IL_0bf4, IL_0c02, IL_0c70, IL_0c83, IL_0c91, IL_0c9c, IL_0cb4, IL_0cc2, IL_0cd0, IL_0ce3, IL_0cf1, IL_0cff, IL_0d51, IL_0d64, IL_0d6f, IL_0d7d, IL_0d8b, IL_0da5, IL_0db3, IL_0dc1, IL_0dd4, IL_0ddd, IL_0deb, IL_0e29, IL_0e3d, IL_0e50, IL_0e90, IL_0ea4, IL_0eb7, IL_0ed3, IL_0eef, IL_0f03, IL_0f16, IL_0f24, IL_0f32, IL_0f46, IL_0fae, IL_0fbc, IL_0fcf, IL_0fdd, IL_0fe8, IL_1028, IL_1041, IL_104c, IL_105f, IL_106d, IL_107b, IL_108f, IL_10ce, IL_10e1, IL_10ef, IL_10fd, IL_1106, IL_1123, IL_1162, IL_1175, IL_1183, IL_1196, IL_11a1, IL_11cf, IL_11e2, IL_11f0, IL_11fe, IL_1243, IL_125a, IL_127e, IL_128c, IL_129f, IL_12df, IL_12f3, IL_1306, IL_1319, IL_1332, IL_1340, IL_134e, IL_1361, IL_1375, IL_1388, IL_1396, IL_13a1, IL_13af, IL_13c2, IL_13d0, IL_13de, IL_13e7, IL_1427, IL_143b, IL_144e, IL_1457, IL_1462, IL_14a2, IL_14b6, IL_14d2, IL_14e0, IL_14ee, IL_152e, IL_1542, IL_1555, IL_1563, IL_1576, IL_1589, IL_1597, IL_15a5, IL_15ae, IL_15c6, IL_15e4, IL_1608, IL_1629, IL_163c, IL_164a, IL_1655, IL_1663, IL_1671, IL_167f, IL_1688, IL_16a5, IL_16f4, IL_16fe, IL_172b, IL_173f, IL_174d, IL_1760, IL_176b, IL_1779, IL_1797, IL_17a5, IL_17b8, IL_17c6, IL_17d4, IL_17fd, IL_181f, IL_182d, IL_183b, IL_1846, IL_1854, IL_1862, IL_187a, IL_1888, IL_189b, IL_18a9, IL_18b7, IL_18f5, IL_1908, IL_191c, IL_1954, IL_1967, IL_1972, IL_197d, IL_1996, IL_19a4, IL_19b2, IL_19c2, IL_19cd, IL_19d8, IL_19ed, IL_1a00, IL_1a13, IL_1a1d, IL_1a28, IL_1a38, IL_1a48, IL_1a58, IL_1a68, IL_1a78, IL_1a88, IL_1a98, IL_1aa8, IL_1ab8, IL_1ad3 are reachable both inside and outside the pinned region starting at IL_1acd. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 221;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef81 = default(int);
			ref int reference = ref __rxRef81;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1ab8:
					num2 = 1;
					while (true)
					{
						IL_1aa8:
						num3 = num2 * 4;
						while (true)
						{
							IL_1a98:
							num4 = num2 * 8;
							while (true)
							{
								IL_1a88:
								array2 = new byte[4];
								while (true)
								{
									IL_1a78:
									array3 = new object[4];
									while (true)
									{
										IL_1a68:
										array4 = new int[4];
										while (true)
										{
											IL_1a58:
											array5 = new int[7];
											while (true)
											{
												IL_1a48:
												array6 = new long[4];
												while (true)
												{
													IL_1a38:
													array7 = new object[9];
													while (true)
													{
														IL_1a28:
														array7[0] = this;
														while (true)
														{
															IL_1a1d:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AccessRightTypegetBaseUtcOffset.ICompatibleFrameworksMetadataEntryIsolatedStorageScope);
															while (true)
															{
																IL_1a13:
																ptr2 = ptr;
																while (true)
																{
																	IL_1a00:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_06c3:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_06b3:
																				ptr2++;
																				while (true)
																				{
																					IL_06a3:
																					if (b >= 1)
																					{
																						while (b <= 42)
																						{
																							num = 88;
																							while (true)
																							{
																								IL_0683:
																								if (21 >= b)
																								{
																									while (true)
																									{
																										IL_0673:
																										if (21 > b)
																										{
																											while (true)
																											{
																												IL_0663:
																												if (10 < b)
																												{
																													goto IL_1589;
																												}
																												while (true)
																												{
																													IL_0653:
																													if (10 <= b)
																													{
																														num = 310;
																														while (true)
																														{
																															IL_05e6:
																															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															num = 362;
																															while (true)
																															{
																																if (num != 362)
																																{
																																	if (num != 1343)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 221:
																																		break;
																																	default:
																																		continue;
																																	case 174:
																																	case 310:
																																		goto IL_05e6;
																																	case 136:
																																		goto IL_0653;
																																	case 126:
																																		goto IL_0663;
																																	case 163:
																																		goto IL_0673;
																																	case 88:
																																		goto IL_0683;
																																	case 9:
																																		goto IL_0690;
																																	case 82:
																																		goto IL_06a3;
																																	case 254:
																																		goto IL_06b3;
																																	case 65:
																																	case 201:
																																		goto IL_06c3;
																																	case 29:
																																		goto IL_06ce;
																																	case 33:
																																		goto IL_06de;
																																	case 186:
																																		goto IL_06ee;
																																	case 190:
																																		goto IL_0701;
																																	case 180:
																																		goto IL_070f;
																																	case 107:
																																		goto IL_071a;
																																	case 56:
																																		goto IL_0725;
																																	case 31:
																																		goto IL_0741;
																																	case 111:
																																		goto IL_074f;
																																	case 123:
																																	case 140:
																																		goto IL_075d;
																																	case 60:
																																		goto IL_076b;
																																	case 158:
																																		goto IL_079c;
																																	case 142:
																																		goto IL_07aa;
																																	case 204:
																																		goto IL_07ba;
																																	case 231:
																																		goto IL_07ca;
																																	case 152:
																																	case 177:
																																		goto IL_07d8;
																																	case 5:
																																		goto IL_07f1;
																																	case 212:
																																		goto IL_07ff;
																																	case 233:
																																		goto IL_080d;
																																	case 236:
																																		goto IL_0820;
																																	case 22:
																																		goto IL_082e;
																																	case 69:
																																		goto IL_083c;
																																	case 120:
																																	case 122:
																																		goto IL_084a;
																																	case 1:
																																		goto IL_085e;
																																	case 248:
																																		goto IL_089f;
																																	case 157:
																																		goto IL_08a9;
																																	case 251:
																																		goto IL_08bc;
																																	case 203:
																																	case 255:
																																		goto IL_08cf;
																																	case 171:
																																		goto IL_08f8;
																																	case 64:
																																		goto IL_0906;
																																	case 258:
																																		goto IL_0919;
																																	case 114:
																																	case 196:
																																		goto IL_0924;
																																	case 209:
																																		goto IL_0938;
																																	case 169:
																																		goto IL_098f;
																																	case 150:
																																		goto IL_099d;
																																	case 0:
																																		goto IL_09a8;
																																	case 184:
																																	case 205:
																																		goto IL_09b6;
																																	case 179:
																																		goto IL_09ca;
																																	case 73:
																																		goto IL_0a09;
																																	case 37:
																																		goto IL_0a1c;
																																	case 87:
																																		goto IL_0a2a;
																																	case 61:
																																	case 144:
																																		goto IL_0a38;
																																	case 51:
																																		goto IL_0a46;
																																	case 265:
																																	case 270:
																																		goto IL_0a69;
																																	case 275:
																																		goto IL_0aae;
																																	case 281:
																																		goto IL_0ac1;
																																	case 232:
																																		goto IL_0acc;
																																	case 141:
																																	case 219:
																																		goto IL_0ada;
																																	case 185:
																																		goto IL_0ae8;
																																	case 227:
																																		goto IL_0b0b;
																																	case 217:
																																		goto IL_0b22;
																																	case 99:
																																		goto IL_0b35;
																																	case 288:
																																		goto IL_0b45;
																																	case 291:
																																		goto IL_0b58;
																																	case 300:
																																		goto IL_0b6b;
																																	case 8:
																																	case 312:
																																		goto IL_0b7e;
																																	case 104:
																																		goto IL_0bbf;
																																	case 46:
																																		goto IL_0bd3;
																																	case 316:
																																		goto IL_0be6;
																																	case 76:
																																		goto IL_0bf4;
																																	case 12:
																																	case 116:
																																		goto IL_0c02;
																																	case 100:
																																		goto IL_0c70;
																																	case 202:
																																		goto IL_0c83;
																																	case 90:
																																		goto IL_0c91;
																																	case 138:
																																	case 247:
																																		goto IL_0c9c;
																																	case 134:
																																		goto IL_0cb4;
																																	case 93:
																																		goto IL_0cc2;
																																	case 13:
																																		goto IL_0cd0;
																																	case 242:
																																		goto IL_0ce3;
																																	case 32:
																																		goto IL_0cf1;
																																	case 129:
																																	case 156:
																																		goto IL_0cff;
																																	case 94:
																																		goto IL_0d51;
																																	case 249:
																																		goto IL_0d64;
																																	case 188:
																																		goto IL_0d6f;
																																	case 147:
																																		goto IL_0d7d;
																																	case 194:
																																	case 262:
																																		goto IL_0d8b;
																																	case 303:
																																		goto IL_0da5;
																																	case 110:
																																		goto IL_0db3;
																																	case 280:
																																		goto IL_0dc1;
																																	case 155:
																																		goto IL_0ddd;
																																	case 68:
																																	case 172:
																																		goto IL_0deb;
																																	case 289:
																																		goto IL_0e29;
																																	case 109:
																																		goto IL_0e3d;
																																	case 19:
																																	case 317:
																																		goto IL_0e50;
																																	case 145:
																																		goto IL_0e90;
																																	case 74:
																																		goto IL_0ea4;
																																	case 319:
																																		goto IL_0eb7;
																																	case 124:
																																	case 321:
																																		goto IL_0ed3;
																																	case 325:
																																		goto IL_0eef;
																																	case 135:
																																		goto IL_0f03;
																																	case 327:
																																		goto IL_0f16;
																																	case 148:
																																		goto IL_0f24;
																																	case 25:
																																	case 34:
																																		goto IL_0f32;
																																	case 153:
																																		goto IL_0f46;
																																	case 92:
																																		goto IL_0fae;
																																	case 222:
																																		goto IL_0fbc;
																																	case 330:
																																		goto IL_0fcf;
																																	case 6:
																																		goto IL_0fdd;
																																	case 282:
																																	case 286:
																																		goto IL_0fe8;
																																	case 159:
																																		goto IL_1028;
																																	case 271:
																																		goto IL_1041;
																																	case 264:
																																		goto IL_104c;
																																	case 101:
																																		goto IL_105f;
																																	case 328:
																																		goto IL_106d;
																																	case 298:
																																	case 307:
																																		goto IL_107b;
																																	case 225:
																																		goto IL_108f;
																																	case 235:
																																		goto IL_10ce;
																																	case 216:
																																		goto IL_10e1;
																																	case 214:
																																		goto IL_10ef;
																																	case 72:
																																	case 323:
																																		goto IL_1106;
																																	case 127:
																																		goto IL_1123;
																																	case 161:
																																		goto IL_1162;
																																	case 260:
																																		goto IL_1175;
																																	case 181:
																																		goto IL_1183;
																																	case 331:
																																		goto IL_1196;
																																	case 160:
																																	case 283:
																																		goto IL_11a1;
																																	case 183:
																																		goto IL_11cf;
																																	case 306:
																																		goto IL_11e2;
																																	case 7:
																																		goto IL_11f0;
																																	case 36:
																																	case 223:
																																		goto IL_11fe;
																																	case 257:
																																	case 333:
																																		goto IL_1243;
																																	case 313:
																																		goto IL_125a;
																																	case 139:
																																		goto IL_127e;
																																	case 62:
																																		goto IL_128c;
																																	case 256:
																																	case 337:
																																		goto IL_129f;
																																	case 215:
																																		goto IL_12df;
																																	case 143:
																																		goto IL_12f3;
																																	case 343:
																																		goto IL_1306;
																																	case 112:
																																	case 345:
																																		goto IL_1319;
																																	case 63:
																																		goto IL_1332;
																																	case 175:
																																		goto IL_1340;
																																	case 324:
																																		goto IL_134e;
																																	case 349:
																																		goto IL_1361;
																																	case 30:
																																		goto IL_1375;
																																	case 350:
																																		goto IL_1388;
																																	case 26:
																																		goto IL_1396;
																																	case 176:
																																		goto IL_13a1;
																																	case 277:
																																	case 304:
																																		goto IL_13af;
																																	case 269:
																																		goto IL_13c2;
																																	case 193:
																																		goto IL_13d0;
																																	case 45:
																																	case 241:
																																		goto IL_13e7;
																																	case 52:
																																		goto IL_1427;
																																	case 71:
																																		goto IL_143b;
																																	case 53:
																																		goto IL_1457;
																																	case 228:
																																	case 320:
																																		goto IL_1462;
																																	case 332:
																																		goto IL_14a2;
																																	case 314:
																																		goto IL_14b6;
																																	case 81:
																																		goto IL_14d2;
																																	case 21:
																																		goto IL_14e0;
																																	case 246:
																																	case 253:
																																		goto IL_14ee;
																																	case 239:
																																		goto IL_152e;
																																	case 47:
																																		goto IL_1542;
																																	case 353:
																																		goto IL_1555;
																																	case 97:
																																		goto IL_1563;
																																	case 297:
																																		goto IL_1589;
																																	case 309:
																																		goto IL_1597;
																																	case 16:
																																	case 18:
																																		goto IL_15ae;
																																	case 273:
																																		goto IL_15c6;
																																	case 210:
																																		goto IL_15e4;
																																	case 67:
																																		goto end_IL_05d3;
																																	case 35:
																																		goto IL_1629;
																																	case 339:
																																		goto IL_163c;
																																	case 39:
																																		goto IL_164a;
																																	case 318:
																																		goto IL_1655;
																																	case 237:
																																		goto IL_1663;
																																	case 130:
																																	case 272:
																																		goto IL_1688;
																																	case 308:
																																		goto IL_173f;
																																	case 42:
																																		goto IL_174d;
																																	case 14:
																																		goto IL_1760;
																																	case 170:
																																		goto IL_176b;
																																	case 336:
																																	case 346:
																																		goto IL_1779;
																																	case 211:
																																		goto IL_1797;
																																	case 261:
																																		goto IL_17a5;
																																	case 287:
																																		goto IL_17b8;
																																	case 238:
																																		goto IL_17c6;
																																	case 294:
																																	case 341:
																																		goto IL_17d4;
																																	case 191:
																																		goto IL_17fd;
																																	case 195:
																																		goto IL_181f;
																																	case 207:
																																		goto IL_182d;
																																	case 178:
																																		goto IL_183b;
																																	case 11:
																																		goto IL_1846;
																																	case 15:
																																	case 299:
																																		goto IL_1854;
																																	case 240:
																																		goto IL_1862;
																																	case 200:
																																		goto IL_187a;
																																	case 192:
																																		goto IL_1888;
																																	case 329:
																																		goto IL_189b;
																																	case 118:
																																		goto IL_18a9;
																																	case 149:
																																	case 348:
																																		goto IL_18b7;
																																	case 259:
																																		goto IL_18f5;
																																	case 293:
																																	case 344:
																																		goto IL_1908;
																																	case 20:
																																		goto IL_191c;
																																	case 102:
																																		goto IL_1954;
																																	case 70:
																																		goto IL_1967;
																																	case 48:
																																		goto IL_1972;
																																	case 243:
																																	case 292:
																																		goto IL_197d;
																																	case 315:
																																		goto IL_1996;
																																	case 302:
																																		goto IL_19a4;
																																	case 96:
																																		goto IL_19b2;
																																	case 340:
																																		goto IL_19c2;
																																	case 86:
																																		goto IL_19cd;
																																	case 187:
																																	case 311:
																																		goto IL_19d8;
																																	case 24:
																																	case 38:
																																	case 43:
																																	case 44:
																																	case 49:
																																	case 55:
																																	case 57:
																																	case 58:
																																	case 77:
																																	case 79:
																																	case 80:
																																	case 95:
																																	case 108:
																																	case 115:
																																	case 121:
																																	case 131:
																																	case 132:
																																	case 133:
																																	case 137:
																																	case 151:
																																	case 154:
																																	case 162:
																																	case 166:
																																	case 189:
																																	case 198:
																																	case 199:
																																	case 218:
																																	case 224:
																																	case 226:
																																	case 230:
																																	case 234:
																																	case 244:
																																	case 245:
																																	case 267:
																																	case 274:
																																	case 279:
																																	case 284:
																																	case 285:
																																	case 290:
																																	case 295:
																																	case 296:
																																	case 301:
																																	case 305:
																																	case 352:
																																	case 354:
																																		goto end_IL_0690;
																																	case 3:
																																	case 4:
																																	case 10:
																																	case 17:
																																	case 23:
																																	case 27:
																																	case 40:
																																	case 41:
																																	case 50:
																																	case 54:
																																	case 59:
																																	case 66:
																																	case 75:
																																	case 83:
																																	case 85:
																																	case 89:
																																	case 98:
																																	case 103:
																																	case 105:
																																	case 106:
																																	case 113:
																																	case 117:
																																	case 119:
																																	case 125:
																																	case 128:
																																	case 146:
																																	case 164:
																																	case 165:
																																	case 167:
																																	case 173:
																																	case 197:
																																	case 208:
																																	case 213:
																																	case 229:
																																	case 250:
																																	case 252:
																																	case 263:
																																	case 266:
																																	case 276:
																																	case 335:
																																	case 338:
																																	case 342:
																																	case 347:
																																	case 351:
																																	case 355:
																																		goto IL_1a00;
																																	case 91:
																																		goto IL_1a13;
																																	case 326:
																																		goto IL_1a1d;
																																	case 2:
																																		goto IL_1a28;
																																	case 168:
																																		goto IL_1a38;
																																	case 278:
																																		goto IL_1a48;
																																	case 84:
																																		goto IL_1a58;
																																	case 322:
																																		goto IL_1a68;
																																	case 28:
																																		goto IL_1a78;
																																	case 334:
																																		goto IL_1a88;
																																	case 206:
																																		goto IL_1a98;
																																	case 182:
																																		goto IL_1aa8;
																																	case 220:
																																		goto IL_1ab8;
																																	case 78:
																																	case 268:
																																		goto IL_1ad3;
																																	}
																																	goto end_IL_0663;
																																}
																																num6 -= 2;
																																goto IL_1a00;
																																continue;
																																end_IL_05d3:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_06de;
																													IL_14b6:
																													num6--;
																													num = 4;
																													goto IL_1a00;
																													IL_14d2:
																													if (6 < b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_14e0;
																													IL_06de:
																													if (5 >= b)
																													{
																														goto IL_0701;
																													}
																													goto IL_1388;
																													IL_0701:
																													if (5 > b)
																													{
																														goto IL_070f;
																													}
																													goto IL_0a69;
																													IL_070f:
																													if (2 < b)
																													{
																														goto IL_071a;
																													}
																													num = 158;
																													goto IL_079c;
																													IL_071a:
																													if (3 >= b)
																													{
																														goto IL_0725;
																													}
																													goto IL_0741;
																													IL_0725:
																													if (3 > b)
																													{
																														goto end_IL_0690;
																													}
																													num = 203;
																													goto IL_08cf;
																													IL_14ee:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_152e;
																													IL_08cf:
																													reference = ref array5[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_08f8;
																													IL_08f8:
																													ptr2 += 8;
																													goto IL_0906;
																													IL_0906:
																													num6--;
																													goto IL_1a00;
																													IL_0741:
																													if (4 < b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_074f;
																													IL_074f:
																													if (4 > b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_075d;
																													IL_075d:
																													array2[num6] = 0;
																													goto IL_076b;
																													IL_076b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																													goto IL_089f;
																													IL_089f:
																													array3[num6] = null;
																													goto IL_08a9;
																													IL_08a9:
																													num6++;
																													goto IL_0aae;
																													IL_0aae:
																													ptr2 += 8;
																													goto IL_1a00;
																													IL_14e0:
																													if (6 > b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_14ee;
																													IL_079c:
																													if (2 > b)
																													{
																														goto IL_07aa;
																													}
																													goto IL_0e50;
																													IL_07aa:
																													if (1 < b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_07ca;
																													IL_07ca:
																													if (1 > b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_07d8;
																													IL_07d8:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																													goto IL_07f1;
																													IL_07f1:
																													array2[num6] = 0;
																													goto IL_07ff;
																													IL_07ff:
																													num6++;
																													goto IL_080d;
																													IL_080d:
																													ptr2 += 8;
																													goto IL_1a00;
																													IL_0e50:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0e90;
																													IL_0e90:
																													array2[num6 - 2] = 0;
																													goto IL_0ea4;
																													IL_0ea4:
																													num6--;
																													goto IL_1a00;
																													IL_0a69:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0eef;
																													IL_0eef:
																													array2[num6 - 2] = 0;
																													goto IL_0f03;
																													IL_0f03:
																													num6--;
																													goto IL_1a00;
																													IL_1388:
																													if (7 < b)
																													{
																														goto IL_1396;
																													}
																													num = 53;
																													goto IL_1457;
																													IL_1396:
																													if (8 >= b)
																													{
																														goto IL_13a1;
																													}
																													goto IL_13c2;
																													IL_13a1:
																													if (8 > b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_13af;
																													IL_13af:
																													num6--;
																													goto IL_1a00;
																													IL_13c2:
																													if (9 < b)
																													{
																														goto end_IL_0690;
																													}
																													goto IL_13d0;
																													IL_13d0:
																													if (9 > b)
																													{
																														goto end_IL_0690;
																													}
																													num = 45;
																													goto IL_13e7;
																													IL_1542:
																													num6--;
																													goto IL_1a00;
																													IL_13e7:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_1427;
																													IL_1427:
																													array2[num6 - 2] = 0;
																													goto IL_143b;
																													IL_143b:
																													num6--;
																													goto IL_1a00;
																													IL_152e:
																													array2[num6 - 2] = 0;
																													goto IL_1542;
																													IL_1457:
																													if (7 <= b)
																													{
																														goto IL_1462;
																													}
																													goto IL_14d2;
																													IL_1462:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_14a2;
																													IL_14a2:
																													array2[num6 - 2] = 0;
																													goto IL_14b6;
																												}
																												goto IL_1608;
																												IL_197d:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																												goto IL_1996;
																												IL_1589:
																												if (15 >= b)
																												{
																													goto IL_1597;
																												}
																												goto IL_181f;
																												IL_1597:
																												if (15 <= b)
																												{
																													num = 16;
																													goto IL_15ae;
																												}
																												goto IL_163c;
																												IL_1996:
																												array2[num6] = 1;
																												goto IL_19a4;
																												IL_15ae:
																												array2[num6] = array2[num6 - 1];
																												goto IL_15c6;
																												IL_15c6:
																												array4[num6 - 0] = array4[num6 - 1];
																												goto IL_15e4;
																												IL_15e4:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_1608;
																												IL_1608:
																												array3[num6] = array3[num6 - 1];
																												num = 35;
																												goto IL_1629;
																												IL_1629:
																												num6++;
																												goto IL_1a00;
																												IL_163c:
																												if (12 >= b)
																												{
																													goto IL_164a;
																												}
																												goto IL_1760;
																												IL_164a:
																												if (12 > b)
																												{
																													goto IL_1655;
																												}
																												num = 272;
																												goto IL_1688;
																												IL_1655:
																												if (11 < b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_1663;
																												IL_1663:
																												if (11 > b)
																												{
																													goto end_IL_0690;
																												}
																												num = 59;
																												goto IL_1a00;
																												IL_19b2:
																												ptr2 += 16;
																												goto IL_1a00;
																												IL_19a4:
																												num6++;
																												goto IL_19b2;
																												IL_1688:
																												array8 = array3;
																												num7 = num6;
																												if (array == null)
																												{
																													goto IL_1697;
																												}
																												num8 = ptr2;
																												byte b2 = *num8;
																												ptr2 = num8 + 4;
																												int num9 = *(int*)(ptr2 + num3);
																												ptr2 += 8;
																												byte* ptr3 = ptr2 + num9;
																												byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																												while (ptr2 != ptr3)
																												{
																													*ptr4 = (byte)(*ptr2 ^ b2);
																													ptr2++;
																													ptr4++;
																												}
																												array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																												goto IL_173f;
																												IL_19c2:
																												if (20 < b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_19cd;
																												IL_19cd:
																												if (20 > b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_19d8;
																												IL_19d8:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												goto IL_1a00;
																												IL_173f:
																												array2[num6] = 5;
																												goto IL_174d;
																												IL_174d:
																												num6++;
																												goto IL_1a00;
																												IL_1760:
																												if (13 >= b)
																												{
																													goto IL_176b;
																												}
																												goto IL_17b8;
																												IL_176b:
																												if (13 > b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_1779;
																												IL_1779:
																												array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																												goto IL_1797;
																												IL_1797:
																												ptr2 += 8;
																												goto IL_17a5;
																												IL_17a5:
																												num6--;
																												goto IL_1a00;
																												IL_17b8:
																												if (14 < b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_17c6;
																												IL_17c6:
																												if (14 > b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_17d4;
																												IL_17d4:
																												array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																												goto IL_17fd;
																												IL_17fd:
																												array2[num6 - 1] = 5;
																												num = 105;
																												goto IL_1a00;
																												IL_181f:
																												if (18 >= b)
																												{
																													goto IL_182d;
																												}
																												goto IL_1967;
																												IL_182d:
																												if (18 > b)
																												{
																													goto IL_183b;
																												}
																												goto IL_1908;
																												IL_183b:
																												if (16 >= b)
																												{
																													goto IL_1846;
																												}
																												goto IL_189b;
																												IL_1846:
																												if (16 > b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_1854;
																												IL_1854:
																												array2[num6] = 5;
																												goto IL_1862;
																												IL_1862:
																												array3[num6] = array7[*(int*)(ptr2 + num3)];
																												goto IL_187a;
																												IL_187a:
																												num6++;
																												goto IL_1888;
																												IL_1888:
																												ptr2 += 8;
																												goto IL_1a00;
																												IL_189b:
																												if (17 < b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_18a9;
																												IL_18a9:
																												if (17 > b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_18b7;
																												IL_18b7:
																												((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																												goto IL_18f5;
																												IL_18f5:
																												num6 -= 3;
																												goto IL_1a00;
																												IL_1908:
																												array2[num6 - 1] = 5;
																												goto IL_191c;
																												IL_191c:
																												array3[num6 - 1] = ((delegate*<string[], string>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																												goto IL_1954;
																												IL_1954:
																												ptr2 += 8;
																												goto IL_1a00;
																												IL_1967:
																												if (19 >= b)
																												{
																													goto IL_1972;
																												}
																												goto IL_19c2;
																												IL_1972:
																												if (19 > b)
																												{
																													goto end_IL_0690;
																												}
																												goto IL_197d;
																												continue;
																												end_IL_0663:
																												break;
																											}
																											break;
																										}
																										goto IL_0b7e;
																										IL_0bd3:
																										num6--;
																										goto IL_1a00;
																										IL_0b7e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																										goto IL_0bbf;
																										IL_0bbf:
																										array2[num6 - 2] = 0;
																										goto IL_0bd3;
																									}
																									break;
																								}
																								goto IL_06ce;
																								IL_0b22:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_06ce:
																								if (32 < b)
																								{
																									goto IL_06ee;
																								}
																								goto IL_0b45;
																								IL_0b45:
																								if (32 > b)
																								{
																									goto IL_0be6;
																								}
																								goto IL_129f;
																								IL_129f:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_12df;
																								IL_12df:
																								array2[num6 - 2] = 3;
																								goto IL_12f3;
																								IL_12f3:
																								num6--;
																								goto IL_1a00;
																								IL_0be6:
																								if (26 >= b)
																								{
																									goto IL_0bf4;
																								}
																								goto IL_0fcf;
																								IL_0bf4:
																								if (26 <= b)
																								{
																									goto IL_0c02;
																								}
																								goto IL_0c83;
																								IL_0c02:
																								ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0c70;
																								IL_0c70:
																								num6 -= 2;
																								goto IL_1a00;
																								IL_0c83:
																								if (23 >= b)
																								{
																									goto IL_0c91;
																								}
																								goto IL_0d64;
																								IL_0c91:
																								if (23 <= b)
																								{
																									goto IL_0c9c;
																								}
																								goto IL_0ce3;
																								IL_0c9c:
																								array3[num6] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0cb4;
																								IL_0cb4:
																								array2[num6] = 5;
																								goto IL_0cc2;
																								IL_0cc2:
																								num6++;
																								goto IL_0cd0;
																								IL_0cd0:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_0ce3:
																								if (22 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0cf1;
																								IL_0cf1:
																								if (22 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0cff;
																								IL_0cff:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0d51;
																								IL_0d51:
																								num6--;
																								goto IL_1a00;
																								IL_0d64:
																								if (24 < b)
																								{
																									goto IL_0d6f;
																								}
																								num = 155;
																								goto IL_0ddd;
																								IL_0d6f:
																								if (25 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0d7d;
																								IL_0d7d:
																								if (25 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0d8b;
																								IL_0d8b:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																								goto IL_0da5;
																								IL_0da5:
																								array2[num6] = 3;
																								goto IL_0db3;
																								IL_0db3:
																								num6++;
																								goto IL_0dc1;
																								IL_0dc1:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_0b35:
																								if (42 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0b6b;
																								IL_0ddd:
																								if (24 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0deb;
																								IL_0deb:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class179, float>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((Class179)array3[num6 - 1]);
																								goto IL_0e29;
																								IL_0e29:
																								array2[num6 - 1] = 3;
																								goto IL_0e3d;
																								IL_0e3d:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_0fcf:
																								if (29 >= b)
																								{
																									goto IL_0fdd;
																								}
																								goto IL_10e1;
																								IL_0fdd:
																								if (29 <= b)
																								{
																									goto IL_0fe8;
																								}
																								goto IL_1041;
																								IL_0fe8:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1028;
																								IL_1028:
																								array2[num6 - 2] = 3;
																								goto IL_1306;
																								IL_1306:
																								num6--;
																								goto IL_1a00;
																								IL_1041:
																								if (27 >= b)
																								{
																									goto IL_104c;
																								}
																								goto IL_105f;
																								IL_104c:
																								if (27 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_1319;
																								IL_1319:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																								goto IL_1332;
																								IL_1332:
																								array2[num6] = 3;
																								goto IL_1340;
																								IL_1340:
																								num6++;
																								goto IL_134e;
																								IL_134e:
																								ptr2 += 16;
																								goto IL_1a00;
																								IL_105f:
																								if (28 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_106d;
																								IL_106d:
																								if (28 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_107b;
																								IL_107b:
																								array2[num6 - 1] = 3;
																								goto IL_108f;
																								IL_108f:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_10ce;
																								IL_10ce:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_10e1:
																								if (30 >= b)
																								{
																									goto IL_10ef;
																								}
																								goto IL_1175;
																								IL_10ef:
																								if (30 > b)
																								{
																									goto end_IL_0690;
																								}
																								num = 72;
																								goto IL_1106;
																								IL_0b6b:
																								if (42 > b)
																								{
																								}
																								goto end_IL_0690;
																								IL_1106:
																								array2[num6 - 1] = 0;
																								num = 127;
																								goto IL_1123;
																								IL_1123:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1162;
																								IL_1162:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_1175:
																								if (31 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_1183;
																								IL_1183:
																								if (31 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_1243;
																								IL_1243:
																								array2[num6] = 3;
																								num = 313;
																								goto IL_125a;
																								IL_125a:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])();
																								goto IL_127e;
																								IL_127e:
																								num6++;
																								goto IL_128c;
																								IL_128c:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_06ee:
																								if (37 < b)
																								{
																									goto IL_07ba;
																								}
																								goto IL_0919;
																								IL_0919:
																								if (37 <= b)
																								{
																									goto IL_0924;
																								}
																								goto IL_098f;
																								IL_0924:
																								array2[num6 - 2] = 0;
																								goto IL_0938;
																								IL_0938:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																								goto IL_0b58;
																								IL_0b58:
																								num6--;
																								goto IL_0eb7;
																								IL_0eb7:
																								ptr2 += 8;
																								num = 167;
																								goto IL_1a00;
																								IL_098f:
																								if (34 < b)
																								{
																									goto IL_099d;
																								}
																								goto IL_1196;
																								IL_099d:
																								if (35 >= b)
																								{
																									goto IL_09a8;
																								}
																								goto IL_0a1c;
																								IL_09a8:
																								if (35 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_09b6;
																								IL_09b6:
																								array2[num6 - 1] = 3;
																								goto IL_09ca;
																								IL_09ca:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_0a09;
																								IL_0a09:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_0a1c:
																								if (36 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0a2a;
																								IL_0a2a:
																								if (36 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0a38;
																								IL_0a38:
																								array2[num6] = 5;
																								goto IL_0a46;
																								IL_0a46:
																								array3[num6] = ((delegate*<string>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])();
																								goto IL_1555;
																								IL_1555:
																								num6++;
																								goto IL_1563;
																								IL_1563:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_1196:
																								if (34 <= b)
																								{
																									goto IL_11a1;
																								}
																								goto IL_11e2;
																								IL_11a1:
																								((Class179)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_11cf;
																								IL_11cf:
																								num6 -= 2;
																								goto IL_1a00;
																								IL_11e2:
																								if (33 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_11f0;
																								IL_11f0:
																								if (33 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_11fe;
																								IL_11fe:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_1361;
																								IL_1361:
																								array2[num6 - 2] = 3;
																								goto IL_1375;
																								IL_1375:
																								num6--;
																								goto IL_1a00;
																								IL_07ba:
																								if (40 >= b)
																								{
																									goto IL_0820;
																								}
																								goto IL_0ac1;
																								IL_0820:
																								if (40 > b)
																								{
																									goto IL_082e;
																								}
																								goto IL_0ed3;
																								IL_082e:
																								if (38 >= b)
																								{
																									goto IL_083c;
																								}
																								goto IL_0f16;
																								IL_083c:
																								if (38 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_084a;
																								IL_084a:
																								array2[num6 - 1] = 3;
																								goto IL_085e;
																								IL_085e:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_08bc;
																								IL_08bc:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_0f16:
																								if (39 < b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0f24;
																								IL_0f24:
																								if (39 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0f32;
																								IL_0f32:
																								array2[num6 - 3] = 4;
																								goto IL_0f46;
																								IL_0f46:
																								array3[num6 - 3] = ((delegate*<float, float, float, Color>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																								goto IL_0fae;
																								IL_0fae:
																								num6 -= 2;
																								goto IL_0fbc;
																								IL_0fbc:
																								ptr2 += 8;
																								goto IL_1a00;
																								IL_0ed3:
																								num10 = ptr2;
																								num11 = -200;
																								num5 = 1;
																								ptr2 = num10 + num11;
																								goto IL_1a00;
																								IL_0ac1:
																								if (41 >= b)
																								{
																									goto IL_0acc;
																								}
																								goto IL_0b35;
																								IL_0acc:
																								if (41 > b)
																								{
																									goto end_IL_0690;
																								}
																								goto IL_0ada;
																								IL_0ada:
																								array2[num6] = 4;
																								goto IL_0ae8;
																								IL_0ae8:
																								array3[num6] = ((delegate*<Color>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])();
																								goto IL_0b0b;
																								IL_0b0b:
																								num6++;
																								num = 217;
																								goto IL_0b22;
																							}
																							goto end_IL_06a3;
																							continue;
																							end_IL_0690:
																							break;
																							IL_0690:;
																						}
																					}
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_1a00;
																					continue;
																					end_IL_06a3:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_1ad3;
																	IL_1ad3:
																	return (Color)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_1697:
			while (true)
			{
				IL_1697_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_173f_2:
						array2[num6] = 5;
						while (true)
						{
							IL_174d_2:
							num6++;
							while (true)
							{
								IL_1a00_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_06a3_2:
												if (b >= 1)
												{
													while (b <= 42)
													{
														num = 88;
														while (true)
														{
															if (21 >= b)
															{
																while (true)
																{
																	if (21 > b)
																	{
																		while (true)
																		{
																			IL_0663_2:
																			if (10 < b)
																			{
																				goto IL_1589_2;
																			}
																			while (true)
																			{
																				IL_0653_2:
																				if (10 <= b)
																				{
																					num = 310;
																					while (true)
																					{
																						IL_05e6_2:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						num = 362;
																						while (true)
																						{
																							if (num != 362)
																							{
																								if (num != 1343)
																								{
																									break;
																								}
																								switch (num)
																								{
																								case 174:
																								case 310:
																									goto IL_05e6_2;
																								case 136:
																									goto IL_0653_2;
																								case 126:
																									goto IL_0663_2;
																								case 163:
																									goto end_IL_0663_2;
																								case 88:
																									goto end_IL_0673;
																								case 9:
																									goto end_IL_0683;
																								case 82:
																									goto IL_06a3_2;
																								case 254:
																									goto end_IL_06a3_2;
																								case 65:
																								case 201:
																									goto end_IL_06b3;
																								case 29:
																									goto IL_06ce_2;
																								case 33:
																									goto IL_06de_2;
																								case 186:
																									goto IL_06ee_2;
																								case 190:
																									goto IL_0701_2;
																								case 180:
																									goto IL_070f_2;
																								case 107:
																									goto IL_071a_2;
																								case 56:
																									goto IL_0725_2;
																								case 31:
																									goto IL_0741_2;
																								case 111:
																									goto IL_074f_2;
																								case 123:
																								case 140:
																									goto IL_075d_2;
																								case 60:
																									goto IL_076b_2;
																								case 158:
																									goto IL_079c_2;
																								case 142:
																									goto IL_07aa_2;
																								case 204:
																									goto IL_07ba_2;
																								case 231:
																									goto IL_07ca_2;
																								case 152:
																								case 177:
																									goto IL_07d8_2;
																								case 5:
																									goto IL_07f1_2;
																								case 212:
																									goto IL_07ff_2;
																								case 233:
																									goto IL_080d_2;
																								case 236:
																									goto IL_0820_2;
																								case 22:
																									goto IL_082e_2;
																								case 69:
																									goto IL_083c_2;
																								case 120:
																								case 122:
																									goto IL_084a_2;
																								case 1:
																									goto IL_085e_2;
																								case 248:
																									goto IL_089f_2;
																								case 157:
																									goto IL_08a9_2;
																								case 251:
																									goto IL_08bc_2;
																								case 203:
																								case 255:
																									goto IL_08cf_2;
																								case 171:
																									goto IL_08f8_2;
																								case 64:
																									goto IL_0906_2;
																								case 258:
																									goto IL_0919_2;
																								case 114:
																								case 196:
																									goto IL_0924_2;
																								case 209:
																									goto IL_0938_2;
																								case 169:
																									goto IL_098f_2;
																								case 150:
																									goto IL_099d_2;
																								case 0:
																									goto IL_09a8_2;
																								case 184:
																								case 205:
																									goto IL_09b6_2;
																								case 179:
																									goto IL_09ca_2;
																								case 73:
																									goto IL_0a09_2;
																								case 37:
																									goto IL_0a1c_2;
																								case 87:
																									goto IL_0a2a_2;
																								case 61:
																								case 144:
																									goto IL_0a38_2;
																								case 51:
																									goto IL_0a46_2;
																								case 265:
																								case 270:
																									goto IL_0a69_2;
																								case 275:
																									goto IL_0aae_2;
																								case 281:
																									goto IL_0ac1_2;
																								case 232:
																									goto IL_0acc_2;
																								case 141:
																								case 219:
																									goto IL_0ada_2;
																								case 185:
																									goto IL_0ae8_2;
																								case 227:
																									goto IL_0b0b_2;
																								case 217:
																									goto IL_0b22_2;
																								case 99:
																									goto IL_0b35_2;
																								case 288:
																									goto IL_0b45_2;
																								case 291:
																									goto IL_0b58_2;
																								case 300:
																									goto IL_0b6b_2;
																								case 8:
																								case 312:
																									goto IL_0b7e_2;
																								case 104:
																									goto IL_0bbf_2;
																								case 46:
																									goto IL_0bd3_2;
																								case 316:
																									goto IL_0be6_2;
																								case 76:
																									goto IL_0bf4_2;
																								case 12:
																								case 116:
																									goto IL_0c02_2;
																								case 100:
																									goto IL_0c70_2;
																								case 202:
																									goto IL_0c83_2;
																								case 90:
																									goto IL_0c91_2;
																								case 138:
																								case 247:
																									goto IL_0c9c_2;
																								case 134:
																									goto IL_0cb4_2;
																								case 93:
																									goto IL_0cc2_2;
																								case 13:
																									goto IL_0cd0_2;
																								case 242:
																									goto IL_0ce3_2;
																								case 32:
																									goto IL_0cf1_2;
																								case 129:
																								case 156:
																									goto IL_0cff_2;
																								case 94:
																									goto IL_0d51_2;
																								case 249:
																									goto IL_0d64_2;
																								case 188:
																									goto IL_0d6f_2;
																								case 147:
																									goto IL_0d7d_2;
																								case 194:
																								case 262:
																									goto IL_0d8b_2;
																								case 303:
																									goto IL_0da5_2;
																								case 110:
																									goto IL_0db3_2;
																								case 280:
																									goto IL_0dc1_2;
																								case 155:
																									goto IL_0ddd_2;
																								case 68:
																								case 172:
																									goto IL_0deb_2;
																								case 289:
																									goto IL_0e29_2;
																								case 109:
																									goto IL_0e3d_2;
																								case 19:
																								case 317:
																									goto IL_0e50_2;
																								case 145:
																									goto IL_0e90_2;
																								case 74:
																									goto IL_0ea4_2;
																								case 319:
																									goto IL_0eb7_2;
																								case 124:
																								case 321:
																									goto IL_0ed3_2;
																								case 325:
																									goto IL_0eef_2;
																								case 135:
																									goto IL_0f03_2;
																								case 327:
																									goto IL_0f16_2;
																								case 148:
																									goto IL_0f24_2;
																								case 25:
																								case 34:
																									goto IL_0f32_2;
																								case 153:
																									goto IL_0f46_2;
																								case 92:
																									goto IL_0fae_2;
																								case 222:
																									goto IL_0fbc_2;
																								case 330:
																									goto IL_0fcf_2;
																								case 6:
																									goto IL_0fdd_2;
																								case 282:
																								case 286:
																									goto IL_0fe8_2;
																								case 159:
																									goto IL_1028_2;
																								case 271:
																									goto IL_1041_2;
																								case 264:
																									goto IL_104c_2;
																								case 101:
																									goto IL_105f_2;
																								case 328:
																									goto IL_106d_2;
																								case 298:
																								case 307:
																									goto IL_107b_2;
																								case 225:
																									goto IL_108f_2;
																								case 235:
																									goto IL_10ce_2;
																								case 216:
																									goto IL_10e1_2;
																								case 214:
																									goto IL_10ef_2;
																								case 72:
																								case 323:
																									goto IL_1106_2;
																								case 127:
																									goto IL_1123_2;
																								case 161:
																									goto IL_1162_2;
																								case 260:
																									goto IL_1175_2;
																								case 181:
																									goto IL_1183_2;
																								case 331:
																									goto IL_1196_2;
																								case 160:
																								case 283:
																									goto IL_11a1_2;
																								case 183:
																									goto IL_11cf_2;
																								case 306:
																									goto IL_11e2_2;
																								case 7:
																									goto IL_11f0_2;
																								case 36:
																								case 223:
																									goto IL_11fe_2;
																								case 257:
																								case 333:
																									goto IL_1243_2;
																								case 313:
																									goto IL_125a_2;
																								case 139:
																									goto IL_127e_2;
																								case 62:
																									goto IL_128c_2;
																								case 256:
																								case 337:
																									goto IL_129f_2;
																								case 215:
																									goto IL_12df_2;
																								case 143:
																									goto IL_12f3_2;
																								case 343:
																									goto IL_1306_2;
																								case 112:
																								case 345:
																									goto IL_1319_2;
																								case 63:
																									goto IL_1332_2;
																								case 175:
																									goto IL_1340_2;
																								case 324:
																									goto IL_134e_2;
																								case 349:
																									goto IL_1361_2;
																								case 30:
																									goto IL_1375_2;
																								case 350:
																									goto IL_1388_2;
																								case 26:
																									goto IL_1396_2;
																								case 176:
																									goto IL_13a1_2;
																								case 277:
																								case 304:
																									goto IL_13af_2;
																								case 269:
																									goto IL_13c2_2;
																								case 193:
																									goto IL_13d0_2;
																								case 45:
																								case 241:
																									goto IL_13e7_2;
																								case 52:
																									goto IL_1427_2;
																								case 71:
																									goto IL_143b_2;
																								case 53:
																									goto IL_1457_2;
																								case 228:
																								case 320:
																									goto IL_1462_2;
																								case 332:
																									goto IL_14a2_2;
																								case 314:
																									goto IL_14b6_2;
																								case 81:
																									goto IL_14d2_2;
																								case 21:
																									goto IL_14e0_2;
																								case 246:
																								case 253:
																									goto IL_14ee_2;
																								case 239:
																									goto IL_152e_2;
																								case 47:
																									goto IL_1542_2;
																								case 353:
																									goto IL_1555_2;
																								case 97:
																									goto IL_1563_2;
																								case 297:
																									goto IL_1589_2;
																								case 309:
																									goto IL_1597_2;
																								case 16:
																								case 18:
																									goto IL_15ae_2;
																								case 273:
																									goto IL_15c6_2;
																								case 210:
																									goto IL_15e4_2;
																								case 67:
																									goto end_IL_05d3_2;
																								case 35:
																									goto IL_1629_2;
																								case 339:
																									goto IL_163c_2;
																								case 39:
																									goto IL_164a_2;
																								case 318:
																									goto IL_1655_2;
																								case 237:
																									goto IL_1663_2;
																								case 130:
																								case 272:
																									goto end_IL_06c3;
																								case 308:
																									goto IL_173f_2;
																								case 42:
																									goto IL_174d_2;
																								case 14:
																									goto IL_1760_2;
																								case 170:
																									goto IL_176b_2;
																								case 336:
																								case 346:
																									goto IL_1779_2;
																								case 211:
																									goto IL_1797_2;
																								case 261:
																									goto IL_17a5_2;
																								case 287:
																									goto IL_17b8_2;
																								case 238:
																									goto IL_17c6_2;
																								case 294:
																								case 341:
																									goto IL_17d4_2;
																								case 191:
																									goto IL_17fd_2;
																								case 195:
																									goto IL_181f_2;
																								case 207:
																									goto IL_182d_2;
																								case 178:
																									goto IL_183b_2;
																								case 11:
																									goto IL_1846_2;
																								case 15:
																								case 299:
																									goto IL_1854_2;
																								case 240:
																									goto IL_1862_2;
																								case 200:
																									goto IL_187a_2;
																								case 192:
																									goto IL_1888_2;
																								case 329:
																									goto IL_189b_2;
																								case 118:
																									goto IL_18a9_2;
																								case 149:
																								case 348:
																									goto IL_18b7_2;
																								case 259:
																									goto IL_18f5_2;
																								case 293:
																								case 344:
																									goto IL_1908_2;
																								case 20:
																									goto IL_191c_2;
																								case 102:
																									goto IL_1954_2;
																								case 70:
																									goto IL_1967_2;
																								case 48:
																									goto IL_1972_2;
																								case 243:
																								case 292:
																									goto IL_197d_2;
																								case 315:
																									goto IL_1996_2;
																								case 302:
																									goto IL_19a4_2;
																								case 96:
																									goto IL_19b2_2;
																								case 340:
																									goto IL_19c2_2;
																								case 86:
																									goto IL_19cd_2;
																								case 187:
																								case 311:
																									goto IL_19d8_2;
																								case 24:
																								case 38:
																								case 43:
																								case 44:
																								case 49:
																								case 55:
																								case 57:
																								case 58:
																								case 77:
																								case 79:
																								case 80:
																								case 95:
																								case 108:
																								case 115:
																								case 121:
																								case 131:
																								case 132:
																								case 133:
																								case 137:
																								case 151:
																								case 154:
																								case 162:
																								case 166:
																								case 189:
																								case 198:
																								case 199:
																								case 218:
																								case 224:
																								case 226:
																								case 230:
																								case 234:
																								case 244:
																								case 245:
																								case 267:
																								case 274:
																								case 279:
																								case 284:
																								case 285:
																								case 290:
																								case 295:
																								case 296:
																								case 301:
																								case 305:
																								case 352:
																								case 354:
																									goto end_IL_0690_2;
																								case 3:
																								case 4:
																								case 10:
																								case 17:
																								case 23:
																								case 27:
																								case 40:
																								case 41:
																								case 50:
																								case 54:
																								case 59:
																								case 66:
																								case 75:
																								case 83:
																								case 85:
																								case 89:
																								case 98:
																								case 103:
																								case 105:
																								case 106:
																								case 113:
																								case 117:
																								case 119:
																								case 125:
																								case 128:
																								case 146:
																								case 164:
																								case 165:
																								case 167:
																								case 173:
																								case 197:
																								case 208:
																								case 213:
																								case 229:
																								case 250:
																								case 252:
																								case 263:
																								case 266:
																								case 276:
																								case 335:
																								case 338:
																								case 342:
																								case 347:
																								case 351:
																								case 355:
																									goto IL_1a00_2;
																								case 91:
																									ptr2 = ptr;
																									goto IL_1a00_2;
																								case 326:
																									ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AccessRightTypegetBaseUtcOffset.ICompatibleFrameworksMetadataEntryIsolatedStorageScope);
																									goto case 91;
																								case 2:
																									array7[0] = this;
																									goto case 326;
																								case 168:
																									array7 = new object[9];
																									goto case 2;
																								case 278:
																									array6 = new long[4];
																									goto case 168;
																								case 84:
																									array5 = new int[7];
																									goto case 278;
																								case 322:
																									array4 = new int[4];
																									goto case 84;
																								case 28:
																									array3 = new object[4];
																									goto case 322;
																								case 334:
																									array2 = new byte[4];
																									goto case 28;
																								case 206:
																									num4 = num2 * 8;
																									goto case 334;
																								case 182:
																									num3 = num2 * 4;
																									goto case 206;
																								case 220:
																									num2 = 1;
																									goto case 182;
																								case 221:
																									goto end_IL_16a5;
																								case 78:
																								case 268:
																									goto IL_1ad3_2;
																								}
																								continue;
																							}
																							num6 -= 2;
																							goto IL_1a00_2;
																							continue;
																							end_IL_05d3_2:
																							break;
																						}
																						break;
																					}
																					break;
																				}
																				goto IL_06de_2;
																				IL_14b6_2:
																				num6--;
																				num = 4;
																				goto IL_1a00_2;
																				IL_14d2_2:
																				if (6 < b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_14e0_2;
																				IL_06de_2:
																				if (5 >= b)
																				{
																					goto IL_0701_2;
																				}
																				goto IL_1388_2;
																				IL_0701_2:
																				if (5 > b)
																				{
																					goto IL_070f_2;
																				}
																				goto IL_0a69_2;
																				IL_070f_2:
																				if (2 < b)
																				{
																					goto IL_071a_2;
																				}
																				num = 158;
																				goto IL_079c_2;
																				IL_071a_2:
																				if (3 >= b)
																				{
																					goto IL_0725_2;
																				}
																				goto IL_0741_2;
																				IL_0725_2:
																				if (3 > b)
																				{
																					goto end_IL_0690_2;
																				}
																				num = 203;
																				goto IL_08cf_2;
																				IL_14ee_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_152e_2;
																				IL_08cf_2:
																				reference = ref array5[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_08f8_2;
																				IL_08f8_2:
																				ptr2 += 8;
																				goto IL_0906_2;
																				IL_0906_2:
																				num6--;
																				goto IL_1a00_2;
																				IL_0741_2:
																				if (4 < b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_074f_2;
																				IL_074f_2:
																				if (4 > b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_075d_2;
																				IL_075d_2:
																				array2[num6] = 0;
																				goto IL_076b_2;
																				IL_076b_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																				goto IL_089f_2;
																				IL_089f_2:
																				array3[num6] = null;
																				goto IL_08a9_2;
																				IL_08a9_2:
																				num6++;
																				goto IL_0aae_2;
																				IL_0aae_2:
																				ptr2 += 8;
																				goto IL_1a00_2;
																				IL_14e0_2:
																				if (6 > b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_14ee_2;
																				IL_079c_2:
																				if (2 > b)
																				{
																					goto IL_07aa_2;
																				}
																				goto IL_0e50_2;
																				IL_07aa_2:
																				if (1 < b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_07ca_2;
																				IL_07ca_2:
																				if (1 > b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_07d8_2;
																				IL_07d8_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																				goto IL_07f1_2;
																				IL_07f1_2:
																				array2[num6] = 0;
																				goto IL_07ff_2;
																				IL_07ff_2:
																				num6++;
																				goto IL_080d_2;
																				IL_080d_2:
																				ptr2 += 8;
																				goto IL_1a00_2;
																				IL_0e50_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0e90_2;
																				IL_0e90_2:
																				array2[num6 - 2] = 0;
																				goto IL_0ea4_2;
																				IL_0ea4_2:
																				num6--;
																				goto IL_1a00_2;
																				IL_0a69_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0eef_2;
																				IL_0eef_2:
																				array2[num6 - 2] = 0;
																				goto IL_0f03_2;
																				IL_0f03_2:
																				num6--;
																				goto IL_1a00_2;
																				IL_1388_2:
																				if (7 < b)
																				{
																					goto IL_1396_2;
																				}
																				num = 53;
																				goto IL_1457_2;
																				IL_1396_2:
																				if (8 >= b)
																				{
																					goto IL_13a1_2;
																				}
																				goto IL_13c2_2;
																				IL_13a1_2:
																				if (8 > b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_13af_2;
																				IL_13af_2:
																				num6--;
																				goto IL_1a00_2;
																				IL_13c2_2:
																				if (9 < b)
																				{
																					goto end_IL_0690_2;
																				}
																				goto IL_13d0_2;
																				IL_13d0_2:
																				if (9 > b)
																				{
																					goto end_IL_0690_2;
																				}
																				num = 45;
																				goto IL_13e7_2;
																				IL_1542_2:
																				num6--;
																				goto IL_1a00_2;
																				IL_13e7_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_1427_2;
																				IL_1427_2:
																				array2[num6 - 2] = 0;
																				goto IL_143b_2;
																				IL_143b_2:
																				num6--;
																				goto IL_1a00_2;
																				IL_152e_2:
																				array2[num6 - 2] = 0;
																				goto IL_1542_2;
																				IL_1457_2:
																				if (7 <= b)
																				{
																					goto IL_1462_2;
																				}
																				goto IL_14d2_2;
																				IL_1462_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_14a2_2;
																				IL_14a2_2:
																				array2[num6 - 2] = 0;
																				goto IL_14b6_2;
																			}
																			goto IL_1608_2;
																			IL_19b2_2:
																			ptr2 += 16;
																			goto IL_1a00_2;
																			IL_1589_2:
																			if (15 >= b)
																			{
																				goto IL_1597_2;
																			}
																			goto IL_181f_2;
																			IL_1597_2:
																			if (15 <= b)
																			{
																				num = 16;
																				goto IL_15ae_2;
																			}
																			goto IL_163c_2;
																			IL_19c2_2:
																			if (20 < b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_19cd_2;
																			IL_15ae_2:
																			array2[num6] = array2[num6 - 1];
																			goto IL_15c6_2;
																			IL_15c6_2:
																			array4[num6 - 0] = array4[num6 - 1];
																			goto IL_15e4_2;
																			IL_15e4_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_1608_2;
																			IL_1608_2:
																			array3[num6] = array3[num6 - 1];
																			num = 35;
																			goto IL_1629_2;
																			IL_1629_2:
																			num6++;
																			goto IL_1a00_2;
																			IL_163c_2:
																			if (12 >= b)
																			{
																				goto IL_164a_2;
																			}
																			goto IL_1760_2;
																			IL_164a_2:
																			if (12 <= b)
																			{
																				num = 272;
																				goto end_IL_06c3;
																			}
																			goto IL_1655_2;
																			IL_1655_2:
																			if (11 < b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_1663_2;
																			IL_1663_2:
																			if (11 > b)
																			{
																				goto end_IL_0690_2;
																			}
																			num = 59;
																			goto IL_1a00_2;
																			IL_19d8_2:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1a00_2;
																			IL_19cd_2:
																			if (20 > b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_19d8_2;
																			IL_1760_2:
																			if (13 >= b)
																			{
																				goto IL_176b_2;
																			}
																			goto IL_17b8_2;
																			IL_176b_2:
																			if (13 > b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_1779_2;
																			IL_1779_2:
																			array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																			goto IL_1797_2;
																			IL_1797_2:
																			ptr2 += 8;
																			goto IL_17a5_2;
																			IL_17a5_2:
																			num6--;
																			goto IL_1a00_2;
																			IL_17b8_2:
																			if (14 < b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_17c6_2;
																			IL_17c6_2:
																			if (14 > b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_17d4_2;
																			IL_17d4_2:
																			array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																			goto IL_17fd_2;
																			IL_17fd_2:
																			array2[num6 - 1] = 5;
																			num = 105;
																			goto IL_1a00_2;
																			IL_181f_2:
																			if (18 >= b)
																			{
																				goto IL_182d_2;
																			}
																			goto IL_1967_2;
																			IL_182d_2:
																			if (18 > b)
																			{
																				goto IL_183b_2;
																			}
																			goto IL_1908_2;
																			IL_183b_2:
																			if (16 >= b)
																			{
																				goto IL_1846_2;
																			}
																			goto IL_189b_2;
																			IL_1846_2:
																			if (16 > b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_1854_2;
																			IL_1854_2:
																			array2[num6] = 5;
																			goto IL_1862_2;
																			IL_1862_2:
																			array3[num6] = array7[*(int*)(ptr2 + num3)];
																			goto IL_187a_2;
																			IL_187a_2:
																			num6++;
																			goto IL_1888_2;
																			IL_1888_2:
																			ptr2 += 8;
																			goto IL_1a00_2;
																			IL_189b_2:
																			if (17 < b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_18a9_2;
																			IL_18a9_2:
																			if (17 > b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_18b7_2;
																			IL_18b7_2:
																			((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																			goto IL_18f5_2;
																			IL_18f5_2:
																			num6 -= 3;
																			goto IL_1a00_2;
																			IL_1908_2:
																			array2[num6 - 1] = 5;
																			goto IL_191c_2;
																			IL_191c_2:
																			array3[num6 - 1] = ((delegate*<string[], string>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																			goto IL_1954_2;
																			IL_1954_2:
																			ptr2 += 8;
																			goto IL_1a00_2;
																			IL_1967_2:
																			if (19 >= b)
																			{
																				goto IL_1972_2;
																			}
																			goto IL_19c2_2;
																			IL_1972_2:
																			if (19 > b)
																			{
																				goto end_IL_0690_2;
																			}
																			goto IL_197d_2;
																			IL_197d_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																			goto IL_1996_2;
																			IL_1996_2:
																			array2[num6] = 1;
																			goto IL_19a4_2;
																			IL_19a4_2:
																			num6++;
																			goto IL_19b2_2;
																			continue;
																			end_IL_0663_2:
																			break;
																		}
																		continue;
																	}
																	goto IL_0b7e_2;
																	IL_0bd3_2:
																	num6--;
																	goto IL_1a00_2;
																	IL_0b7e_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																	goto IL_0bbf_2;
																	IL_0bbf_2:
																	array2[num6 - 2] = 0;
																	goto IL_0bd3_2;
																	continue;
																	end_IL_0673:
																	break;
																}
																continue;
															}
															goto IL_06ce_2;
															IL_0b22_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_06ce_2:
															if (32 < b)
															{
																goto IL_06ee_2;
															}
															goto IL_0b45_2;
															IL_0b45_2:
															if (32 > b)
															{
																goto IL_0be6_2;
															}
															goto IL_129f_2;
															IL_129f_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_12df_2;
															IL_12df_2:
															array2[num6 - 2] = 3;
															goto IL_12f3_2;
															IL_12f3_2:
															num6--;
															goto IL_1a00_2;
															IL_0be6_2:
															if (26 >= b)
															{
																goto IL_0bf4_2;
															}
															goto IL_0fcf_2;
															IL_0bf4_2:
															if (26 <= b)
															{
																goto IL_0c02_2;
															}
															goto IL_0c83_2;
															IL_0c02_2:
															ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0c70_2;
															IL_0c70_2:
															num6 -= 2;
															goto IL_1a00_2;
															IL_0c83_2:
															if (23 >= b)
															{
																goto IL_0c91_2;
															}
															goto IL_0d64_2;
															IL_0c91_2:
															if (23 <= b)
															{
																goto IL_0c9c_2;
															}
															goto IL_0ce3_2;
															IL_0c9c_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_0cb4_2;
															IL_0cb4_2:
															array2[num6] = 5;
															goto IL_0cc2_2;
															IL_0cc2_2:
															num6++;
															goto IL_0cd0_2;
															IL_0cd0_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_0ce3_2:
															if (22 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0cf1_2;
															IL_0cf1_2:
															if (22 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0cff_2;
															IL_0cff_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0d51_2;
															IL_0d51_2:
															num6--;
															goto IL_1a00_2;
															IL_0d64_2:
															if (24 < b)
															{
																goto IL_0d6f_2;
															}
															num = 155;
															goto IL_0ddd_2;
															IL_0d6f_2:
															if (25 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0d7d_2;
															IL_0d7d_2:
															if (25 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0d8b_2;
															IL_0d8b_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
															goto IL_0da5_2;
															IL_0da5_2:
															array2[num6] = 3;
															goto IL_0db3_2;
															IL_0db3_2:
															num6++;
															goto IL_0dc1_2;
															IL_0dc1_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_0b35_2:
															if (42 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0b6b_2;
															IL_0ddd_2:
															if (24 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0deb_2;
															IL_0deb_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class179, float>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((Class179)array3[num6 - 1]);
															goto IL_0e29_2;
															IL_0e29_2:
															array2[num6 - 1] = 3;
															goto IL_0e3d_2;
															IL_0e3d_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_0fcf_2:
															if (29 >= b)
															{
																goto IL_0fdd_2;
															}
															goto IL_10e1_2;
															IL_0fdd_2:
															if (29 <= b)
															{
																goto IL_0fe8_2;
															}
															goto IL_1041_2;
															IL_0fe8_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1028_2;
															IL_1028_2:
															array2[num6 - 2] = 3;
															goto IL_1306_2;
															IL_1306_2:
															num6--;
															goto IL_1a00_2;
															IL_1041_2:
															if (27 >= b)
															{
																goto IL_104c_2;
															}
															goto IL_105f_2;
															IL_104c_2:
															if (27 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_1319_2;
															IL_1319_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
															goto IL_1332_2;
															IL_1332_2:
															array2[num6] = 3;
															goto IL_1340_2;
															IL_1340_2:
															num6++;
															goto IL_134e_2;
															IL_134e_2:
															ptr2 += 16;
															goto IL_1a00_2;
															IL_105f_2:
															if (28 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_106d_2;
															IL_106d_2:
															if (28 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_107b_2;
															IL_107b_2:
															array2[num6 - 1] = 3;
															goto IL_108f_2;
															IL_108f_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_10ce_2;
															IL_10ce_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_10e1_2:
															if (30 >= b)
															{
																goto IL_10ef_2;
															}
															goto IL_1175_2;
															IL_10ef_2:
															if (30 > b)
															{
																goto end_IL_0690_2;
															}
															num = 72;
															goto IL_1106_2;
															IL_0b6b_2:
															if (42 > b)
															{
															}
															goto end_IL_0690_2;
															IL_1106_2:
															array2[num6 - 1] = 0;
															num = 127;
															goto IL_1123_2;
															IL_1123_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1162_2;
															IL_1162_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_1175_2:
															if (31 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_1183_2;
															IL_1183_2:
															if (31 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_1243_2;
															IL_1243_2:
															array2[num6] = 3;
															num = 313;
															goto IL_125a_2;
															IL_125a_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<float>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])();
															goto IL_127e_2;
															IL_127e_2:
															num6++;
															goto IL_128c_2;
															IL_128c_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_06ee_2:
															if (37 < b)
															{
																goto IL_07ba_2;
															}
															goto IL_0919_2;
															IL_0919_2:
															if (37 <= b)
															{
																goto IL_0924_2;
															}
															goto IL_098f_2;
															IL_0924_2:
															array2[num6 - 2] = 0;
															goto IL_0938_2;
															IL_0938_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
															goto IL_0b58_2;
															IL_0b58_2:
															num6--;
															goto IL_0eb7_2;
															IL_0eb7_2:
															ptr2 += 8;
															num = 167;
															goto IL_1a00_2;
															IL_098f_2:
															if (34 < b)
															{
																goto IL_099d_2;
															}
															goto IL_1196_2;
															IL_099d_2:
															if (35 >= b)
															{
																goto IL_09a8_2;
															}
															goto IL_0a1c_2;
															IL_09a8_2:
															if (35 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_09b6_2;
															IL_09b6_2:
															array2[num6 - 1] = 3;
															goto IL_09ca_2;
															IL_09ca_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_0a09_2;
															IL_0a09_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_0a1c_2:
															if (36 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0a2a_2;
															IL_0a2a_2:
															if (36 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0a38_2;
															IL_0a38_2:
															array2[num6] = 5;
															goto IL_0a46_2;
															IL_0a46_2:
															array3[num6] = ((delegate*<string>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])();
															goto IL_1555_2;
															IL_1555_2:
															num6++;
															goto IL_1563_2;
															IL_1563_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_1196_2:
															if (34 <= b)
															{
																goto IL_11a1_2;
															}
															goto IL_11e2_2;
															IL_11a1_2:
															((Class179)array3[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_11cf_2;
															IL_11cf_2:
															num6 -= 2;
															goto IL_1a00_2;
															IL_11e2_2:
															if (33 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_11f0_2;
															IL_11f0_2:
															if (33 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_11fe_2;
															IL_11fe_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1361_2;
															IL_1361_2:
															array2[num6 - 2] = 3;
															goto IL_1375_2;
															IL_1375_2:
															num6--;
															goto IL_1a00_2;
															IL_07ba_2:
															if (40 >= b)
															{
																goto IL_0820_2;
															}
															goto IL_0ac1_2;
															IL_0820_2:
															if (40 > b)
															{
																goto IL_082e_2;
															}
															goto IL_0ed3_2;
															IL_082e_2:
															if (38 >= b)
															{
																goto IL_083c_2;
															}
															goto IL_0f16_2;
															IL_083c_2:
															if (38 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_084a_2;
															IL_084a_2:
															array2[num6 - 1] = 3;
															goto IL_085e_2;
															IL_085e_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_08bc_2;
															IL_08bc_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_0f16_2:
															if (39 < b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0f24_2;
															IL_0f24_2:
															if (39 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0f32_2;
															IL_0f32_2:
															array2[num6 - 3] = 4;
															goto IL_0f46_2;
															IL_0f46_2:
															array3[num6 - 3] = ((delegate*<float, float, float, Color>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
															goto IL_0fae_2;
															IL_0fae_2:
															num6 -= 2;
															goto IL_0fbc_2;
															IL_0fbc_2:
															ptr2 += 8;
															goto IL_1a00_2;
															IL_0ed3_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															goto IL_1a00_2;
															IL_0ac1_2:
															if (41 >= b)
															{
																goto IL_0acc_2;
															}
															goto IL_0b35_2;
															IL_0acc_2:
															if (41 > b)
															{
																goto end_IL_0690_2;
															}
															goto IL_0ada_2;
															IL_0ada_2:
															array2[num6] = 4;
															goto IL_0ae8_2;
															IL_0ae8_2:
															array3[num6] = ((delegate*<Color>)getHasInfoSetEnvironmentVariable[*(int*)(ptr2 + num3)])();
															goto IL_0b0b_2;
															IL_0b0b_2:
															num6++;
															num = 217;
															goto IL_0b22_2;
															continue;
															end_IL_0683:
															break;
														}
														continue;
														end_IL_0690_2:
														break;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_1a00_2;
												continue;
												end_IL_06a3_2:
												break;
											}
											continue;
											end_IL_06b3:
											break;
										}
										continue;
										end_IL_06c3:
										break;
									}
									break;
								}
								goto IL_1ad3_2;
								IL_1ad3_2:
								return (Color)array3[num6 - 1];
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_1697_2;
					}
					continue;
					end_IL_16a5:
					break;
				}
				break;
			}
		}
	}

	private static int MuiResourceTypeIdIntStringIdssetCryptoKeySecurity()
	{
		return smethod_1();
	}

	private unsafe static int smethod_1()
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref dictionarySystemThreadingTasksTaskDebugView.IHashElementEntryBlockSize);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_037a:
														byte b = *ptr2;
														while (true)
														{
															IL_036a:
															ptr2++;
															while (true)
															{
																IL_035a:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_033d:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_032d:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_031d:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_030d:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02fd:
																											if (10 <= b)
																											{
																												while (true)
																												{
																													IL_02ed:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_02bf:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 38;
																														while (true)
																														{
																															IL_02b3:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_02a3:
																																num5++;
																																while (true)
																																{
																																	IL_028a:
																																	ptr2 += 8;
																																	num = 154;
																																	while (num != 154)
																																	{
																																		if (num != 1135)
																																		{
																																			goto IL_05a9;
																																		}
																																		switch (num)
																																		{
																																		case 134:
																																			goto IL_028a;
																																		case 87:
																																			goto IL_02a3;
																																		case 38:
																																			goto IL_02b3;
																																		case 47:
																																			goto IL_02bf;
																																		case 2:
																																		case 18:
																																			goto IL_02ed;
																																		case 80:
																																			goto IL_02fd;
																																		case 97:
																																		case 108:
																																			goto IL_030d;
																																		case 3:
																																			goto IL_031d;
																																		case 78:
																																			goto IL_032d;
																																		case 68:
																																			goto IL_033d;
																																		case 76:
																																			goto IL_034a;
																																		case 9:
																																			goto IL_035a;
																																		case 85:
																																			goto IL_036a;
																																		case 10:
																																		case 17:
																																			goto IL_037a;
																																		case 14:
																																			goto IL_0385;
																																		case 58:
																																		case 119:
																																			goto IL_0393;
																																		case 39:
																																			goto IL_03a1;
																																		case 4:
																																			goto IL_03ac;
																																		case 89:
																																		case 92:
																																			goto IL_03b7;
																																		case 12:
																																		case 83:
																																			goto IL_03ca;
																																		case 61:
																																			goto IL_0409;
																																		case 29:
																																			goto IL_041c;
																																		case 25:
																																			goto IL_042a;
																																		case 115:
																																		case 128:
																																			goto IL_0443;
																																		case 6:
																																			goto IL_046c;
																																		case 94:
																																			goto IL_047a;
																																		case 133:
																																			goto IL_048d;
																																		case 82:
																																		case 129:
																																			goto IL_049b;
																																		case 139:
																																			goto IL_04b7;
																																		case 81:
																																			goto IL_04c5;
																																		case 28:
																																		case 84:
																																			goto IL_04d0;
																																		case 125:
																																			goto IL_04de;
																																		case 67:
																																		case 74:
																																			goto IL_04ec;
																																		case 55:
																																			goto IL_051e;
																																		case 136:
																																			goto IL_0537;
																																		case 33:
																																		case 66:
																																			goto IL_0542;
																																		case 60:
																																			goto IL_0582;
																																		case 52:
																																			goto IL_0596;
																																		case 19:
																																		case 116:
																																			goto IL_05a9;
																																		case 7:
																																			goto IL_05b7;
																																		case 65:
																																		case 118:
																																			goto IL_05c5;
																																		case 57:
																																		case 123:
																																			goto IL_05e9;
																																		case 95:
																																			goto IL_0607;
																																		case 40:
																																			goto IL_0615;
																																		case 142:
																																			goto IL_0628;
																																		case 31:
																																			goto IL_0636;
																																		case 53:
																																			goto IL_0644;
																																		case 26:
																																		case 144:
																																			goto IL_0657;
																																		case 147:
																																			goto IL_066f;
																																		case 138:
																																			goto IL_0687;
																																		case 72:
																																			goto IL_0695;
																																		case 107:
																																			goto IL_06a8;
																																		case 103:
																																			goto IL_06b6;
																																		case 49:
																																			goto IL_06c9;
																																		case 79:
																																			goto IL_06d7;
																																		case 51:
																																		case 77:
																																			goto IL_06e5;
																																		case 120:
																																			goto IL_0729;
																																		case 24:
																																			goto IL_073d;
																																		case 59:
																																		case 73:
																																			goto IL_0750;
																																		case 101:
																																			goto IL_0790;
																																		case 45:
																																			goto IL_07a4;
																																		case 35:
																																			goto IL_07c0;
																																		case 48:
																																		case 124:
																																			goto IL_07cb;
																																		case 50:
																																			goto IL_07d9;
																																		case 137:
																																			goto IL_07ec;
																																		case 41:
																																		case 111:
																																			goto IL_07f7;
																																		case 5:
																																			goto IL_0813;
																																		case 145:
																																			goto IL_0821;
																																		case 15:
																																		case 46:
																																			goto IL_082c;
																																		case 69:
																																			goto IL_0897;
																																		case 0:
																																		case 1:
																																		case 8:
																																		case 16:
																																		case 20:
																																		case 22:
																																		case 27:
																																		case 34:
																																		case 36:
																																		case 37:
																																		case 44:
																																		case 63:
																																		case 71:
																																		case 75:
																																		case 91:
																																		case 93:
																																		case 104:
																																		case 105:
																																		case 106:
																																		case 109:
																																		case 110:
																																		case 113:
																																		case 117:
																																		case 126:
																																		case 132:
																																		case 140:
																																		case 143:
																																		case 146:
																																			goto end_IL_034a;
																																		case 11:
																																		case 21:
																																		case 30:
																																		case 42:
																																		case 56:
																																		case 62:
																																		case 64:
																																		case 70:
																																		case 88:
																																		case 90:
																																		case 96:
																																		case 100:
																																		case 102:
																																		case 112:
																																		case 130:
																																		case 131:
																																		case 135:
																																			goto end_IL_0277;
																																		case 121:
																																			goto end_IL_08ba;
																																		case 127:
																																			goto end_IL_08cd;
																																		case 13:
																																			goto end_IL_08d7;
																																		case 86:
																																			goto end_IL_08e2;
																																		case 114:
																																		case 141:
																																			goto end_IL_08f2;
																																		case 43:
																																			goto end_IL_0902;
																																		case 32:
																																		case 122:
																																			goto end_IL_0912;
																																		case 98:
																																			goto end_IL_0922;
																																		case 99:
																																			goto end_IL_0932;
																																		case 23:
																																		case 54:
																																			goto IL_094d;
																																		}
																																		continue;
																																		end_IL_0277:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_06a8;
																											IL_06b6:
																											if (9 <= b)
																											{
																												break;
																											}
																											goto end_IL_034a;
																											IL_06a8:
																											if (9 < b)
																											{
																												goto end_IL_034a;
																											}
																											goto IL_06b6;
																										}
																										break;
																									}
																									goto IL_06c9;
																									IL_073d:
																									num5--;
																									break;
																									IL_06c9:
																									if (11 < b)
																									{
																										goto end_IL_034a;
																									}
																									goto IL_06d7;
																									IL_06d7:
																									if (11 > b)
																									{
																										goto end_IL_034a;
																									}
																									goto IL_06e5;
																									IL_06e5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_0729;
																									IL_0729:
																									array[num5 - 2] = 0;
																									goto IL_073d;
																								}
																								break;
																							}
																							goto IL_0750;
																							IL_07a4:
																							num5--;
																							num = 102;
																							break;
																							IL_0750:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0790;
																							IL_0790:
																							array[num5 - 2] = 0;
																							goto IL_07a4;
																						}
																						break;
																					}
																					goto IL_07c0;
																					IL_0897:
																					num5 -= 2;
																					break;
																					IL_07c0:
																					if (14 < b)
																					{
																						goto IL_07cb;
																					}
																					goto IL_07ec;
																					IL_07cb:
																					if (15 < b)
																					{
																						goto end_IL_034a;
																					}
																					goto IL_07d9;
																					IL_07d9:
																					if (15 > b)
																					{
																					}
																					goto end_IL_034a;
																					IL_07ec:
																					if (14 <= b)
																					{
																						goto IL_07f7;
																					}
																					goto IL_0813;
																					IL_07f7:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0813:
																					if (13 < b)
																					{
																						goto end_IL_034a;
																					}
																					goto IL_0821;
																					IL_0821:
																					if (13 > b)
																					{
																						goto end_IL_034a;
																					}
																					goto IL_082c;
																					IL_082c:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 69;
																					goto IL_0897;
																				}
																				break;
																			}
																			goto IL_0385;
																			IL_0607:
																			ptr2 += 8;
																			goto IL_0615;
																			IL_0385:
																			if (8 > b)
																			{
																				goto IL_0393;
																			}
																			goto IL_0657;
																			IL_0393:
																			if (4 < b)
																			{
																				goto IL_03a1;
																			}
																			goto IL_04b7;
																			IL_03a1:
																			if (6 >= b)
																			{
																				goto IL_03ac;
																			}
																			goto IL_041c;
																			IL_03ac:
																			if (6 > b)
																			{
																				goto IL_03b7;
																			}
																			goto IL_03ca;
																			IL_03b7:
																			if (5 < b)
																			{
																				goto end_IL_034a;
																			}
																			goto IL_048d;
																			IL_048d:
																			if (5 > b)
																			{
																				goto end_IL_034a;
																			}
																			goto IL_049b;
																			IL_049b:
																			array[num5] = 5;
																			num = 147;
																			goto IL_066f;
																			IL_066f:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0687;
																			IL_0687:
																			num5++;
																			goto IL_0695;
																			IL_0695:
																			ptr2 += 8;
																			break;
																			IL_03ca:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0409;
																			IL_0409:
																			num5 -= 3;
																			break;
																			IL_041c:
																			if (7 < b)
																			{
																				goto end_IL_034a;
																			}
																			goto IL_042a;
																			IL_042a:
																			if (7 > b)
																			{
																				num = 109;
																				goto end_IL_034a;
																			}
																			goto IL_0443;
																			IL_0615:
																			num5--;
																			break;
																			IL_0443:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_046c;
																			IL_046c:
																			ptr2 += 8;
																			goto IL_047a;
																			IL_047a:
																			num5--;
																			break;
																			IL_04b7:
																			if (4 > b)
																			{
																				goto IL_04c5;
																			}
																			num = 123;
																			goto IL_05e9;
																			IL_04c5:
																			if (2 < b)
																			{
																				goto IL_04d0;
																			}
																			goto IL_0537;
																			IL_04d0:
																			if (3 < b)
																			{
																				goto end_IL_034a;
																			}
																			goto IL_04de;
																			IL_04de:
																			if (3 > b)
																			{
																				goto end_IL_034a;
																			}
																			goto IL_04ec;
																			IL_04ec:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 55;
																			goto IL_051e;
																			IL_051e:
																			array[num5 - 1] = 5;
																			break;
																			IL_0537:
																			if (2 <= b)
																			{
																				goto IL_0542;
																			}
																			goto IL_05a9;
																			IL_0542:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0582;
																			IL_0582:
																			array[num5 - 2] = 0;
																			goto IL_0596;
																			IL_0596:
																			num5--;
																			break;
																			IL_05a9:
																			if (1 < b)
																			{
																				goto end_IL_034a;
																			}
																			goto IL_05b7;
																			IL_05b7:
																			if (1 > b)
																			{
																				goto end_IL_034a;
																			}
																			goto IL_05c5;
																			IL_05c5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0628;
																			IL_0628:
																			array[num5] = 0;
																			goto IL_0636;
																			IL_0636:
																			num5++;
																			goto IL_0644;
																			IL_0644:
																			ptr2 += 8;
																			break;
																			IL_0657:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_05e9:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0607;
																		}
																		goto end_IL_035a;
																		continue;
																		end_IL_034a:
																		break;
																		IL_034a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_035a:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_094d;
												IL_094d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08ba:
												break;
											}
											continue;
											end_IL_08cd:
											break;
										}
										continue;
										end_IL_08d7:
										break;
									}
									continue;
									end_IL_08e2:
									break;
								}
								continue;
								end_IL_08f2:
								break;
							}
							continue;
							end_IL_0902:
							break;
						}
						continue;
						end_IL_0912:
						break;
					}
					continue;
					end_IL_0922:
					break;
				}
				continue;
				end_IL_0932:
				break;
			}
		}
	}

	private static bool ListSeparatorURI(ControllerInputPoller controllerInputPoller_0)
	{
		return controllerInputPoller_0.leftControllerSecondaryButton;
	}

	public unsafe static Color smethod_2()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0735, IL_0748, IL_075b, IL_076b, IL_077b, IL_078b, IL_079b, IL_07ab, IL_07b8, IL_07c8, IL_07d8, IL_07e8, IL_07f8, IL_0803, IL_0845, IL_0855, IL_0869, IL_087c, IL_088c, IL_089a, IL_08aa, IL_08bd, IL_08d6, IL_08e4, IL_08fb, IL_090e, IL_091c, IL_093a, IL_0948, IL_095b, IL_096f, IL_09c1, IL_09d4, IL_09f1, IL_0a40, IL_0a4a, IL_0a77, IL_0a90, IL_0aa3, IL_0ab1, IL_0abc, IL_0b05, IL_0b19, IL_0b2c, IL_0b3a, IL_0b45, IL_0b73, IL_0b7e, IL_0b87, IL_0b95, IL_0bb3, IL_0bc1, IL_0bd4, IL_0be2, IL_0bed, IL_0c2d, IL_0c41, IL_0c54, IL_0c5f, IL_0c6d, IL_0cad, IL_0cc6, IL_0cd4, IL_0ce2, IL_0cf5, IL_0d03, IL_0d11, IL_0d1a, IL_0d2d, IL_0d6d, IL_0d81, IL_0d94, IL_0da7, IL_0db2, IL_0dc6, IL_0e05, IL_0e18, IL_0e26, IL_0e34, IL_0e96, IL_0ea9, IL_0eb7, IL_0eca, IL_0edd, IL_0eeb, IL_0ef9, IL_0f11, IL_0f2f, IL_0f53, IL_0f6b, IL_0f7e, IL_0f89, IL_0f9c, IL_0faa, IL_0fb8, IL_0fea, IL_1003, IL_100e, IL_1019, IL_1057, IL_106a, IL_1078, IL_108b, IL_1099, IL_10a7, IL_10bb, IL_10f3, IL_1106, IL_1124, IL_1132, IL_1145, IL_1150, IL_115e, IL_116c, IL_118f, IL_11a2, IL_11b0, IL_11c3, IL_11d1, IL_11df, IL_121f, IL_1235, IL_124c, IL_125f, IL_1272, IL_1280, IL_1298, IL_12a6, IL_12b9, IL_12c7, IL_12da, IL_12f3, IL_1301, IL_130f, IL_1322, IL_132d, IL_137f, IL_1392, IL_139d, IL_13ab, IL_13c3, IL_13d1, IL_13df, IL_1429, IL_143d, IL_1450, IL_145e, IL_146c, IL_147a, IL_1488, IL_1496, IL_14a4, IL_14b2, IL_14c0, IL_14d4, IL_1513, IL_152f, IL_153d, IL_1551, IL_1590, IL_15a3, IL_15bc, IL_15d8, IL_15e6, IL_15f1, IL_160f, IL_161d, IL_162b, IL_163e, IL_164c, IL_165a, IL_1668, IL_168c, IL_169a, IL_16ad, IL_16bb, IL_16c9, IL_16d2, IL_16fc, IL_1715, IL_1740, IL_1759, IL_1767, IL_1772, IL_178c, IL_179f, IL_17aa, IL_17b8, IL_17f8, IL_1815, IL_1828, IL_1836, IL_1844, IL_1858, IL_18c1, IL_18cf, IL_18e2, IL_18f0, IL_18fb, IL_1909, IL_1917, IL_193b, IL_1949, IL_1957, IL_196a, IL_19a7, IL_19bb, IL_19ce, IL_19dc, IL_19ef, IL_19fd, IL_1a0b, IL_1a16, IL_1a30, IL_1a3e, IL_1a4c, IL_1a5f, IL_1a6d, IL_1a7b, IL_1a86, IL_1a94, IL_1aa8, IL_1ae7, IL_1afa, IL_1b08, IL_1b11, IL_1b1f, IL_1b2d, IL_1b50, IL_1b5e, IL_1b71, IL_1b8d, IL_1b9b, IL_1ba9, IL_1bb7, IL_1bc5, IL_1bd9, IL_1c18, IL_1c2b, IL_1c6b, IL_1c7f, IL_1c9b, IL_1ca9, IL_1cb7, IL_1ce0, IL_1cf9, IL_1d07, IL_1d12, IL_1d2f, IL_1d6e, IL_1d81, IL_1d8c, IL_1d9a, IL_1da8, IL_1dea, IL_1dfd, IL_1e0b, IL_1e14, IL_1e31, IL_1ea9, IL_1ec0, IL_1ed3, IL_1ee1, IL_1eec, IL_1f17, IL_1f30, IL_1f3e, IL_1f47, IL_1f55, IL_1f95, IL_1fa9, IL_1fbc, IL_1fca, IL_1fd8, IL_1fec, IL_202b, IL_203e, IL_207e, IL_209b, IL_20ab, IL_20be, IL_20d1, IL_20db, IL_20e6, IL_20f6, IL_2106, IL_2116, IL_2126, IL_2136, IL_2146, IL_2156, IL_2166, IL_2181 are reachable both inside and outside the pinned region starting at IL_217b. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 170;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef82 = default(int);
			ref int reference = ref __rxRef82;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2166:
					num2 = 1;
					while (true)
					{
						IL_2156:
						num3 = num2 * 4;
						while (true)
						{
							IL_2146:
							num4 = num2 * 8;
							while (true)
							{
								IL_2136:
								array2 = new byte[7];
								while (true)
								{
									IL_2126:
									array3 = new object[7];
									while (true)
									{
										IL_2116:
										array4 = new int[7];
										while (true)
										{
											IL_2106:
											array5 = new int[7];
											while (true)
											{
												IL_20f6:
												array6 = new long[7];
												while (true)
												{
													IL_20e6:
													array7 = new object[8];
													while (true)
													{
														IL_20db:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RsaFullCMSFILEWRITABLETYPENOTWRITABLE.SEPDateOrOffsetBeginGetRequestStream);
														while (true)
														{
															IL_20d1:
															ptr2 = ptr;
															while (true)
															{
																IL_20be:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_07f8:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_07e8:
																			ptr2++;
																			while (true)
																			{
																				IL_07d8:
																				if (b >= 1)
																				{
																					while (b <= 54)
																					{
																						while (true)
																						{
																							IL_07b8:
																							if (27 >= b)
																							{
																								while (true)
																								{
																									IL_07ab:
																									if (27 > b)
																									{
																										while (true)
																										{
																											IL_079b:
																											if (13 < b)
																											{
																												while (true)
																												{
																													IL_078b:
																													if (20 < b)
																													{
																														while (true)
																														{
																															IL_077b:
																															if (23 < b)
																															{
																																while (true)
																																{
																																	IL_076b:
																																	if (25 < b)
																																	{
																																		while (26 >= b)
																																		{
																																			while (26 <= b)
																																			{
																																				num = 454;
																																				while (true)
																																				{
																																					if (num != 454)
																																					{
																																						if (num != 1435)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 170:
																																							break;
																																						default:
																																							continue;
																																						case 369:
																																							goto IL_0748;
																																						case 243:
																																							goto IL_075b;
																																						case 10:
																																							goto IL_076b;
																																						case 160:
																																							goto IL_077b;
																																						case 221:
																																							goto IL_078b;
																																						case 342:
																																							goto IL_079b;
																																						case 301:
																																							goto IL_07ab;
																																						case 317:
																																							goto IL_07b8;
																																						case 435:
																																							goto IL_07c8;
																																						case 147:
																																							goto IL_07d8;
																																						case 108:
																																							goto IL_07e8;
																																						case 77:
																																						case 292:
																																							goto IL_07f8;
																																						case 35:
																																						case 64:
																																							goto IL_0803;
																																						case 95:
																																							goto IL_0845;
																																						case 117:
																																							goto IL_0855;
																																						case 96:
																																							goto IL_0869;
																																						case 149:
																																							goto IL_087c;
																																						case 207:
																																							goto IL_088c;
																																						case 186:
																																							goto IL_089a;
																																						case 256:
																																							goto IL_08aa;
																																						case 140:
																																						case 280:
																																							goto IL_08bd;
																																						case 242:
																																							goto IL_08d6;
																																						case 29:
																																							goto IL_08e4;
																																						case 311:
																																							goto IL_08fb;
																																						case 251:
																																						case 313:
																																							goto IL_090e;
																																						case 217:
																																							goto IL_091c;
																																						case 318:
																																							goto IL_093a;
																																						case 32:
																																							goto IL_0948;
																																						case 233:
																																						case 334:
																																							goto IL_095b;
																																						case 231:
																																							goto IL_096f;
																																						case 208:
																																							goto IL_09c1;
																																						case 328:
																																						case 381:
																																							goto IL_09d4;
																																						case 385:
																																							goto IL_0a90;
																																						case 386:
																																							goto IL_0aa3;
																																						case 244:
																																							goto IL_0ab1;
																																						case 63:
																																						case 191:
																																							goto IL_0abc;
																																						case 214:
																																							goto IL_0b05;
																																						case 110:
																																							goto IL_0b19;
																																						case 47:
																																							goto IL_0b2c;
																																						case 230:
																																							goto IL_0b3a;
																																						case 66:
																																						case 137:
																																							goto IL_0b45;
																																						case 138:
																																							goto IL_0b73;
																																						case 141:
																																							goto IL_0b87;
																																						case 124:
																																						case 324:
																																							goto IL_0b95;
																																						case 329:
																																							goto IL_0bb3;
																																						case 125:
																																							goto IL_0bc1;
																																						case 245:
																																							goto IL_0bd4;
																																						case 257:
																																							goto IL_0be2;
																																						case 83:
																																						case 346:
																																							goto IL_0bed;
																																						case 102:
																																							goto IL_0c2d;
																																						case 205:
																																							goto IL_0c41;
																																						case 2:
																																							goto end_IL_0735;
																																						case 86:
																																							goto IL_0c5f;
																																						case 100:
																																						case 114:
																																							goto IL_0c6d;
																																						case 337:
																																							goto IL_0cad;
																																						case 332:
																																							goto IL_0cc6;
																																						case 274:
																																							goto IL_0cd4;
																																						case 82:
																																						case 375:
																																							goto IL_0ce2;
																																						case 73:
																																							goto IL_0cf5;
																																						case 28:
																																							goto IL_0d03;
																																						case 380:
																																							goto IL_0d1a;
																																						case 378:
																																						case 388:
																																							goto IL_0d2d;
																																						case 146:
																																							goto IL_0d6d;
																																						case 139:
																																							goto IL_0d81;
																																						case 393:
																																							goto IL_0d94;
																																						case 401:
																																							goto IL_0da7;
																																						case 88:
																																						case 392:
																																							goto IL_0db2;
																																						case 211:
																																							goto IL_0dc6;
																																						case 368:
																																							goto IL_0e05;
																																						case 65:
																																							goto IL_0e18;
																																						case 320:
																																							goto IL_0e26;
																																						case 20:
																																						case 232:
																																							goto IL_0e34;
																																						case 143:
																																							goto IL_0e96;
																																						case 418:
																																							goto IL_0ea9;
																																						case 187:
																																							goto IL_0eb7;
																																						case 419:
																																							goto IL_0eca;
																																						case 430:
																																							goto IL_0edd;
																																						case 5:
																																							goto IL_0eeb;
																																						case 365:
																																						case 371:
																																							goto IL_0ef9;
																																						case 277:
																																							goto IL_0f11;
																																						case 198:
																																							goto IL_0f2f;
																																						case 400:
																																							goto IL_0f53;
																																						case 128:
																																							goto IL_0f6b;
																																						case 424:
																																							goto IL_0f7e;
																																						case 376:
																																							goto IL_0f89;
																																						case 121:
																																							goto IL_0f9c;
																																						case 384:
																																							goto IL_0faa;
																																						case 78:
																																						case 126:
																																							goto IL_0fb8;
																																						case 62:
																																							goto IL_0fea;
																																						case 8:
																																							goto IL_1003;
																																						case 408:
																																							goto IL_100e;
																																						case 276:
																																						case 338:
																																							goto IL_1019;
																																						case 157:
																																							goto IL_1057;
																																						case 42:
																																							goto IL_106a;
																																						case 195:
																																							goto IL_1078;
																																						case 420:
																																							goto IL_108b;
																																						case 122:
																																							goto IL_1099;
																																						case 26:
																																						case 417:
																																							goto IL_10a7;
																																						case 112:
																																							goto IL_10bb;
																																						case 106:
																																							goto IL_10f3;
																																						case 336:
																																						case 431:
																																							goto IL_1106;
																																						case 105:
																																							goto IL_1124;
																																						case 421:
																																							goto IL_1132;
																																						case 436:
																																							goto IL_1145;
																																						case 395:
																																							goto IL_1150;
																																						case 18:
																																						case 67:
																																							goto IL_115e;
																																						case 288:
																																							goto IL_116c;
																																						case 402:
																																							goto IL_118f;
																																						case 173:
																																							goto IL_11a2;
																																						case 31:
																																							goto IL_11b0;
																																						case 364:
																																							goto IL_11c3;
																																						case 224:
																																							goto IL_11d1;
																																						case 55:
																																						case 287:
																																							goto IL_11df;
																																						case 278:
																																							goto IL_121f;
																																						case 438:
																																							goto IL_1235;
																																						case 14:
																																							goto IL_124c;
																																						case 439:
																																							goto IL_125f;
																																						case 209:
																																						case 443:
																																							goto IL_1272;
																																						case 304:
																																							goto IL_1280;
																																						case 377:
																																							goto IL_1298;
																																						case 203:
																																							goto IL_12a6;
																																						case 446:
																																							goto IL_12b9;
																																						case 109:
																																							goto IL_12c7;
																																						case 94:
																																							goto IL_12da;
																																						case 226:
																																							goto IL_12f3;
																																						case 223:
																																							goto IL_1301;
																																						case 129:
																																							goto IL_130f;
																																						case 27:
																																							goto IL_1322;
																																						case 333:
																																						case 339:
																																							goto IL_132d;
																																						case 259:
																																							goto IL_137f;
																																						case 441:
																																							goto IL_1392;
																																						case 410:
																																							goto IL_139d;
																																						case 134:
																																						case 273:
																																							goto IL_13ab;
																																						case 144:
																																							goto IL_13c3;
																																						case 192:
																																							goto IL_13d1;
																																						case 261:
																																						case 323:
																																							goto IL_13df;
																																						case 227:
																																							goto IL_1429;
																																						case 200:
																																							goto IL_143d;
																																						case 220:
																																							goto IL_1450;
																																						case 174:
																																							goto IL_145e;
																																						case 373:
																																							goto IL_146c;
																																						case 44:
																																							goto IL_147a;
																																						case 264:
																																							goto IL_1488;
																																						case 1:
																																							goto IL_1496;
																																						case 120:
																																							goto IL_14a4;
																																						case 164:
																																							goto IL_14b2;
																																						case 97:
																																						case 268:
																																							goto IL_14c0;
																																						case 17:
																																							goto IL_14d4;
																																						case 255:
																																							goto IL_1513;
																																						case 107:
																																							goto IL_152f;
																																						case 45:
																																						case 434:
																																							goto IL_153d;
																																						case 298:
																																							goto IL_1551;
																																						case 327:
																																							goto IL_1590;
																																						case 151:
																																						case 254:
																																							goto IL_15a3;
																																						case 16:
																																							goto IL_15bc;
																																						case 234:
																																							goto IL_15d8;
																																						case 442:
																																							goto IL_15e6;
																																						case 357:
																																						case 360:
																																							goto IL_15f1;
																																						case 302:
																																							goto IL_160f;
																																						case 39:
																																							goto IL_161d;
																																						case 183:
																																							goto IL_162b;
																																						case 415:
																																							goto IL_163e;
																																						case 40:
																																							goto IL_164c;
																																						case 38:
																																						case 219:
																																							goto IL_165a;
																																						case 150:
																																							goto IL_1668;
																																						case 248:
																																							goto IL_168c;
																																						case 123:
																																							goto IL_169a;
																																						case 290:
																																							goto IL_16ad;
																																						case 289:
																																							goto IL_16bb;
																																						case 158:
																																						case 429:
																																							goto IL_16d2;
																																						case 252:
																																							goto IL_16fc;
																																						case 48:
																																						case 204:
																																							goto IL_1715;
																																						case 239:
																																							goto IL_1740;
																																						case 445:
																																							goto IL_1759;
																																						case 262:
																																							goto IL_1767;
																																						case 99:
																																						case 101:
																																							goto IL_1772;
																																						case 284:
																																							goto IL_178c;
																																						case 247:
																																							goto IL_179f;
																																						case 343:
																																							goto IL_17aa;
																																						case 267:
																																						case 335:
																																							goto IL_17b8;
																																						case 131:
																																							goto IL_17f8;
																																						case 354:
																																							goto IL_1815;
																																						case 270:
																																							goto IL_1828;
																																						case 347:
																																							goto IL_1836;
																																						case 197:
																																						case 355:
																																							goto IL_1844;
																																						case 391:
																																							goto IL_1858;
																																						case 326:
																																							goto IL_18c1;
																																						case 286:
																																							goto IL_18cf;
																																						case 396:
																																							goto IL_18e2;
																																						case 156:
																																							goto IL_18f0;
																																						case 309:
																																							goto IL_18fb;
																																						case 201:
																																							goto IL_1909;
																																						case 154:
																																						case 359:
																																							goto IL_1917;
																																						case 374:
																																							goto IL_193b;
																																						case 36:
																																							goto IL_1949;
																																						case 52:
																																							goto IL_1957;
																																						case 119:
																																						case 166:
																																							goto IL_196a;
																																						case 178:
																																							goto IL_19a7;
																																						case 53:
																																							goto IL_19bb;
																																						case 23:
																																							goto IL_19ce;
																																						case 281:
																																							goto IL_19dc;
																																						case 89:
																																							goto IL_19ef;
																																						case 69:
																																							goto IL_19fd;
																																						case 403:
																																							goto IL_1a0b;
																																						case 127:
																																						case 133:
																																							goto IL_1a16;
																																						case 148:
																																							goto IL_1a30;
																																						case 91:
																																							goto IL_1a3e;
																																						case 58:
																																							goto IL_1a4c;
																																						case 379:
																																							goto IL_1a5f;
																																						case 404:
																																							goto IL_1a6d;
																																						case 330:
																																							goto IL_1a7b;
																																						case 348:
																																							goto IL_1a86;
																																						case 81:
																																						case 314:
																																							goto IL_1a94;
																																						case 306:
																																							goto IL_1aa8;
																																						case 13:
																																							goto IL_1ae7;
																																						case 199:
																																							goto IL_1afa;
																																						case 294:
																																							goto IL_1b11;
																																						case 85:
																																						case 212:
																																							goto IL_1b1f;
																																						case 433:
																																							goto IL_1b2d;
																																						case 241:
																																							goto IL_1b50;
																																						case 180:
																																							goto IL_1b5e;
																																						case 113:
																																						case 246:
																																							goto IL_1b71;
																																						case 87:
																																							goto IL_1b8d;
																																						case 389:
																																							goto IL_1b9b;
																																						case 0:
																																							goto IL_1ba9;
																																						case 437:
																																							goto IL_1bb7;
																																						case 72:
																																						case 80:
																																							goto IL_1bc5;
																																						case 341:
																																							goto IL_1bd9;
																																						case 167:
																																							goto IL_1c18;
																																						case 11:
																																						case 59:
																																							goto IL_1c2b;
																																						case 367:
																																							goto IL_1c6b;
																																						case 414:
																																							goto IL_1c7f;
																																						case 405:
																																							goto IL_1c9b;
																																						case 176:
																																							goto IL_1ca9;
																																						case 161:
																																						case 300:
																																							goto IL_1cb7;
																																						case 422:
																																							goto IL_1ce0;
																																						case 297:
																																							goto IL_1cf9;
																																						case 152:
																																							goto IL_1d07;
																																						case 394:
																																						case 397:
																																							goto IL_1d12;
																																						case 413:
																																							goto IL_1d2f;
																																						case 432:
																																							goto IL_1d6e;
																																						case 228:
																																							goto IL_1d81;
																																						case 325:
																																							goto IL_1d8c;
																																						case 322:
																																							goto IL_1d9a;
																																						case 399:
																																						case 411:
																																							goto IL_1da8;
																																						case 423:
																																							goto IL_1dea;
																																						case 407:
																																							goto IL_1dfd;
																																						case 331:
																																						case 340:
																																							goto IL_1e14;
																																						case 366:
																																							goto IL_1e31;
																																						case 33:
																																							goto IL_1ea9;
																																						case 215:
																																							goto IL_1ec0;
																																						case 263:
																																							goto IL_1ed3;
																																						case 283:
																																							goto IL_1ee1;
																																						case 76:
																																						case 103:
																																							goto IL_1eec;
																																						case 84:
																																							goto IL_1f17;
																																						case 25:
																																							goto IL_1f30;
																																						case 237:
																																							goto IL_1f47;
																																						case 51:
																																						case 162:
																																							goto IL_1f55;
																																						case 372:
																																							goto IL_1f95;
																																						case 321:
																																							goto IL_1fa9;
																																						case 98:
																																							goto IL_1fbc;
																																						case 177:
																																							goto IL_1fca;
																																						case 216:
																																						case 390:
																																							goto IL_1fd8;
																																						case 425:
																																							goto IL_1fec;
																																						case 196:
																																							goto IL_202b;
																																						case 75:
																																						case 382:
																																							goto IL_203e;
																																						case 222:
																																							goto IL_207e;
																																						case 319:
																																							goto IL_209b;
																																						case 7:
																																						case 15:
																																						case 21:
																																						case 30:
																																						case 37:
																																						case 46:
																																						case 49:
																																						case 54:
																																						case 60:
																																						case 70:
																																						case 92:
																																						case 111:
																																						case 130:
																																						case 135:
																																						case 136:
																																						case 145:
																																						case 153:
																																						case 163:
																																						case 165:
																																						case 168:
																																						case 172:
																																						case 185:
																																						case 189:
																																						case 190:
																																						case 202:
																																						case 213:
																																						case 225:
																																						case 238:
																																						case 240:
																																						case 258:
																																						case 260:
																																						case 266:
																																						case 269:
																																						case 272:
																																						case 275:
																																						case 285:
																																						case 291:
																																						case 293:
																																						case 295:
																																						case 299:
																																						case 303:
																																						case 307:
																																						case 312:
																																						case 315:
																																						case 344:
																																						case 345:
																																						case 358:
																																						case 362:
																																						case 363:
																																						case 370:
																																						case 383:
																																						case 406:
																																						case 409:
																																						case 416:
																																						case 428:
																																						case 444:
																																						case 447:
																																							goto end_IL_0748;
																																						case 3:
																																						case 4:
																																						case 6:
																																						case 9:
																																						case 19:
																																						case 22:
																																						case 24:
																																						case 34:
																																						case 50:
																																						case 56:
																																						case 68:
																																						case 71:
																																						case 74:
																																						case 79:
																																						case 90:
																																						case 104:
																																						case 115:
																																						case 116:
																																						case 118:
																																						case 132:
																																						case 142:
																																						case 155:
																																						case 159:
																																						case 171:
																																						case 179:
																																						case 181:
																																						case 182:
																																						case 184:
																																						case 188:
																																						case 193:
																																						case 194:
																																						case 206:
																																						case 210:
																																						case 218:
																																						case 229:
																																						case 235:
																																						case 236:
																																						case 249:
																																						case 250:
																																						case 271:
																																						case 279:
																																						case 282:
																																						case 296:
																																						case 305:
																																						case 308:
																																						case 310:
																																						case 316:
																																						case 349:
																																						case 350:
																																						case 351:
																																						case 356:
																																						case 361:
																																						case 387:
																																						case 398:
																																						case 426:
																																						case 427:
																																						case 440:
																																							goto IL_20be;
																																						case 175:
																																							goto IL_20d1;
																																						case 353:
																																							goto IL_20db;
																																						case 61:
																																							goto IL_20e6;
																																						case 412:
																																							goto IL_20f6;
																																						case 253:
																																							goto IL_2106;
																																						case 93:
																																							goto IL_2116;
																																						case 265:
																																							goto IL_2126;
																																						case 352:
																																							goto IL_2136;
																																						case 12:
																																							goto IL_2146;
																																						case 41:
																																							goto IL_2156;
																																						case 169:
																																							goto IL_2166;
																																						case 43:
																																						case 57:
																																							goto IL_2181;
																																						}
																																						goto end_IL_07d8;
																																					}
																																					goto IL_12da;
																																					IL_1301:
																																					num6++;
																																					goto IL_130f;
																																					IL_130f:
																																					ptr2 += 16;
																																					goto IL_20be;
																																					IL_12da:
																																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																																					goto IL_12f3;
																																					IL_12f3:
																																					array2[num6] = 3;
																																					goto IL_1301;
																																					continue;
																																					end_IL_0735:
																																					break;
																																				}
																																				goto IL_0c54;
																																				continue;
																																				end_IL_0748:
																																				break;
																																				IL_0748:;
																																			}
																																			break;
																																			IL_075b:;
																																		}
																																		break;
																																	}
																																	goto IL_0845;
																																	IL_0948:
																																	ptr2 += 8;
																																	goto IL_20be;
																																	IL_0845:
																																	if (25 > b)
																																	{
																																		goto IL_088c;
																																	}
																																	goto IL_095b;
																																	IL_095b:
																																	array2[num6 - 2] = 0;
																																	goto IL_096f;
																																	IL_096f:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																																	goto IL_09c1;
																																	IL_09c1:
																																	num6--;
																																	goto IL_0a90;
																																	IL_0a90:
																																	ptr2 += 8;
																																	goto IL_20be;
																																	IL_088c:
																																	if (24 < b)
																																	{
																																		break;
																																	}
																																	goto IL_089a;
																																	IL_089a:
																																	if (24 > b)
																																	{
																																		break;
																																	}
																																	goto IL_090e;
																																	IL_090e:
																																	array2[num6] = 5;
																																	goto IL_091c;
																																	IL_091c:
																																	array3[num6] = ((delegate*<string>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
																																	goto IL_093a;
																																	IL_093a:
																																	num6++;
																																	goto IL_0948;
																																}
																																break;
																															}
																															goto IL_1322;
																															IL_143d:
																															num6--;
																															goto IL_20be;
																															IL_1322:
																															if (23 <= b)
																															{
																																goto IL_132d;
																															}
																															goto IL_1392;
																															IL_132d:
																															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																															goto IL_137f;
																															IL_137f:
																															num6--;
																															goto IL_20be;
																															IL_1392:
																															if (21 >= b)
																															{
																																goto IL_139d;
																															}
																															goto IL_13c3;
																															IL_139d:
																															if (21 > b)
																															{
																																break;
																															}
																															goto IL_13ab;
																															IL_13ab:
																															ptr2 = ptr + *(int*)(ptr2 + num3);
																															goto IL_20be;
																															IL_13c3:
																															if (22 < b)
																															{
																																break;
																															}
																															goto IL_13d1;
																															IL_13d1:
																															if (22 > b)
																															{
																																break;
																															}
																															goto IL_13df;
																															IL_13df:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																															num = 227;
																															goto IL_1429;
																															IL_1429:
																															array2[num6 - 2] = 0;
																															goto IL_143d;
																														}
																														break;
																													}
																													goto IL_087c;
																													IL_08fb:
																													ptr2 += 16;
																													goto IL_20be;
																													IL_087c:
																													if (20 <= b)
																													{
																														goto IL_08bd;
																													}
																													goto IL_0edd;
																													IL_0edd:
																													if (16 >= b)
																													{
																														goto IL_0eeb;
																													}
																													goto IL_1003;
																													IL_0eeb:
																													if (16 <= b)
																													{
																														goto IL_0ef9;
																													}
																													goto IL_0f7e;
																													IL_0ef9:
																													array2[num6] = array2[num6 - 1];
																													goto IL_0f11;
																													IL_0f11:
																													array4[num6 - 0] = array4[num6 - 1];
																													goto IL_0f2f;
																													IL_0f2f:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0f53;
																													IL_0f53:
																													array3[num6] = array3[num6 - 1];
																													goto IL_0f6b;
																													IL_0f6b:
																													num6++;
																													goto IL_20be;
																													IL_0f7e:
																													if (14 >= b)
																													{
																														goto IL_0f89;
																													}
																													goto IL_0f9c;
																													IL_0f89:
																													if (14 > b)
																													{
																														break;
																													}
																													goto IL_1106;
																													IL_1106:
																													array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																													goto IL_1124;
																													IL_1124:
																													ptr2 += 8;
																													goto IL_1132;
																													IL_1132:
																													num6--;
																													goto IL_20be;
																													IL_0f9c:
																													if (15 < b)
																													{
																														break;
																													}
																													goto IL_0faa;
																													IL_0faa:
																													if (15 > b)
																													{
																														break;
																													}
																													goto IL_0fb8;
																													IL_0fb8:
																													array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																													num = 62;
																													goto IL_0fea;
																													IL_0fea:
																													array2[num6 - 1] = 5;
																													goto IL_20be;
																													IL_1003:
																													if (18 >= b)
																													{
																														goto IL_100e;
																													}
																													goto IL_108b;
																													IL_100e:
																													if (18 <= b)
																													{
																														goto IL_1019;
																													}
																													goto IL_106a;
																													IL_1019:
																													((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																													goto IL_1057;
																													IL_1057:
																													num6 -= 3;
																													goto IL_20be;
																													IL_106a:
																													if (17 < b)
																													{
																														break;
																													}
																													goto IL_1078;
																													IL_1078:
																													if (17 > b)
																													{
																														break;
																													}
																													goto IL_1272;
																													IL_1272:
																													array2[num6] = 5;
																													goto IL_1280;
																													IL_1280:
																													array3[num6] = array7[*(int*)(ptr2 + num3)];
																													goto IL_1298;
																													IL_1298:
																													num6++;
																													goto IL_12a6;
																													IL_12a6:
																													ptr2 += 8;
																													goto IL_20be;
																													IL_108b:
																													if (19 < b)
																													{
																														break;
																													}
																													goto IL_1099;
																													IL_1099:
																													if (19 > b)
																													{
																														break;
																													}
																													goto IL_10a7;
																													IL_10a7:
																													array2[num6 - 1] = 5;
																													goto IL_10bb;
																													IL_10bb:
																													array3[num6 - 1] = ((delegate*<string[], string>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																													goto IL_10f3;
																													IL_10f3:
																													ptr2 += 8;
																													goto IL_20be;
																													IL_08bd:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																													goto IL_08d6;
																													IL_08d6:
																													array2[num6] = 1;
																													goto IL_08e4;
																													IL_08e4:
																													num6++;
																													num = 311;
																													goto IL_08fb;
																												}
																												break;
																											}
																											goto IL_08aa;
																											IL_0dc6:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_0e05;
																											IL_08aa:
																											if (13 <= b)
																											{
																												goto IL_09d4;
																											}
																											goto IL_0aa3;
																											IL_09d4:
																											array8 = array3;
																											num7 = num6;
																											if (array == null)
																											{
																												goto IL_09e3;
																											}
																											num8 = ptr2;
																											byte b2 = *num8;
																											ptr2 = num8 + 4;
																											int num9 = *(int*)(ptr2 + num3);
																											ptr2 += 8;
																											byte* ptr3 = ptr2 + num9;
																											byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																											while (ptr2 != ptr3)
																											{
																												*ptr4 = (byte)(*ptr2 ^ b2);
																												ptr2++;
																												ptr4++;
																											}
																											array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																											goto IL_1235;
																											IL_0e05:
																											ptr2 += 8;
																											goto IL_20be;
																											IL_0e18:
																											if (10 < b)
																											{
																												break;
																											}
																											goto IL_0e26;
																											IL_0e26:
																											if (10 > b)
																											{
																												break;
																											}
																											goto IL_0e34;
																											IL_1235:
																											array2[num6] = 5;
																											num = 14;
																											goto IL_124c;
																											IL_124c:
																											num6++;
																											goto IL_20be;
																											IL_0aa3:
																											if (6 >= b)
																											{
																												goto IL_0ab1;
																											}
																											goto IL_0bd4;
																											IL_0ab1:
																											if (6 <= b)
																											{
																												goto IL_0abc;
																											}
																											goto IL_0b2c;
																											IL_0abc:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											num = 214;
																											goto IL_0b05;
																											IL_0b05:
																											array2[num6 - 2] = 0;
																											goto IL_0b19;
																											IL_0b19:
																											num6--;
																											goto IL_20be;
																											IL_0b2c:
																											if (3 >= b)
																											{
																												goto IL_0b3a;
																											}
																											goto IL_1145;
																											IL_0b3a:
																											if (3 <= b)
																											{
																												goto IL_0b45;
																											}
																											goto IL_0b73;
																											IL_0b45:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0ea9;
																											IL_0ea9:
																											ptr2 += 8;
																											goto IL_0eb7;
																											IL_0eb7:
																											num6--;
																											goto IL_20be;
																											IL_0b73:
																											if (1 >= b)
																											{
																												num = 141;
																												goto IL_0b87;
																											}
																											goto IL_0bb3;
																											IL_0e34:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0e96;
																											IL_0b87:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0b95;
																											IL_0b95:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																											goto IL_0d94;
																											IL_0d94:
																											array2[num6] = 0;
																											goto IL_12b9;
																											IL_12b9:
																											num6++;
																											goto IL_12c7;
																											IL_12c7:
																											ptr2 += 8;
																											goto IL_20be;
																											IL_0bb3:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_0bc1;
																											IL_0bc1:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0d2d;
																											IL_0d2d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0d6d;
																											IL_0d6d:
																											array2[num6 - 2] = 0;
																											goto IL_0d81;
																											IL_0d81:
																											num6--;
																											goto IL_20be;
																											IL_1145:
																											if (4 >= b)
																											{
																												goto IL_1150;
																											}
																											goto IL_11c3;
																											IL_1150:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_115e;
																											IL_115e:
																											array2[num6] = 0;
																											goto IL_116c;
																											IL_116c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_118f;
																											IL_118f:
																											array3[num6] = null;
																											num = 173;
																											goto IL_11a2;
																											IL_11a2:
																											num6++;
																											goto IL_11b0;
																											IL_11b0:
																											ptr2 += 8;
																											goto IL_20be;
																											IL_11c3:
																											if (5 < b)
																											{
																												break;
																											}
																											goto IL_11d1;
																											IL_11d1:
																											if (5 > b)
																											{
																												break;
																											}
																											goto IL_11df;
																											IL_11df:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_121f;
																											IL_121f:
																											array2[num6 - 2] = 0;
																											goto IL_125f;
																											IL_125f:
																											num6--;
																											goto IL_20be;
																											IL_0bd4:
																											if (9 >= b)
																											{
																												goto IL_0be2;
																											}
																											goto IL_0cf5;
																											IL_0be2:
																											if (9 <= b)
																											{
																												goto IL_0bed;
																											}
																											goto IL_0c54;
																											IL_0bed:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0c2d;
																											IL_0c2d:
																											array2[num6 - 2] = 0;
																											goto IL_0c41;
																											IL_0c41:
																											num6--;
																											goto IL_20be;
																											IL_0c54:
																											if (7 >= b)
																											{
																												goto IL_0c5f;
																											}
																											goto IL_0cc6;
																											IL_0c5f:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_0c6d;
																											IL_0c6d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0cad;
																											IL_0cad:
																											array2[num6 - 2] = 0;
																											goto IL_0eca;
																											IL_0eca:
																											num6--;
																											goto IL_20be;
																											IL_0cc6:
																											if (8 < b)
																											{
																												break;
																											}
																											goto IL_0cd4;
																											IL_0cd4:
																											if (8 > b)
																											{
																												break;
																											}
																											goto IL_0ce2;
																											IL_0ce2:
																											num6--;
																											goto IL_20be;
																											IL_0cf5:
																											if (11 < b)
																											{
																												goto IL_0d03;
																											}
																											goto IL_0da7;
																											IL_0d03:
																											if (12 < b)
																											{
																												break;
																											}
																											num = 380;
																											goto IL_0d1a;
																											IL_0e96:
																											num6 -= 2;
																											goto IL_20be;
																											IL_0d1a:
																											if (12 > b)
																											{
																												break;
																											}
																											goto IL_20be;
																											IL_0da7:
																											if (11 <= b)
																											{
																												goto IL_0db2;
																											}
																											goto IL_0e18;
																											IL_0db2:
																											array2[num6 - 1] = 0;
																											goto IL_0dc6;
																										}
																										break;
																									}
																									goto IL_0803;
																									IL_0869:
																									num6--;
																									goto IL_20be;
																									IL_0803:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0855;
																									IL_0855:
																									array2[num6 - 2] = 3;
																									goto IL_0869;
																								}
																								break;
																							}
																							goto IL_1450;
																							IL_1fec:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_202b;
																							IL_1450:
																							if (41 < b)
																							{
																								goto IL_145e;
																							}
																							goto IL_19ef;
																							IL_145e:
																							if (48 >= b)
																							{
																								goto IL_146c;
																							}
																							goto IL_1759;
																							IL_146c:
																							if (48 > b)
																							{
																								goto IL_147a;
																							}
																							goto IL_1715;
																							IL_147a:
																							if (44 >= b)
																							{
																								goto IL_1488;
																							}
																							goto IL_15d8;
																							IL_1488:
																							if (44 > b)
																							{
																								goto IL_1496;
																							}
																							goto IL_15a3;
																							IL_1496:
																							if (42 < b)
																							{
																								goto IL_14a4;
																							}
																							goto IL_152f;
																							IL_14a4:
																							if (43 < b)
																							{
																								break;
																							}
																							goto IL_14b2;
																							IL_14b2:
																							if (43 > b)
																							{
																								break;
																							}
																							goto IL_14c0;
																							IL_14c0:
																							array2[num6 - 1] = 3;
																							goto IL_14d4;
																							IL_14d4:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1513;
																							IL_1513:
																							ptr2 += 8;
																							num = 68;
																							goto IL_20be;
																							IL_152f:
																							if (42 > b)
																							{
																								break;
																							}
																							goto IL_153d;
																							IL_153d:
																							array2[num6 - 1] = 3;
																							goto IL_1551;
																							IL_1551:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1590;
																							IL_1590:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_15a3:
																							global::_003CModule_003E.color_13 = (Color[])array3[num6 - 1];
																							goto IL_15bc;
																							IL_15bc:
																							num6--;
																							num = 90;
																							goto IL_20be;
																							IL_15d8:
																							if (46 >= b)
																							{
																								goto IL_15e6;
																							}
																							goto IL_16ad;
																							IL_15e6:
																							if (46 <= b)
																							{
																								goto IL_15f1;
																							}
																							goto IL_163e;
																							IL_15f1:
																							array3[num6] = ((delegate*<Color[]>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
																							goto IL_160f;
																							IL_160f:
																							array2[num6] = 5;
																							goto IL_161d;
																							IL_161d:
																							num6++;
																							goto IL_162b;
																							IL_162b:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_163e:
																							if (45 < b)
																							{
																								break;
																							}
																							goto IL_164c;
																							IL_164c:
																							if (45 > b)
																							{
																								break;
																							}
																							goto IL_165a;
																							IL_165a:
																							array2[num6] = 0;
																							goto IL_1668;
																							IL_1668:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
																							goto IL_168c;
																							IL_168c:
																							num6++;
																							goto IL_169a;
																							IL_169a:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_16ad:
																							if (47 < b)
																							{
																								break;
																							}
																							goto IL_16bb;
																							IL_16bb:
																							if (47 > b)
																							{
																								break;
																							}
																							num = 158;
																							goto IL_16d2;
																							IL_202b:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_16d2:
																							*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((Color[])array3[num6 - 1]).LongLength;
																							goto IL_16fc;
																							IL_16fc:
																							array2[num6 - 1] = 2;
																							goto IL_20be;
																							IL_1715:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1740;
																							IL_1740:
																							array2[num6 - 1] = 0;
																							goto IL_20be;
																							IL_1759:
																							if (51 >= b)
																							{
																								goto IL_1767;
																							}
																							goto IL_18e2;
																							IL_1767:
																							if (51 <= b)
																							{
																								goto IL_1772;
																							}
																							goto IL_179f;
																							IL_1772:
																							global::_003CModule_003E.int_211 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_178c;
																							IL_178c:
																							num6--;
																							goto IL_20be;
																							IL_179f:
																							if (49 >= b)
																							{
																								goto IL_17aa;
																							}
																							goto IL_1828;
																							IL_17aa:
																							if (49 > b)
																							{
																								break;
																							}
																							goto IL_17b8;
																							IL_17b8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_17f8;
																							IL_17f8:
																							array2[num6 - 2] = 0;
																							num = 354;
																							goto IL_1815;
																							IL_1815:
																							num6--;
																							goto IL_20be;
																							IL_1828:
																							if (50 < b)
																							{
																								break;
																							}
																							goto IL_1836;
																							IL_1836:
																							if (50 > b)
																							{
																								break;
																							}
																							goto IL_1844;
																							IL_1844:
																							array2[num6 - 3] = 0;
																							goto IL_1858;
																							IL_1858:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]) = ((delegate*<int, int, int, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_18c1;
																							IL_18c1:
																							num6 -= 2;
																							goto IL_18cf;
																							IL_18cf:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_18e2:
																							if (53 >= b)
																							{
																								goto IL_18f0;
																							}
																							goto IL_19ce;
																							IL_18f0:
																							if (53 > b)
																							{
																								goto IL_18fb;
																							}
																							goto IL_196a;
																							IL_18fb:
																							if (52 < b)
																							{
																								break;
																							}
																							goto IL_1909;
																							IL_1909:
																							if (52 > b)
																							{
																								break;
																							}
																							goto IL_1917;
																							IL_1917:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
																							goto IL_193b;
																							IL_193b:
																							array2[num6] = 0;
																							goto IL_1949;
																							IL_1949:
																							num6++;
																							goto IL_1957;
																							IL_1957:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_196a:
																							array3[num6 - 2] = ((Color[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_19a7;
																							IL_19a7:
																							array2[num6 - 2] = 4;
																							goto IL_19bb;
																							IL_19bb:
																							num6--;
																							goto IL_20be;
																							IL_19ce:
																							if (54 < b)
																							{
																								break;
																							}
																							goto IL_19dc;
																							IL_19dc:
																							if (54 > b)
																							{
																							}
																							break;
																							IL_19ef:
																							if (41 > b)
																							{
																								goto IL_19fd;
																							}
																							goto IL_203e;
																							IL_19fd:
																							if (34 >= b)
																							{
																								goto IL_1a0b;
																							}
																							goto IL_1cf9;
																							IL_1a0b:
																							if (34 <= b)
																							{
																								goto IL_1a16;
																							}
																							goto IL_1a5f;
																							IL_1a16:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																							goto IL_1a30;
																							IL_1a30:
																							array2[num6] = 3;
																							goto IL_1a3e;
																							IL_1a3e:
																							num6++;
																							goto IL_1a4c;
																							IL_1a4c:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_1a5f:
																							if (30 >= b)
																							{
																								goto IL_1a6d;
																							}
																							goto IL_1b8d;
																							IL_1a6d:
																							if (30 > b)
																							{
																								goto IL_1a7b;
																							}
																							goto IL_1b71;
																							IL_1a7b:
																							if (28 >= b)
																							{
																								goto IL_1a86;
																							}
																							goto IL_1afa;
																							IL_1a86:
																							if (28 > b)
																							{
																								break;
																							}
																							goto IL_1a94;
																							IL_1a94:
																							array2[num6 - 1] = 0;
																							goto IL_1aa8;
																							IL_1aa8:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1ae7;
																							IL_1ae7:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_1afa:
																							if (29 < b)
																							{
																								break;
																							}
																							num = 294;
																							goto IL_1b11;
																							IL_203e:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_207e;
																							IL_1b11:
																							if (29 > b)
																							{
																								break;
																							}
																							goto IL_1b1f;
																							IL_1b1f:
																							array2[num6] = 4;
																							goto IL_1b2d;
																							IL_1b2d:
																							array3[num6] = ((delegate*<Color>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
																							goto IL_1b50;
																							IL_1b50:
																							num6++;
																							goto IL_1b5e;
																							IL_1b5e:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_1b71:
																							num10 = ptr2;
																							num11 = -200;
																							num5 = 1;
																							ptr2 = num10 + num11;
																							goto IL_20be;
																							IL_1b8d:
																							if (32 >= b)
																							{
																								goto IL_1b9b;
																							}
																							goto IL_1c9b;
																							IL_1b9b:
																							if (32 > b)
																							{
																								goto IL_1ba9;
																							}
																							goto IL_1c2b;
																							IL_1ba9:
																							if (31 < b)
																							{
																								break;
																							}
																							goto IL_1bb7;
																							IL_1bb7:
																							if (31 > b)
																							{
																								break;
																							}
																							goto IL_1bc5;
																							IL_1bc5:
																							array2[num6 - 1] = 3;
																							goto IL_1bd9;
																							IL_1bd9:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1c18;
																							IL_1c18:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_1c2b:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1c6b;
																							IL_1c6b:
																							array2[num6 - 2] = 3;
																							goto IL_1c7f;
																							IL_1c7f:
																							num6--;
																							num = 115;
																							goto IL_20be;
																							IL_1c9b:
																							if (33 < b)
																							{
																								break;
																							}
																							goto IL_1ca9;
																							IL_1ca9:
																							if (33 > b)
																							{
																								break;
																							}
																							goto IL_1cb7;
																							IL_1cb7:
																							array3[num6 - 1] = new Color[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_1ce0;
																							IL_1ce0:
																							array2[num6 - 1] = 5;
																							goto IL_20be;
																							IL_1cf9:
																							if (37 >= b)
																							{
																								goto IL_1d07;
																							}
																							goto IL_1ed3;
																							IL_1d07:
																							if (37 <= b)
																							{
																								goto IL_1d12;
																							}
																							goto IL_1d81;
																							IL_1d12:
																							array2[num6 - 1] = 0;
																							num = 413;
																							goto IL_1d2f;
																							IL_1d2f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1d6e;
																							IL_1d6e:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_1d81:
																							if (35 < b)
																							{
																								goto IL_1d8c;
																							}
																							goto IL_1dfd;
																							IL_1d8c:
																							if (36 < b)
																							{
																								break;
																							}
																							goto IL_1d9a;
																							IL_1d9a:
																							if (36 > b)
																							{
																								break;
																							}
																							goto IL_1da8;
																							IL_1da8:
																							((Color[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (Color)array3[num6 - 1];
																							goto IL_1dea;
																							IL_1dea:
																							num6 -= 3;
																							goto IL_20be;
																							IL_1dfd:
																							if (35 > b)
																							{
																								break;
																							}
																							num = 340;
																							goto IL_1e14;
																							IL_207e:
																							array2[num6 - 2] = 3;
																							num = 319;
																							goto IL_209b;
																							IL_1e14:
																							array2[num6 - 4] = 5;
																							num = 366;
																							goto IL_1e31;
																							IL_1e31:
																							array3[num6 - 4] = ((delegate*<float, float, float, float, object>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
																							goto IL_1ea9;
																							IL_1ea9:
																							num6 -= 3;
																							num = 215;
																							goto IL_1ec0;
																							IL_1ec0:
																							ptr2 += 8;
																							goto IL_20be;
																							IL_1ed3:
																							if (39 >= b)
																							{
																								goto IL_1ee1;
																							}
																							goto IL_1fbc;
																							IL_1ee1:
																							if (39 <= b)
																							{
																								goto IL_1eec;
																							}
																							goto IL_1f30;
																							IL_1eec:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1f17;
																							IL_1f17:
																							array2[num6 - 1] = 0;
																							goto IL_20be;
																							IL_1f30:
																							if (38 < b)
																							{
																								break;
																							}
																							num = 237;
																							goto IL_1f47;
																							IL_209b:
																							num6--;
																							goto IL_20be;
																							IL_1f47:
																							if (38 > b)
																							{
																								break;
																							}
																							goto IL_1f55;
																							IL_1f55:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1f95;
																							IL_1f95:
																							array2[num6 - 2] = 3;
																							goto IL_1fa9;
																							IL_1fa9:
																							num6--;
																							goto IL_20be;
																							IL_1fbc:
																							if (40 < b)
																							{
																								break;
																							}
																							goto IL_1fca;
																							IL_1fca:
																							if (40 > b)
																							{
																								break;
																							}
																							goto IL_1fd8;
																							IL_1fd8:
																							array2[num6 - 1] = 3;
																							goto IL_1fec;
																						}
																						break;
																						IL_07c8:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_20be;
																				continue;
																				end_IL_07d8:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																goto IL_2181;
																IL_2181:
																return (Color)array3[num6 - 1];
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_09e3:
			while (true)
			{
				IL_09e3_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_1235_2:
						array2[num6] = 5;
						num = 14;
						while (true)
						{
							IL_124c_2:
							num6++;
							while (true)
							{
								IL_20be_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_07d8_2:
												if (b >= 1)
												{
													while (b <= 54)
													{
														while (true)
														{
															IL_07b8_2:
															if (27 >= b)
															{
																while (true)
																{
																	IL_07ab_2:
																	if (27 > b)
																	{
																		while (true)
																		{
																			IL_079b_2:
																			if (13 < b)
																			{
																				while (true)
																				{
																					IL_078b_2:
																					if (20 < b)
																					{
																						while (true)
																						{
																							IL_077b_2:
																							if (23 < b)
																							{
																								while (true)
																								{
																									IL_076b_2:
																									if (25 < b)
																									{
																										while (26 >= b)
																										{
																											while (26 <= b)
																											{
																												num = 454;
																												while (true)
																												{
																													if (num != 454)
																													{
																														if (num != 1435)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 369:
																															goto IL_0748_2;
																														case 243:
																															goto IL_075b_2;
																														case 10:
																															goto IL_076b_2;
																														case 160:
																															goto IL_077b_2;
																														case 221:
																															goto IL_078b_2;
																														case 342:
																															goto IL_079b_2;
																														case 301:
																															goto IL_07ab_2;
																														case 317:
																															goto IL_07b8_2;
																														case 435:
																															goto IL_07c8_2;
																														case 147:
																															goto IL_07d8_2;
																														case 108:
																															goto end_IL_07d8_2;
																														case 77:
																														case 292:
																															goto end_IL_07e8;
																														case 35:
																														case 64:
																															goto IL_0803_2;
																														case 95:
																															goto IL_0845_2;
																														case 117:
																															goto IL_0855_2;
																														case 96:
																															goto IL_0869_2;
																														case 149:
																															goto IL_087c_2;
																														case 207:
																															goto IL_088c_2;
																														case 186:
																															goto IL_089a_2;
																														case 256:
																															goto IL_08aa_2;
																														case 140:
																														case 280:
																															goto IL_08bd_2;
																														case 242:
																															goto IL_08d6_2;
																														case 29:
																															goto IL_08e4_2;
																														case 311:
																															goto IL_08fb_2;
																														case 251:
																														case 313:
																															goto IL_090e_2;
																														case 217:
																															goto IL_091c_2;
																														case 318:
																															goto IL_093a_2;
																														case 32:
																															goto IL_0948_2;
																														case 233:
																														case 334:
																															goto IL_095b_2;
																														case 231:
																															goto IL_096f_2;
																														case 208:
																															goto IL_09c1_2;
																														case 328:
																														case 381:
																															goto end_IL_07f8;
																														case 385:
																															goto IL_0a90_2;
																														case 386:
																															goto IL_0aa3_2;
																														case 244:
																															goto IL_0ab1_2;
																														case 63:
																														case 191:
																															goto IL_0abc_2;
																														case 214:
																															goto IL_0b05_2;
																														case 110:
																															goto IL_0b19_2;
																														case 47:
																															goto IL_0b2c_2;
																														case 230:
																															goto IL_0b3a_2;
																														case 66:
																														case 137:
																															goto IL_0b45_2;
																														case 138:
																															goto IL_0b73_2;
																														case 141:
																															goto IL_0b87_2;
																														case 124:
																														case 324:
																															goto IL_0b95_2;
																														case 329:
																															goto IL_0bb3_2;
																														case 125:
																															goto IL_0bc1_2;
																														case 245:
																															goto IL_0bd4_2;
																														case 257:
																															goto IL_0be2_2;
																														case 83:
																														case 346:
																															goto IL_0bed_2;
																														case 102:
																															goto IL_0c2d_2;
																														case 205:
																															goto IL_0c41_2;
																														case 2:
																															goto end_IL_0735_2;
																														case 86:
																															goto IL_0c5f_2;
																														case 100:
																														case 114:
																															goto IL_0c6d_2;
																														case 337:
																															goto IL_0cad_2;
																														case 332:
																															goto IL_0cc6_2;
																														case 274:
																															goto IL_0cd4_2;
																														case 82:
																														case 375:
																															goto IL_0ce2_2;
																														case 73:
																															goto IL_0cf5_2;
																														case 28:
																															goto IL_0d03_2;
																														case 380:
																															goto IL_0d1a_2;
																														case 378:
																														case 388:
																															goto IL_0d2d_2;
																														case 146:
																															goto IL_0d6d_2;
																														case 139:
																															goto IL_0d81_2;
																														case 393:
																															goto IL_0d94_2;
																														case 401:
																															goto IL_0da7_2;
																														case 88:
																														case 392:
																															goto IL_0db2_2;
																														case 211:
																															goto IL_0dc6_2;
																														case 368:
																															goto IL_0e05_2;
																														case 65:
																															goto IL_0e18_2;
																														case 320:
																															goto IL_0e26_2;
																														case 20:
																														case 232:
																															goto IL_0e34_2;
																														case 143:
																															goto IL_0e96_2;
																														case 418:
																															goto IL_0ea9_2;
																														case 187:
																															goto IL_0eb7_2;
																														case 419:
																															goto IL_0eca_2;
																														case 430:
																															goto IL_0edd_2;
																														case 5:
																															goto IL_0eeb_2;
																														case 365:
																														case 371:
																															goto IL_0ef9_2;
																														case 277:
																															goto IL_0f11_2;
																														case 198:
																															goto IL_0f2f_2;
																														case 400:
																															goto IL_0f53_2;
																														case 128:
																															goto IL_0f6b_2;
																														case 424:
																															goto IL_0f7e_2;
																														case 376:
																															goto IL_0f89_2;
																														case 121:
																															goto IL_0f9c_2;
																														case 384:
																															goto IL_0faa_2;
																														case 78:
																														case 126:
																															goto IL_0fb8_2;
																														case 62:
																															goto IL_0fea_2;
																														case 8:
																															goto IL_1003_2;
																														case 408:
																															goto IL_100e_2;
																														case 276:
																														case 338:
																															goto IL_1019_2;
																														case 157:
																															goto IL_1057_2;
																														case 42:
																															goto IL_106a_2;
																														case 195:
																															goto IL_1078_2;
																														case 420:
																															goto IL_108b_2;
																														case 122:
																															goto IL_1099_2;
																														case 26:
																														case 417:
																															goto IL_10a7_2;
																														case 112:
																															goto IL_10bb_2;
																														case 106:
																															goto IL_10f3_2;
																														case 336:
																														case 431:
																															goto IL_1106_2;
																														case 105:
																															goto IL_1124_2;
																														case 421:
																															goto IL_1132_2;
																														case 436:
																															goto IL_1145_2;
																														case 395:
																															goto IL_1150_2;
																														case 18:
																														case 67:
																															goto IL_115e_2;
																														case 288:
																															goto IL_116c_2;
																														case 402:
																															goto IL_118f_2;
																														case 173:
																															goto IL_11a2_2;
																														case 31:
																															goto IL_11b0_2;
																														case 364:
																															goto IL_11c3_2;
																														case 224:
																															goto IL_11d1_2;
																														case 55:
																														case 287:
																															goto IL_11df_2;
																														case 278:
																															goto IL_121f_2;
																														case 438:
																															goto IL_1235_2;
																														case 14:
																															goto IL_124c_2;
																														case 439:
																															goto IL_125f_2;
																														case 209:
																														case 443:
																															goto IL_1272_2;
																														case 304:
																															goto IL_1280_2;
																														case 377:
																															goto IL_1298_2;
																														case 203:
																															goto IL_12a6_2;
																														case 446:
																															goto IL_12b9_2;
																														case 109:
																															goto IL_12c7_2;
																														case 94:
																															goto IL_12da_2;
																														case 226:
																															goto IL_12f3_2;
																														case 223:
																															goto IL_1301_2;
																														case 129:
																															goto IL_130f_2;
																														case 27:
																															goto IL_1322_2;
																														case 333:
																														case 339:
																															goto IL_132d_2;
																														case 259:
																															goto IL_137f_2;
																														case 441:
																															goto IL_1392_2;
																														case 410:
																															goto IL_139d_2;
																														case 134:
																														case 273:
																															goto IL_13ab_2;
																														case 144:
																															goto IL_13c3_2;
																														case 192:
																															goto IL_13d1_2;
																														case 261:
																														case 323:
																															goto IL_13df_2;
																														case 227:
																															goto IL_1429_2;
																														case 200:
																															goto IL_143d_2;
																														case 220:
																															goto IL_1450_2;
																														case 174:
																															goto IL_145e_2;
																														case 373:
																															goto IL_146c_2;
																														case 44:
																															goto IL_147a_2;
																														case 264:
																															goto IL_1488_2;
																														case 1:
																															goto IL_1496_2;
																														case 120:
																															goto IL_14a4_2;
																														case 164:
																															goto IL_14b2_2;
																														case 97:
																														case 268:
																															goto IL_14c0_2;
																														case 17:
																															goto IL_14d4_2;
																														case 255:
																															goto IL_1513_2;
																														case 107:
																															goto IL_152f_2;
																														case 45:
																														case 434:
																															goto IL_153d_2;
																														case 298:
																															goto IL_1551_2;
																														case 327:
																															goto IL_1590_2;
																														case 151:
																														case 254:
																															goto IL_15a3_2;
																														case 16:
																															goto IL_15bc_2;
																														case 234:
																															goto IL_15d8_2;
																														case 442:
																															goto IL_15e6_2;
																														case 357:
																														case 360:
																															goto IL_15f1_2;
																														case 302:
																															goto IL_160f_2;
																														case 39:
																															goto IL_161d_2;
																														case 183:
																															goto IL_162b_2;
																														case 415:
																															goto IL_163e_2;
																														case 40:
																															goto IL_164c_2;
																														case 38:
																														case 219:
																															goto IL_165a_2;
																														case 150:
																															goto IL_1668_2;
																														case 248:
																															goto IL_168c_2;
																														case 123:
																															goto IL_169a_2;
																														case 290:
																															goto IL_16ad_2;
																														case 289:
																															goto IL_16bb_2;
																														case 158:
																														case 429:
																															goto IL_16d2_2;
																														case 252:
																															goto IL_16fc_2;
																														case 48:
																														case 204:
																															goto IL_1715_2;
																														case 239:
																															goto IL_1740_2;
																														case 445:
																															goto IL_1759_2;
																														case 262:
																															goto IL_1767_2;
																														case 99:
																														case 101:
																															goto IL_1772_2;
																														case 284:
																															goto IL_178c_2;
																														case 247:
																															goto IL_179f_2;
																														case 343:
																															goto IL_17aa_2;
																														case 267:
																														case 335:
																															goto IL_17b8_2;
																														case 131:
																															goto IL_17f8_2;
																														case 354:
																															goto IL_1815_2;
																														case 270:
																															goto IL_1828_2;
																														case 347:
																															goto IL_1836_2;
																														case 197:
																														case 355:
																															goto IL_1844_2;
																														case 391:
																															goto IL_1858_2;
																														case 326:
																															goto IL_18c1_2;
																														case 286:
																															goto IL_18cf_2;
																														case 396:
																															goto IL_18e2_2;
																														case 156:
																															goto IL_18f0_2;
																														case 309:
																															goto IL_18fb_2;
																														case 201:
																															goto IL_1909_2;
																														case 154:
																														case 359:
																															goto IL_1917_2;
																														case 374:
																															goto IL_193b_2;
																														case 36:
																															goto IL_1949_2;
																														case 52:
																															goto IL_1957_2;
																														case 119:
																														case 166:
																															goto IL_196a_2;
																														case 178:
																															goto IL_19a7_2;
																														case 53:
																															goto IL_19bb_2;
																														case 23:
																															goto IL_19ce_2;
																														case 281:
																															goto IL_19dc_2;
																														case 89:
																															goto IL_19ef_2;
																														case 69:
																															goto IL_19fd_2;
																														case 403:
																															goto IL_1a0b_2;
																														case 127:
																														case 133:
																															goto IL_1a16_2;
																														case 148:
																															goto IL_1a30_2;
																														case 91:
																															goto IL_1a3e_2;
																														case 58:
																															goto IL_1a4c_2;
																														case 379:
																															goto IL_1a5f_2;
																														case 404:
																															goto IL_1a6d_2;
																														case 330:
																															goto IL_1a7b_2;
																														case 348:
																															goto IL_1a86_2;
																														case 81:
																														case 314:
																															goto IL_1a94_2;
																														case 306:
																															goto IL_1aa8_2;
																														case 13:
																															goto IL_1ae7_2;
																														case 199:
																															goto IL_1afa_2;
																														case 294:
																															goto IL_1b11_2;
																														case 85:
																														case 212:
																															goto IL_1b1f_2;
																														case 433:
																															goto IL_1b2d_2;
																														case 241:
																															goto IL_1b50_2;
																														case 180:
																															goto IL_1b5e_2;
																														case 113:
																														case 246:
																															goto IL_1b71_2;
																														case 87:
																															goto IL_1b8d_2;
																														case 389:
																															goto IL_1b9b_2;
																														case 0:
																															goto IL_1ba9_2;
																														case 437:
																															goto IL_1bb7_2;
																														case 72:
																														case 80:
																															goto IL_1bc5_2;
																														case 341:
																															goto IL_1bd9_2;
																														case 167:
																															goto IL_1c18_2;
																														case 11:
																														case 59:
																															goto IL_1c2b_2;
																														case 367:
																															goto IL_1c6b_2;
																														case 414:
																															goto IL_1c7f_2;
																														case 405:
																															goto IL_1c9b_2;
																														case 176:
																															goto IL_1ca9_2;
																														case 161:
																														case 300:
																															goto IL_1cb7_2;
																														case 422:
																															goto IL_1ce0_2;
																														case 297:
																															goto IL_1cf9_2;
																														case 152:
																															goto IL_1d07_2;
																														case 394:
																														case 397:
																															goto IL_1d12_2;
																														case 413:
																															goto IL_1d2f_2;
																														case 432:
																															goto IL_1d6e_2;
																														case 228:
																															goto IL_1d81_2;
																														case 325:
																															goto IL_1d8c_2;
																														case 322:
																															goto IL_1d9a_2;
																														case 399:
																														case 411:
																															goto IL_1da8_2;
																														case 423:
																															goto IL_1dea_2;
																														case 407:
																															goto IL_1dfd_2;
																														case 331:
																														case 340:
																															goto IL_1e14_2;
																														case 366:
																															goto IL_1e31_2;
																														case 33:
																															goto IL_1ea9_2;
																														case 215:
																															goto IL_1ec0_2;
																														case 263:
																															goto IL_1ed3_2;
																														case 283:
																															goto IL_1ee1_2;
																														case 76:
																														case 103:
																															goto IL_1eec_2;
																														case 84:
																															goto IL_1f17_2;
																														case 25:
																															goto IL_1f30_2;
																														case 237:
																															goto IL_1f47_2;
																														case 51:
																														case 162:
																															goto IL_1f55_2;
																														case 372:
																															goto IL_1f95_2;
																														case 321:
																															goto IL_1fa9_2;
																														case 98:
																															goto IL_1fbc_2;
																														case 177:
																															goto IL_1fca_2;
																														case 216:
																														case 390:
																															goto IL_1fd8_2;
																														case 425:
																															goto IL_1fec_2;
																														case 196:
																															goto IL_202b_2;
																														case 75:
																														case 382:
																															goto IL_203e_2;
																														case 222:
																															goto IL_207e_2;
																														case 319:
																															goto IL_209b_2;
																														case 7:
																														case 15:
																														case 21:
																														case 30:
																														case 37:
																														case 46:
																														case 49:
																														case 54:
																														case 60:
																														case 70:
																														case 92:
																														case 111:
																														case 130:
																														case 135:
																														case 136:
																														case 145:
																														case 153:
																														case 163:
																														case 165:
																														case 168:
																														case 172:
																														case 185:
																														case 189:
																														case 190:
																														case 202:
																														case 213:
																														case 225:
																														case 238:
																														case 240:
																														case 258:
																														case 260:
																														case 266:
																														case 269:
																														case 272:
																														case 275:
																														case 285:
																														case 291:
																														case 293:
																														case 295:
																														case 299:
																														case 303:
																														case 307:
																														case 312:
																														case 315:
																														case 344:
																														case 345:
																														case 358:
																														case 362:
																														case 363:
																														case 370:
																														case 383:
																														case 406:
																														case 409:
																														case 416:
																														case 428:
																														case 444:
																														case 447:
																															goto end_IL_0748_2;
																														case 3:
																														case 4:
																														case 6:
																														case 9:
																														case 19:
																														case 22:
																														case 24:
																														case 34:
																														case 50:
																														case 56:
																														case 68:
																														case 71:
																														case 74:
																														case 79:
																														case 90:
																														case 104:
																														case 115:
																														case 116:
																														case 118:
																														case 132:
																														case 142:
																														case 155:
																														case 159:
																														case 171:
																														case 179:
																														case 181:
																														case 182:
																														case 184:
																														case 188:
																														case 193:
																														case 194:
																														case 206:
																														case 210:
																														case 218:
																														case 229:
																														case 235:
																														case 236:
																														case 249:
																														case 250:
																														case 271:
																														case 279:
																														case 282:
																														case 296:
																														case 305:
																														case 308:
																														case 310:
																														case 316:
																														case 349:
																														case 350:
																														case 351:
																														case 356:
																														case 361:
																														case 387:
																														case 398:
																														case 426:
																														case 427:
																														case 440:
																															goto IL_20be_2;
																														case 175:
																															ptr2 = ptr;
																															goto IL_20be_2;
																														case 353:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RsaFullCMSFILEWRITABLETYPENOTWRITABLE.SEPDateOrOffsetBeginGetRequestStream);
																															goto case 175;
																														case 61:
																															array7 = new object[8];
																															goto case 353;
																														case 412:
																															array6 = new long[7];
																															goto case 61;
																														case 253:
																															array5 = new int[7];
																															goto case 412;
																														case 93:
																															array4 = new int[7];
																															goto case 253;
																														case 265:
																															array3 = new object[7];
																															goto case 93;
																														case 352:
																															array2 = new byte[7];
																															goto case 265;
																														case 12:
																															num4 = num2 * 8;
																															goto case 352;
																														case 41:
																															num3 = num2 * 4;
																															goto case 12;
																														case 169:
																															num2 = 1;
																															goto case 41;
																														case 170:
																															goto end_IL_09f1;
																														case 43:
																														case 57:
																															goto IL_2181_2;
																														}
																														continue;
																													}
																													goto IL_12da_2;
																													IL_1301_2:
																													num6++;
																													goto IL_130f_2;
																													IL_130f_2:
																													ptr2 += 16;
																													goto IL_20be_2;
																													IL_12da_2:
																													*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																													goto IL_12f3_2;
																													IL_12f3_2:
																													array2[num6] = 3;
																													goto IL_1301_2;
																													continue;
																													end_IL_0735_2:
																													break;
																												}
																												goto IL_0c54_2;
																												continue;
																												end_IL_0748_2:
																												break;
																												IL_0748_2:;
																											}
																											break;
																											IL_075b_2:;
																										}
																										break;
																									}
																									goto IL_0845_2;
																									IL_0948_2:
																									ptr2 += 8;
																									goto IL_20be_2;
																									IL_0845_2:
																									if (25 > b)
																									{
																										goto IL_088c_2;
																									}
																									goto IL_095b_2;
																									IL_095b_2:
																									array2[num6 - 2] = 0;
																									goto IL_096f_2;
																									IL_096f_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																									goto IL_09c1_2;
																									IL_09c1_2:
																									num6--;
																									goto IL_0a90_2;
																									IL_0a90_2:
																									ptr2 += 8;
																									goto IL_20be_2;
																									IL_088c_2:
																									if (24 < b)
																									{
																										break;
																									}
																									goto IL_089a_2;
																									IL_089a_2:
																									if (24 > b)
																									{
																										break;
																									}
																									goto IL_090e_2;
																									IL_090e_2:
																									array2[num6] = 5;
																									goto IL_091c_2;
																									IL_091c_2:
																									array3[num6] = ((delegate*<string>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
																									goto IL_093a_2;
																									IL_093a_2:
																									num6++;
																									goto IL_0948_2;
																								}
																								break;
																							}
																							goto IL_1322_2;
																							IL_143d_2:
																							num6--;
																							goto IL_20be_2;
																							IL_1322_2:
																							if (23 <= b)
																							{
																								goto IL_132d_2;
																							}
																							goto IL_1392_2;
																							IL_132d_2:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_137f_2;
																							IL_137f_2:
																							num6--;
																							goto IL_20be_2;
																							IL_1392_2:
																							if (21 >= b)
																							{
																								goto IL_139d_2;
																							}
																							goto IL_13c3_2;
																							IL_139d_2:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_13ab_2;
																							IL_13ab_2:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_20be_2;
																							IL_13c3_2:
																							if (22 < b)
																							{
																								break;
																							}
																							goto IL_13d1_2;
																							IL_13d1_2:
																							if (22 > b)
																							{
																								break;
																							}
																							goto IL_13df_2;
																							IL_13df_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							num = 227;
																							goto IL_1429_2;
																							IL_1429_2:
																							array2[num6 - 2] = 0;
																							goto IL_143d_2;
																						}
																						break;
																					}
																					goto IL_087c_2;
																					IL_08fb_2:
																					ptr2 += 16;
																					goto IL_20be_2;
																					IL_087c_2:
																					if (20 <= b)
																					{
																						goto IL_08bd_2;
																					}
																					goto IL_0edd_2;
																					IL_0edd_2:
																					if (16 >= b)
																					{
																						goto IL_0eeb_2;
																					}
																					goto IL_1003_2;
																					IL_0eeb_2:
																					if (16 <= b)
																					{
																						goto IL_0ef9_2;
																					}
																					goto IL_0f7e_2;
																					IL_0ef9_2:
																					array2[num6] = array2[num6 - 1];
																					goto IL_0f11_2;
																					IL_0f11_2:
																					array4[num6 - 0] = array4[num6 - 1];
																					goto IL_0f2f_2;
																					IL_0f2f_2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0f53_2;
																					IL_0f53_2:
																					array3[num6] = array3[num6 - 1];
																					goto IL_0f6b_2;
																					IL_0f6b_2:
																					num6++;
																					goto IL_20be_2;
																					IL_0f7e_2:
																					if (14 >= b)
																					{
																						goto IL_0f89_2;
																					}
																					goto IL_0f9c_2;
																					IL_0f89_2:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_1106_2;
																					IL_1106_2:
																					array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																					goto IL_1124_2;
																					IL_1124_2:
																					ptr2 += 8;
																					goto IL_1132_2;
																					IL_1132_2:
																					num6--;
																					goto IL_20be_2;
																					IL_0f9c_2:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_0faa_2;
																					IL_0faa_2:
																					if (15 > b)
																					{
																						break;
																					}
																					goto IL_0fb8_2;
																					IL_0fb8_2:
																					array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					num = 62;
																					goto IL_0fea_2;
																					IL_0fea_2:
																					array2[num6 - 1] = 5;
																					goto IL_20be_2;
																					IL_1003_2:
																					if (18 >= b)
																					{
																						goto IL_100e_2;
																					}
																					goto IL_108b_2;
																					IL_100e_2:
																					if (18 <= b)
																					{
																						goto IL_1019_2;
																					}
																					goto IL_106a_2;
																					IL_1019_2:
																					((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																					goto IL_1057_2;
																					IL_1057_2:
																					num6 -= 3;
																					goto IL_20be_2;
																					IL_106a_2:
																					if (17 < b)
																					{
																						break;
																					}
																					goto IL_1078_2;
																					IL_1078_2:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_1272_2;
																					IL_1272_2:
																					array2[num6] = 5;
																					goto IL_1280_2;
																					IL_1280_2:
																					array3[num6] = array7[*(int*)(ptr2 + num3)];
																					goto IL_1298_2;
																					IL_1298_2:
																					num6++;
																					goto IL_12a6_2;
																					IL_12a6_2:
																					ptr2 += 8;
																					goto IL_20be_2;
																					IL_108b_2:
																					if (19 < b)
																					{
																						break;
																					}
																					goto IL_1099_2;
																					IL_1099_2:
																					if (19 > b)
																					{
																						break;
																					}
																					goto IL_10a7_2;
																					IL_10a7_2:
																					array2[num6 - 1] = 5;
																					goto IL_10bb_2;
																					IL_10bb_2:
																					array3[num6 - 1] = ((delegate*<string[], string>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																					goto IL_10f3_2;
																					IL_10f3_2:
																					ptr2 += 8;
																					goto IL_20be_2;
																					IL_08bd_2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																					goto IL_08d6_2;
																					IL_08d6_2:
																					array2[num6] = 1;
																					goto IL_08e4_2;
																					IL_08e4_2:
																					num6++;
																					num = 311;
																					goto IL_08fb_2;
																				}
																				break;
																			}
																			goto IL_08aa_2;
																			IL_0e26_2:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0e34_2;
																			IL_08aa_2:
																			if (13 <= b)
																			{
																				goto end_IL_07f8;
																			}
																			goto IL_0aa3_2;
																			IL_0aa3_2:
																			if (6 >= b)
																			{
																				goto IL_0ab1_2;
																			}
																			goto IL_0bd4_2;
																			IL_0ab1_2:
																			if (6 <= b)
																			{
																				goto IL_0abc_2;
																			}
																			goto IL_0b2c_2;
																			IL_0abc_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			num = 214;
																			goto IL_0b05_2;
																			IL_0b05_2:
																			array2[num6 - 2] = 0;
																			goto IL_0b19_2;
																			IL_0b19_2:
																			num6--;
																			goto IL_20be_2;
																			IL_0b2c_2:
																			if (3 >= b)
																			{
																				goto IL_0b3a_2;
																			}
																			goto IL_1145_2;
																			IL_0b3a_2:
																			if (3 <= b)
																			{
																				goto IL_0b45_2;
																			}
																			goto IL_0b73_2;
																			IL_0b45_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0ea9_2;
																			IL_0ea9_2:
																			ptr2 += 8;
																			goto IL_0eb7_2;
																			IL_0eb7_2:
																			num6--;
																			goto IL_20be_2;
																			IL_0b73_2:
																			if (1 >= b)
																			{
																				num = 141;
																				goto IL_0b87_2;
																			}
																			goto IL_0bb3_2;
																			IL_0e34_2:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0e96_2;
																			IL_0b87_2:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0b95_2;
																			IL_0b95_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0d94_2;
																			IL_0d94_2:
																			array2[num6] = 0;
																			goto IL_12b9_2;
																			IL_12b9_2:
																			num6++;
																			goto IL_12c7_2;
																			IL_12c7_2:
																			ptr2 += 8;
																			goto IL_20be_2;
																			IL_0bb3_2:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0bc1_2;
																			IL_0bc1_2:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0d2d_2;
																			IL_0d2d_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0d6d_2;
																			IL_0d6d_2:
																			array2[num6 - 2] = 0;
																			goto IL_0d81_2;
																			IL_0d81_2:
																			num6--;
																			goto IL_20be_2;
																			IL_1145_2:
																			if (4 >= b)
																			{
																				goto IL_1150_2;
																			}
																			goto IL_11c3_2;
																			IL_1150_2:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_115e_2;
																			IL_115e_2:
																			array2[num6] = 0;
																			goto IL_116c_2;
																			IL_116c_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_118f_2;
																			IL_118f_2:
																			array3[num6] = null;
																			num = 173;
																			goto IL_11a2_2;
																			IL_11a2_2:
																			num6++;
																			goto IL_11b0_2;
																			IL_11b0_2:
																			ptr2 += 8;
																			goto IL_20be_2;
																			IL_11c3_2:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_11d1_2;
																			IL_11d1_2:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_11df_2;
																			IL_11df_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_121f_2;
																			IL_121f_2:
																			array2[num6 - 2] = 0;
																			goto IL_125f_2;
																			IL_125f_2:
																			num6--;
																			goto IL_20be_2;
																			IL_0bd4_2:
																			if (9 >= b)
																			{
																				goto IL_0be2_2;
																			}
																			goto IL_0cf5_2;
																			IL_0be2_2:
																			if (9 <= b)
																			{
																				goto IL_0bed_2;
																			}
																			goto IL_0c54_2;
																			IL_0bed_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0c2d_2;
																			IL_0c2d_2:
																			array2[num6 - 2] = 0;
																			goto IL_0c41_2;
																			IL_0c41_2:
																			num6--;
																			goto IL_20be_2;
																			IL_0c54_2:
																			if (7 >= b)
																			{
																				goto IL_0c5f_2;
																			}
																			goto IL_0cc6_2;
																			IL_0c5f_2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0c6d_2;
																			IL_0c6d_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0cad_2;
																			IL_0cad_2:
																			array2[num6 - 2] = 0;
																			goto IL_0eca_2;
																			IL_0eca_2:
																			num6--;
																			goto IL_20be_2;
																			IL_0cc6_2:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0cd4_2;
																			IL_0cd4_2:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0ce2_2;
																			IL_0ce2_2:
																			num6--;
																			goto IL_20be_2;
																			IL_0cf5_2:
																			if (11 < b)
																			{
																				goto IL_0d03_2;
																			}
																			goto IL_0da7_2;
																			IL_0d03_2:
																			if (12 < b)
																			{
																				break;
																			}
																			num = 380;
																			goto IL_0d1a_2;
																			IL_0e96_2:
																			num6 -= 2;
																			goto IL_20be_2;
																			IL_0d1a_2:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_20be_2;
																			IL_0da7_2:
																			if (11 <= b)
																			{
																				goto IL_0db2_2;
																			}
																			goto IL_0e18_2;
																			IL_0db2_2:
																			array2[num6 - 1] = 0;
																			goto IL_0dc6_2;
																			IL_0dc6_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																			goto IL_0e05_2;
																			IL_0e05_2:
																			ptr2 += 8;
																			goto IL_20be_2;
																			IL_0e18_2:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0e26_2;
																		}
																		break;
																	}
																	goto IL_0803_2;
																	IL_0869_2:
																	num6--;
																	goto IL_20be_2;
																	IL_0803_2:
																	*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_0855_2;
																	IL_0855_2:
																	array2[num6 - 2] = 3;
																	goto IL_0869_2;
																}
																break;
															}
															goto IL_1450_2;
															IL_1fec_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_202b_2;
															IL_1450_2:
															if (41 < b)
															{
																goto IL_145e_2;
															}
															goto IL_19ef_2;
															IL_145e_2:
															if (48 >= b)
															{
																goto IL_146c_2;
															}
															goto IL_1759_2;
															IL_146c_2:
															if (48 > b)
															{
																goto IL_147a_2;
															}
															goto IL_1715_2;
															IL_147a_2:
															if (44 >= b)
															{
																goto IL_1488_2;
															}
															goto IL_15d8_2;
															IL_1488_2:
															if (44 > b)
															{
																goto IL_1496_2;
															}
															goto IL_15a3_2;
															IL_1496_2:
															if (42 < b)
															{
																goto IL_14a4_2;
															}
															goto IL_152f_2;
															IL_14a4_2:
															if (43 < b)
															{
																break;
															}
															goto IL_14b2_2;
															IL_14b2_2:
															if (43 > b)
															{
																break;
															}
															goto IL_14c0_2;
															IL_14c0_2:
															array2[num6 - 1] = 3;
															goto IL_14d4_2;
															IL_14d4_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1513_2;
															IL_1513_2:
															ptr2 += 8;
															num = 68;
															goto IL_20be_2;
															IL_152f_2:
															if (42 > b)
															{
																break;
															}
															goto IL_153d_2;
															IL_153d_2:
															array2[num6 - 1] = 3;
															goto IL_1551_2;
															IL_1551_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1590_2;
															IL_1590_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_15a3_2:
															global::_003CModule_003E.color_13 = (Color[])array3[num6 - 1];
															goto IL_15bc_2;
															IL_15bc_2:
															num6--;
															num = 90;
															goto IL_20be_2;
															IL_15d8_2:
															if (46 >= b)
															{
																goto IL_15e6_2;
															}
															goto IL_16ad_2;
															IL_15e6_2:
															if (46 <= b)
															{
																goto IL_15f1_2;
															}
															goto IL_163e_2;
															IL_15f1_2:
															array3[num6] = ((delegate*<Color[]>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
															goto IL_160f_2;
															IL_160f_2:
															array2[num6] = 5;
															goto IL_161d_2;
															IL_161d_2:
															num6++;
															goto IL_162b_2;
															IL_162b_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_163e_2:
															if (45 < b)
															{
																break;
															}
															goto IL_164c_2;
															IL_164c_2:
															if (45 > b)
															{
																break;
															}
															goto IL_165a_2;
															IL_165a_2:
															array2[num6] = 0;
															goto IL_1668_2;
															IL_1668_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
															goto IL_168c_2;
															IL_168c_2:
															num6++;
															goto IL_169a_2;
															IL_169a_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_16ad_2:
															if (47 < b)
															{
																break;
															}
															goto IL_16bb_2;
															IL_16bb_2:
															if (47 > b)
															{
																break;
															}
															num = 158;
															goto IL_16d2_2;
															IL_202b_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_16d2_2:
															*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((Color[])array3[num6 - 1]).LongLength;
															goto IL_16fc_2;
															IL_16fc_2:
															array2[num6 - 1] = 2;
															goto IL_20be_2;
															IL_1715_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1740_2;
															IL_1740_2:
															array2[num6 - 1] = 0;
															goto IL_20be_2;
															IL_1759_2:
															if (51 >= b)
															{
																goto IL_1767_2;
															}
															goto IL_18e2_2;
															IL_1767_2:
															if (51 <= b)
															{
																goto IL_1772_2;
															}
															goto IL_179f_2;
															IL_1772_2:
															global::_003CModule_003E.int_211 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_178c_2;
															IL_178c_2:
															num6--;
															goto IL_20be_2;
															IL_179f_2:
															if (49 >= b)
															{
																goto IL_17aa_2;
															}
															goto IL_1828_2;
															IL_17aa_2:
															if (49 > b)
															{
																break;
															}
															goto IL_17b8_2;
															IL_17b8_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_17f8_2;
															IL_17f8_2:
															array2[num6 - 2] = 0;
															num = 354;
															goto IL_1815_2;
															IL_1815_2:
															num6--;
															goto IL_20be_2;
															IL_1828_2:
															if (50 < b)
															{
																break;
															}
															goto IL_1836_2;
															IL_1836_2:
															if (50 > b)
															{
																break;
															}
															goto IL_1844_2;
															IL_1844_2:
															array2[num6 - 3] = 0;
															goto IL_1858_2;
															IL_1858_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]) = ((delegate*<int, int, int, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_18c1_2;
															IL_18c1_2:
															num6 -= 2;
															goto IL_18cf_2;
															IL_18cf_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_18e2_2:
															if (53 >= b)
															{
																goto IL_18f0_2;
															}
															goto IL_19ce_2;
															IL_18f0_2:
															if (53 > b)
															{
																goto IL_18fb_2;
															}
															goto IL_196a_2;
															IL_18fb_2:
															if (52 < b)
															{
																break;
															}
															goto IL_1909_2;
															IL_1909_2:
															if (52 > b)
															{
																break;
															}
															goto IL_1917_2;
															IL_1917_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
															goto IL_193b_2;
															IL_193b_2:
															array2[num6] = 0;
															goto IL_1949_2;
															IL_1949_2:
															num6++;
															goto IL_1957_2;
															IL_1957_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_196a_2:
															array3[num6 - 2] = ((Color[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_19a7_2;
															IL_19a7_2:
															array2[num6 - 2] = 4;
															goto IL_19bb_2;
															IL_19bb_2:
															num6--;
															goto IL_20be_2;
															IL_19ce_2:
															if (54 < b)
															{
																break;
															}
															goto IL_19dc_2;
															IL_19dc_2:
															if (54 > b)
															{
															}
															break;
															IL_19ef_2:
															if (41 > b)
															{
																goto IL_19fd_2;
															}
															goto IL_203e_2;
															IL_19fd_2:
															if (34 >= b)
															{
																goto IL_1a0b_2;
															}
															goto IL_1cf9_2;
															IL_1a0b_2:
															if (34 <= b)
															{
																goto IL_1a16_2;
															}
															goto IL_1a5f_2;
															IL_1a16_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
															goto IL_1a30_2;
															IL_1a30_2:
															array2[num6] = 3;
															goto IL_1a3e_2;
															IL_1a3e_2:
															num6++;
															goto IL_1a4c_2;
															IL_1a4c_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_1a5f_2:
															if (30 >= b)
															{
																goto IL_1a6d_2;
															}
															goto IL_1b8d_2;
															IL_1a6d_2:
															if (30 > b)
															{
																goto IL_1a7b_2;
															}
															goto IL_1b71_2;
															IL_1a7b_2:
															if (28 >= b)
															{
																goto IL_1a86_2;
															}
															goto IL_1afa_2;
															IL_1a86_2:
															if (28 > b)
															{
																break;
															}
															goto IL_1a94_2;
															IL_1a94_2:
															array2[num6 - 1] = 0;
															goto IL_1aa8_2;
															IL_1aa8_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1ae7_2;
															IL_1ae7_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_1afa_2:
															if (29 < b)
															{
																break;
															}
															num = 294;
															goto IL_1b11_2;
															IL_203e_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_207e_2;
															IL_1b11_2:
															if (29 > b)
															{
																break;
															}
															goto IL_1b1f_2;
															IL_1b1f_2:
															array2[num6] = 4;
															goto IL_1b2d_2;
															IL_1b2d_2:
															array3[num6] = ((delegate*<Color>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])();
															goto IL_1b50_2;
															IL_1b50_2:
															num6++;
															goto IL_1b5e_2;
															IL_1b5e_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_1b71_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															goto IL_20be_2;
															IL_1b8d_2:
															if (32 >= b)
															{
																goto IL_1b9b_2;
															}
															goto IL_1c9b_2;
															IL_1b9b_2:
															if (32 > b)
															{
																goto IL_1ba9_2;
															}
															goto IL_1c2b_2;
															IL_1ba9_2:
															if (31 < b)
															{
																break;
															}
															goto IL_1bb7_2;
															IL_1bb7_2:
															if (31 > b)
															{
																break;
															}
															goto IL_1bc5_2;
															IL_1bc5_2:
															array2[num6 - 1] = 3;
															goto IL_1bd9_2;
															IL_1bd9_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1c18_2;
															IL_1c18_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_1c2b_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1c6b_2;
															IL_1c6b_2:
															array2[num6 - 2] = 3;
															goto IL_1c7f_2;
															IL_1c7f_2:
															num6--;
															num = 115;
															goto IL_20be_2;
															IL_1c9b_2:
															if (33 < b)
															{
																break;
															}
															goto IL_1ca9_2;
															IL_1ca9_2:
															if (33 > b)
															{
																break;
															}
															goto IL_1cb7_2;
															IL_1cb7_2:
															array3[num6 - 1] = new Color[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
															goto IL_1ce0_2;
															IL_1ce0_2:
															array2[num6 - 1] = 5;
															goto IL_20be_2;
															IL_1cf9_2:
															if (37 >= b)
															{
																goto IL_1d07_2;
															}
															goto IL_1ed3_2;
															IL_1d07_2:
															if (37 <= b)
															{
																goto IL_1d12_2;
															}
															goto IL_1d81_2;
															IL_1d12_2:
															array2[num6 - 1] = 0;
															num = 413;
															goto IL_1d2f_2;
															IL_1d2f_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_1d6e_2;
															IL_1d6e_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_1d81_2:
															if (35 < b)
															{
																goto IL_1d8c_2;
															}
															goto IL_1dfd_2;
															IL_1d8c_2:
															if (36 < b)
															{
																break;
															}
															goto IL_1d9a_2;
															IL_1d9a_2:
															if (36 > b)
															{
																break;
															}
															goto IL_1da8_2;
															IL_1da8_2:
															((Color[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (Color)array3[num6 - 1];
															goto IL_1dea_2;
															IL_1dea_2:
															num6 -= 3;
															goto IL_20be_2;
															IL_1dfd_2:
															if (35 > b)
															{
																break;
															}
															num = 340;
															goto IL_1e14_2;
															IL_207e_2:
															array2[num6 - 2] = 3;
															num = 319;
															goto IL_209b_2;
															IL_1e14_2:
															array2[num6 - 4] = 5;
															num = 366;
															goto IL_1e31_2;
															IL_1e31_2:
															array3[num6 - 4] = ((delegate*<float, float, float, float, object>)StaticIndexRangePartitionerEnumEqualityComparer[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])));
															goto IL_1ea9_2;
															IL_1ea9_2:
															num6 -= 3;
															num = 215;
															goto IL_1ec0_2;
															IL_1ec0_2:
															ptr2 += 8;
															goto IL_20be_2;
															IL_1ed3_2:
															if (39 >= b)
															{
																goto IL_1ee1_2;
															}
															goto IL_1fbc_2;
															IL_1ee1_2:
															if (39 <= b)
															{
																goto IL_1eec_2;
															}
															goto IL_1f30_2;
															IL_1eec_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1f17_2;
															IL_1f17_2:
															array2[num6 - 1] = 0;
															goto IL_20be_2;
															IL_1f30_2:
															if (38 < b)
															{
																break;
															}
															num = 237;
															goto IL_1f47_2;
															IL_209b_2:
															num6--;
															goto IL_20be_2;
															IL_1f47_2:
															if (38 > b)
															{
																break;
															}
															goto IL_1f55_2;
															IL_1f55_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_1f95_2;
															IL_1f95_2:
															array2[num6 - 2] = 3;
															goto IL_1fa9_2;
															IL_1fa9_2:
															num6--;
															goto IL_20be_2;
															IL_1fbc_2:
															if (40 < b)
															{
																break;
															}
															goto IL_1fca_2;
															IL_1fca_2:
															if (40 > b)
															{
																break;
															}
															goto IL_1fd8_2;
															IL_1fd8_2:
															array2[num6 - 1] = 3;
															goto IL_1fec_2;
														}
														break;
														IL_07c8_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_20be_2;
												continue;
												end_IL_07d8_2:
												break;
											}
											continue;
											end_IL_07e8:
											break;
										}
										continue;
										end_IL_07f8:
										break;
									}
									break;
								}
								goto IL_2181_2;
								IL_2181_2:
								return (Color)array3[num6 - 1];
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_09e3_2;
					}
					continue;
					end_IL_09f1:
					break;
				}
				break;
			}
		}
	}

	private static double ReferenceCountValueCryptoKeyRights(double double_1)
	{
		return Math.Round(double_1);
	}

	private unsafe void Update()
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					num3 = 0;
					num = 14;
					while (true)
					{
						if (num != 14)
						{
							if (num != 995)
							{
								return;
							}
							switch (num)
							{
							case 3:
								goto end_IL_0041;
							case 0:
								goto end_IL_004e;
							case 1:
								goto end_IL_005c;
							case 2:
								goto IL_0066;
							case 7:
								goto IL_0088;
							case 5:
								goto IL_008e;
							case 4:
							case 6:
								return;
							}
							continue;
						}
						goto IL_0088;
						IL_008e:
						num3 = 0;
						return;
						IL_0066:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, Class179, void>)TBStrIsReEntrant[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref num11, this);
						goto IL_0088;
						IL_0088:
						if (num3 != 57)
						{
							goto IL_0066;
						}
						goto IL_008e;
						continue;
						end_IL_0041:
						break;
					}
					continue;
					end_IL_004e:
					break;
				}
				continue;
				end_IL_005c:
				break;
			}
		}
	}

	private static double SetCurrentDirectoryStringSplitOptions(double double_1)
	{
		return Math.Tan(double_1);
	}

	private static void MetadataSectionHashAlgorithmHasDefault(Behaviour behaviour_0, bool bool_5)
	{
		behaviour_0.enabled = bool_5;
	}

	private static void NeedToRevertBinaryParser(Class179 class179_2)
	{
		class179_2.method_1();
	}

	private static bool IsValidTargetTypeEuropeanNumberSeparator(Class179 class179_2)
	{
		return class179_2.bool_1;
	}

	private unsafe static int smethod_3(int int_1, int int_2)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 84;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ExitIMethodCallMessage.StartDocumentsetRefusedSet);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0205:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01e5:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01d5:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01c8:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01b8:
																										if (2 > b)
																										{
																											while (true)
																											{
																												IL_01a8:
																												if (1 < b)
																												{
																													num = 94;
																													while (num != 94)
																													{
																														if (num != 1075)
																														{
																															goto IL_0251;
																														}
																														switch (num)
																														{
																														case 69:
																															goto IL_01a8;
																														case 51:
																															goto IL_01b8;
																														case 17:
																														case 79:
																															goto IL_01c8;
																														case 34:
																															goto IL_01d5;
																														case 81:
																															goto IL_01e5;
																														case 74:
																															goto IL_01f5;
																														case 29:
																															goto IL_0205;
																														case 30:
																															goto end_IL_0205;
																														case 16:
																														case 54:
																															goto end_IL_0215;
																														case 68:
																															goto IL_0230;
																														case 53:
																														case 76:
																															goto IL_0243;
																														case 82:
																															goto IL_0251;
																														case 22:
																														case 85:
																															goto IL_025f;
																														case 40:
																															goto IL_029f;
																														case 66:
																															goto IL_02b3;
																														case 9:
																														case 24:
																															goto IL_02d8;
																														case 62:
																															goto IL_0346;
																														case 27:
																														case 58:
																															goto IL_0362;
																														case 78:
																															goto IL_038b;
																														case 52:
																															goto IL_0399;
																														case 8:
																															goto IL_03ac;
																														case 0:
																														case 36:
																															goto IL_03ba;
																														case 59:
																															goto IL_03c5;
																														case 15:
																														case 23:
																															goto IL_03d3;
																														case 6:
																															goto IL_03e1;
																														case 86:
																															goto IL_0404;
																														case 57:
																															goto IL_040e;
																														case 71:
																															goto IL_041c;
																														case 61:
																															goto IL_042f;
																														case 14:
																															goto IL_043a;
																														case 35:
																														case 65:
																															goto IL_044e;
																														case 80:
																															goto IL_046a;
																														case 41:
																														case 72:
																															goto IL_0478;
																														case 50:
																															goto IL_0483;
																														case 3:
																														case 87:
																															goto IL_048e;
																														case 5:
																														case 13:
																														case 18:
																														case 26:
																														case 28:
																														case 33:
																														case 42:
																														case 44:
																														case 45:
																														case 49:
																														case 55:
																														case 63:
																														case 75:
																														case 77:
																															goto end_IL_0195;
																														case 25:
																															goto IL_04cf;
																														case 48:
																															goto IL_04dd;
																														case 1:
																															goto IL_04eb;
																														case 2:
																														case 11:
																														case 20:
																														case 21:
																														case 31:
																														case 32:
																														case 37:
																														case 46:
																														case 70:
																														case 73:
																														case 83:
																															goto end_IL_0225;
																														case 10:
																															goto end_IL_04f9;
																														case 56:
																															goto end_IL_050c;
																														case 64:
																															goto end_IL_0516;
																														case 12:
																															goto end_IL_0521;
																														case 47:
																															goto end_IL_0536;
																														case 19:
																														case 60:
																															goto end_IL_054b;
																														case 84:
																															goto end_IL_055b;
																														case 4:
																														case 43:
																															goto end_IL_056b;
																														case 38:
																															goto end_IL_057b;
																														case 39:
																															goto end_IL_0594;
																														case 7:
																														case 67:
																															goto IL_05af;
																														}
																														continue;
																														end_IL_0195:
																														break;
																													}
																													break;
																												}
																												goto IL_0230;
																												IL_0230:
																												if (1 <= b)
																												{
																												}
																												break;
																											}
																											break;
																										}
																										num = 24;
																										goto IL_02d8;
																										IL_02d8:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0346;
																										IL_0346:
																										num5 -= 2;
																										num = 37;
																										goto end_IL_0225;
																									}
																									break;
																								}
																								goto IL_0243;
																								IL_02b3:
																								num5--;
																								num = 70;
																								goto end_IL_0225;
																								IL_0243:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_0251;
																								IL_0251:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_025f;
																								IL_025f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_029f;
																								IL_029f:
																								array[num5 - 2] = 0;
																								goto IL_02b3;
																							}
																							break;
																						}
																						goto IL_0362;
																						IL_0399:
																						num5--;
																						goto end_IL_0225;
																						IL_0362:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_038b;
																						IL_038b:
																						ptr2 += 8;
																						goto IL_0399;
																					}
																					break;
																				}
																				goto IL_03ac;
																				IL_0483:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_048e;
																				IL_03ac:
																				if (6 < b)
																				{
																					goto IL_03ba;
																				}
																				goto IL_046a;
																				IL_03ba:
																				if (7 >= b)
																				{
																					goto IL_03c5;
																				}
																				goto IL_042f;
																				IL_03c5:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_03d3;
																				IL_03d3:
																				array[num5] = 0;
																				goto IL_03e1;
																				IL_03e1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0404;
																				IL_0404:
																				array2[num5] = null;
																				goto IL_040e;
																				IL_040e:
																				num5++;
																				goto IL_041c;
																				IL_041c:
																				ptr2 += 8;
																				goto end_IL_0225;
																				IL_042f:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_043a;
																				IL_043a:
																				if (8 > b)
																				{
																					break;
																				}
																				num = 65;
																				goto IL_044e;
																				IL_048e:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 46;
																				goto end_IL_0225;
																				IL_044e:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0225;
																				IL_046a:
																				if (6 <= b)
																				{
																					goto end_IL_0225;
																				}
																				goto IL_0478;
																				IL_0478:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0483;
																			}
																			break;
																			IL_01f5:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04cf;
																	IL_04eb:
																	ptr2 += 8;
																	goto end_IL_0225;
																	IL_04dd:
																	num5++;
																	goto IL_04eb;
																	IL_04cf:
																	array[num5] = 0;
																	goto IL_04dd;
																	continue;
																	end_IL_0205:
																	break;
																}
																continue;
																end_IL_0215:
																break;
															}
															continue;
															end_IL_0225:
															break;
														}
														continue;
													}
													goto IL_05af;
													IL_05af:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f9:
													break;
												}
												continue;
												end_IL_050c:
												break;
											}
											continue;
											end_IL_0516:
											break;
										}
										continue;
										end_IL_0521:
										break;
									}
									continue;
									end_IL_0536:
									break;
								}
								continue;
								end_IL_054b:
								break;
							}
							continue;
							end_IL_055b:
							break;
						}
						continue;
						end_IL_056b:
						break;
					}
					continue;
					end_IL_057b:
					break;
				}
				continue;
				end_IL_0594:
				break;
			}
		}
	}

	private static bool IClientChannelSinkStackgetCopyright(Class179 class179_2)
	{
		return class179_2.bool_3;
	}

	private static bool BlockSizegetKeyPassword()
	{
		return Class184.InvisActive;
	}

	private static VRRig getPercentGroupSizesTRACEGUIDINFO(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.offlineVRRig;
	}

	public Class179()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 39;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref POLICYSERVERADMINServerSecurity.GetSddlFormsetCursorSize);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0279:
														byte b = *ptr2;
														while (true)
														{
															IL_0269:
															ptr2++;
															while (true)
															{
																IL_0259:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_023c:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_022c:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_021f:
																							if (10 >= b)
																							{
																								while (10 <= b)
																								{
																									num = 119;
																									while (true)
																									{
																										if (num != 119)
																										{
																											if (num != 1100)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 105:
																												goto IL_020c;
																											case 32:
																											case 46:
																												goto IL_021f;
																											case 1:
																												goto IL_022c;
																											case 35:
																												goto IL_023c;
																											case 20:
																												goto IL_0249;
																											case 52:
																												goto IL_0259;
																											case 91:
																												goto IL_0269;
																											case 55:
																											case 90:
																												goto IL_0279;
																											case 2:
																											case 49:
																												goto IL_028d;
																											case 8:
																												goto IL_02a4;
																											case 66:
																												goto IL_02b7;
																											case 5:
																											case 73:
																												goto IL_02c5;
																											case 13:
																												goto IL_02d0;
																											case 42:
																											case 51:
																												goto IL_02de;
																											case 100:
																												goto IL_02f6;
																											case 15:
																											case 75:
																												goto IL_0304;
																											case 54:
																												goto IL_0312;
																											case 41:
																											case 98:
																												goto IL_0320;
																											case 86:
																												goto IL_032e;
																											case 23:
																												goto IL_0351;
																											case 27:
																												goto IL_0364;
																											case 53:
																												goto IL_0372;
																											case 96:
																												goto IL_0385;
																											case 79:
																											case 104:
																												goto IL_0398;
																											case 16:
																												goto IL_03d8;
																											case 72:
																												goto IL_03ec;
																											case 43:
																											case 110:
																												goto IL_03ff;
																											case 0:
																											case 37:
																												goto IL_040a;
																											case 21:
																												goto IL_0418;
																											case 70:
																											case 84:
																												goto IL_0426;
																											case 36:
																												goto IL_044f;
																											case 92:
																												goto IL_045d;
																											case 93:
																												goto IL_0470;
																											case 14:
																											case 50:
																												goto IL_047e;
																											case 47:
																												goto IL_0497;
																											case 4:
																												goto IL_04a5;
																											case 77:
																												goto IL_04b3;
																											case 33:
																												goto IL_04c6;
																											case 76:
																												goto IL_04e2;
																											case 40:
																											case 56:
																												goto IL_04f0;
																											case 34:
																												goto IL_04fb;
																											case 107:
																											case 111:
																												goto IL_0509;
																											case 99:
																												goto IL_0552;
																											case 94:
																												goto IL_0566;
																											case 57:
																												goto IL_0579;
																											case 25:
																												goto IL_0587;
																											case 29:
																											case 80:
																												goto IL_0595;
																											case 103:
																												goto IL_05b8;
																											case 101:
																												goto IL_05c6;
																											case 45:
																												goto IL_05d4;
																											case 69:
																											case 81:
																												goto IL_05f0;
																											case 3:
																												goto IL_0652;
																											case 6:
																											case 9:
																											case 11:
																											case 18:
																											case 26:
																											case 30:
																											case 44:
																											case 61:
																											case 64:
																											case 65:
																											case 67:
																											case 74:
																											case 83:
																											case 89:
																											case 97:
																											case 102:
																											case 106:
																											case 108:
																												goto end_IL_020c;
																											case 7:
																											case 10:
																											case 12:
																											case 19:
																											case 24:
																											case 58:
																											case 59:
																											case 68:
																											case 71:
																											case 82:
																											case 85:
																											case 87:
																											case 95:
																											case 109:
																												goto end_IL_01f9;
																											case 62:
																												goto end_IL_0675;
																											case 22:
																												goto end_IL_0688;
																											case 28:
																												goto end_IL_0692;
																											case 48:
																												goto end_IL_069d;
																											case 31:
																											case 63:
																												goto end_IL_06b2;
																											case 78:
																												goto end_IL_06c2;
																											case 17:
																											case 88:
																												goto end_IL_06d2;
																											case 38:
																												goto end_IL_06e2;
																											case 39:
																												goto end_IL_06f2;
																											case 60:
																											case 112:
																												goto IL_070d;
																											}
																											continue;
																										}
																										goto IL_04c6;
																										IL_04c6:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										break;
																										continue;
																										end_IL_01f9:
																										break;
																									}
																									goto end_IL_0259;
																									continue;
																									end_IL_020c:
																									break;
																									IL_020c:;
																								}
																								break;
																							}
																							num = 2;
																							goto IL_028d;
																							IL_028d:
																							if (11 < b)
																							{
																								break;
																							}
																							num = 8;
																							goto IL_02a4;
																							IL_02a4:
																							if (11 <= b)
																							{
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_04e2;
																					IL_0652:
																					num6 -= 2;
																					goto end_IL_0259;
																					IL_04e2:
																					if (9 > b)
																					{
																						goto IL_04f0;
																					}
																					goto IL_05f0;
																					IL_04f0:
																					if (7 >= b)
																					{
																						goto IL_04fb;
																					}
																					goto IL_0579;
																					IL_04fb:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0509;
																					IL_0509:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 99;
																					goto IL_0552;
																					IL_0552:
																					array[num6 - 2] = 0;
																					goto IL_0566;
																					IL_0566:
																					num6--;
																					goto end_IL_0259;
																					IL_0579:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0587;
																					IL_0587:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0595;
																					IL_0595:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05b8;
																					IL_05b8:
																					array[num6] = 0;
																					goto IL_05c6;
																					IL_05c6:
																					num6++;
																					goto IL_05d4;
																					IL_05d4:
																					ptr2 += 8;
																					num = 19;
																					goto end_IL_0259;
																					IL_05f0:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0652;
																				}
																				break;
																			}
																			goto IL_02b7;
																			IL_03ec:
																			num6--;
																			goto end_IL_0259;
																			IL_02b7:
																			if (6 > b)
																			{
																				goto IL_02c5;
																			}
																			goto IL_0398;
																			IL_02c5:
																			if (3 >= b)
																			{
																				goto IL_02d0;
																			}
																			goto IL_02f6;
																			IL_02d0:
																			if (3 <= b)
																			{
																				goto IL_02de;
																			}
																			goto IL_03ff;
																			IL_02de:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0259;
																			IL_03ff:
																			if (1 < b)
																			{
																				goto IL_040a;
																			}
																			goto IL_0470;
																			IL_040a:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0418;
																			IL_0418:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0426;
																			IL_0426:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_044f;
																			IL_044f:
																			ptr2 += 8;
																			goto IL_045d;
																			IL_045d:
																			num6--;
																			goto end_IL_0259;
																			IL_0470:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_047e;
																			IL_047e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0497;
																			IL_0497:
																			array[num6] = 0;
																			goto IL_04a5;
																			IL_04a5:
																			num6++;
																			goto IL_04b3;
																			IL_04b3:
																			ptr2 += 8;
																			goto end_IL_0259;
																			IL_02f6:
																			if (4 < b)
																			{
																				goto IL_0304;
																			}
																			goto IL_0385;
																			IL_0304:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0312;
																			IL_0312:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0320;
																			IL_0320:
																			array[num6] = 0;
																			goto IL_032e;
																			IL_032e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0351;
																			IL_0351:
																			array2[num6] = null;
																			num = 27;
																			goto IL_0364;
																			IL_0364:
																			num6++;
																			goto IL_0372;
																			IL_0372:
																			ptr2 += 8;
																			goto end_IL_0259;
																			IL_0385:
																			if (4 <= b)
																			{
																				goto end_IL_0259;
																			}
																			break;
																			IL_0398:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_03d8;
																			IL_03d8:
																			array[num6 - 2] = 0;
																			goto IL_03ec;
																		}
																		break;
																		IL_0249:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0259:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_070d;
												IL_070d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0675:
												break;
											}
											continue;
											end_IL_0688:
											break;
										}
										continue;
										end_IL_0692:
										break;
									}
									continue;
									end_IL_069d:
									break;
								}
								continue;
								end_IL_06b2:
								break;
							}
							continue;
							end_IL_06c2:
							break;
						}
						continue;
						end_IL_06d2:
						break;
					}
					continue;
					end_IL_06e2:
					break;
				}
				continue;
				end_IL_06f2:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 136;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LoopTimerStaticMethodOnly.setAccessMaskFriendlyName);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_04e0:
																if (b >= 1)
																{
																	while (b <= 27)
																	{
																		while (true)
																		{
																			IL_04c0:
																			if (14 < b)
																			{
																				while (true)
																				{
																					IL_04b0:
																					if (21 < b)
																					{
																						while (true)
																						{
																							IL_04a0:
																							if (24 >= b)
																							{
																								while (true)
																								{
																									IL_0490:
																									if (24 > b)
																									{
																										while (true)
																										{
																											IL_0483:
																											if (22 >= b)
																											{
																												while (22 <= b)
																												{
																													while (true)
																													{
																														IL_045a:
																														array[num5] = 0;
																														num = 270;
																														while (true)
																														{
																															if (num != 270)
																															{
																																if (num != 1251)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 43:
																																case 45:
																																	goto IL_045a;
																																case 256:
																																	goto IL_0473;
																																case 182:
																																case 213:
																																	goto IL_0483;
																																case 98:
																																	goto IL_0490;
																																case 120:
																																case 162:
																																	goto IL_04a0;
																																case 163:
																																	goto IL_04b0;
																																case 134:
																																	goto IL_04c0;
																																case 109:
																																	goto IL_04d0;
																																case 39:
																																	goto IL_04e0;
																																case 242:
																																	goto end_IL_04e0;
																																case 86:
																																case 205:
																																	goto end_IL_04f0;
																																case 157:
																																	goto IL_050b;
																																case 156:
																																	goto IL_0519;
																																case 21:
																																case 224:
																																	goto IL_0527;
																																case 89:
																																	goto IL_058e;
																																case 222:
																																	goto IL_05c5;
																																case 252:
																																	goto IL_05d3;
																																case 0:
																																case 83:
																																	goto IL_05e6;
																																case 243:
																																	goto IL_062d;
																																case 208:
																																	goto IL_063b;
																																case 189:
																																	goto IL_064e;
																																case 55:
																																	goto IL_065c;
																																case 71:
																																case 124:
																																	goto IL_0667;
																																case 19:
																																	goto IL_0675;
																																case 57:
																																case 126:
																																	goto IL_0683;
																																case 215:
																																	goto IL_06ac;
																																case 99:
																																	goto IL_06ba;
																																case 127:
																																case 152:
																																	goto IL_06cd;
																																case 155:
																																	goto IL_06e9;
																																case 61:
																																	goto IL_06f7;
																																case 239:
																																	goto IL_070a;
																																case 88:
																																case 214:
																																	goto IL_0718;
																																case 68:
																																	goto IL_072c;
																																case 241:
																																	goto IL_0779;
																																case 257:
																																	goto IL_0787;
																																case 253:
																																	goto IL_079a;
																																case 96:
																																	goto IL_07a8;
																																case 110:
																																case 142:
																																	goto IL_07b3;
																																case 2:
																																	goto IL_07bd;
																																case 203:
																																	goto IL_07cb;
																																case 84:
																																	goto IL_07de;
																																case 198:
																																case 206:
																																	goto IL_07e9;
																																case 100:
																																	goto IL_07f7;
																																case 132:
																																case 172:
																																	goto IL_0805;
																																case 93:
																																	goto IL_0813;
																																case 197:
																																	goto IL_0831;
																																case 194:
																																	goto IL_083f;
																																case 188:
																																	goto IL_0852;
																																case 53:
																																case 183:
																																	goto IL_0860;
																																case 181:
																																	goto IL_088a;
																																case 17:
																																	goto IL_0898;
																																case 15:
																																	goto IL_08b4;
																																case 38:
																																	goto IL_08c2;
																																case 51:
																																case 176:
																																	goto IL_08d0;
																																case 150:
																																	goto IL_08de;
																																case 34:
																																case 94:
																																	goto IL_08ec;
																																case 118:
																																	goto IL_0900;
																																case 108:
																																	goto IL_094d;
																																case 3:
																																	goto IL_095b;
																																case 144:
																																case 255:
																																	goto IL_096e;
																																case 234:
																																	goto IL_09c0;
																																case 49:
																																	goto end_IL_0447;
																																case 125:
																																	goto IL_09e1;
																																case 117:
																																case 202:
																																	goto IL_09ef;
																																case 159:
																																	goto IL_0a30;
																																case 72:
																																	goto IL_0a44;
																																case 65:
																																	goto IL_0a60;
																																case 23:
																																case 59:
																																	goto IL_0a6b;
																																case 129:
																																	goto IL_0aa2;
																																case 229:
																																	goto IL_0ab5;
																																case 175:
																																	goto IL_0ac3;
																																case 32:
																																case 133:
																																	goto IL_0ace;
																																case 171:
																																	goto IL_0b0e;
																																case 190:
																																	goto IL_0b22;
																																case 75:
																																case 233:
																																	goto IL_0b35;
																																case 169:
																																case 226:
																																	goto IL_0b43;
																																case 105:
																																case 195:
																																	goto IL_0b51;
																																case 216:
																																	goto IL_0b5f;
																																case 50:
																																case 101:
																																	goto IL_0b6d;
																																case 10:
																																	goto IL_0bad;
																																case 219:
																																	goto IL_0bc1;
																																case 31:
																																	goto IL_0bd4;
																																case 33:
																																case 122:
																																	goto IL_0bdf;
																																case 85:
																																	goto IL_0c1f;
																																case 145:
																																	goto IL_0c33;
																																case 217:
																																	goto IL_0c46;
																																case 87:
																																	goto IL_0c54;
																																case 26:
																																case 137:
																																	goto IL_0c62;
																																case 74:
																																	goto IL_0c79;
																																case 102:
																																	goto IL_0ca5;
																																case 174:
																																	goto IL_0caf;
																																case 149:
																																	goto IL_0cbd;
																																case 24:
																																	goto IL_0cd0;
																																case 11:
																																case 258:
																																	goto IL_0cde;
																																case 259:
																																	goto IL_0cec;
																																case 66:
																																	goto IL_0cfa;
																																case 90:
																																case 221:
																																	goto IL_0d08;
																																case 114:
																																	goto IL_0d48;
																																case 56:
																																	goto IL_0d5c;
																																case 20:
																																	goto IL_0d78;
																																case 123:
																																case 223:
																																	goto IL_0d86;
																																case 151:
																																	goto IL_0d9f;
																																case 173:
																																	goto IL_0dad;
																																case 18:
																																	goto IL_0dbb;
																																case 160:
																																case 249:
																																	goto IL_0dce;
																																case 227:
																																	goto IL_0df7;
																																case 1:
																																	goto IL_0e05;
																																case 42:
																																	goto IL_0e18;
																																case 47:
																																case 235:
																																	goto IL_0e26;
																																case 27:
																																case 131:
																																	goto IL_0e31;
																																case 48:
																																	goto IL_0e3f;
																																case 164:
																																case 186:
																																	goto IL_0e4d;
																																case 8:
																																	goto IL_0e65;
																																case 178:
																																	goto IL_0e73;
																																case 12:
																																	goto IL_0e81;
																																case 79:
																																	goto IL_0e9d;
																																case 82:
																																case 200:
																																	goto IL_0eab;
																																case 207:
																																	goto IL_0eb9;
																																case 111:
																																case 263:
																																	goto IL_0ec7;
																																case 238:
																																	goto IL_0edb;
																																case 262:
																																	goto IL_0f2f;
																																case 193:
																																	goto IL_0f3d;
																																case 121:
																																	goto IL_0f5e;
																																case 81:
																																case 165:
																																	goto IL_0f69;
																																case 29:
																																	goto IL_0fcb;
																																case 220:
																																case 250:
																																	goto IL_0fde;
																																case 116:
																																	goto IL_0fe9;
																																case 140:
																																case 210:
																																	goto IL_0ff7;
																																case 70:
																																	goto IL_100a;
																																case 254:
																																	goto IL_1015;
																																case 52:
																																case 54:
																																	goto IL_1020;
																																case 5:
																																	goto IL_1060;
																																case 170:
																																	goto IL_1074;
																																case 9:
																																case 13:
																																case 14:
																																case 16:
																																case 22:
																																case 36:
																																case 41:
																																case 44:
																																case 46:
																																case 60:
																																case 63:
																																case 64:
																																case 69:
																																case 73:
																																case 76:
																																case 77:
																																case 91:
																																case 106:
																																case 107:
																																case 113:
																																case 119:
																																case 128:
																																case 141:
																																case 146:
																																case 147:
																																case 148:
																																case 153:
																																case 154:
																																case 158:
																																case 161:
																																case 166:
																																case 167:
																																case 168:
																																case 177:
																																case 179:
																																case 184:
																																case 185:
																																case 187:
																																case 196:
																																case 199:
																																case 201:
																																case 218:
																																case 231:
																																case 232:
																																case 237:
																																case 244:
																																case 248:
																																case 261:
																																	goto end_IL_0473;
																																case 4:
																																case 6:
																																case 7:
																																case 25:
																																case 28:
																																case 30:
																																case 35:
																																case 40:
																																case 58:
																																case 62:
																																case 67:
																																case 78:
																																case 80:
																																case 95:
																																case 104:
																																case 115:
																																case 138:
																																case 139:
																																case 143:
																																case 204:
																																case 209:
																																case 212:
																																case 230:
																																case 236:
																																case 240:
																																case 245:
																																case 246:
																																case 247:
																																case 251:
																																case 260:
																																	goto end_IL_0500;
																																case 180:
																																	goto end_IL_1097;
																																case 192:
																																	goto end_IL_10aa;
																																case 228:
																																	goto end_IL_10b4;
																																case 130:
																																	goto end_IL_10bf;
																																case 103:
																																	goto end_IL_10cf;
																																case 37:
																																case 97:
																																	goto end_IL_10df;
																																case 191:
																																	goto end_IL_10ef;
																																case 112:
																																case 225:
																																	goto end_IL_10ff;
																																case 135:
																																	goto end_IL_110f;
																																case 136:
																																	goto end_IL_111f;
																																case 92:
																																case 211:
																																	return;
																																}
																																continue;
																															}
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = (((delegate*<bool>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])() ? 1 : 0);
																															goto IL_05c5;
																															IL_05c5:
																															num5++;
																															goto IL_05d3;
																															IL_05d3:
																															ptr2 += 8;
																															goto end_IL_0500;
																															continue;
																															end_IL_0447:
																															break;
																														}
																														break;
																													}
																													goto IL_09d3;
																													continue;
																													end_IL_0473:
																													break;
																													IL_0473:;
																												}
																												break;
																											}
																											goto IL_050b;
																											IL_058e:
																											num5--;
																											goto end_IL_0500;
																											IL_050b:
																											if (23 < b)
																											{
																												break;
																											}
																											goto IL_0519;
																											IL_0519:
																											if (23 > b)
																											{
																												break;
																											}
																											goto IL_0527;
																											IL_0527:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											num = 89;
																											goto IL_058e;
																										}
																										break;
																									}
																									goto IL_05e6;
																									IL_063b:
																									ptr2 += 8;
																									goto end_IL_0500;
																									IL_05e6:
																									((delegate*<Behaviour, bool, void>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																									num = 243;
																									goto IL_062d;
																									IL_062d:
																									num5 -= 2;
																									goto IL_063b;
																								}
																								break;
																							}
																							goto IL_064e;
																							IL_06f7:
																							if (27 <= b)
																							{
																							}
																							break;
																							IL_064e:
																							if (26 >= b)
																							{
																								goto IL_065c;
																							}
																							goto IL_06e9;
																							IL_065c:
																							if (26 > b)
																							{
																								goto IL_0667;
																							}
																							goto IL_06cd;
																							IL_0667:
																							if (25 < b)
																							{
																								break;
																							}
																							goto IL_0675;
																							IL_0675:
																							if (25 > b)
																							{
																								break;
																							}
																							goto IL_0683;
																							IL_0683:
																							((delegate*<Class179, void>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])((Class179)array2[num5 - 1]);
																							goto IL_06ac;
																							IL_06ac:
																							num5--;
																							goto IL_06ba;
																							IL_06ba:
																							ptr2 += 8;
																							goto end_IL_0500;
																							IL_06cd:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0500;
																							IL_06e9:
																							if (27 < b)
																							{
																								break;
																							}
																							goto IL_06f7;
																						}
																						break;
																					}
																					goto IL_070a;
																					IL_0a44:
																					ptr2 += 8;
																					goto end_IL_0500;
																					IL_070a:
																					if (21 <= b)
																					{
																						goto IL_0718;
																					}
																					goto IL_079a;
																					IL_0718:
																					array[num5 - 2] = 0;
																					goto IL_072c;
																					IL_072c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																					goto IL_0779;
																					IL_0779:
																					num5--;
																					goto IL_0787;
																					IL_0787:
																					ptr2 += 8;
																					goto end_IL_0500;
																					IL_079a:
																					if (17 >= b)
																					{
																						goto IL_07a8;
																					}
																					goto IL_08b4;
																					IL_07a8:
																					if (17 <= b)
																					{
																						goto IL_07b3;
																					}
																					goto IL_07de;
																					IL_07b3:
																					array2[num5] = null;
																					goto IL_07bd;
																					IL_07bd:
																					array[num5] = 5;
																					goto IL_07cb;
																					IL_07cb:
																					num5++;
																					goto end_IL_0500;
																					IL_07de:
																					if (15 < b)
																					{
																						goto IL_07e9;
																					}
																					goto IL_0852;
																					IL_07e9:
																					if (16 < b)
																					{
																						break;
																					}
																					goto IL_07f7;
																					IL_07f7:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_0805;
																					IL_0805:
																					array[num5] = 5;
																					goto IL_0813;
																					IL_0813:
																					array2[num5] = ((delegate*<GorillaTagger>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])();
																					goto IL_0831;
																					IL_0831:
																					num5++;
																					goto IL_083f;
																					IL_083f:
																					ptr2 += 8;
																					goto end_IL_0500;
																					IL_0852:
																					if (15 > b)
																					{
																						break;
																					}
																					goto IL_0860;
																					IL_0860:
																					((delegate*<bool, void>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																					goto IL_088a;
																					IL_088a:
																					num5--;
																					goto IL_0898;
																					IL_0898:
																					ptr2 += 8;
																					num = 6;
																					goto end_IL_0500;
																					IL_08b4:
																					if (19 >= b)
																					{
																						goto IL_08c2;
																					}
																					goto IL_09d3;
																					IL_08c2:
																					if (19 > b)
																					{
																						goto IL_08d0;
																					}
																					goto IL_096e;
																					IL_08d0:
																					if (18 < b)
																					{
																						break;
																					}
																					goto IL_08de;
																					IL_08de:
																					if (18 > b)
																					{
																						break;
																					}
																					goto IL_08ec;
																					IL_08ec:
																					array[num5 - 2] = 0;
																					goto IL_0900;
																					IL_0900:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																					goto IL_094d;
																					IL_094d:
																					num5--;
																					goto IL_095b;
																					IL_095b:
																					ptr2 += 8;
																					goto end_IL_0500;
																					IL_096e:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_09c0;
																					IL_09c0:
																					num5--;
																					goto end_IL_0500;
																					IL_09d3:
																					if (20 < b)
																					{
																						break;
																					}
																					goto IL_09e1;
																					IL_09e1:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_09ef;
																					IL_09ef:
																					array2[num5 - 1] = ((delegate*<GorillaTagger, VRRig>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																					num = 159;
																					goto IL_0a30;
																					IL_0a30:
																					array[num5 - 1] = 5;
																					goto IL_0a44;
																				}
																				break;
																			}
																			num = 65;
																			goto IL_0a60;
																			IL_1015:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_1020;
																			IL_1020:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_1060;
																			IL_0a60:
																			if (14 <= b)
																			{
																				goto IL_0a6b;
																			}
																			goto IL_0ab5;
																			IL_0a6b:
																			((Class179)array2[num5 - 2]).bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																			num = 129;
																			goto IL_0aa2;
																			IL_0aa2:
																			num5 -= 2;
																			goto end_IL_0500;
																			IL_0ab5:
																			if (7 >= b)
																			{
																				goto IL_0ac3;
																			}
																			goto IL_0e18;
																			IL_0ac3:
																			if (7 <= b)
																			{
																				goto IL_0ace;
																			}
																			goto IL_0b35;
																			IL_0ace:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0b0e;
																			IL_0b0e:
																			array[num5 - 2] = 0;
																			goto IL_0b22;
																			IL_0b22:
																			num5--;
																			goto end_IL_0500;
																			IL_0b35:
																			if (3 < b)
																			{
																				goto IL_0b43;
																			}
																			goto IL_0cd0;
																			IL_0b43:
																			if (5 < b)
																			{
																				goto IL_0b51;
																			}
																			goto IL_0bd4;
																			IL_0b51:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_0b5f;
																			IL_0b5f:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0b6d;
																			IL_0b6d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0bad;
																			IL_0bad:
																			array[num5 - 2] = 0;
																			goto IL_0bc1;
																			IL_0bc1:
																			num5--;
																			goto end_IL_0500;
																			IL_0bd4:
																			if (5 <= b)
																			{
																				goto IL_0bdf;
																			}
																			goto IL_0c46;
																			IL_0bdf:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0c1f;
																			IL_0c1f:
																			array[num5 - 2] = 0;
																			goto IL_0c33;
																			IL_0c33:
																			num5--;
																			goto end_IL_0500;
																			IL_0c46:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0c54;
																			IL_0c54:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_0c62;
																			IL_0c62:
																			array[num5] = 0;
																			num = 74;
																			goto IL_0c79;
																			IL_0c79:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 102;
																			goto IL_0ca5;
																			IL_0ca5:
																			array2[num5] = null;
																			goto IL_0caf;
																			IL_0caf:
																			num5++;
																			goto IL_0cbd;
																			IL_0cbd:
																			ptr2 += 8;
																			goto end_IL_0500;
																			IL_0cd0:
																			if (3 > b)
																			{
																				goto IL_0cde;
																			}
																			goto IL_0dce;
																			IL_0cde:
																			if (1 < b)
																			{
																				goto IL_0cec;
																			}
																			num = 20;
																			goto IL_0d78;
																			IL_0cec:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0cfa;
																			IL_0cfa:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0d08;
																			IL_0d08:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0d48;
																			IL_0d48:
																			array[num5 - 2] = 0;
																			goto IL_0d5c;
																			IL_0d5c:
																			num5--;
																			goto end_IL_0500;
																			IL_1060:
																			array[num5 - 2] = 0;
																			goto IL_1074;
																			IL_0d78:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0d86;
																			IL_0d86:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0d9f;
																			IL_0d9f:
																			array[num5] = 0;
																			goto IL_0dad;
																			IL_0dad:
																			num5++;
																			goto IL_0dbb;
																			IL_0dbb:
																			ptr2 += 8;
																			goto end_IL_0500;
																			IL_0dce:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0df7;
																			IL_0df7:
																			ptr2 += 8;
																			goto IL_0e05;
																			IL_0e05:
																			num5--;
																			goto end_IL_0500;
																			IL_0e18:
																			if (10 < b)
																			{
																				goto IL_0e26;
																			}
																			goto IL_0f5e;
																			IL_0e26:
																			if (12 < b)
																			{
																				goto IL_0e31;
																			}
																			goto IL_0e9d;
																			IL_0e31:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0e3f;
																			IL_0e3f:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0e4d;
																			IL_0e4d:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0e65;
																			IL_0e65:
																			array[num5] = 5;
																			goto IL_0e73;
																			IL_0e73:
																			num5++;
																			goto IL_0e81;
																			IL_0e81:
																			ptr2 += 8;
																			num = 260;
																			goto end_IL_0500;
																			IL_0e9d:
																			if (12 <= b)
																			{
																				goto end_IL_0500;
																			}
																			goto IL_0eab;
																			IL_0eab:
																			if (11 < b)
																			{
																				num = 73;
																				break;
																			}
																			goto IL_0eb9;
																			IL_0eb9:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0ec7;
																			IL_0ec7:
																			array[num5 - 2] = 0;
																			goto IL_0edb;
																			IL_0edb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getDefaultInternalActivationContextHelper[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0f2f;
																			IL_0f2f:
																			num5--;
																			goto IL_0f3d;
																			IL_0f3d:
																			ptr2 += 8;
																			goto end_IL_0500;
																			IL_1074:
																			num5--;
																			goto end_IL_0500;
																			IL_0f5e:
																			if (10 <= b)
																			{
																				goto IL_0f69;
																			}
																			goto IL_0fde;
																			IL_0f69:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0fcb;
																			IL_0fcb:
																			num5 -= 2;
																			goto end_IL_0500;
																			IL_0fde:
																			if (8 >= b)
																			{
																				goto IL_0fe9;
																			}
																			goto IL_100a;
																			IL_0fe9:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0ff7;
																			IL_0ff7:
																			num5--;
																			goto end_IL_0500;
																			IL_100a:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_1015;
																		}
																		break;
																		IL_04d0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0500;
																continue;
																end_IL_04e0:
																break;
															}
															continue;
															end_IL_04f0:
															break;
														}
														continue;
														end_IL_0500:
														break;
													}
													continue;
													end_IL_1097:
													break;
												}
												continue;
												end_IL_10aa:
												break;
											}
											continue;
											end_IL_10b4:
											break;
										}
										continue;
										end_IL_10bf:
										break;
									}
									continue;
									end_IL_10cf:
									break;
								}
								continue;
								end_IL_10df:
								break;
							}
							continue;
							end_IL_10ef:
							break;
						}
						continue;
						end_IL_10ff:
						break;
					}
					continue;
					end_IL_110f:
					break;
				}
				continue;
				end_IL_111f:
				break;
			}
		}
	}

	private static void LdobjConsoleCancelEventHandler(Class179 class179_2)
	{
		class179_2.method_2();
	}

	private unsafe void method_1()
	{
		int num = 173;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											num = 158;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FileAttributesCrossAppDomainChannel.CommonOemLinksStringReader);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 248;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_08bb:
																		if (b >= 1)
																		{
																			while (b <= 60)
																			{
																				while (true)
																				{
																					if (30 >= b)
																					{
																						while (true)
																						{
																							if (30 > b)
																							{
																								while (true)
																								{
																									IL_087e:
																									if (15 >= b)
																									{
																										while (true)
																										{
																											IL_0871:
																											if (15 > b)
																											{
																												while (true)
																												{
																													IL_0861:
																													if (7 >= b)
																													{
																														while (true)
																														{
																															IL_0851:
																															if (7 <= b)
																															{
																																while (true)
																																{
																																	IL_0806:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																	num = 505;
																																	while (true)
																																	{
																																		if (num != 505)
																																		{
																																			if (num != 1486)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 177:
																																			case 331:
																																				goto IL_0806;
																																			case 447:
																																				goto IL_0851;
																																			case 243:
																																				goto IL_0861;
																																			case 386:
																																				goto IL_0871;
																																			case 272:
																																				goto IL_087e;
																																			case 61:
																																				goto end_IL_087e;
																																			case 163:
																																				goto end_IL_088b;
																																			case 171:
																																				goto end_IL_089b;
																																			case 328:
																																				goto IL_08bb;
																																			case 249:
																																				goto end_IL_08bb;
																																			case 494:
																																			case 498:
																																				goto end_IL_08cb;
																																			case 122:
																																				goto IL_08e6;
																																			case 132:
																																			case 240:
																																				goto IL_08f6;
																																			case 86:
																																				goto IL_0940;
																																			case 82:
																																				goto IL_095d;
																																			case 282:
																																				goto IL_0970;
																																			case 287:
																																				goto IL_097e;
																																			case 10:
																																				goto IL_098c;
																																			case 41:
																																				goto IL_09a3;
																																			case 320:
																																				goto IL_09b6;
																																			case 161:
																																				goto IL_09c4;
																																			case 101:
																																				goto IL_09d2;
																																			case 32:
																																				goto IL_09dd;
																																			case 104:
																																				goto IL_09e8;
																																			case 99:
																																				goto IL_09fb;
																																			case 256:
																																			case 334:
																																				goto IL_0a0e;
																																			case 87:
																																				goto IL_0a46;
																																			case 351:
																																				goto IL_0a5c;
																																			case 353:
																																				goto IL_0a6f;
																																			case 375:
																																				goto IL_0a82;
																																			case 103:
																																				goto IL_0a90;
																																			case 360:
																																				goto IL_0aa9;
																																			case 178:
																																				goto IL_0ab7;
																																			case 403:
																																				goto IL_0ac7;
																																			case 277:
																																			case 411:
																																				goto IL_0ada;
																																			case 144:
																																				goto IL_0ae4;
																																			case 176:
																																				goto IL_0af2;
																																			case 307:
																																			case 423:
																																				goto IL_0b05;
																																			case 394:
																																				goto IL_0b57;
																																			case 311:
																																			case 424:
																																				goto IL_0b6a;
																																			case 344:
																																				goto IL_0b7e;
																																			case 113:
																																				goto IL_0bcb;
																																			case 205:
																																				goto IL_0bd9;
																																			case 363:
																																			case 426:
																																				goto IL_0bec;
																																			case 18:
																																				goto IL_0c00;
																																			case 43:
																																				goto IL_0c3f;
																																			case 1:
																																			case 440:
																																				goto IL_0c52;
																																			case 46:
																																				goto IL_0c66;
																																			case 416:
																																				goto IL_0c9e;
																																			case 448:
																																				goto IL_0cb1;
																																			case 126:
																																				goto IL_0cbf;
																																			case 37:
																																			case 254:
																																				goto IL_0cca;
																																			case 296:
																																				goto IL_0ce6;
																																			case 355:
																																				goto IL_0cf4;
																																			case 80:
																																			case 137:
																																				goto IL_0d02;
																																			case 48:
																																				goto IL_0d40;
																																			case 346:
																																				goto IL_0d4e;
																																			case 78:
																																				goto IL_0d61;
																																			case 125:
																																				goto IL_0d78;
																																			case 377:
																																			case 452:
																																				goto IL_0d94;
																																			case 166:
																																				goto IL_0da8;
																																			case 133:
																																				goto IL_0de7;
																																			case 454:
																																				goto IL_0dfa;
																																			case 109:
																																				goto IL_0e08;
																																			case 395:
																																			case 443:
																																				goto IL_0e16;
																																			case 365:
																																				goto IL_0e4e;
																																			case 418:
																																				goto IL_0e6b;
																																			case 179:
																																			case 457:
																																				goto IL_0e7e;
																																			case 433:
																																				goto IL_0eab;
																																			case 461:
																																				goto IL_0ebe;
																																			case 275:
																																				goto IL_0ecc;
																																			case 31:
																																			case 83:
																																				goto IL_0eda;
																																			case 183:
																																				goto end_IL_07f3;
																																			case 50:
																																				goto IL_0f01;
																																			case 259:
																																				goto IL_0f0f;
																																			case 340:
																																			case 477:
																																				goto IL_0f22;
																																			case 119:
																																				goto IL_0f36;
																																			case 225:
																																				goto IL_0f6f;
																																			case 481:
																																				goto IL_0f82;
																																			case 52:
																																			case 284:
																																				goto IL_0f90;
																																			case 164:
																																				goto IL_0fd0;
																																			case 98:
																																				goto IL_0fe4;
																																			case 100:
																																			case 484:
																																				goto IL_0ff7;
																																			case 127:
																																				goto IL_100f;
																																			case 44:
																																				goto IL_101d;
																																			case 257:
																																				goto IL_102b;
																																			case 434:
																																				goto IL_1052;
																																			case 495:
																																				goto IL_1065;
																																			case 444:
																																				goto IL_1073;
																																			case 155:
																																			case 402:
																																				goto IL_107e;
																																			case 490:
																																				goto IL_10a7;
																																			case 182:
																																				goto IL_10b5;
																																			case 422:
																																				goto IL_10c8;
																																			case 409:
																																				goto IL_10d3;
																																			case 29:
																																			case 194:
																																				goto IL_10e1;
																																			case 435:
																																				goto IL_10fa;
																																			case 321:
																																				goto IL_1108;
																																			case 230:
																																				goto IL_1116;
																																			case 140:
																																				goto IL_1129;
																																			case 108:
																																				goto IL_1137;
																																			case 157:
																																			case 234:
																																				goto IL_1145;
																																			case 493:
																																				goto IL_1185;
																																			case 310:
																																				goto IL_1199;
																																			case 42:
																																				goto IL_11b5;
																																			case 19:
																																				goto IL_11c3;
																																			case 81:
																																			case 189:
																																				goto IL_11d7;
																																			case 308:
																																				goto IL_1217;
																																			case 376:
																																				goto IL_122b;
																																			case 441:
																																				goto IL_1247;
																																			case 14:
																																				goto IL_1255;
																																			case 206:
																																			case 215:
																																				goto IL_1263;
																																			case 319:
																																				goto IL_1271;
																																			case 474:
																																				goto IL_1294;
																																			case 218:
																																				goto IL_129e;
																																			case 110:
																																				goto IL_12ac;
																																			case 268:
																																				goto IL_12bf;
																																			case 188:
																																				goto IL_12cd;
																																			case 74:
																																			case 196:
																																				goto IL_12db;
																																			case 187:
																																				goto IL_1324;
																																			case 252:
																																				goto IL_1338;
																																			case 404:
																																				goto IL_134b;
																																			case 129:
																																				goto IL_1359;
																																			case 357:
																																				goto IL_1367;
																																			case 130:
																																				goto IL_1375;
																																			case 35:
																																			case 236:
																																				goto IL_1380;
																																			case 54:
																																				goto IL_13c0;
																																			case 112:
																																				goto IL_13d4;
																																			case 59:
																																				goto IL_13e7;
																																			case 398:
																																				goto IL_13f5;
																																			case 118:
																																			case 322:
																																				goto IL_1403;
																																			case 358:
																																				goto IL_1416;
																																			case 36:
																																				goto IL_1424;
																																			case 413:
																																			case 472:
																																				goto IL_1432;
																																			case 298:
																																				goto IL_1494;
																																			case 24:
																																			case 208:
																																				goto IL_14b0;
																																			case 255:
																																				goto IL_14c4;
																																			case 217:
																																				goto IL_1503;
																																			case 55:
																																				goto IL_1516;
																																			case 285:
																																				goto IL_1521;
																																			case 392:
																																				goto IL_152c;
																																			case 420:
																																				goto IL_153a;
																																			case 349:
																																			case 471:
																																				goto IL_154d;
																																			case 286:
																																				goto IL_1566;
																																			case 449:
																																				goto IL_1574;
																																			case 412:
																																				goto IL_1582;
																																			case 283:
																																				goto IL_1595;
																																			case 266:
																																				goto IL_15a3;
																																			case 38:
																																			case 181:
																																				goto IL_15ba;
																																			case 49:
																																				goto IL_15d2;
																																			case 446:
																																				goto IL_15e0;
																																			case 204:
																																			case 222:
																																				goto IL_15eb;
																																			case 432:
																																				goto IL_160e;
																																			case 343:
																																				goto IL_161c;
																																			case 165:
																																				goto IL_162a;
																																			case 221:
																																				goto IL_163d;
																																			case 60:
																																				goto IL_164b;
																																			case 63:
																																			case 407:
																																				goto IL_1656;
																																			case 114:
																																				goto IL_166a;
																																			case 175:
																																				goto IL_16a9;
																																			case 152:
																																				goto IL_16bc;
																																			case 185:
																																				goto IL_16ca;
																																			case 160:
																																			case 430:
																																				goto IL_16d5;
																																			case 150:
																																				goto IL_16e3;
																																			case 269:
																																				goto IL_1701;
																																			case 138:
																																				goto IL_170f;
																																			case 316:
																																				goto IL_1722;
																																			case 79:
																																				goto IL_172d;
																																			case 191:
																																			case 198:
																																				goto IL_173b;
																																			case 479:
																																				goto IL_174f;
																																			case 415:
																																				goto IL_178e;
																																			case 211:
																																				goto IL_17a1;
																																			case 149:
																																				goto IL_17af;
																																			case 72:
																																			case 396:
																																				goto IL_17bd;
																																			case 265:
																																				goto IL_17d1;
																																			case 379:
																																				goto IL_1809;
																																			case 476:
																																				goto IL_181c;
																																			case 26:
																																				goto IL_182a;
																																			case 47:
																																			case 437:
																																				goto IL_1835;
																																			case 314:
																																				goto IL_1849;
																																			case 380:
																																				goto IL_1886;
																																			case 306:
																																				goto IL_1899;
																																			case 21:
																																				goto IL_18a7;
																																			case 13:
																																			case 120:
																																				goto IL_18b5;
																																			case 143:
																																				goto IL_18f6;
																																			case 64:
																																				goto IL_190a;
																																			case 235:
																																				goto IL_191d;
																																			case 128:
																																				goto IL_192b;
																																			case 97:
																																			case 281:
																																				goto IL_1939;
																																			case 85:
																																				goto IL_1976;
																																			case 141:
																																				goto IL_1984;
																																			case 458:
																																				goto IL_1997;
																																			case 62:
																																				goto IL_19a5;
																																			case 139:
																																				goto IL_19b3;
																																			case 89:
																																			case 297:
																																				goto IL_19be;
																																			case 487:
																																				goto IL_19fe;
																																			case 356:
																																				goto IL_1a12;
																																			case 350:
																																				goto IL_1a25;
																																			case 27:
																																				goto IL_1a33;
																																			case 145:
																																			case 174:
																																				goto IL_1a41;
																																			case 378:
																																				goto IL_1a55;
																																			case 483:
																																				goto IL_1a9d;
																																			case 7:
																																				goto IL_1ab0;
																																			case 241:
																																				goto IL_1abe;
																																			case 11:
																																			case 51:
																																				goto IL_1acc;
																																			case 327:
																																				goto IL_1ae0;
																																			case 289:
																																				goto IL_1b18;
																																			case 216:
																																				goto IL_1b3d;
																																			case 347:
																																			case 439:
																																				goto IL_1b51;
																																			case 159:
																																				goto IL_1b87;
																																			case 229:
																																				goto IL_1ba3;
																																			case 214:
																																				goto IL_1bb1;
																																			case 361:
																																				goto IL_1bc8;
																																			case 68:
																																			case 324:
																																				goto IL_1bd6;
																																			case 399:
																																				goto IL_1c1f;
																																			case 388:
																																				goto IL_1c33;
																																			case 73:
																																				goto IL_1c4f;
																																			case 342:
																																			case 470:
																																				goto IL_1c5a;
																																			case 75:
																																				goto IL_1c83;
																																			case 250:
																																				goto IL_1c91;
																																			case 369:
																																				goto IL_1ca4;
																																			case 425:
																																				goto IL_1cb2;
																																			case 123:
																																			case 391:
																																				goto IL_1cc0;
																																			case 237:
																																				goto IL_1cd4;
																																			case 231:
																																				goto IL_1d0c;
																																			case 22:
																																				goto IL_1d28;
																																			case 53:
																																				goto IL_1d36;
																																			case 95:
																																			case 451:
																																				goto IL_1d41;
																																			case 309:
																																				goto IL_1d79;
																																			case 485:
																																				goto IL_1d8d;
																																			case 111:
																																				goto IL_1da0;
																																			case 372:
																																				goto IL_1dae;
																																			case 45:
																																				goto IL_1dbc;
																																			case 116:
																																				goto IL_1dca;
																																			case 25:
																																			case 209:
																																				goto IL_1dd5;
																																			case 417:
																																				goto IL_1de9;
																																			case 421:
																																				goto IL_1e28;
																																			case 338:
																																				goto IL_1e3b;
																																			case 190:
																																				goto IL_1e49;
																																			case 105:
																																			case 326:
																																				goto IL_1e57;
																																			case 408:
																																				goto IL_1e94;
																																			case 276:
																																				goto IL_1ea2;
																																			case 33:
																																				goto IL_1eb5;
																																			case 292:
																																				goto IL_1ec3;
																																			case 278:
																																			case 366:
																																				goto IL_1ed1;
																																			case 492:
																																				goto IL_1edf;
																																			case 473:
																																				goto IL_1f03;
																																			case 383:
																																				goto IL_1f11;
																																			case 93:
																																			case 233:
																																				goto IL_1f2d;
																																			case 371:
																																				goto IL_1f3b;
																																			case 496:
																																				goto IL_1f5e;
																																			case 401:
																																				goto IL_1f6c;
																																			case 65:
																																				goto IL_1f7f;
																																			case 491:
																																				goto IL_1f8d;
																																			case 5:
																																			case 169:
																																				goto IL_1f9b;
																																			case 279:
																																				goto IL_1faf;
																																			case 239:
																																				goto IL_200a;
																																			case 453:
																																				goto IL_2021;
																																			case 94:
																																				goto IL_2034;
																																			case 352:
																																				goto IL_2042;
																																			case 192:
																																			case 258:
																																				goto IL_2050;
																																			case 70:
																																				goto IL_206a;
																																			case 220:
																																				goto IL_2078;
																																			case 325:
																																				goto IL_2086;
																																			case 294:
																																				goto IL_2099;
																																			case 368:
																																				goto IL_20a7;
																																			case 9:
																																			case 260:
																																				goto IL_20b5;
																																			case 273:
																																				goto IL_20f2;
																																			case 131:
																																				goto IL_2100;
																																			case 219:
																																				goto IL_2113;
																																			case 30:
																																				goto IL_2121;
																																			case 213:
																																			case 370:
																																				goto IL_212c;
																																			case 414:
																																				goto IL_213a;
																																			case 367:
																																				goto IL_215e;
																																			case 387:
																																				goto IL_216c;
																																			case 480:
																																				goto IL_217f;
																																			case 374:
																																				goto IL_218d;
																																			case 106:
																																			case 442:
																																				goto IL_2198;
																																			case 227:
																																				goto IL_21ac;
																																			case 245:
																																				goto IL_21eb;
																																			case 312:
																																				goto IL_21fe;
																																			case 393:
																																				goto IL_220c;
																																			case 28:
																																			case 66:
																																				goto IL_221a;
																																			case 464:
																																				goto IL_224e;
																																			case 299:
																																				goto IL_2270;
																																			case 335:
																																				goto IL_227e;
																																			case 223:
																																			case 385:
																																				goto IL_228c;
																																			case 12:
																																				goto IL_229a;
																																			case 251:
																																				goto IL_22be;
																																			case 315:
																																				goto IL_22cc;
																																			case 121:
																																				goto IL_22df;
																																			case 180:
																																				goto IL_22ed;
																																			case 186:
																																			case 224:
																																				goto IL_22f8;
																																			case 107:
																																				goto IL_2311;
																																			case 207:
																																				goto IL_2324;
																																			case 147:
																																				goto IL_2332;
																																			case 288:
																																			case 488:
																																				goto IL_2340;
																																			case 317:
																																				goto IL_2354;
																																			case 253:
																																				goto IL_2391;
																																			case 8:
																																				goto IL_23aa;
																																			case 489:
																																				goto IL_23be;
																																			case 0:
																																			case 16:
																																			case 17:
																																			case 20:
																																			case 34:
																																			case 39:
																																			case 40:
																																			case 58:
																																			case 69:
																																			case 76:
																																			case 84:
																																			case 91:
																																			case 102:
																																			case 124:
																																			case 134:
																																			case 135:
																																			case 153:
																																			case 154:
																																			case 156:
																																			case 167:
																																			case 170:
																																			case 195:
																																			case 200:
																																			case 201:
																																			case 203:
																																			case 226:
																																			case 228:
																																			case 232:
																																			case 238:
																																			case 242:
																																			case 244:
																																			case 246:
																																			case 263:
																																			case 267:
																																			case 280:
																																			case 291:
																																			case 293:
																																			case 303:
																																			case 330:
																																			case 336:
																																			case 337:
																																			case 339:
																																			case 362:
																																			case 364:
																																			case 373:
																																			case 382:
																																			case 389:
																																			case 406:
																																			case 410:
																																			case 427:
																																			case 428:
																																			case 429:
																																			case 431:
																																			case 436:
																																			case 445:
																																			case 450:
																																			case 456:
																																			case 460:
																																			case 465:
																																			case 466:
																																			case 467:
																																			case 478:
																																			case 486:
																																				goto end_IL_08ab;
																																			case 6:
																																			case 15:
																																			case 23:
																																			case 57:
																																			case 67:
																																			case 71:
																																			case 77:
																																			case 88:
																																			case 96:
																																			case 115:
																																			case 136:
																																			case 142:
																																			case 146:
																																			case 148:
																																			case 151:
																																			case 168:
																																			case 184:
																																			case 193:
																																			case 202:
																																			case 212:
																																			case 247:
																																			case 248:
																																			case 261:
																																			case 262:
																																			case 264:
																																			case 270:
																																			case 271:
																																			case 274:
																																			case 290:
																																			case 295:
																																			case 300:
																																			case 301:
																																			case 302:
																																			case 304:
																																			case 305:
																																			case 313:
																																			case 318:
																																			case 323:
																																			case 329:
																																			case 332:
																																			case 333:
																																			case 341:
																																			case 345:
																																			case 348:
																																			case 354:
																																			case 359:
																																			case 381:
																																			case 384:
																																			case 390:
																																			case 397:
																																			case 400:
																																			case 405:
																																			case 419:
																																			case 438:
																																			case 459:
																																			case 462:
																																			case 463:
																																			case 468:
																																			case 469:
																																			case 475:
																																			case 482:
																																			case 497:
																																				goto end_IL_08db;
																																			case 90:
																																				goto end_IL_23dc;
																																			case 2:
																																				goto end_IL_23ef;
																																			case 158:
																																				goto end_IL_23fa;
																																			case 92:
																																				goto end_IL_2404;
																																			case 117:
																																				goto end_IL_240f;
																																			case 3:
																																				goto end_IL_2428;
																																			case 4:
																																			case 56:
																																				goto end_IL_2438;
																																			case 455:
																																				goto end_IL_2448;
																																			case 210:
																																				goto end_IL_2458;
																																			case 199:
																																				goto end_IL_2468;
																																			case 172:
																																				goto end_IL_2478;
																																			case 173:
																																				goto end_IL_2488;
																																			case 162:
																																			case 197:
																																				return;
																																			}
																																			continue;
																																		}
																																		array[num6 - 2] = 0;
																																		goto IL_1052;
																																		IL_1052:
																																		num6--;
																																		goto end_IL_08db;
																																		continue;
																																		end_IL_07f3:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_1065;
																															IL_1324:
																															array[num6 - 2] = 0;
																															goto IL_1338;
																															IL_1065:
																															if (3 >= b)
																															{
																																goto IL_1073;
																															}
																															goto IL_11b5;
																															IL_1073:
																															if (3 <= b)
																															{
																																goto IL_107e;
																															}
																															goto IL_10c8;
																															IL_107e:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																															goto IL_10a7;
																															IL_10a7:
																															ptr2 += 8;
																															goto IL_10b5;
																															IL_10b5:
																															num6--;
																															goto end_IL_08db;
																															IL_10c8:
																															if (1 >= b)
																															{
																																goto IL_10d3;
																															}
																															goto IL_1129;
																															IL_10d3:
																															if (1 > b)
																															{
																																goto end_IL_08ab;
																															}
																															goto IL_10e1;
																															IL_10e1:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																															goto IL_10fa;
																															IL_10fa:
																															array[num6] = 0;
																															goto IL_1108;
																															IL_1108:
																															num6++;
																															goto IL_1116;
																															IL_1116:
																															ptr2 += 8;
																															goto end_IL_08db;
																															IL_1129:
																															if (2 < b)
																															{
																																goto end_IL_08ab;
																															}
																															goto IL_1137;
																															IL_1137:
																															if (2 > b)
																															{
																																goto end_IL_08ab;
																															}
																															goto IL_1145;
																															IL_1145:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																															goto IL_1185;
																															IL_1185:
																															array[num6 - 2] = 0;
																															goto IL_1199;
																															IL_1199:
																															num6--;
																															num = 313;
																															goto end_IL_08db;
																															IL_11b5:
																															if (5 >= b)
																															{
																																goto IL_11c3;
																															}
																															goto IL_12bf;
																															IL_11c3:
																															if (5 <= b)
																															{
																																num = 189;
																																goto IL_11d7;
																															}
																															goto IL_1247;
																															IL_1338:
																															num6--;
																															goto end_IL_08db;
																															IL_11d7:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																															goto IL_1217;
																															IL_1217:
																															array[num6 - 2] = 0;
																															goto IL_122b;
																															IL_122b:
																															num6--;
																															num = 359;
																															goto end_IL_08db;
																															IL_1247:
																															if (4 < b)
																															{
																																goto end_IL_08ab;
																															}
																															goto IL_1255;
																															IL_1255:
																															if (4 > b)
																															{
																																goto end_IL_08ab;
																															}
																															goto IL_1263;
																															IL_1263:
																															array[num6] = 0;
																															goto IL_1271;
																															IL_1271:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																															goto IL_1294;
																															IL_1294:
																															array2[num6] = null;
																															goto IL_129e;
																															IL_129e:
																															num6++;
																															goto IL_12ac;
																															IL_12ac:
																															ptr2 += 8;
																															goto end_IL_08db;
																															IL_12bf:
																															if (6 < b)
																															{
																																goto end_IL_08ab;
																															}
																															goto IL_12cd;
																															IL_12cd:
																															if (6 > b)
																															{
																																goto end_IL_08ab;
																															}
																															goto IL_12db;
																															IL_12db:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																															num = 187;
																															goto IL_1324;
																														}
																														break;
																													}
																													goto IL_134b;
																													IL_15a3:
																													if (14 > b)
																													{
																														goto end_IL_08ab;
																													}
																													num = 38;
																													goto IL_15ba;
																													IL_134b:
																													if (11 >= b)
																													{
																														goto IL_1359;
																													}
																													goto IL_1516;
																													IL_1359:
																													if (11 > b)
																													{
																														goto IL_1367;
																													}
																													num = 208;
																													goto IL_14b0;
																													IL_1367:
																													if (9 >= b)
																													{
																														goto IL_1375;
																													}
																													goto IL_1416;
																													IL_1375:
																													if (9 <= b)
																													{
																														goto IL_1380;
																													}
																													goto IL_13e7;
																													IL_1380:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																													goto IL_13c0;
																													IL_13c0:
																													array[num6 - 2] = 0;
																													goto IL_13d4;
																													IL_13d4:
																													num6--;
																													goto end_IL_08db;
																													IL_13e7:
																													if (8 < b)
																													{
																														goto end_IL_08ab;
																													}
																													goto IL_13f5;
																													IL_13f5:
																													if (8 > b)
																													{
																														goto end_IL_08ab;
																													}
																													goto IL_1403;
																													IL_1403:
																													num6--;
																													goto end_IL_08db;
																													IL_1416:
																													if (10 < b)
																													{
																														goto end_IL_08ab;
																													}
																													goto IL_1424;
																													IL_1424:
																													if (10 > b)
																													{
																														goto end_IL_08ab;
																													}
																													goto IL_1432;
																													IL_1432:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_1494;
																													IL_1494:
																													num6 -= 2;
																													goto end_IL_08db;
																													IL_15ba:
																													ptr2 = ptr + *(int*)(ptr2 + num3);
																													goto end_IL_08db;
																													IL_14b0:
																													array[num6 - 1] = 0;
																													goto IL_14c4;
																													IL_14c4:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																													goto IL_1503;
																													IL_1503:
																													ptr2 += 8;
																													goto end_IL_08db;
																													IL_1516:
																													if (13 >= b)
																													{
																														goto IL_1521;
																													}
																													goto IL_1595;
																													IL_1521:
																													if (13 > b)
																													{
																														goto IL_152c;
																													}
																													goto IL_154d;
																													IL_152c:
																													if (12 < b)
																													{
																														goto end_IL_08ab;
																													}
																													goto IL_153a;
																													IL_153a:
																													if (12 > b)
																													{
																														goto end_IL_08ab;
																													}
																													goto end_IL_08db;
																													IL_154d:
																													*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																													goto IL_1566;
																													IL_1566:
																													array[num6] = 1;
																													goto IL_1574;
																													IL_1574:
																													num6++;
																													goto IL_1582;
																													IL_1582:
																													ptr2 += 16;
																													goto end_IL_08db;
																													IL_1595:
																													if (14 < b)
																													{
																														goto end_IL_08ab;
																													}
																													goto IL_15a3;
																												}
																												break;
																											}
																											goto IL_08f6;
																											IL_095d:
																											num6--;
																											goto end_IL_08db;
																											IL_08f6:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																											num = 86;
																											goto IL_0940;
																											IL_0940:
																											array[num6 - 2] = 0;
																											num = 82;
																											goto IL_095d;
																										}
																										goto IL_0ef3;
																									}
																									goto IL_08e6;
																									IL_0d78:
																									if (29 > b)
																									{
																										goto end_IL_08ab;
																									}
																									num = 340;
																									goto IL_0f22;
																									IL_08e6:
																									if (22 < b)
																									{
																										goto IL_0970;
																									}
																									goto IL_09b6;
																									IL_09b6:
																									if (22 > b)
																									{
																										goto IL_09c4;
																									}
																									goto IL_0d94;
																									IL_09c4:
																									if (18 >= b)
																									{
																										goto IL_09d2;
																									}
																									goto IL_0a82;
																									IL_09d2:
																									if (18 > b)
																									{
																										goto IL_09dd;
																									}
																									goto IL_0a0e;
																									IL_09dd:
																									if (16 >= b)
																									{
																										goto IL_09e8;
																									}
																									goto IL_09fb;
																									IL_09e8:
																									if (16 > b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0b05;
																									IL_0b05:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0b57;
																									IL_0b57:
																									num6--;
																									goto end_IL_08db;
																									IL_09fb:
																									if (17 < b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0ac7;
																									IL_0ac7:
																									if (17 > b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0ff7;
																									IL_0ff7:
																									array2[num6] = array5[*(int*)(ptr2 + num3)];
																									goto IL_100f;
																									IL_100f:
																									array[num6] = 5;
																									goto IL_101d;
																									IL_101d:
																									num6++;
																									goto IL_102b;
																									IL_102b:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0a0e:
																									array2[num6 - 1] = ((delegate*<Class179, GameObject>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 1]);
																									goto IL_0a46;
																									IL_0a46:
																									array[num6 - 1] = 5;
																									goto IL_0a6f;
																									IL_0a6f:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0a82:
																									if (20 >= b)
																									{
																										goto IL_0a90;
																									}
																									goto IL_0ebe;
																									IL_0a90:
																									if (20 > b)
																									{
																										goto IL_0aa9;
																									}
																									num = 311;
																									goto IL_0b6a;
																									IL_0f6f:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0b6a:
																									array[num6 - 2] = 0;
																									goto IL_0b7e;
																									IL_0b7e:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																									goto IL_0bcb;
																									IL_0bcb:
																									num6--;
																									goto IL_0bd9;
																									IL_0bd9:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0aa9:
																									if (19 < b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0ab7;
																									IL_0ab7:
																									if (19 > b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0ada;
																									IL_0ada:
																									array2[num6] = null;
																									goto IL_0ae4;
																									IL_0ae4:
																									array[num6] = 5;
																									goto IL_0af2;
																									IL_0af2:
																									num6++;
																									goto end_IL_08db;
																									IL_0ebe:
																									if (21 < b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0ecc;
																									IL_0ecc:
																									if (21 > b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0eda;
																									IL_0eda:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																									goto IL_0ef3;
																									IL_0ef3:
																									array[num6] = 3;
																									goto IL_0f01;
																									IL_0f01:
																									num6++;
																									goto IL_0f0f;
																									IL_0f0f:
																									ptr2 += 16;
																									goto end_IL_08db;
																									IL_0d94:
																									array[num6 - 1] = 3;
																									goto IL_0da8;
																									IL_0da8:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_0de7;
																									IL_0de7:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0970:
																									if (26 >= b)
																									{
																										goto IL_097e;
																									}
																									goto IL_0cb1;
																									IL_097e:
																									if (26 > b)
																									{
																										goto IL_098c;
																									}
																									goto IL_0c52;
																									IL_098c:
																									if (24 >= b)
																									{
																										num = 41;
																										goto IL_09a3;
																									}
																									goto IL_0dfa;
																									IL_0f22:
																									array[num6 - 1] = 5;
																									goto IL_0f36;
																									IL_09a3:
																									if (24 > b)
																									{
																										goto IL_0a5c;
																									}
																									goto IL_0bec;
																									IL_0bec:
																									array[num6 - 1] = 0;
																									goto IL_0c00;
																									IL_0c00:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_0c3f;
																									IL_0c3f:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0a5c:
																									if (23 < b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0f82;
																									IL_0f82:
																									if (23 > b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0f90;
																									IL_0f90:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0fd0;
																									IL_0fd0:
																									array[num6 - 2] = 3;
																									goto IL_0fe4;
																									IL_0fe4:
																									num6--;
																									goto end_IL_08db;
																									IL_0dfa:
																									if (25 < b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0e08;
																									IL_0e08:
																									if (25 > b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0e16;
																									IL_0e16:
																									array2[num6 - 1] = ((delegate*<Class179, GameObject>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 1]);
																									goto IL_0e4e;
																									IL_0e4e:
																									array[num6 - 1] = 5;
																									num = 418;
																									goto IL_0e6b;
																									IL_0e6b:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0c52:
																									array[num6 - 1] = 5;
																									goto IL_0c66;
																									IL_0c66:
																									array2[num6 - 1] = ((delegate*<GameObject, Renderer>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																									goto IL_0c9e;
																									IL_0c9e:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0cb1:
																									if (28 >= b)
																									{
																										goto IL_0cbf;
																									}
																									goto IL_0d61;
																									IL_0cbf:
																									if (28 <= b)
																									{
																										goto IL_0cca;
																									}
																									goto IL_0ce6;
																									IL_0cca:
																									byte* num7 = ptr2;
																									num5 = 1;
																									ptr2 = num7 + -200;
																									goto end_IL_08db;
																									IL_0ce6:
																									if (27 < b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0cf4;
																									IL_0cf4:
																									if (27 > b)
																									{
																										goto end_IL_08ab;
																									}
																									goto IL_0d02;
																									IL_0d02:
																									((delegate*<Renderer, bool, void>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Renderer)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																									goto IL_0d40;
																									IL_0d40:
																									num6 -= 2;
																									goto IL_0d4e;
																									IL_0d4e:
																									ptr2 += 8;
																									goto end_IL_08db;
																									IL_0d61:
																									if (29 < b)
																									{
																										goto end_IL_08ab;
																									}
																									num = 125;
																									goto IL_0d78;
																									IL_0f36:
																									array2[num6 - 1] = ((delegate*<PrimitiveType, GameObject>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(PrimitiveType*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_0f6f;
																									continue;
																									end_IL_087e:
																									break;
																								}
																								continue;
																							}
																							goto IL_0e7e;
																							IL_0eab:
																							num6 -= 2;
																							goto end_IL_08db;
																							IL_0e7e:
																							((Class179)array2[num6 - 2]).gameObject_0 = (GameObject)array2[num6 - 1];
																							goto IL_0eab;
																							continue;
																							end_IL_088b:
																							break;
																						}
																						continue;
																					}
																					goto IL_15d2;
																					IL_2332:
																					if (58 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_2340;
																					IL_15d2:
																					if (45 >= b)
																					{
																						goto IL_15e0;
																					}
																					goto IL_1d28;
																					IL_15e0:
																					if (45 <= b)
																					{
																						goto IL_15eb;
																					}
																					goto IL_163d;
																					IL_15eb:
																					array2[num6] = ((delegate*<Color>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])();
																					goto IL_160e;
																					IL_160e:
																					array[num6] = 4;
																					goto IL_161c;
																					IL_161c:
																					num6++;
																					goto IL_162a;
																					IL_162a:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_163d:
																					if (37 >= b)
																					{
																						goto IL_164b;
																					}
																					goto IL_1997;
																					IL_164b:
																					if (37 <= b)
																					{
																						goto IL_1656;
																					}
																					goto IL_16bc;
																					IL_1656:
																					array[num6 - 1] = 3;
																					goto IL_166a;
																					IL_166a:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_16a9;
																					IL_16a9:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_16bc:
																					if (33 >= b)
																					{
																						goto IL_16ca;
																					}
																					goto IL_181c;
																					IL_16ca:
																					if (33 <= b)
																					{
																						goto IL_16d5;
																					}
																					goto IL_1722;
																					IL_16d5:
																					array[num6] = 5;
																					goto IL_16e3;
																					IL_16e3:
																					array2[num6] = ((delegate*<GorillaTagger>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])();
																					goto IL_1701;
																					IL_1701:
																					num6++;
																					goto IL_170f;
																					IL_170f:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1722:
																					if (31 >= b)
																					{
																						goto IL_172d;
																					}
																					goto IL_17a1;
																					IL_172d:
																					if (31 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_173b;
																					IL_173b:
																					array[num6 - 1] = 3;
																					goto IL_174f;
																					IL_174f:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_178e;
																					IL_178e:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_17a1:
																					if (32 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_17af;
																					IL_17af:
																					if (32 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_17bd;
																					IL_17bd:
																					array[num6 - 1] = 5;
																					goto IL_17d1;
																					IL_17d1:
																					array2[num6 - 1] = ((delegate*<GameObject, Transform>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																					goto IL_1809;
																					IL_1809:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_181c:
																					if (35 >= b)
																					{
																						goto IL_182a;
																					}
																					goto IL_191d;
																					IL_182a:
																					if (35 <= b)
																					{
																						goto IL_1835;
																					}
																					goto IL_1899;
																					IL_1835:
																					array[num6 - 1] = 4;
																					goto IL_1849;
																					IL_1849:
																					array2[num6 - 1] = ((delegate*<Transform, Vector3>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																					goto IL_1886;
																					IL_1886:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1899:
																					if (34 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_18a7;
																					IL_18a7:
																					if (34 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_18b5;
																					IL_18b5:
																					array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																					num = 143;
																					goto IL_18f6;
																					IL_18f6:
																					array[num6 - 1] = 5;
																					goto IL_190a;
																					IL_190a:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_191d:
																					if (36 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_192b;
																					IL_192b:
																					if (36 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1939;
																					IL_1939:
																					((delegate*<Transform, Vector3, void>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																					goto IL_1976;
																					IL_1976:
																					num6 -= 2;
																					goto IL_1984;
																					IL_1984:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1997:
																					if (41 < b)
																					{
																						goto IL_19a5;
																					}
																					num = 216;
																					goto IL_1b3d;
																					IL_19a5:
																					if (43 >= b)
																					{
																						goto IL_19b3;
																					}
																					goto IL_1ab0;
																					IL_19b3:
																					if (43 <= b)
																					{
																						goto IL_19be;
																					}
																					goto IL_1a25;
																					IL_19be:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_19fe;
																					IL_19fe:
																					array[num6 - 2] = 3;
																					goto IL_1a12;
																					IL_1a12:
																					num6--;
																					goto end_IL_08db;
																					IL_1a25:
																					if (42 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1a33;
																					IL_1a33:
																					if (42 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1a41;
																					IL_1a41:
																					array[num6 - 1] = 3;
																					goto IL_1a55;
																					IL_1a55:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 483;
																					goto IL_1a9d;
																					IL_1a9d:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1ab0:
																					if (44 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1abe;
																					IL_1abe:
																					if (44 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1acc;
																					IL_1acc:
																					array[num6 - 1] = 5;
																					goto IL_1ae0;
																					IL_1ae0:
																					array2[num6 - 1] = ((delegate*<Renderer, Material>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Renderer)array2[num6 - 1]);
																					goto IL_1b18;
																					IL_1b18:
																					ptr2 += 8;
																					num = 397;
																					goto end_IL_08db;
																					IL_2340:
																					array[num6 - 1] = 4;
																					goto IL_2354;
																					IL_1b3d:
																					if (41 <= b)
																					{
																						num = 347;
																						goto IL_1b51;
																					}
																					goto IL_1ba3;
																					IL_2354:
																					array2[num6 - 1] = ((delegate*<Class179, Color>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 1]);
																					goto IL_2391;
																					IL_1b51:
																					((Class179)array2[num6 - 2]).gameObject_1 = (GameObject)array2[num6 - 1];
																					num = 159;
																					goto IL_1b87;
																					IL_1b87:
																					num6 -= 2;
																					num = 115;
																					goto end_IL_08db;
																					IL_1ba3:
																					if (39 < b)
																					{
																						goto IL_1bb1;
																					}
																					num = 73;
																					goto IL_1c4f;
																					IL_1bb1:
																					if (40 < b)
																					{
																						goto end_IL_08ab;
																					}
																					num = 361;
																					goto IL_1bc8;
																					IL_23aa:
																					if (60 < b)
																					{
																						goto end_IL_08ab;
																					}
																					num = 489;
																					goto IL_23be;
																					IL_1bc8:
																					if (40 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1bd6;
																					IL_1bd6:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 399;
																					goto IL_1c1f;
																					IL_1c1f:
																					array[num6 - 2] = 3;
																					goto IL_1c33;
																					IL_1c33:
																					num6--;
																					goto end_IL_08db;
																					IL_2391:
																					ptr2 += 8;
																					num = 462;
																					goto end_IL_08db;
																					IL_1c4f:
																					if (39 <= b)
																					{
																						goto IL_1c5a;
																					}
																					goto IL_1ca4;
																					IL_1c5a:
																					((delegate*<UnityEngine.Object, void>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Collider)array2[num6 - 1]);
																					goto IL_1c83;
																					IL_1c83:
																					num6--;
																					goto IL_1c91;
																					IL_1c91:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1ca4:
																					if (38 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1cb2;
																					IL_1cb2:
																					if (38 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1cc0;
																					IL_1cc0:
																					array[num6 - 1] = 5;
																					goto IL_1cd4;
																					IL_1cd4:
																					array2[num6 - 1] = ((delegate*<GameObject, Collider>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																					goto IL_1d0c;
																					IL_1d0c:
																					ptr2 += 8;
																					num = 77;
																					goto end_IL_08db;
																					IL_1d28:
																					if (53 >= b)
																					{
																						goto IL_1d36;
																					}
																					goto IL_2113;
																					IL_1d36:
																					if (53 <= b)
																					{
																						goto IL_1d41;
																					}
																					goto IL_1da0;
																					IL_1d41:
																					array2[num6 - 1] = ((delegate*<GorillaTagger, Transform>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																					goto IL_1d79;
																					IL_1d79:
																					array[num6 - 1] = 5;
																					goto IL_1d8d;
																					IL_1d8d:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1da0:
																					if (49 >= b)
																					{
																						goto IL_1dae;
																					}
																					goto IL_1f7f;
																					IL_1dae:
																					if (49 > b)
																					{
																						goto IL_1dbc;
																					}
																					num = 233;
																					goto IL_1f2d;
																					IL_1dbc:
																					if (47 >= b)
																					{
																						goto IL_1dca;
																					}
																					goto IL_1eb5;
																					IL_1dca:
																					if (47 <= b)
																					{
																						goto IL_1dd5;
																					}
																					goto IL_1e3b;
																					IL_1dd5:
																					array[num6 - 1] = 3;
																					goto IL_1de9;
																					IL_1de9:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1e28;
																					IL_1e28:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1e3b:
																					if (46 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1e49;
																					IL_1e49:
																					if (46 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1e57;
																					IL_1e57:
																					((delegate*<Material, Color, void>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Material)array2[num6 - 2], (Color)array2[num6 - 1]);
																					goto IL_1e94;
																					IL_1e94:
																					num6 -= 2;
																					goto IL_1ea2;
																					IL_1ea2:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1eb5:
																					if (48 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1ec3;
																					IL_1ec3:
																					if (48 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_1ed1;
																					IL_1ed1:
																					array[num6] = 0;
																					goto IL_1edf;
																					IL_1edf:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])() ? 1 : 0);
																					goto IL_1f03;
																					IL_1f03:
																					num6++;
																					goto IL_1f11;
																					IL_1f11:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_23be:
																					if (60 <= b)
																					{
																					}
																					goto end_IL_08ab;
																					IL_1f2d:
																					array[num6] = 4;
																					goto IL_1f3b;
																					IL_1f3b:
																					array2[num6] = ((delegate*<Vector3>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])();
																					goto IL_1f5e;
																					IL_1f5e:
																					num6++;
																					goto IL_1f6c;
																					IL_1f6c:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_1f7f:
																					if (51 >= b)
																					{
																						goto IL_1f8d;
																					}
																					goto IL_2099;
																					IL_1f8d:
																					if (51 <= b)
																					{
																						goto IL_1f9b;
																					}
																					goto IL_2034;
																					IL_1f9b:
																					array[num6 - 2] = 4;
																					goto IL_1faf;
																					IL_1faf:
																					array2[num6 - 2] = ((delegate*<Vector3, float, Vector3>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																					num = 239;
																					goto IL_200a;
																					IL_200a:
																					num6--;
																					num = 453;
																					goto IL_2021;
																					IL_2021:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_2034:
																					if (50 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_2042;
																					IL_2042:
																					if (50 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_2050;
																					IL_2050:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																					goto IL_206a;
																					IL_206a:
																					array[num6] = 3;
																					goto IL_2078;
																					IL_2078:
																					num6++;
																					goto IL_2086;
																					IL_2086:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_2099:
																					if (52 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_20a7;
																					IL_20a7:
																					if (52 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_20b5;
																					IL_20b5:
																					((delegate*<Transform, Vector3, void>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																					goto IL_20f2;
																					IL_20f2:
																					num6 -= 2;
																					goto IL_2100;
																					IL_2100:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_2113:
																					if (57 >= b)
																					{
																						goto IL_2121;
																					}
																					goto IL_22df;
																					IL_2121:
																					if (57 <= b)
																					{
																						goto IL_212c;
																					}
																					goto IL_217f;
																					IL_212c:
																					array[num6] = 0;
																					goto IL_213a;
																					IL_213a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])() ? 1 : 0);
																					goto IL_215e;
																					IL_215e:
																					num6++;
																					goto IL_216c;
																					IL_216c:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_217f:
																					if (55 >= b)
																					{
																						goto IL_218d;
																					}
																					goto IL_2270;
																					IL_218d:
																					if (55 <= b)
																					{
																						goto IL_2198;
																					}
																					goto IL_21fe;
																					IL_2198:
																					array[num6 - 1] = 3;
																					goto IL_21ac;
																					IL_21ac:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_21eb;
																					IL_21eb:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_21fe:
																					if (54 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_220c;
																					IL_220c:
																					if (54 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_221a;
																					IL_221a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					num = 464;
																					goto IL_224e;
																					IL_224e:
																					array[num6 - 1] = 0;
																					num = 262;
																					goto end_IL_08db;
																					IL_2270:
																					if (56 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_227e;
																					IL_227e:
																					if (56 > b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_228c;
																					IL_228c:
																					array[num6] = 0;
																					goto IL_229a;
																					IL_229a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)getIsSecurityTransparentGetDefaultReader[*(int*)(ptr2 + num3)])() ? 1 : 0);
																					goto IL_22be;
																					IL_22be:
																					num6++;
																					goto IL_22cc;
																					IL_22cc:
																					ptr2 += 8;
																					goto end_IL_08db;
																					IL_22df:
																					if (59 >= b)
																					{
																						goto IL_22ed;
																					}
																					goto IL_23aa;
																					IL_22ed:
																					if (59 <= b)
																					{
																						goto IL_22f8;
																					}
																					goto IL_2324;
																					IL_22f8:
																					global::_003CModule_003E.color_14 = (Color)array2[num6 - 1];
																					goto IL_2311;
																					IL_2311:
																					num6--;
																					goto end_IL_08db;
																					IL_2324:
																					if (58 < b)
																					{
																						goto end_IL_08ab;
																					}
																					goto IL_2332;
																					continue;
																					end_IL_089b:
																					break;
																				}
																				continue;
																				end_IL_08ab:
																				break;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_08db;
																		continue;
																		end_IL_08bb:
																		break;
																	}
																	continue;
																	end_IL_08cb:
																	break;
																}
																continue;
																end_IL_08db:
																break;
															}
															continue;
															end_IL_23dc:
															break;
														}
														continue;
														end_IL_23ef:
														break;
													}
													continue;
													end_IL_23fa:
													break;
												}
												continue;
												end_IL_2404:
												break;
											}
											continue;
											end_IL_240f:
											break;
										}
										continue;
										end_IL_2428:
										break;
									}
									continue;
									end_IL_2438:
									break;
								}
								continue;
								end_IL_2448:
								break;
							}
							continue;
							end_IL_2458:
							break;
						}
						continue;
						end_IL_2468:
						break;
					}
					continue;
					end_IL_2478:
					break;
				}
				continue;
				end_IL_2488:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1, int int_2)
	{
		int num = 43;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								num = 28;
								while (true)
								{
									array3[0] = int_1;
									num = 91;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getHostSecurityManagerIConvertible.getIsInheritedsetDiscretionaryAcl);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0337:
															byte b = *ptr2;
															while (true)
															{
																IL_0327:
																ptr2++;
																while (true)
																{
																	IL_0317:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02f7:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02e7:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_02d7:
																								if (9 <= b)
																								{
																									num = 71;
																									while (true)
																									{
																										IL_02b8:
																										array[num5 - 2] = 0;
																										num = 40;
																										while (true)
																										{
																											IL_0262:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)setLockedsetDisallowApplicationBaseProbing[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																											while (true)
																											{
																												IL_0249:
																												num5--;
																												num = 56;
																												while (true)
																												{
																													IL_0230:
																													ptr2 += 8;
																													num = 128;
																													while (num != 128)
																													{
																														if (num != 1109)
																														{
																															goto IL_0307;
																														}
																														switch (num)
																														{
																														case 56:
																															goto IL_0230;
																														case 61:
																															goto IL_0249;
																														case 40:
																															goto IL_0262;
																														case 32:
																														case 71:
																															goto IL_02b8;
																														case 73:
																															goto IL_02d7;
																														case 11:
																														case 34:
																															goto IL_02e7;
																														case 19:
																															goto IL_02f7;
																														case 3:
																															goto IL_0307;
																														case 57:
																															goto IL_0317;
																														case 41:
																															goto IL_0327;
																														case 22:
																														case 45:
																															goto IL_0337;
																														case 119:
																															goto IL_0342;
																														case 85:
																															goto IL_034d;
																														case 1:
																														case 89:
																															goto IL_035b;
																														case 13:
																															goto IL_0374;
																														case 97:
																															goto IL_0382;
																														case 75:
																															goto IL_0390;
																														case 88:
																															goto IL_03ac;
																														case 110:
																															goto IL_03ba;
																														case 30:
																														case 98:
																															goto IL_03c5;
																														case 24:
																															goto IL_0405;
																														case 46:
																															goto IL_0419;
																														case 47:
																															goto IL_043a;
																														case 9:
																															goto IL_0445;
																														case 6:
																														case 39:
																															goto IL_0453;
																														case 120:
																															goto IL_0466;
																														case 26:
																															goto IL_0474;
																														case 70:
																														case 80:
																															goto IL_0482;
																														case 77:
																															goto IL_049e;
																														case 66:
																														case 90:
																															goto IL_04a9;
																														case 108:
																															goto IL_04e9;
																														case 17:
																															goto IL_04fd;
																														case 78:
																															goto IL_0510;
																														case 86:
																															goto IL_051e;
																														case 4:
																														case 33:
																															goto IL_052c;
																														case 14:
																															goto IL_0537;
																														case 112:
																														case 121:
																															goto IL_054a;
																														case 60:
																															goto IL_0558;
																														case 10:
																														case 55:
																															goto IL_0566;
																														case 99:
																															goto IL_05a6;
																														case 102:
																															goto IL_05ba;
																														case 20:
																														case 58:
																															goto IL_05cd;
																														case 67:
																															goto IL_05f6;
																														case 72:
																															goto IL_060d;
																														case 93:
																														case 114:
																															goto IL_0629;
																														case 29:
																														case 38:
																															goto IL_0637;
																														case 21:
																															goto IL_0645;
																														case 83:
																														case 101:
																															goto IL_0653;
																														case 95:
																															goto IL_0661;
																														case 92:
																															goto IL_0684;
																														case 106:
																															goto IL_068e;
																														case 74:
																															goto IL_06a5;
																														case 54:
																															goto IL_06b8;
																														case 53:
																														case 96:
																															goto IL_06c3;
																														case 25:
																															goto IL_0703;
																														case 59:
																															goto IL_0717;
																														case 5:
																														case 8:
																														case 12:
																														case 15:
																														case 27:
																														case 35:
																														case 36:
																														case 51:
																														case 62:
																														case 63:
																														case 69:
																														case 79:
																														case 81:
																														case 82:
																														case 84:
																														case 100:
																														case 104:
																														case 111:
																														case 115:
																														case 117:
																														case 118:
																															goto end_IL_0307;
																														case 50:
																															goto IL_074a;
																														case 87:
																															goto IL_0758;
																														case 49:
																															goto IL_0766;
																														case 0:
																														case 2:
																														case 23:
																														case 44:
																														case 48:
																														case 52:
																														case 64:
																														case 65:
																														case 68:
																														case 76:
																														case 105:
																														case 109:
																															goto end_IL_021d;
																														case 18:
																															goto end_IL_0774;
																														case 107:
																															goto end_IL_0787;
																														case 91:
																															goto end_IL_0791;
																														case 28:
																															goto end_IL_079c;
																														case 113:
																															goto end_IL_07b1;
																														case 94:
																														case 103:
																															goto end_IL_07cf;
																														case 16:
																															goto end_IL_07e8;
																														case 37:
																														case 116:
																															goto end_IL_07f8;
																														case 42:
																															goto end_IL_0808;
																														case 43:
																															goto end_IL_0818;
																														case 7:
																														case 31:
																															goto IL_0833;
																														}
																														continue;
																														end_IL_021d:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0342;
																								IL_0405:
																								array[num5 - 2] = 0;
																								goto IL_0419;
																								IL_0419:
																								num5--;
																								break;
																								IL_0342:
																								if (7 >= b)
																								{
																									goto IL_034d;
																								}
																								goto IL_03ac;
																								IL_034d:
																								if (7 > b)
																								{
																									goto end_IL_0307;
																								}
																								goto IL_035b;
																								IL_035b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0374;
																								IL_0374:
																								array[num5] = 0;
																								goto IL_0382;
																								IL_0382:
																								num5++;
																								goto IL_0390;
																								IL_0390:
																								ptr2 += 8;
																								num = 48;
																								break;
																								IL_03ac:
																								if (8 < b)
																								{
																									goto end_IL_0307;
																								}
																								goto IL_03ba;
																								IL_03ba:
																								if (8 > b)
																								{
																									num = 12;
																									goto end_IL_0307;
																								}
																								goto IL_03c5;
																								IL_03c5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0405;
																							}
																							break;
																						}
																						goto IL_043a;
																						IL_0482:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_043a:
																						if (10 >= b)
																						{
																							goto IL_0445;
																						}
																						goto IL_0466;
																						IL_0445:
																						if (10 > b)
																						{
																							goto end_IL_0307;
																						}
																						goto IL_0453;
																						IL_0453:
																						num5--;
																						break;
																						IL_0466:
																						if (11 < b)
																						{
																							goto end_IL_0307;
																						}
																						goto IL_0474;
																						IL_0474:
																						if (11 > b)
																						{
																							goto end_IL_0307;
																						}
																						goto IL_0482;
																					}
																					break;
																				}
																				goto IL_049e;
																				IL_0703:
																				array[num5 - 2] = 0;
																				goto IL_0717;
																				IL_049e:
																				if (6 <= b)
																				{
																					goto IL_04a9;
																				}
																				goto IL_0510;
																				IL_04a9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04e9;
																				IL_04e9:
																				array[num5 - 2] = 0;
																				goto IL_04fd;
																				IL_04fd:
																				num5--;
																				break;
																				IL_0510:
																				if (3 >= b)
																				{
																					goto IL_051e;
																				}
																				num = 93;
																				goto IL_0629;
																				IL_051e:
																				if (3 > b)
																				{
																					goto IL_052c;
																				}
																				goto IL_05cd;
																				IL_052c:
																				if (1 >= b)
																				{
																					goto IL_0537;
																				}
																				goto IL_054a;
																				IL_0537:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0307;
																				IL_054a:
																				if (2 < b)
																				{
																					goto end_IL_0307;
																				}
																				goto IL_0558;
																				IL_0558:
																				if (2 > b)
																				{
																					goto end_IL_0307;
																				}
																				goto IL_0566;
																				IL_0566:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05a6;
																				IL_05a6:
																				array[num5 - 2] = 0;
																				goto IL_05ba;
																				IL_05ba:
																				num5--;
																				break;
																				IL_05cd:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05f6;
																				IL_05f6:
																				ptr2 += 8;
																				num = 72;
																				goto IL_060d;
																				IL_060d:
																				num5--;
																				break;
																				IL_0717:
																				num5--;
																				break;
																				IL_0629:
																				if (4 < b)
																				{
																					goto IL_0637;
																				}
																				goto IL_06b8;
																				IL_0637:
																				if (5 < b)
																				{
																					goto end_IL_0307;
																				}
																				goto IL_0645;
																				IL_0645:
																				if (5 > b)
																				{
																					goto end_IL_0307;
																				}
																				goto IL_0653;
																				IL_0653:
																				array[num5] = 0;
																				goto IL_0661;
																				IL_0661:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0684;
																				IL_0684:
																				array2[num5] = null;
																				goto IL_068e;
																				IL_068e:
																				num5++;
																				num = 74;
																				goto IL_06a5;
																				IL_06a5:
																				ptr2 += 8;
																				break;
																				IL_06b8:
																				if (4 > b)
																				{
																					goto end_IL_0307;
																				}
																				goto IL_06c3;
																				IL_06c3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0703;
																			}
																			goto end_IL_0317;
																			continue;
																			end_IL_0307:
																			break;
																			IL_0307:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_074a;
																	IL_0766:
																	ptr2 += 8;
																	break;
																	IL_0758:
																	num5++;
																	goto IL_0766;
																	IL_074a:
																	array[num5] = 0;
																	goto IL_0758;
																	continue;
																	end_IL_0317:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0833;
													IL_0833:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0774:
													break;
												}
												continue;
												end_IL_0787:
												break;
											}
											continue;
											end_IL_0791:
											break;
										}
										continue;
										end_IL_079c:
										break;
									}
									continue;
									end_IL_07b1:
									break;
								}
								continue;
								end_IL_07cf:
								break;
							}
							continue;
							end_IL_07e8:
							break;
						}
						continue;
						end_IL_07f8:
						break;
					}
					continue;
					end_IL_0808:
					break;
				}
				continue;
				end_IL_0818:
				break;
			}
		}
	}

	private static double IPrincipalgetPreviousApplicationIdentity(double double_1)
	{
		return Math.Tanh(double_1);
	}

	private unsafe void method_2()
	{
		int num = 278;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					num = 248;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								num = 121;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											object[] array5 = new object[1];
											num = 183;
											while (true)
											{
												array5[0] = this;
												while (true)
												{
													byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnabledForAnyListenerPoprefpopipopref.GetResourceSetRijndael);
													while (true)
													{
														byte* ptr2 = ptr;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																IL_05a3:
																byte b = *ptr2;
																while (true)
																{
																	IL_0593:
																	ptr2++;
																	while (true)
																	{
																		IL_0583:
																		if (b >= 1)
																		{
																			while (b <= 35)
																			{
																				while (true)
																				{
																					IL_0563:
																					if (18 >= b)
																					{
																						while (true)
																						{
																							IL_0553:
																							if (18 > b)
																							{
																								while (true)
																								{
																									IL_0546:
																									if (9 < b)
																									{
																										while (true)
																										{
																											IL_0536:
																											if (13 >= b)
																											{
																												while (true)
																												{
																													IL_0526:
																													if (13 <= b)
																													{
																														while (true)
																														{
																															IL_050b:
																															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																															while (true)
																															{
																																IL_04fb:
																																array[num6] = 1;
																																while (true)
																																{
																																	IL_04eb:
																																	num6++;
																																	while (true)
																																	{
																																		IL_04d2:
																																		ptr2 += 16;
																																		num = 300;
																																		while (num != 300)
																																		{
																																			if (num != 1281)
																																			{
																																				goto IL_0805;
																																			}
																																			switch (num)
																																			{
																																			case 125:
																																				goto IL_04d2;
																																			case 232:
																																				goto IL_04eb;
																																			case 254:
																																				goto IL_04fb;
																																			case 267:
																																			case 273:
																																				goto IL_050b;
																																			case 122:
																																				goto IL_0526;
																																			case 105:
																																				goto IL_0536;
																																			case 90:
																																				goto IL_0546;
																																			case 177:
																																				goto IL_0553;
																																			case 165:
																																				goto IL_0563;
																																			case 168:
																																				goto IL_0573;
																																			case 20:
																																				goto IL_0583;
																																			case 200:
																																				goto IL_0593;
																																			case 47:
																																			case 65:
																																				goto IL_05a3;
																																			case 221:
																																				goto IL_05ae;
																																			case 116:
																																			case 213:
																																				goto IL_05b9;
																																			case 166:
																																				goto IL_05f9;
																																			case 156:
																																				goto IL_060d;
																																			case 280:
																																				goto IL_0620;
																																			case 173:
																																				goto IL_062e;
																																			case 117:
																																			case 162:
																																				goto IL_0639;
																																			case 144:
																																				goto IL_0647;
																																			case 271:
																																				goto IL_066a;
																																			case 11:
																																				goto IL_0674;
																																			case 97:
																																				goto IL_0682;
																																			case 5:
																																				goto IL_0695;
																																			case 95:
																																				goto IL_06a3;
																																			case 141:
																																			case 262:
																																				goto IL_06b7;
																																			case 88:
																																				goto IL_06f7;
																																			case 29:
																																				goto IL_070b;
																																			case 79:
																																				goto IL_071e;
																																			case 49:
																																				goto IL_072c;
																																			case 103:
																																			case 275:
																																				goto IL_073a;
																																			case 30:
																																				goto IL_0753;
																																			case 111:
																																				goto IL_0761;
																																			case 202:
																																				goto IL_076f;
																																			case 163:
																																				goto IL_078b;
																																			case 26:
																																				goto IL_0799;
																																			case 62:
																																			case 155:
																																				goto IL_07a7;
																																			case 140:
																																				goto IL_07d0;
																																			case 6:
																																				goto IL_07e3;
																																			case 209:
																																				goto IL_07fa;
																																			case 139:
																																			case 238:
																																				goto IL_0805;
																																			case 256:
																																				goto IL_0845;
																																			case 46:
																																				goto IL_0859;
																																			case 226:
																																				goto IL_086c;
																																			case 102:
																																				goto IL_087a;
																																			case 93:
																																			case 257:
																																				goto IL_0888;
																																			case 161:
																																				goto IL_08c8;
																																			case 128:
																																				goto IL_08dc;
																																			case 284:
																																				goto IL_08ef;
																																			case 192:
																																				goto IL_08fa;
																																			case 67:
																																				goto IL_090a;
																																			case 63:
																																			case 261:
																																				goto IL_0918;
																																			case 255:
																																				goto IL_0961;
																																			case 282:
																																				goto IL_0975;
																																			case 287:
																																				goto IL_0988;
																																			case 224:
																																			case 270:
																																				goto IL_0996;
																																			case 291:
																																				goto IL_09a9;
																																			case 199:
																																				goto IL_09bc;
																																			case 113:
																																				goto IL_09c7;
																																			case 55:
																																				goto IL_09d5;
																																			case 135:
																																				goto IL_09e8;
																																			case 157:
																																			case 194:
																																				goto IL_09f6;
																																			case 1:
																																				goto IL_0a0a;
																																			case 71:
																																				goto IL_0a5e;
																																			case 240:
																																				goto IL_0a6c;
																																			case 243:
																																				goto IL_0a7f;
																																			case 245:
																																				goto IL_0a8d;
																																			case 159:
																																			case 190:
																																				goto IL_0a9b;
																																			case 292:
																																				goto IL_0afd;
																																			case 104:
																																				goto IL_0b10;
																																			case 85:
																																				goto IL_0b1e;
																																			case 35:
																																				goto IL_0b29;
																																			case 44:
																																				goto IL_0b37;
																																			case 52:
																																			case 223:
																																				goto IL_0b45;
																																			case 196:
																																			case 212:
																																				goto IL_0b5d;
																																			case 208:
																																				goto IL_0b9e;
																																			case 228:
																																				goto IL_0bb2;
																																			case 120:
																																				goto IL_0bc5;
																																			case 98:
																																				goto IL_0bd0;
																																			case 74:
																																				goto IL_0bde;
																																			case 8:
																																			case 99:
																																				goto IL_0bec;
																																			case 195:
																																				goto IL_0c04;
																																			case 268:
																																				goto IL_0c12;
																																			case 38:
																																				goto IL_0c20;
																																			case 263:
																																				goto IL_0c33;
																																			case 40:
																																			case 124:
																																				goto IL_0c41;
																																			case 276:
																																				goto IL_0c93;
																																			case 172:
																																			case 290:
																																				goto IL_0caf;
																																			case 28:
																																				goto IL_0ce7;
																																			case 80:
																																				goto IL_0cfb;
																																			case 51:
																																				goto IL_0d0e;
																																			case 75:
																																				goto IL_0d1c;
																																			case 274:
																																				goto IL_0d2a;
																																			case 236:
																																				goto IL_0d38;
																																			case 293:
																																				goto IL_0d46;
																																			case 83:
																																			case 218:
																																				goto IL_0d51;
																																			case 7:
																																				goto IL_0d89;
																																			case 115:
																																				goto IL_0d9d;
																																			case 283:
																																				goto IL_0db0;
																																			case 167:
																																				goto IL_0dbe;
																																			case 138:
																																			case 219:
																																				goto IL_0dcc;
																																			case 9:
																																				goto IL_0de0;
																																			case 250:
																																				goto IL_0e1f;
																																			case 187:
																																				goto IL_0e32;
																																			case 118:
																																				goto IL_0e3d;
																																			case 42:
																																			case 84:
																																				goto IL_0e4b;
																																			case 170:
																																				goto IL_0e5f;
																																			case 66:
																																				goto IL_0e9e;
																																			case 182:
																																				goto IL_0eb1;
																																			case 68:
																																				goto IL_0ebf;
																																			case 69:
																																			case 215:
																																				goto IL_0ecd;
																																			case 107:
																																				goto IL_0f0d;
																																			case 181:
																																				goto IL_0f21;
																																			case 78:
																																				goto IL_0f3d;
																																			case 72:
																																			case 286:
																																				goto IL_0f48;
																																			case 244:
																																				goto IL_0f88;
																																			case 130:
																																				goto IL_0f9c;
																																			case 265:
																																				goto IL_0faf;
																																			case 76:
																																				goto IL_0fbd;
																																			case 53:
																																			case 251:
																																				goto IL_0fc8;
																																			case 203:
																																				goto IL_0fe1;
																																			case 214:
																																				goto IL_0fef;
																																			case 153:
																																				goto IL_0ffd;
																																			case 231:
																																				goto IL_1010;
																																			case 193:
																																				goto IL_101e;
																																			case 132:
																																			case 142:
																																				goto IL_102c;
																																			case 45:
																																				goto IL_1055;
																																			case 169:
																																				goto IL_1063;
																																			case 17:
																																				goto IL_107f;
																																			case 189:
																																				goto IL_108d;
																																			case 242:
																																			case 253:
																																				goto IL_109b;
																																			case 241:
																																				goto IL_10af;
																																			case 126:
																																				goto IL_10ee;
																																			case 89:
																																			case 137:
																																				goto IL_1101;
																																			case 234:
																																				goto IL_110b;
																																			case 176:
																																				goto IL_1119;
																																			case 112:
																																				goto IL_112c;
																																			case 198:
																																				goto IL_113a;
																																			case 14:
																																				goto IL_1148;
																																			case 151:
																																				goto IL_1156;
																																			case 19:
																																				goto IL_1164;
																																			case 59:
																																				goto IL_1172;
																																			case 123:
																																			case 239:
																																				goto IL_1180;
																																			case 264:
																																				goto IL_1194;
																																			case 185:
																																				goto IL_11e1;
																																			case 147:
																																				goto IL_11ef;
																																			case 201:
																																			case 260:
																																				goto IL_1202;
																																			case 150:
																																				goto IL_1242;
																																			case 288:
																																				goto IL_125f;
																																			case 149:
																																				goto IL_1272;
																																			case 96:
																																				goto IL_1289;
																																			case 27:
																																			case 36:
																																				goto IL_1297;
																																			case 87:
																																				goto IL_12bf;
																																			case 0:
																																			case 101:
																																				goto IL_12d2;
																																			case 252:
																																				goto IL_12e6;
																																			case 222:
																																				goto IL_1325;
																																			case 37:
																																				goto IL_1338;
																																			case 143:
																																				goto IL_1343;
																																			case 145:
																																				goto IL_134e;
																																			case 82:
																																			case 285:
																																				goto IL_135c;
																																			case 70:
																																				goto IL_1378;
																																			case 54:
																																				goto IL_138f;
																																			case 229:
																																				goto IL_13ab;
																																			case 160:
																																				goto IL_13b6;
																																			case 43:
																																				goto IL_13c4;
																																			case 18:
																																			case 91:
																																				goto IL_13d2;
																																			case 22:
																																				goto IL_13fa;
																																			case 61:
																																			case 119:
																																				goto IL_140a;
																																			case 129:
																																				goto IL_1427;
																																			case 2:
																																				goto IL_1466;
																																			case 3:
																																			case 12:
																																			case 13:
																																			case 16:
																																			case 23:
																																			case 24:
																																			case 33:
																																			case 34:
																																			case 39:
																																			case 41:
																																			case 48:
																																			case 57:
																																			case 58:
																																			case 77:
																																			case 92:
																																			case 94:
																																			case 106:
																																			case 127:
																																			case 131:
																																			case 134:
																																			case 146:
																																			case 152:
																																			case 178:
																																			case 188:
																																			case 204:
																																			case 206:
																																			case 211:
																																			case 216:
																																			case 217:
																																			case 230:
																																			case 235:
																																			case 237:
																																			case 246:
																																			case 258:
																																			case 259:
																																			case 266:
																																			case 281:
																																			case 289:
																																				goto end_IL_0573;
																																			case 10:
																																			case 15:
																																			case 21:
																																			case 31:
																																			case 50:
																																			case 56:
																																			case 64:
																																			case 73:
																																			case 81:
																																			case 86:
																																			case 100:
																																			case 108:
																																			case 114:
																																			case 133:
																																			case 136:
																																			case 154:
																																			case 158:
																																			case 164:
																																			case 171:
																																			case 174:
																																			case 175:
																																			case 180:
																																			case 184:
																																			case 191:
																																			case 197:
																																			case 205:
																																			case 207:
																																			case 210:
																																			case 220:
																																			case 225:
																																			case 227:
																																			case 233:
																																			case 247:
																																			case 249:
																																			case 269:
																																			case 272:
																																			case 279:
																																				goto end_IL_04bf;
																																			case 25:
																																				goto end_IL_1489;
																																			case 179:
																																				goto end_IL_149c;
																																			case 183:
																																				goto end_IL_14a6;
																																			case 186:
																																				goto end_IL_14b1;
																																			case 109:
																																				goto end_IL_14c1;
																																			case 121:
																																				goto end_IL_14da;
																																			case 60:
																																				goto end_IL_14ea;
																																			case 110:
																																				goto end_IL_14fa;
																																			case 248:
																																				goto end_IL_1505;
																																			case 148:
																																				goto end_IL_1515;
																																			case 277:
																																				goto end_IL_1525;
																																			case 278:
																																				goto end_IL_153e;
																																			case 4:
																																			case 32:
																																				return;
																																			}
																																			continue;
																																			end_IL_04bf:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_09bc;
																													IL_0afd:
																													num6 -= 2;
																													break;
																													IL_09bc:
																													if (11 < b)
																													{
																														goto IL_09c7;
																													}
																													goto IL_09e8;
																													IL_09c7:
																													if (12 < b)
																													{
																														goto end_IL_0573;
																													}
																													goto IL_09d5;
																													IL_09d5:
																													if (12 > b)
																													{
																														goto end_IL_0573;
																													}
																													break;
																													IL_09e8:
																													if (11 <= b)
																													{
																														goto IL_09f6;
																													}
																													goto IL_0a7f;
																													IL_09f6:
																													array[num6 - 2] = 0;
																													goto IL_0a0a;
																													IL_0a0a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																													goto IL_0a5e;
																													IL_0a5e:
																													num6--;
																													goto IL_0a6c;
																													IL_0a6c:
																													ptr2 += 8;
																													break;
																													IL_0a7f:
																													if (10 < b)
																													{
																														goto end_IL_0573;
																													}
																													goto IL_0a8d;
																													IL_0a8d:
																													if (10 > b)
																													{
																														goto end_IL_0573;
																													}
																													goto IL_0a9b;
																													IL_0a9b:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0afd;
																												}
																												break;
																											}
																											goto IL_0b10;
																											IL_0c93:
																											num6--;
																											break;
																											IL_0b10:
																											if (15 >= b)
																											{
																												goto IL_0b1e;
																											}
																											goto IL_0bc5;
																											IL_0b1e:
																											if (15 > b)
																											{
																												goto IL_0b29;
																											}
																											goto IL_0b5d;
																											IL_0b29:
																											if (14 < b)
																											{
																												goto end_IL_0573;
																											}
																											goto IL_0b37;
																											IL_0b37:
																											if (14 > b)
																											{
																												goto end_IL_0573;
																											}
																											goto IL_0b45;
																											IL_0b45:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											break;
																											IL_0b5d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																											goto IL_0b9e;
																											IL_0b9e:
																											array[num6 - 2] = 0;
																											goto IL_0bb2;
																											IL_0bb2:
																											num6--;
																											break;
																											IL_0bc5:
																											if (16 < b)
																											{
																												goto IL_0bd0;
																											}
																											goto IL_0c33;
																											IL_0bd0:
																											if (17 < b)
																											{
																												goto end_IL_0573;
																											}
																											goto IL_0bde;
																											IL_0bde:
																											if (17 > b)
																											{
																												goto end_IL_0573;
																											}
																											goto IL_0bec;
																											IL_0bec:
																											array2[num6] = array5[*(int*)(ptr2 + num3)];
																											goto IL_0c04;
																											IL_0c04:
																											array[num6] = 5;
																											goto IL_0c12;
																											IL_0c12:
																											num6++;
																											goto IL_0c20;
																											IL_0c20:
																											ptr2 += 8;
																											break;
																											IL_0c33:
																											if (16 > b)
																											{
																												goto end_IL_0573;
																											}
																											goto IL_0c41;
																											IL_0c41:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0c93;
																										}
																										break;
																									}
																									goto IL_05ae;
																									IL_0918:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									num = 255;
																									goto IL_0961;
																									IL_05ae:
																									if (9 <= b)
																									{
																										goto IL_05b9;
																									}
																									goto IL_0620;
																									IL_05b9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_05f9;
																									IL_05f9:
																									array[num6 - 2] = 0;
																									goto IL_060d;
																									IL_060d:
																									num6--;
																									break;
																									IL_0620:
																									if (4 >= b)
																									{
																										goto IL_062e;
																									}
																									goto IL_07e3;
																									IL_062e:
																									if (4 <= b)
																									{
																										goto IL_0639;
																									}
																									goto IL_0695;
																									IL_0639:
																									array[num6] = 0;
																									goto IL_0647;
																									IL_0647:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_066a;
																									IL_066a:
																									array2[num6] = null;
																									goto IL_0674;
																									IL_0674:
																									num6++;
																									goto IL_0682;
																									IL_0682:
																									ptr2 += 8;
																									break;
																									IL_0695:
																									if (2 >= b)
																									{
																										goto IL_06a3;
																									}
																									goto IL_078b;
																									IL_06a3:
																									if (2 <= b)
																									{
																										num = 141;
																										goto IL_06b7;
																									}
																									goto IL_071e;
																									IL_0961:
																									array[num6 - 2] = 0;
																									goto IL_0975;
																									IL_06b7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_06f7;
																									IL_06f7:
																									array[num6 - 2] = 0;
																									goto IL_070b;
																									IL_070b:
																									num6--;
																									break;
																									IL_071e:
																									if (1 < b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_072c;
																									IL_072c:
																									if (1 > b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_073a;
																									IL_073a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																									goto IL_0753;
																									IL_0753:
																									array[num6] = 0;
																									goto IL_0761;
																									IL_0761:
																									num6++;
																									goto IL_076f;
																									IL_076f:
																									ptr2 += 8;
																									num = 249;
																									break;
																									IL_078b:
																									if (3 < b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_0799;
																									IL_0799:
																									if (3 > b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_07a7;
																									IL_07a7:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_07d0;
																									IL_07d0:
																									ptr2 += 8;
																									goto IL_09a9;
																									IL_09a9:
																									num6--;
																									break;
																									IL_07e3:
																									if (6 >= b)
																									{
																										num = 209;
																										goto IL_07fa;
																									}
																									goto IL_08ef;
																									IL_0975:
																									num6--;
																									break;
																									IL_07fa:
																									if (6 <= b)
																									{
																										goto IL_0805;
																									}
																									goto IL_086c;
																									IL_0805:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0845;
																									IL_0845:
																									array[num6 - 2] = 0;
																									goto IL_0859;
																									IL_0859:
																									num6--;
																									break;
																									IL_086c:
																									if (5 < b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_087a;
																									IL_087a:
																									if (5 > b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_0888;
																									IL_0888:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_08c8;
																									IL_08c8:
																									array[num6 - 2] = 0;
																									goto IL_08dc;
																									IL_08dc:
																									num6--;
																									break;
																									IL_08ef:
																									if (7 < b)
																									{
																										goto IL_08fa;
																									}
																									goto IL_090a;
																									IL_08fa:
																									if (8 < b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_0988;
																									IL_0988:
																									if (8 > b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_0996;
																									IL_0996:
																									num6--;
																									break;
																									IL_090a:
																									if (7 > b)
																									{
																										goto end_IL_0573;
																									}
																									goto IL_0918;
																								}
																								break;
																							}
																							num = 172;
																							goto IL_0caf;
																							IL_0ce7:
																							array[num6 - 1] = 5;
																							goto IL_0cfb;
																							IL_0cfb:
																							ptr2 += 8;
																							break;
																							IL_0caf:
																							array2[num6 - 1] = ((delegate*<Class179, GameObject>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 1]);
																							goto IL_0ce7;
																						}
																						break;
																					}
																					goto IL_0d0e;
																					IL_13d2:
																					((Class179)array2[num6 - 2]).gameObject_0 = (GameObject)array2[num6 - 1];
																					goto IL_13fa;
																					IL_0d0e:
																					if (27 >= b)
																					{
																						goto IL_0d1c;
																					}
																					goto IL_112c;
																					IL_0d1c:
																					if (27 > b)
																					{
																						goto IL_0d2a;
																					}
																					goto IL_1101;
																					IL_0d2a:
																					if (22 < b)
																					{
																						goto IL_0d38;
																					}
																					num = 78;
																					goto IL_0f3d;
																					IL_0d38:
																					if (24 >= b)
																					{
																						goto IL_0d46;
																					}
																					goto IL_0e32;
																					IL_0d46:
																					if (24 <= b)
																					{
																						goto IL_0d51;
																					}
																					goto IL_0db0;
																					IL_0d51:
																					array2[num6 - 1] = ((delegate*<Class179, GameObject>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 1]);
																					goto IL_0d89;
																					IL_0d89:
																					array[num6 - 1] = 5;
																					goto IL_0d9d;
																					IL_0d9d:
																					ptr2 += 8;
																					break;
																					IL_0db0:
																					if (23 < b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_0dbe;
																					IL_0dbe:
																					if (23 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_0dcc;
																					IL_0dcc:
																					array[num6 - 1] = 0;
																					goto IL_0de0;
																					IL_0de0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0e1f;
																					IL_0e1f:
																					ptr2 += 8;
																					break;
																					IL_0e32:
																					if (25 >= b)
																					{
																						goto IL_0e3d;
																					}
																					goto IL_0eb1;
																					IL_0e3d:
																					if (25 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_0e4b;
																					IL_0e4b:
																					array[num6 - 1] = 3;
																					goto IL_0e5f;
																					IL_0e5f:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_0e9e;
																					IL_0e9e:
																					ptr2 += 8;
																					break;
																					IL_0eb1:
																					if (26 < b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_0ebf;
																					IL_0ebf:
																					if (26 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_0ecd;
																					IL_0ecd:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0f0d;
																					IL_0f0d:
																					array[num6 - 2] = 3;
																					goto IL_0f21;
																					IL_0f21:
																					num6--;
																					break;
																					IL_13fa:
																					num6 -= 2;
																					break;
																					IL_0f3d:
																					if (22 <= b)
																					{
																						goto IL_0f48;
																					}
																					goto IL_0faf;
																					IL_0f48:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0f88;
																					IL_0f88:
																					array[num6 - 2] = 3;
																					goto IL_0f9c;
																					IL_0f9c:
																					num6--;
																					break;
																					IL_0faf:
																					if (20 >= b)
																					{
																						goto IL_0fbd;
																					}
																					goto IL_107f;
																					IL_0fbd:
																					if (20 <= b)
																					{
																						goto IL_0fc8;
																					}
																					goto IL_1010;
																					IL_0fc8:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																					goto IL_0fe1;
																					IL_0fe1:
																					array[num6] = 3;
																					goto IL_0fef;
																					IL_0fef:
																					num6++;
																					goto IL_0ffd;
																					IL_0ffd:
																					ptr2 += 16;
																					break;
																					IL_1010:
																					if (19 < b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_101e;
																					IL_101e:
																					if (19 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_102c;
																					IL_102c:
																					((delegate*<UnityEngine.Object, void>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 1]);
																					goto IL_1055;
																					IL_1055:
																					num6--;
																					goto IL_1063;
																					IL_1063:
																					ptr2 += 8;
																					num = 21;
																					break;
																					IL_107f:
																					if (21 < b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_108d;
																					IL_108d:
																					if (21 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_109b;
																					IL_109b:
																					array[num6 - 1] = 3;
																					goto IL_10af;
																					IL_10af:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_10ee;
																					IL_10ee:
																					ptr2 += 8;
																					break;
																					IL_1101:
																					array2[num6] = null;
																					goto IL_110b;
																					IL_110b:
																					array[num6] = 5;
																					goto IL_1119;
																					IL_1119:
																					num6++;
																					break;
																					IL_112c:
																					if (31 >= b)
																					{
																						goto IL_113a;
																					}
																					goto IL_1338;
																					IL_113a:
																					if (31 > b)
																					{
																						goto IL_1148;
																					}
																					goto IL_12d2;
																					IL_1148:
																					if (29 >= b)
																					{
																						goto IL_1156;
																					}
																					goto IL_1272;
																					IL_1156:
																					if (29 > b)
																					{
																						goto IL_1164;
																					}
																					goto IL_1202;
																					IL_1164:
																					if (28 < b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_1172;
																					IL_1172:
																					if (28 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_1180;
																					IL_1180:
																					array[num6 - 2] = 0;
																					goto IL_1194;
																					IL_1194:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])((GameObject)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																					goto IL_11e1;
																					IL_11e1:
																					num6--;
																					goto IL_11ef;
																					IL_11ef:
																					ptr2 += 8;
																					break;
																					IL_1202:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_1242;
																					IL_1242:
																					array[num6 - 2] = 3;
																					num = 288;
																					goto IL_125f;
																					IL_125f:
																					num6--;
																					break;
																					IL_1272:
																					if (30 < b)
																					{
																						goto end_IL_0573;
																					}
																					num = 96;
																					goto IL_1289;
																					IL_140a:
																					array[num6 - 1] = 3;
																					num = 129;
																					goto IL_1427;
																					IL_1289:
																					if (30 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_1297;
																					IL_1297:
																					((Class179)array2[num6 - 2]).gameObject_1 = (GameObject)array2[num6 - 1];
																					goto IL_12bf;
																					IL_12bf:
																					num6 -= 2;
																					break;
																					IL_12d2:
																					array[num6 - 1] = 3;
																					goto IL_12e6;
																					IL_12e6:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1325;
																					IL_1325:
																					ptr2 += 8;
																					break;
																					IL_1338:
																					if (33 < b)
																					{
																						goto IL_1343;
																					}
																					num = 229;
																					goto IL_13ab;
																					IL_1343:
																					if (34 >= b)
																					{
																						goto IL_134e;
																					}
																					goto IL_1378;
																					IL_134e:
																					if (34 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_135c;
																					IL_135c:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					break;
																					IL_1378:
																					if (35 < b)
																					{
																						goto end_IL_0573;
																					}
																					num = 54;
																					goto IL_138f;
																					IL_1466:
																					ptr2 += 8;
																					break;
																					IL_138f:
																					if (35 > b)
																					{
																					}
																					goto end_IL_0573;
																					IL_1427:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)GetTypeArrayTypeKind[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1466;
																					IL_13ab:
																					if (33 > b)
																					{
																						goto IL_13b6;
																					}
																					goto IL_140a;
																					IL_13b6:
																					if (32 < b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_13c4;
																					IL_13c4:
																					if (32 > b)
																					{
																						goto end_IL_0573;
																					}
																					goto IL_13d2;
																				}
																				goto end_IL_0583;
																				continue;
																				end_IL_0573:
																				break;
																				IL_0573:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_0583:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
															end_IL_1489:
															break;
														}
														continue;
														end_IL_149c:
														break;
													}
													continue;
													end_IL_14a6:
													break;
												}
												continue;
												end_IL_14b1:
												break;
											}
											continue;
											end_IL_14c1:
											break;
										}
										continue;
										end_IL_14da:
										break;
									}
									continue;
									end_IL_14ea:
									break;
								}
								continue;
								end_IL_14fa:
								break;
							}
							continue;
							end_IL_1505:
							break;
						}
						continue;
						end_IL_1515:
						break;
					}
					continue;
					end_IL_1525:
					break;
				}
				continue;
				end_IL_153e:
				break;
			}
		}
	}

	private static double PrivilegeLocalSiteString(double double_1)
	{
		return Math.Log(double_1);
	}

	private static bool HexadecimalInternalElementTypeE(Behaviour behaviour_0)
	{
		return behaviour_0.enabled;
	}

	private static double RemoveAccessRuleAllCOREFILENOTFOUND(double double_1)
	{
		return Math.Sin(double_1);
	}

	static Class179()
	{
		int num = 10;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 22;
			while (true)
			{
				if (num != 22)
				{
					if (num != 1003)
					{
						goto IL_009a;
					}
					switch (num)
					{
					case 10:
						goto end_IL_0064;
					case 0:
					case 2:
					case 4:
					case 5:
					case 6:
					case 8:
					case 9:
					case 11:
					case 12:
					case 14:
						goto IL_008f;
					case 1:
					case 13:
						goto IL_009a;
					case 3:
						return;
					case 7:
						return;
					case 15:
						return;
					}
					continue;
				}
				Class300.smethod_0();
				goto IL_008f;
				IL_008f:
				num = 13;
				goto IL_009a;
				IL_009a:
				num = 3;
				return;
				continue;
				end_IL_0064:
				break;
			}
		}
	}

	private static int SignedFileMoveBufferArea(double double_1)
	{
		return Convert.ToInt32(double_1);
	}

	private static void MProcessorArchitectureIA(bool bool_5)
	{
		IsActive = bool_5;
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 37;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 97;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PrimitiveValueGetProxiedType.StackFrameGacIdentityPermission);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 60;
															while (true)
															{
																IL_02c8:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_02a8:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0298:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0285:
																							if (8 > b)
																							{
																								num = 46;
																								while (true)
																								{
																									IL_0275:
																									if (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_0223:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_0204:
																													array[num5 - 2] = 0;
																													num = 117;
																													while (true)
																													{
																														if (num != 117)
																														{
																															if (num != 1098)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 30:
																																goto IL_0204;
																															case 19:
																															case 67:
																																goto IL_0223;
																															case 81:
																																goto IL_0265;
																															case 45:
																															case 46:
																																goto IL_0275;
																															case 15:
																																goto IL_0285;
																															case 75:
																															case 80:
																																goto IL_0298;
																															case 106:
																																goto IL_02a8;
																															case 94:
																																goto IL_02b8;
																															case 60:
																																goto IL_02c8;
																															case 9:
																																goto end_IL_02c8;
																															case 51:
																															case 93:
																																goto end_IL_02d8;
																															case 109:
																																goto IL_030f;
																															case 39:
																																goto IL_031d;
																															case 12:
																															case 90:
																																goto IL_032b;
																															case 104:
																																goto IL_034e;
																															case 56:
																																goto IL_035c;
																															case 110:
																																goto IL_0373;
																															case 26:
																															case 72:
																																goto IL_0386;
																															case 86:
																																goto IL_03e8;
																															case 1:
																																goto IL_03fb;
																															case 83:
																																goto IL_0406;
																															case 79:
																															case 100:
																																goto IL_0414;
																															case 48:
																															case 52:
																																goto IL_0439;
																															case 101:
																																goto IL_0452;
																															case 20:
																																goto IL_0465;
																															case 27:
																															case 55:
																																goto IL_0473;
																															case 42:
																																goto IL_0481;
																															case 76:
																															case 84:
																																goto IL_048c;
																															case 57:
																																goto IL_049a;
																															case 103:
																															case 107:
																																goto IL_04a8;
																															case 4:
																																goto IL_04c1;
																															case 23:
																																goto IL_04cf;
																															case 64:
																																goto IL_04dd;
																															case 3:
																															case 92:
																																goto IL_04f9;
																															case 62:
																																goto IL_0522;
																															case 82:
																																goto IL_0530;
																															case 73:
																																goto IL_0543;
																															case 53:
																																goto IL_054e;
																															case 77:
																																goto IL_0559;
																															case 74:
																																goto IL_0569;
																															case 31:
																															case 34:
																																goto IL_0574;
																															case 5:
																															case 8:
																															case 14:
																															case 17:
																															case 21:
																															case 22:
																															case 24:
																															case 25:
																															case 32:
																															case 35:
																															case 40:
																															case 41:
																															case 43:
																															case 66:
																															case 68:
																															case 69:
																															case 85:
																															case 88:
																															case 89:
																															case 91:
																															case 96:
																															case 99:
																															case 102:
																															case 105:
																															case 108:
																																goto end_IL_01f1;
																															case 2:
																															case 65:
																																goto IL_059e;
																															case 63:
																																goto IL_05ac;
																															case 11:
																																goto IL_05cf;
																															case 59:
																																goto IL_05d9;
																															case 49:
																																goto IL_05e7;
																															case 0:
																															case 6:
																															case 10:
																															case 13:
																															case 28:
																															case 29:
																															case 44:
																															case 47:
																															case 58:
																															case 61:
																															case 87:
																															case 95:
																															case 98:
																																goto end_IL_02f1;
																															case 7:
																																goto end_IL_05f5;
																															case 78:
																																goto end_IL_0608;
																															case 38:
																																goto end_IL_0612;
																															case 71:
																																goto end_IL_061d;
																															case 18:
																															case 54:
																																goto end_IL_0632;
																															case 97:
																																goto end_IL_0642;
																															case 16:
																															case 70:
																																goto end_IL_0652;
																															case 36:
																																goto end_IL_0662;
																															case 37:
																																goto end_IL_067b;
																															case 33:
																															case 50:
																																goto IL_0696;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_02f1;
																														continue;
																														end_IL_01f1:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																											IL_0265:;
																										}
																										break;
																									}
																									goto IL_030f;
																									IL_0373:
																									ptr2 += 8;
																									goto end_IL_02f1;
																									IL_030f:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_031d;
																									IL_031d:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_032b;
																									IL_032b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_034e;
																									IL_034e:
																									array[num5] = 0;
																									goto IL_035c;
																									IL_035c:
																									num5++;
																									num = 110;
																									goto IL_0373;
																								}
																								break;
																							}
																							goto IL_0386;
																							IL_0386:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03e8;
																							IL_03e8:
																							num5 -= 2;
																							goto end_IL_02f1;
																						}
																						break;
																					}
																					goto IL_03fb;
																					IL_0439:
																					if (10 < b)
																					{
																						num = 21;
																						break;
																					}
																					goto IL_0452;
																					IL_03fb:
																					if (9 >= b)
																					{
																						goto IL_0406;
																					}
																					num = 48;
																					goto IL_0439;
																					IL_0406:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0414;
																					IL_0414:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02f1;
																					IL_0452:
																					if (10 <= b)
																					{
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_0465;
																			IL_05e7:
																			ptr2 += 8;
																			goto end_IL_02f1;
																			IL_0465:
																			if (5 > b)
																			{
																				goto IL_0473;
																			}
																			goto IL_059e;
																			IL_0473:
																			if (2 >= b)
																			{
																				goto IL_0481;
																			}
																			goto IL_0543;
																			IL_0481:
																			if (2 > b)
																			{
																				goto IL_048c;
																			}
																			goto IL_04f9;
																			IL_048c:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_049a;
																			IL_049a:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04a8;
																			IL_04a8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04c1;
																			IL_04c1:
																			array[num5] = 0;
																			goto IL_04cf;
																			IL_04cf:
																			num5++;
																			goto IL_04dd;
																			IL_04dd:
																			ptr2 += 8;
																			num = 44;
																			goto end_IL_02f1;
																			IL_04f9:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0522;
																			IL_0522:
																			ptr2 += 8;
																			goto IL_0530;
																			IL_0530:
																			num5--;
																			goto end_IL_02f1;
																			IL_0543:
																			if (3 < b)
																			{
																				goto IL_054e;
																			}
																			goto IL_0569;
																			IL_054e:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0559;
																			IL_0559:
																			if (4 <= b)
																			{
																				goto end_IL_02f1;
																			}
																			break;
																			IL_0569:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0574;
																			IL_0574:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02f1;
																			IL_059e:
																			array[num5] = 0;
																			goto IL_05ac;
																			IL_05ac:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05cf;
																			IL_05cf:
																			array2[num5] = null;
																			goto IL_05d9;
																			IL_05d9:
																			num5++;
																			goto IL_05e7;
																		}
																		break;
																		IL_02b8:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02f1;
																continue;
																end_IL_02c8:
																break;
															}
															continue;
															end_IL_02d8:
															break;
														}
														continue;
														end_IL_02f1:
														break;
													}
													continue;
												}
												goto IL_0696;
												IL_0696:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f5:
												break;
											}
											continue;
											end_IL_0608:
											break;
										}
										continue;
										end_IL_0612:
										break;
									}
									continue;
									end_IL_061d:
									break;
								}
								continue;
								end_IL_0632:
								break;
							}
							continue;
							end_IL_0642:
							break;
						}
						continue;
						end_IL_0652:
						break;
					}
					continue;
					end_IL_0662:
					break;
				}
				continue;
				end_IL_067b:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_1, int int_2)
	{
		int num = 20;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 38;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StaticIndexRangePartitionForArraysetHostCanGenerate.mhandleResolveSignature);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0214:
															byte b = *ptr2;
															while (true)
															{
																IL_0204:
																ptr2++;
																while (true)
																{
																	IL_01f4:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01d4:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01c7:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (5 >= b)
																								{
																									num = 93;
																									while (true)
																									{
																										if (num != 93)
																										{
																											if (num != 1074)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 70:
																												goto IL_01a4;
																											case 67:
																												goto IL_01b7;
																											case 53:
																											case 73:
																												goto IL_01c7;
																											case 52:
																												goto IL_01d4;
																											case 41:
																												goto IL_01e4;
																											case 3:
																												goto IL_01f4;
																											case 48:
																												goto IL_0204;
																											case 30:
																											case 40:
																												goto IL_0214;
																											case 57:
																											case 69:
																												goto IL_021f;
																											case 28:
																												goto IL_022a;
																											case 6:
																												goto IL_023a;
																											case 84:
																												goto IL_0248;
																											case 13:
																											case 22:
																												goto IL_025f;
																											case 82:
																											case 85:
																												goto IL_027b;
																											case 25:
																												goto IL_0289;
																											case 54:
																												goto IL_02ac;
																											case 36:
																												goto IL_02b6;
																											case 5:
																												goto IL_02c4;
																											case 34:
																											case 68:
																												goto IL_02e5;
																											case 72:
																												goto IL_0306;
																											case 58:
																											case 65:
																												goto IL_0314;
																											case 77:
																												goto IL_0322;
																											case 14:
																											case 31:
																												goto IL_0330;
																											case 63:
																												goto IL_039e;
																											case 46:
																												goto IL_03b1;
																											case 83:
																												goto IL_03bf;
																											case 9:
																												goto IL_03d2;
																											case 80:
																												goto IL_03e0;
																											case 17:
																											case 47:
																												goto IL_03ee;
																											case 35:
																												goto IL_042e;
																											case 66:
																												goto IL_0442;
																											case 4:
																											case 61:
																												goto IL_0455;
																											case 21:
																												goto IL_047e;
																											case 43:
																												goto IL_048c;
																											case 0:
																											case 11:
																											case 15:
																											case 16:
																											case 24:
																											case 29:
																											case 37:
																											case 42:
																											case 51:
																											case 55:
																											case 74:
																											case 75:
																											case 76:
																											case 78:
																											case 81:
																												goto end_IL_0191;
																											case 2:
																												goto IL_04c8;
																											case 62:
																												goto IL_04d6;
																											case 64:
																												goto IL_04e4;
																											case 8:
																											case 10:
																											case 12:
																											case 18:
																											case 23:
																											case 26:
																											case 32:
																											case 39:
																											case 49:
																											case 50:
																											case 79:
																												goto end_IL_01b7;
																											case 60:
																												goto end_IL_04f2;
																											case 86:
																												goto end_IL_0505;
																											case 33:
																												goto end_IL_050f;
																											case 71:
																												goto end_IL_051a;
																											case 1:
																												goto end_IL_052f;
																											case 7:
																											case 56:
																												goto end_IL_0544;
																											case 38:
																												goto end_IL_0554;
																											case 45:
																											case 59:
																												goto end_IL_0564;
																											case 19:
																												goto end_IL_0574;
																											case 20:
																												goto end_IL_058d;
																											case 27:
																											case 44:
																												goto IL_05a8;
																											}
																											continue;
																										}
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_02e5;
																										IL_02e5:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										num = 32;
																										goto end_IL_01b7;
																										continue;
																										end_IL_0191:
																										break;
																									}
																									break;
																									IL_01a4:;
																								}
																								goto end_IL_01e4;
																								continue;
																								end_IL_01b7:
																								break;
																								IL_01b7:;
																							}
																							break;
																						}
																						goto IL_021f;
																						IL_025f:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						break;
																						IL_021f:
																						if (7 >= b)
																						{
																							goto IL_022a;
																						}
																						goto IL_023a;
																						IL_022a:
																						if (7 > b)
																						{
																							goto end_IL_01e4;
																						}
																						goto IL_027b;
																						IL_027b:
																						array[num6] = 0;
																						goto IL_0289;
																						IL_0289:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_02ac;
																						IL_02ac:
																						array2[num6] = null;
																						goto IL_02b6;
																						IL_02b6:
																						num6++;
																						goto IL_02c4;
																						IL_02c4:
																						ptr2 += 8;
																						break;
																						IL_023a:
																						if (8 < b)
																						{
																							goto end_IL_01e4;
																						}
																						goto IL_0248;
																						IL_0248:
																						if (8 > b)
																						{
																							goto end_IL_01e4;
																						}
																						num = 22;
																						goto IL_025f;
																					}
																					break;
																				}
																				goto IL_0306;
																				IL_048c:
																				num6--;
																				break;
																				IL_0306:
																				if (4 > b)
																				{
																					goto IL_0314;
																				}
																				goto IL_0455;
																				IL_0314:
																				if (2 >= b)
																				{
																					goto IL_0322;
																				}
																				goto IL_03d2;
																				IL_0322:
																				if (2 <= b)
																				{
																					goto IL_0330;
																				}
																				goto IL_03b1;
																				IL_0330:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_039e;
																				IL_039e:
																				num6 -= 2;
																				break;
																				IL_03b1:
																				if (1 < b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03bf;
																				IL_03bf:
																				if (1 > b)
																				{
																				}
																				goto end_IL_01e4;
																				IL_03d2:
																				if (3 < b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03e0;
																				IL_03e0:
																				if (3 > b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03ee;
																				IL_03ee:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_042e;
																				IL_042e:
																				array[num6 - 2] = 0;
																				goto IL_0442;
																				IL_0442:
																				num6--;
																				break;
																				IL_0455:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_047e;
																				IL_047e:
																				ptr2 += 8;
																				goto IL_048c;
																			}
																			goto end_IL_01f4;
																			continue;
																			end_IL_01e4:
																			break;
																			IL_01e4:;
																		}
																	}
																	else
																	{
																		num = 29;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c8;
																	IL_04d6:
																	num6++;
																	goto IL_04e4;
																	IL_04e4:
																	ptr2 += 8;
																	break;
																	IL_04c8:
																	array[num6] = 0;
																	goto IL_04d6;
																	continue;
																	end_IL_01f4:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a8;
													IL_05a8:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04f2:
													break;
												}
												continue;
												end_IL_0505:
												break;
											}
											continue;
											end_IL_050f:
											break;
										}
										continue;
										end_IL_051a:
										break;
									}
									continue;
									end_IL_052f:
									break;
								}
								continue;
								end_IL_0544:
								break;
							}
							continue;
							end_IL_0554:
							break;
						}
						continue;
						end_IL_0564:
						break;
					}
					continue;
					end_IL_0574:
					break;
				}
				continue;
				end_IL_058d:
				break;
			}
		}
	}

	private unsafe static int smethod_9(int int_1, int int_2)
	{
		int num = 4;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 96;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_1;
										while (true)
										{
											array3[1] = int_2;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ASSEMBLYFLAGSINITIALIZEDGetLastAccessTimeUtc.ICustomPropertyProviderProxyTransformer);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_02ad:
																byte b = *ptr2;
																while (true)
																{
																	IL_029d:
																	ptr2++;
																	while (true)
																	{
																		IL_028d:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_026d:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_0260:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_0250:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_0243:
																											if (2 <= b)
																											{
																												while (true)
																												{
																													IL_0201:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_01e2:
																														array[num5 - 2] = 0;
																														num = 112;
																														while (true)
																														{
																															if (num != 112)
																															{
																																if (num != 1093)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 33:
																																	goto IL_01e2;
																																case 22:
																																case 62:
																																	goto IL_0201;
																																case 5:
																																	goto IL_0243;
																																case 57:
																																case 89:
																																	goto IL_0250;
																																case 39:
																																	goto IL_0260;
																																case 60:
																																	goto IL_026d;
																																case 35:
																																	goto IL_027d;
																																case 51:
																																	goto IL_028d;
																																case 92:
																																	goto IL_029d;
																																case 28:
																																case 100:
																																	goto IL_02ad;
																																case 21:
																																	goto IL_02b8;
																																case 13:
																																	goto IL_02c6;
																																case 20:
																																case 30:
																																	goto IL_02d9;
																																case 34:
																																case 69:
																																	goto IL_02e9;
																																case 12:
																																	goto IL_02f7;
																																case 49:
																																	goto IL_0305;
																																case 2:
																																case 77:
																																	goto IL_0313;
																																case 90:
																																	goto IL_0358;
																																case 71:
																																	goto IL_037b;
																																case 70:
																																	goto IL_038e;
																																case 1:
																																	goto IL_039c;
																																case 91:
																																case 93:
																																	goto IL_03af;
																																case 45:
																																	goto IL_03bd;
																																case 66:
																																case 74:
																																	goto IL_03cb;
																																case 78:
																																	goto IL_03e2;
																																case 48:
																																case 76:
																																	goto IL_03f0;
																																case 41:
																																	goto IL_0430;
																																case 81:
																																	goto IL_0444;
																																case 82:
																																case 88:
																																	goto IL_0457;
																																case 7:
																																	goto IL_0479;
																																case 24:
																																	goto IL_0487;
																																case 54:
																																	goto IL_0495;
																																case 87:
																																	goto IL_04a8;
																																case 36:
																																	goto IL_04b3;
																																case 55:
																																case 99:
																																	goto IL_04c1;
																																case 8:
																																	goto IL_0501;
																																case 23:
																																	goto IL_0515;
																																case 101:
																																	goto IL_0528;
																																case 29:
																																	goto IL_0536;
																																case 11:
																																case 40:
																																	goto IL_0544;
																																case 102:
																																	goto IL_0560;
																																case 79:
																																	goto IL_0574;
																																case 103:
																																	goto IL_0587;
																																case 9:
																																case 27:
																																	goto IL_0592;
																																case 25:
																																	goto IL_05bb;
																																case 43:
																																	goto IL_05c9;
																																case 0:
																																case 14:
																																case 15:
																																case 16:
																																case 18:
																																case 19:
																																case 50:
																																case 52:
																																case 53:
																																case 58:
																																case 59:
																																case 61:
																																case 63:
																																case 65:
																																case 67:
																																case 68:
																																case 75:
																																case 80:
																																case 104:
																																	goto end_IL_027d;
																																case 47:
																																	goto IL_060c;
																																case 38:
																																	goto IL_061a;
																																case 94:
																																	goto IL_0628;
																																case 17:
																																case 26:
																																case 32:
																																case 44:
																																case 64:
																																case 72:
																																case 83:
																																case 85:
																																case 86:
																																case 97:
																																case 105:
																																	goto end_IL_01cf;
																																case 42:
																																	goto end_IL_0636;
																																case 46:
																																	goto end_IL_0649;
																																case 73:
																																	goto end_IL_0653;
																																case 98:
																																	goto end_IL_065e;
																																case 31:
																																	goto end_IL_0673;
																																case 10:
																																case 95:
																																	goto end_IL_0688;
																																case 6:
																																	goto end_IL_0698;
																																case 96:
																																	goto end_IL_06a8;
																																case 84:
																																	goto end_IL_06b8;
																																case 3:
																																	goto end_IL_06c8;
																																case 4:
																																	goto end_IL_06d3;
																																case 37:
																																case 56:
																																	goto IL_06ee;
																																}
																																continue;
																															}
																															num5--;
																															break;
																															continue;
																															end_IL_01cf:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_02b8;
																											IL_02c6:
																											if (1 <= b)
																											{
																											}
																											goto end_IL_027d;
																											IL_02b8:
																											if (1 < b)
																											{
																												goto end_IL_027d;
																											}
																											goto IL_02c6;
																										}
																										break;
																									}
																									goto IL_02e9;
																									IL_05c9:
																									num5--;
																									break;
																									IL_02e9:
																									if (3 < b)
																									{
																										goto IL_02f7;
																									}
																									goto IL_0587;
																									IL_02f7:
																									if (4 < b)
																									{
																										goto end_IL_027d;
																									}
																									goto IL_0305;
																									IL_0305:
																									if (4 > b)
																									{
																										goto end_IL_027d;
																									}
																									goto IL_0313;
																									IL_0313:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0560;
																									IL_0560:
																									array[num5 - 2] = 0;
																									goto IL_0574;
																									IL_0574:
																									num5--;
																									break;
																									IL_0587:
																									if (3 > b)
																									{
																										goto end_IL_027d;
																									}
																									goto IL_0592;
																									IL_0592:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05bb;
																									IL_05bb:
																									ptr2 += 8;
																									goto IL_05c9;
																								}
																								break;
																							}
																							goto IL_02d9;
																							IL_039c:
																							ptr2 += 8;
																							break;
																							IL_02d9:
																							array[num5] = 0;
																							goto IL_0358;
																							IL_0358:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_037b;
																							IL_037b:
																							array2[num5] = null;
																							num = 70;
																							goto IL_038e;
																							IL_038e:
																							num5++;
																							goto IL_039c;
																						}
																						break;
																					}
																					goto IL_03af;
																					IL_0536:
																					if (9 > b)
																					{
																						goto end_IL_027d;
																					}
																					goto IL_0544;
																					IL_03af:
																					if (7 >= b)
																					{
																						goto IL_03bd;
																					}
																					goto IL_04a8;
																					IL_03bd:
																					if (7 > b)
																					{
																						goto IL_03cb;
																					}
																					goto IL_0457;
																					IL_03cb:
																					if (6 < b)
																					{
																						goto end_IL_027d;
																					}
																					num = 78;
																					goto IL_03e2;
																					IL_0544:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_03e2:
																					if (6 > b)
																					{
																						goto end_IL_027d;
																					}
																					goto IL_03f0;
																					IL_03f0:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0430;
																					IL_0430:
																					array[num5 - 2] = 0;
																					goto IL_0444;
																					IL_0444:
																					num5--;
																					break;
																					IL_0457:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					num = 7;
																					goto IL_0479;
																					IL_0479:
																					array[num5] = 0;
																					goto IL_0487;
																					IL_0487:
																					num5++;
																					goto IL_0495;
																					IL_0495:
																					ptr2 += 8;
																					break;
																					IL_04a8:
																					if (8 >= b)
																					{
																						goto IL_04b3;
																					}
																					goto IL_0528;
																					IL_04b3:
																					if (8 > b)
																					{
																						goto end_IL_027d;
																					}
																					goto IL_04c1;
																					IL_04c1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0501;
																					IL_0501:
																					array[num5 - 2] = 0;
																					goto IL_0515;
																					IL_0515:
																					num5--;
																					break;
																					IL_0528:
																					if (9 < b)
																					{
																						goto end_IL_027d;
																					}
																					goto IL_0536;
																				}
																				goto end_IL_028d;
																				continue;
																				end_IL_027d:
																				break;
																				IL_027d:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_060c;
																		IL_0628:
																		ptr2 += 8;
																		break;
																		IL_061a:
																		num5++;
																		goto IL_0628;
																		IL_060c:
																		array[num5] = 0;
																		goto IL_061a;
																		continue;
																		end_IL_028d:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_06ee;
														IL_06ee:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0636:
														break;
													}
													continue;
													end_IL_0649:
													break;
												}
												continue;
												end_IL_0653:
												break;
											}
											continue;
											end_IL_065e:
											break;
										}
										continue;
										end_IL_0673:
										break;
									}
									continue;
									end_IL_0688:
									break;
								}
								continue;
								end_IL_0698:
								break;
							}
							continue;
							end_IL_06a8:
							break;
						}
						continue;
						end_IL_06b8:
						break;
					}
					continue;
					end_IL_06c8:
					break;
				}
				continue;
				end_IL_06d3:
				break;
			}
		}
	}

	private unsafe void method_3()
	{
		int num = 230;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 234;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ThreadStartExceptionStopRequested.getCompatibleFrameworksDataClientSponsor);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															IL_0668:
															byte b = *ptr2;
															while (true)
															{
																IL_0658:
																ptr2++;
																while (true)
																{
																	IL_0648:
																	if (b >= 1)
																	{
																		while (b <= 39)
																		{
																			while (true)
																			{
																				IL_0628:
																				if (20 >= b)
																				{
																					while (true)
																					{
																						IL_0618:
																						if (20 > b)
																						{
																							while (true)
																							{
																								IL_0608:
																								if (10 < b)
																								{
																									while (true)
																									{
																										IL_05f8:
																										if (15 >= b)
																										{
																											while (true)
																											{
																												IL_05eb:
																												if (15 > b)
																												{
																													while (true)
																													{
																														IL_05db:
																														if (12 < b)
																														{
																															while (true)
																															{
																																IL_05cb:
																																if (13 >= b)
																																{
																																	while (13 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_05a0:
																																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																																			while (true)
																																			{
																																				IL_0587:
																																				array[num6] = 1;
																																				num = 315;
																																				while (true)
																																				{
																																					IL_0577:
																																					num6++;
																																					while (true)
																																					{
																																						IL_055e:
																																						ptr2 += 16;
																																						num = 335;
																																						while (num != 335)
																																						{
																																							if (num != 1316)
																																							{
																																								goto IL_14ec;
																																							}
																																							switch (num)
																																							{
																																							case 188:
																																								goto IL_055e;
																																							case 315:
																																								goto IL_0577;
																																							case 201:
																																								goto IL_0587;
																																							case 68:
																																							case 96:
																																								goto IL_05a0;
																																							case 146:
																																								goto IL_05bb;
																																							case 285:
																																								goto IL_05cb;
																																							case 215:
																																								goto IL_05db;
																																							case 271:
																																								goto IL_05eb;
																																							case 38:
																																								goto IL_05f8;
																																							case 3:
																																								goto IL_0608;
																																							case 16:
																																								goto IL_0618;
																																							case 157:
																																								goto IL_0628;
																																							case 30:
																																								goto IL_0638;
																																							case 105:
																																								goto IL_0648;
																																							case 76:
																																								goto IL_0658;
																																							case 153:
																																							case 160:
																																								goto IL_0668;
																																							case 89:
																																							case 214:
																																								goto IL_0673;
																																							case 15:
																																								goto IL_06b4;
																																							case 104:
																																								goto IL_06c8;
																																							case 66:
																																							case 266:
																																								goto IL_06db;
																																							case 67:
																																								goto IL_06ef;
																																							case 263:
																																								goto IL_072e;
																																							case 292:
																																								goto IL_0741;
																																							case 312:
																																								goto IL_074f;
																																							case 251:
																																								goto IL_075d;
																																							case 8:
																																							case 248:
																																								goto IL_076b;
																																							case 59:
																																								goto IL_0779;
																																							case 129:
																																								goto IL_079d;
																																							case 91:
																																								goto IL_07ab;
																																							case 258:
																																								goto IL_07be;
																																							case 107:
																																								goto IL_07cc;
																																							case 83:
																																							case 301:
																																								goto IL_07da;
																																							case 182:
																																								goto IL_07f2;
																																							case 237:
																																								goto IL_0800;
																																							case 165:
																																							case 323:
																																								goto IL_080b;
																																							case 125:
																																								goto IL_0823;
																																							case 198:
																																								goto IL_083a;
																																							case 63:
																																								goto IL_0851;
																																							case 150:
																																								goto IL_0864;
																																							case 23:
																																								goto IL_0872;
																																							case 62:
																																							case 313:
																																								goto IL_0880;
																																							case 253:
																																								goto IL_08d2;
																																							case 311:
																																								goto IL_08ee;
																																							case 261:
																																								goto IL_08f9;
																																							case 7:
																																							case 95:
																																								goto IL_0907;
																																							case 115:
																																								goto IL_0930;
																																							case 238:
																																								goto IL_093e;
																																							case 178:
																																								goto IL_0951;
																																							case 192:
																																								goto IL_095f;
																																							case 143:
																																							case 225:
																																								goto IL_0976;
																																							case 219:
																																								goto IL_098f;
																																							case 194:
																																								goto IL_099d;
																																							case 203:
																																								goto IL_09ab;
																																							case 53:
																																								goto IL_09be;
																																							case 47:
																																							case 275:
																																								goto IL_09c9;
																																							case 121:
																																								goto IL_0a2b;
																																							case 307:
																																								goto IL_0a3e;
																																							case 247:
																																								goto IL_0a4c;
																																							case 51:
																																							case 264:
																																								goto IL_0a57;
																																							case 127:
																																								goto IL_0a97;
																																							case 205:
																																								goto IL_0aab;
																																							case 92:
																																								goto IL_0abe;
																																							case 13:
																																								goto IL_0acc;
																																							case 80:
																																							case 119:
																																								goto IL_0ad7;
																																							case 260:
																																								goto IL_0b17;
																																							case 28:
																																								goto IL_0b34;
																																							case 137:
																																								goto IL_0b47;
																																							case 321:
																																								goto IL_0b55;
																																							case 75:
																																							case 144:
																																								goto IL_0b63;
																																							case 112:
																																								goto IL_0b7c;
																																							case 84:
																																								goto IL_0b8a;
																																							case 273:
																																								goto IL_0b98;
																																							case 156:
																																								goto IL_0bab;
																																							case 18:
																																								goto IL_0bb6;
																																							case 2:
																																							case 132:
																																								goto IL_0bc4;
																																							case 291:
																																								goto IL_0bed;
																																							case 117:
																																								goto IL_0bfb;
																																							case 111:
																																								goto IL_0c0e;
																																							case 79:
																																								goto IL_0c1c;
																																							case 122:
																																							case 195:
																																								goto IL_0c2a;
																																							case 142:
																																								goto IL_0c38;
																																							case 240:
																																								goto IL_0c5b;
																																							case 151:
																																								goto IL_0c65;
																																							case 113:
																																								goto IL_0c73;
																																							case 21:
																																								goto IL_0c86;
																																							case 184:
																																								goto IL_0c94;
																																							case 295:
																																								goto IL_0ca2;
																																							case 318:
																																								goto IL_0cb0;
																																							case 140:
																																							case 287:
																																								goto IL_0cbe;
																																							case 181:
																																								goto IL_0cfe;
																																							case 139:
																																								goto IL_0d12;
																																							case 267:
																																							case 314:
																																								goto IL_0d2e;
																																							case 97:
																																								goto IL_0d6e;
																																							case 98:
																																								goto IL_0d82;
																																							case 85:
																																								goto IL_0d9e;
																																							case 328:
																																								goto IL_0da9;
																																							case 177:
																																							case 199:
																																								goto IL_0db7;
																																							case 309:
																																								goto IL_0dca;
																																							case 100:
																																								goto IL_0dd8;
																																							case 154:
																																							case 269:
																																								goto IL_0de6;
																																							case 128:
																																								goto IL_0e26;
																																							case 270:
																																								goto IL_0e3a;
																																							case 244:
																																								goto IL_0e4d;
																																							case 276:
																																								goto IL_0e5b;
																																							case 32:
																																							case 42:
																																								goto IL_0e66;
																																							case 224:
																																								goto IL_0e7a;
																																							case 180:
																																								goto IL_0eb9;
																																							case 189:
																																								goto IL_0ecc;
																																							case 310:
																																								goto IL_0eda;
																																							case 185:
																																							case 211:
																																								goto IL_0ee5;
																																							case 155:
																																								goto IL_0f25;
																																							case 322:
																																								goto IL_0f39;
																																							case 294:
																																								goto IL_0f4c;
																																							case 249:
																																								goto IL_0f5a;
																																							case 191:
																																								goto IL_0f68;
																																							case 190:
																																								goto IL_0f76;
																																							case 114:
																																							case 252:
																																								goto IL_0f84;
																																							case 256:
																																								goto IL_0fc4;
																																							case 218:
																																								goto IL_0fd8;
																																							case 60:
																																							case 217:
																																								goto IL_0ff4;
																																							case 246:
																																								goto IL_1011;
																																							case 175:
																																								goto IL_1050;
																																							case 36:
																																								goto IL_1063;
																																							case 138:
																																								goto IL_1071;
																																							case 173:
																																								goto IL_107f;
																																							case 31:
																																							case 69:
																																								goto IL_108d;
																																							case 145:
																																								goto IL_10eb;
																																							case 226:
																																								goto IL_10fe;
																																							case 55:
																																							case 108:
																																								goto IL_110c;
																																							case 278:
																																								goto IL_111a;
																																							case 164:
																																								goto IL_113e;
																																							case 37:
																																								goto IL_114c;
																																							case 136:
																																								goto IL_1168;
																																							case 255:
																																								goto IL_1176;
																																							case 10:
																																							case 304:
																																								goto IL_1181;
																																							case 27:
																																								goto IL_118b;
																																							case 90:
																																								goto IL_1199;
																																							case 296:
																																								goto IL_11ac;
																																							case 148:
																																								goto IL_11ba;
																																							case 168:
																																							case 206:
																																								goto IL_11c8;
																																							case 116:
																																								goto IL_11d6;
																																							case 46:
																																								goto IL_11f4;
																																							case 166:
																																								goto IL_1202;
																																							case 272:
																																								goto IL_1215;
																																							case 283:
																																								goto IL_1220;
																																							case 87:
																																								goto IL_122e;
																																							case 33:
																																							case 94:
																																								goto IL_123c;
																																							case 106:
																																								goto IL_1266;
																																							case 280:
																																								goto IL_1274;
																																							case 235:
																																								goto IL_1287;
																																							case 24:
																																							case 26:
																																								goto IL_1295;
																																							case 250:
																																								goto IL_12a9;
																																							case 265:
																																								goto IL_12f6;
																																							case 81:
																																								goto IL_1304;
																																							case 109:
																																								goto IL_1317;
																																							case 210:
																																								goto IL_1325;
																																							case 326:
																																								goto IL_1333;
																																							case 17:
																																							case 207:
																																								goto IL_133e;
																																							case 204:
																																								goto IL_136c;
																																							case 170:
																																								goto IL_137f;
																																							case 186:
																																								goto IL_138d;
																																							case 56:
																																							case 243:
																																								goto IL_139b;
																																							case 64:
																																								goto IL_13af;
																																							case 289:
																																								goto IL_13ee;
																																							case 149:
																																								goto IL_1401;
																																							case 324:
																																								goto IL_140c;
																																							case 172:
																																							case 327:
																																								goto IL_1423;
																																							case 293:
																																								goto IL_143f;
																																							case 61:
																																								goto IL_144d;
																																							case 176:
																																								goto IL_1469;
																																							case 233:
																																							case 284:
																																								goto IL_1474;
																																							case 70:
																																								goto IL_14b2;
																																							case 239:
																																								goto IL_14c0;
																																							case 44:
																																								goto IL_14d3;
																																							case 11:
																																								goto IL_14e1;
																																							case 196:
																																							case 221:
																																								goto IL_14ec;
																																							case 274:
																																								goto IL_152d;
																																							case 159:
																																								goto IL_1541;
																																							case 319:
																																								goto IL_1554;
																																							case 268:
																																								goto IL_1562;
																																							case 52:
																																							case 167:
																																								goto IL_1570;
																																							case 254:
																																								goto IL_15b0;
																																							case 174:
																																								goto IL_15c4;
																																							case 134:
																																								goto IL_15d7;
																																							case 290:
																																								goto IL_15e5;
																																							case 12:
																																							case 325:
																																								goto IL_15f3;
																																							case 187:
																																								goto IL_1607;
																																							case 120:
																																								goto IL_1654;
																																							case 131:
																																								goto IL_1662;
																																							case 262:
																																								goto IL_1675;
																																							case 29:
																																								goto IL_1680;
																																							case 99:
																																							case 298:
																																								goto IL_168b;
																																							case 57:
																																								goto IL_169f;
																																							case 212:
																																								goto IL_16de;
																																							case 14:
																																							case 19:
																																							case 34:
																																							case 35:
																																							case 40:
																																							case 41:
																																							case 43:
																																							case 45:
																																							case 54:
																																							case 58:
																																							case 71:
																																							case 78:
																																							case 82:
																																							case 110:
																																							case 118:
																																							case 123:
																																							case 124:
																																							case 135:
																																							case 141:
																																							case 158:
																																							case 162:
																																							case 163:
																																							case 169:
																																							case 183:
																																							case 197:
																																							case 209:
																																							case 220:
																																							case 222:
																																							case 223:
																																							case 227:
																																							case 257:
																																							case 259:
																																							case 277:
																																							case 279:
																																							case 281:
																																							case 282:
																																							case 288:
																																							case 297:
																																							case 300:
																																							case 308:
																																							case 316:
																																							case 317:
																																								goto end_IL_05bb;
																																							case 0:
																																							case 1:
																																							case 5:
																																							case 6:
																																							case 20:
																																							case 25:
																																							case 48:
																																							case 50:
																																							case 65:
																																							case 72:
																																							case 73:
																																							case 74:
																																							case 77:
																																							case 86:
																																							case 88:
																																							case 93:
																																							case 101:
																																							case 102:
																																							case 103:
																																							case 126:
																																							case 133:
																																							case 161:
																																							case 171:
																																							case 193:
																																							case 200:
																																							case 213:
																																							case 216:
																																							case 228:
																																							case 231:
																																							case 232:
																																							case 236:
																																							case 241:
																																							case 242:
																																							case 245:
																																							case 286:
																																							case 299:
																																							case 302:
																																							case 303:
																																							case 305:
																																							case 306:
																																							case 320:
																																								goto end_IL_054b;
																																							case 130:
																																								goto end_IL_170a;
																																							case 152:
																																								goto end_IL_171d;
																																							case 22:
																																								goto end_IL_1727;
																																							case 202:
																																								goto end_IL_1732;
																																							case 39:
																																								goto end_IL_1742;
																																							case 49:
																																							case 208:
																																								goto end_IL_1752;
																																							case 179:
																																								goto end_IL_1762;
																																							case 4:
																																								goto end_IL_1772;
																																							case 234:
																																								goto end_IL_1782;
																																							case 229:
																																								goto end_IL_1792;
																																							case 230:
																																								goto end_IL_17a2;
																																							case 9:
																																							case 147:
																																								return;
																																							}
																																							continue;
																																							end_IL_054b:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto end_IL_0648;
																																		continue;
																																		end_IL_05bb:
																																		break;
																																		IL_05bb:;
																																	}
																																	break;
																																}
																																goto IL_07be;
																																IL_07da:
																																ptr2 = ptr + *(int*)(ptr2 + num3);
																																goto end_IL_0648;
																																IL_07be:
																																if (14 < b)
																																{
																																	break;
																																}
																																goto IL_07cc;
																																IL_07cc:
																																if (14 > b)
																																{
																																	break;
																																}
																																goto IL_07da;
																															}
																															break;
																														}
																														goto IL_0741;
																														IL_07ab:
																														ptr2 += 8;
																														goto end_IL_0648;
																														IL_0741:
																														if (12 <= b)
																														{
																															goto end_IL_0648;
																														}
																														goto IL_074f;
																														IL_074f:
																														if (11 < b)
																														{
																															break;
																														}
																														goto IL_075d;
																														IL_075d:
																														if (11 > b)
																														{
																															break;
																														}
																														goto IL_076b;
																														IL_076b:
																														array[num6] = 0;
																														goto IL_0779;
																														IL_0779:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])();
																														goto IL_079d;
																														IL_079d:
																														num6++;
																														goto IL_07ab;
																													}
																													break;
																												}
																												goto IL_0673;
																												IL_06c8:
																												num6--;
																												goto end_IL_0648;
																												IL_0673:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																												goto IL_06b4;
																												IL_06b4:
																												array[num6 - 2] = 0;
																												goto IL_06c8;
																											}
																											break;
																										}
																										goto IL_07f2;
																										IL_099d:
																										num6++;
																										goto IL_09ab;
																										IL_07f2:
																										if (17 >= b)
																										{
																											goto IL_0800;
																										}
																										goto IL_08ee;
																										IL_0800:
																										if (17 <= b)
																										{
																											goto IL_080b;
																										}
																										goto IL_0864;
																										IL_080b:
																										array2[num6] = array5[*(int*)(ptr2 + num3)];
																										goto IL_0823;
																										IL_0823:
																										array[num6] = 5;
																										num = 198;
																										goto IL_083a;
																										IL_083a:
																										num6++;
																										num = 63;
																										goto IL_0851;
																										IL_0851:
																										ptr2 += 8;
																										goto end_IL_0648;
																										IL_0864:
																										if (16 < b)
																										{
																											break;
																										}
																										goto IL_0872;
																										IL_0872:
																										if (16 > b)
																										{
																											break;
																										}
																										goto IL_0880;
																										IL_0880:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_08d2;
																										IL_08d2:
																										num6--;
																										num = 286;
																										goto end_IL_0648;
																										IL_08ee:
																										if (18 >= b)
																										{
																											goto IL_08f9;
																										}
																										goto IL_0951;
																										IL_08f9:
																										if (18 > b)
																										{
																											break;
																										}
																										goto IL_0907;
																										IL_0907:
																										((delegate*<Class179, void>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 1]);
																										goto IL_0930;
																										IL_0930:
																										num6--;
																										goto IL_093e;
																										IL_093e:
																										ptr2 += 8;
																										goto end_IL_0648;
																										IL_0951:
																										if (19 < b)
																										{
																											break;
																										}
																										goto IL_095f;
																										IL_095f:
																										if (19 > b)
																										{
																											break;
																										}
																										num = 143;
																										goto IL_0976;
																										IL_09ab:
																										ptr2 += 16;
																										goto end_IL_0648;
																										IL_0976:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_098f;
																										IL_098f:
																										array[num6] = 3;
																										goto IL_099d;
																									}
																									break;
																								}
																								goto IL_09be;
																								IL_0e26:
																								array[num6 - 2] = 0;
																								goto IL_0e3a;
																								IL_09be:
																								if (10 <= b)
																								{
																									goto IL_09c9;
																								}
																								goto IL_0a3e;
																								IL_09c9:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0a2b;
																								IL_0a2b:
																								num6 -= 2;
																								goto end_IL_0648;
																								IL_0a3e:
																								if (5 >= b)
																								{
																									goto IL_0a4c;
																								}
																								goto IL_0c86;
																								IL_0a4c:
																								if (5 <= b)
																								{
																									goto IL_0a57;
																								}
																								goto IL_0abe;
																								IL_0a57:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0a97;
																								IL_0a97:
																								array[num6 - 2] = 0;
																								goto IL_0aab;
																								IL_0aab:
																								num6--;
																								goto end_IL_0648;
																								IL_0abe:
																								if (2 >= b)
																								{
																									goto IL_0acc;
																								}
																								goto IL_0bab;
																								IL_0acc:
																								if (2 <= b)
																								{
																									goto IL_0ad7;
																								}
																								goto IL_0b47;
																								IL_0ad7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0b17;
																								IL_0b17:
																								array[num6 - 2] = 0;
																								num = 28;
																								goto IL_0b34;
																								IL_0b34:
																								num6--;
																								goto end_IL_0648;
																								IL_0b47:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0b55;
																								IL_0b55:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0b63;
																								IL_0b63:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																								goto IL_0b7c;
																								IL_0b7c:
																								array[num6] = 0;
																								goto IL_0b8a;
																								IL_0b8a:
																								num6++;
																								goto IL_0b98;
																								IL_0b98:
																								ptr2 += 8;
																								goto end_IL_0648;
																								IL_0bab:
																								if (3 >= b)
																								{
																									goto IL_0bb6;
																								}
																								goto IL_0c0e;
																								IL_0bb6:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0bc4;
																								IL_0bc4:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0bed;
																								IL_0bed:
																								ptr2 += 8;
																								goto IL_0bfb;
																								IL_0bfb:
																								num6--;
																								goto end_IL_0648;
																								IL_0c0e:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0c1c;
																								IL_0c1c:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0c2a;
																								IL_0c2a:
																								array[num6] = 0;
																								goto IL_0c38;
																								IL_0c38:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0c5b;
																								IL_0c5b:
																								array2[num6] = null;
																								goto IL_0c65;
																								IL_0c65:
																								num6++;
																								goto IL_0c73;
																								IL_0c73:
																								ptr2 += 8;
																								goto end_IL_0648;
																								IL_0c86:
																								if (7 >= b)
																								{
																									goto IL_0c94;
																								}
																								goto IL_0d9e;
																								IL_0c94:
																								if (7 > b)
																								{
																									goto IL_0ca2;
																								}
																								num = 314;
																								goto IL_0d2e;
																								IL_0ca2:
																								if (6 < b)
																								{
																									break;
																								}
																								goto IL_0cb0;
																								IL_0cb0:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_0cbe;
																								IL_0cbe:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0cfe;
																								IL_0cfe:
																								array[num6 - 2] = 0;
																								goto IL_0d12;
																								IL_0d12:
																								num6--;
																								goto end_IL_0648;
																								IL_0e3a:
																								num6--;
																								goto end_IL_0648;
																								IL_0d2e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0d6e;
																								IL_0d6e:
																								array[num6 - 2] = 0;
																								goto IL_0d82;
																								IL_0d82:
																								num6--;
																								num = 306;
																								goto end_IL_0648;
																								IL_0d9e:
																								if (8 >= b)
																								{
																									goto IL_0da9;
																								}
																								goto IL_0dca;
																								IL_0da9:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_0db7;
																								IL_0db7:
																								num6--;
																								goto end_IL_0648;
																								IL_0dca:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_0dd8;
																								IL_0dd8:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0de6;
																								IL_0de6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0e26;
																							}
																							break;
																						}
																						goto IL_06db;
																						IL_072e:
																						ptr2 += 8;
																						goto end_IL_0648;
																						IL_06db:
																						array[num6 - 1] = 3;
																						goto IL_06ef;
																						IL_06ef:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_072e;
																					}
																					break;
																				}
																				goto IL_0e4d;
																				IL_168b:
																				array[num6 - 1] = 3;
																				goto IL_169f;
																				IL_0e4d:
																				if (30 >= b)
																				{
																					goto IL_0e5b;
																				}
																				goto IL_1317;
																				IL_0e5b:
																				if (30 <= b)
																				{
																					goto IL_0e66;
																				}
																				goto IL_0ecc;
																				IL_0e66:
																				array[num6 - 1] = 3;
																				goto IL_0e7a;
																				IL_0e7a:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0eb9;
																				IL_0eb9:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_0ecc:
																				if (25 >= b)
																				{
																					goto IL_0eda;
																				}
																				goto IL_1168;
																				IL_0eda:
																				if (25 <= b)
																				{
																					goto IL_0ee5;
																				}
																				goto IL_0f4c;
																				IL_0ee5:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0f25;
																				IL_0f25:
																				array[num6 - 2] = 3;
																				goto IL_0f39;
																				IL_0f39:
																				num6--;
																				goto end_IL_0648;
																				IL_0f4c:
																				if (22 >= b)
																				{
																					goto IL_0f5a;
																				}
																				goto IL_1063;
																				IL_0f5a:
																				if (22 > b)
																				{
																					goto IL_0f68;
																				}
																				goto IL_0ff4;
																				IL_0f68:
																				if (21 < b)
																				{
																					break;
																				}
																				goto IL_0f76;
																				IL_0f76:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_0f84;
																				IL_0f84:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0fc4;
																				IL_0fc4:
																				array[num6 - 2] = 3;
																				goto IL_0fd8;
																				IL_0fd8:
																				num6--;
																				num = 320;
																				goto end_IL_0648;
																				IL_0ff4:
																				array[num6 - 1] = 0;
																				num = 246;
																				goto IL_1011;
																				IL_1011:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1050;
																				IL_1050:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1063:
																				if (23 < b)
																				{
																					goto IL_1071;
																				}
																				goto IL_10fe;
																				IL_1071:
																				if (24 < b)
																				{
																					break;
																				}
																				goto IL_107f;
																				IL_107f:
																				if (24 > b)
																				{
																					break;
																				}
																				goto IL_108d;
																				IL_108d:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_10eb;
																				IL_10eb:
																				num6--;
																				goto end_IL_0648;
																				IL_10fe:
																				if (23 > b)
																				{
																					break;
																				}
																				goto IL_110c;
																				IL_110c:
																				array[num6] = 0;
																				goto IL_111a;
																				IL_111a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])() ? 1 : 0);
																				goto IL_113e;
																				IL_113e:
																				num6++;
																				goto IL_114c;
																				IL_114c:
																				ptr2 += 8;
																				num = 299;
																				goto end_IL_0648;
																				IL_1168:
																				if (27 >= b)
																				{
																					goto IL_1176;
																				}
																				goto IL_1215;
																				IL_1176:
																				if (27 <= b)
																				{
																					goto IL_1181;
																				}
																				goto IL_11ac;
																				IL_1181:
																				array2[num6] = null;
																				goto IL_118b;
																				IL_118b:
																				array[num6] = 5;
																				goto IL_1199;
																				IL_1199:
																				num6++;
																				goto end_IL_0648;
																				IL_11ac:
																				if (26 < b)
																				{
																					break;
																				}
																				goto IL_11ba;
																				IL_11ba:
																				if (26 > b)
																				{
																					break;
																				}
																				goto IL_11c8;
																				IL_11c8:
																				array[num6] = 5;
																				goto IL_11d6;
																				IL_11d6:
																				array2[num6] = ((delegate*<GorillaTagger>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])();
																				goto IL_11f4;
																				IL_11f4:
																				num6++;
																				goto IL_1202;
																				IL_1202:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1215:
																				if (28 < b)
																				{
																					goto IL_1220;
																				}
																				goto IL_1287;
																				IL_1220:
																				if (29 < b)
																				{
																					break;
																				}
																				goto IL_122e;
																				IL_122e:
																				if (29 > b)
																				{
																					break;
																				}
																				goto IL_123c;
																				IL_123c:
																				((delegate*<bool, void>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																				goto IL_1266;
																				IL_1266:
																				num6--;
																				goto IL_1274;
																				IL_1274:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1287:
																				if (28 > b)
																				{
																					break;
																				}
																				goto IL_1295;
																				IL_1295:
																				array[num6 - 2] = 0;
																				goto IL_12a9;
																				IL_12a9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_12f6;
																				IL_12f6:
																				num6--;
																				goto IL_1304;
																				IL_1304:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1317:
																				if (35 < b)
																				{
																					goto IL_1325;
																				}
																				num = 176;
																				goto IL_1469;
																				IL_1325:
																				if (37 >= b)
																				{
																					goto IL_1333;
																				}
																				goto IL_1401;
																				IL_1333:
																				if (37 <= b)
																				{
																					goto IL_133e;
																				}
																				goto IL_137f;
																				IL_133e:
																				((Class179)array2[num6 - 2]).bool_1 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																				goto IL_136c;
																				IL_136c:
																				num6 -= 2;
																				goto end_IL_0648;
																				IL_137f:
																				if (36 < b)
																				{
																					break;
																				}
																				goto IL_138d;
																				IL_138d:
																				if (36 > b)
																				{
																					break;
																				}
																				goto IL_139b;
																				IL_139b:
																				array[num6 - 1] = 3;
																				goto IL_13af;
																				IL_13af:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_13ee;
																				IL_13ee:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1401:
																				if (38 >= b)
																				{
																					goto IL_140c;
																				}
																				goto IL_143f;
																				IL_140c:
																				if (38 > b)
																				{
																					break;
																				}
																				num = 327;
																				goto IL_1423;
																				IL_16de:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1423:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_0648;
																				IL_143f:
																				if (39 < b)
																				{
																					break;
																				}
																				goto IL_144d;
																				IL_144d:
																				if (39 <= b)
																				{
																				}
																				break;
																				IL_169f:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_16de;
																				IL_1469:
																				if (35 <= b)
																				{
																					goto IL_1474;
																				}
																				goto IL_14d3;
																				IL_1474:
																				((delegate*<Behaviour, bool, void>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																				goto IL_14b2;
																				IL_14b2:
																				num6 -= 2;
																				goto IL_14c0;
																				IL_14c0:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_14d3:
																				if (32 >= b)
																				{
																					goto IL_14e1;
																				}
																				goto IL_15d7;
																				IL_14e1:
																				if (32 <= b)
																				{
																					goto IL_14ec;
																				}
																				goto IL_1554;
																				IL_14ec:
																				array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																				num = 274;
																				goto IL_152d;
																				IL_152d:
																				array[num6 - 1] = 5;
																				goto IL_1541;
																				IL_1541:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1554:
																				if (31 < b)
																				{
																					break;
																				}
																				goto IL_1562;
																				IL_1562:
																				if (31 > b)
																				{
																					break;
																				}
																				goto IL_1570;
																				IL_1570:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_15b0;
																				IL_15b0:
																				array[num6 - 2] = 3;
																				goto IL_15c4;
																				IL_15c4:
																				num6--;
																				goto end_IL_0648;
																				IL_15d7:
																				if (33 >= b)
																				{
																					goto IL_15e5;
																				}
																				goto IL_1675;
																				IL_15e5:
																				if (33 > b)
																				{
																					break;
																				}
																				goto IL_15f3;
																				IL_15f3:
																				array[num6 - 2] = 0;
																				goto IL_1607;
																				IL_1607:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)ToEvenOSPlatform[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																				goto IL_1654;
																				IL_1654:
																				num6--;
																				goto IL_1662;
																				IL_1662:
																				ptr2 += 8;
																				goto end_IL_0648;
																				IL_1675:
																				if (34 < b)
																				{
																					break;
																				}
																				goto IL_1680;
																				IL_1680:
																				if (34 > b)
																				{
																					break;
																				}
																				goto IL_168b;
																			}
																			break;
																			IL_0638:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 242;
																	break;
																	continue;
																	end_IL_0648:
																	break;
																}
																break;
															}
															break;
														}
														continue;
														end_IL_170a:
														break;
													}
													continue;
													end_IL_171d:
													break;
												}
												continue;
												end_IL_1727:
												break;
											}
											continue;
											end_IL_1732:
											break;
										}
										continue;
										end_IL_1742:
										break;
									}
									continue;
									end_IL_1752:
									break;
								}
								continue;
								end_IL_1762:
								break;
							}
							continue;
							end_IL_1772:
							break;
						}
						continue;
						end_IL_1782:
						break;
					}
					continue;
					end_IL_1792:
					break;
				}
				continue;
				end_IL_17a2:
				break;
			}
		}
	}

	public unsafe static void smethod_11()
	{
		int num = 16;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllRegisterObjectBound.ProcessingConcurrentTasksgetLCID);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_043c:
															if (b >= 1)
															{
																while (b <= 26)
																{
																	while (true)
																	{
																		IL_041c:
																		if (13 < b)
																		{
																			while (true)
																			{
																				IL_040c:
																				if (20 >= b)
																				{
																					while (true)
																					{
																						IL_03ff:
																						if (20 > b)
																						{
																							while (true)
																							{
																								IL_03ef:
																								if (16 < b)
																								{
																									while (true)
																									{
																										IL_03df:
																										if (18 >= b)
																										{
																											while (true)
																											{
																												IL_03cf:
																												if (18 > b)
																												{
																													while (17 >= b)
																													{
																														num = 227;
																														while (true)
																														{
																															if (num != 227)
																															{
																																if (num != 1208)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 188:
																																	goto IL_03bc;
																																case 204:
																																	goto IL_03cf;
																																case 96:
																																	goto IL_03df;
																																case 116:
																																	goto IL_03ef;
																																case 143:
																																	goto IL_03ff;
																																case 68:
																																	goto IL_040c;
																																case 5:
																																	goto IL_041c;
																																case 158:
																																	goto IL_042c;
																																case 191:
																																	goto IL_043c;
																																case 125:
																																	goto end_IL_043c;
																																case 10:
																																case 208:
																																	goto end_IL_044c;
																																case 9:
																																case 95:
																																	goto IL_0467;
																																case 63:
																																	goto IL_047b;
																																case 172:
																																	goto IL_04ba;
																																case 211:
																																	goto IL_04cd;
																																case 163:
																																	goto IL_04db;
																																case 18:
																																	goto end_IL_03a9;
																																case 64:
																																case 133:
																																	goto IL_04fd;
																																case 100:
																																	goto IL_053d;
																																case 159:
																																	goto IL_055a;
																																case 164:
																																	goto IL_056d;
																																case 99:
																																	goto IL_057b;
																																case 24:
																																	goto IL_0589;
																																case 89:
																																	goto IL_0597;
																																case 20:
																																	goto IL_05a5;
																																case 14:
																																case 201:
																																	goto IL_05bc;
																																case 53:
																																	goto IL_05fc;
																																case 30:
																																	goto IL_0610;
																																case 170:
																																	goto IL_062c;
																																case 115:
																																case 192:
																																	goto IL_063a;
																																case 117:
																																	goto IL_0653;
																																case 74:
																																	goto IL_0661;
																																case 202:
																																	goto IL_066f;
																																case 0:
																																case 128:
																																	goto IL_0682;
																																case 120:
																																	goto IL_06ab;
																																case 160:
																																	goto IL_06b9;
																																case 166:
																																	goto IL_06cc;
																																case 171:
																																	goto IL_06d7;
																																case 78:
																																	goto IL_06e2;
																																case 61:
																																	goto IL_06f0;
																																case 11:
																																	goto IL_06fe;
																																case 109:
																																	goto IL_0711;
																																case 179:
																																	goto IL_071f;
																																case 177:
																																	goto IL_0732;
																																case 1:
																																case 51:
																																	goto IL_073d;
																																case 138:
																																	goto IL_077d;
																																case 130:
																																	goto IL_0791;
																																case 83:
																																	goto IL_07a4;
																																case 97:
																																	goto IL_07af;
																																case 19:
																																case 86:
																																	goto IL_07bd;
																																case 60:
																																	goto IL_07fd;
																																case 42:
																																	goto IL_0811;
																																case 57:
																																	goto IL_082d;
																																case 43:
																																	goto IL_083b;
																																case 77:
																																case 88:
																																	goto IL_0849;
																																case 189:
																																case 203:
																																	goto IL_085c;
																																case 17:
																																case 215:
																																	goto IL_0874;
																																case 152:
																																	goto IL_08df;
																																case 216:
																																	goto IL_08f2;
																																case 114:
																																	goto IL_08fd;
																																case 46:
																																case 90:
																																	goto IL_090b;
																																case 182:
																																	goto IL_0919;
																																case 156:
																																	goto IL_093c;
																																case 123:
																																	goto IL_0946;
																																case 62:
																																	goto IL_0954;
																																case 213:
																																	goto IL_0967;
																																case 28:
																																	goto IL_0975;
																																case 4:
																																case 82:
																																	goto IL_0983;
																																case 105:
																																	goto IL_09c3;
																																case 206:
																																	goto IL_09e0;
																																case 32:
																																case 218:
																																	goto IL_09f3;
																																case 196:
																																	goto IL_0a15;
																																case 104:
																																	goto IL_0a23;
																																case 118:
																																	goto IL_0a31;
																																case 140:
																																case 219:
																																	goto IL_0a44;
																																case 122:
																																	goto IL_0a61;
																																case 198:
																																	goto IL_0aae;
																																case 157:
																																	goto IL_0abc;
																																case 154:
																																case 194:
																																	goto IL_0add;
																																case 207:
																																	goto IL_0ae7;
																																case 38:
																																	goto IL_0af5;
																																case 220:
																																	goto IL_0b08;
																																case 67:
																																	goto IL_0b16;
																																case 27:
																																case 47:
																																	goto IL_0b24;
																																case 75:
																																	goto IL_0b3d;
																																case 91:
																																	goto IL_0b4b;
																																case 22:
																																	goto IL_0b59;
																																case 8:
																																	goto IL_0b75;
																																case 153:
																																case 161:
																																	goto IL_0b80;
																																case 103:
																																	goto IL_0b9e;
																																case 52:
																																	goto IL_0bac;
																																case 3:
																																	goto IL_0bba;
																																case 31:
																																	goto IL_0bcd;
																																case 73:
																																	goto IL_0bd8;
																																case 33:
																																case 110:
																																	goto IL_0be6;
																																case 107:
																																	goto IL_0c27;
																																case 180:
																																	goto IL_0c3b;
																																case 121:
																																	goto IL_0c4e;
																																case 168:
																																	goto IL_0c5c;
																																case 40:
																																case 48:
																																	goto IL_0c6a;
																																case 187:
																																	goto IL_0cbc;
																																case 66:
																																	goto IL_0ccf;
																																case 217:
																																	goto IL_0cdd;
																																case 58:
																																case 134:
																																	goto IL_0ce8;
																																case 76:
																																	goto IL_0d11;
																																case 197:
																																	goto IL_0d1f;
																																case 36:
																																	goto IL_0d32;
																																case 7:
																																	goto IL_0d40;
																																case 54:
																																	goto IL_0d4e;
																																case 56:
																																case 149:
																																	goto IL_0d5c;
																																case 71:
																																	goto IL_0d70;
																																case 13:
																																	goto IL_0daf;
																																case 124:
																																	goto IL_0dcb;
																																case 25:
																																case 212:
																																	goto IL_0dd9;
																																case 165:
																																	goto IL_0e19;
																																case 92:
																																	goto IL_0e2d;
																																case 195:
																																	goto IL_0e40;
																																case 183:
																																	goto IL_0e4e;
																																case 79:
																																case 106:
																																	goto IL_0e59;
																																case 72:
																																	goto IL_0e75;
																																case 39:
																																	goto IL_0e8c;
																																case 81:
																																case 84:
																																	goto IL_0e97;
																																case 69:
																																	goto IL_0eab;
																																case 169:
																																	goto IL_0eea;
																																case 98:
																																	goto IL_0efa;
																																case 145:
																																	goto IL_0f05;
																																case 41:
																																case 44:
																																case 49:
																																case 50:
																																case 59:
																																case 70:
																																case 85:
																																case 94:
																																case 101:
																																case 102:
																																case 112:
																																case 113:
																																case 119:
																																case 127:
																																case 131:
																																case 139:
																																case 144:
																																case 146:
																																case 148:
																																case 151:
																																case 155:
																																case 174:
																																case 175:
																																case 181:
																																case 184:
																																case 193:
																																case 199:
																																case 205:
																																case 210:
																																	goto end_IL_03bc;
																																case 2:
																																case 12:
																																case 21:
																																case 23:
																																case 26:
																																case 29:
																																case 35:
																																case 45:
																																case 65:
																																case 93:
																																case 108:
																																case 111:
																																case 129:
																																case 132:
																																case 135:
																																case 136:
																																case 137:
																																case 142:
																																case 162:
																																case 167:
																																case 173:
																																case 176:
																																case 178:
																																case 185:
																																case 186:
																																case 190:
																																case 200:
																																case 209:
																																case 214:
																																	goto end_IL_045c;
																																case 6:
																																	goto end_IL_0f23;
																																case 87:
																																	goto end_IL_0f36;
																																case 37:
																																	goto end_IL_0f40;
																																case 80:
																																case 141:
																																	goto end_IL_0f4b;
																																case 126:
																																	goto end_IL_0f5b;
																																case 147:
																																	goto end_IL_0f6b;
																																case 55:
																																	goto end_IL_0f7b;
																																case 15:
																																	goto end_IL_0f8b;
																																case 16:
																																	goto end_IL_0f9b;
																																case 34:
																																case 150:
																																	return;
																																}
																																continue;
																															}
																															if (17 > b)
																															{
																																goto end_IL_03bc;
																															}
																															goto IL_0add;
																															IL_0add:
																															array2[num6] = null;
																															goto IL_0ae7;
																															IL_0af5:
																															num6++;
																															goto end_IL_045c;
																															IL_0ae7:
																															array[num6] = 5;
																															goto IL_0af5;
																															continue;
																															end_IL_03a9:
																															break;
																														}
																														goto IL_04e9;
																														continue;
																														end_IL_03bc:
																														break;
																														IL_03bc:;
																													}
																													break;
																												}
																												goto IL_0a44;
																												IL_0abc:
																												ptr2 += 8;
																												goto end_IL_045c;
																												IL_0a44:
																												array[num6 - 2] = 0;
																												num = 122;
																												goto IL_0a61;
																												IL_0a61:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)GetDefaultWritergetSize[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																												goto IL_0aae;
																												IL_0aae:
																												num6--;
																												goto IL_0abc;
																											}
																											break;
																										}
																										goto IL_0b08;
																										IL_0b59:
																										ptr2 += 16;
																										goto end_IL_045c;
																										IL_0b08:
																										if (19 < b)
																										{
																											break;
																										}
																										goto IL_0b16;
																										IL_0b16:
																										if (19 > b)
																										{
																											break;
																										}
																										goto IL_0b24;
																										IL_0b24:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_0b3d;
																										IL_0b3d:
																										array[num6] = 3;
																										goto IL_0b4b;
																										IL_0b4b:
																										num6++;
																										goto IL_0b59;
																									}
																									break;
																								}
																								num = 8;
																								goto IL_0b75;
																								IL_0c6a:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0cbc;
																								IL_0cbc:
																								num6--;
																								goto end_IL_045c;
																								IL_0b75:
																								if (16 <= b)
																								{
																									goto IL_0b80;
																								}
																								goto IL_0bcd;
																								IL_0b80:
																								array2[num6] = ((delegate*<Class179>)GetDefaultWritergetSize[*(int*)(ptr2 + num3)])();
																								goto IL_0b9e;
																								IL_0b9e:
																								array[num6] = 5;
																								goto IL_0bac;
																								IL_0bac:
																								num6++;
																								goto IL_0bba;
																								IL_0bba:
																								ptr2 += 8;
																								goto end_IL_045c;
																								IL_0bcd:
																								if (14 >= b)
																								{
																									goto IL_0bd8;
																								}
																								goto IL_0c4e;
																								IL_0bd8:
																								if (14 > b)
																								{
																									break;
																								}
																								goto IL_0be6;
																								IL_0be6:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																								goto IL_0c27;
																								IL_0c27:
																								array[num6 - 2] = 0;
																								goto IL_0c3b;
																								IL_0c3b:
																								num6--;
																								goto end_IL_045c;
																								IL_0c4e:
																								if (15 < b)
																								{
																									break;
																								}
																								goto IL_0c5c;
																								IL_0c5c:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_0c6a;
																							}
																							break;
																						}
																						goto IL_0467;
																						IL_04ba:
																						ptr2 += 8;
																						goto end_IL_045c;
																						IL_0467:
																						array[num6 - 1] = 3;
																						goto IL_047b;
																						IL_047b:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)GetDefaultWritergetSize[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_04ba;
																					}
																					break;
																				}
																				goto IL_0ccf;
																				IL_0eea:
																				ptr2 += 8;
																				goto end_IL_045c;
																				IL_0ccf:
																				if (23 >= b)
																				{
																					goto IL_0cdd;
																				}
																				goto IL_0e40;
																				IL_0cdd:
																				if (23 <= b)
																				{
																					goto IL_0ce8;
																				}
																				goto IL_0d32;
																				IL_0ce8:
																				((delegate*<Class179, void>)GetDefaultWritergetSize[*(int*)(ptr2 + num3)])((Class179)array2[num6 - 1]);
																				goto IL_0d11;
																				IL_0d11:
																				num6--;
																				goto IL_0d1f;
																				IL_0d1f:
																				ptr2 += 8;
																				goto end_IL_045c;
																				IL_0d32:
																				if (21 < b)
																				{
																					goto IL_0d40;
																				}
																				num = 124;
																				goto IL_0dcb;
																				IL_0d40:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_0d4e;
																				IL_0d4e:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_0d5c;
																				IL_0d5c:
																				array[num6 - 1] = 0;
																				goto IL_0d70;
																				IL_0d70:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)GetDefaultWritergetSize[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0daf;
																				IL_0daf:
																				ptr2 += 8;
																				goto end_IL_045c;
																				IL_0efa:
																				if (26 < b)
																				{
																					break;
																				}
																				goto IL_0f05;
																				IL_0dcb:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_0dd9;
																				IL_0dd9:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0e19;
																				IL_0e19:
																				array[num6 - 2] = 3;
																				goto IL_0e2d;
																				IL_0e2d:
																				num6--;
																				goto end_IL_045c;
																				IL_0e40:
																				if (25 >= b)
																				{
																					goto IL_0e4e;
																				}
																				goto IL_0efa;
																				IL_0e4e:
																				if (25 <= b)
																				{
																					goto IL_0e59;
																				}
																				goto IL_0e75;
																				IL_0e59:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_045c;
																				IL_0e75:
																				if (24 < b)
																				{
																					break;
																				}
																				num = 39;
																				goto IL_0e8c;
																				IL_0f05:
																				if (26 <= b)
																				{
																				}
																				break;
																				IL_0e8c:
																				if (24 > b)
																				{
																					break;
																				}
																				goto IL_0e97;
																				IL_0e97:
																				array[num6 - 1] = 3;
																				goto IL_0eab;
																				IL_0eab:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)GetDefaultWritergetSize[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0eea;
																			}
																			break;
																		}
																		goto IL_04cd;
																		IL_083b:
																		if (8 > b)
																		{
																			break;
																		}
																		goto IL_0849;
																		IL_04cd:
																		if (13 > b)
																		{
																			goto IL_04db;
																		}
																		goto IL_085c;
																		IL_04db:
																		if (6 >= b)
																		{
																			goto IL_04e9;
																		}
																		goto IL_06cc;
																		IL_04e9:
																		if (6 <= b)
																		{
																			num = 133;
																			goto IL_04fd;
																		}
																		goto IL_056d;
																		IL_0849:
																		num6--;
																		goto end_IL_045c;
																		IL_04fd:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_053d;
																		IL_053d:
																		array[num6 - 2] = 0;
																		num = 159;
																		goto IL_055a;
																		IL_055a:
																		num6--;
																		goto end_IL_045c;
																		IL_056d:
																		if (3 >= b)
																		{
																			goto IL_057b;
																		}
																		goto IL_08f2;
																		IL_057b:
																		if (3 > b)
																		{
																			goto IL_0589;
																		}
																		goto IL_0682;
																		IL_0589:
																		if (1 < b)
																		{
																			goto IL_0597;
																		}
																		goto IL_062c;
																		IL_0597:
																		if (2 < b)
																		{
																			break;
																		}
																		goto IL_05a5;
																		IL_05a5:
																		if (2 > b)
																		{
																			break;
																		}
																		num = 14;
																		goto IL_05bc;
																		IL_085c:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto end_IL_045c;
																		IL_05bc:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_05fc;
																		IL_05fc:
																		array[num6 - 2] = 0;
																		goto IL_0610;
																		IL_0610:
																		num6--;
																		num = 185;
																		goto end_IL_045c;
																		IL_062c:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_063a;
																		IL_063a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0653;
																		IL_0653:
																		array[num6] = 0;
																		goto IL_0661;
																		IL_0661:
																		num6++;
																		goto IL_066f;
																		IL_066f:
																		ptr2 += 8;
																		goto end_IL_045c;
																		IL_0682:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_06ab;
																		IL_06ab:
																		ptr2 += 8;
																		goto IL_06b9;
																		IL_06b9:
																		num6--;
																		goto end_IL_045c;
																		IL_08f2:
																		if (4 >= b)
																		{
																			goto IL_08fd;
																		}
																		goto IL_0967;
																		IL_08fd:
																		if (4 > b)
																		{
																			break;
																		}
																		goto IL_090b;
																		IL_090b:
																		array[num6] = 0;
																		goto IL_0919;
																		IL_0919:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_093c;
																		IL_093c:
																		array2[num6] = null;
																		goto IL_0946;
																		IL_0946:
																		num6++;
																		goto IL_0954;
																		IL_0954:
																		ptr2 += 8;
																		goto end_IL_045c;
																		IL_0967:
																		if (5 < b)
																		{
																			break;
																		}
																		goto IL_0975;
																		IL_0975:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_0983;
																		IL_0983:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_09c3;
																		IL_09c3:
																		array[num6 - 2] = 0;
																		num = 206;
																		goto IL_09e0;
																		IL_09e0:
																		num6--;
																		goto end_IL_045c;
																		IL_06cc:
																		if (9 < b)
																		{
																			goto IL_06d7;
																		}
																		goto IL_0732;
																		IL_06d7:
																		if (11 >= b)
																		{
																			goto IL_06e2;
																		}
																		goto IL_0711;
																		IL_06e2:
																		if (11 <= b)
																		{
																			goto end_IL_045c;
																		}
																		goto IL_06f0;
																		IL_06f0:
																		if (10 < b)
																		{
																			break;
																		}
																		goto IL_06fe;
																		IL_06fe:
																		if (10 > b)
																		{
																			break;
																		}
																		goto IL_0874;
																		IL_0874:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		num = 152;
																		goto IL_08df;
																		IL_08df:
																		num6 -= 2;
																		goto end_IL_045c;
																		IL_0711:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_071f;
																		IL_071f:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_09f3;
																		IL_09f3:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																		num = 196;
																		goto IL_0a15;
																		IL_0a15:
																		array[num6] = 1;
																		goto IL_0a23;
																		IL_0a23:
																		num6++;
																		goto IL_0a31;
																		IL_0a31:
																		ptr2 += 16;
																		goto end_IL_045c;
																		IL_0732:
																		if (9 <= b)
																		{
																			goto IL_073d;
																		}
																		goto IL_07a4;
																		IL_073d:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_077d;
																		IL_077d:
																		array[num6 - 2] = 0;
																		goto IL_0791;
																		IL_0791:
																		num6--;
																		goto end_IL_045c;
																		IL_07a4:
																		if (7 >= b)
																		{
																			goto IL_07af;
																		}
																		goto IL_082d;
																		IL_07af:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_07bd;
																		IL_07bd:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_07fd;
																		IL_07fd:
																		array[num6 - 2] = 0;
																		goto IL_0811;
																		IL_0811:
																		num6--;
																		num = 178;
																		goto end_IL_045c;
																		IL_082d:
																		if (8 < b)
																		{
																			break;
																		}
																		goto IL_083b;
																	}
																	break;
																	IL_042c:;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_045c;
															continue;
															end_IL_043c:
															break;
														}
														continue;
														end_IL_044c:
														break;
													}
													continue;
													end_IL_045c:
													break;
												}
												continue;
												end_IL_0f23:
												break;
											}
											continue;
											end_IL_0f36:
											break;
										}
										continue;
										end_IL_0f40:
										break;
									}
									continue;
									end_IL_0f4b:
									break;
								}
								continue;
								end_IL_0f5b:
								break;
							}
							continue;
							end_IL_0f6b:
							break;
						}
						continue;
						end_IL_0f7b:
						break;
					}
					continue;
					end_IL_0f8b:
					break;
				}
				continue;
				end_IL_0f9b:
				break;
			}
		}
	}

	private static bool RegistryAuditRulegetIconFile(Class179 class179_2)
	{
		return class179_2.bool_2;
	}

	private static double semaphoreLockTaskWaitingForChildrenToComplete(double double_1)
	{
		return Math.Truncate(double_1);
	}

	private static GorillaTagger AggregateExceptionISecurityEncodable()
	{
		return GorillaTagger.Instance;
	}
}
