using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Fake Lag Self", "Rig", "Makes you appear laggy to others.", false, 32, ModType.const_0, false)]
internal class Class177 : MonoBehaviour
{
	private float float_0;

	private float float_1;

	private static double double_0;

	private static double double_1;

	private static float float_2;

	private static float float_3;

	private static float float_4;

	private static float float_5;

	private static IntPtr[] InvalidHebrewNumberTaskScheduler;

	private static IntPtr[] intptr_0;

	private unsafe void Update()
	{
		int num = 303;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 302;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					num = 253;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSTIMEUNITTYPEDAYSEnum.LazyCancellationUnsafeValueTypeAttribute);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 != 1)
														{
															while (true)
															{
																IL_06e3:
																byte b = *ptr2;
																while (true)
																{
																	IL_06ca:
																	ptr2++;
																	num = 161;
																	while (true)
																	{
																		IL_06ba:
																		if (b >= 1)
																		{
																			while (b <= 43)
																			{
																				while (true)
																				{
																					IL_069a:
																					if (22 >= b)
																					{
																						while (true)
																						{
																							IL_068d:
																							if (22 > b)
																							{
																								while (true)
																								{
																									IL_067d:
																									if (11 >= b)
																									{
																										while (11 > b)
																										{
																											while (true)
																											{
																												IL_065d:
																												if (5 < b)
																												{
																													while (true)
																													{
																														IL_064d:
																														if (8 >= b)
																														{
																															while (true)
																															{
																																IL_063d:
																																if (8 > b)
																																{
																																	while (true)
																																	{
																																		IL_062d:
																																		if (6 >= b)
																																		{
																																			while (6 <= b)
																																			{
																																				while (true)
																																				{
																																					IL_05d2:
																																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																					num = 364;
																																					while (true)
																																					{
																																						if (num != 364)
																																						{
																																							if (num != 1345)
																																							{
																																								break;
																																							}
																																							switch (num)
																																							{
																																							case 156:
																																							case 284:
																																								goto IL_05d2;
																																							case 225:
																																								goto IL_061d;
																																							case 32:
																																								goto IL_062d;
																																							case 10:
																																								goto IL_063d;
																																							case 12:
																																								goto IL_064d;
																																							case 126:
																																								goto IL_065d;
																																							case 255:
																																								goto IL_066d;
																																							case 351:
																																								goto IL_067d;
																																							case 93:
																																								goto IL_068d;
																																							case 264:
																																								goto IL_069a;
																																							case 43:
																																								goto IL_06aa;
																																							case 161:
																																								goto IL_06ba;
																																							case 101:
																																								goto IL_06ca;
																																							case 78:
																																							case 293:
																																								goto IL_06e3;
																																							case 56:
																																							case 304:
																																								goto IL_06ee;
																																							case 189:
																																							case 305:
																																								goto IL_0701;
																																							case 286:
																																								goto IL_071a;
																																							case 94:
																																								goto IL_0728;
																																							case 314:
																																								goto IL_073b;
																																							case 29:
																																							case 36:
																																								goto IL_0746;
																																							case 246:
																																								goto IL_0786;
																																							case 251:
																																								goto IL_079a;
																																							case 97:
																																								goto IL_07ad;
																																							case 158:
																																								goto IL_07bb;
																																							case 70:
																																							case 137:
																																								goto IL_07c6;
																																							case 112:
																																								goto IL_0806;
																																							case 121:
																																								goto IL_081a;
																																							case 104:
																																								goto IL_082d;
																																							case 151:
																																								goto IL_083b;
																																							case 331:
																																								goto IL_0857;
																																							case 332:
																																								goto IL_086a;
																																							case 282:
																																								goto IL_0875;
																																							case 90:
																																							case 277:
																																								goto IL_0883;
																																							case 257:
																																								goto IL_08ac;
																																							case 20:
																																								goto IL_08ba;
																																							case 147:
																																								goto IL_08cd;
																																							case 294:
																																								goto IL_08db;
																																							case 19:
																																							case 157:
																																								goto IL_08e9;
																																							case 198:
																																								goto IL_08f7;
																																							case 98:
																																								goto IL_091a;
																																							case 342:
																																								goto IL_0924;
																																							case 248:
																																								goto IL_0932;
																																							case 176:
																																							case 343:
																																								goto IL_0945;
																																							case 333:
																																								goto IL_095e;
																																							case 229:
																																								goto IL_096c;
																																							case 287:
																																								goto IL_097a;
																																							case 139:
																																								goto IL_09a1;
																																							case 172:
																																								goto IL_09b4;
																																							case 245:
																																								goto IL_09c2;
																																							case 270:
																																							case 353:
																																								goto IL_09d0;
																																							case 155:
																																								goto IL_0a10;
																																							case 40:
																																								goto IL_0a24;
																																							case 300:
																																								goto IL_0a37;
																																							case 308:
																																								goto IL_0a42;
																																							case 210:
																																							case 249:
																																								goto IL_0a50;
																																							case 240:
																																								goto IL_0a90;
																																							case 186:
																																								goto IL_0aa4;
																																							case 106:
																																								goto IL_0ab7;
																																							case 82:
																																								goto IL_0ac5;
																																							case 272:
																																							case 309:
																																								goto IL_0adc;
																																							case 63:
																																								goto IL_0b3e;
																																							case 23:
																																								goto IL_0b51;
																																							case 152:
																																								goto IL_0b5f;
																																							case 73:
																																							case 276:
																																								goto IL_0b6a;
																																							case 22:
																																								goto IL_0b78;
																																							case 207:
																																								goto IL_0b9c;
																																							case 83:
																																								goto IL_0baa;
																																							case 69:
																																								goto IL_0bbd;
																																							case 315:
																																								goto IL_0bcb;
																																							case 64:
																																							case 177:
																																								goto IL_0bdf;
																																							case 326:
																																								goto IL_0bf7;
																																							case 84:
																																								goto IL_0c0e;
																																							case 193:
																																							case 291:
																																								goto IL_0c1c;
																																							case 143:
																																								goto IL_0c3e;
																																							case 4:
																																								goto IL_0c4c;
																																							case 179:
																																								goto IL_0c5a;
																																							case 92:
																																								goto IL_0c6d;
																																							case 231:
																																								goto IL_0c78;
																																							case 128:
																																							case 338:
																																								goto IL_0c86;
																																							case 117:
																																								goto IL_0cc7;
																																							case 13:
																																								goto IL_0cdb;
																																							case 123:
																																								goto IL_0cee;
																																							case 91:
																																								goto IL_0cfc;
																																							case 127:
																																							case 201:
																																								goto IL_0d0a;
																																							case 159:
																																								goto IL_0d5c;
																																							case 218:
																																								goto IL_0d6f;
																																							case 273:
																																								goto IL_0d7d;
																																							case 222:
																																							case 355:
																																								goto IL_0d88;
																																							case 167:
																																								goto IL_0dab;
																																							case 28:
																																								goto IL_0db9;
																																							case 350:
																																								goto IL_0dc7;
																																							case 335:
																																								goto IL_0dda;
																																							case 44:
																																								goto IL_0de5;
																																							case 65:
																																							case 235:
																																								goto IL_0df3;
																																							case 223:
																																								goto IL_0e0b;
																																							case 164:
																																								goto IL_0e19;
																																							case 278:
																																								goto IL_0e27;
																																							case 345:
																																								goto IL_0e3a;
																																							case 134:
																																								goto IL_0e51;
																																							case 252:
																																							case 266:
																																								goto IL_0e5f;
																																							case 224:
																																								goto IL_0e9d;
																																							case 175:
																																								goto IL_0eb1;
																																							case 74:
																																								goto IL_0ec4;
																																							case 146:
																																								goto IL_0ecf;
																																							case 21:
																																							case 292:
																																								goto IL_0edd;
																																							case 336:
																																								goto IL_0f1d;
																																							case 344:
																																								goto IL_0f31;
																																							case 88:
																																								goto IL_0f4d;
																																							case 49:
																																								goto IL_0f5b;
																																							case 133:
																																							case 313:
																																								goto IL_0f72;
																																							case 140:
																																								goto IL_0fe0;
																																							case 312:
																																								goto IL_0ff3;
																																							case 296:
																																								goto IL_1001;
																																							case 31:
																																								goto IL_100f;
																																							case 48:
																																							case 183:
																																								goto IL_101d;
																																							case 120:
																																								goto IL_108b;
																																							case 119:
																																								goto IL_109e;
																																							case 148:
																																								goto IL_10ac;
																																							case 42:
																																								goto IL_10ba;
																																							case 219:
																																								goto IL_10d1;
																																							case 47:
																																							case 150:
																																								goto IL_10df;
																																							case 339:
																																								goto IL_10f3;
																																							case 57:
																																								goto IL_1150;
																																							case 318:
																																								goto IL_115e;
																																							case 330:
																																							case 334:
																																								goto IL_117a;
																																							case 163:
																																								goto IL_1194;
																																							case 105:
																																								goto IL_11a7;
																																							case 269:
																																								goto IL_11b2;
																																							case 95:
																																							case 145:
																																								goto IL_11c0;
																																							case 138:
																																								goto IL_1207;
																																							case 205:
																																								goto IL_121b;
																																							case 166:
																																								goto IL_122e;
																																							case 220:
																																								goto IL_123c;
																																							case 76:
																																							case 241:
																																								goto IL_1253;
																																							case 328:
																																								goto IL_1280;
																																							case 27:
																																								goto IL_128e;
																																							case 171:
																																								goto IL_129c;
																																							case 15:
																																								goto IL_12af;
																																							case 325:
																																								goto IL_12bd;
																																							case 107:
																																							case 124:
																																								goto IL_12c8;
																																							case 233:
																																								goto IL_12dc;
																																							case 37:
																																								goto IL_131a;
																																							case 250:
																																								goto IL_132d;
																																							case 111:
																																								goto IL_1338;
																																							case 274:
																																							case 316:
																																								goto IL_1346;
																																							case 115:
																																								goto IL_137d;
																																							case 141:
																																								goto IL_1399;
																																							case 213:
																																								goto IL_13a7;
																																							case 17:
																																							case 192:
																																								goto IL_13b5;
																																							case 298:
																																								goto IL_13c3;
																																							case 131:
																																								goto IL_13e1;
																																							case 329:
																																								goto IL_13ef;
																																							case 352:
																																								goto IL_1402;
																																							case 81:
																																								goto IL_140d;
																																							case 1:
																																							case 188:
																																								goto IL_141b;
																																							case 232:
																																								goto IL_1459;
																																							case 169:
																																								goto IL_1467;
																																							case 182:
																																								goto IL_147a;
																																							case 258:
																																								goto IL_1491;
																																							case 340:
																																								goto IL_14ad;
																																							case 41:
																																							case 357:
																																								goto IL_14b8;
																																							case 87:
																																								goto IL_14e3;
																																							case 108:
																																								goto IL_14fc;
																																							case 259:
																																								goto IL_150a;
																																							case 39:
																																							case 153:
																																								goto IL_1515;
																																							case 203:
																																								goto IL_154d;
																																							case 194:
																																								goto IL_1561;
																																							case 354:
																																								goto IL_1574;
																																							case 347:
																																								goto IL_1582;
																																							case 18:
																																							case 34:
																																								goto IL_158d;
																																							case 178:
																																								goto IL_15a1;
																																							case 144:
																																								goto IL_15e0;
																																							case 349:
																																								goto IL_15f3;
																																							case 100:
																																								goto IL_1601;
																																							case 72:
																																							case 214:
																																								goto IL_1618;
																																							case 149:
																																								goto IL_162c;
																																							case 6:
																																								goto IL_166b;
																																							case 110:
																																								goto IL_167e;
																																							case 236:
																																								goto IL_1689;
																																							case 200:
																																							case 306:
																																								goto IL_1697;
																																							case 238:
																																								goto IL_16b3;
																																							case 234:
																																								goto IL_16c1;
																																							case 26:
																																							case 285:
																																								goto IL_16cf;
																																							case 268:
																																								goto IL_16dd;
																																							case 135:
																																								goto IL_1704;
																																							case 60:
																																								goto IL_1712;
																																							case 30:
																																								goto IL_1725;
																																							case 85:
																																								goto IL_1733;
																																							case 55:
																																								goto IL_1741;
																																							case 211:
																																								goto IL_174c;
																																							case 16:
																																							case 35:
																																								goto IL_175a;
																																							case 228:
																																								goto IL_176e;
																																							case 327:
																																								goto IL_17ac;
																																							case 68:
																																								goto IL_17bf;
																																							case 263:
																																								goto IL_17cd;
																																							case 116:
																																							case 136:
																																								goto IL_17db;
																																							case 301:
																																								goto IL_1839;
																																							case 58:
																																							case 280:
																																								goto IL_184c;
																																							case 160:
																																								goto IL_1860;
																																							case 5:
																																								goto IL_18a8;
																																							case 7:
																																								goto IL_18bb;
																																							case 77:
																																								goto IL_18c6;
																																							case 168:
																																								goto IL_18d4;
																																							case 71:
																																							case 321:
																																								goto IL_18e2;
																																							case 260:
																																								goto IL_1910;
																																							case 66:
																																								goto IL_1929;
																																							case 125:
																																							case 132:
																																								goto IL_1934;
																																							case 8:
																																								goto IL_1942;
																																							case 170:
																																								goto IL_1966;
																																							case 265:
																																								goto IL_1974;
																																							case 3:
																																							case 25:
																																							case 33:
																																							case 45:
																																							case 46:
																																							case 50:
																																							case 52:
																																							case 59:
																																							case 62:
																																							case 67:
																																							case 75:
																																							case 79:
																																							case 89:
																																							case 96:
																																							case 102:
																																							case 109:
																																							case 118:
																																							case 129:
																																							case 154:
																																							case 162:
																																							case 165:
																																							case 174:
																																							case 180:
																																							case 187:
																																							case 195:
																																							case 196:
																																							case 199:
																																							case 206:
																																							case 215:
																																							case 221:
																																							case 226:
																																							case 227:
																																							case 230:
																																							case 244:
																																							case 281:
																																							case 289:
																																							case 290:
																																							case 295:
																																							case 297:
																																							case 307:
																																							case 310:
																																							case 317:
																																							case 319:
																																							case 324:
																																							case 346:
																																							case 348:
																																								goto end_IL_05bf;
																																							case 0:
																																							case 2:
																																							case 14:
																																							case 24:
																																							case 38:
																																							case 51:
																																							case 53:
																																							case 54:
																																							case 61:
																																							case 80:
																																							case 99:
																																							case 103:
																																							case 114:
																																							case 122:
																																							case 130:
																																							case 142:
																																							case 173:
																																							case 181:
																																							case 184:
																																							case 185:
																																							case 190:
																																							case 191:
																																							case 202:
																																							case 212:
																																							case 216:
																																							case 217:
																																							case 237:
																																							case 239:
																																							case 242:
																																							case 243:
																																							case 247:
																																							case 261:
																																							case 262:
																																							case 267:
																																							case 271:
																																							case 275:
																																							case 279:
																																							case 283:
																																							case 299:
																																							case 311:
																																							case 320:
																																							case 322:
																																							case 323:
																																							case 337:
																																							case 341:
																																							case 356:
																																								goto end_IL_066d;
																																							case 204:
																																								goto end_IL_1997;
																																							case 86:
																																								goto end_IL_19aa;
																																							case 254:
																																								goto end_IL_19b4;
																																							case 9:
																																								goto end_IL_19bf;
																																							case 11:
																																								goto end_IL_19cf;
																																							case 113:
																																							case 209:
																																								goto end_IL_19df;
																																							case 208:
																																								goto end_IL_19ef;
																																							case 253:
																																								goto end_IL_19ff;
																																							case 256:
																																								goto end_IL_1a0f;
																																							case 302:
																																								goto end_IL_1a1f;
																																							case 303:
																																								goto end_IL_1a38;
																																							case 197:
																																							case 288:
																																								return;
																																							}
																																							continue;
																																						}
																																						array[num6 - 2] = 0;
																																						goto IL_09a1;
																																						IL_09a1:
																																						num6--;
																																						goto end_IL_066d;
																																						continue;
																																						end_IL_05bf:
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																				IL_061d:;
																																			}
																																			break;
																																		}
																																		goto IL_09b4;
																																		IL_0a24:
																																		num6--;
																																		goto end_IL_066d;
																																		IL_09b4:
																																		if (7 < b)
																																		{
																																			break;
																																		}
																																		goto IL_09c2;
																																		IL_09c2:
																																		if (7 > b)
																																		{
																																			break;
																																		}
																																		goto IL_09d0;
																																		IL_09d0:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																																		goto IL_0a10;
																																		IL_0a10:
																																		array[num6 - 2] = 0;
																																		goto IL_0a24;
																																	}
																																	break;
																																}
																																goto IL_06ee;
																																IL_06ee:
																																num6--;
																																goto end_IL_066d;
																															}
																															break;
																														}
																														goto IL_0a37;
																														IL_0adc:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_0b3e;
																														IL_0a37:
																														if (9 >= b)
																														{
																															goto IL_0a42;
																														}
																														goto IL_0ab7;
																														IL_0a42:
																														if (9 > b)
																														{
																															break;
																														}
																														goto IL_0a50;
																														IL_0a50:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														goto IL_0a90;
																														IL_0a90:
																														array[num6 - 2] = 0;
																														goto IL_0aa4;
																														IL_0aa4:
																														num6--;
																														goto end_IL_066d;
																														IL_0ab7:
																														if (10 < b)
																														{
																															break;
																														}
																														goto IL_0ac5;
																														IL_0ac5:
																														if (10 > b)
																														{
																															break;
																														}
																														num = 272;
																														goto IL_0adc;
																														IL_0b3e:
																														num6 -= 2;
																														goto end_IL_066d;
																													}
																													break;
																												}
																												goto IL_073b;
																												IL_0924:
																												num6++;
																												goto IL_0932;
																												IL_073b:
																												if (5 <= b)
																												{
																													goto IL_0746;
																												}
																												goto IL_07ad;
																												IL_0746:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0786;
																												IL_0786:
																												array[num6 - 2] = 0;
																												goto IL_079a;
																												IL_079a:
																												num6--;
																												goto end_IL_066d;
																												IL_07ad:
																												if (2 >= b)
																												{
																													goto IL_07bb;
																												}
																												goto IL_086a;
																												IL_07bb:
																												if (2 <= b)
																												{
																													goto IL_07c6;
																												}
																												goto IL_082d;
																												IL_07c6:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0806;
																												IL_0806:
																												array[num6 - 2] = 0;
																												goto IL_081a;
																												IL_081a:
																												num6--;
																												goto end_IL_066d;
																												IL_082d:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_083b;
																												IL_083b:
																												if (1 > b)
																												{
																													break;
																												}
																												num = 343;
																												goto IL_0945;
																												IL_0932:
																												ptr2 += 8;
																												goto end_IL_066d;
																												IL_0945:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																												goto IL_095e;
																												IL_095e:
																												array[num6] = 0;
																												goto IL_096c;
																												IL_096c:
																												num6++;
																												goto IL_097a;
																												IL_097a:
																												ptr2 += 8;
																												goto end_IL_066d;
																												IL_086a:
																												if (3 >= b)
																												{
																													goto IL_0875;
																												}
																												goto IL_08cd;
																												IL_0875:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_0883;
																												IL_0883:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_08ac;
																												IL_08ac:
																												ptr2 += 8;
																												goto IL_08ba;
																												IL_08ba:
																												num6--;
																												goto end_IL_066d;
																												IL_08cd:
																												if (4 < b)
																												{
																													break;
																												}
																												goto IL_08db;
																												IL_08db:
																												if (4 > b)
																												{
																													break;
																												}
																												goto IL_08e9;
																												IL_08e9:
																												array[num6] = 0;
																												goto IL_08f7;
																												IL_08f7:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_091a;
																												IL_091a:
																												array2[num6] = null;
																												goto IL_0924;
																											}
																											goto end_IL_06aa;
																											continue;
																											end_IL_066d:
																											break;
																											IL_066d:;
																										}
																										break;
																									}
																									goto IL_0b51;
																									IL_0f4d:
																									if (21 < b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0f5b;
																									IL_0b51:
																									if (16 >= b)
																									{
																										goto IL_0b5f;
																									}
																									goto IL_0d6f;
																									IL_0b5f:
																									if (16 <= b)
																									{
																										goto IL_0b6a;
																									}
																									goto IL_0bbd;
																									IL_0b6a:
																									array[num6] = 3;
																									goto IL_0b78;
																									IL_0b78:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])();
																									goto IL_0b9c;
																									IL_0b9c:
																									num6++;
																									goto IL_0baa;
																									IL_0baa:
																									ptr2 += 8;
																									break;
																									IL_0bbd:
																									if (13 >= b)
																									{
																										goto IL_0bcb;
																									}
																									goto IL_0c6d;
																									IL_0bcb:
																									if (13 <= b)
																									{
																										num = 177;
																										goto IL_0bdf;
																									}
																									goto IL_0bf7;
																									IL_0f5b:
																									if (21 > b)
																									{
																										goto end_IL_06aa;
																									}
																									num = 313;
																									goto IL_0f72;
																									IL_0bdf:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									break;
																									IL_0bf7:
																									if (12 < b)
																									{
																										goto end_IL_06aa;
																									}
																									num = 84;
																									goto IL_0c0e;
																									IL_0fe0:
																									num6 -= 2;
																									break;
																									IL_0c0e:
																									if (12 > b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0c1c;
																									IL_0c1c:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									num = 143;
																									goto IL_0c3e;
																									IL_0c3e:
																									array[num6] = 1;
																									goto IL_0c4c;
																									IL_0c4c:
																									num6++;
																									goto IL_0c5a;
																									IL_0c5a:
																									ptr2 += 16;
																									break;
																									IL_0c6d:
																									if (14 >= b)
																									{
																										goto IL_0c78;
																									}
																									goto IL_0cee;
																									IL_0c78:
																									if (14 > b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0c86;
																									IL_0c86:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																									goto IL_0cc7;
																									IL_0cc7:
																									array[num6 - 2] = 0;
																									goto IL_0cdb;
																									IL_0cdb:
																									num6--;
																									break;
																									IL_0cee:
																									if (15 < b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0cfc;
																									IL_0cfc:
																									if (15 > b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0d0a;
																									IL_0d0a:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0d5c;
																									IL_0d5c:
																									num6--;
																									break;
																									IL_0d6f:
																									if (19 >= b)
																									{
																										goto IL_0d7d;
																									}
																									goto IL_0ec4;
																									IL_0d7d:
																									if (19 <= b)
																									{
																										goto IL_0d88;
																									}
																									goto IL_0dda;
																									IL_0d88:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																									num = 167;
																									goto IL_0dab;
																									IL_0dab:
																									array[num6] = 3;
																									goto IL_0db9;
																									IL_0db9:
																									num6++;
																									goto IL_0dc7;
																									IL_0dc7:
																									ptr2 += 8;
																									break;
																									IL_0dda:
																									if (17 >= b)
																									{
																										goto IL_0de5;
																									}
																									goto IL_0e3a;
																									IL_0de5:
																									if (17 > b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0df3;
																									IL_0df3:
																									array2[num6] = array5[*(int*)(ptr2 + num3)];
																									goto IL_0e0b;
																									IL_0e0b:
																									array[num6] = 5;
																									goto IL_0e19;
																									IL_0e19:
																									num6++;
																									goto IL_0e27;
																									IL_0e27:
																									ptr2 += 8;
																									break;
																									IL_0e3a:
																									if (18 < b)
																									{
																										goto end_IL_06aa;
																									}
																									num = 134;
																									goto IL_0e51;
																									IL_0f72:
																									ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_0fe0;
																									IL_0e51:
																									if (18 > b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0e5f;
																									IL_0e5f:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Class177, float>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])((Class177)array2[num6 - 1]);
																									goto IL_0e9d;
																									IL_0e9d:
																									array[num6 - 1] = 3;
																									goto IL_0eb1;
																									IL_0eb1:
																									ptr2 += 8;
																									break;
																									IL_0ec4:
																									if (20 >= b)
																									{
																										goto IL_0ecf;
																									}
																									goto IL_0f4d;
																									IL_0ecf:
																									if (20 > b)
																									{
																										goto end_IL_06aa;
																									}
																									goto IL_0edd;
																									IL_0edd:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0f1d;
																									IL_0f1d:
																									array[num6 - 2] = 3;
																									goto IL_0f31;
																									IL_0f31:
																									num6--;
																									num = 212;
																									break;
																								}
																								break;
																							}
																							goto IL_0701;
																							IL_0857:
																							ptr2 += 16;
																							break;
																							IL_0701:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																							goto IL_071a;
																							IL_071a:
																							array[num6] = 3;
																							goto IL_0728;
																							IL_0728:
																							num6++;
																							goto IL_0857;
																						}
																						break;
																					}
																					goto IL_0ff3;
																					IL_18e2:
																					((Class177)array2[num6 - 2]).float_1 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1910;
																					IL_0ff3:
																					if (33 < b)
																					{
																						goto IL_1001;
																					}
																					num = 340;
																					goto IL_14ad;
																					IL_1001:
																					if (38 >= b)
																					{
																						goto IL_100f;
																					}
																					goto IL_12af;
																					IL_100f:
																					if (38 <= b)
																					{
																						goto IL_101d;
																					}
																					goto IL_109e;
																					IL_101d:
																					ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_108b;
																					IL_108b:
																					num6 -= 2;
																					break;
																					IL_109e:
																					if (35 >= b)
																					{
																						goto IL_10ac;
																					}
																					goto IL_11a7;
																					IL_10ac:
																					if (35 > b)
																					{
																						goto IL_10ba;
																					}
																					num = 334;
																					goto IL_117a;
																					IL_10ba:
																					if (34 < b)
																					{
																						goto end_IL_06aa;
																					}
																					num = 219;
																					goto IL_10d1;
																					IL_1929:
																					if (31 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_1934;
																					IL_10d1:
																					if (34 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_10df;
																					IL_10df:
																					array[num6 - 2] = 3;
																					goto IL_10f3;
																					IL_10f3:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<float, float, float>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																					num = 57;
																					goto IL_1150;
																					IL_1150:
																					num6--;
																					goto IL_115e;
																					IL_115e:
																					ptr2 += 8;
																					break;
																					IL_1974:
																					ptr2 += 8;
																					break;
																					IL_117a:
																					global::_003CModule_003E.float_110 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_1194;
																					IL_1194:
																					num6--;
																					break;
																					IL_11a7:
																					if (36 >= b)
																					{
																						goto IL_11b2;
																					}
																					goto IL_122e;
																					IL_11b2:
																					if (36 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_11c0;
																					IL_11c0:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Class177, float>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])((Class177)array2[num6 - 1]);
																					num = 138;
																					goto IL_1207;
																					IL_1207:
																					array[num6 - 1] = 3;
																					goto IL_121b;
																					IL_121b:
																					ptr2 += 8;
																					break;
																					IL_122e:
																					if (37 < b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_123c;
																					IL_123c:
																					if (37 > b)
																					{
																						goto end_IL_06aa;
																					}
																					num = 241;
																					goto IL_1253;
																					IL_1934:
																					array[num6] = 3;
																					goto IL_1942;
																					IL_1253:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])();
																					num = 328;
																					goto IL_1280;
																					IL_1280:
																					array[num6] = 3;
																					goto IL_128e;
																					IL_128e:
																					num6++;
																					goto IL_129c;
																					IL_129c:
																					ptr2 += 8;
																					break;
																					IL_12af:
																					if (41 >= b)
																					{
																						goto IL_12bd;
																					}
																					goto IL_1402;
																					IL_12bd:
																					if (41 <= b)
																					{
																						goto IL_12c8;
																					}
																					goto IL_132d;
																					IL_12c8:
																					array[num6 - 1] = 0;
																					goto IL_12dc;
																					IL_12dc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (((delegate*<Behaviour, bool>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]) ? 1 : 0);
																					goto IL_131a;
																					IL_131a:
																					ptr2 += 8;
																					break;
																					IL_132d:
																					if (39 >= b)
																					{
																						goto IL_1338;
																					}
																					goto IL_1399;
																					IL_1338:
																					if (39 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_1346;
																					IL_1346:
																					((Class177)array2[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 115;
																					goto IL_137d;
																					IL_137d:
																					num6 -= 2;
																					num = 262;
																					break;
																					IL_1399:
																					if (40 < b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_13a7;
																					IL_13a7:
																					if (40 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_13b5;
																					IL_13b5:
																					array[num6] = 5;
																					goto IL_13c3;
																					IL_13c3:
																					array2[num6] = ((delegate*<GorillaTagger>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])();
																					goto IL_13e1;
																					IL_13e1:
																					num6++;
																					goto IL_13ef;
																					IL_13ef:
																					ptr2 += 8;
																					break;
																					IL_1402:
																					if (42 >= b)
																					{
																						goto IL_140d;
																					}
																					goto IL_147a;
																					IL_140d:
																					if (42 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_141b;
																					IL_141b:
																					((delegate*<Behaviour, bool, void>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0);
																					goto IL_1459;
																					IL_1459:
																					num6 -= 2;
																					goto IL_1467;
																					IL_1467:
																					ptr2 += 8;
																					break;
																					IL_147a:
																					if (43 < b)
																					{
																						goto end_IL_06aa;
																					}
																					num = 258;
																					goto IL_1491;
																					IL_1942:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])();
																					goto IL_1966;
																					IL_1491:
																					if (43 > b)
																					{
																					}
																					goto end_IL_06aa;
																					IL_1910:
																					num6 -= 2;
																					break;
																					IL_14ad:
																					if (33 <= b)
																					{
																						goto IL_14b8;
																					}
																					goto IL_14fc;
																					IL_14b8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_14e3;
																					IL_14e3:
																					array[num6 - 1] = 0;
																					break;
																					IL_14fc:
																					if (27 >= b)
																					{
																						goto IL_150a;
																					}
																					goto IL_1725;
																					IL_150a:
																					if (27 <= b)
																					{
																						goto IL_1515;
																					}
																					goto IL_1574;
																					IL_1515:
																					array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																					goto IL_154d;
																					IL_154d:
																					array[num6 - 1] = 5;
																					goto IL_1561;
																					IL_1561:
																					ptr2 += 8;
																					break;
																					IL_1574:
																					if (24 >= b)
																					{
																						goto IL_1582;
																					}
																					goto IL_167e;
																					IL_1582:
																					if (24 <= b)
																					{
																						goto IL_158d;
																					}
																					goto IL_15f3;
																					IL_158d:
																					array[num6 - 1] = 0;
																					goto IL_15a1;
																					IL_15a1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_15e0;
																					IL_15e0:
																					ptr2 += 8;
																					break;
																					IL_15f3:
																					if (23 < b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_1601;
																					IL_1601:
																					if (23 > b)
																					{
																						goto end_IL_06aa;
																					}
																					num = 72;
																					goto IL_1618;
																					IL_1966:
																					num6++;
																					goto IL_1974;
																					IL_1618:
																					array[num6 - 1] = 3;
																					goto IL_162c;
																					IL_162c:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					goto IL_166b;
																					IL_166b:
																					ptr2 += 8;
																					break;
																					IL_167e:
																					if (25 >= b)
																					{
																						goto IL_1689;
																					}
																					goto IL_16b3;
																					IL_1689:
																					if (25 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_1697;
																					IL_1697:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					break;
																					IL_16b3:
																					if (26 < b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_16c1;
																					IL_16c1:
																					if (26 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_16cf;
																					IL_16cf:
																					array[num6] = 5;
																					goto IL_16dd;
																					IL_16dd:
																					array2[num6] = ((delegate*<GorillaTagger>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])();
																					num = 135;
																					goto IL_1704;
																					IL_1704:
																					num6++;
																					goto IL_1712;
																					IL_1712:
																					ptr2 += 8;
																					break;
																					IL_1725:
																					if (30 >= b)
																					{
																						goto IL_1733;
																					}
																					goto IL_18bb;
																					IL_1733:
																					if (30 > b)
																					{
																						goto IL_1741;
																					}
																					goto IL_184c;
																					IL_1741:
																					if (28 >= b)
																					{
																						goto IL_174c;
																					}
																					goto IL_17bf;
																					IL_174c:
																					if (28 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_175a;
																					IL_175a:
																					array[num6 - 1] = 0;
																					goto IL_176e;
																					IL_176e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (((delegate*<Behaviour, bool>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]) ? 1 : 0);
																					goto IL_17ac;
																					IL_17ac:
																					ptr2 += 8;
																					break;
																					IL_17bf:
																					if (29 < b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_17cd;
																					IL_17cd:
																					if (29 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_17db;
																					IL_17db:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_1839;
																					IL_1839:
																					num6--;
																					break;
																					IL_184c:
																					array[num6 - 1] = 3;
																					goto IL_1860;
																					IL_1860:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)InvalidHebrewNumberTaskScheduler[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																					num = 5;
																					goto IL_18a8;
																					IL_18a8:
																					ptr2 += 8;
																					break;
																					IL_18bb:
																					if (31 < b)
																					{
																						goto IL_18c6;
																					}
																					num = 66;
																					goto IL_1929;
																					IL_18c6:
																					if (32 < b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_18d4;
																					IL_18d4:
																					if (32 > b)
																					{
																						goto end_IL_06aa;
																					}
																					goto IL_18e2;
																				}
																				goto end_IL_06ba;
																				continue;
																				end_IL_06aa:
																				break;
																				IL_06aa:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		break;
																		continue;
																		end_IL_06ba:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														num = 197;
														return;
														continue;
														end_IL_1997:
														break;
													}
													continue;
													end_IL_19aa:
													break;
												}
												continue;
												end_IL_19b4:
												break;
											}
											continue;
											end_IL_19bf:
											break;
										}
										continue;
										end_IL_19cf:
										break;
									}
									continue;
									end_IL_19df:
									break;
								}
								continue;
								end_IL_19ef:
								break;
							}
							continue;
							end_IL_19ff:
							break;
						}
						continue;
						end_IL_1a0f:
						break;
					}
					continue;
					end_IL_1a1f:
					break;
				}
				continue;
				end_IL_1a38:
				break;
			}
		}
	}

	private void OnDisable()
	{
		GorillaTagger instance = GorillaTagger.Instance;
		VRRig offlineVRRig = instance.offlineVRRig;
		ReadDataEntryPointCommandLineFile(offlineVRRig, bool_0: true);
	}

	public Class177()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 8;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 7;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadLineAsyncInternaldgetDateTime.RemoveFullTrustAssemblyAddBinary);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0355:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0338:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_032b:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_031b:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_030b:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02fb:
																											if (2 < b)
																											{
																												while (3 >= b)
																												{
																													while (3 <= b)
																													{
																														num = 59;
																														while (true)
																														{
																															IL_02a4:
																															array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																															num = 157;
																															while (true)
																															{
																																if (num != 157)
																																{
																																	if (num != 1138)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 59:
																																	case 126:
																																		goto IL_02a4;
																																	case 47:
																																		goto IL_02d8;
																																	case 2:
																																	case 101:
																																		goto IL_02eb;
																																	case 26:
																																	case 134:
																																		goto IL_02fb;
																																	case 12:
																																		goto IL_030b;
																																	case 62:
																																		goto IL_031b;
																																	case 29:
																																		goto IL_032b;
																																	case 102:
																																		goto IL_0338;
																																	case 77:
																																		goto IL_0345;
																																	case 114:
																																		goto IL_0355;
																																	case 85:
																																		goto end_IL_0355;
																																	case 40:
																																	case 41:
																																		goto end_IL_0365;
																																	case 66:
																																	case 100:
																																		goto IL_0380;
																																	case 44:
																																	case 140:
																																		goto IL_0398;
																																	case 60:
																																		goto end_IL_0291;
																																	case 31:
																																	case 42:
																																		goto IL_03b1;
																																	case 81:
																																		goto IL_03f1;
																																	case 9:
																																		goto IL_040a;
																																	case 107:
																																		goto IL_0418;
																																	case 117:
																																		goto IL_0426;
																																	case 50:
																																	case 54:
																																		goto IL_0434;
																																	case 20:
																																		goto IL_0478;
																																	case 108:
																																		goto IL_048c;
																																	case 113:
																																		goto IL_04a8;
																																	case 18:
																																	case 30:
																																		goto IL_04b3;
																																	case 35:
																																		goto IL_04c1;
																																	case 79:
																																	case 84:
																																		goto IL_04d4;
																																	case 87:
																																		goto IL_04e2;
																																	case 99:
																																		goto IL_0505;
																																	case 58:
																																		goto IL_050f;
																																	case 37:
																																		goto IL_051d;
																																	case 74:
																																	case 148:
																																		goto IL_0539;
																																	case 14:
																																		goto IL_0547;
																																	case 98:
																																	case 142:
																																		goto IL_0552;
																																	case 27:
																																		goto IL_056e;
																																	case 28:
																																		goto IL_057c;
																																	case 93:
																																	case 137:
																																		goto IL_058a;
																																	case 76:
																																		goto IL_05ec;
																																	case 83:
																																		goto IL_05ff;
																																	case 3:
																																		goto IL_060d;
																																	case 149:
																																		goto IL_0620;
																																	case 72:
																																		goto IL_064c;
																																	case 11:
																																	case 82:
																																		goto IL_0657;
																																	case 120:
																																		goto IL_066e;
																																	case 86:
																																	case 144:
																																		goto IL_067c;
																																	case 70:
																																		goto IL_0695;
																																	case 49:
																																		goto IL_06a3;
																																	case 32:
																																		goto IL_06b1;
																																	case 24:
																																	case 143:
																																		goto IL_06c4;
																																	case 57:
																																		goto IL_0704;
																																	case 43:
																																		goto IL_0718;
																																	case 92:
																																	case 112:
																																		goto IL_072b;
																																	case 90:
																																		goto IL_0749;
																																	case 124:
																																		goto IL_0760;
																																	case 131:
																																	case 136:
																																		goto IL_077c;
																																	case 52:
																																	case 69:
																																		goto IL_0787;
																																	case 119:
																																		goto IL_079e;
																																	case 91:
																																	case 133:
																																		goto IL_07ac;
																																	case 4:
																																		goto IL_07d5;
																																	case 13:
																																		goto IL_07e3;
																																	case 75:
																																		goto IL_07f6;
																																	case 5:
																																	case 135:
																																		goto IL_0801;
																																	case 55:
																																		goto IL_080f;
																																	case 97:
																																	case 123:
																																		goto IL_081d;
																																	case 34:
																																		goto IL_082b;
																																	case 22:
																																		goto IL_0843;
																																	case 61:
																																		goto IL_0851;
																																	case 17:
																																	case 105:
																																		goto IL_0861;
																																	case 78:
																																		goto IL_08a0;
																																	case 0:
																																	case 15:
																																	case 16:
																																	case 25:
																																	case 36:
																																	case 39:
																																	case 45:
																																	case 46:
																																	case 48:
																																	case 53:
																																	case 64:
																																	case 67:
																																	case 71:
																																	case 73:
																																	case 88:
																																	case 94:
																																	case 95:
																																	case 96:
																																	case 106:
																																	case 110:
																																	case 121:
																																	case 128:
																																	case 130:
																																	case 132:
																																	case 138:
																																	case 139:
																																	case 141:
																																	case 147:
																																		goto end_IL_02d8;
																																	case 1:
																																	case 10:
																																	case 23:
																																	case 33:
																																	case 38:
																																	case 51:
																																	case 56:
																																	case 63:
																																	case 65:
																																	case 80:
																																	case 104:
																																	case 109:
																																	case 111:
																																	case 116:
																																	case 122:
																																	case 125:
																																	case 127:
																																	case 150:
																																		goto end_IL_0375;
																																	case 145:
																																		goto end_IL_08cc;
																																	case 129:
																																		goto end_IL_08df;
																																	case 146:
																																		goto end_IL_08e9;
																																	case 89:
																																		goto end_IL_08f4;
																																	case 6:
																																	case 19:
																																		goto end_IL_0904;
																																	case 118:
																																		goto end_IL_0914;
																																	case 68:
																																	case 103:
																																		goto end_IL_0924;
																																	case 7:
																																		goto end_IL_0934;
																																	case 8:
																																		goto end_IL_0944;
																																	case 21:
																																	case 115:
																																		goto IL_0968;
																																	}
																																	continue;
																																}
																																array[num5 - 1] = 5;
																																goto end_IL_0375;
																																continue;
																																end_IL_0291:
																																break;
																															}
																															break;
																														}
																														goto IL_03a6;
																														continue;
																														end_IL_02d8:
																														break;
																														IL_02d8:;
																													}
																													break;
																													IL_02eb:;
																												}
																												break;
																											}
																											goto IL_064c;
																											IL_0704:
																											array[num5 - 2] = 0;
																											goto IL_0718;
																											IL_064c:
																											if (2 > b)
																											{
																												goto IL_0657;
																											}
																											goto IL_06c4;
																											IL_0657:
																											if (1 < b)
																											{
																												break;
																											}
																											num = 120;
																											goto IL_066e;
																											IL_0718:
																											num5--;
																											goto end_IL_0375;
																											IL_066e:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_067c;
																											IL_067c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0695;
																											IL_0695:
																											array[num5] = 0;
																											goto IL_06a3;
																											IL_06a3:
																											num5++;
																											goto IL_06b1;
																											IL_06b1:
																											ptr2 += 8;
																											goto end_IL_0375;
																											IL_06c4:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0704;
																										}
																										break;
																									}
																									goto IL_072b;
																									IL_0760:
																									num5--;
																									goto end_IL_0375;
																									IL_072b:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_0749;
																									IL_0749:
																									ptr2 += 8;
																									num = 124;
																									goto IL_0760;
																								}
																								break;
																							}
																							num = 136;
																							goto IL_077c;
																							IL_0851:
																							ptr2 += 8;
																							goto end_IL_0375;
																							IL_0861:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_08a0;
																							IL_077c:
																							if (6 < b)
																							{
																								goto IL_0787;
																							}
																							goto IL_07f6;
																							IL_0787:
																							if (7 < b)
																							{
																								break;
																							}
																							num = 119;
																							goto IL_079e;
																							IL_08a0:
																							num5 -= 3;
																							goto end_IL_0375;
																							IL_079e:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_07ac;
																							IL_07ac:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07d5;
																							IL_07d5:
																							ptr2 += 8;
																							goto IL_07e3;
																							IL_07e3:
																							num5--;
																							goto end_IL_0375;
																							IL_07f6:
																							if (6 > b)
																							{
																								goto IL_0801;
																							}
																							goto IL_0861;
																							IL_0801:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_080f;
																							IL_080f:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_081d;
																							IL_081d:
																							array[num5] = 5;
																							goto IL_082b;
																							IL_082b:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0843;
																							IL_0843:
																							num5++;
																							goto IL_0851;
																						}
																						break;
																					}
																					goto IL_0380;
																					IL_0380:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0375;
																				}
																				break;
																			}
																			goto IL_0398;
																			IL_05ff:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_060d;
																			IL_0398:
																			if (12 >= b)
																			{
																				goto IL_03a6;
																			}
																			goto IL_0539;
																			IL_03a6:
																			if (12 <= b)
																			{
																				goto IL_03b1;
																			}
																			goto IL_040a;
																			IL_03b1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03f1;
																			IL_03f1:
																			array[num5 - 2] = 0;
																			goto IL_0620;
																			IL_0620:
																			num5--;
																			goto end_IL_0375;
																			IL_040a:
																			if (10 < b)
																			{
																				goto IL_0418;
																			}
																			num = 113;
																			goto IL_04a8;
																			IL_0418:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0426;
																			IL_0426:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0434;
																			IL_0434:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0478;
																			IL_0478:
																			array[num5 - 2] = 0;
																			goto IL_048c;
																			IL_048c:
																			num5--;
																			goto end_IL_0375;
																			IL_060d:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_04a8:
																			if (10 > b)
																			{
																				goto IL_04b3;
																			}
																			goto IL_04d4;
																			IL_04b3:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_04c1;
																			IL_04c1:
																			if (9 <= b)
																			{
																				goto end_IL_0375;
																			}
																			break;
																			IL_04d4:
																			array[num5] = 0;
																			goto IL_04e2;
																			IL_04e2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0505;
																			IL_0505:
																			array2[num5] = null;
																			goto IL_050f;
																			IL_050f:
																			num5++;
																			goto IL_051d;
																			IL_051d:
																			ptr2 += 8;
																			num = 56;
																			goto end_IL_0375;
																			IL_0539:
																			if (14 >= b)
																			{
																				goto IL_0547;
																			}
																			goto IL_05ff;
																			IL_0547:
																			if (14 <= b)
																			{
																				goto IL_0552;
																			}
																			goto IL_056e;
																			IL_0552:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0375;
																			IL_056e:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_057c;
																			IL_057c:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_058a;
																			IL_058a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05ec;
																			IL_05ec:
																			num5 -= 2;
																			goto end_IL_0375;
																		}
																		break;
																		IL_0345:;
																	}
																}
																else
																{
																	num = 95;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0375;
																continue;
																end_IL_0355:
																break;
															}
															continue;
															end_IL_0365:
															break;
														}
														continue;
														end_IL_0375:
														break;
													}
													continue;
												}
												goto IL_0968;
												IL_0968:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08cc:
												break;
											}
											continue;
											end_IL_08df:
											break;
										}
										continue;
										end_IL_08e9:
										break;
									}
									continue;
									end_IL_08f4:
									break;
								}
								continue;
								end_IL_0904:
								break;
							}
							continue;
							end_IL_0914:
							break;
						}
						continue;
						end_IL_0924:
						break;
					}
					continue;
					end_IL_0934:
					break;
				}
				continue;
				end_IL_0944:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_0, int int_1)
	{
		int num = 19;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 111;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref bodyWithStateSystemThreadingTasksTaskSchedulerDebugView.CharArraygetScheduledConcurrent);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_02d5:
																byte b = *ptr2;
																while (true)
																{
																	IL_02c5:
																	ptr2++;
																	while (true)
																	{
																		IL_02b5:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_0295:
																					if (6 >= b)
																					{
																						while (6 > b)
																						{
																							while (true)
																							{
																								IL_0275:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0268:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_022a:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														num = 130;
																														while (num != 130)
																														{
																															if (num != 1111)
																															{
																																goto end_IL_0248;
																															}
																															switch (num)
																															{
																															case 94:
																															case 116:
																																goto IL_022a;
																															case 1:
																																goto IL_0248;
																															case 117:
																																goto IL_0258;
																															case 52:
																															case 110:
																																goto IL_0268;
																															case 25:
																															case 35:
																																goto IL_0275;
																															case 10:
																																goto IL_0285;
																															case 112:
																																goto IL_0295;
																															case 105:
																																goto IL_02a5;
																															case 84:
																																goto IL_02b5;
																															case 24:
																																goto IL_02c5;
																															case 37:
																															case 79:
																																goto IL_02d5;
																															case 80:
																																goto IL_02e0;
																															case 33:
																															case 106:
																																goto IL_02ee;
																															case 88:
																																goto IL_0317;
																															case 51:
																																goto IL_0325;
																															case 83:
																																goto IL_0338;
																															case 38:
																															case 87:
																																goto IL_0343;
																															case 118:
																																goto IL_0383;
																															case 9:
																																goto IL_0397;
																															case 57:
																																goto IL_03aa;
																															case 15:
																															case 92:
																																goto IL_03b8;
																															case 121:
																																goto IL_03c6;
																															case 22:
																															case 55:
																																goto IL_03d4;
																															case 13:
																																goto IL_0442;
																															case 74:
																																goto IL_045e;
																															case 86:
																																goto IL_0471;
																															case 26:
																															case 98:
																																goto IL_047f;
																															case 4:
																																goto IL_048a;
																															case 27:
																																goto IL_0498;
																															case 85:
																															case 122:
																																goto IL_04b1;
																															case 75:
																																goto IL_04d6;
																															case 47:
																															case 59:
																																goto IL_04e4;
																															case 101:
																																goto IL_04f2;
																															case 40:
																															case 89:
																																goto IL_0500;
																															case 108:
																																goto IL_0514;
																															case 100:
																																goto IL_0553;
																															case 17:
																															case 70:
																																goto IL_0566;
																															case 107:
																																goto IL_0579;
																															case 20:
																															case 71:
																																goto IL_0587;
																															case 11:
																																goto IL_0592;
																															case 28:
																															case 97:
																																goto IL_05a0;
																															case 61:
																																goto IL_05ae;
																															case 32:
																																goto IL_05d1;
																															case 48:
																																goto IL_05db;
																															case 67:
																																goto IL_05e9;
																															case 53:
																																goto IL_05fc;
																															case 96:
																																goto IL_0613;
																															case 60:
																															case 72:
																																goto IL_0621;
																															case 62:
																																goto IL_063a;
																															case 7:
																																goto IL_0648;
																															case 14:
																																goto IL_0656;
																															case 43:
																															case 99:
																																goto IL_0669;
																															case 56:
																																goto IL_06a9;
																															case 63:
																																goto IL_06bd;
																															case 2:
																															case 5:
																															case 6:
																															case 8:
																															case 12:
																															case 23:
																															case 29:
																															case 36:
																															case 45:
																															case 49:
																															case 50:
																															case 58:
																															case 64:
																															case 69:
																															case 73:
																															case 77:
																															case 81:
																															case 91:
																															case 109:
																															case 113:
																															case 115:
																															case 120:
																																goto end_IL_0248;
																															case 78:
																																goto IL_06f0;
																															case 44:
																																goto IL_06fe;
																															case 90:
																																goto IL_070c;
																															case 16:
																															case 21:
																															case 30:
																															case 34:
																															case 42:
																															case 54:
																															case 65:
																															case 76:
																															case 82:
																															case 102:
																															case 103:
																															case 104:
																															case 114:
																															case 119:
																																goto end_IL_0217;
																															case 95:
																																goto end_IL_071a;
																															case 31:
																																goto end_IL_072d;
																															case 41:
																																goto end_IL_0737;
																															case 68:
																																goto end_IL_0742;
																															case 93:
																																goto end_IL_0757;
																															case 3:
																															case 39:
																																goto end_IL_076c;
																															case 46:
																																goto end_IL_077c;
																															case 111:
																																goto end_IL_078c;
																															case 123:
																																goto end_IL_079c;
																															case 18:
																																goto end_IL_07ac;
																															case 19:
																																goto end_IL_07b7;
																															case 0:
																															case 66:
																																goto IL_07d2;
																															}
																															continue;
																															end_IL_0217:
																															break;
																														}
																														break;
																													}
																													goto end_IL_0285;
																													continue;
																													end_IL_0248:
																													break;
																													IL_0248:;
																												}
																												break;
																												IL_0258:;
																											}
																											break;
																										}
																										goto IL_02e0;
																										IL_0325:
																										num5--;
																										goto end_IL_0285;
																										IL_02e0:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_02ee;
																										IL_02ee:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0317;
																										IL_0317:
																										ptr2 += 8;
																										goto IL_0325;
																									}
																									break;
																								}
																								goto IL_0338;
																								IL_045e:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0338:
																								if (3 <= b)
																								{
																									goto IL_0343;
																								}
																								goto IL_03aa;
																								IL_0343:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0383;
																								IL_0383:
																								array[num5 - 2] = 0;
																								goto IL_0397;
																								IL_0397:
																								num5--;
																								goto end_IL_0285;
																								IL_03aa:
																								if (1 < b)
																								{
																									goto IL_03b8;
																								}
																								goto IL_045e;
																								IL_03b8:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_03c6;
																								IL_03c6:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_03d4;
																								IL_03d4:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0442;
																								IL_0442:
																								num5 -= 2;
																								num = 21;
																								goto end_IL_0285;
																							}
																							goto end_IL_02a5;
																							continue;
																							end_IL_0285:
																							break;
																							IL_0285:;
																						}
																						break;
																					}
																					goto IL_0471;
																					IL_0656:
																					ptr2 += 8;
																					break;
																					IL_0471:
																					if (9 < b)
																					{
																						goto IL_047f;
																					}
																					goto IL_0579;
																					IL_047f:
																					if (11 < b)
																					{
																						goto IL_048a;
																					}
																					num = 75;
																					goto IL_04d6;
																					IL_048a:
																					if (12 < b)
																					{
																						goto end_IL_02a5;
																					}
																					goto IL_0498;
																					IL_0498:
																					if (12 > b)
																					{
																						num = 69;
																						goto end_IL_02a5;
																					}
																					goto IL_04b1;
																					IL_06a9:
																					array[num5 - 2] = 0;
																					goto IL_06bd;
																					IL_04b1:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_0669:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_06a9;
																					IL_04d6:
																					if (11 > b)
																					{
																						goto IL_04e4;
																					}
																					goto IL_0566;
																					IL_04e4:
																					if (10 < b)
																					{
																						goto end_IL_02a5;
																					}
																					goto IL_04f2;
																					IL_04f2:
																					if (10 > b)
																					{
																						goto end_IL_02a5;
																					}
																					goto IL_0500;
																					IL_0500:
																					array[num5 - 1] = 0;
																					goto IL_0514;
																					IL_0514:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)intptr_0[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0553;
																					IL_0553:
																					ptr2 += 8;
																					break;
																					IL_0566:
																					num5--;
																					break;
																					IL_0579:
																					if (9 > b)
																					{
																						goto IL_0587;
																					}
																					goto IL_0669;
																					IL_0587:
																					if (7 >= b)
																					{
																						goto IL_0592;
																					}
																					goto IL_05fc;
																					IL_0592:
																					if (7 > b)
																					{
																						goto end_IL_02a5;
																					}
																					goto IL_05a0;
																					IL_05a0:
																					array[num5] = 0;
																					goto IL_05ae;
																					IL_05ae:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05d1;
																					IL_05d1:
																					array2[num5] = null;
																					goto IL_05db;
																					IL_05db:
																					num5++;
																					goto IL_05e9;
																					IL_05e9:
																					ptr2 += 8;
																					break;
																					IL_05fc:
																					if (8 < b)
																					{
																						goto end_IL_02a5;
																					}
																					num = 96;
																					goto IL_0613;
																					IL_06bd:
																					num5--;
																					break;
																					IL_0613:
																					if (8 > b)
																					{
																						goto end_IL_02a5;
																					}
																					goto IL_0621;
																					IL_0621:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_063a;
																					IL_063a:
																					array[num5] = 0;
																					goto IL_0648;
																					IL_0648:
																					num5++;
																					goto IL_0656;
																				}
																				goto end_IL_02b5;
																				continue;
																				end_IL_02a5:
																				break;
																				IL_02a5:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_06f0;
																		IL_070c:
																		ptr2 += 8;
																		break;
																		IL_06fe:
																		num5++;
																		goto IL_070c;
																		IL_06f0:
																		array[num5] = 0;
																		goto IL_06fe;
																		continue;
																		end_IL_02b5:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_07d2;
														IL_07d2:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_071a:
														break;
													}
													continue;
													end_IL_072d:
													break;
												}
												continue;
												end_IL_0737:
												break;
											}
											continue;
											end_IL_0742:
											break;
										}
										continue;
										end_IL_0757:
										break;
									}
									continue;
									end_IL_076c:
									break;
								}
								continue;
								end_IL_077c:
								break;
							}
							continue;
							end_IL_078c:
							break;
						}
						continue;
						end_IL_079c:
						break;
					}
					continue;
					end_IL_07ac:
					break;
				}
				continue;
				end_IL_07b7:
				break;
			}
		}
	}

	private static int smethod_2(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		num += num2;
		int num3 = num;
		num = int_0;
		num2 = int_1;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 990;
		num2 = 90;
		return num + 90;
	}

	private unsafe static int smethod_3(int int_0)
	{
		int num = 34;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 74;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									num = 36;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsCreatedIsNumber.FormatAssemblyIsSubsetOfPathDiscovery);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 39;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0234:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0214:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0204:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_01f4:
																								if (2 < b)
																								{
																									num = 113;
																									while (true)
																									{
																										if (num != 113)
																										{
																											if (num != 1094)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 53:
																											case 55:
																												goto IL_01f4;
																											case 18:
																												goto IL_0204;
																											case 66:
																												goto IL_0214;
																											case 67:
																												goto end_IL_0214;
																											case 91:
																												goto IL_0234;
																											case 101:
																												goto end_IL_0234;
																											case 61:
																											case 84:
																												goto end_IL_0244;
																											case 48:
																												goto IL_025f;
																											case 65:
																											case 86:
																												goto IL_026d;
																											case 87:
																												goto IL_027b;
																											case 9:
																											case 23:
																												goto IL_0292;
																											case 81:
																												goto IL_02ab;
																											case 41:
																												goto IL_02b9;
																											case 77:
																												goto IL_02c7;
																											case 44:
																											case 96:
																												goto IL_02da;
																											case 42:
																											case 89:
																												goto IL_02e5;
																											case 27:
																												goto IL_02f0;
																											case 14:
																											case 63:
																												goto IL_02fe;
																											case 46:
																												goto IL_031a;
																											case 69:
																												goto IL_0328;
																											case 40:
																												goto IL_033b;
																											case 75:
																											case 90:
																												goto end_IL_01e1;
																											case 2:
																												goto IL_03a8;
																											case 92:
																												goto IL_03bb;
																											case 38:
																											case 80:
																												goto IL_03c6;
																											case 76:
																												goto IL_03d4;
																											case 32:
																											case 59:
																												goto IL_03e2;
																											case 45:
																												goto IL_0405;
																											case 37:
																												goto IL_0413;
																											case 56:
																												goto IL_0423;
																											case 29:
																											case 68:
																												goto IL_0431;
																											case 79:
																												goto IL_0471;
																											case 51:
																												goto IL_0485;
																											case 100:
																												goto IL_0498;
																											case 93:
																											case 104:
																												goto IL_04ab;
																											case 3:
																												goto IL_04dd;
																											case 88:
																												goto IL_04eb;
																											case 10:
																												goto IL_04fe;
																											case 11:
																												goto IL_0509;
																											case 73:
																												goto IL_0517;
																											case 52:
																												goto IL_0533;
																											case 22:
																											case 31:
																												goto IL_053e;
																											case 20:
																											case 43:
																												goto IL_055e;
																											case 1:
																												goto IL_056c;
																											case 83:
																												goto IL_058f;
																											case 17:
																												goto IL_0599;
																											case 4:
																												goto IL_05a7;
																											case 0:
																											case 5:
																											case 12:
																											case 19:
																											case 21:
																											case 26:
																											case 28:
																											case 35:
																											case 54:
																											case 57:
																											case 60:
																											case 72:
																											case 78:
																											case 82:
																											case 95:
																											case 97:
																											case 98:
																											case 99:
																											case 102:
																											case 103:
																												goto end_IL_0224;
																											case 13:
																											case 15:
																											case 16:
																											case 25:
																											case 30:
																											case 39:
																											case 50:
																											case 58:
																											case 70:
																											case 71:
																											case 105:
																											case 106:
																												goto end_IL_0254;
																											case 49:
																												goto end_IL_05ca;
																											case 24:
																												goto end_IL_05dd;
																											case 36:
																												goto end_IL_05e8;
																											case 64:
																												goto end_IL_05f2;
																											case 6:
																												goto end_IL_05fd;
																											case 74:
																											case 85:
																												goto end_IL_061b;
																											case 8:
																												goto end_IL_062b;
																											case 7:
																											case 47:
																												goto end_IL_063b;
																											case 33:
																												goto end_IL_0654;
																											case 34:
																												goto end_IL_0664;
																											case 62:
																											case 94:
																												goto IL_067f;
																											}
																											continue;
																										}
																										goto IL_04fe;
																										IL_053e:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_0254;
																										IL_0533:
																										if (3 > b)
																										{
																											num = 60;
																											goto end_IL_0224;
																										}
																										goto IL_053e;
																										IL_04fe:
																										if (3 < b)
																										{
																											goto IL_0509;
																										}
																										num = 52;
																										goto IL_0533;
																										IL_0509:
																										if (4 < b)
																										{
																											goto end_IL_0224;
																										}
																										goto IL_0517;
																										IL_0517:
																										if (4 > b)
																										{
																											goto end_IL_0224;
																										}
																										goto end_IL_0254;
																										continue;
																										end_IL_01e1:
																										break;
																									}
																									break;
																								}
																								goto IL_025f;
																								IL_04ab:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 3;
																								goto IL_04dd;
																								IL_04dd:
																								ptr2 += 8;
																								goto IL_04eb;
																								IL_025f:
																								if (2 > b)
																								{
																									goto IL_026d;
																								}
																								goto IL_04ab;
																								IL_026d:
																								if (1 < b)
																								{
																									goto end_IL_0224;
																								}
																								goto IL_027b;
																								IL_027b:
																								if (1 > b)
																								{
																									goto end_IL_0224;
																								}
																								num = 9;
																								goto IL_0292;
																								IL_04eb:
																								num5--;
																								goto end_IL_0254;
																								IL_0292:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_02ab;
																								IL_02ab:
																								array[num5] = 0;
																								goto IL_02b9;
																								IL_02b9:
																								num5++;
																								goto IL_02c7;
																								IL_02c7:
																								ptr2 += 8;
																								goto end_IL_0254;
																							}
																							break;
																						}
																						goto IL_055e;
																						IL_05a7:
																						ptr2 += 8;
																						goto end_IL_0254;
																						IL_055e:
																						array[num5] = 0;
																						goto IL_056c;
																						IL_056c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_058f;
																						IL_058f:
																						array2[num5] = null;
																						goto IL_0599;
																						IL_0599:
																						num5++;
																						goto IL_05a7;
																					}
																					goto IL_0346;
																				}
																				goto IL_02da;
																				IL_0485:
																				num5--;
																				goto end_IL_0254;
																				IL_02da:
																				if (8 < b)
																				{
																					goto IL_02e5;
																				}
																				goto IL_033b;
																				IL_02e5:
																				if (9 >= b)
																				{
																					goto IL_02f0;
																				}
																				goto IL_031a;
																				IL_02f0:
																				if (9 > b)
																				{
																					goto end_IL_0224;
																				}
																				goto IL_02fe;
																				IL_02fe:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0254;
																				IL_031a:
																				if (10 < b)
																				{
																					goto end_IL_0224;
																				}
																				goto IL_0328;
																				IL_0328:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_0224;
																				IL_033b:
																				if (8 <= b)
																				{
																					goto IL_0346;
																				}
																				goto IL_03bb;
																				IL_0346:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03a8;
																				IL_03a8:
																				num5 -= 2;
																				goto end_IL_0254;
																				IL_03bb:
																				if (6 < b)
																				{
																					goto IL_03c6;
																				}
																				goto IL_0423;
																				IL_03c6:
																				if (7 < b)
																				{
																					goto end_IL_0224;
																				}
																				goto IL_03d4;
																				IL_03d4:
																				if (7 > b)
																				{
																					goto end_IL_0224;
																				}
																				goto IL_03e2;
																				IL_03e2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0405;
																				IL_0405:
																				array[num5] = 0;
																				goto IL_0413;
																				IL_0413:
																				num5++;
																				goto IL_0498;
																				IL_0498:
																				ptr2 += 8;
																				goto end_IL_0254;
																				IL_0423:
																				if (6 > b)
																				{
																					goto end_IL_0224;
																				}
																				goto IL_0431;
																				IL_0431:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0471;
																				IL_0471:
																				array[num5 - 2] = 0;
																				goto IL_0485;
																				continue;
																				end_IL_0214:
																				break;
																			}
																			continue;
																			end_IL_0224:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0254;
																	continue;
																	end_IL_0234:
																	break;
																}
																continue;
																end_IL_0244:
																break;
															}
															continue;
															end_IL_0254:
															break;
														}
														continue;
													}
													goto IL_067f;
													IL_067f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05ca:
													break;
												}
												continue;
												end_IL_05dd:
												break;
											}
											continue;
											end_IL_05e8:
											break;
										}
										continue;
										end_IL_05f2:
										break;
									}
									continue;
									end_IL_05fd:
									break;
								}
								continue;
								end_IL_061b:
								break;
							}
							continue;
							end_IL_062b:
							break;
						}
						continue;
						end_IL_063b:
						break;
					}
					continue;
					end_IL_0654:
					break;
				}
				continue;
				end_IL_0664:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 90;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BrowserHomeUnwrap.ClaimsPortablePdb);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0220:
															byte b = *ptr2;
															num = 3;
															while (true)
															{
																IL_0210:
																ptr2++;
																while (true)
																{
																	IL_0200:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_01e0:
																				if (5 >= b)
																				{
																					num = 108;
																					while (true)
																					{
																						if (num != 108)
																						{
																							if (num != 1089)
																							{
																								break;
																							}
																							switch (num)
																							{
																							case 32:
																								goto IL_01e0;
																							case 37:
																								goto IL_01f0;
																							case 80:
																								goto IL_0200;
																							case 3:
																								goto IL_0210;
																							case 10:
																							case 84:
																								goto IL_0220;
																							case 72:
																								goto IL_0234;
																							case 28:
																							case 75:
																								goto IL_023f;
																							case 64:
																								goto IL_024a;
																							case 77:
																								goto IL_025d;
																							case 76:
																								goto IL_026b;
																							case 85:
																								goto IL_027e;
																							case 24:
																							case 61:
																								goto IL_0289;
																							case 58:
																								goto IL_02a2;
																							case 62:
																								goto IL_02b0;
																							case 66:
																								goto IL_02be;
																							case 35:
																								goto IL_02d1;
																							case 59:
																								goto IL_02df;
																							case 6:
																							case 68:
																								goto IL_02ed;
																							case 18:
																								goto IL_032d;
																							case 54:
																								goto IL_0341;
																							case 87:
																							case 96:
																								goto IL_0354;
																							case 49:
																							case 100:
																								goto IL_0370;
																							case 7:
																								goto IL_03b0;
																							case 55:
																								goto IL_03c4;
																							case 56:
																							case 83:
																								goto IL_03e2;
																							case 0:
																								goto IL_03f0;
																							case 31:
																								goto IL_0413;
																							case 39:
																								goto IL_041d;
																							case 12:
																								goto IL_042b;
																							case 81:
																								goto IL_043e;
																							case 4:
																							case 20:
																								goto IL_044c;
																							case 14:
																							case 40:
																								goto IL_045a;
																							case 101:
																								goto IL_0468;
																							case 43:
																							case 79:
																								goto IL_0476;
																							case 8:
																								goto IL_04b6;
																							case 98:
																								goto IL_04ca;
																							case 48:
																								goto IL_04dd;
																							case 15:
																							case 91:
																								goto IL_04eb;
																							case 50:
																								goto IL_0514;
																							case 95:
																								goto IL_0522;
																							case 57:
																								goto IL_0535;
																							case 17:
																							case 21:
																								goto IL_0540;
																							case 88:
																								goto IL_0580;
																							case 26:
																								goto IL_0594;
																							case 73:
																								goto IL_05a4;
																							case 27:
																								goto IL_05af;
																							case 1:
																							case 9:
																							case 13:
																							case 16:
																							case 23:
																							case 29:
																							case 33:
																							case 34:
																							case 41:
																							case 44:
																							case 47:
																							case 63:
																							case 74:
																							case 82:
																							case 93:
																							case 94:
																								goto end_IL_01f0;
																							case 36:
																								goto IL_05e6;
																							case 22:
																								goto IL_05f4;
																							case 70:
																								goto IL_0602;
																							case 2:
																							case 5:
																							case 11:
																							case 38:
																							case 60:
																							case 67:
																							case 71:
																							case 86:
																							case 92:
																							case 97:
																							case 99:
																								goto end_IL_01cd;
																							case 78:
																								goto end_IL_0610;
																							case 65:
																								goto end_IL_0623;
																							case 69:
																								goto end_IL_062d;
																							case 25:
																								goto end_IL_0638;
																							case 19:
																								goto end_IL_064d;
																							case 30:
																							case 45:
																								goto end_IL_0662;
																							case 46:
																								goto end_IL_0672;
																							case 52:
																							case 53:
																								goto end_IL_0682;
																							case 89:
																								goto end_IL_0692;
																							case 90:
																								goto end_IL_06a2;
																							case 42:
																							case 51:
																								goto IL_06bd;
																							}
																							continue;
																						}
																						if (5 <= b)
																						{
																							goto IL_03e2;
																						}
																						goto IL_043e;
																						IL_0594:
																						num5--;
																						break;
																						IL_05af:
																						if (1 <= b)
																						{
																						}
																						goto end_IL_01f0;
																						IL_05a4:
																						if (1 < b)
																						{
																							goto end_IL_01f0;
																						}
																						goto IL_05af;
																						IL_03e2:
																						array[num5] = 0;
																						goto IL_03f0;
																						IL_03f0:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0413;
																						IL_0413:
																						array2[num5] = null;
																						goto IL_041d;
																						IL_041d:
																						num5++;
																						goto IL_042b;
																						IL_042b:
																						ptr2 += 8;
																						break;
																						IL_043e:
																						if (2 < b)
																						{
																							goto IL_044c;
																						}
																						goto IL_0535;
																						IL_044c:
																						if (3 < b)
																						{
																							goto IL_045a;
																						}
																						goto IL_04dd;
																						IL_045a:
																						if (4 < b)
																						{
																							goto end_IL_01f0;
																						}
																						goto IL_0468;
																						IL_0468:
																						if (4 > b)
																						{
																							goto end_IL_01f0;
																						}
																						goto IL_0476;
																						IL_0476:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04b6;
																						IL_04b6:
																						array[num5 - 2] = 0;
																						goto IL_04ca;
																						IL_04ca:
																						num5--;
																						break;
																						IL_04dd:
																						if (3 > b)
																						{
																							goto end_IL_01f0;
																						}
																						goto IL_04eb;
																						IL_04eb:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0514;
																						IL_0514:
																						ptr2 += 8;
																						goto IL_0522;
																						IL_0522:
																						num5--;
																						break;
																						IL_0535:
																						if (2 <= b)
																						{
																							goto IL_0540;
																						}
																						goto IL_05a4;
																						IL_0540:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0580;
																						IL_0580:
																						array[num5 - 2] = 0;
																						goto IL_0594;
																						continue;
																						end_IL_01cd:
																						break;
																					}
																					break;
																				}
																				goto IL_0234;
																				IL_032d:
																				array[num5 - 2] = 0;
																				goto IL_0341;
																				IL_0341:
																				num5--;
																				break;
																				IL_0234:
																				if (7 < b)
																				{
																					goto IL_023f;
																				}
																				goto IL_027e;
																				IL_023f:
																				if (8 >= b)
																				{
																					goto IL_024a;
																				}
																				goto IL_025d;
																				IL_024a:
																				if (8 > b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_0370;
																				IL_0370:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03b0;
																				IL_03b0:
																				array[num5 - 2] = 0;
																				goto IL_03c4;
																				IL_03c4:
																				num5--;
																				break;
																				IL_025d:
																				if (9 < b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_026b;
																				IL_026b:
																				if (9 > b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_0354;
																				IL_0354:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_027e:
																				if (7 <= b)
																				{
																					goto IL_0289;
																				}
																				goto IL_02d1;
																				IL_0289:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_02a2;
																				IL_02a2:
																				array[num5] = 0;
																				goto IL_02b0;
																				IL_02b0:
																				num5++;
																				goto IL_02be;
																				IL_02be:
																				ptr2 += 8;
																				break;
																				IL_02d1:
																				if (6 < b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_02df;
																				IL_02df:
																				if (6 > b)
																				{
																					goto end_IL_01f0;
																				}
																				goto IL_02ed;
																				IL_02ed:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_032d;
																			}
																			goto end_IL_0200;
																			continue;
																			end_IL_01f0:
																			break;
																			IL_01f0:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 36;
																	goto IL_05e6;
																	IL_0602:
																	ptr2 += 8;
																	break;
																	IL_05f4:
																	num5++;
																	goto IL_0602;
																	IL_05e6:
																	array[num5] = 0;
																	goto IL_05f4;
																	continue;
																	end_IL_0200:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06bd;
													IL_06bd:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0610:
													break;
												}
												continue;
												end_IL_0623:
												break;
											}
											continue;
											end_IL_062d:
											break;
										}
										continue;
										end_IL_0638:
										break;
									}
									continue;
									end_IL_064d:
									break;
								}
								continue;
								end_IL_0662:
								break;
							}
							continue;
							end_IL_0672:
							break;
						}
						continue;
						end_IL_0682:
						break;
					}
					continue;
					end_IL_0692:
					break;
				}
				continue;
				end_IL_06a2:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 53;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 32;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnknownValueServerCallback.getUrlValueGetRuntimeFields);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															IL_02c5:
															ptr2++;
															while (true)
															{
																IL_02b5:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0298:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0288:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0278:
																							if (9 > b)
																							{
																								while (true)
																								{
																									IL_0268:
																									if (7 < b)
																									{
																										while (true)
																										{
																											IL_0258:
																											if (8 >= b)
																											{
																												while (8 <= b)
																												{
																													while (true)
																													{
																														IL_0223:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_020a:
																															array[num5] = 0;
																															num = 122;
																															while (true)
																															{
																																if (num != 122)
																																{
																																	if (num != 1103)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 81:
																																		goto IL_020a;
																																	case 46:
																																	case 89:
																																		goto IL_0223;
																																	case 65:
																																		goto IL_0248;
																																	case 62:
																																	case 111:
																																		goto IL_0258;
																																	case 25:
																																	case 64:
																																		goto IL_0268;
																																	case 77:
																																		goto IL_0278;
																																	case 5:
																																		goto IL_0288;
																																	case 2:
																																		goto IL_0298;
																																	case 27:
																																		goto IL_02a5;
																																	case 76:
																																		goto IL_02b5;
																																	case 0:
																																		goto IL_02c5;
																																	case 18:
																																	case 106:
																																		goto end_IL_01f7;
																																	case 38:
																																		goto IL_02e0;
																																	case 78:
																																	case 82:
																																		goto IL_02eb;
																																	case 24:
																																		goto IL_032b;
																																	case 49:
																																		goto IL_033f;
																																	case 105:
																																		goto IL_0352;
																																	case 11:
																																	case 29:
																																		goto IL_0360;
																																	case 21:
																																	case 103:
																																		goto IL_0374;
																																	case 17:
																																		goto IL_0382;
																																	case 55:
																																	case 63:
																																		goto IL_0390;
																																	case 61:
																																		goto IL_039e;
																																	case 68:
																																		goto IL_03c1;
																																	case 99:
																																		goto IL_03cb;
																																	case 100:
																																		goto IL_03de;
																																	case 70:
																																		goto IL_03f1;
																																	case 26:
																																	case 97:
																																		goto IL_03ff;
																																	case 13:
																																	case 35:
																																		goto IL_040a;
																																	case 85:
																																		goto IL_0418;
																																	case 33:
																																	case 90:
																																		goto IL_0426;
																																	case 6:
																																		goto IL_044f;
																																	case 69:
																																		goto IL_045d;
																																	case 72:
																																		goto IL_0470;
																																	case 47:
																																	case 56:
																																		goto IL_047e;
																																	case 39:
																																		goto IL_0497;
																																	case 4:
																																		goto IL_04ae;
																																	case 107:
																																		goto IL_04bc;
																																	case 3:
																																	case 108:
																																		goto IL_04cf;
																																	case 22:
																																	case 98:
																																		goto IL_04da;
																																	case 102:
																																		goto IL_04e8;
																																	case 96:
																																		goto IL_0504;
																																	case 92:
																																	case 93:
																																		goto IL_0512;
																																	case 41:
																																	case 109:
																																		goto IL_052e;
																																	case 113:
																																		goto IL_0546;
																																	case 44:
																																		goto IL_0567;
																																	case 95:
																																		goto IL_0588;
																																	case 83:
																																	case 88:
																																		goto IL_059f;
																																	case 58:
																																		goto IL_05df;
																																	case 114:
																																		goto IL_05f3;
																																	case 7:
																																	case 15:
																																		goto IL_0606;
																																	case 51:
																																		goto IL_0668;
																																	case 8:
																																	case 9:
																																	case 12:
																																	case 16:
																																	case 20:
																																	case 23:
																																	case 28:
																																	case 30:
																																	case 31:
																																	case 42:
																																	case 45:
																																	case 48:
																																	case 71:
																																	case 74:
																																	case 86:
																																	case 91:
																																	case 101:
																																	case 104:
																																	case 110:
																																	case 115:
																																		goto end_IL_0248;
																																	case 14:
																																	case 34:
																																	case 37:
																																	case 40:
																																	case 43:
																																	case 50:
																																	case 60:
																																	case 73:
																																	case 79:
																																	case 80:
																																	case 84:
																																	case 87:
																																	case 94:
																																	case 112:
																																		goto end_IL_02d5;
																																	case 36:
																																		goto end_IL_068b;
																																	case 1:
																																		goto end_IL_069e;
																																	case 54:
																																		goto end_IL_06a8;
																																	case 67:
																																		goto end_IL_06b3;
																																	case 57:
																																	case 66:
																																		goto end_IL_06c8;
																																	case 32:
																																		goto end_IL_06d8;
																																	case 19:
																																	case 59:
																																		goto end_IL_06e8;
																																	case 52:
																																		goto end_IL_06f8;
																																	case 53:
																																		goto end_IL_0711;
																																	case 10:
																																	case 75:
																																		goto IL_0735;
																																	}
																																	continue;
																																}
																																num5++;
																																goto IL_0567;
																																IL_0567:
																																ptr2 += 8;
																																goto end_IL_02d5;
																																continue;
																																end_IL_01f7:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_02b5;
																													continue;
																													end_IL_0248:
																													break;
																													IL_0248:;
																												}
																											}
																											else
																											{
																												num = 20;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0588;
																									IL_05df:
																									array[num5 - 2] = 0;
																									goto IL_05f3;
																									IL_0588:
																									if (7 > b)
																									{
																										break;
																									}
																									num = 88;
																									goto IL_059f;
																									IL_05f3:
																									num5--;
																									goto end_IL_02d5;
																									IL_059f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05df;
																								}
																								break;
																							}
																							goto IL_0606;
																							IL_0668:
																							num5 -= 2;
																							goto end_IL_02d5;
																							IL_0606:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0668;
																						}
																						break;
																					}
																					goto IL_04cf;
																					IL_0504:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0512;
																					IL_04cf:
																					if (10 < b)
																					{
																						goto IL_04da;
																					}
																					goto IL_0504;
																					IL_04da:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_04e8;
																					IL_04e8:
																					if (11 > b)
																					{
																						num = 16;
																					}
																					break;
																					IL_0512:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02d5;
																				}
																				break;
																			}
																			goto IL_02e0;
																			IL_04bc:
																			ptr2 += 8;
																			goto end_IL_02d5;
																			IL_02e0:
																			if (6 <= b)
																			{
																				goto IL_02eb;
																			}
																			goto IL_0352;
																			IL_02eb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_032b;
																			IL_032b:
																			array[num5 - 2] = 0;
																			goto IL_033f;
																			IL_033f:
																			num5--;
																			goto end_IL_02d5;
																			IL_0352:
																			if (3 < b)
																			{
																				goto IL_0360;
																			}
																			goto IL_03f1;
																			IL_0360:
																			if (4 < b)
																			{
																				num = 21;
																				goto IL_0374;
																			}
																			goto IL_03de;
																			IL_052e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02d5;
																			IL_0374:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0382;
																			IL_0382:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0390;
																			IL_0390:
																			array[num5] = 0;
																			goto IL_039e;
																			IL_039e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03c1;
																			IL_03c1:
																			array2[num5] = null;
																			goto IL_03cb;
																			IL_03cb:
																			num5++;
																			goto IL_0546;
																			IL_0546:
																			ptr2 += 8;
																			goto end_IL_02d5;
																			IL_03de:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02d5;
																			IL_03f1:
																			if (3 > b)
																			{
																				goto IL_03ff;
																			}
																			goto IL_052e;
																			IL_03ff:
																			if (1 < b)
																			{
																				goto IL_040a;
																			}
																			goto IL_0470;
																			IL_040a:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0418;
																			IL_0418:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0426;
																			IL_0426:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_044f;
																			IL_044f:
																			ptr2 += 8;
																			goto IL_045d;
																			IL_045d:
																			num5--;
																			goto end_IL_02d5;
																			IL_0470:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_047e;
																			IL_047e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0497;
																			IL_0497:
																			array[num5] = 0;
																			num = 4;
																			goto IL_04ae;
																			IL_04ae:
																			num5++;
																			goto IL_04bc;
																		}
																		break;
																		IL_02a5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02d5;
																continue;
																end_IL_02b5:
																break;
															}
															break;
														}
														continue;
														end_IL_02d5:
														break;
													}
													continue;
												}
												num = 75;
												goto IL_0735;
												IL_0735:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068b:
												break;
											}
											continue;
											end_IL_069e:
											break;
										}
										continue;
										end_IL_06a8:
										break;
									}
									continue;
									end_IL_06b3:
									break;
								}
								continue;
								end_IL_06c8:
								break;
							}
							continue;
							end_IL_06d8:
							break;
						}
						continue;
						end_IL_06e8:
						break;
					}
					continue;
					end_IL_06f8:
					break;
				}
				continue;
				end_IL_0711:
				break;
			}
		}
	}

	private static int smethod_6(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		num += num2;
		int num3 = num;
		num = int_0;
		num2 = int_1;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 196;
		num2 = 49;
		num += 49;
		num2 = 442;
		num2 = 34;
		int num6 = smethod_3(34);
		num2 = num6;
		return num;
	}

	private unsafe static int smethod_7(int int_0)
	{
		int num = 103;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MethodRentalIMPNOFLOW.IsInterfaceSymLanguageVendor);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															IL_02d5:
															ptr2++;
															while (true)
															{
																IL_02c5:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02a5:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0295:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0285:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0278:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												while (true)
																												{
																													IL_0248:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_0223:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_0217:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_01fe:
																																num5++;
																																num = 119;
																																while (true)
																																{
																																	if (num != 119)
																																	{
																																		if (num != 1100)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 63:
																																			goto IL_01fe;
																																		case 52:
																																			goto IL_0217;
																																		case 90:
																																			goto IL_0223;
																																		case 1:
																																		case 23:
																																			goto IL_0248;
																																		case 92:
																																			goto IL_0258;
																																		case 60:
																																			goto IL_0268;
																																		case 32:
																																		case 97:
																																			goto IL_0278;
																																		case 14:
																																		case 73:
																																			goto IL_0285;
																																		case 79:
																																			goto IL_0295;
																																		case 53:
																																			goto IL_02a5;
																																		case 64:
																																			goto IL_02b5;
																																		case 43:
																																			goto IL_02c5;
																																		case 33:
																																			goto IL_02d5;
																																		case 34:
																																		case 74:
																																			goto end_IL_01eb;
																																		case 82:
																																			goto IL_02f0;
																																		case 72:
																																			goto IL_031f;
																																		case 54:
																																			goto IL_032d;
																																		case 36:
																																			goto IL_0338;
																																		case 31:
																																		case 106:
																																			goto IL_0346;
																																		case 27:
																																			goto IL_035f;
																																		case 95:
																																			goto IL_036d;
																																		case 29:
																																			goto IL_037b;
																																		case 8:
																																			goto IL_038e;
																																		case 62:
																																			goto IL_03a5;
																																		case 48:
																																		case 99:
																																			goto IL_03b3;
																																		case 67:
																																			goto IL_03dc;
																																		case 69:
																																			goto IL_03ea;
																																		case 24:
																																		case 81:
																																			goto IL_03fd;
																																		case 68:
																																		case 86:
																																			goto IL_0415;
																																		case 19:
																																			goto IL_045e;
																																		case 107:
																																			goto IL_0472;
																																		case 9:
																																		case 84:
																																			goto IL_0485;
																																		case 66:
																																			goto IL_0493;
																																		case 77:
																																		case 87:
																																			goto IL_049e;
																																		case 59:
																																			goto IL_0500;
																																		case 46:
																																		case 76:
																																			goto IL_051c;
																																		case 104:
																																			goto IL_0527;
																																		case 21:
																																		case 37:
																																			goto IL_0535;
																																		case 111:
																																			goto IL_0575;
																																		case 58:
																																			goto IL_0589;
																																		case 12:
																																			goto IL_059c;
																																		case 96:
																																			goto IL_05aa;
																																		case 39:
																																		case 112:
																																			goto IL_05b8;
																																		case 15:
																																			goto IL_05db;
																																		case 105:
																																			goto IL_05f2;
																																		case 78:
																																			goto IL_0609;
																																		case 108:
																																			goto IL_0619;
																																		case 2:
																																			goto IL_0624;
																																		case 80:
																																			goto IL_062f;
																																		case 26:
																																			goto IL_0645;
																																		case 11:
																																		case 65:
																																			goto IL_065b;
																																		case 0:
																																		case 3:
																																		case 5:
																																		case 10:
																																		case 13:
																																		case 16:
																																		case 18:
																																		case 22:
																																		case 25:
																																		case 28:
																																		case 30:
																																		case 41:
																																		case 47:
																																		case 49:
																																		case 50:
																																		case 55:
																																		case 57:
																																		case 61:
																																		case 75:
																																		case 88:
																																		case 91:
																																			goto end_IL_0258;
																																		case 6:
																																		case 38:
																																		case 40:
																																		case 44:
																																		case 45:
																																		case 56:
																																		case 71:
																																		case 83:
																																		case 89:
																																		case 93:
																																		case 94:
																																		case 100:
																																		case 109:
																																		case 110:
																																			goto end_IL_02e5;
																																		case 101:
																																			goto end_IL_0690;
																																		case 17:
																																			goto end_IL_06a3;
																																		case 70:
																																			goto end_IL_06ad;
																																		case 35:
																																			goto end_IL_06b8;
																																		case 42:
																																		case 51:
																																			goto end_IL_06cd;
																																		case 20:
																																			goto end_IL_06dd;
																																		case 85:
																																		case 98:
																																			goto end_IL_06ed;
																																		case 102:
																																			goto end_IL_06fd;
																																		case 103:
																																			goto end_IL_070d;
																																		case 4:
																																		case 7:
																																			goto IL_0728;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	num = 109;
																																	goto end_IL_02e5;
																																	continue;
																																	end_IL_01eb:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02c5;
																												continue;
																												end_IL_0258:
																												break;
																												IL_0258:;
																											}
																											break;
																											IL_0268:;
																										}
																										break;
																									}
																									goto IL_02f0;
																									IL_02f0:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02e5;
																								}
																								break;
																							}
																							goto IL_031f;
																							IL_03ea:
																							num5--;
																							goto end_IL_02e5;
																							IL_031f:
																							if (3 > b)
																							{
																								goto IL_032d;
																							}
																							goto IL_03fd;
																							IL_032d:
																							if (1 >= b)
																							{
																								goto IL_0338;
																							}
																							goto IL_038e;
																							IL_0338:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0346;
																							IL_0346:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_035f;
																							IL_035f:
																							array[num5] = 0;
																							goto IL_036d;
																							IL_036d:
																							num5++;
																							goto IL_037b;
																							IL_037b:
																							ptr2 += 8;
																							goto end_IL_02e5;
																							IL_038e:
																							if (2 < b)
																							{
																								break;
																							}
																							num = 62;
																							goto IL_03a5;
																							IL_03fd:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02e5;
																							IL_03a5:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_03b3;
																							IL_03b3:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_03dc;
																							IL_03dc:
																							ptr2 += 8;
																							goto IL_03ea;
																						}
																						break;
																					}
																					goto IL_0415;
																					IL_0472:
																					num5--;
																					goto end_IL_02e5;
																					IL_0415:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 19;
																					goto IL_045e;
																					IL_045e:
																					array[num5 - 2] = 0;
																					goto IL_0472;
																				}
																				break;
																			}
																			goto IL_0485;
																			IL_065b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 100;
																			goto end_IL_02e5;
																			IL_0485:
																			if (9 >= b)
																			{
																				goto IL_0493;
																			}
																			goto IL_0619;
																			IL_0493:
																			if (9 <= b)
																			{
																				goto IL_049e;
																			}
																			num = 76;
																			goto IL_051c;
																			IL_049e:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0500;
																			IL_0500:
																			num5 -= 2;
																			goto end_IL_02e5;
																			IL_0645:
																			if (10 > b)
																			{
																				num = 28;
																				break;
																			}
																			goto IL_065b;
																			IL_051c:
																			if (7 >= b)
																			{
																				goto IL_0527;
																			}
																			goto IL_059c;
																			IL_0527:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0535;
																			IL_0535:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0575;
																			IL_0575:
																			array[num5 - 2] = 0;
																			goto IL_0589;
																			IL_0589:
																			num5--;
																			goto end_IL_02e5;
																			IL_059c:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_05aa;
																			IL_05aa:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_05b8;
																			IL_05b8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05db;
																			IL_05db:
																			array[num5] = 0;
																			num = 105;
																			goto IL_05f2;
																			IL_05f2:
																			num5++;
																			num = 78;
																			goto IL_0609;
																			IL_0609:
																			ptr2 += 8;
																			goto end_IL_02e5;
																			IL_0619:
																			if (10 < b)
																			{
																				goto IL_0624;
																			}
																			goto IL_0645;
																			IL_0624:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_062f;
																			IL_062f:
																			if (11 <= b)
																			{
																				num = 5;
																			}
																			break;
																		}
																		break;
																		IL_02b5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02e5;
																continue;
																end_IL_02c5:
																break;
															}
															break;
														}
														continue;
														end_IL_02e5:
														break;
													}
													continue;
												}
												goto IL_0728;
												IL_0728:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0690:
												break;
											}
											continue;
											end_IL_06a3:
											break;
										}
										continue;
										end_IL_06ad:
										break;
									}
									continue;
									end_IL_06b8:
									break;
								}
								continue;
								end_IL_06cd:
								break;
							}
							continue;
							end_IL_06dd:
							break;
						}
						continue;
						end_IL_06ed:
						break;
					}
					continue;
					end_IL_06fd:
					break;
				}
				continue;
				end_IL_070d:
				break;
			}
		}
	}

	static Class177()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 13;
					while (true)
					{
						if (num == 13 || num != 994)
						{
							return;
						}
						switch (num)
						{
						case 5:
							goto end_IL_003d;
						case 2:
							goto end_IL_004a;
						case 3:
							goto end_IL_0056;
						case 0:
							return;
						case 1:
							return;
						case 4:
							return;
						case 6:
							return;
						}
						continue;
						end_IL_003d:
						break;
					}
					continue;
					end_IL_004a:
					break;
				}
				continue;
				end_IL_0056:
				break;
			}
		}
	}

	private static void ReadDataEntryPointCommandLineFile(Behaviour behaviour_0, bool bool_0)
	{
		behaviour_0.enabled = bool_0;
	}
}
