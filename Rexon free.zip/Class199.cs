using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Rotate Head To Nearest", "Rig", "Head tracks nearest player.", false, 35, ModType.const_0, false)]
internal class Class199 : MonoBehaviour
{
	private static bool bool_0;

	private static double double_0;

	private static double double_1;

	private static double double_2;

	private static double double_3;

	private static double double_4;

	private static IntPtr[] byteBufferSetLengthToFirstNull;

	private static IntPtr[] getXmlFieldOrderEntryPointEntryFieldId;

	private static IntPtr[] KerbSmartCardUnlockLogonNonPublic;

	private static IntPtr[] getKeyCharHostEvidence;

	private static IntPtr[] RegistryKeyPermissionCheckVerifyHash;

	private static IntPtr[] AsyncTaskMethodBuilderIsEnumDefined;

	private unsafe void Update()
	{
		int num = 255;
		int num5 = default(int);
		int num6 = default(int);
		object[] array6 = default(object[]);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										num = 616;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PasswordDeriveBytesOleAutBinder.passwordDeriveBytesOleAutBinder_0);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 == 1)
													{
														return;
													}
													while (true)
													{
														IL_0d1e:
														byte b = *ptr2;
														while (true)
														{
															IL_0d0e:
															ptr2++;
															while (true)
															{
																IL_0cfe:
																if (b >= 1)
																{
																	while (b <= 92)
																	{
																		while (true)
																		{
																			IL_0cde:
																			if (46 >= b)
																			{
																				while (true)
																				{
																					IL_0cce:
																					if (46 > b)
																					{
																						while (true)
																						{
																							IL_0cbe:
																							if (23 >= b)
																							{
																								while (true)
																								{
																									IL_0cae:
																									if (23 > b)
																									{
																										while (true)
																										{
																											IL_0c9e:
																											if (11 >= b)
																											{
																												while (11 > b)
																												{
																													while (true)
																													{
																														IL_0c7e:
																														if (5 >= b)
																														{
																															while (true)
																															{
																																IL_0c6e:
																																if (5 > b)
																																{
																																	while (true)
																																	{
																																		IL_0c5e:
																																		if (2 >= b)
																																		{
																																			while (true)
																																			{
																																				IL_0c4e:
																																				if (2 > b)
																																				{
																																					while (1 >= b)
																																					{
																																						while (1 <= b)
																																						{
																																							while (true)
																																							{
																																								IL_0c13:
																																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																																								while (true)
																																								{
																																									IL_0bfa:
																																									array[num6] = 0;
																																									num = 758;
																																									while (true)
																																									{
																																										if (num != 758)
																																										{
																																											if (num != 1739)
																																											{
																																												break;
																																											}
																																											switch (num)
																																											{
																																											case 694:
																																												goto IL_0bfa;
																																											case 361:
																																											case 577:
																																												goto IL_0c13;
																																											case 344:
																																												goto IL_0c2e;
																																											case 360:
																																												goto IL_0c3e;
																																											case 646:
																																												goto IL_0c4e;
																																											case 153:
																																												goto IL_0c5e;
																																											case 696:
																																												goto IL_0c6e;
																																											case 117:
																																												goto IL_0c7e;
																																											case 554:
																																												goto IL_0c8e;
																																											case 76:
																																												goto IL_0c9e;
																																											case 269:
																																												goto IL_0cae;
																																											case 740:
																																												goto IL_0cbe;
																																											case 674:
																																												goto IL_0cce;
																																											case 399:
																																												goto IL_0cde;
																																											case 199:
																																												goto IL_0cee;
																																											case 578:
																																												goto IL_0cfe;
																																											case 324:
																																												goto IL_0d0e;
																																											case 228:
																																											case 732:
																																												goto IL_0d1e;
																																											case 229:
																																												goto IL_0d29;
																																											case 34:
																																												goto IL_0d37;
																																											case 175:
																																												goto IL_0d45;
																																											case 196:
																																												goto IL_0d50;
																																											case 129:
																																											case 183:
																																												goto IL_0d5e;
																																											case 54:
																																												goto IL_0da0;
																																											case 212:
																																												goto IL_0dae;
																																											case 301:
																																												goto IL_0dc1;
																																											case 13:
																																												goto IL_0dd5;
																																											case 204:
																																											case 338:
																																												goto IL_0de8;
																																											case 329:
																																												goto IL_0e28;
																																											case 218:
																																												goto IL_0e3c;
																																											case 65:
																																											case 424:
																																												goto IL_0e4f;
																																											case 499:
																																												goto IL_0e8f;
																																											case 359:
																																												goto IL_0ea3;
																																											case 536:
																																												goto IL_0eb6;
																																											case 390:
																																											case 568:
																																												goto IL_0ec6;
																																											case 103:
																																												goto IL_0eda;
																																											case 334:
																																												goto IL_0f19;
																																											case 573:
																																												goto IL_0f2c;
																																											case 45:
																																											case 613:
																																												goto IL_0f3c;
																																											case 476:
																																												goto IL_0f5a;
																																											case 11:
																																												goto IL_0f68;
																																											case 63:
																																												goto IL_0f76;
																																											case 641:
																																												goto IL_0f89;
																																											case 458:
																																												goto IL_0f97;
																																											case 599:
																																											case 658:
																																												goto IL_0fa7;
																																											case 289:
																																											case 676:
																																												goto IL_0fba;
																																											case 602:
																																												goto IL_0ffa;
																																											case 621:
																																												goto IL_100e;
																																											case 140:
																																											case 723:
																																												goto IL_1021;
																																											case 200:
																																												goto IL_108c;
																																											case 378:
																																												goto IL_10ad;
																																											case 162:
																																											case 724:
																																												goto IL_10c0;
																																											case 2:
																																												goto IL_1109;
																																											case 393:
																																												goto IL_111d;
																																											case 137:
																																												goto IL_1130;
																																											case 125:
																																												goto IL_113b;
																																											case 511:
																																											case 546:
																																												goto IL_1149;
																																											case 309:
																																												goto IL_1172;
																																											case 440:
																																												goto IL_1180;
																																											case 495:
																																												goto IL_1193;
																																											case 688:
																																												goto IL_11a1;
																																											case 61:
																																											case 145:
																																												goto IL_11b8;
																																											case 84:
																																												goto IL_11c6;
																																											case 632:
																																												goto IL_11f2;
																																											case 243:
																																												goto IL_11fc;
																																											case 439:
																																												goto IL_120a;
																																											case 77:
																																												goto IL_121d;
																																											case 158:
																																												goto IL_122b;
																																											case 32:
																																											case 351:
																																												goto IL_1236;
																																											case 542:
																																												goto IL_124f;
																																											case 426:
																																												goto IL_1262;
																																											case 347:
																																												goto IL_1270;
																																											case 1:
																																											case 241:
																																												goto IL_127b;
																																											case 244:
																																												goto IL_12bc;
																																											case 188:
																																												goto IL_12d0;
																																											case 564:
																																												goto IL_12e3;
																																											case 75:
																																												goto IL_12ee;
																																											case 59:
																																											case 507:
																																												goto IL_12fc;
																																											case 612:
																																												goto IL_1315;
																																											case 445:
																																												goto IL_1323;
																																											case 58:
																																												goto IL_1331;
																																											case 702:
																																												goto IL_1344;
																																											case 681:
																																												goto IL_1352;
																																											case 201:
																																											case 423:
																																												goto IL_1360;
																																											case 538:
																																												goto IL_1381;
																																											case 386:
																																												goto IL_138c;
																																											case 416:
																																												goto IL_139a;
																																											case 644:
																																											case 669:
																																												goto IL_13a8;
																																											case 461:
																																												goto IL_13c6;
																																											case 498:
																																												goto IL_13d4;
																																											case 274:
																																												goto IL_13e2;
																																											case 56:
																																												goto IL_13fe;
																																											case 260:
																																											case 443:
																																												goto IL_140c;
																																											case 455:
																																												goto IL_1467;
																																											case 601:
																																												goto IL_147a;
																																											case 256:
																																												goto IL_1488;
																																											case 64:
																																												goto IL_1496;
																																											case 302:
																																												goto IL_14a1;
																																											case 19:
																																											case 501:
																																												goto IL_14af;
																																											case 505:
																																												goto IL_14c8;
																																											case 377:
																																												goto IL_14d6;
																																											case 116:
																																												goto IL_14e4;
																																											case 560:
																																												goto IL_14f7;
																																											case 230:
																																												goto IL_1505;
																																											case 315:
																																											case 353:
																																												goto IL_1513;
																																											case 24:
																																												goto IL_1527;
																																											case 727:
																																												goto IL_156f;
																																											case 502:
																																											case 712:
																																												goto IL_1582;
																																											case 102:
																																												goto IL_15c2;
																																											case 504:
																																												goto IL_15d6;
																																											case 472:
																																												goto IL_15e9;
																																											case 67:
																																												goto IL_15f7;
																																											case 653:
																																											case 749:
																																												goto IL_1605;
																																											case 119:
																																												goto IL_1622;
																																											case 722:
																																												goto IL_166a;
																																											case 620:
																																												goto IL_167d;
																																											case 278:
																																												goto IL_168b;
																																											case 739:
																																											case 743:
																																												goto IL_1699;
																																											case 411:
																																												goto IL_16bd;
																																											case 53:
																																												goto IL_16cb;
																																											case 285:
																																												goto IL_16d9;
																																											case 322:
																																												goto IL_16ec;
																																											case 394:
																																												goto IL_16fa;
																																											case 0:
																																												goto IL_1708;
																																											case 21:
																																												goto IL_1716;
																																											case 691:
																																												goto IL_1724;
																																											case 524:
																																												goto IL_1732;
																																											case 267:
																																												goto IL_173d;
																																											case 281:
																																											case 537:
																																												goto IL_174b;
																																											case 413:
																																												goto IL_1768;
																																											case 182:
																																												goto IL_17a5;
																																											case 277:
																																												goto IL_17b8;
																																											case 155:
																																												goto IL_17c6;
																																											case 404:
																																											case 552:
																																												goto IL_17d4;
																																											case 221:
																																												goto IL_17f2;
																																											case 308:
																																												goto IL_1800;
																																											case 232:
																																												goto IL_180e;
																																											case 192:
																																											case 606:
																																												goto IL_1821;
																																											case 402:
																																												goto IL_1835;
																																											case 631:
																																												goto IL_1876;
																																											case 213:
																																												goto IL_1889;
																																											case 589:
																																												goto IL_1894;
																																											case 36:
																																											case 474:
																																												goto IL_18a2;
																																											case 86:
																																												goto IL_18b6;
																																											case 726:
																																												goto IL_18f3;
																																											case 126:
																																												goto IL_1906;
																																											case 595:
																																												goto IL_1914;
																																											case 216:
																																											case 735:
																																												goto IL_1922;
																																											case 608:
																																												goto IL_1936;
																																											case 368:
																																												goto IL_1987;
																																											case 100:
																																												goto IL_1995;
																																											case 714:
																																												goto IL_19a8;
																																											case 682:
																																												goto IL_19b6;
																																											case 432:
																																												goto IL_19c4;
																																											case 371:
																																											case 586:
																																												goto IL_19cf;
																																											case 383:
																																												goto IL_19fa;
																																											case 197:
																																												goto IL_1a13;
																																											case 698:
																																												goto IL_1a21;
																																											case 66:
																																											case 520:
																																												goto IL_1a2f;
																																											case 730:
																																												goto IL_1a59;
																																											case 675:
																																												goto IL_1a72;
																																											case 80:
																																												goto IL_1a7d;
																																											case 462:
																																											case 565:
																																												goto IL_1a8b;
																																											case 671:
																																												goto IL_1a9f;
																																											case 55:
																																												goto IL_1ae7;
																																											case 28:
																																												goto IL_1afa;
																																											case 514:
																																												goto IL_1b08;
																																											case 385:
																																											case 528:
																																												goto IL_1b16;
																																											case 666:
																																												goto IL_1b34;
																																											case 638:
																																												goto IL_1b42;
																																											case 44:
																																												goto IL_1b50;
																																											case 328:
																																											case 747:
																																												goto IL_1b63;
																																											case 622:
																																												goto IL_1b77;
																																											case 746:
																																												goto IL_1baf;
																																											case 35:
																																											case 529:
																																												goto IL_1bc2;
																																											case 614:
																																												goto IL_1be4;
																																											case 4:
																																												goto IL_1bf7;
																																											case 146:
																																												goto IL_1c05;
																																											case 553:
																																												goto IL_1c13;
																																											case 268:
																																											case 649:
																																												goto IL_1c1e;
																																											case 561:
																																												goto IL_1c3c;
																																											case 248:
																																												goto IL_1c4a;
																																											case 327:
																																												goto IL_1c58;
																																											case 90:
																																												goto IL_1c6b;
																																											case 163:
																																												goto IL_1c76;
																																											case 209:
																																											case 349:
																																												goto IL_1c84;
																																											case 14:
																																												goto IL_1ca0;
																																											case 550:
																																												goto IL_1cae;
																																											case 27:
																																											case 679:
																																												goto IL_1cc5;
																																											case 738:
																																												goto IL_1cd3;
																																											case 38:
																																												goto IL_1cf1;
																																											case 725:
																																												goto IL_1cff;
																																											case 239:
																																												goto IL_1d12;
																																											case 625:
																																												goto IL_1d20;
																																											case 169:
																																											case 392:
																																												goto IL_1d2e;
																																											case 447:
																																												goto IL_1d42;
																																											case 549:
																																												goto IL_1d8e;
																																											case 104:
																																												goto IL_1d9c;
																																											case 154:
																																												goto IL_1daf;
																																											case 114:
																																												goto IL_1dbd;
																																											case 480:
																																											case 637:
																																												goto IL_1dcb;
																																											case 551:
																																												goto IL_1de4;
																																											case 270:
																																												goto IL_1e00;
																																											case 105:
																																												goto IL_1e0e;
																																											case 467:
																																												goto IL_1e1c;
																																											case 70:
																																											case 203:
																																												goto IL_1e27;
																																											case 85:
																																												goto IL_1e4a;
																																											case 16:
																																												goto IL_1e58;
																																											case 630:
																																												goto IL_1e66;
																																											case 52:
																																												goto IL_1e79;
																																											case 180:
																																												goto IL_1e84;
																																											case 71:
																																											case 670:
																																												goto IL_1e92;
																																											case 20:
																																												goto IL_1ea6;
																																											case 590:
																																												goto IL_1ee5;
																																											case 497:
																																												goto IL_1ef8;
																																											case 217:
																																												goto IL_1f06;
																																											case 668:
																																											case 686:
																																												goto IL_1f14;
																																											case 693:
																																												goto IL_1f4c;
																																											case 519:
																																												goto IL_1f60;
																																											case 751:
																																												goto IL_1f73;
																																											case 356:
																																												goto IL_1f7e;
																																											case 280:
																																											case 543:
																																												goto IL_1f8c;
																																											case 316:
																																												goto IL_1fc2;
																																											case 82:
																																												goto IL_1fd5;
																																											case 208:
																																												goto IL_1fe3;
																																											case 121:
																																											case 178:
																																												goto IL_1ff1;
																																											case 31:
																																												goto IL_2005;
																																											case 636:
																																												goto IL_2044;
																																											case 62:
																																											case 484:
																																												goto IL_2057;
																																											case 396:
																																												goto IL_2097;
																																											case 236:
																																												goto IL_20ab;
																																											case 176:
																																												goto IL_20be;
																																											case 409:
																																												goto IL_20cc;
																																											case 481:
																																											case 597:
																																												goto IL_20d7;
																																											case 42:
																																												goto IL_2110;
																																											case 251:
																																												goto IL_2124;
																																											case 703:
																																												goto IL_2137;
																																											case 596:
																																												goto IL_2145;
																																											case 101:
																																											case 415:
																																												goto IL_2150;
																																											case 490:
																																												goto IL_2164;
																																											case 287:
																																												goto IL_21aa;
																																											case 737:
																																												goto IL_21bd;
																																											case 220:
																																												goto IL_21cb;
																																											case 246:
																																											case 629:
																																												goto IL_21d6;
																																											case 405:
																																												goto IL_21f4;
																																											case 556:
																																												goto IL_2202;
																																											case 654:
																																												goto IL_2210;
																																											case 3:
																																												goto IL_2223;
																																											case 306:
																																												goto IL_2231;
																																											case 194:
																																											case 290:
																																												goto IL_223c;
																																											case 258:
																																												goto IL_2256;
																																											case 300:
																																												goto IL_2269;
																																											case 576:
																																												goto IL_2277;
																																											case 23:
																																											case 711:
																																												goto IL_2285;
																																											case 333:
																																												goto IL_22a9;
																																											case 307:
																																												goto IL_22b7;
																																											case 157:
																																												goto IL_22c5;
																																											case 655:
																																												goto IL_22e1;
																																											case 745:
																																												goto IL_22ec;
																																											case 541:
																																											case 701:
																																												goto IL_22fa;
																																											case 708:
																																												goto IL_230e;
																																											case 709:
																																												goto IL_234d;
																																											case 680:
																																												goto IL_2360;
																																											case 286:
																																												goto IL_236e;
																																											case 141:
																																											case 705:
																																												goto IL_237c;
																																											case 531:
																																												goto IL_2396;
																																											case 485:
																																												goto IL_23a4;
																																											case 566:
																																												goto IL_23b2;
																																											case 433:
																																												goto IL_23c5;
																																											case 363:
																																												goto IL_23d3;
																																											case 160:
																																											case 264:
																																												goto IL_23de;
																																											case 156:
																																												goto IL_23f8;
																																											case 159:
																																												goto IL_240b;
																																											case 184:
																																												goto IL_2416;
																																											case 211:
																																											case 425:
																																												goto IL_2424;
																																											case 635:
																																												goto IL_242e;
																																											case 509:
																																												goto IL_2445;
																																											case 521:
																																												goto IL_2458;
																																											case 598:
																																												goto IL_2466;
																																											case 464:
																																											case 652:
																																												goto IL_2474;
																																											case 326:
																																												goto IL_2488;
																																											case 135:
																																												goto IL_24d5;
																																											case 335:
																																												goto IL_24e3;
																																											case 352:
																																												goto IL_24f6;
																																											case 456:
																																												goto IL_2501;
																																											case 51:
																																												goto IL_2518;
																																											case 167:
																																											case 342:
																																												goto IL_2526;
																																											case 109:
																																												goto IL_253f;
																																											case 557:
																																												goto IL_255b;
																																											case 49:
																																											case 291:
																																												goto IL_2569;
																																											case 39:
																																												goto IL_257d;
																																											case 97:
																																												goto IL_25b5;
																																											case 600:
																																												goto IL_25c8;
																																											case 310:
																																												goto IL_25d6;
																																											case 29:
																																											case 489:
																																												goto IL_25e4;
																																											case 508:
																																												goto IL_2652;
																																											case 89:
																																												goto IL_266e;
																																											case 283:
																																												goto IL_267c;
																																											case 314:
																																											case 355:
																																												goto IL_268a;
																																											case 580:
																																												goto IL_269e;
																																											case 651:
																																												goto IL_26ef;
																																											case 231:
																																												goto IL_26fd;
																																											case 348:
																																												goto IL_2710;
																																											case 421:
																																												goto IL_271b;
																																											case 181:
																																											case 459:
																																												goto IL_2729;
																																											case 700:
																																												goto IL_273d;
																																											case 111:
																																												goto IL_277a;
																																											case 448:
																																												goto IL_278d;
																																											case 25:
																																												goto IL_279b;
																																											case 78:
																																											case 186:
																																												goto IL_27a9;
																																											case 341:
																																												goto IL_27cc;
																																											case 397:
																																												goto IL_27da;
																																											case 190:
																																												goto IL_27e8;
																																											case 491:
																																												goto IL_27fb;
																																											case 534:
																																												goto IL_2806;
																																											case 273:
																																											case 594:
																																												goto IL_2814;
																																											case 339:
																																												goto IL_282d;
																																											case 431:
																																												goto IL_2840;
																																											case 559:
																																												goto IL_284e;
																																											case 493:
																																											case 690:
																																												goto IL_285c;
																																											case 665:
																																												goto IL_2880;
																																											case 478:
																																												goto IL_288e;
																																											case 96:
																																												goto IL_289c;
																																											case 10:
																																												goto IL_28af;
																																											case 487:
																																												goto IL_28bd;
																																											case 30:
																																											case 189:
																																												goto IL_28c8;
																																											case 452:
																																												goto IL_2928;
																																											case 7:
																																												goto IL_293b;
																																											case 50:
																																												goto IL_2946;
																																											case 43:
																																											case 748:
																																												goto IL_2954;
																																											case 588:
																																												goto IL_2968;
																																											case 533:
																																												goto IL_29a7;
																																											case 477:
																																												goto IL_29ba;
																																											case 518:
																																												goto IL_29c8;
																																											case 238:
																																											case 645:
																																												goto IL_29d6;
																																											case 366:
																																												goto IL_29ed;
																																											case 526:
																																												goto IL_2a00;
																																											case 496:
																																												goto IL_2a0e;
																																											case 152:
																																												goto IL_2a21;
																																											case 441:
																																												goto IL_2a2c;
																																											case 108:
																																											case 331:
																																												goto IL_2a3a;
																																											case 673:
																																												goto IL_2a65;
																																											case 473:
																																												goto IL_2a7e;
																																											case 206:
																																												goto IL_2a8c;
																																											case 120:
																																											case 454:
																																												goto IL_2a9a;
																																											case 87:
																																												goto IL_2ab7;
																																											case 124:
																																												goto IL_2b0d;
																																											case 138:
																																												goto IL_2b1b;
																																											case 202:
																																												goto IL_2b2e;
																																											case 147:
																																												goto IL_2b3c;
																																											case 33:
																																											case 323:
																																												goto IL_2b47;
																																											case 249:
																																												goto IL_2b5b;
																																											case 115:
																																												goto IL_2b9a;
																																											case 133:
																																												goto IL_2bad;
																																											case 592:
																																												goto IL_2bbb;
																																											case 165:
																																											case 428:
																																												goto IL_2bc9;
																																											case 48:
																																												goto IL_2bdd;
																																											case 219:
																																												goto IL_2c2a;
																																											case 179:
																																												goto IL_2c38;
																																											case 611:
																																												goto IL_2c4b;
																																											case 741:
																																												goto IL_2c59;
																																											case 148:
																																											case 276:
																																												goto IL_2c67;
																																											case 662:
																																												goto IL_2c7b;
																																											case 419:
																																												goto IL_2cea;
																																											case 69:
																																												goto IL_2cfd;
																																											case 293:
																																												goto IL_2d08;
																																											case 144:
																																											case 247:
																																												goto IL_2d16;
																																											case 12:
																																												goto IL_2d38;
																																											case 672:
																																												goto IL_2d4b;
																																											case 187:
																																												goto IL_2d59;
																																											case 350:
																																											case 435:
																																												goto IL_2d67;
																																											case 523:
																																												goto IL_2d75;
																																											case 161:
																																												goto IL_2d88;
																																											case 728:
																																												goto IL_2d96;
																																											case 623:
																																												goto IL_2da9;
																																											case 234:
																																												goto IL_2db4;
																																											case 391:
																																												goto IL_2dc2;
																																											case 263:
																																											case 517:
																																												goto IL_2dd0;
																																											case 656:
																																												goto IL_2de9;
																																											case 664:
																																												goto IL_2dfc;
																																											case 345:
																																											case 516:
																																												goto IL_2e0a;
																																											case 575:
																																												goto IL_2e1e;
																																											case 60:
																																												goto IL_2e5b;
																																											case 250:
																																												goto IL_2e6e;
																																											case 118:
																																												goto IL_2e7c;
																																											case 222:
																																											case 226:
																																												goto IL_2e87;
																																											case 318:
																																												goto IL_2ea0;
																																											case 569:
																																												goto IL_2eb3;
																																											case 381:
																																												goto IL_2ebe;
																																											case 198:
																																											case 574:
																																												goto IL_2ecc;
																																											case 94:
																																												goto IL_2f2a;
																																											case 617:
																																												goto IL_2f3d;
																																											case 367:
																																												goto IL_2f4b;
																																											case 410:
																																											case 639:
																																												goto IL_2f59;
																																											case 83:
																																												goto IL_2f6d;
																																											case 450:
																																												goto IL_2fa5;
																																											case 604:
																																												goto IL_2fc1;
																																											case 79:
																																												goto IL_2fcc;
																																											case 463:
																																											case 634:
																																												goto IL_2fda;
																																											case 492:
																																												goto IL_3023;
																																											case 610:
																																												goto IL_3037;
																																											case 527:
																																												goto IL_304a;
																																											case 704:
																																												goto IL_3058;
																																											case 535:
																																											case 692:
																																												goto IL_3066;
																																											case 128:
																																												goto IL_307a;
																																											case 127:
																																												goto IL_308d;
																																											case 112:
																																												goto IL_309b;
																																											case 275:
																																											case 460:
																																												goto IL_30a6;
																																											case 297:
																																												goto IL_30b4;
																																											case 15:
																																												goto IL_30d2;
																																											case 571:
																																												goto IL_30e0;
																																											case 191:
																																												goto IL_30f3;
																																											case 417:
																																												goto IL_3101;
																																											case 272:
																																											case 375:
																																												goto IL_3115;
																																											case 512:
																																												goto IL_312e;
																																											case 721:
																																												goto IL_3141;
																																											case 451:
																																												goto IL_314c;
																																											case 245:
																																											case 354:
																																												goto IL_315a;
																																											case 539:
																																												goto IL_3168;
																																											case 46:
																																												goto IL_317b;
																																											case 370:
																																												goto IL_3189;
																																											case 488:
																																												goto IL_31a5;
																																											case 657:
																																												goto IL_31b3;
																																											case 150:
																																											case 547:
																																												goto IL_31c1;
																																											case 427:
																																												goto IL_31d5;
																																											case 650:
																																												goto IL_3244;
																																											case 332:
																																												goto IL_3257;
																																											case 683:
																																												goto IL_3265;
																																											case 8:
																																											case 659:
																																												goto IL_3273;
																																											case 607:
																																												goto IL_3287;
																																											case 582:
																																												goto IL_32d4;
																																											case 282:
																																												goto IL_32e2;
																																											case 384:
																																												goto IL_32f5;
																																											case 583:
																																												goto IL_3303;
																																											case 457:
																																											case 626:
																																												goto IL_3311;
																																											case 483:
																																												goto IL_3325;
																																											case 134:
																																												goto IL_3364;
																																											case 358:
																																												goto IL_3377;
																																											case 99:
																																												goto IL_3385;
																																											case 136:
																																												goto IL_3393;
																																											case 177:
																																												goto IL_339e;
																																											case 185:
																																											case 593:
																																												goto IL_33ac;
																																											case 406:
																																												goto IL_33e4;
																																											case 562:
																																												goto IL_3401;
																																											case 320:
																																												goto IL_3414;
																																											case 584:
																																												goto IL_3422;
																																											case 525:
																																											case 572:
																																												goto IL_3430;
																																											case 215:
																																												goto IL_3444;
																																											case 403:
																																												goto IL_3496;
																																											case 471:
																																												goto IL_34a4;
																																											case 131:
																																											case 373:
																																												goto IL_34c0;
																																											case 470:
																																												goto IL_34da;
																																											case 532:
																																												goto IL_34ed;
																																											case 292:
																																												goto IL_34f8;
																																											case 142:
																																											case 591:
																																												goto IL_3506;
																																											case 325:
																																												goto IL_3523;
																																											case 193:
																																												goto IL_3562;
																																											case 132:
																																												goto IL_3572;
																																											case 312:
																																												goto IL_357d;
																																											case 18:
																																											case 26:
																																											case 40:
																																											case 57:
																																											case 72:
																																											case 81:
																																											case 91:
																																											case 92:
																																											case 95:
																																											case 113:
																																											case 122:
																																											case 143:
																																											case 151:
																																											case 170:
																																											case 171:
																																											case 195:
																																											case 210:
																																											case 214:
																																											case 223:
																																											case 224:
																																											case 225:
																																											case 233:
																																											case 235:
																																											case 240:
																																											case 242:
																																											case 253:
																																											case 259:
																																											case 261:
																																											case 262:
																																											case 265:
																																											case 266:
																																											case 271:
																																											case 284:
																																											case 295:
																																											case 296:
																																											case 303:
																																											case 304:
																																											case 305:
																																											case 311:
																																											case 313:
																																											case 319:
																																											case 321:
																																											case 330:
																																											case 369:
																																											case 372:
																																											case 374:
																																											case 376:
																																											case 379:
																																											case 380:
																																											case 382:
																																											case 387:
																																											case 388:
																																											case 400:
																																											case 407:
																																											case 408:
																																											case 414:
																																											case 420:
																																											case 434:
																																											case 438:
																																											case 446:
																																											case 466:
																																											case 468:
																																											case 475:
																																											case 482:
																																											case 486:
																																											case 494:
																																											case 506:
																																											case 515:
																																											case 540:
																																											case 548:
																																											case 581:
																																											case 603:
																																											case 605:
																																											case 615:
																																											case 618:
																																											case 633:
																																											case 640:
																																											case 642:
																																											case 643:
																																											case 647:
																																											case 648:
																																											case 661:
																																											case 667:
																																											case 684:
																																											case 687:
																																											case 715:
																																											case 717:
																																											case 719:
																																											case 720:
																																											case 729:
																																											case 731:
																																											case 733:
																																											case 734:
																																											case 736:
																																											case 744:
																																												goto end_IL_0c2e;
																																											case 5:
																																											case 6:
																																											case 9:
																																											case 17:
																																											case 22:
																																											case 37:
																																											case 41:
																																											case 47:
																																											case 68:
																																											case 73:
																																											case 74:
																																											case 88:
																																											case 93:
																																											case 98:
																																											case 107:
																																											case 110:
																																											case 123:
																																											case 130:
																																											case 139:
																																											case 149:
																																											case 166:
																																											case 168:
																																											case 172:
																																											case 173:
																																											case 174:
																																											case 205:
																																											case 207:
																																											case 227:
																																											case 237:
																																											case 252:
																																											case 257:
																																											case 279:
																																											case 288:
																																											case 294:
																																											case 298:
																																											case 299:
																																											case 317:
																																											case 336:
																																											case 337:
																																											case 340:
																																											case 343:
																																											case 346:
																																											case 357:
																																											case 362:
																																											case 364:
																																											case 365:
																																											case 389:
																																											case 395:
																																											case 398:
																																											case 401:
																																											case 412:
																																											case 418:
																																											case 429:
																																											case 430:
																																											case 436:
																																											case 437:
																																											case 442:
																																											case 453:
																																											case 465:
																																											case 469:
																																											case 479:
																																											case 500:
																																											case 510:
																																											case 513:
																																											case 522:
																																											case 530:
																																											case 544:
																																											case 545:
																																											case 555:
																																											case 558:
																																											case 563:
																																											case 567:
																																											case 570:
																																											case 579:
																																											case 587:
																																											case 609:
																																											case 624:
																																											case 628:
																																											case 660:
																																											case 663:
																																											case 677:
																																											case 678:
																																											case 685:
																																											case 689:
																																											case 695:
																																											case 697:
																																											case 699:
																																											case 706:
																																											case 707:
																																											case 710:
																																											case 713:
																																											case 716:
																																											case 718:
																																											case 742:
																																											case 750:
																																												goto end_IL_0be7;
																																											case 422:
																																												goto end_IL_35a4;
																																											case 616:
																																												goto end_IL_35b7;
																																											case 627:
																																												goto end_IL_35c1;
																																											case 619:
																																												goto end_IL_35cc;
																																											case 585:
																																												goto end_IL_35e5;
																																											case 444:
																																												goto end_IL_35f5;
																																											case 503:
																																												goto end_IL_3605;
																																											case 106:
																																												goto end_IL_3615;
																																											case 254:
																																												goto end_IL_3625;
																																											case 255:
																																												goto end_IL_3635;
																																											case 164:
																																											case 449:
																																												return;
																																											}
																																											continue;
																																										}
																																										num6++;
																																										goto IL_10ad;
																																										IL_10ad:
																																										ptr2 += 8;
																																										break;
																																										continue;
																																										end_IL_0be7:
																																										break;
																																									}
																																									break;
																																								}
																																								break;
																																							}
																																							goto end_IL_0c8e;
																																							continue;
																																							end_IL_0c2e:
																																							break;
																																							IL_0c2e:;
																																						}
																																						break;
																																						IL_0c3e:;
																																					}
																																					break;
																																				}
																																				goto IL_10c0;
																																				IL_111d:
																																				num6--;
																																				goto end_IL_0c8e;
																																				IL_10c0:
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																				num = 2;
																																				goto IL_1109;
																																				IL_1109:
																																				array[num6 - 2] = 0;
																																				goto IL_111d;
																																			}
																																			break;
																																		}
																																		goto IL_1130;
																																		IL_11fc:
																																		num6++;
																																		goto IL_120a;
																																		IL_1130:
																																		if (3 >= b)
																																		{
																																			goto IL_113b;
																																		}
																																		goto IL_1193;
																																		IL_113b:
																																		if (3 > b)
																																		{
																																			break;
																																		}
																																		goto IL_1149;
																																		IL_1149:
																																		ref int reference = ref array4[*(int*)(ptr2 + num3)];
																																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																		goto IL_1172;
																																		IL_1172:
																																		ptr2 += 8;
																																		goto IL_1180;
																																		IL_1180:
																																		num6--;
																																		goto end_IL_0c8e;
																																		IL_1193:
																																		if (4 < b)
																																		{
																																			break;
																																		}
																																		goto IL_11a1;
																																		IL_11a1:
																																		if (4 > b)
																																		{
																																			break;
																																		}
																																		num = 61;
																																		goto IL_11b8;
																																		IL_120a:
																																		ptr2 += 8;
																																		goto end_IL_0c8e;
																																		IL_11b8:
																																		array[num6] = 0;
																																		goto IL_11c6;
																																		IL_11c6:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																																		num = 632;
																																		goto IL_11f2;
																																		IL_11f2:
																																		array2[num6] = null;
																																		goto IL_11fc;
																																	}
																																	break;
																																}
																																goto IL_0de8;
																																IL_0e3c:
																																num6--;
																																goto end_IL_0c8e;
																																IL_0de8:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																goto IL_0e28;
																																IL_0e28:
																																array[num6 - 2] = 0;
																																goto IL_0e3c;
																															}
																															break;
																														}
																														goto IL_0d29;
																														IL_100e:
																														num6--;
																														goto end_IL_0c8e;
																														IL_0d29:
																														if (8 >= b)
																														{
																															goto IL_0d37;
																														}
																														goto IL_0eb6;
																														IL_0d37:
																														if (8 > b)
																														{
																															goto IL_0d45;
																														}
																														goto IL_0fa7;
																														IL_0d45:
																														if (6 >= b)
																														{
																															goto IL_0d50;
																														}
																														goto IL_0da0;
																														IL_0d50:
																														if (6 > b)
																														{
																															break;
																														}
																														goto IL_0d5e;
																														IL_0d5e:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0dc1;
																														IL_0dc1:
																														array[num6 - 2] = 0;
																														goto IL_0dd5;
																														IL_0dd5:
																														num6--;
																														goto end_IL_0c8e;
																														IL_0da0:
																														if (7 < b)
																														{
																															break;
																														}
																														goto IL_0dae;
																														IL_0dae:
																														if (7 > b)
																														{
																															break;
																														}
																														goto IL_0e4f;
																														IL_0e4f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0e8f;
																														IL_0e8f:
																														array[num6 - 2] = 0;
																														goto IL_0ea3;
																														IL_0ea3:
																														num6--;
																														goto end_IL_0c8e;
																														IL_0fa7:
																														num6--;
																														goto end_IL_0c8e;
																														IL_0eb6:
																														if (9 >= b)
																														{
																															goto IL_0f2c;
																														}
																														goto IL_0f89;
																														IL_0f89:
																														if (10 < b)
																														{
																															break;
																														}
																														goto IL_0f97;
																														IL_0f97:
																														if (10 > b)
																														{
																															break;
																														}
																														goto IL_1021;
																														IL_1021:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														num = 200;
																														goto IL_108c;
																														IL_108c:
																														num6 -= 2;
																														goto end_IL_0c8e;
																														IL_0f2c:
																														if (9 > b)
																														{
																															break;
																														}
																														goto IL_0fba;
																														IL_0fba:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0ffa;
																														IL_0ffa:
																														array[num6 - 2] = 0;
																														goto IL_100e;
																													}
																													goto end_IL_0cee;
																													continue;
																													end_IL_0c8e:
																													break;
																													IL_0c8e:;
																												}
																												break;
																											}
																											goto IL_121d;
																											IL_16cb:
																											num6++;
																											goto IL_16d9;
																											IL_121d:
																											if (17 >= b)
																											{
																												goto IL_122b;
																											}
																											goto IL_147a;
																											IL_122b:
																											if (17 <= b)
																											{
																												goto IL_1236;
																											}
																											goto IL_1262;
																											IL_1236:
																											global::_003CModule_003E.vrrig_59 = (VRRig)array2[num6 - 1];
																											goto IL_124f;
																											IL_124f:
																											num6--;
																											break;
																											IL_1262:
																											if (14 >= b)
																											{
																												goto IL_1270;
																											}
																											goto IL_1381;
																											IL_1270:
																											if (14 <= b)
																											{
																												goto IL_127b;
																											}
																											goto IL_12e3;
																											IL_127b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																											goto IL_12bc;
																											IL_12bc:
																											array[num6 - 2] = 0;
																											goto IL_12d0;
																											IL_12d0:
																											num6--;
																											break;
																											IL_12e3:
																											if (12 >= b)
																											{
																												goto IL_12ee;
																											}
																											goto IL_1344;
																											IL_12ee:
																											if (12 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_12fc;
																											IL_12fc:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																											goto IL_1315;
																											IL_1315:
																											array[num6] = 1;
																											goto IL_1323;
																											IL_1323:
																											num6++;
																											goto IL_1331;
																											IL_1331:
																											ptr2 += 16;
																											break;
																											IL_1344:
																											if (13 < b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_1352;
																											IL_1352:
																											if (13 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_1360;
																											IL_1360:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											num = 442;
																											break;
																											IL_1381:
																											if (15 < b)
																											{
																												goto IL_138c;
																											}
																											num = 56;
																											goto IL_13fe;
																											IL_138c:
																											if (16 < b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_139a;
																											IL_139a:
																											if (16 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_13a8;
																											IL_13a8:
																											array2[num6] = ((delegate*<VRRig>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																											goto IL_13c6;
																											IL_13c6:
																											array[num6] = 5;
																											goto IL_13d4;
																											IL_13d4:
																											num6++;
																											goto IL_13e2;
																											IL_13e2:
																											ptr2 += 8;
																											break;
																											IL_16d9:
																											ptr2 += 8;
																											break;
																											IL_13fe:
																											if (15 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_140c;
																											IL_140c:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											num = 455;
																											goto IL_1467;
																											IL_1467:
																											num6--;
																											break;
																											IL_147a:
																											if (20 >= b)
																											{
																												goto IL_1488;
																											}
																											goto IL_15e9;
																											IL_1488:
																											if (20 > b)
																											{
																												goto IL_1496;
																											}
																											goto IL_1582;
																											IL_1496:
																											if (18 >= b)
																											{
																												goto IL_14a1;
																											}
																											goto IL_14f7;
																											IL_14a1:
																											if (18 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_14af;
																											IL_14af:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(double*)(ptr2 + num4);
																											goto IL_14c8;
																											IL_14c8:
																											array[num6] = 3;
																											goto IL_14d6;
																											IL_14d6:
																											num6++;
																											goto IL_14e4;
																											IL_14e4:
																											ptr2 += 16;
																											break;
																											IL_14f7:
																											if (19 < b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_1505;
																											IL_1505:
																											if (19 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_1513;
																											IL_1513:
																											array[num6 - 1] = 3;
																											goto IL_1527;
																											IL_1527:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																											num = 727;
																											goto IL_156f;
																											IL_156f:
																											ptr2 += 8;
																											break;
																											IL_1582:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_15c2;
																											IL_15c2:
																											array[num6 - 2] = 3;
																											goto IL_15d6;
																											IL_15d6:
																											num6--;
																											break;
																											IL_15e9:
																											if (21 >= b)
																											{
																												goto IL_15f7;
																											}
																											goto IL_167d;
																											IL_15f7:
																											if (21 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_1605;
																											IL_1605:
																											array[num6 - 1] = 0;
																											num = 119;
																											goto IL_1622;
																											IL_1622:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																											num = 722;
																											goto IL_166a;
																											IL_166a:
																											ptr2 += 8;
																											break;
																											IL_167d:
																											if (22 < b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_168b;
																											IL_168b:
																											if (22 > b)
																											{
																												goto end_IL_0cee;
																											}
																											goto IL_1699;
																											IL_1699:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<int>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																											goto IL_16bd;
																											IL_16bd:
																											array[num6] = 0;
																											goto IL_16cb;
																										}
																										break;
																									}
																									goto IL_0f3c;
																									IL_0f76:
																									ptr2 += 8;
																									break;
																									IL_0f3c:
																									array2[num6] = ((delegate*<NetPlayer[]>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																									goto IL_0f5a;
																									IL_0f5a:
																									array[num6] = 5;
																									goto IL_0f68;
																									IL_0f68:
																									num6++;
																									goto IL_0f76;
																								}
																								break;
																							}
																							goto IL_16ec;
																							IL_2057:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																							goto IL_2097;
																							IL_16ec:
																							if (34 >= b)
																							{
																								goto IL_16fa;
																							}
																							goto IL_1bf7;
																							IL_16fa:
																							if (34 > b)
																							{
																								goto IL_1708;
																							}
																							goto IL_1bc2;
																							IL_1708:
																							if (28 < b)
																							{
																								goto IL_1716;
																							}
																							goto IL_19a8;
																							IL_1716:
																							if (31 >= b)
																							{
																								goto IL_1724;
																							}
																							goto IL_1889;
																							IL_1724:
																							if (31 > b)
																							{
																								goto IL_1732;
																							}
																							goto IL_1821;
																							IL_1732:
																							if (29 >= b)
																							{
																								goto IL_173d;
																							}
																							goto IL_17b8;
																							IL_173d:
																							if (29 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_174b;
																							IL_174b:
																							array[num6 - 1] = 4;
																							num = 413;
																							goto IL_1768;
																							IL_1768:
																							array2[num6 - 1] = ((delegate*<Transform, Vector3>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																							goto IL_17a5;
																							IL_17a5:
																							ptr2 += 8;
																							break;
																							IL_17b8:
																							if (30 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_17c6;
																							IL_17c6:
																							if (30 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_17d4;
																							IL_17d4:
																							array2[num6] = ((delegate*<VRRig>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																							goto IL_17f2;
																							IL_17f2:
																							array[num6] = 5;
																							goto IL_1800;
																							IL_1800:
																							num6++;
																							goto IL_180e;
																							IL_180e:
																							ptr2 += 8;
																							break;
																							IL_1821:
																							array[num6 - 1] = 5;
																							goto IL_1835;
																							IL_1835:
																							array2[num6 - 1] = ((delegate*<Component, Transform>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																							num = 631;
																							goto IL_1876;
																							IL_1876:
																							ptr2 += 8;
																							break;
																							IL_1889:
																							if (32 >= b)
																							{
																								goto IL_1894;
																							}
																							goto IL_1906;
																							IL_1894:
																							if (32 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_18a2;
																							IL_18a2:
																							array[num6 - 1] = 4;
																							goto IL_18b6;
																							IL_18b6:
																							array2[num6 - 1] = ((delegate*<Transform, Vector3>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																							goto IL_18f3;
																							IL_18f3:
																							ptr2 += 8;
																							break;
																							IL_1906:
																							if (33 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1914;
																							IL_1914:
																							if (33 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1922;
																							IL_1922:
																							array[num6 - 2] = 4;
																							goto IL_1936;
																							IL_1936:
																							array2[num6 - 2] = ((delegate*<Vector3, Vector3, Vector3>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																							goto IL_1987;
																							IL_1987:
																							num6--;
																							goto IL_1995;
																							IL_1995:
																							ptr2 += 8;
																							break;
																							IL_19a8:
																							if (28 > b)
																							{
																								goto IL_19b6;
																							}
																							goto IL_1b63;
																							IL_19b6:
																							if (25 >= b)
																							{
																								goto IL_19c4;
																							}
																							goto IL_1a72;
																							IL_19c4:
																							if (25 <= b)
																							{
																								goto IL_19cf;
																							}
																							goto IL_1a13;
																							IL_19cf:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_19fa;
																							IL_19fa:
																							array[num6 - 1] = 0;
																							break;
																							IL_1a13:
																							if (24 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1a21;
																							IL_1a21:
																							if (24 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1a2f;
																							IL_1a2f:
																							*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = (nint)((NetPlayer[])array2[num6 - 1]).LongLength;
																							goto IL_1a59;
																							IL_1a59:
																							array[num6 - 1] = 2;
																							break;
																							IL_1a72:
																							if (26 >= b)
																							{
																								goto IL_1a7d;
																							}
																							goto IL_1afa;
																							IL_1a7d:
																							if (26 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1a8b;
																							IL_1a8b:
																							array[num6 - 1] = 3;
																							goto IL_1a9f;
																							IL_1a9f:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							num = 55;
																							goto IL_1ae7;
																							IL_1ae7:
																							ptr2 += 8;
																							break;
																							IL_1afa:
																							if (27 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1b08;
																							IL_1b08:
																							if (27 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1b16;
																							IL_1b16:
																							array2[num6] = ((delegate*<VRRig>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																							goto IL_1b34;
																							IL_1b34:
																							array[num6] = 5;
																							goto IL_1b42;
																							IL_1b42:
																							num6++;
																							goto IL_1b50;
																							IL_1b50:
																							ptr2 += 8;
																							break;
																							IL_1b63:
																							array[num6 - 1] = 5;
																							goto IL_1b77;
																							IL_1b77:
																							array2[num6 - 1] = ((delegate*<Component, Transform>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																							goto IL_1baf;
																							IL_1baf:
																							ptr2 += 8;
																							break;
																							IL_1bc2:
																							global::_003CModule_003E.vector3_156 = (Vector3)array2[num6 - 1];
																							num = 614;
																							goto IL_1be4;
																							IL_1be4:
																							num6--;
																							break;
																							IL_1bf7:
																							if (40 < b)
																							{
																								goto IL_1c05;
																							}
																							num = 270;
																							goto IL_1e00;
																							IL_1c05:
																							if (43 >= b)
																							{
																								goto IL_1c13;
																							}
																							goto IL_1d12;
																							IL_1c13:
																							if (43 <= b)
																							{
																								goto IL_1c1e;
																							}
																							goto IL_1c6b;
																							IL_1c1e:
																							array2[num6] = ((delegate*<NetPlayer>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																							goto IL_1c3c;
																							IL_1c3c:
																							array[num6] = 5;
																							goto IL_1c4a;
																							IL_1c4a:
																							num6++;
																							goto IL_1c58;
																							IL_1c58:
																							ptr2 += 8;
																							break;
																							IL_1c6b:
																							if (41 >= b)
																							{
																								goto IL_1c76;
																							}
																							goto IL_1ca0;
																							IL_1c76:
																							if (41 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1c84;
																							IL_1c84:
																							byte* num7 = ptr2;
																							num5 = 1;
																							ptr2 = num7 + -200;
																							break;
																							IL_1ca0:
																							if (42 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1cae;
																							IL_1cae:
																							if (42 > b)
																							{
																								goto end_IL_0cee;
																							}
																							num = 679;
																							goto IL_1cc5;
																							IL_20ab:
																							num6--;
																							break;
																							IL_1cc5:
																							array[num6] = 5;
																							goto IL_1cd3;
																							IL_1cd3:
																							array2[num6] = ((delegate*<GorillaGameManager>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																							goto IL_1cf1;
																							IL_1cf1:
																							num6++;
																							goto IL_1cff;
																							IL_1cff:
																							ptr2 += 8;
																							break;
																							IL_1d12:
																							if (44 >= b)
																							{
																								goto IL_1d20;
																							}
																							goto IL_1daf;
																							IL_1d20:
																							if (44 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1d2e;
																							IL_1d2e:
																							array[num6 - 2] = 5;
																							goto IL_1d42;
																							IL_1d42:
																							array2[num6 - 2] = ((delegate*<GorillaGameManager, NetPlayer, VRRig>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((GorillaGameManager)array2[num6 - 2], (NetPlayer)array2[num6 - 1]);
																							goto IL_1d8e;
																							IL_1d8e:
																							num6--;
																							goto IL_1d9c;
																							IL_1d9c:
																							ptr2 += 8;
																							break;
																							IL_1daf:
																							if (45 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1dbd;
																							IL_1dbd:
																							if (45 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1dcb;
																							IL_1dcb:
																							global::_003CModule_003E.vrrig_58 = (VRRig)array2[num6 - 1];
																							goto IL_1de4;
																							IL_1de4:
																							num6--;
																							break;
																							IL_2097:
																							array[num6 - 2] = 3;
																							goto IL_20ab;
																							IL_1e00:
																							if (40 > b)
																							{
																								goto IL_1e0e;
																							}
																							goto IL_2057;
																							IL_1e0e:
																							if (37 >= b)
																							{
																								goto IL_1e1c;
																							}
																							goto IL_1f73;
																							IL_1e1c:
																							if (37 <= b)
																							{
																								goto IL_1e27;
																							}
																							goto IL_1e79;
																							IL_1e27:
																							array2[num6] = ((delegate*<Vector3>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																							goto IL_1e4a;
																							IL_1e4a:
																							array[num6] = 4;
																							goto IL_1e58;
																							IL_1e58:
																							num6++;
																							goto IL_1e66;
																							IL_1e66:
																							ptr2 += 8;
																							break;
																							IL_1e79:
																							if (35 >= b)
																							{
																								goto IL_1e84;
																							}
																							goto IL_1ef8;
																							IL_1e84:
																							if (35 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1e92;
																							IL_1e92:
																							array[num6 - 1] = 3;
																							goto IL_1ea6;
																							IL_1ea6:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_1ee5;
																							IL_1ee5:
																							ptr2 += 8;
																							break;
																							IL_1ef8:
																							if (36 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1f06;
																							IL_1f06:
																							if (36 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1f14;
																							IL_1f14:
																							array2[num6 - 1] = ((delegate*<VRRig, VRMap>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																							goto IL_1f4c;
																							IL_1f4c:
																							array[num6 - 1] = 5;
																							goto IL_1f60;
																							IL_1f60:
																							ptr2 += 8;
																							break;
																							IL_1f73:
																							if (38 >= b)
																							{
																								goto IL_1f7e;
																							}
																							goto IL_1fd5;
																							IL_1f7e:
																							if (38 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1f8c;
																							IL_1f8c:
																							((VRMap)array2[num6 - 2]).trackingRotationOffset = (Vector3)array2[num6 - 1];
																							num = 316;
																							goto IL_1fc2;
																							IL_1fc2:
																							num6 -= 2;
																							break;
																							IL_1fd5:
																							if (39 < b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1fe3;
																							IL_1fe3:
																							if (39 > b)
																							{
																								goto end_IL_0cee;
																							}
																							goto IL_1ff1;
																							IL_1ff1:
																							array[num6 - 1] = 3;
																							goto IL_2005;
																							IL_2005:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_2044;
																							IL_2044:
																							ptr2 += 8;
																							break;
																						}
																						break;
																					}
																					goto IL_0ec6;
																					IL_0f19:
																					ptr2 += 8;
																					break;
																					IL_0ec6:
																					array[num6 - 1] = 3;
																					goto IL_0eda;
																					IL_0eda:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																					goto IL_0f19;
																				}
																				break;
																			}
																			goto IL_20be;
																			IL_3523:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_3562;
																			IL_20be:
																			if (69 >= b)
																			{
																				goto IL_20cc;
																			}
																			goto IL_2b2e;
																			IL_20cc:
																			if (69 <= b)
																			{
																				goto IL_20d7;
																			}
																			goto IL_2137;
																			IL_20d7:
																			array2[num6 - 2] = ((NetPlayer[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])];
																			goto IL_2110;
																			IL_2110:
																			array[num6 - 2] = 5;
																			goto IL_2124;
																			IL_2124:
																			num6--;
																			break;
																			IL_2137:
																			if (57 >= b)
																			{
																				goto IL_2145;
																			}
																			goto IL_25c8;
																			IL_2145:
																			if (57 <= b)
																			{
																				goto IL_2150;
																			}
																			goto IL_21bd;
																			IL_2150:
																			array[num6 - 1] = 4;
																			goto IL_2164;
																			IL_2164:
																			array2[num6 - 1] = ((delegate*<Transform, Quaternion>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Transform)array2[num6 - 1]);
																			num = 287;
																			goto IL_21aa;
																			IL_21aa:
																			ptr2 += 8;
																			break;
																			IL_21bd:
																			if (51 >= b)
																			{
																				goto IL_21cb;
																			}
																			goto IL_23c5;
																			IL_21cb:
																			if (51 <= b)
																			{
																				goto IL_21d6;
																			}
																			goto IL_2223;
																			IL_21d6:
																			array2[num6] = ((delegate*<NetworkSystem>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																			goto IL_21f4;
																			IL_21f4:
																			array[num6] = 5;
																			goto IL_2202;
																			IL_2202:
																			num6++;
																			goto IL_2210;
																			IL_2210:
																			ptr2 += 8;
																			break;
																			IL_2223:
																			if (48 >= b)
																			{
																				goto IL_2231;
																			}
																			goto IL_22e1;
																			IL_2231:
																			if (48 <= b)
																			{
																				goto IL_223c;
																			}
																			goto IL_2269;
																			IL_223c:
																			global::_003CModule_003E.float_116 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_2256;
																			IL_2256:
																			num6--;
																			break;
																			IL_2269:
																			if (47 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2277;
																			IL_2277:
																			if (47 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2285;
																			IL_2285:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																			goto IL_22a9;
																			IL_22a9:
																			array[num6] = 3;
																			goto IL_22b7;
																			IL_22b7:
																			num6++;
																			goto IL_22c5;
																			IL_22c5:
																			ptr2 += 8;
																			num = 412;
																			break;
																			IL_22e1:
																			if (49 >= b)
																			{
																				goto IL_22ec;
																			}
																			goto IL_2360;
																			IL_22ec:
																			if (49 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_22fa;
																			IL_22fa:
																			array[num6 - 1] = 3;
																			goto IL_230e;
																			IL_230e:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_234d;
																			IL_234d:
																			ptr2 += 8;
																			break;
																			IL_2360:
																			if (50 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_236e;
																			IL_236e:
																			if (50 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_237c;
																			IL_237c:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																			goto IL_2396;
																			IL_2396:
																			array[num6] = 3;
																			goto IL_23a4;
																			IL_23a4:
																			num6++;
																			goto IL_23b2;
																			IL_23b2:
																			ptr2 += 8;
																			break;
																			IL_23c5:
																			if (54 >= b)
																			{
																				goto IL_23d3;
																			}
																			goto IL_24f6;
																			IL_23d3:
																			if (54 <= b)
																			{
																				goto IL_23de;
																			}
																			goto IL_240b;
																			IL_23de:
																			global::_003CModule_003E.int_213 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																			goto IL_23f8;
																			IL_23f8:
																			num6--;
																			break;
																			IL_240b:
																			if (52 >= b)
																			{
																				goto IL_2416;
																			}
																			goto IL_2458;
																			IL_2416:
																			if (52 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2424;
																			IL_2424:
																			array2[num6] = null;
																			goto IL_242e;
																			IL_242e:
																			array[num6] = 5;
																			num = 509;
																			goto IL_2445;
																			IL_2445:
																			num6++;
																			break;
																			IL_2458:
																			if (53 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2466;
																			IL_2466:
																			if (53 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2474;
																			IL_2474:
																			array[num6 - 2] = 0;
																			goto IL_2488;
																			IL_2488:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((NetworkSystem)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																			goto IL_24d5;
																			IL_24d5:
																			num6--;
																			goto IL_24e3;
																			IL_24e3:
																			ptr2 += 8;
																			break;
																			IL_24f6:
																			if (55 < b)
																			{
																				goto IL_2501;
																			}
																			num = 557;
																			goto IL_255b;
																			IL_2501:
																			if (56 < b)
																			{
																				goto end_IL_0cee;
																			}
																			num = 51;
																			goto IL_2518;
																			IL_3572:
																			if (92 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_357d;
																			IL_2518:
																			if (56 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2526;
																			IL_2526:
																			global::_003CModule_003E.vrrig_60 = (VRRig)array2[num6 - 1];
																			goto IL_253f;
																			IL_253f:
																			num6--;
																			break;
																			IL_3562:
																			ptr2 += 8;
																			break;
																			IL_255b:
																			if (55 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2569;
																			IL_2569:
																			array[num6 - 1] = 5;
																			goto IL_257d;
																			IL_257d:
																			array2[num6 - 1] = ((delegate*<NetworkSystem, NetPlayer>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((NetworkSystem)array2[num6 - 1]);
																			goto IL_25b5;
																			IL_25b5:
																			ptr2 += 8;
																			break;
																			IL_25c8:
																			if (63 >= b)
																			{
																				goto IL_25d6;
																			}
																			goto IL_28af;
																			IL_25d6:
																			if (63 <= b)
																			{
																				goto IL_25e4;
																			}
																			goto IL_266e;
																			IL_25e4:
																			ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) >= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_2652;
																			IL_2652:
																			num6 -= 2;
																			num = 299;
																			break;
																			IL_266e:
																			if (60 >= b)
																			{
																				goto IL_267c;
																			}
																			goto IL_27fb;
																			IL_267c:
																			if (60 <= b)
																			{
																				goto IL_268a;
																			}
																			goto IL_2710;
																			IL_268a:
																			array[num6 - 2] = 4;
																			goto IL_269e;
																			IL_269e:
																			array2[num6 - 2] = ((delegate*<Quaternion, Quaternion, Quaternion>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Quaternion)array2[num6 - 2], (Quaternion)array2[num6 - 1]);
																			goto IL_26ef;
																			IL_26ef:
																			num6--;
																			goto IL_26fd;
																			IL_26fd:
																			ptr2 += 8;
																			break;
																			IL_2710:
																			if (58 >= b)
																			{
																				goto IL_271b;
																			}
																			goto IL_278d;
																			IL_271b:
																			if (58 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2729;
																			IL_2729:
																			array[num6 - 1] = 4;
																			goto IL_273d;
																			IL_273d:
																			array2[num6 - 1] = ((delegate*<Quaternion, Quaternion>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Quaternion)array2[num6 - 1]);
																			goto IL_277a;
																			IL_277a:
																			ptr2 += 8;
																			break;
																			IL_278d:
																			if (59 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_279b;
																			IL_279b:
																			if (59 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_27a9;
																			IL_27a9:
																			array2[num6] = ((delegate*<Quaternion>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																			goto IL_27cc;
																			IL_27cc:
																			array[num6] = 4;
																			goto IL_27da;
																			IL_27da:
																			num6++;
																			goto IL_27e8;
																			IL_27e8:
																			ptr2 += 8;
																			break;
																			IL_27fb:
																			if (61 >= b)
																			{
																				goto IL_2806;
																			}
																			goto IL_2840;
																			IL_2806:
																			if (61 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2814;
																			IL_2814:
																			global::_003CModule_003E.quaternion_9 = (Quaternion)array2[num6 - 1];
																			goto IL_282d;
																			IL_282d:
																			num6--;
																			break;
																			IL_2840:
																			if (62 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_284e;
																			IL_284e:
																			if (62 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_285c;
																			IL_285c:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<float>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																			goto IL_2880;
																			IL_2880:
																			array[num6] = 3;
																			goto IL_288e;
																			IL_288e:
																			num6++;
																			goto IL_289c;
																			IL_289c:
																			ptr2 += 8;
																			break;
																			IL_28af:
																			if (66 >= b)
																			{
																				goto IL_28bd;
																			}
																			goto IL_2a21;
																			IL_28bd:
																			if (66 <= b)
																			{
																				goto IL_28c8;
																			}
																			goto IL_293b;
																			IL_28c8:
																			((delegate*<object, IntPtr, object[], int[], ref Vector3>)byteBufferSetLengthToFirstNull[array3[num6 - 2]])(array2[num6 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), array6, array4).z = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_2928;
																			IL_2928:
																			num6 -= 2;
																			break;
																			IL_293b:
																			if (64 >= b)
																			{
																				goto IL_2946;
																			}
																			goto IL_29ba;
																			IL_2946:
																			if (64 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2954;
																			IL_2954:
																			array[num6 - 1] = 3;
																			goto IL_2968;
																			IL_2968:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_29a7;
																			IL_29a7:
																			ptr2 += 8;
																			break;
																			IL_29ba:
																			if (65 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_29c8;
																			IL_29c8:
																			if (65 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_29d6;
																			IL_29d6:
																			array[num6] = 15;
																			num = 366;
																			goto IL_29ed;
																			IL_29ed:
																			array3[num6] = *(int*)(ptr2 + num3);
																			goto IL_2a00;
																			IL_2a00:
																			ptr2 += 8;
																			goto IL_2a0e;
																			IL_2a0e:
																			num6++;
																			break;
																			IL_2a21:
																			if (67 >= b)
																			{
																				goto IL_2a2c;
																			}
																			goto IL_2a7e;
																			IL_2a2c:
																			if (67 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2a3a;
																			IL_2a3a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																			goto IL_2a65;
																			IL_2a65:
																			array[num6 - 1] = 0;
																			break;
																			IL_2a7e:
																			if (68 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2a8c;
																			IL_2a8c:
																			if (68 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2a9a;
																			IL_2a9a:
																			array[num6 - 2] = 0;
																			num = 87;
																			goto IL_2ab7;
																			IL_2ab7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																			num = 124;
																			goto IL_2b0d;
																			IL_2b0d:
																			num6--;
																			goto IL_2b1b;
																			IL_2b1b:
																			ptr2 += 8;
																			break;
																			IL_2b2e:
																			if (81 >= b)
																			{
																				goto IL_2b3c;
																			}
																			goto IL_308d;
																			IL_2b3c:
																			if (81 <= b)
																			{
																				goto IL_2b47;
																			}
																			goto IL_2bad;
																			IL_2b47:
																			array[num6 - 1] = 3;
																			goto IL_2b5b;
																			IL_2b5b:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_2b9a;
																			IL_2b9a:
																			ptr2 += 8;
																			break;
																			IL_2bad:
																			if (75 >= b)
																			{
																				goto IL_2bbb;
																			}
																			goto IL_2e6e;
																			IL_2bbb:
																			if (75 <= b)
																			{
																				goto IL_2bc9;
																			}
																			goto IL_2c4b;
																			IL_2bc9:
																			array[num6 - 2] = 0;
																			goto IL_2bdd;
																			IL_2bdd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((GorillaGameManager)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																			goto IL_2c2a;
																			IL_2c2a:
																			num6--;
																			goto IL_2c38;
																			IL_2c38:
																			ptr2 += 8;
																			break;
																			IL_2c4b:
																			if (72 >= b)
																			{
																				goto IL_2c59;
																			}
																			goto IL_2da9;
																			IL_2c59:
																			if (72 <= b)
																			{
																				goto IL_2c67;
																			}
																			goto IL_2cfd;
																			IL_2c67:
																			array[num6 - 1] = 4;
																			goto IL_2c7b;
																			IL_2c7b:
																			array2[num6 - 1] = ((delegate*<ref Vector3, Vector3>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Vector3>)byteBufferSetLengthToFirstNull[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																			goto IL_2cea;
																			IL_2cea:
																			ptr2 += 8;
																			break;
																			IL_2cfd:
																			if (70 >= b)
																			{
																				goto IL_2d08;
																			}
																			goto IL_2d4b;
																			IL_2d08:
																			if (70 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2d16;
																			IL_2d16:
																			global::_003CModule_003E.netPlayer_4 = (NetPlayer)array2[num6 - 1];
																			num = 12;
																			goto IL_2d38;
																			IL_2d38:
																			num6--;
																			break;
																			IL_2d4b:
																			if (71 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2d59;
																			IL_2d59:
																			if (71 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2d67;
																			IL_2d67:
																			array[num6] = 15;
																			goto IL_2d75;
																			IL_2d75:
																			array3[num6] = *(int*)(ptr2 + num3);
																			goto IL_2d88;
																			IL_2d88:
																			ptr2 += 8;
																			goto IL_2d96;
																			IL_2d96:
																			num6++;
																			break;
																			IL_2da9:
																			if (73 < b)
																			{
																				goto IL_2db4;
																			}
																			goto IL_2dfc;
																			IL_2db4:
																			if (74 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2dc2;
																			IL_2dc2:
																			if (74 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2dd0;
																			IL_2dd0:
																			global::_003CModule_003E.quaternion_8 = (Quaternion)array2[num6 - 1];
																			goto IL_2de9;
																			IL_2de9:
																			num6--;
																			break;
																			IL_2dfc:
																			if (73 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2e0a;
																			IL_2e0a:
																			array[num6 - 1] = 4;
																			goto IL_2e1e;
																			IL_2e1e:
																			array2[num6 - 1] = ((delegate*<Vector3, Quaternion>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 1]);
																			goto IL_2e5b;
																			IL_2e5b:
																			ptr2 += 8;
																			break;
																			IL_2e6e:
																			if (78 >= b)
																			{
																				goto IL_2e7c;
																			}
																			goto IL_2fc1;
																			IL_2e7c:
																			if (78 <= b)
																			{
																				goto IL_2e87;
																			}
																			goto IL_2eb3;
																			IL_2e87:
																			global::_003CModule_003E.netPlayer_3 = (NetPlayer[])array2[num6 - 1];
																			goto IL_2ea0;
																			IL_2ea0:
																			num6--;
																			break;
																			IL_2eb3:
																			if (76 >= b)
																			{
																				goto IL_2ebe;
																			}
																			goto IL_2f3d;
																			IL_2ebe:
																			if (76 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2ecc;
																			IL_2ecc:
																			ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_2f2a;
																			IL_2f2a:
																			num6--;
																			break;
																			IL_2f3d:
																			if (77 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2f4b;
																			IL_2f4b:
																			if (77 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2f59;
																			IL_2f59:
																			array[num6 - 1] = 5;
																			goto IL_2f6d;
																			IL_2f6d:
																			array2[num6 - 1] = ((delegate*<NetworkSystem, NetPlayer[]>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((NetworkSystem)array2[num6 - 1]);
																			goto IL_2fa5;
																			IL_2fa5:
																			ptr2 += 8;
																			num = 678;
																			break;
																			IL_2fc1:
																			if (79 >= b)
																			{
																				goto IL_2fcc;
																			}
																			goto IL_304a;
																			IL_2fcc:
																			if (79 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_2fda;
																			IL_2fda:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																			num = 492;
																			goto IL_3023;
																			IL_3023:
																			array[num6 - 2] = 3;
																			goto IL_3037;
																			IL_3037:
																			num6--;
																			break;
																			IL_304a:
																			if (80 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3058;
																			IL_3058:
																			if (80 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3066;
																			IL_3066:
																			global::_003CModule_003E.vrrig_59 = (VRRig)array2[num6 - 1];
																			goto IL_307a;
																			IL_307a:
																			num6--;
																			break;
																			IL_308d:
																			if (87 >= b)
																			{
																				goto IL_309b;
																			}
																			goto IL_3377;
																			IL_309b:
																			if (87 <= b)
																			{
																				goto IL_30a6;
																			}
																			goto IL_30f3;
																			IL_30a6:
																			array[num6] = 5;
																			goto IL_30b4;
																			IL_30b4:
																			array2[num6] = ((delegate*<GorillaTagger>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])();
																			goto IL_30d2;
																			IL_30d2:
																			num6++;
																			goto IL_30e0;
																			IL_30e0:
																			ptr2 += 8;
																			break;
																			IL_30f3:
																			if (84 >= b)
																			{
																				goto IL_3101;
																			}
																			goto IL_3257;
																			IL_3101:
																			if (84 <= b)
																			{
																				num = 375;
																				goto IL_3115;
																			}
																			goto IL_3141;
																			IL_357d:
																			if (92 <= b)
																			{
																				num = 684;
																			}
																			goto end_IL_0cee;
																			IL_3115:
																			global::_003CModule_003E.vector3_157 = (Vector3)array2[num6 - 1];
																			goto IL_312e;
																			IL_312e:
																			num6--;
																			break;
																			IL_3141:
																			if (82 >= b)
																			{
																				goto IL_314c;
																			}
																			goto IL_31a5;
																			IL_314c:
																			if (82 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_315a;
																			IL_315a:
																			array[num6] = 15;
																			goto IL_3168;
																			IL_3168:
																			array3[num6] = *(int*)(ptr2 + num3);
																			goto IL_317b;
																			IL_317b:
																			ptr2 += 8;
																			goto IL_3189;
																			IL_3189:
																			num6++;
																			num = 389;
																			break;
																			IL_31a5:
																			if (83 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_31b3;
																			IL_31b3:
																			if (83 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_31c1;
																			IL_31c1:
																			array[num6 - 1] = 4;
																			goto IL_31d5;
																			IL_31d5:
																			array2[num6 - 1] = ((delegate*<ref Quaternion, Vector3>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref Quaternion>)byteBufferSetLengthToFirstNull[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																			goto IL_3244;
																			IL_3244:
																			ptr2 += 8;
																			break;
																			IL_3257:
																			if (85 >= b)
																			{
																				goto IL_3265;
																			}
																			goto IL_32f5;
																			IL_3265:
																			if (85 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3273;
																			IL_3273:
																			array[num6 - 2] = 0;
																			goto IL_3287;
																			IL_3287:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																			goto IL_32d4;
																			IL_32d4:
																			num6--;
																			goto IL_32e2;
																			IL_32e2:
																			ptr2 += 8;
																			break;
																			IL_32f5:
																			if (86 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3303;
																			IL_3303:
																			if (86 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3311;
																			IL_3311:
																			array[num6 - 1] = 3;
																			goto IL_3325;
																			IL_3325:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_3364;
																			IL_3364:
																			ptr2 += 8;
																			break;
																			IL_3377:
																			if (90 >= b)
																			{
																				goto IL_3385;
																			}
																			goto IL_34ed;
																			IL_3385:
																			if (90 > b)
																			{
																				goto IL_3393;
																			}
																			goto IL_34c0;
																			IL_3393:
																			if (88 >= b)
																			{
																				goto IL_339e;
																			}
																			goto IL_3414;
																			IL_339e:
																			if (88 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_33ac;
																			IL_33ac:
																			array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																			goto IL_33e4;
																			IL_33e4:
																			array[num6 - 1] = 5;
																			num = 562;
																			goto IL_3401;
																			IL_3401:
																			ptr2 += 8;
																			break;
																			IL_3414:
																			if (89 < b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3422;
																			IL_3422:
																			if (89 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3430;
																			IL_3430:
																			array[num6 - 2] = 3;
																			goto IL_3444;
																			IL_3444:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<Vector3, Vector3, float>)byteBufferSetLengthToFirstNull[*(int*)(ptr2 + num3)])((Vector3)array2[num6 - 2], (Vector3)array2[num6 - 1]);
																			goto IL_3496;
																			IL_3496:
																			num6--;
																			goto IL_34a4;
																			IL_34a4:
																			ptr2 += 8;
																			num = 123;
																			break;
																			IL_34c0:
																			global::_003CModule_003E.float_115 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_34da;
																			IL_34da:
																			num6--;
																			break;
																			IL_34ed:
																			if (91 >= b)
																			{
																				goto IL_34f8;
																			}
																			goto IL_3572;
																			IL_34f8:
																			if (91 > b)
																			{
																				goto end_IL_0cee;
																			}
																			goto IL_3506;
																			IL_3506:
																			array[num6 - 1] = 3;
																			num = 325;
																			goto IL_3523;
																		}
																		goto end_IL_0cfe;
																		continue;
																		end_IL_0cee:
																		break;
																		IL_0cee:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0cfe:
																break;
															}
															break;
														}
														break;
													}
													continue;
													end_IL_35a4:
													break;
												}
												continue;
												end_IL_35b7:
												break;
											}
											continue;
											end_IL_35c1:
											break;
										}
										continue;
										end_IL_35cc:
										break;
									}
									continue;
									end_IL_35e5:
									break;
								}
								continue;
								end_IL_35f5:
								break;
							}
							continue;
							end_IL_3605:
							break;
						}
						continue;
						end_IL_3615:
						break;
					}
					continue;
					end_IL_3625:
					break;
				}
				continue;
				end_IL_3635:
				break;
			}
		}
	}

	private void OnDisable()
	{
		ReleaseWriterLockCustomErrorsMode(this);
	}

	private unsafe void method_0()
	{
		int num = 77;
		int num5 = default(int);
		int num7 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OwnClipboardGetAllVarCustData.getResolvedAssemblyFilesgetIsHeld);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															num = 162;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03bd:
																	if (b >= 1)
																	{
																		while (b <= 23)
																		{
																			while (true)
																			{
																				IL_03a0:
																				if (12 < b)
																				{
																					while (true)
																					{
																						IL_0393:
																						if (18 < b)
																						{
																							while (true)
																							{
																								IL_0383:
																								if (21 < b)
																								{
																									while (true)
																									{
																										IL_0373:
																										if (22 >= b)
																										{
																											while (22 <= b)
																											{
																												num = 204;
																												while (true)
																												{
																													if (num != 204)
																													{
																														if (num != 1185)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 190:
																															goto IL_0360;
																														case 24:
																															goto IL_0373;
																														case 71:
																															goto IL_0383;
																														case 138:
																															goto IL_0393;
																														case 69:
																															goto IL_03a0;
																														case 177:
																															goto IL_03ad;
																														case 20:
																															goto IL_03bd;
																														case 162:
																															goto end_IL_03bd;
																														case 52:
																														case 174:
																															goto end_IL_03cd;
																														case 68:
																															goto IL_03f1;
																														case 70:
																															goto IL_0401;
																														case 43:
																															goto IL_040f;
																														case 13:
																															goto IL_041a;
																														case 82:
																															goto IL_042d;
																														case 85:
																															goto IL_043d;
																														case 95:
																															goto IL_0450;
																														case 48:
																															goto IL_045b;
																														case 67:
																															goto IL_046b;
																														case 86:
																															goto IL_0479;
																														case 60:
																															goto IL_0487;
																														case 102:
																															goto IL_049a;
																														case 92:
																															goto IL_04a5;
																														case 103:
																															goto IL_04b8;
																														case 115:
																														case 123:
																															goto IL_04c8;
																														case 110:
																														case 127:
																															goto IL_04e6;
																														case 74:
																															goto IL_052f;
																														case 27:
																															goto IL_0543;
																														case 133:
																															goto IL_0556;
																														case 139:
																															goto IL_0569;
																														case 2:
																															goto IL_0577;
																														case 145:
																															goto IL_058a;
																														case 94:
																															goto IL_0598;
																														case 23:
																														case 121:
																															goto IL_05a6;
																														case 15:
																															goto IL_05cf;
																														case 46:
																															goto IL_05dd;
																														case 148:
																															goto IL_05f0;
																														case 149:
																															goto IL_0603;
																														case 65:
																															goto IL_060e;
																														case 101:
																															goto IL_0621;
																														case 151:
																															goto IL_0634;
																														case 157:
																															goto IL_0647;
																														case 147:
																															goto IL_0655;
																														case 4:
																														case 66:
																															goto IL_0660;
																														case 166:
																															goto IL_068e;
																														case 55:
																															goto IL_0699;
																														case 53:
																														case 79:
																															goto IL_06a7;
																														case 132:
																															goto IL_06c0;
																														case 22:
																															goto IL_06d7;
																														case 54:
																															goto IL_06e5;
																														case 117:
																															goto IL_06f8;
																														case 87:
																															goto IL_0706;
																														case 57:
																														case 156:
																															goto IL_0714;
																														case 97:
																															goto IL_0754;
																														case 35:
																															goto IL_0768;
																														case 9:
																														case 168:
																															goto IL_077b;
																														case 96:
																														case 169:
																															goto IL_07c6;
																														case 170:
																															goto IL_07de;
																														case 175:
																															goto IL_07f7;
																														case 130:
																															goto IL_0802;
																														case 8:
																														case 32:
																															goto IL_0810;
																														case 137:
																															goto IL_081e;
																														case 141:
																															goto IL_0841;
																														case 109:
																															goto IL_084b;
																														case 44:
																															goto IL_085e;
																														case 61:
																															goto IL_086c;
																														case 89:
																														case 146:
																															goto IL_087a;
																														case 0:
																															goto IL_08ba;
																														case 7:
																															goto IL_08ce;
																														case 176:
																															goto IL_08e1;
																														case 178:
																															goto IL_08f4;
																														case 58:
																															goto IL_0902;
																														case 179:
																															goto IL_0915;
																														case 18:
																															goto IL_0923;
																														case 159:
																															goto IL_0931;
																														case 14:
																														case 26:
																															goto IL_093f;
																														case 51:
																														case 180:
																															goto IL_0958;
																														case 40:
																															goto IL_0998;
																														case 72:
																															goto IL_09ac;
																														case 88:
																														case 182:
																															goto IL_09bf;
																														case 10:
																															goto IL_09d7;
																														case 41:
																															goto IL_09e5;
																														case 126:
																															goto IL_09f3;
																														case 33:
																														case 183:
																															goto IL_0a06;
																														case 99:
																														case 184:
																															goto IL_0a19;
																														case 36:
																															goto IL_0a2d;
																														case 6:
																															goto IL_0a6c;
																														case 49:
																														case 185:
																															goto IL_0a7f;
																														case 155:
																															goto IL_0a98;
																														case 21:
																															goto IL_0aa6;
																														case 100:
																															goto end_IL_034d;
																														case 186:
																															goto IL_0ac7;
																														case 187:
																															goto IL_0ada;
																														case 107:
																															goto IL_0b19;
																														case 189:
																															goto IL_0b2c;
																														case 192:
																															goto IL_0b48;
																														case 128:
																														case 188:
																															goto IL_0b56;
																														case 191:
																															goto IL_0b97;
																														case 42:
																															goto IL_0bb4;
																														case 64:
																														case 193:
																															goto IL_0bc7;
																														case 119:
																															goto IL_0c19;
																														case 194:
																															goto IL_0c35;
																														case 28:
																														case 129:
																															goto IL_0c43;
																														case 114:
																															goto IL_0cae;
																														case 195:
																															goto IL_0cc1;
																														case 16:
																															goto IL_0ccf;
																														case 12:
																														case 73:
																															goto IL_0cdd;
																														case 75:
																															goto IL_0d1d;
																														case 196:
																															goto IL_0d31;
																														case 50:
																															goto IL_0d41;
																														case 11:
																															goto IL_0d5a;
																														case 143:
																															goto IL_0d65;
																														case 5:
																														case 25:
																														case 31:
																														case 38:
																														case 39:
																														case 47:
																														case 62:
																														case 63:
																														case 90:
																														case 91:
																														case 104:
																														case 106:
																														case 108:
																														case 112:
																														case 113:
																														case 118:
																														case 122:
																														case 134:
																														case 136:
																														case 150:
																														case 152:
																														case 158:
																														case 164:
																														case 165:
																														case 167:
																														case 173:
																															goto end_IL_0360;
																														case 1:
																														case 17:
																														case 19:
																														case 29:
																														case 30:
																														case 45:
																														case 59:
																														case 78:
																														case 80:
																														case 81:
																														case 98:
																														case 111:
																														case 124:
																														case 125:
																														case 135:
																														case 140:
																														case 142:
																														case 144:
																														case 153:
																														case 154:
																														case 160:
																														case 161:
																														case 163:
																														case 171:
																														case 172:
																														case 197:
																															goto end_IL_03dd;
																														case 84:
																															goto end_IL_0d83;
																														case 83:
																															goto end_IL_0d96;
																														case 120:
																															goto end_IL_0da0;
																														case 116:
																															goto end_IL_0dab;
																														case 3:
																															goto end_IL_0dbb;
																														case 56:
																														case 131:
																															goto end_IL_0dcb;
																														case 37:
																															goto end_IL_0ddb;
																														case 181:
																															goto end_IL_0deb;
																														case 34:
																															goto end_IL_0dfb;
																														case 76:
																															goto end_IL_0e0b;
																														case 77:
																															goto end_IL_0e1b;
																														case 93:
																														case 105:
																															return;
																														}
																														continue;
																													}
																													goto IL_0d41;
																													IL_0d41:
																													byte* num6 = ptr2;
																													num5 = 1;
																													ptr2 = num6 + -200;
																													goto end_IL_03dd;
																													continue;
																													end_IL_034d:
																													break;
																												}
																												goto IL_0ab4;
																												continue;
																												end_IL_0360:
																												break;
																												IL_0360:;
																											}
																											break;
																										}
																										goto IL_0d5a;
																										IL_0d65:
																										if (23 <= b)
																										{
																										}
																										break;
																										IL_0d5a:
																										if (23 < b)
																										{
																											break;
																										}
																										goto IL_0d65;
																									}
																									break;
																								}
																								goto IL_0915;
																								IL_0a6c:
																								ptr2 += 8;
																								goto end_IL_03dd;
																								IL_0915:
																								if (21 > b)
																								{
																									goto IL_0923;
																								}
																								goto IL_0a19;
																								IL_0923:
																								if (19 >= b)
																								{
																									goto IL_0931;
																								}
																								goto IL_0cc1;
																								IL_0931:
																								if (19 > b)
																								{
																									break;
																								}
																								goto IL_093f;
																								IL_093f:
																								array[num7 - 1] = 3;
																								goto IL_0ada;
																								IL_0ada:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) = ((delegate*<double, double>)getXmlFieldOrderEntryPointEntryFieldId[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]));
																								goto IL_0b19;
																								IL_0b19:
																								ptr2 += 8;
																								goto end_IL_03dd;
																								IL_0cc1:
																								if (20 < b)
																								{
																									break;
																								}
																								goto IL_0ccf;
																								IL_0ccf:
																								if (20 > b)
																								{
																									break;
																								}
																								goto IL_0cdd;
																								IL_0cdd:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																								goto IL_0d1d;
																								IL_0d1d:
																								array[num7 - 2] = 3;
																								goto IL_0d31;
																								IL_0d31:
																								num7--;
																								goto end_IL_03dd;
																								IL_0a19:
																								array[num7 - 1] = 0;
																								goto IL_0a2d;
																								IL_0a2d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) = ((delegate*<double, int>)getXmlFieldOrderEntryPointEntryFieldId[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]));
																								goto IL_0a6c;
																							}
																							break;
																						}
																						goto IL_0401;
																						IL_0ab4:
																						ptr2 += 16;
																						goto end_IL_03dd;
																						IL_0401:
																						if (18 > b)
																						{
																							goto IL_040f;
																						}
																						goto IL_0a7f;
																						IL_040f:
																						if (15 >= b)
																						{
																							goto IL_041a;
																						}
																						goto IL_043d;
																						IL_041a:
																						if (15 > b)
																						{
																							goto IL_0603;
																						}
																						goto IL_0bc7;
																						IL_0bc7:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0c19;
																						IL_0c19:
																						num7--;
																						num = 160;
																						goto end_IL_03dd;
																						IL_0603:
																						if (13 >= b)
																						{
																							goto IL_060e;
																						}
																						goto IL_0621;
																						IL_060e:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_07c6;
																						IL_07c6:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_03dd;
																						IL_0621:
																						if (14 < b)
																						{
																							break;
																						}
																						goto IL_0b48;
																						IL_0b48:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0b56;
																						IL_0b56:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1])) ? 1 : 0);
																						goto IL_0b97;
																						IL_0b97:
																						array[num7 - 2] = 0;
																						num = 42;
																						goto IL_0bb4;
																						IL_0bb4:
																						num7--;
																						goto end_IL_03dd;
																						IL_043d:
																						if (16 < b)
																						{
																							goto IL_058a;
																						}
																						goto IL_0634;
																						IL_0634:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_09bf;
																						IL_09bf:
																						array2[num7] = array5[*(int*)(ptr2 + num3)];
																						goto IL_09d7;
																						IL_09d7:
																						array[num7] = 5;
																						goto IL_09e5;
																						IL_09e5:
																						num7++;
																						goto IL_09f3;
																						IL_09f3:
																						ptr2 += 8;
																						goto end_IL_03dd;
																						IL_058a:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0598;
																						IL_0598:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_05a6;
																						IL_05a6:
																						((delegate*<Class199, void>)getXmlFieldOrderEntryPointEntryFieldId[*(int*)(ptr2 + num3)])((Class199)array2[num7 - 1]);
																						goto IL_05cf;
																						IL_05cf:
																						num7--;
																						goto IL_05dd;
																						IL_05dd:
																						ptr2 += 8;
																						goto end_IL_03dd;
																						IL_0a7f:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(double*)(ptr2 + num4);
																						goto IL_0a98;
																						IL_0a98:
																						array[num7] = 3;
																						goto IL_0aa6;
																						IL_0aa6:
																						num7++;
																						goto IL_0ab4;
																					}
																					break;
																				}
																				goto IL_03f1;
																				IL_0cae:
																				num7 -= 2;
																				goto end_IL_03dd;
																				IL_03f1:
																				if (12 > b)
																				{
																					goto IL_042d;
																				}
																				goto IL_04c8;
																				IL_04c8:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(long*)(ptr2 + num4);
																				goto IL_0569;
																				IL_0569:
																				array[num7] = 1;
																				goto IL_0577;
																				IL_0577:
																				num7++;
																				goto IL_08e1;
																				IL_08e1:
																				ptr2 += 16;
																				goto end_IL_03dd;
																				IL_042d:
																				if (6 < b)
																				{
																					goto IL_0450;
																				}
																				goto IL_0556;
																				IL_0556:
																				if (6 > b)
																				{
																					goto IL_0647;
																				}
																				goto IL_0958;
																				IL_0958:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_0998;
																				IL_0998:
																				array[num7 - 2] = 0;
																				goto IL_09ac;
																				IL_09ac:
																				num7--;
																				goto end_IL_03dd;
																				IL_0647:
																				if (3 >= b)
																				{
																					goto IL_0655;
																				}
																				goto IL_07f7;
																				IL_0655:
																				if (3 <= b)
																				{
																					goto IL_0660;
																				}
																				goto IL_068e;
																				IL_0660:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_08f4;
																				IL_08f4:
																				ptr2 += 8;
																				goto IL_0902;
																				IL_0902:
																				num7--;
																				goto end_IL_03dd;
																				IL_068e:
																				if (1 >= b)
																				{
																					goto IL_0699;
																				}
																				goto IL_06f8;
																				IL_0699:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_06a7;
																				IL_06a7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = *(int*)(ptr2 + num3);
																				goto IL_06c0;
																				IL_06c0:
																				array[num7] = 0;
																				num = 22;
																				goto IL_06d7;
																				IL_06d7:
																				num7++;
																				goto IL_06e5;
																				IL_06e5:
																				ptr2 += 8;
																				goto end_IL_03dd;
																				IL_06f8:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0706;
																				IL_0706:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0714;
																				IL_0714:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_0754;
																				IL_0754:
																				array[num7 - 2] = 0;
																				goto IL_0768;
																				IL_0768:
																				num7--;
																				goto end_IL_03dd;
																				IL_07f7:
																				if (4 >= b)
																				{
																					goto IL_0802;
																				}
																				goto IL_085e;
																				IL_0802:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0810;
																				IL_0810:
																				array[num7] = 0;
																				goto IL_081e;
																				IL_081e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0841;
																				IL_0841:
																				array2[num7] = null;
																				goto IL_084b;
																				IL_084b:
																				num7++;
																				goto IL_0b2c;
																				IL_0b2c:
																				ptr2 += 8;
																				num = 135;
																				goto end_IL_03dd;
																				IL_085e:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_086c;
																				IL_086c:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_087a;
																				IL_087a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				goto IL_08ba;
																				IL_08ba:
																				array[num7 - 2] = 0;
																				goto IL_08ce;
																				IL_08ce:
																				num7--;
																				goto end_IL_03dd;
																				IL_0450:
																				if (9 >= b)
																				{
																					goto IL_045b;
																				}
																				goto IL_046b;
																				IL_045b:
																				if (9 > b)
																				{
																					goto IL_049a;
																				}
																				goto IL_077b;
																				IL_077b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				num = 170;
																				goto IL_07de;
																				IL_07de:
																				array[num7 - 2] = 0;
																				goto IL_0ac7;
																				IL_0ac7:
																				num7--;
																				goto end_IL_03dd;
																				IL_049a:
																				if (7 < b)
																				{
																					goto IL_04a5;
																				}
																				goto IL_04b8;
																				IL_04a5:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_05f0;
																				IL_05f0:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0a06;
																				IL_0a06:
																				num7--;
																				goto end_IL_03dd;
																				IL_04b8:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04e6;
																				IL_04e6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1]);
																				num = 74;
																				goto IL_052f;
																				IL_052f:
																				array[num7 - 2] = 0;
																				goto IL_0543;
																				IL_0543:
																				num7--;
																				goto end_IL_03dd;
																				IL_046b:
																				if (10 < b)
																				{
																					goto IL_0479;
																				}
																				goto IL_0c35;
																				IL_0479:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0487;
																				IL_0487:
																				if (11 > b)
																				{
																					break;
																				}
																				goto end_IL_03dd;
																				IL_0c35:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0c43;
																				IL_0c43:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 114;
																				goto IL_0cae;
																			}
																			break;
																			IL_03ad:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_03dd;
																	continue;
																	end_IL_03bd:
																	break;
																}
																continue;
																end_IL_03cd:
																break;
															}
															continue;
															end_IL_03dd:
															break;
														}
														continue;
														end_IL_0d83:
														break;
													}
													continue;
													end_IL_0d96:
													break;
												}
												continue;
												end_IL_0da0:
												break;
											}
											continue;
											end_IL_0dab:
											break;
										}
										continue;
										end_IL_0dbb:
										break;
									}
									continue;
									end_IL_0dcb:
									break;
								}
								continue;
								end_IL_0ddb:
								break;
							}
							continue;
							end_IL_0deb:
							break;
						}
						continue;
						end_IL_0dfb:
						break;
					}
					continue;
					end_IL_0e0b:
					break;
				}
				continue;
				end_IL_0e1b:
				break;
			}
		}
	}

	private unsafe void method_1()
	{
		int num = 105;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setHashNamePropertyAccessor.SwallowUnhandledExceptionssetLocked);
											num = 225;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_058c:
																if (b >= 1)
																{
																	while (b <= 37)
																	{
																		while (true)
																		{
																			IL_056c:
																			if (19 >= b)
																			{
																				while (true)
																				{
																					IL_055f:
																					if (19 > b)
																					{
																						while (true)
																						{
																							IL_054f:
																							if (9 >= b)
																							{
																								while (true)
																								{
																									IL_053f:
																									if (9 > b)
																									{
																										while (true)
																										{
																											IL_052f:
																											if (4 >= b)
																											{
																												while (true)
																												{
																													IL_051c:
																													if (4 <= b)
																													{
																														num = 315;
																														while (true)
																														{
																															if (num != 315)
																															{
																																if (num != 1296)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 170:
																																	goto IL_051c;
																																case 245:
																																	goto IL_052f;
																																case 187:
																																	goto IL_053f;
																																case 209:
																																	goto IL_054f;
																																case 60:
																																	goto IL_055f;
																																case 24:
																																	goto IL_056c;
																																case 296:
																																	goto IL_057c;
																																case 202:
																																	goto IL_058c;
																																case 214:
																																	goto end_IL_058c;
																																case 43:
																																case 222:
																																	goto end_IL_059c;
																																case 148:
																																case 203:
																																	goto IL_05b7;
																																case 121:
																																	goto IL_05c5;
																																case 95:
																																	goto IL_05e8;
																																case 38:
																																	goto IL_05f6;
																																case 211:
																																case 254:
																																	goto IL_0609;
																																case 49:
																																	goto IL_0649;
																																case 206:
																																	goto IL_065d;
																																case 180:
																																	goto IL_0670;
																																case 129:
																																	goto IL_0687;
																																case 281:
																																	goto IL_06aa;
																																case 270:
																																	goto IL_06b4;
																																case 143:
																																	goto IL_06c2;
																																case 92:
																																	goto IL_06de;
																																case 23:
																																	goto IL_06ec;
																																case 215:
																																	goto IL_06f7;
																																case 176:
																																	goto IL_0705;
																																case 101:
																																case 234:
																																	goto IL_0713;
																																case 142:
																																	goto IL_072c;
																																case 183:
																																	goto IL_073a;
																																case 7:
																																	goto IL_0748;
																																case 210:
																																case 271:
																																	goto IL_0764;
																																case 152:
																																	goto IL_07a4;
																																case 26:
																																	goto IL_07b8;
																																case 97:
																																	goto IL_07cb;
																																case 295:
																																	goto IL_07d9;
																																case 157:
																																case 263:
																																	goto IL_07f0;
																																case 257:
																																	goto IL_0819;
																																case 51:
																																	goto IL_0827;
																																case 227:
																																	goto IL_083a;
																																case 81:
																																	goto IL_0848;
																																case 196:
																																case 204:
																																	goto IL_0853;
																																case 15:
																																	goto IL_0893;
																																case 194:
																																	goto IL_08a7;
																																case 99:
																																	goto IL_08c3;
																																case 58:
																																	goto IL_08d1;
																																case 59:
																																case 140:
																																	goto IL_08df;
																																case 249:
																																	goto IL_091f;
																																case 153:
																																	goto IL_0933;
																																case 2:
																																	goto IL_094f;
																																case 207:
																																	goto IL_095a;
																																case 17:
																																case 288:
																																	goto IL_0968;
																																case 63:
																																	goto IL_09a8;
																																case 147:
																																	goto IL_09bc;
																																case 172:
																																	goto IL_09cf;
																																case 74:
																																	goto IL_09e6;
																																case 42:
																																case 192:
																																	goto IL_09fd;
																																case 294:
																																	goto IL_0a10;
																																case 136:
																																	goto IL_0a1e;
																																case 14:
																																case 256:
																																	goto IL_0a29;
																																case 198:
																																	goto IL_0a41;
																																case 193:
																																	goto IL_0a4f;
																																case 242:
																																	goto IL_0a5d;
																																case 55:
																																	goto IL_0a74;
																																case 40:
																																case 191:
																																	goto IL_0a82;
																																case 78:
																																	goto IL_0ae4;
																																case 167:
																																case 247:
																																	goto IL_0af7;
																																case 9:
																																	goto IL_0b0b;
																																case 306:
																																	goto IL_0b5f;
																																case 44:
																																	goto IL_0b6d;
																																case 217:
																																	goto IL_0b80;
																																case 185:
																																	goto IL_0b8b;
																																case 83:
																																	goto IL_0b9e;
																																case 175:
																																	goto IL_0bac;
																																case 62:
																																case 297:
																																	goto IL_0bc3;
																																case 93:
																																	goto IL_0bdc;
																																case 71:
																																	goto IL_0bea;
																																case 244:
																																	goto IL_0bf8;
																																case 213:
																																	goto IL_0c0b;
																																case 260:
																																	goto IL_0c19;
																																case 21:
																																case 111:
																																	goto IL_0c24;
																																case 149:
																																	goto IL_0c76;
																																case 47:
																																	goto IL_0c89;
																																case 146:
																																	goto IL_0c97;
																																case 139:
																																case 280:
																																	goto IL_0ca5;
																																case 158:
																																	goto IL_0ce6;
																																case 265:
																																	goto IL_0cfa;
																																case 87:
																																	goto IL_0d0d;
																																case 106:
																																	goto IL_0d18;
																																case 19:
																																case 154:
																																	goto IL_0d26;
																																case 120:
																																	goto IL_0d44;
																																case 54:
																																	goto IL_0d52;
																																case 48:
																																	goto IL_0d69;
																																case 276:
																																	goto IL_0d85;
																																case 164:
																																	goto IL_0d93;
																																case 6:
																																case 108:
																																	goto IL_0da1;
																																case 278:
																																	goto IL_0dd9;
																																case 163:
																																	goto IL_0ded;
																																case 1:
																																	goto IL_0e00;
																																case 279:
																																	goto IL_0e0e;
																																case 223:
																																	goto IL_0e1c;
																																case 30:
																																case 119:
																																	goto IL_0e27;
																																case 232:
																																	goto IL_0e7b;
																																case 189:
																																	goto IL_0e8e;
																																case 151:
																																	goto IL_0e9c;
																																case 110:
																																case 269:
																																	goto IL_0ea7;
																																case 56:
																																	goto IL_0ee7;
																																case 85:
																																	goto IL_0efb;
																																case 33:
																																	goto IL_0f0e;
																																case 156:
																																	goto IL_0f1c;
																																case 11:
																																case 308:
																																	goto IL_0f2a;
																																case 150:
																																	goto IL_0f72;
																																case 70:
																																	goto IL_0f85;
																																case 61:
																																	goto IL_0f93;
																																case 197:
																																	goto IL_0fa1;
																																case 162:
																																case 181:
																																	goto IL_0faf;
																																case 169:
																																	goto IL_0fc7;
																																case 173:
																																	goto IL_0fee;
																																case 57:
																																	goto IL_101b;
																																case 166:
																																	goto IL_103c;
																																case 302:
																																	goto IL_104f;
																																case 94:
																																case 109:
																																	goto IL_105d;
																																case 304:
																																	goto IL_106b;
																																case 28:
																																	goto IL_1089;
																																case 235:
																																	goto IL_1097;
																																case 114:
																																	goto IL_10aa;
																																case 72:
																																	goto IL_10b8;
																																case 91:
																																case 287:
																																	goto IL_10c6;
																																case 125:
																																	goto IL_10da;
																																case 138:
																																	goto IL_1127;
																																case 52:
																																	goto IL_1135;
																																case 69:
																																	goto IL_1148;
																																case 65:
																																	goto IL_1156;
																																case 39:
																																case 103:
																																	goto IL_1164;
																																case 240:
																																	goto IL_1178;
																																case 246:
																																	goto IL_11b7;
																																case 253:
																																	goto IL_11ca;
																																case 205:
																																	goto IL_11d5;
																																case 275:
																																case 286:
																																	goto IL_11e3;
																																case 277:
																																	goto IL_11ff;
																																case 35:
																																	goto IL_120d;
																																case 307:
																																	goto IL_1220;
																																case 16:
																																case 224:
																																	goto IL_122b;
																																case 264:
																																	goto IL_123f;
																																case 25:
																																	goto IL_1252;
																																case 233:
																																	goto IL_1260;
																																case 237:
																																	goto IL_126e;
																																case 29:
																																	goto IL_127c;
																																case 10:
																																	goto IL_128a;
																																case 182:
																																case 291:
																																	goto IL_1298;
																																case 299:
																																	goto IL_12ac;
																																case 116:
																																	goto IL_12eb;
																																case 68:
																																case 238:
																																	goto IL_1307;
																																case 305:
																																	goto IL_1311;
																																case 75:
																																	goto IL_131f;
																																case 228:
																																	goto IL_1332;
																																case 250:
																																	goto IL_133d;
																																case 102:
																																case 122:
																																	goto IL_134b;
																																case 178:
																																	goto IL_1383;
																																case 155:
																																	goto IL_1397;
																																case 266:
																																	goto IL_13b3;
																																case 300:
																																	goto IL_13c1;
																																case 41:
																																case 195:
																																	goto IL_13cf;
																																case 221:
																																	goto IL_13e8;
																																case 219:
																																	goto IL_1404;
																																case 76:
																																case 100:
																																	goto IL_140f;
																																case 144:
																																	goto IL_144f;
																																case 73:
																																	goto IL_1463;
																																case 241:
																																	goto IL_147f;
																																case 79:
																																	goto IL_148d;
																																case 285:
																																case 289:
																																	goto IL_1498;
																																case 86:
																																	goto IL_14b1;
																																case 226:
																																	goto IL_14bf;
																																case 274:
																																	goto IL_14cd;
																																case 133:
																																	goto IL_14e0;
																																case 12:
																																	goto IL_14ee;
																																case 27:
																																case 262:
																																	goto IL_14fc;
																																case 220:
																																	goto IL_1529;
																																case 67:
																																	goto IL_153c;
																																case 115:
																																	goto IL_1547;
																																case 132:
																																case 268:
																																	goto IL_1552;
																																case 22:
																																	goto IL_1566;
																																case 243:
																																	goto IL_15a5;
																																case 3:
																																case 4:
																																case 5:
																																case 8:
																																case 18:
																																case 20:
																																case 32:
																																case 34:
																																case 45:
																																case 50:
																																case 53:
																																case 64:
																																case 66:
																																case 80:
																																case 89:
																																case 107:
																																case 113:
																																case 117:
																																case 123:
																																case 126:
																																case 130:
																																case 131:
																																case 137:
																																case 141:
																																case 145:
																																case 159:
																																case 171:
																																case 186:
																																case 190:
																																case 201:
																																case 212:
																																case 251:
																																case 252:
																																case 258:
																																case 259:
																																case 267:
																																case 272:
																																case 282:
																																case 293:
																																case 298:
																																	goto end_IL_0509;
																																case 0:
																																case 13:
																																case 31:
																																case 37:
																																case 77:
																																case 82:
																																case 84:
																																case 88:
																																case 96:
																																case 98:
																																case 112:
																																case 118:
																																case 124:
																																case 127:
																																case 128:
																																case 135:
																																case 161:
																																case 165:
																																case 168:
																																case 174:
																																case 177:
																																case 179:
																																case 188:
																																case 199:
																																case 200:
																																case 216:
																																case 218:
																																case 229:
																																case 230:
																																case 231:
																																case 239:
																																case 248:
																																case 255:
																																case 261:
																																case 273:
																																case 283:
																																case 284:
																																case 292:
																																case 301:
																																case 303:
																																	goto end_IL_05ac;
																																case 225:
																																	goto end_IL_15d1;
																																case 90:
																																	goto end_IL_15e4;
																																case 36:
																																	goto end_IL_15ee;
																																case 184:
																																	goto end_IL_1602;
																																case 134:
																																	goto end_IL_1612;
																																case 208:
																																	goto end_IL_1622;
																																case 160:
																																	goto end_IL_1632;
																																case 46:
																																	goto end_IL_1642;
																																case 104:
																																	goto end_IL_1652;
																																case 105:
																																	goto end_IL_1662;
																																case 236:
																																case 290:
																																	return;
																																}
																																continue;
																															}
																															goto IL_0670;
																															IL_06b4:
																															num6++;
																															goto IL_06c2;
																															IL_06c2:
																															ptr2 += 8;
																															num = 199;
																															goto end_IL_05ac;
																															IL_0670:
																															array[num6] = 0;
																															num = 129;
																															goto IL_0687;
																															IL_0687:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																															goto IL_06aa;
																															IL_06aa:
																															array2[num6] = null;
																															goto IL_06b4;
																															continue;
																															end_IL_0509:
																															break;
																														}
																														break;
																													}
																													goto IL_06de;
																													IL_0827:
																													num6--;
																													goto end_IL_05ac;
																													IL_07f0:
																													ref int reference = ref array4[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																													goto IL_0819;
																													IL_06de:
																													if (2 >= b)
																													{
																														goto IL_06ec;
																													}
																													goto IL_07cb;
																													IL_06ec:
																													if (2 > b)
																													{
																														goto IL_06f7;
																													}
																													num = 271;
																													goto IL_0764;
																													IL_06f7:
																													if (1 < b)
																													{
																														break;
																													}
																													goto IL_0705;
																													IL_0705:
																													if (1 > b)
																													{
																														break;
																													}
																													goto IL_0713;
																													IL_0713:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																													goto IL_072c;
																													IL_072c:
																													array[num6] = 0;
																													goto IL_073a;
																													IL_073a:
																													num6++;
																													goto IL_0748;
																													IL_0748:
																													ptr2 += 8;
																													goto end_IL_05ac;
																													IL_0819:
																													ptr2 += 8;
																													goto IL_0827;
																													IL_0764:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																													goto IL_07a4;
																													IL_07a4:
																													array[num6 - 2] = 0;
																													goto IL_07b8;
																													IL_07b8:
																													num6--;
																													goto end_IL_05ac;
																													IL_07cb:
																													if (3 < b)
																													{
																														break;
																													}
																													goto IL_07d9;
																													IL_07d9:
																													if (3 > b)
																													{
																														break;
																													}
																													num = 157;
																													goto IL_07f0;
																												}
																												break;
																											}
																											goto IL_083a;
																											IL_09e6:
																											if (8 > b)
																											{
																												break;
																											}
																											num = 192;
																											goto IL_09fd;
																											IL_083a:
																											if (6 >= b)
																											{
																												goto IL_0848;
																											}
																											goto IL_094f;
																											IL_0848:
																											if (6 <= b)
																											{
																												goto IL_0853;
																											}
																											goto IL_08c3;
																											IL_0853:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_0893;
																											IL_0893:
																											array[num6 - 2] = 0;
																											goto IL_08a7;
																											IL_08a7:
																											num6--;
																											num = 255;
																											goto end_IL_05ac;
																											IL_08c3:
																											if (5 < b)
																											{
																												break;
																											}
																											goto IL_08d1;
																											IL_08d1:
																											if (5 > b)
																											{
																												break;
																											}
																											goto IL_08df;
																											IL_08df:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_091f;
																											IL_091f:
																											array[num6 - 2] = 0;
																											goto IL_0933;
																											IL_0933:
																											num6--;
																											num = 230;
																											goto end_IL_05ac;
																											IL_094f:
																											if (7 >= b)
																											{
																												goto IL_095a;
																											}
																											goto IL_09cf;
																											IL_095a:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_0968;
																											IL_0968:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																											goto IL_09a8;
																											IL_09a8:
																											array[num6 - 2] = 0;
																											goto IL_09bc;
																											IL_09bc:
																											num6--;
																											goto end_IL_05ac;
																											IL_09cf:
																											if (8 < b)
																											{
																												break;
																											}
																											num = 74;
																											goto IL_09e6;
																											IL_09fd:
																											num6--;
																											goto end_IL_05ac;
																										}
																										break;
																									}
																									goto IL_0609;
																									IL_065d:
																									num6--;
																									goto end_IL_05ac;
																									IL_0609:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																									goto IL_0649;
																									IL_0649:
																									array[num6 - 2] = 0;
																									goto IL_065d;
																								}
																								break;
																							}
																							goto IL_0a10;
																							IL_0da1:
																							array2[num6 - 1] = ((delegate*<VRRig, VRMap>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 1]);
																							goto IL_0dd9;
																							IL_0a10:
																							if (14 >= b)
																							{
																								goto IL_0a1e;
																							}
																							goto IL_0c0b;
																							IL_0a1e:
																							if (14 <= b)
																							{
																								goto IL_0a29;
																							}
																							goto IL_0a41;
																							IL_0a29:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_05ac;
																							IL_0a41:
																							if (11 >= b)
																							{
																								goto IL_0a4f;
																							}
																							goto IL_0b80;
																							IL_0a4f:
																							if (11 > b)
																							{
																								goto IL_0a5d;
																							}
																							goto IL_0af7;
																							IL_0a5d:
																							if (10 < b)
																							{
																								break;
																							}
																							num = 55;
																							goto IL_0a74;
																							IL_0dd9:
																							array[num6 - 1] = 5;
																							goto IL_0ded;
																							IL_0a74:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_0a82;
																							IL_0a82:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0ae4;
																							IL_0ae4:
																							num6 -= 2;
																							goto end_IL_05ac;
																							IL_0af7:
																							array[num6 - 2] = 0;
																							goto IL_0b0b;
																							IL_0b0b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((delegate*<int, int, int>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																							goto IL_0b5f;
																							IL_0b5f:
																							num6--;
																							goto IL_0b6d;
																							IL_0b6d:
																							ptr2 += 8;
																							goto end_IL_05ac;
																							IL_0b80:
																							if (12 >= b)
																							{
																								goto IL_0b8b;
																							}
																							goto IL_0b9e;
																							IL_0b8b:
																							if (12 > b)
																							{
																								break;
																							}
																							goto end_IL_05ac;
																							IL_0b9e:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_0bac;
																							IL_0bac:
																							if (13 > b)
																							{
																								break;
																							}
																							num = 62;
																							goto IL_0bc3;
																							IL_0ded:
																							ptr2 += 8;
																							goto end_IL_05ac;
																							IL_0bc3:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0bdc;
																							IL_0bdc:
																							array[num6] = 1;
																							goto IL_0bea;
																							IL_0bea:
																							num6++;
																							goto IL_0bf8;
																							IL_0bf8:
																							ptr2 += 16;
																							goto end_IL_05ac;
																							IL_0c0b:
																							if (16 >= b)
																							{
																								goto IL_0c19;
																							}
																							goto IL_0d0d;
																							IL_0c19:
																							if (16 <= b)
																							{
																								goto IL_0c24;
																							}
																							goto IL_0c89;
																							IL_0c24:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0c76;
																							IL_0c76:
																							num6--;
																							goto end_IL_05ac;
																							IL_0c89:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_0c97;
																							IL_0c97:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_0ca5;
																							IL_0ca5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																							goto IL_0ce6;
																							IL_0ce6:
																							array[num6 - 2] = 0;
																							goto IL_0cfa;
																							IL_0cfa:
																							num6--;
																							goto end_IL_05ac;
																							IL_0d0d:
																							if (17 >= b)
																							{
																								goto IL_0d18;
																							}
																							goto IL_0d85;
																							IL_0d18:
																							if (17 > b)
																							{
																								break;
																							}
																							goto IL_0d26;
																							IL_0d26:
																							array2[num6] = ((delegate*<VRRig>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])();
																							goto IL_0d44;
																							IL_0d44:
																							array[num6] = 5;
																							goto IL_0d52;
																							IL_0d52:
																							num6++;
																							num = 48;
																							goto IL_0d69;
																							IL_0d69:
																							ptr2 += 8;
																							num = 292;
																							goto end_IL_05ac;
																							IL_0d85:
																							if (18 < b)
																							{
																								break;
																							}
																							goto IL_0d93;
																							IL_0d93:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0da1;
																						}
																						break;
																					}
																					goto IL_05b7;
																					IL_05f6:
																					ptr2 += 8;
																					goto end_IL_05ac;
																					IL_05b7:
																					array[num6] = 4;
																					goto IL_05c5;
																					IL_05c5:
																					array2[num6] = ((delegate*<Vector3>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])();
																					goto IL_05e8;
																					IL_05e8:
																					num6++;
																					goto IL_05f6;
																				}
																				break;
																			}
																			goto IL_0e00;
																			IL_1552:
																			array[num6 - 1] = 3;
																			goto IL_1566;
																			IL_0e00:
																			if (28 < b)
																			{
																				goto IL_0e0e;
																			}
																			goto IL_1220;
																			IL_0e0e:
																			if (33 >= b)
																			{
																				goto IL_0e1c;
																			}
																			goto IL_10aa;
																			IL_0e1c:
																			if (33 <= b)
																			{
																				goto IL_0e27;
																			}
																			goto IL_0e8e;
																			IL_0e27:
																			ptr2 = (((array2[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0e7b;
																			IL_0e7b:
																			num6--;
																			goto end_IL_05ac;
																			IL_0e8e:
																			if (30 >= b)
																			{
																				goto IL_0e9c;
																			}
																			goto IL_0f85;
																			IL_0e9c:
																			if (30 <= b)
																			{
																				goto IL_0ea7;
																			}
																			goto IL_0f0e;
																			IL_0ea7:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																			goto IL_0ee7;
																			IL_0ee7:
																			array[num6 - 2] = 3;
																			goto IL_0efb;
																			IL_0efb:
																			num6--;
																			goto end_IL_05ac;
																			IL_0f0e:
																			if (29 < b)
																			{
																				break;
																			}
																			goto IL_0f1c;
																			IL_0f1c:
																			if (29 > b)
																			{
																				break;
																			}
																			goto IL_0f2a;
																			IL_0f2a:
																			ptr2 = ((array2[num6 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0f72;
																			IL_0f72:
																			num6--;
																			goto end_IL_05ac;
																			IL_0f85:
																			if (31 < b)
																			{
																				goto IL_0f93;
																			}
																			goto IL_104f;
																			IL_0f93:
																			if (32 < b)
																			{
																				break;
																			}
																			goto IL_0fa1;
																			IL_0fa1:
																			if (32 > b)
																			{
																				break;
																			}
																			goto IL_0faf;
																			IL_0faf:
																			array[num6] = array[num6 - 1];
																			goto IL_0fc7;
																			IL_0fc7:
																			array3[num6 - 0] = array3[num6 - 1];
																			num = 173;
																			goto IL_0fee;
																			IL_0fee:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																			num = 57;
																			goto IL_101b;
																			IL_101b:
																			array2[num6] = array2[num6 - 1];
																			num = 166;
																			goto IL_103c;
																			IL_103c:
																			num6++;
																			goto end_IL_05ac;
																			IL_104f:
																			if (31 > b)
																			{
																				break;
																			}
																			goto IL_105d;
																			IL_105d:
																			array[num6] = 5;
																			goto IL_106b;
																			IL_106b:
																			array2[num6] = ((delegate*<GorillaTagger>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])();
																			goto IL_1089;
																			IL_1089:
																			num6++;
																			goto IL_1097;
																			IL_1097:
																			ptr2 += 8;
																			goto end_IL_05ac;
																			IL_10aa:
																			if (35 >= b)
																			{
																				goto IL_10b8;
																			}
																			goto IL_11ca;
																			IL_10b8:
																			if (35 <= b)
																			{
																				goto IL_10c6;
																			}
																			goto IL_1148;
																			IL_10c6:
																			array[num6 - 2] = 0;
																			goto IL_10da;
																			IL_10da:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																			goto IL_1127;
																			IL_1127:
																			num6--;
																			goto IL_1135;
																			IL_1135:
																			ptr2 += 8;
																			goto end_IL_05ac;
																			IL_1148:
																			if (34 < b)
																			{
																				break;
																			}
																			goto IL_1156;
																			IL_1156:
																			if (34 > b)
																			{
																				break;
																			}
																			goto IL_1164;
																			IL_1164:
																			array[num6 - 1] = 3;
																			goto IL_1178;
																			IL_1178:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_11b7;
																			IL_11b7:
																			ptr2 += 8;
																			goto end_IL_05ac;
																			IL_11ca:
																			if (36 >= b)
																			{
																				goto IL_11d5;
																			}
																			goto IL_11ff;
																			IL_11d5:
																			if (36 > b)
																			{
																				break;
																			}
																			goto IL_11e3;
																			IL_11e3:
																			byte* num7 = ptr2;
																			num5 = 1;
																			ptr2 = num7 + -200;
																			goto end_IL_05ac;
																			IL_11ff:
																			if (37 < b)
																			{
																				break;
																			}
																			goto IL_120d;
																			IL_120d:
																			if (37 > b)
																			{
																			}
																			break;
																			IL_1220:
																			if (28 <= b)
																			{
																				goto IL_122b;
																			}
																			goto IL_1252;
																			IL_122b:
																			global::_003CModule_003E.vrrig_61 = (VRRig)array2[num6 - 1];
																			goto IL_123f;
																			IL_123f:
																			num6--;
																			goto end_IL_05ac;
																			IL_1252:
																			if (23 < b)
																			{
																				goto IL_1260;
																			}
																			num = 219;
																			goto IL_1404;
																			IL_1260:
																			if (25 >= b)
																			{
																				goto IL_126e;
																			}
																			goto IL_1332;
																			IL_126e:
																			if (25 > b)
																			{
																				goto IL_127c;
																			}
																			num = 238;
																			goto IL_1307;
																			IL_127c:
																			if (24 < b)
																			{
																				break;
																			}
																			goto IL_128a;
																			IL_128a:
																			if (24 > b)
																			{
																				break;
																			}
																			goto IL_1298;
																			IL_1298:
																			array[num6 - 1] = 0;
																			goto IL_12ac;
																			IL_12ac:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, int>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_12eb;
																			IL_12eb:
																			ptr2 += 8;
																			goto end_IL_05ac;
																			IL_15a5:
																			ptr2 += 8;
																			num = 161;
																			goto end_IL_05ac;
																			IL_1307:
																			array2[num6] = null;
																			goto IL_1311;
																			IL_1311:
																			array[num6] = 5;
																			goto IL_131f;
																			IL_131f:
																			num6++;
																			goto end_IL_05ac;
																			IL_1332:
																			if (26 >= b)
																			{
																				goto IL_133d;
																			}
																			goto IL_13b3;
																			IL_133d:
																			if (26 > b)
																			{
																				break;
																			}
																			goto IL_134b;
																			IL_134b:
																			array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																			goto IL_1383;
																			IL_1383:
																			array[num6 - 1] = 5;
																			goto IL_1397;
																			IL_1397:
																			ptr2 += 8;
																			num = 179;
																			goto end_IL_05ac;
																			IL_13b3:
																			if (27 < b)
																			{
																				break;
																			}
																			goto IL_13c1;
																			IL_13c1:
																			if (27 > b)
																			{
																				break;
																			}
																			goto IL_13cf;
																			IL_13cf:
																			global::_003CModule_003E.vrrig_61 = (VRRig)array2[num6 - 1];
																			goto IL_13e8;
																			IL_13e8:
																			num6--;
																			goto end_IL_05ac;
																			IL_1566:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) = ((delegate*<double, double>)KerbSmartCardUnlockLogonNonPublic[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]));
																			goto IL_15a5;
																			IL_1404:
																			if (23 <= b)
																			{
																				goto IL_140f;
																			}
																			goto IL_147f;
																			IL_140f:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																			goto IL_144f;
																			IL_144f:
																			array[num6 - 2] = 3;
																			goto IL_1463;
																			IL_1463:
																			num6--;
																			num = 273;
																			goto end_IL_05ac;
																			IL_147f:
																			if (21 >= b)
																			{
																				goto IL_148d;
																			}
																			goto IL_153c;
																			IL_148d:
																			if (21 <= b)
																			{
																				goto IL_1498;
																			}
																			goto IL_14e0;
																			IL_1498:
																			*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(double*)(ptr2 + num4);
																			goto IL_14b1;
																			IL_14b1:
																			array[num6] = 3;
																			goto IL_14bf;
																			IL_14bf:
																			num6++;
																			goto IL_14cd;
																			IL_14cd:
																			ptr2 += 16;
																			goto end_IL_05ac;
																			IL_14e0:
																			if (20 < b)
																			{
																				break;
																			}
																			goto IL_14ee;
																			IL_14ee:
																			if (20 > b)
																			{
																				break;
																			}
																			goto IL_14fc;
																			IL_14fc:
																			((VRMap)array2[num6 - 2]).trackingRotationOffset = (Vector3)array2[num6 - 1];
																			goto IL_1529;
																			IL_1529:
																			num6 -= 2;
																			goto end_IL_05ac;
																			IL_153c:
																			if (22 < b)
																			{
																				break;
																			}
																			goto IL_1547;
																			IL_1547:
																			if (22 > b)
																			{
																				break;
																			}
																			goto IL_1552;
																		}
																		break;
																		IL_057c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_05ac;
																continue;
																end_IL_058c:
																break;
															}
															continue;
															end_IL_059c:
															break;
														}
														continue;
														end_IL_05ac:
														break;
													}
													continue;
													end_IL_15d1:
													break;
												}
												continue;
												end_IL_15e4:
												break;
											}
											continue;
											end_IL_15ee:
											break;
										}
										continue;
										end_IL_1602:
										break;
									}
									continue;
									end_IL_1612:
									break;
								}
								continue;
								end_IL_1622:
								break;
							}
							continue;
							end_IL_1632:
							break;
						}
						continue;
						end_IL_1642:
						break;
					}
					continue;
					end_IL_1652:
					break;
				}
				continue;
				end_IL_1662:
				break;
			}
		}
	}

	public Class199()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_0, int int_1)
	{
		int num = 11;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 30;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							num = 101;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										num = 31;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GBDecoderTuesday.GuidStylesHashName);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02b1:
															byte b = *ptr2;
															while (true)
															{
																IL_02a1:
																ptr2++;
																while (true)
																{
																	IL_0291:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0274:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0267:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_0257:
																								if (7 > b)
																								{
																									while (6 >= b)
																									{
																										while (6 <= b)
																										{
																											while (true)
																											{
																												IL_01f5:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01d6:
																													array[num5 - 2] = 0;
																													num = 109;
																													while (true)
																													{
																														if (num != 109)
																														{
																															if (num != 1090)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 47:
																																goto IL_01d6;
																															case 13:
																															case 55:
																																goto IL_01f5;
																															case 1:
																																goto IL_0237;
																															case 102:
																																goto IL_0247;
																															case 45:
																																goto IL_0257;
																															case 54:
																																goto IL_0267;
																															case 15:
																																goto IL_0274;
																															case 97:
																																goto IL_0281;
																															case 41:
																																goto IL_0291;
																															case 87:
																																goto IL_02a1;
																															case 32:
																															case 72:
																																goto IL_02b1;
																															case 23:
																																goto IL_02bc;
																															case 44:
																															case 80:
																																goto IL_02cf;
																															case 66:
																																goto IL_02dd;
																															case 69:
																															case 75:
																																goto IL_02f4;
																															case 62:
																																goto IL_0334;
																															case 12:
																																goto IL_0348;
																															case 76:
																															case 82:
																																goto IL_035b;
																															case 18:
																															case 81:
																																goto IL_0369;
																															case 74:
																																goto IL_0374;
																															case 6:
																															case 71:
																																goto IL_0382;
																															case 14:
																																goto IL_03ab;
																															case 57:
																																goto IL_03b9;
																															case 48:
																																goto IL_03cc;
																															case 7:
																																goto IL_03da;
																															case 3:
																															case 4:
																																goto IL_03e8;
																															case 36:
																																goto IL_0428;
																															case 40:
																																goto IL_0445;
																															case 33:
																																goto IL_0461;
																															case 49:
																															case 56:
																																goto IL_046c;
																															case 67:
																																goto IL_04b1;
																															case 63:
																																goto IL_04bf;
																															case 61:
																															case 88:
																																goto IL_04d2;
																															case 79:
																															case 89:
																																goto IL_04f0;
																															case 43:
																																goto IL_04fe;
																															case 58:
																																goto IL_0521;
																															case 90:
																																goto IL_052b;
																															case 28:
																																goto IL_0539;
																															case 91:
																																goto IL_054c;
																															case 5:
																																goto IL_0560;
																															case 24:
																															case 95:
																																goto IL_0573;
																															case 27:
																																goto IL_057e;
																															case 20:
																															case 29:
																																goto IL_0589;
																															case 100:
																																goto IL_05a5;
																															case 42:
																																goto IL_05b3;
																															case 34:
																																goto IL_05c1;
																															case 8:
																															case 9:
																															case 16:
																															case 22:
																															case 26:
																															case 35:
																															case 37:
																															case 46:
																															case 50:
																															case 60:
																															case 65:
																															case 84:
																															case 85:
																															case 86:
																															case 93:
																															case 94:
																																goto end_IL_0237;
																															case 21:
																																goto IL_0604;
																															case 77:
																																goto IL_0612;
																															case 53:
																																goto IL_0620;
																															case 0:
																															case 38:
																															case 39:
																															case 51:
																															case 68:
																															case 73:
																															case 78:
																															case 83:
																															case 96:
																															case 98:
																															case 99:
																																goto end_IL_01c3;
																															case 52:
																																goto end_IL_062e;
																															case 31:
																																goto end_IL_0641;
																															case 25:
																																goto end_IL_064b;
																															case 19:
																																goto end_IL_0656;
																															case 101:
																																goto end_IL_0674;
																															case 70:
																															case 92:
																																goto end_IL_0689;
																															case 30:
																																goto end_IL_0699;
																															case 17:
																															case 64:
																																goto end_IL_06b2;
																															case 10:
																																goto end_IL_06c2;
																															case 11:
																																goto end_IL_06db;
																															case 2:
																															case 59:
																																goto IL_06f6;
																															}
																															continue;
																														}
																														num5--;
																														break;
																														continue;
																														end_IL_01c3:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto end_IL_0291;
																											continue;
																											end_IL_0237:
																											break;
																											IL_0237:;
																										}
																										break;
																										IL_0247:;
																									}
																									break;
																								}
																								goto IL_04d2;
																								IL_05c1:
																								ptr2 += 8;
																								goto end_IL_0291;
																								IL_04d2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_05a5;
																								IL_05a5:
																								array[num5] = 0;
																								goto IL_05b3;
																								IL_05b3:
																								num5++;
																								goto IL_05c1;
																							}
																							break;
																						}
																						goto IL_02cf;
																						IL_057e:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0589;
																						IL_02cf:
																						if (8 >= b)
																						{
																							goto IL_02dd;
																						}
																						goto IL_0573;
																						IL_02dd:
																						if (8 > b)
																						{
																							break;
																						}
																						num = 75;
																						goto IL_02f4;
																						IL_0589:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0291;
																						IL_02f4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0334;
																						IL_0334:
																						array[num5 - 2] = 0;
																						goto IL_0348;
																						IL_0348:
																						num5--;
																						goto end_IL_0291;
																						IL_0573:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_057e;
																					}
																					break;
																				}
																				goto IL_02bc;
																				IL_0539:
																				ptr2 += 8;
																				goto end_IL_0291;
																				IL_02bc:
																				if (5 > b)
																				{
																					goto IL_035b;
																				}
																				goto IL_04f0;
																				IL_035b:
																				if (2 < b)
																				{
																					goto IL_0369;
																				}
																				goto IL_0461;
																				IL_0369:
																				if (3 >= b)
																				{
																					goto IL_0374;
																				}
																				goto IL_03cc;
																				IL_0374:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0382;
																				IL_0382:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03ab;
																				IL_03ab:
																				ptr2 += 8;
																				goto IL_03b9;
																				IL_03b9:
																				num5--;
																				goto end_IL_0291;
																				IL_03cc:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_03da;
																				IL_03da:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_03e8;
																				IL_03e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0428;
																				IL_0428:
																				array[num5 - 2] = 0;
																				num = 40;
																				goto IL_0445;
																				IL_0445:
																				num5--;
																				num = 98;
																				goto end_IL_0291;
																				IL_0461:
																				if (2 <= b)
																				{
																					goto IL_046c;
																				}
																				goto IL_04b1;
																				IL_046c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_054c;
																				IL_054c:
																				array[num5 - 2] = 0;
																				goto IL_0560;
																				IL_0560:
																				num5--;
																				goto end_IL_0291;
																				IL_04b1:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_04bf;
																				IL_04bf:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_04f0:
																				array[num5] = 0;
																				goto IL_04fe;
																				IL_04fe:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0521;
																				IL_0521:
																				array2[num5] = null;
																				goto IL_052b;
																				IL_052b:
																				num5++;
																				goto IL_0539;
																			}
																			break;
																			IL_0281:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0604;
																	IL_0620:
																	ptr2 += 8;
																	break;
																	IL_0612:
																	num5++;
																	goto IL_0620;
																	IL_0604:
																	array[num5] = 0;
																	goto IL_0612;
																	continue;
																	end_IL_0291:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06f6;
													IL_06f6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062e:
													break;
												}
												continue;
												end_IL_0641:
												break;
											}
											continue;
											end_IL_064b:
											break;
										}
										continue;
										end_IL_0656:
										break;
									}
									continue;
									end_IL_0674:
									break;
								}
								continue;
								end_IL_0689:
								break;
							}
							continue;
							end_IL_0699:
							break;
						}
						continue;
						end_IL_06b2:
						break;
					}
					continue;
					end_IL_06c2:
					break;
				}
				continue;
				end_IL_06db:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_0, int int_1)
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref addFirstChanceExceptiongetContentType.CollectionCountDomainIdentity);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02e3:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_02c6:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02b9:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_02a9:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0299:
																										if (7 < b)
																										{
																											while (8 >= b)
																											{
																												while (8 <= b)
																												{
																													while (true)
																													{
																														IL_022e:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														num = 131;
																														while (true)
																														{
																															if (num != 131)
																															{
																																if (num != 1112)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 109:
																																case 114:
																																	goto IL_022e;
																																case 124:
																																	goto IL_0279;
																																case 40:
																																	goto IL_0289;
																																case 68:
																																	goto IL_0299;
																																case 48:
																																	goto end_IL_021b;
																																case 94:
																																	goto IL_02b9;
																																case 8:
																																	goto IL_02c6;
																																case 110:
																																	goto IL_02d3;
																																case 18:
																																	goto IL_02e3;
																																case 97:
																																	goto end_IL_02e3;
																																case 0:
																																case 25:
																																	goto end_IL_02f3;
																																case 47:
																																case 57:
																																	goto IL_030e;
																																case 20:
																																	goto IL_031c;
																																case 32:
																																case 52:
																																	goto IL_032a;
																																case 74:
																																	goto IL_0346;
																																case 33:
																																case 41:
																																	goto IL_0354;
																																case 12:
																																	goto IL_0394;
																																case 29:
																																case 85:
																																	goto IL_03ad;
																																case 15:
																																	goto IL_03c1;
																																case 84:
																																case 89:
																																	goto IL_0417;
																																case 7:
																																case 34:
																																	goto IL_0422;
																																case 49:
																																	goto IL_0439;
																																case 62:
																																	goto IL_044c;
																																case 2:
																																case 70:
																																	goto IL_045a;
																																case 45:
																																	goto IL_0465;
																																case 66:
																																	goto IL_0478;
																																case 100:
																																	goto IL_048b;
																																case 19:
																																	goto IL_0499;
																																case 103:
																																case 105:
																																	goto IL_04ac;
																																case 71:
																																	goto IL_04ba;
																																case 10:
																																case 37:
																																	goto IL_04c8;
																																case 101:
																																case 111:
																																	goto IL_04e4;
																																case 69:
																																case 112:
																																	goto IL_0529;
																																case 88:
																																	goto IL_0552;
																																case 17:
																																	goto IL_0560;
																																case 113:
																																	goto IL_0573;
																																case 43:
																																case 87:
																																	goto IL_0581;
																																case 91:
																																	goto IL_059a;
																																case 83:
																																	goto IL_05a8;
																																case 59:
																																	goto IL_05b6;
																																case 116:
																																	goto IL_05c9;
																																case 28:
																																	goto IL_05d7;
																																case 5:
																																case 86:
																																	goto IL_05e5;
																																case 107:
																																	goto IL_05f3;
																																case 96:
																																	goto IL_0616;
																																case 46:
																																	goto IL_0620;
																																case 51:
																																	goto IL_062e;
																																case 118:
																																	goto IL_0641;
																																case 58:
																																	goto IL_0655;
																																case 121:
																																	goto IL_0668;
																																case 22:
																																case 67:
																																	goto IL_0673;
																																case 64:
																																	goto IL_06b3;
																																case 115:
																																	goto IL_06c7;
																																case 123:
																																	goto IL_06e5;
																																case 106:
																																	goto IL_0709;
																																case 3:
																																case 4:
																																case 9:
																																case 13:
																																case 16:
																																case 21:
																																case 23:
																																case 30:
																																case 31:
																																case 38:
																																case 39:
																																case 53:
																																case 54:
																																case 55:
																																case 56:
																																case 63:
																																case 65:
																																case 72:
																																case 82:
																																case 90:
																																case 95:
																																case 102:
																																case 104:
																																case 117:
																																	goto end_IL_0279;
																																case 6:
																																	goto IL_073c;
																																case 81:
																																	goto IL_074a;
																																case 27:
																																	goto IL_0758;
																																case 1:
																																case 11:
																																case 26:
																																case 35:
																																case 42:
																																case 79:
																																case 80:
																																case 92:
																																case 99:
																																case 108:
																																case 119:
																																case 120:
																																case 122:
																																	goto end_IL_0303;
																																case 78:
																																	goto end_IL_0766;
																																case 75:
																																	goto end_IL_0779;
																																case 50:
																																	goto end_IL_0783;
																																case 93:
																																	goto end_IL_078e;
																																case 98:
																																	goto end_IL_07a3;
																																case 24:
																																case 73:
																																	goto end_IL_07b8;
																																case 14:
																																	goto end_IL_07c8;
																																case 60:
																																case 61:
																																	goto end_IL_07d8;
																																case 76:
																																	goto end_IL_07e8;
																																case 77:
																																	goto end_IL_07f8;
																																case 36:
																																case 44:
																																	goto IL_0813;
																																}
																																continue;
																															}
																															array[num5 - 2] = 0;
																															goto IL_0709;
																															IL_0709:
																															num5--;
																															goto end_IL_0303;
																															continue;
																															end_IL_021b:
																															break;
																														}
																														break;
																													}
																													goto IL_02a9;
																													continue;
																													end_IL_0279:
																													break;
																													IL_0279:;
																												}
																												break;
																												IL_0289:;
																											}
																											break;
																										}
																										goto IL_0573;
																										IL_05b6:
																										ptr2 += 8;
																										goto end_IL_0303;
																										IL_0573:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0581;
																										IL_0581:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_059a;
																										IL_059a:
																										array[num5] = 0;
																										goto IL_05a8;
																										IL_05a8:
																										num5++;
																										goto IL_05b6;
																									}
																									break;
																								}
																								goto IL_03ad;
																								IL_0499:
																								ptr2 += 8;
																								goto end_IL_0303;
																								IL_03ad:
																								array[num5 - 2] = 0;
																								goto IL_03c1;
																								IL_03c1:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getKeyCharHostEvidence[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_048b;
																								IL_048b:
																								num5--;
																								goto IL_0499;
																							}
																							break;
																						}
																						goto IL_030e;
																						IL_04c8:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0303;
																						IL_030e:
																						if (10 >= b)
																						{
																							goto IL_031c;
																						}
																						goto IL_04ac;
																						IL_031c:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_032a;
																						IL_032a:
																						num5--;
																						num = 42;
																						goto end_IL_0303;
																						IL_04ac:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_04ba;
																						IL_04ba:
																						if (11 > b)
																						{
																							break;
																						}
																						goto IL_04c8;
																					}
																					break;
																				}
																				goto IL_0346;
																				IL_0529:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0552;
																				IL_0346:
																				if (6 <= b)
																				{
																					goto IL_0354;
																				}
																				goto IL_0417;
																				IL_0354:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0394;
																				IL_0394:
																				array[num5 - 2] = 0;
																				goto IL_06e5;
																				IL_06e5:
																				num5--;
																				goto end_IL_0303;
																				IL_0417:
																				if (3 < b)
																				{
																					goto IL_0422;
																				}
																				goto IL_044c;
																				IL_0422:
																				if (4 >= b)
																				{
																					num = 49;
																					goto IL_0439;
																				}
																				goto IL_05c9;
																				IL_0552:
																				ptr2 += 8;
																				goto IL_0560;
																				IL_0439:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_04e4;
																				IL_04e4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0641;
																				IL_0641:
																				array[num5 - 2] = 0;
																				goto IL_0655;
																				IL_0655:
																				num5--;
																				goto end_IL_0303;
																				IL_05c9:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_05d7;
																				IL_05d7:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_05e5;
																				IL_05e5:
																				array[num5] = 0;
																				goto IL_05f3;
																				IL_05f3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0616;
																				IL_0616:
																				array2[num5] = null;
																				goto IL_0620;
																				IL_0620:
																				num5++;
																				goto IL_062e;
																				IL_062e:
																				ptr2 += 8;
																				goto end_IL_0303;
																				IL_044c:
																				if (3 > b)
																				{
																					goto IL_045a;
																				}
																				goto IL_0529;
																				IL_045a:
																				if (1 >= b)
																				{
																					goto IL_0465;
																				}
																				goto IL_0478;
																				IL_0465:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0478:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0668;
																				IL_0668:
																				if (2 > b)
																				{
																					num = 16;
																					break;
																				}
																				goto IL_0673;
																				IL_0673:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06b3;
																				IL_06b3:
																				array[num5 - 2] = 0;
																				goto IL_06c7;
																				IL_06c7:
																				num5--;
																				goto end_IL_0303;
																				IL_0560:
																				num5--;
																				goto end_IL_0303;
																			}
																			break;
																			IL_02d3:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_073c;
																	IL_0758:
																	ptr2 += 8;
																	goto end_IL_0303;
																	IL_074a:
																	num5++;
																	goto IL_0758;
																	IL_073c:
																	array[num5] = 0;
																	goto IL_074a;
																	continue;
																	end_IL_02e3:
																	break;
																}
																continue;
																end_IL_02f3:
																break;
															}
															continue;
															end_IL_0303:
															break;
														}
														continue;
													}
													goto IL_0813;
													IL_0813:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0766:
													break;
												}
												continue;
												end_IL_0779:
												break;
											}
											continue;
											end_IL_0783:
											break;
										}
										continue;
										end_IL_078e:
										break;
									}
									continue;
									end_IL_07a3:
									break;
								}
								continue;
								end_IL_07b8:
								break;
							}
							continue;
							end_IL_07c8:
							break;
						}
						continue;
						end_IL_07d8:
						break;
					}
					continue;
					end_IL_07e8:
					break;
				}
				continue;
				end_IL_07f8:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_0)
	{
		int num = 69;
		byte* ptr = default(byte*);
		int num4 = default(int);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								num = 49;
								while (true)
								{
									array3[0] = int_0;
									num = 122;
									while (true)
									{
										if (num != 122)
										{
											if (num != 1103)
											{
												goto IL_06f5;
											}
											switch (num)
											{
											case 49:
												goto end_IL_01f7;
											case 10:
												goto end_IL_020a;
											case 6:
											case 19:
												goto end_IL_0228;
											case 41:
												goto end_IL_0241;
											case 73:
											case 75:
												goto end_IL_0251;
											case 68:
												goto end_IL_0261;
											case 69:
												goto end_IL_0271;
											case 57:
												goto IL_029e;
											case 0:
											case 24:
											case 32:
											case 34:
											case 35:
											case 42:
											case 45:
											case 53:
											case 62:
											case 64:
											case 82:
											case 83:
											case 87:
											case 115:
												goto IL_02a6;
											case 102:
											case 104:
												goto IL_02b6;
											case 89:
												goto IL_02bf;
											case 108:
												goto IL_02cd;
											case 110:
												goto IL_02db;
											case 55:
												goto IL_02e9;
											case 26:
											case 56:
												goto IL_02f7;
											case 9:
												goto IL_0305;
											case 44:
												goto IL_0313;
											case 1:
												goto IL_031e;
											case 72:
											case 74:
												goto IL_032c;
											case 13:
												goto IL_036c;
											case 98:
												goto IL_0380;
											case 47:
												goto IL_0393;
											case 78:
												goto IL_03a1;
											case 22:
											case 112:
												goto IL_03af;
											case 79:
												goto IL_03d2;
											case 91:
												goto IL_03e0;
											case 77:
												goto IL_03ee;
											case 59:
											case 81:
												goto IL_0401;
											case 70:
												goto IL_046c;
											case 93:
												goto IL_047f;
											case 28:
											case 58:
												goto IL_048a;
											case 60:
												goto IL_0498;
											case 113:
												goto IL_04ab;
											case 52:
											case 66:
												goto IL_04b9;
											case 48:
												goto IL_04d5;
											case 4:
											case 46:
												goto IL_04e3;
											case 12:
											case 61:
												goto IL_04f1;
											case 8:
												goto IL_04fc;
											case 85:
												goto IL_050f;
											case 65:
												goto IL_051d;
											case 15:
											case 95:
												goto IL_0528;
											case 40:
												goto IL_0536;
											case 2:
												goto IL_0559;
											case 109:
												goto IL_0563;
											case 36:
												goto IL_0571;
											case 67:
												goto IL_0592;
											case 20:
											case 86:
												goto IL_059d;
											case 7:
											case 54:
												goto IL_05be;
											case 94:
												goto IL_05c9;
											case 23:
											case 25:
												goto IL_05d7;
											case 37:
												goto IL_05f0;
											case 30:
												goto IL_0607;
											case 71:
												goto IL_0615;
											case 103:
												goto IL_0628;
											case 5:
												goto IL_0636;
											case 11:
											case 99:
												goto IL_0644;
											case 50:
												goto IL_066d;
											case 27:
												goto IL_067b;
											case 33:
											case 38:
												goto IL_068e;
											case 29:
												goto IL_06ce;
											case 114:
												goto IL_06e2;
											case 14:
											case 16:
											case 17:
											case 18:
											case 21:
											case 31:
											case 39:
											case 43:
											case 51:
											case 63:
											case 80:
											case 84:
											case 88:
											case 90:
											case 92:
											case 96:
											case 97:
											case 100:
											case 101:
											case 105:
											case 106:
											case 107:
											case 111:
												goto IL_06f5;
											case 3:
											case 76:
												goto IL_070d;
											}
											continue;
										}
										ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResourceManagerAddingCultureFromConfigFileMulOvf.IgnoreCasePrivilegeNotHeldException);
										num = 57;
										goto IL_029e;
										IL_067b:
										num4--;
										goto IL_02a6;
										IL_06ce:
										array[num4 - 2] = 0;
										goto IL_06e2;
										IL_068e:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										goto IL_06ce;
										IL_029e:
										ptr2 = ptr;
										goto IL_02a6;
										IL_02a6:
										if (num5 != 1)
										{
											goto IL_02b6;
										}
										goto IL_070d;
										IL_070d:
										return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										IL_02b6:
										b = *ptr2;
										goto IL_02bf;
										IL_02bf:
										ptr2++;
										goto IL_02cd;
										IL_02cd:
										if (b >= 1)
										{
											goto IL_02db;
										}
										goto IL_06f5;
										IL_02db:
										if (b <= 11)
										{
											goto IL_02e9;
										}
										goto IL_06f5;
										IL_02e9:
										if (6 < b)
										{
											goto IL_02f7;
										}
										goto IL_04d5;
										IL_02f7:
										if (9 >= b)
										{
											goto IL_0305;
										}
										goto IL_047f;
										IL_0305:
										if (9 > b)
										{
											goto IL_0313;
										}
										goto IL_0401;
										IL_0313:
										if (7 >= b)
										{
											goto IL_031e;
										}
										goto IL_0393;
										IL_031e:
										if (7 <= b)
										{
											goto IL_032c;
										}
										goto IL_06f5;
										IL_032c:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										goto IL_036c;
										IL_036c:
										array[num4 - 2] = 0;
										goto IL_0380;
										IL_0380:
										num4--;
										goto IL_02a6;
										IL_0393:
										if (8 >= b)
										{
											goto IL_03a1;
										}
										goto IL_06f5;
										IL_03a1:
										if (8 <= b)
										{
											goto IL_03af;
										}
										goto IL_06f5;
										IL_03af:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
										goto IL_03d2;
										IL_03d2:
										array[num4] = 0;
										goto IL_03e0;
										IL_03e0:
										num4++;
										goto IL_03ee;
										IL_03ee:
										ptr2 += 8;
										goto IL_02a6;
										IL_0401:
										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
										num = 70;
										goto IL_046c;
										IL_046c:
										num4 -= 2;
										goto IL_02a6;
										IL_047f:
										if (10 < b)
										{
											goto IL_048a;
										}
										goto IL_04ab;
										IL_048a:
										if (11 >= b)
										{
											goto IL_0498;
										}
										goto IL_06f5;
										IL_0498:
										if (11 > b)
										{
										}
										goto IL_06f5;
										IL_04ab:
										if (10 <= b)
										{
											goto IL_04b9;
										}
										goto IL_06f5;
										IL_04b9:
										byte* num6 = ptr2;
										num5 = 1;
										ptr2 = num6 + -200;
										goto IL_02a6;
										IL_04d5:
										if (6 > b)
										{
											goto IL_04e3;
										}
										goto IL_068e;
										IL_04e3:
										if (3 < b)
										{
											goto IL_04f1;
										}
										goto IL_0592;
										IL_04f1:
										if (4 >= b)
										{
											goto IL_04fc;
										}
										goto IL_050f;
										IL_04fc:
										if (4 <= b)
										{
											goto IL_02a6;
										}
										goto IL_06f5;
										IL_050f:
										if (5 >= b)
										{
											goto IL_051d;
										}
										goto IL_06f5;
										IL_051d:
										if (5 <= b)
										{
											goto IL_0528;
										}
										num = 18;
										goto IL_06f5;
										IL_0528:
										array[num4] = 0;
										goto IL_0536;
										IL_0536:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
										goto IL_0559;
										IL_0559:
										array2[num4] = null;
										goto IL_0563;
										IL_0563:
										num4++;
										goto IL_0571;
										IL_0571:
										ptr2 += 8;
										goto IL_02a6;
										IL_06e2:
										num4--;
										goto IL_02a6;
										IL_0592:
										if (3 <= b)
										{
											goto IL_059d;
										}
										num = 54;
										goto IL_05be;
										IL_059d:
										ptr2 = ptr + *(int*)(ptr2 + num3);
										goto IL_02a6;
										IL_06f5:
										ptr2 = ptr + *(int*)(ptr2 + num3);
										goto IL_02a6;
										IL_05be:
										if (1 >= b)
										{
											goto IL_05c9;
										}
										goto IL_0628;
										IL_05c9:
										if (1 <= b)
										{
											goto IL_05d7;
										}
										goto IL_06f5;
										IL_05d7:
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
										goto IL_05f0;
										IL_05f0:
										array[num4] = 0;
										num = 30;
										goto IL_0607;
										IL_0607:
										num4++;
										goto IL_0615;
										IL_0615:
										ptr2 += 8;
										goto IL_02a6;
										IL_0628:
										if (2 >= b)
										{
											goto IL_0636;
										}
										goto IL_06f5;
										IL_0636:
										if (2 <= b)
										{
											goto IL_0644;
										}
										goto IL_06f5;
										IL_0644:
										ref int reference = ref array3[*(int*)(ptr2 + num3)];
										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
										goto IL_066d;
										IL_066d:
										ptr2 += 8;
										goto IL_067b;
										continue;
										end_IL_01f7:
										break;
									}
									continue;
									end_IL_020a:
									break;
								}
								continue;
								end_IL_0228:
								break;
							}
							continue;
							end_IL_0241:
							break;
						}
						continue;
						end_IL_0251:
						break;
					}
					continue;
					end_IL_0261:
					break;
				}
				continue;
				end_IL_0271:
				break;
			}
		}
	}

	private static int smethod_3(int int_0, int int_1)
	{
		int num = int_0;
		int num2 = int_1;
		if (num <= num2)
		{
			num = int_1;
			num2 = int_0;
			return num - num2;
		}
		num = int_0;
		num2 = int_1;
		return num - num2;
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 34;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_0;
									num = 73;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ResumeStringExpressionSet.IconFileISecurityElementFactory);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_024c:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			num = 131;
																			while (true)
																			{
																				if (num != 131)
																				{
																					if (num != 1112)
																					{
																						goto IL_053b;
																					}
																					switch (num)
																					{
																					case 81:
																						goto end_IL_0229;
																					case 113:
																						goto IL_024c;
																					case 51:
																						goto end_IL_024c;
																					case 38:
																					case 106:
																						goto end_IL_025c;
																					case 84:
																						goto IL_0285;
																					case 57:
																					case 110:
																						goto IL_0293;
																					case 10:
																					case 85:
																						goto IL_02a1;
																					case 50:
																					case 66:
																						goto IL_02ac;
																					case 116:
																						goto IL_02ba;
																					case 86:
																					case 97:
																						goto IL_02c8;
																					case 2:
																						goto IL_02e0;
																					case 11:
																					case 27:
																						goto IL_02eb;
																					case 37:
																						goto IL_0314;
																					case 24:
																						goto IL_0322;
																					case 26:
																						goto IL_0343;
																					case 68:
																					case 101:
																						goto IL_0351;
																					case 40:
																						goto IL_035c;
																					case 54:
																						goto IL_036f;
																					case 82:
																						goto IL_037d;
																					case 104:
																					case 123:
																						goto IL_038b;
																					case 0:
																						goto IL_03f9;
																					case 91:
																					case 94:
																						goto IL_0415;
																					case 30:
																						goto IL_0455;
																					case 89:
																						goto IL_0469;
																					case 61:
																						goto IL_047c;
																					case 115:
																						goto IL_048a;
																					case 18:
																					case 75:
																						goto IL_0498;
																					case 83:
																						goto IL_04a3;
																					case 74:
																					case 117:
																						goto IL_04b1;
																					case 60:
																						goto IL_04c8;
																					case 32:
																						goto IL_04eb;
																					case 5:
																						goto IL_04f5;
																					case 7:
																						goto IL_0503;
																					case 29:
																						goto IL_0516;
																					case 44:
																						goto IL_0524;
																					case 20:
																					case 59:
																						goto IL_053b;
																					case 99:
																						goto IL_0554;
																					case 4:
																						goto IL_0562;
																					case 6:
																						goto IL_0570;
																					case 8:
																					case 124:
																						goto IL_0583;
																					case 55:
																						goto IL_05c3;
																					case 76:
																						goto IL_05d7;
																					case 47:
																						goto IL_05ea;
																					case 107:
																						goto IL_05f8;
																					case 62:
																					case 64:
																						goto IL_0606;
																					case 9:
																						goto IL_0614;
																					case 80:
																					case 102:
																						goto IL_0622;
																					case 52:
																						goto IL_0636;
																					case 45:
																						goto IL_068a;
																					case 31:
																						goto IL_0698;
																					case 36:
																					case 56:
																						goto IL_06ab;
																					case 3:
																						goto IL_06be;
																					case 111:
																						goto IL_06c9;
																					case 17:
																					case 93:
																						goto IL_06d4;
																					case 12:
																					case 15:
																					case 22:
																					case 43:
																					case 46:
																					case 53:
																					case 58:
																					case 65:
																					case 67:
																					case 71:
																					case 78:
																					case 88:
																					case 90:
																					case 95:
																					case 96:
																					case 98:
																					case 103:
																					case 114:
																					case 118:
																					case 119:
																					case 121:
																					case 122:
																						goto end_IL_0239;
																					case 14:
																						goto IL_0719;
																					case 49:
																						goto IL_0727;
																					case 108:
																						goto IL_0735;
																					case 16:
																					case 19:
																					case 21:
																					case 23:
																					case 25:
																					case 35:
																					case 39:
																					case 41:
																					case 48:
																					case 63:
																					case 69:
																					case 70:
																					case 72:
																					case 105:
																					case 112:
																						goto end_IL_026c;
																					case 1:
																						goto end_IL_0743;
																					case 100:
																						goto end_IL_0756;
																					case 73:
																						goto end_IL_0760;
																					case 92:
																						goto end_IL_076b;
																					case 120:
																						goto end_IL_0780;
																					case 77:
																					case 87:
																						goto end_IL_079e;
																					case 79:
																						goto end_IL_07ae;
																					case 13:
																					case 28:
																						goto end_IL_07be;
																					case 33:
																						goto end_IL_07ce;
																					case 34:
																						goto end_IL_07de;
																					case 42:
																					case 109:
																						goto IL_07f9;
																					}
																					continue;
																				}
																				if (6 >= b)
																				{
																					goto IL_0285;
																				}
																				goto IL_047c;
																				IL_0698:
																				ptr2 += 8;
																				goto end_IL_026c;
																				IL_06be:
																				if (12 < b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_06c9;
																				IL_06ab:
																				num5--;
																				goto end_IL_026c;
																				IL_0285:
																				if (6 <= b)
																				{
																					goto end_IL_026c;
																				}
																				goto IL_0293;
																				IL_0293:
																				if (3 < b)
																				{
																					goto IL_02a1;
																				}
																				goto IL_0343;
																				IL_02a1:
																				if (4 < b)
																				{
																					goto IL_02ac;
																				}
																				goto IL_02e0;
																				IL_02ac:
																				if (5 < b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_02ba;
																				IL_02ba:
																				if (5 > b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_02c8;
																				IL_02c8:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_026c;
																				IL_02e0:
																				if (4 > b)
																				{
																					num = 46;
																					goto end_IL_0239;
																				}
																				goto IL_02eb;
																				IL_02eb:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0314;
																				IL_0314:
																				ptr2 += 8;
																				goto IL_0322;
																				IL_0322:
																				num5--;
																				goto end_IL_026c;
																				IL_06c9:
																				if (12 > b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_06d4;
																				IL_0343:
																				if (3 > b)
																				{
																					goto IL_0351;
																				}
																				goto IL_0415;
																				IL_0351:
																				if (1 >= b)
																				{
																					goto IL_035c;
																				}
																				goto IL_036f;
																				IL_035c:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0239;
																				IL_036f:
																				if (2 < b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_037d;
																				IL_037d:
																				if (2 > b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_038b;
																				IL_038b:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_03f9;
																				IL_03f9:
																				num5 -= 2;
																				num = 25;
																				goto end_IL_026c;
																				IL_0415:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0455;
																				IL_0455:
																				array[num5 - 2] = 0;
																				goto IL_0469;
																				IL_0469:
																				num5--;
																				goto end_IL_026c;
																				IL_047c:
																				if (9 >= b)
																				{
																					goto IL_048a;
																				}
																				goto IL_05ea;
																				IL_048a:
																				if (9 > b)
																				{
																					goto IL_0498;
																				}
																				goto IL_0583;
																				IL_0498:
																				if (7 >= b)
																				{
																					goto IL_04a3;
																				}
																				goto IL_0516;
																				IL_04a3:
																				if (7 > b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_04b1;
																				IL_04b1:
																				array[num5] = 0;
																				num = 60;
																				goto IL_04c8;
																				IL_04c8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04eb;
																				IL_04eb:
																				array2[num5] = null;
																				goto IL_04f5;
																				IL_04f5:
																				num5++;
																				goto IL_0503;
																				IL_0503:
																				ptr2 += 8;
																				goto end_IL_026c;
																				IL_0516:
																				if (8 < b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_0524;
																				IL_0524:
																				if (8 > b)
																				{
																					goto end_IL_0239;
																				}
																				num = 59;
																				goto IL_053b;
																				IL_06d4:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 69;
																				goto end_IL_026c;
																				IL_053b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0554;
																				IL_0554:
																				array[num5] = 0;
																				goto IL_0562;
																				IL_0562:
																				num5++;
																				goto IL_0570;
																				IL_0570:
																				ptr2 += 8;
																				goto end_IL_026c;
																				IL_0583:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05c3;
																				IL_05c3:
																				array[num5 - 2] = 0;
																				goto IL_05d7;
																				IL_05d7:
																				num5--;
																				goto end_IL_026c;
																				IL_05ea:
																				if (11 >= b)
																				{
																					goto IL_05f8;
																				}
																				goto IL_06be;
																				IL_05f8:
																				if (11 > b)
																				{
																					goto IL_0606;
																				}
																				goto IL_06ab;
																				IL_0606:
																				if (10 < b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_0614;
																				IL_0614:
																				if (10 > b)
																				{
																					goto end_IL_0239;
																				}
																				goto IL_0622;
																				IL_0622:
																				array[num5 - 2] = 0;
																				goto IL_0636;
																				IL_0636:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)RegistryKeyPermissionCheckVerifyHash[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_068a;
																				IL_068a:
																				num5--;
																				goto IL_0698;
																				continue;
																				end_IL_0229:
																				break;
																			}
																			continue;
																			end_IL_0239:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0719;
																	IL_0735:
																	ptr2 += 8;
																	goto end_IL_026c;
																	IL_0727:
																	num5++;
																	goto IL_0735;
																	IL_0719:
																	array[num5] = 0;
																	goto IL_0727;
																	continue;
																	end_IL_024c:
																	break;
																}
																continue;
																end_IL_025c:
																break;
															}
															continue;
															end_IL_026c:
															break;
														}
														continue;
													}
													goto IL_07f9;
													IL_07f9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0743:
													break;
												}
												continue;
												end_IL_0756:
												break;
											}
											continue;
											end_IL_0760:
											break;
										}
										continue;
										end_IL_076b:
										break;
									}
									continue;
									end_IL_0780:
									break;
								}
								continue;
								end_IL_079e:
								break;
							}
							continue;
							end_IL_07ae:
							break;
						}
						continue;
						end_IL_07be:
						break;
					}
					continue;
					end_IL_07ce:
					break;
				}
				continue;
				end_IL_07de:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0)
	{
		int num = 38;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 37;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StartinggetGenericParameterAttributes.PayloadReadWriteParameters);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 98;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0298:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0278:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_026b:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_025b:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_024b:
																										if (6 >= b)
																										{
																											while (6 <= b)
																											{
																												while (true)
																												{
																													IL_01f9:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_01da:
																														array[num5 - 2] = 0;
																														num = 110;
																														while (true)
																														{
																															if (num != 110)
																															{
																																if (num != 1091)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 8:
																																	goto IL_01da;
																																case 20:
																																case 78:
																																	goto IL_01f9;
																																case 19:
																																	goto IL_023b;
																																case 57:
																																	goto IL_024b;
																																case 76:
																																	goto IL_025b;
																																case 33:
																																case 80:
																																	goto IL_026b;
																																case 97:
																																	goto end_IL_01c7;
																																case 65:
																																	goto IL_0288;
																																case 62:
																																	goto IL_0298;
																																case 102:
																																	goto end_IL_0298;
																																case 47:
																																case 49:
																																	goto end_IL_02a8;
																																case 18:
																																case 86:
																																	goto IL_02c3;
																																case 24:
																																case 25:
																																	goto IL_02ce;
																																case 4:
																																	goto IL_02dc;
																																case 5:
																																	goto IL_02ef;
																																case 6:
																																case 95:
																																	goto IL_02fd;
																																case 61:
																																case 96:
																																	goto IL_0319;
																																case 54:
																																	goto IL_037b;
																																case 32:
																																	goto IL_03a1;
																																case 84:
																																	goto IL_03ac;
																																case 23:
																																case 51:
																																	goto IL_03ba;
																																case 44:
																																	goto IL_03dd;
																																case 14:
																																	goto IL_03eb;
																																case 101:
																																	goto IL_03f9;
																																case 26:
																																	goto IL_041a;
																																case 40:
																																case 46:
																																	goto IL_0428;
																																case 21:
																																	goto IL_0436;
																																case 69:
																																case 94:
																																	goto IL_0441;
																																case 31:
																																	goto IL_0473;
																																case 50:
																																	goto IL_048a;
																																case 56:
																																	goto IL_049d;
																																case 2:
																																	goto IL_04ab;
																																case 71:
																																case 90:
																																	goto IL_04b9;
																																case 9:
																																	goto IL_04d2;
																																case 93:
																																	goto IL_04e0;
																																case 55:
																																	goto IL_04ee;
																																case 15:
																																	goto IL_0501;
																																case 91:
																																	goto IL_050c;
																																case 52:
																																case 70:
																																	goto IL_051a;
																																case 30:
																																	goto IL_0532;
																																case 7:
																																	goto IL_053d;
																																case 35:
																																case 74:
																																	goto IL_054a;
																																case 66:
																																	goto IL_0558;
																																case 85:
																																	goto IL_057b;
																																case 88:
																																	goto IL_0585;
																																case 53:
																																	goto IL_0593;
																																case 1:
																																case 3:
																																case 12:
																																case 13:
																																case 16:
																																case 17:
																																case 29:
																																case 42:
																																case 43:
																																case 45:
																																case 63:
																																case 64:
																																case 67:
																																case 72:
																																case 73:
																																case 77:
																																case 81:
																																case 82:
																																case 99:
																																	goto end_IL_023b;
																																case 0:
																																case 11:
																																case 27:
																																case 28:
																																case 48:
																																case 59:
																																case 79:
																																case 83:
																																case 92:
																																case 98:
																																case 100:
																																case 103:
																																	goto end_IL_02b8;
																																case 75:
																																	goto end_IL_05bf;
																																case 68:
																																	goto end_IL_05d2;
																																case 87:
																																	goto end_IL_05dd;
																																case 39:
																																	goto end_IL_05e7;
																																case 58:
																																	goto end_IL_05f2;
																																case 34:
																																case 89:
																																	goto end_IL_0607;
																																case 41:
																																	goto end_IL_0617;
																																case 10:
																																case 36:
																																	goto end_IL_0627;
																																case 37:
																																	goto end_IL_0637;
																																case 38:
																																	goto end_IL_0647;
																																case 22:
																																case 60:
																																	goto IL_066b;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_02b8;
																															continue;
																															end_IL_01c7:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0278;
																												continue;
																												end_IL_023b:
																												break;
																												IL_023b:;
																											}
																											break;
																										}
																										goto IL_03a1;
																										IL_03f9:
																										ptr2 += 8;
																										goto end_IL_02b8;
																										IL_03a1:
																										if (7 < b)
																										{
																											num = 64;
																											break;
																										}
																										goto IL_03ac;
																										IL_03ac:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_03ba;
																										IL_03ba:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_03dd;
																										IL_03dd:
																										array[num5] = 0;
																										goto IL_03eb;
																										IL_03eb:
																										num5++;
																										goto IL_03f9;
																									}
																									break;
																								}
																								goto IL_0319;
																								IL_037b:
																								num5 -= 2;
																								goto end_IL_02b8;
																								IL_0319:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_037b;
																							}
																							break;
																						}
																						goto IL_02c3;
																						IL_02fd:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02b8;
																						IL_02c3:
																						if (9 < b)
																						{
																							goto IL_02ce;
																						}
																						goto IL_02ef;
																						IL_02ce:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_02dc;
																						IL_02dc:
																						if (10 <= b)
																						{
																						}
																						break;
																						IL_02ef:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_02fd;
																					}
																					break;
																				}
																				goto IL_041a;
																				IL_0593:
																				ptr2 += 8;
																				goto end_IL_02b8;
																				IL_041a:
																				if (5 > b)
																				{
																					goto IL_0428;
																				}
																				goto IL_054a;
																				IL_0428:
																				if (2 >= b)
																				{
																					goto IL_0436;
																				}
																				goto IL_0501;
																				IL_0436:
																				if (2 <= b)
																				{
																					goto IL_0441;
																				}
																				goto IL_049d;
																				IL_0441:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 31;
																				goto IL_0473;
																				IL_0473:
																				ptr2 += 8;
																				num = 50;
																				goto IL_048a;
																				IL_048a:
																				num5--;
																				goto end_IL_02b8;
																				IL_049d:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_04ab;
																				IL_04ab:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_04b9;
																				IL_04b9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04d2;
																				IL_04d2:
																				array[num5] = 0;
																				goto IL_04e0;
																				IL_04e0:
																				num5++;
																				goto IL_04ee;
																				IL_04ee:
																				ptr2 += 8;
																				goto end_IL_02b8;
																				IL_0501:
																				if (3 >= b)
																				{
																					goto IL_050c;
																				}
																				goto IL_0532;
																				IL_050c:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_051a;
																				IL_051a:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02b8;
																				IL_0532:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_053d;
																				IL_053d:
																				if (4 > b)
																				{
																					break;
																				}
																				goto end_IL_02b8;
																				IL_054a:
																				array[num5] = 0;
																				goto IL_0558;
																				IL_0558:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_057b;
																				IL_057b:
																				array2[num5] = null;
																				goto IL_0585;
																				IL_0585:
																				num5++;
																				goto IL_0593;
																			}
																			break;
																			IL_0288:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 92;
																	goto end_IL_02b8;
																	continue;
																	end_IL_0298:
																	break;
																}
																continue;
																end_IL_02a8:
																break;
															}
															continue;
															end_IL_02b8:
															break;
														}
														continue;
													}
													goto IL_066b;
													IL_066b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05bf:
													break;
												}
												continue;
												end_IL_05d2:
												break;
											}
											continue;
											end_IL_05dd:
											break;
										}
										continue;
										end_IL_05e7:
										break;
									}
									continue;
									end_IL_05f2:
									break;
								}
								continue;
								end_IL_0607:
								break;
							}
							continue;
							end_IL_0617:
							break;
						}
						continue;
						end_IL_0627:
						break;
					}
					continue;
					end_IL_0637:
					break;
				}
				continue;
				end_IL_0647:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_0, int int_1)
	{
		int num = 45;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							num = 105;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreateIdentityPermissionCustomQueryInterfaceMode.MachineKeySetGetPrimaryInteropAssembly);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 66;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02f4:
															byte b = *ptr2;
															while (true)
															{
																IL_02e4:
																ptr2++;
																while (true)
																{
																	IL_02d4:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_02b4:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02a4:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0297:
																								if (9 <= b)
																								{
																									while (true)
																									{
																										IL_0255:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										while (true)
																										{
																											IL_023f:
																											array[num5 - 2] = 0;
																											while (true)
																											{
																												IL_0226:
																												num5--;
																												num = 129;
																												while (num != 129)
																												{
																													if (num != 1110)
																													{
																														goto IL_035c;
																													}
																													switch (num)
																													{
																													case 4:
																														goto IL_0226;
																													case 38:
																														goto IL_023f;
																													case 57:
																													case 103:
																														goto IL_0255;
																													case 110:
																														goto IL_0297;
																													case 40:
																													case 80:
																														goto IL_02a4;
																													case 109:
																														goto IL_02b4;
																													case 102:
																														goto IL_02c4;
																													case 53:
																														goto IL_02d4;
																													case 3:
																														goto IL_02e4;
																													case 14:
																													case 108:
																														goto IL_02f4;
																													case 46:
																													case 65:
																														goto IL_02ff;
																													case 15:
																														goto IL_030a;
																													case 117:
																													case 121:
																														goto IL_0321;
																													case 78:
																														goto IL_032f;
																													case 81:
																														goto IL_0352;
																													case 97:
																														goto IL_035c;
																													case 12:
																														goto IL_036a;
																													case 36:
																														goto IL_0386;
																													case 48:
																														goto IL_0394;
																													case 39:
																													case 60:
																														goto IL_03a2;
																													case 99:
																														goto IL_03bb;
																													case 96:
																														goto IL_03c9;
																													case 118:
																														goto IL_03d7;
																													case 75:
																														goto IL_03ea;
																													case 74:
																														goto IL_03f8;
																													case 22:
																														goto IL_0406;
																													case 64:
																														goto IL_0414;
																													case 62:
																													case 94:
																														goto IL_0422;
																													case 92:
																														goto IL_0436;
																													case 101:
																														goto IL_0475;
																													case 31:
																													case 90:
																														goto IL_0488;
																													case 47:
																													case 107:
																														goto IL_049b;
																													case 55:
																														goto IL_04a9;
																													case 24:
																													case 56:
																														goto IL_04b7;
																													case 19:
																														goto IL_04d3;
																													case 37:
																													case 68:
																														goto IL_04ea;
																													case 61:
																														goto IL_04f8;
																													case 114:
																														goto IL_050c;
																													case 106:
																													case 122:
																														goto IL_051a;
																													case 18:
																														goto IL_0543;
																													case 98:
																														goto IL_0551;
																													case 86:
																														goto IL_056d;
																													case 116:
																														goto IL_057b;
																													case 6:
																													case 34:
																														goto IL_0589;
																													case 69:
																														goto IL_05a1;
																													case 8:
																													case 76:
																														goto IL_05ac;
																													case 41:
																														goto IL_05ec;
																													case 51:
																														goto IL_0600;
																													case 120:
																														goto IL_0613;
																													case 1:
																													case 73:
																														goto IL_0621;
																													case 27:
																														goto IL_062f;
																													case 21:
																													case 49:
																														goto IL_063d;
																													case 91:
																														goto IL_06ab;
																													case 2:
																														goto IL_06bb;
																													case 5:
																													case 7:
																													case 10:
																													case 20:
																													case 23:
																													case 26:
																													case 30:
																													case 32:
																													case 33:
																													case 43:
																													case 50:
																													case 54:
																													case 72:
																													case 79:
																													case 85:
																													case 88:
																													case 89:
																													case 95:
																													case 111:
																													case 113:
																													case 115:
																													case 119:
																														goto end_IL_02c4;
																													case 11:
																														goto IL_06e9;
																													case 100:
																														goto IL_0700;
																													case 77:
																														goto IL_070e;
																													case 0:
																													case 9:
																													case 13:
																													case 16:
																													case 25:
																													case 28:
																													case 52:
																													case 66:
																													case 70:
																													case 71:
																													case 82:
																													case 84:
																													case 93:
																													case 112:
																														goto end_IL_0213;
																													case 29:
																														goto end_IL_071c;
																													case 59:
																														goto end_IL_072f;
																													case 42:
																														goto end_IL_0742;
																													case 83:
																														goto end_IL_074d;
																													case 105:
																														goto end_IL_0762;
																													case 58:
																													case 87:
																														goto end_IL_0777;
																													case 104:
																														goto end_IL_0787;
																													case 63:
																													case 67:
																														goto end_IL_07a0;
																													case 44:
																														goto end_IL_07b0;
																													case 45:
																														goto end_IL_07c0;
																													case 17:
																													case 35:
																														goto IL_07db;
																													}
																													continue;
																													end_IL_0213:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_02ff;
																								IL_03c9:
																								num5++;
																								goto IL_03d7;
																								IL_02ff:
																								if (7 >= b)
																								{
																									goto IL_030a;
																								}
																								goto IL_0386;
																								IL_030a:
																								if (7 > b)
																								{
																									goto end_IL_02c4;
																								}
																								num = 117;
																								goto IL_0321;
																								IL_03d7:
																								ptr2 += 8;
																								break;
																								IL_0321:
																								array[num5] = 0;
																								goto IL_032f;
																								IL_032f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0352;
																								IL_0352:
																								array2[num5] = null;
																								goto IL_035c;
																								IL_035c:
																								num5++;
																								goto IL_036a;
																								IL_036a:
																								ptr2 += 8;
																								num = 82;
																								break;
																								IL_0386:
																								if (8 < b)
																								{
																									goto end_IL_02c4;
																								}
																								goto IL_0394;
																								IL_0394:
																								if (8 > b)
																								{
																									goto end_IL_02c4;
																								}
																								goto IL_03a2;
																								IL_03a2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_03bb;
																								IL_03bb:
																								array[num5] = 0;
																								goto IL_03c9;
																							}
																							break;
																						}
																						goto IL_03ea;
																						IL_04b7:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_03ea:
																						if (11 >= b)
																						{
																							goto IL_03f8;
																						}
																						goto IL_049b;
																						IL_03f8:
																						if (11 > b)
																						{
																							goto IL_0406;
																						}
																						goto IL_0488;
																						IL_0406:
																						if (10 < b)
																						{
																							goto end_IL_02c4;
																						}
																						goto IL_0414;
																						IL_0414:
																						if (10 > b)
																						{
																							goto end_IL_02c4;
																						}
																						goto IL_0422;
																						IL_0422:
																						array[num5 - 1] = 0;
																						goto IL_0436;
																						IL_0436:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)AsyncTaskMethodBuilderIsEnumDefined[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_0475;
																						IL_0475:
																						ptr2 += 8;
																						break;
																						IL_0488:
																						num5--;
																						break;
																						IL_049b:
																						if (12 < b)
																						{
																							goto end_IL_02c4;
																						}
																						goto IL_04a9;
																						IL_04a9:
																						if (12 > b)
																						{
																							goto end_IL_02c4;
																						}
																						goto IL_04b7;
																					}
																					break;
																				}
																				goto IL_04d3;
																				IL_063d:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06ab;
																				IL_04d3:
																				if (6 <= b)
																				{
																					break;
																				}
																				num = 68;
																				goto IL_04ea;
																				IL_06ab:
																				num5 -= 2;
																				break;
																				IL_04ea:
																				if (3 < b)
																				{
																					goto IL_04f8;
																				}
																				goto IL_05a1;
																				IL_04f8:
																				if (4 >= b)
																				{
																					num = 114;
																					goto IL_050c;
																				}
																				goto IL_056d;
																				IL_06bb:
																				if (1 > b)
																				{
																				}
																				goto end_IL_02c4;
																				IL_050c:
																				if (4 > b)
																				{
																					goto end_IL_02c4;
																				}
																				goto IL_051a;
																				IL_051a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0543;
																				IL_0543:
																				ptr2 += 8;
																				goto IL_0551;
																				IL_0551:
																				num5--;
																				num = 93;
																				break;
																				IL_056d:
																				if (5 < b)
																				{
																					goto end_IL_02c4;
																				}
																				goto IL_057b;
																				IL_057b:
																				if (5 > b)
																				{
																					goto end_IL_02c4;
																				}
																				goto IL_0589;
																				IL_0589:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_05a1:
																				if (3 <= b)
																				{
																					goto IL_05ac;
																				}
																				goto IL_0613;
																				IL_05ac:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05ec;
																				IL_05ec:
																				array[num5 - 2] = 0;
																				goto IL_0600;
																				IL_0600:
																				num5--;
																				break;
																				IL_0613:
																				if (1 < b)
																				{
																					goto IL_0621;
																				}
																				goto IL_06bb;
																				IL_0621:
																				if (2 < b)
																				{
																					goto end_IL_02c4;
																				}
																				goto IL_062f;
																				IL_062f:
																				if (2 > b)
																				{
																					goto end_IL_02c4;
																				}
																				goto IL_063d;
																			}
																			goto end_IL_02d4;
																			continue;
																			end_IL_02c4:
																			break;
																			IL_02c4:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e9;
																	IL_070e:
																	ptr2 += 8;
																	break;
																	IL_0700:
																	num5++;
																	goto IL_070e;
																	IL_06e9:
																	array[num5] = 0;
																	num = 100;
																	goto IL_0700;
																	continue;
																	end_IL_02d4:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07db;
													IL_07db:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_071c:
													break;
												}
												continue;
												end_IL_072f:
												break;
											}
											continue;
											end_IL_0742:
											break;
										}
										continue;
										end_IL_074d:
										break;
									}
									continue;
									end_IL_0762:
									break;
								}
								continue;
								end_IL_0777:
								break;
							}
							continue;
							end_IL_0787:
							break;
						}
						continue;
						end_IL_07a0:
						break;
					}
					continue;
					end_IL_07b0:
					break;
				}
				continue;
				end_IL_07c0:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_0, int int_1)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 11;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									num = 53;
									while (true)
									{
										array3[0] = int_0;
										num = 83;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetConfigurationBytesFindSystemTimeZoneById.getTaskSchedulerProcArch);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0294:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_0274:
																					if (5 < b)
																					{
																						while (true)
																						{
																							IL_0264:
																							if (7 < b)
																							{
																								while (true)
																								{
																									IL_0257:
																									if (8 >= b)
																									{
																										while (8 <= b)
																										{
																											while (true)
																											{
																												IL_0205:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_01e6:
																													array[num5 - 2] = 0;
																													num = 113;
																													while (true)
																													{
																														if (num != 113)
																														{
																															if (num != 1094)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 51:
																																goto IL_01e6;
																															case 10:
																															case 19:
																																goto IL_0205;
																															case 28:
																																goto IL_0247;
																															case 35:
																															case 41:
																																goto IL_0257;
																															case 58:
																																goto IL_0264;
																															case 44:
																																goto IL_0274;
																															case 29:
																																goto IL_0284;
																															case 85:
																																goto IL_0294;
																															case 15:
																																goto end_IL_0294;
																															case 33:
																															case 66:
																																goto end_IL_02a4;
																															case 36:
																																goto IL_02d2;
																															case 34:
																																goto IL_02e0;
																															case 24:
																															case 105:
																																goto IL_02ee;
																															case 8:
																																goto IL_0313;
																															case 43:
																															case 59:
																																goto IL_031e;
																															case 26:
																																goto IL_0337;
																															case 55:
																																goto IL_0345;
																															case 21:
																																goto IL_0353;
																															case 54:
																															case 93:
																																goto IL_0366;
																															case 71:
																																goto IL_0374;
																															case 61:
																															case 89:
																																goto IL_0382;
																															case 102:
																																goto IL_03cb;
																															case 16:
																																goto IL_03e8;
																															case 64:
																																goto IL_0404;
																															case 81:
																															case 100:
																																goto end_IL_01d3;
																															case 88:
																																goto IL_0426;
																															case 20:
																																goto IL_0449;
																															case 14:
																																goto IL_045c;
																															case 37:
																																goto IL_046a;
																															case 92:
																																goto IL_047d;
																															case 60:
																															case 76:
																																goto IL_048b;
																															case 42:
																															case 99:
																																goto IL_0499;
																															case 72:
																																goto IL_04a7;
																															case 94:
																															case 106:
																																goto IL_04b5;
																															case 50:
																																goto IL_04f5;
																															case 70:
																																goto IL_0509;
																															case 40:
																																goto IL_051c;
																															case 32:
																															case 48:
																																goto IL_0527;
																															case 77:
																																goto IL_0550;
																															case 79:
																																goto IL_055e;
																															case 98:
																																goto IL_057f;
																															case 1:
																															case 63:
																																goto IL_058a;
																															case 17:
																																goto IL_05ca;
																															case 49:
																																goto IL_05de;
																															case 69:
																															case 95:
																																goto IL_05ee;
																															case 18:
																																goto IL_0602;
																															case 3:
																															case 6:
																															case 12:
																															case 13:
																															case 23:
																															case 25:
																															case 27:
																															case 46:
																															case 65:
																															case 67:
																															case 68:
																															case 73:
																															case 74:
																															case 78:
																															case 86:
																															case 87:
																															case 96:
																															case 101:
																															case 103:
																																goto end_IL_0247;
																															case 82:
																																goto IL_0639;
																															case 31:
																																goto IL_0647;
																															case 22:
																																goto IL_0655;
																															case 2:
																															case 7:
																															case 45:
																															case 47:
																															case 52:
																															case 56:
																															case 57:
																															case 62:
																															case 80:
																															case 90:
																															case 91:
																																goto end_IL_02b4;
																															case 5:
																																goto end_IL_066c;
																															case 9:
																																goto end_IL_067f;
																															case 83:
																																goto end_IL_0689;
																															case 53:
																																goto end_IL_0694;
																															case 30:
																																goto end_IL_06a9;
																															case 11:
																																goto end_IL_06c7;
																															case 84:
																																goto end_IL_06e0;
																															case 4:
																																goto end_IL_06f0;
																															case 0:
																															case 104:
																																goto end_IL_06fb;
																															case 38:
																																goto end_IL_070b;
																															case 39:
																																goto end_IL_071b;
																															case 75:
																															case 97:
																																goto IL_0736;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_02b4;
																														continue;
																														end_IL_01d3:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0418;
																											continue;
																											end_IL_0247:
																											break;
																											IL_0247:;
																										}
																										break;
																									}
																									goto IL_02d2;
																									IL_02ee:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									num = 80;
																									goto end_IL_02b4;
																									IL_02d2:
																									if (9 < b)
																									{
																										break;
																									}
																									goto IL_02e0;
																									IL_02e0:
																									if (9 > b)
																									{
																										break;
																									}
																									goto IL_02ee;
																								}
																								break;
																							}
																							goto IL_0313;
																							IL_03e8:
																							num5--;
																							num = 47;
																							goto end_IL_02b4;
																							IL_0313:
																							if (7 <= b)
																							{
																								goto IL_031e;
																							}
																							goto IL_0366;
																							IL_031e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0337;
																							IL_0337:
																							array[num5] = 0;
																							goto IL_0345;
																							IL_0345:
																							num5++;
																							goto IL_0353;
																							IL_0353:
																							ptr2 += 8;
																							goto end_IL_02b4;
																							IL_0366:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_0374;
																							IL_0374:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_0382;
																							IL_0382:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 102;
																							goto IL_03cb;
																							IL_03cb:
																							array[num5 - 2] = 0;
																							num = 16;
																							goto IL_03e8;
																						}
																						break;
																					}
																					goto IL_0404;
																					IL_05de:
																					num5--;
																					goto end_IL_02b4;
																					IL_0404:
																					if (5 <= b)
																					{
																						num = 81;
																						goto IL_0418;
																					}
																					goto IL_047d;
																					IL_05ee:
																					if (1 < b)
																					{
																						break;
																					}
																					num = 18;
																					goto IL_0602;
																					IL_0418:
																					array[num5] = 0;
																					goto IL_0426;
																					IL_0426:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0449;
																					IL_0449:
																					array2[num5] = null;
																					num = 14;
																					goto IL_045c;
																					IL_045c:
																					num5++;
																					goto IL_046a;
																					IL_046a:
																					ptr2 += 8;
																					goto end_IL_02b4;
																					IL_047d:
																					if (2 < b)
																					{
																						goto IL_048b;
																					}
																					goto IL_057f;
																					IL_048b:
																					if (3 < b)
																					{
																						goto IL_0499;
																					}
																					goto IL_051c;
																					IL_0499:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_04a7;
																					IL_04a7:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_04b5;
																					IL_04b5:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04f5;
																					IL_04f5:
																					array[num5 - 2] = 0;
																					goto IL_0509;
																					IL_0509:
																					num5--;
																					goto end_IL_02b4;
																					IL_051c:
																					if (3 > b)
																					{
																						num = 12;
																						break;
																					}
																					goto IL_0527;
																					IL_0527:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0550;
																					IL_0550:
																					ptr2 += 8;
																					goto IL_055e;
																					IL_055e:
																					num5--;
																					goto end_IL_02b4;
																					IL_0602:
																					if (1 > b)
																					{
																						num = 65;
																					}
																					break;
																					IL_057f:
																					if (2 <= b)
																					{
																						goto IL_058a;
																					}
																					goto IL_05ee;
																					IL_058a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05ca;
																					IL_05ca:
																					array[num5 - 2] = 0;
																					goto IL_05de;
																				}
																				break;
																				IL_0284:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0639;
																		IL_0655:
																		ptr2 += 8;
																		num = 57;
																		goto end_IL_02b4;
																		IL_0647:
																		num5++;
																		goto IL_0655;
																		IL_0639:
																		array[num5] = 0;
																		goto IL_0647;
																		continue;
																		end_IL_0294:
																		break;
																	}
																	continue;
																	end_IL_02a4:
																	break;
																}
																continue;
																end_IL_02b4:
																break;
															}
															continue;
														}
														goto IL_0736;
														IL_0736:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_066c:
														break;
													}
													continue;
													end_IL_067f:
													break;
												}
												continue;
												end_IL_0689:
												break;
											}
											continue;
											end_IL_0694:
											break;
										}
										continue;
										end_IL_06a9:
										break;
									}
									continue;
									end_IL_06c7:
									break;
								}
								continue;
								end_IL_06e0:
								break;
							}
							continue;
							end_IL_06f0:
							break;
						}
						continue;
						end_IL_06fb:
						break;
					}
					continue;
					end_IL_070b:
					break;
				}
				continue;
				end_IL_071b:
				break;
			}
		}
	}

	static Class199()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 3;
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 16;
					while (true)
					{
						if (num != 16)
						{
							if (num != 997)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 1:
							case 5:
							case 6:
							case 7:
							case 9:
								goto end_IL_004c;
							case 3:
								goto end_IL_0059;
							case 4:
								goto end_IL_0074;
							case 2:
								return;
							case 8:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_004c:
						break;
					}
					continue;
					end_IL_0059:
					break;
				}
				continue;
				end_IL_0074:
				break;
			}
		}
	}

	private static void ReleaseWriterLockCustomErrorsMode(Class199 class199_1)
	{
		class199_1.method_1();
	}
}
