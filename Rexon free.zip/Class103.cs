using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Propellor Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns propellors.", false, 15, ModType.const_0, false)]
internal class Class103 : Class93
{
	private static double double_1;

	private static bool bool_0;

	private static bool bool_1;

	private static float float_0;

	private static bool bool_2;

	private static bool bool_3;

	private static float float_1;

	private static IntPtr[] AbortRequestedAppDomainInitializer;

	private static IntPtr[] ProgIdRedirectionEntryStoreOperationMetadataProperty;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_038b, IL_039e, IL_03cd, IL_03ed, IL_0407, IL_0417, IL_0427, IL_0437, IL_0447, IL_0457, IL_0467, IL_0474, IL_0484, IL_0494, IL_04ad, IL_04b8, IL_04c6, IL_04d4, IL_04e2, IL_04f0, IL_04fe, IL_053e, IL_0557, IL_0565, IL_0570, IL_057e, IL_0591, IL_059a, IL_05a5, IL_05b3, IL_05c6, IL_05d4, IL_05e2, IL_05f0, IL_05fe, IL_060c, IL_0651, IL_065f, IL_066d, IL_0676, IL_0684, IL_06a7, IL_06b1, IL_06bf, IL_06d2, IL_06e5, IL_0725, IL_0739, IL_074c, IL_075f, IL_0773, IL_0786, IL_0794, IL_07a2, IL_0804, IL_0817, IL_0830, IL_083b, IL_0859, IL_0867, IL_087a, IL_0885, IL_0898, IL_08a6, IL_08b4, IL_08d1, IL_0920, IL_092a, IL_0957, IL_096b, IL_0979, IL_098c, IL_09cc, IL_09e0, IL_09f3, IL_0a32, IL_0a45, IL_0a53, IL_0a93, IL_0aa7, IL_0aba, IL_0ae3, IL_0af1, IL_0b04, IL_0b1c, IL_0b2f, IL_0b3d, IL_0b6f, IL_0b88, IL_0b96, IL_0bae, IL_0bbc, IL_0bcf, IL_0bda, IL_0be5, IL_0bf3, IL_0c01, IL_0c1d, IL_0c2b, IL_0c43, IL_0c51, IL_0c5c, IL_0c6a, IL_0ca8, IL_0cbb, IL_0cc9, IL_0cd7, IL_0ceb, IL_0d23, IL_0d36, IL_0d3f, IL_0d58, IL_0d66, IL_0d74, IL_0d84, IL_0d9d, IL_0dab, IL_0db9, IL_0dc7, IL_0dda, IL_0de4, IL_0def, IL_0dff, IL_0e0f, IL_0e1f, IL_0e38, IL_0e51, IL_0e61, IL_0e71, IL_0e81, IL_0e9c are reachable both inside and outside the pinned region starting at IL_0e96. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 106;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				int __rxRef8 = default(int);
				ref int reference = ref __rxRef8;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0e81:
						num2 = 1;
						while (true)
						{
							IL_0e71:
							num3 = num2 * 4;
							while (true)
							{
								IL_0e61:
								num4 = num2 * 8;
								while (true)
								{
									IL_0e51:
									array2 = new byte[4];
									while (true)
									{
										IL_0e38:
										array3 = new object[4];
										num = 115;
										while (true)
										{
											IL_0e1f:
											array4 = new int[4];
											num = 216;
											while (true)
											{
												IL_0e0f:
												array5 = new int[6];
												while (true)
												{
													IL_0dff:
													array6 = new long[4];
													while (true)
													{
														IL_0def:
														array7 = new object[10];
														while (true)
														{
															IL_0de4:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnboxCaseSensitive.DoubleQuoteGetPackagePropertyFlags);
															while (true)
															{
																IL_0dda:
																ptr2 = ptr;
																while (true)
																{
																	IL_0dc7:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_04ad:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_0494:
																				ptr2++;
																				num = 192;
																				while (true)
																				{
																					IL_0484:
																					if (b >= 1)
																					{
																						while (b <= 22)
																						{
																							while (true)
																							{
																								IL_0467:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_0457:
																										if (17 >= b)
																										{
																											while (true)
																											{
																												IL_0447:
																												if (17 > b)
																												{
																													while (true)
																													{
																														IL_0437:
																														if (14 < b)
																														{
																															while (true)
																															{
																																IL_0427:
																																if (15 < b)
																																{
																																	while (16 >= b)
																																	{
																																		while (16 <= b)
																																		{
																																			while (true)
																																			{
																																				IL_03ed:
																																				array2[num6] = array2[num6 - 1];
																																				while (true)
																																				{
																																					IL_03cd:
																																					array4[num6 - 0] = array4[num6 - 1];
																																					while (true)
																																					{
																																						IL_039e:
																																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																						num = 223;
																																						while (true)
																																						{
																																							if (num != 223)
																																							{
																																								if (num != 1204)
																																								{
																																									break;
																																								}
																																								switch (num)
																																								{
																																								case 106:
																																									break;
																																								default:
																																									continue;
																																								case 185:
																																									goto IL_039e;
																																								case 139:
																																									goto IL_03cd;
																																								case 39:
																																								case 201:
																																									goto IL_03ed;
																																								case 140:
																																									goto IL_0407;
																																								case 161:
																																								case 168:
																																									goto IL_0417;
																																								case 22:
																																									goto IL_0427;
																																								case 90:
																																								case 183:
																																									goto IL_0437;
																																								case 59:
																																									goto IL_0447;
																																								case 64:
																																									goto IL_0457;
																																								case 17:
																																									goto IL_0467;
																																								case 85:
																																									goto IL_0474;
																																								case 192:
																																									goto IL_0484;
																																								case 96:
																																									goto IL_0494;
																																								case 12:
																																								case 97:
																																									goto IL_04ad;
																																								case 49:
																																									goto IL_04b8;
																																								case 98:
																																								case 162:
																																									goto IL_04c6;
																																								case 24:
																																								case 76:
																																									goto IL_04d4;
																																								case 130:
																																									goto IL_04e2;
																																								case 47:
																																									goto IL_04f0;
																																								case 63:
																																								case 114:
																																									goto IL_04fe;
																																								case 74:
																																									goto IL_053e;
																																								case 148:
																																									goto IL_0557;
																																								case 27:
																																								case 178:
																																									goto IL_0565;
																																								case 172:
																																									goto IL_0570;
																																								case 121:
																																									goto IL_057e;
																																								case 166:
																																									goto end_IL_038b;
																																								case 42:
																																									goto IL_05a5;
																																								case 2:
																																									goto IL_05b3;
																																								case 179:
																																									goto IL_05d4;
																																								case 8:
																																								case 62:
																																									goto IL_05e2;
																																								case 29:
																																								case 156:
																																									goto IL_05f0;
																																								case 6:
																																									goto IL_05fe;
																																								case 15:
																																								case 180:
																																									goto IL_060c;
																																								case 184:
																																									goto IL_0651;
																																								case 112:
																																									goto IL_065f;
																																								case 169:
																																								case 181:
																																									goto IL_0676;
																																								case 91:
																																									goto IL_0684;
																																								case 5:
																																									goto IL_06a7;
																																								case 102:
																																									goto IL_06b1;
																																								case 160:
																																									goto IL_06bf;
																																								case 188:
																																									goto IL_06d2;
																																								case 110:
																																								case 189:
																																									goto IL_06e5;
																																								case 142:
																																									goto IL_0725;
																																								case 119:
																																									goto IL_0739;
																																								case 73:
																																								case 200:
																																									goto IL_074c;
																																								case 203:
																																									goto IL_075f;
																																								case 4:
																																									goto IL_0773;
																																								case 122:
																																								case 204:
																																									goto IL_0786;
																																								case 125:
																																									goto IL_0794;
																																								case 95:
																																								case 128:
																																									goto IL_07a2;
																																								case 60:
																																									goto IL_0804;
																																								case 26:
																																								case 207:
																																									goto IL_0817;
																																								case 208:
																																									goto IL_0830;
																																								case 35:
																																								case 123:
																																									goto IL_083b;
																																								case 164:
																																									goto IL_0859;
																																								case 141:
																																									goto IL_0867;
																																								case 94:
																																									goto IL_087a;
																																								case 55:
																																									goto IL_0885;
																																								case 70:
																																									goto IL_0898;
																																								case 165:
																																									goto IL_08a6;
																																								case 111:
																																								case 157:
																																									goto IL_08b4;
																																								case 30:
																																									goto IL_096b;
																																								case 13:
																																									goto IL_0979;
																																								case 182:
																																								case 209:
																																									goto IL_098c;
																																								case 107:
																																									goto IL_09cc;
																																								case 99:
																																									goto IL_09e0;
																																								case 212:
																																									goto IL_09f3;
																																								case 46:
																																									goto IL_0a32;
																																								case 214:
																																									goto IL_0a45;
																																								case 52:
																																								case 193:
																																									goto IL_0a53;
																																								case 153:
																																									goto IL_0a93;
																																								case 82:
																																									goto IL_0aa7;
																																								case 38:
																																								case 215:
																																									goto IL_0aba;
																																								case 163:
																																									goto IL_0ae3;
																																								case 93:
																																									goto IL_0af1;
																																								case 173:
																																									goto IL_0b1c;
																																								case 206:
																																									goto IL_0b2f;
																																								case 72:
																																								case 150:
																																									goto IL_0b3d;
																																								case 202:
																																									goto IL_0b6f;
																																								case 88:
																																								case 138:
																																									goto IL_0b88;
																																								case 101:
																																									goto IL_0b96;
																																								case 87:
																																									goto IL_0bae;
																																								case 117:
																																									goto IL_0bbc;
																																								case 134:
																																									goto IL_0bcf;
																																								case 68:
																																								case 104:
																																									goto IL_0bda;
																																								case 9:
																																								case 129:
																																									goto IL_0be5;
																																								case 25:
																																									goto IL_0bf3;
																																								case 108:
																																								case 147:
																																									goto IL_0c01;
																																								case 23:
																																									goto IL_0c1d;
																																								case 155:
																																								case 174:
																																									goto IL_0c2b;
																																								case 3:
																																									goto IL_0c43;
																																								case 167:
																																									goto IL_0c51;
																																								case 127:
																																									goto IL_0c5c;
																																								case 116:
																																								case 205:
																																									goto IL_0c6a;
																																								case 0:
																																									goto IL_0ca8;
																																								case 211:
																																									goto IL_0cbb;
																																								case 66:
																																									goto IL_0cc9;
																																								case 21:
																																								case 145:
																																									goto IL_0cd7;
																																								case 33:
																																									goto IL_0ceb;
																																								case 51:
																																									goto IL_0d23;
																																								case 50:
																																								case 137:
																																									goto IL_0d3f;
																																								case 197:
																																									goto IL_0d58;
																																								case 100:
																																									goto IL_0d66;
																																								case 77:
																																									goto IL_0d74;
																																								case 10:
																																								case 14:
																																								case 19:
																																								case 20:
																																								case 32:
																																								case 36:
																																								case 37:
																																								case 40:
																																								case 43:
																																								case 44:
																																								case 53:
																																								case 56:
																																								case 57:
																																								case 58:
																																								case 67:
																																								case 69:
																																								case 71:
																																								case 80:
																																								case 83:
																																								case 86:
																																								case 92:
																																								case 103:
																																								case 109:
																																								case 120:
																																								case 124:
																																								case 131:
																																								case 133:
																																								case 135:
																																								case 136:
																																								case 143:
																																								case 146:
																																								case 152:
																																								case 158:
																																								case 159:
																																								case 170:
																																								case 171:
																																								case 175:
																																								case 176:
																																								case 186:
																																								case 194:
																																									goto end_IL_0407;
																																								case 177:
																																									goto IL_0d9d;
																																								case 31:
																																									goto IL_0dab;
																																								case 7:
																																									goto IL_0db9;
																																								case 18:
																																								case 34:
																																								case 41:
																																								case 45:
																																								case 65:
																																								case 75:
																																								case 78:
																																								case 79:
																																								case 81:
																																								case 89:
																																								case 113:
																																								case 118:
																																								case 126:
																																								case 132:
																																								case 144:
																																								case 149:
																																								case 151:
																																								case 154:
																																								case 187:
																																								case 190:
																																								case 191:
																																								case 198:
																																								case 199:
																																								case 210:
																																								case 213:
																																									goto IL_0dc7;
																																								case 16:
																																									goto IL_0dda;
																																								case 196:
																																									goto IL_0de4;
																																								case 1:
																																									goto IL_0def;
																																								case 195:
																																									goto IL_0dff;
																																								case 216:
																																									goto IL_0e0f;
																																								case 115:
																																									goto IL_0e1f;
																																								case 28:
																																									goto IL_0e38;
																																								case 11:
																																									goto IL_0e51;
																																								case 54:
																																									goto IL_0e61;
																																								case 84:
																																									goto IL_0e71;
																																								case 105:
																																									goto IL_0e81;
																																								case 48:
																																								case 61:
																																									goto IL_0e9c;
																																								}
																																								goto end_IL_0484;
																																							}
																																							array3[num6] = array3[num6 - 1];
																																							goto IL_0b1c;
																																							IL_0b1c:
																																							num6++;
																																							goto IL_0dc7;
																																							continue;
																																							end_IL_038b:
																																							break;
																																						}
																																						break;
																																					}
																																					break;
																																				}
																																				break;
																																			}
																																			goto IL_059a;
																																			continue;
																																			end_IL_0407:
																																			break;
																																			IL_0407:;
																																		}
																																		break;
																																		IL_0417:;
																																	}
																																	break;
																																}
																																goto IL_0b2f;
																																IL_0b6f:
																																array2[num6 - 1] = 5;
																																goto IL_0dc7;
																																IL_0b2f:
																																if (15 > b)
																																{
																																	break;
																																}
																																goto IL_0b3d;
																																IL_0b3d:
																																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																num = 202;
																																goto IL_0b6f;
																															}
																															break;
																														}
																														goto IL_0830;
																														IL_096b:
																														array2[num6] = 5;
																														goto IL_0979;
																														IL_0830:
																														if (14 <= b)
																														{
																															goto IL_083b;
																														}
																														goto IL_087a;
																														IL_083b:
																														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																														goto IL_0859;
																														IL_0859:
																														ptr2 += 8;
																														goto IL_0867;
																														IL_0867:
																														num6--;
																														goto IL_0dc7;
																														IL_087a:
																														if (12 >= b)
																														{
																															goto IL_0885;
																														}
																														goto IL_0898;
																														IL_0885:
																														if (12 > b)
																														{
																															break;
																														}
																														goto IL_0dc7;
																														IL_0898:
																														if (13 < b)
																														{
																															break;
																														}
																														goto IL_08a6;
																														IL_08a6:
																														if (13 > b)
																														{
																															break;
																														}
																														goto IL_08b4;
																														IL_08b4:
																														array8 = array3;
																														num7 = num6;
																														if (array == null)
																														{
																															goto IL_08c3;
																														}
																														num8 = ptr2;
																														byte b2 = *num8;
																														ptr2 = num8 + 4;
																														int num9 = *(int*)(ptr2 + num3);
																														ptr2 += 8;
																														byte* ptr3 = ptr2 + num9;
																														byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																														while (ptr2 != ptr3)
																														{
																															*ptr4 = (byte)(*ptr2 ^ b2);
																															ptr2++;
																															ptr4++;
																														}
																														array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																														goto IL_096b;
																														IL_0979:
																														num6++;
																														goto IL_0dc7;
																													}
																													break;
																												}
																												goto IL_0b88;
																												IL_0bbc:
																												ptr2 += 8;
																												goto IL_0dc7;
																												IL_0b88:
																												array2[num6] = 5;
																												goto IL_0b96;
																												IL_0b96:
																												array3[num6] = array7[*(int*)(ptr2 + num3)];
																												goto IL_0bae;
																												IL_0bae:
																												num6++;
																												goto IL_0bbc;
																											}
																											break;
																										}
																										goto IL_0bcf;
																										IL_0d66:
																										num6++;
																										goto IL_0d74;
																										IL_0bcf:
																										if (20 < b)
																										{
																											goto IL_0bda;
																										}
																										goto IL_0c43;
																										IL_0bda:
																										if (21 < b)
																										{
																											goto IL_0be5;
																										}
																										goto IL_0c1d;
																										IL_0be5:
																										if (22 < b)
																										{
																											break;
																										}
																										goto IL_0bf3;
																										IL_0bf3:
																										if (22 > b)
																										{
																											break;
																										}
																										goto IL_0c01;
																										IL_0c01:
																										num10 = ptr2;
																										num11 = -200;
																										num5 = 1;
																										ptr2 = num10 + num11;
																										goto IL_0dc7;
																										IL_0c1d:
																										if (21 > b)
																										{
																											break;
																										}
																										goto IL_0c2b;
																										IL_0c2b:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto IL_0dc7;
																										IL_0c43:
																										if (20 > b)
																										{
																											goto IL_0c51;
																										}
																										num = 137;
																										goto IL_0d3f;
																										IL_0c51:
																										if (18 >= b)
																										{
																											goto IL_0c5c;
																										}
																										goto IL_0cbb;
																										IL_0c5c:
																										if (18 > b)
																										{
																											break;
																										}
																										goto IL_0c6a;
																										IL_0c6a:
																										((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																										goto IL_0ca8;
																										IL_0ca8:
																										num6 -= 3;
																										goto IL_0dc7;
																										IL_0cbb:
																										if (19 < b)
																										{
																											break;
																										}
																										goto IL_0cc9;
																										IL_0cc9:
																										if (19 > b)
																										{
																											break;
																										}
																										goto IL_0cd7;
																										IL_0cd7:
																										array2[num6 - 1] = 5;
																										goto IL_0ceb;
																										IL_0ceb:
																										array3[num6 - 1] = ((delegate*<string[], string>)AbortRequestedAppDomainInitializer[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																										goto IL_0d23;
																										IL_0d23:
																										ptr2 += 8;
																										goto IL_0dc7;
																										IL_0d74:
																										ptr2 += 16;
																										goto IL_0dc7;
																										IL_0d3f:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																										goto IL_0d58;
																										IL_0d58:
																										array2[num6] = 1;
																										goto IL_0d66;
																									}
																									break;
																								}
																								goto IL_04b8;
																								IL_0739:
																								num6--;
																								goto IL_0dc7;
																								IL_04b8:
																								if (11 > b)
																								{
																									goto IL_04c6;
																								}
																								goto IL_0817;
																								IL_04c6:
																								if (5 < b)
																								{
																									goto IL_04d4;
																								}
																								goto IL_0557;
																								IL_04d4:
																								if (8 < b)
																								{
																									goto IL_04e2;
																								}
																								goto IL_05d4;
																								IL_04e2:
																								if (9 >= b)
																								{
																									goto IL_04f0;
																								}
																								goto IL_0786;
																								IL_04f0:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_04fe;
																								IL_04fe:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_053e;
																								IL_053e:
																								array2[num6 - 2] = 0;
																								goto IL_06d2;
																								IL_06d2:
																								num6--;
																								goto IL_0dc7;
																								IL_0786:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_0794;
																								IL_0794:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_07a2;
																								IL_07a2:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0804;
																								IL_0804:
																								num6 -= 2;
																								goto IL_0dc7;
																								IL_05d4:
																								if (8 > b)
																								{
																									goto IL_05e2;
																								}
																								goto IL_074c;
																								IL_05e2:
																								if (6 < b)
																								{
																									goto IL_05f0;
																								}
																								goto IL_0a45;
																								IL_05f0:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_05fe;
																								IL_05fe:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_060c;
																								IL_060c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_075f;
																								IL_075f:
																								array2[num6 - 2] = 0;
																								goto IL_0773;
																								IL_0773:
																								num6--;
																								goto IL_0dc7;
																								IL_0a45:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_0a53;
																								IL_0a53:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0a93;
																								IL_0a93:
																								array2[num6 - 2] = 0;
																								goto IL_0aa7;
																								IL_0aa7:
																								num6--;
																								goto IL_0dc7;
																								IL_074c:
																								num6--;
																								goto IL_0dc7;
																								IL_0557:
																								if (5 > b)
																								{
																									goto IL_0565;
																								}
																								goto IL_06e5;
																								IL_0565:
																								if (2 < b)
																								{
																									goto IL_0570;
																								}
																								num = 166;
																								goto IL_059a;
																								IL_0570:
																								if (3 >= b)
																								{
																									goto IL_057e;
																								}
																								goto IL_0651;
																								IL_057e:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0aba;
																								IL_0aba:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0ae3;
																								IL_0ae3:
																								ptr2 += 8;
																								goto IL_0af1;
																								IL_0af1:
																								num6--;
																								goto IL_0dc7;
																								IL_0651:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_065f;
																								IL_065f:
																								if (4 > b)
																								{
																									break;
																								}
																								num = 169;
																								goto IL_0676;
																								IL_09f3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)AbortRequestedAppDomainInitializer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_0a32;
																								IL_0676:
																								array2[num6] = 0;
																								goto IL_0684;
																								IL_0684:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_06a7;
																								IL_06a7:
																								array3[num6] = null;
																								goto IL_06b1;
																								IL_06b1:
																								num6++;
																								goto IL_06bf;
																								IL_06bf:
																								ptr2 += 8;
																								goto IL_0dc7;
																								IL_0817:
																								array2[num6 - 1] = 0;
																								goto IL_09f3;
																								IL_059a:
																								if (2 > b)
																								{
																									goto IL_05a5;
																								}
																								num = 209;
																								goto IL_098c;
																								IL_05a5:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_05b3;
																								IL_05b3:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0a32:
																								ptr2 += 8;
																								goto IL_0dc7;
																								IL_098c:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_09cc;
																								IL_09cc:
																								array2[num6 - 2] = 0;
																								goto IL_09e0;
																								IL_09e0:
																								num6--;
																								goto IL_0dc7;
																								IL_06e5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0725;
																								IL_0725:
																								array2[num6 - 2] = 0;
																								goto IL_0739;
																							}
																							break;
																							IL_0474:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0d9d;
																					IL_0db9:
																					ptr2 += 8;
																					goto IL_0dc7;
																					IL_0dab:
																					num6++;
																					goto IL_0db9;
																					IL_0d9d:
																					array2[num6] = 0;
																					goto IL_0dab;
																					continue;
																					end_IL_0484:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0e9c;
																	IL_0e9c:
																	return (string)array3[num6 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_08c3:
				while (true)
				{
					IL_08c3_2:
					array = new byte[4];
					while (true)
					{
						IL_08d1:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0979_2:
								num6++;
								while (true)
								{
									IL_0dc7_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												num = 192;
												while (true)
												{
													IL_0484_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_0467_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_0457_2:
																		if (17 >= b)
																		{
																			while (true)
																			{
																				IL_0447_2:
																				if (17 > b)
																				{
																					while (true)
																					{
																						IL_0437_2:
																						if (14 < b)
																						{
																							while (true)
																							{
																								IL_0427_2:
																								if (15 < b)
																								{
																									while (16 >= b)
																									{
																										while (16 <= b)
																										{
																											while (true)
																											{
																												IL_03ed_2:
																												array2[num6] = array2[num6 - 1];
																												while (true)
																												{
																													IL_03cd_2:
																													array4[num6 - 0] = array4[num6 - 1];
																													while (true)
																													{
																														IL_039e_2:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														num = 223;
																														while (true)
																														{
																															if (num != 223)
																															{
																																if (num != 1204)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 185:
																																	goto IL_039e_2;
																																case 139:
																																	goto IL_03cd_2;
																																case 39:
																																case 201:
																																	goto IL_03ed_2;
																																case 140:
																																	goto IL_0407_2;
																																case 161:
																																case 168:
																																	goto IL_0417_2;
																																case 22:
																																	goto IL_0427_2;
																																case 90:
																																case 183:
																																	goto IL_0437_2;
																																case 59:
																																	goto IL_0447_2;
																																case 64:
																																	goto IL_0457_2;
																																case 17:
																																	goto IL_0467_2;
																																case 85:
																																	goto IL_0474_2;
																																case 192:
																																	goto IL_0484_2;
																																case 96:
																																	goto end_IL_0484_2;
																																case 12:
																																case 97:
																																	goto end_IL_0494;
																																case 49:
																																	goto IL_04b8_2;
																																case 98:
																																case 162:
																																	goto IL_04c6_2;
																																case 24:
																																case 76:
																																	goto IL_04d4_2;
																																case 130:
																																	goto IL_04e2_2;
																																case 47:
																																	goto IL_04f0_2;
																																case 63:
																																case 114:
																																	goto IL_04fe_2;
																																case 74:
																																	goto IL_053e_2;
																																case 148:
																																	goto IL_0557_2;
																																case 27:
																																case 178:
																																	goto IL_0565_2;
																																case 172:
																																	goto IL_0570_2;
																																case 121:
																																	goto IL_057e_2;
																																case 166:
																																	goto end_IL_038b_2;
																																case 42:
																																	goto IL_05a5_2;
																																case 2:
																																	goto IL_05b3_2;
																																case 179:
																																	goto IL_05d4_2;
																																case 8:
																																case 62:
																																	goto IL_05e2_2;
																																case 29:
																																case 156:
																																	goto IL_05f0_2;
																																case 6:
																																	goto IL_05fe_2;
																																case 15:
																																case 180:
																																	goto IL_060c_2;
																																case 184:
																																	goto IL_0651_2;
																																case 112:
																																	goto IL_065f_2;
																																case 169:
																																case 181:
																																	goto IL_0676_2;
																																case 91:
																																	goto IL_0684_2;
																																case 5:
																																	goto IL_06a7_2;
																																case 102:
																																	goto IL_06b1_2;
																																case 160:
																																	goto IL_06bf_2;
																																case 188:
																																	goto IL_06d2_2;
																																case 110:
																																case 189:
																																	goto IL_06e5_2;
																																case 142:
																																	goto IL_0725_2;
																																case 119:
																																	goto IL_0739_2;
																																case 73:
																																case 200:
																																	goto IL_074c_2;
																																case 203:
																																	goto IL_075f_2;
																																case 4:
																																	goto IL_0773_2;
																																case 122:
																																case 204:
																																	goto IL_0786_2;
																																case 125:
																																	goto IL_0794_2;
																																case 95:
																																case 128:
																																	goto IL_07a2_2;
																																case 60:
																																	goto IL_0804_2;
																																case 26:
																																case 207:
																																	goto IL_0817_2;
																																case 208:
																																	goto IL_0830_2;
																																case 35:
																																case 123:
																																	goto IL_083b_2;
																																case 164:
																																	goto IL_0859_2;
																																case 141:
																																	goto IL_0867_2;
																																case 94:
																																	goto IL_087a_2;
																																case 55:
																																	goto IL_0885_2;
																																case 70:
																																	goto IL_0898_2;
																																case 165:
																																	goto IL_08a6_2;
																																case 111:
																																case 157:
																																	goto IL_08b4_2;
																																case 30:
																																	goto end_IL_04ad;
																																case 13:
																																	goto IL_0979_2;
																																case 182:
																																case 209:
																																	goto IL_098c_2;
																																case 107:
																																	goto IL_09cc_2;
																																case 99:
																																	goto IL_09e0_2;
																																case 212:
																																	goto IL_09f3_2;
																																case 46:
																																	goto IL_0a32_2;
																																case 214:
																																	goto IL_0a45_2;
																																case 52:
																																case 193:
																																	goto IL_0a53_2;
																																case 153:
																																	goto IL_0a93_2;
																																case 82:
																																	goto IL_0aa7_2;
																																case 38:
																																case 215:
																																	goto IL_0aba_2;
																																case 163:
																																	goto IL_0ae3_2;
																																case 93:
																																	goto IL_0af1_2;
																																case 173:
																																	goto IL_0b1c_2;
																																case 206:
																																	goto IL_0b2f_2;
																																case 72:
																																case 150:
																																	goto IL_0b3d_2;
																																case 202:
																																	goto IL_0b6f_2;
																																case 88:
																																case 138:
																																	goto IL_0b88_2;
																																case 101:
																																	goto IL_0b96_2;
																																case 87:
																																	goto IL_0bae_2;
																																case 117:
																																	goto IL_0bbc_2;
																																case 134:
																																	goto IL_0bcf_2;
																																case 68:
																																case 104:
																																	goto IL_0bda_2;
																																case 9:
																																case 129:
																																	goto IL_0be5_2;
																																case 25:
																																	goto IL_0bf3_2;
																																case 108:
																																case 147:
																																	goto IL_0c01_2;
																																case 23:
																																	goto IL_0c1d_2;
																																case 155:
																																case 174:
																																	goto IL_0c2b_2;
																																case 3:
																																	goto IL_0c43_2;
																																case 167:
																																	goto IL_0c51_2;
																																case 127:
																																	goto IL_0c5c_2;
																																case 116:
																																case 205:
																																	goto IL_0c6a_2;
																																case 0:
																																	goto IL_0ca8_2;
																																case 211:
																																	goto IL_0cbb_2;
																																case 66:
																																	goto IL_0cc9_2;
																																case 21:
																																case 145:
																																	goto IL_0cd7_2;
																																case 33:
																																	goto IL_0ceb_2;
																																case 51:
																																	goto IL_0d23_2;
																																case 50:
																																case 137:
																																	goto IL_0d3f_2;
																																case 197:
																																	goto IL_0d58_2;
																																case 100:
																																	goto IL_0d66_2;
																																case 77:
																																	goto IL_0d74_2;
																																case 10:
																																case 14:
																																case 19:
																																case 20:
																																case 32:
																																case 36:
																																case 37:
																																case 40:
																																case 43:
																																case 44:
																																case 53:
																																case 56:
																																case 57:
																																case 58:
																																case 67:
																																case 69:
																																case 71:
																																case 80:
																																case 83:
																																case 86:
																																case 92:
																																case 103:
																																case 109:
																																case 120:
																																case 124:
																																case 131:
																																case 133:
																																case 135:
																																case 136:
																																case 143:
																																case 146:
																																case 152:
																																case 158:
																																case 159:
																																case 170:
																																case 171:
																																case 175:
																																case 176:
																																case 186:
																																case 194:
																																	goto end_IL_0407_2;
																																case 177:
																																	goto IL_0d9d_2;
																																case 31:
																																	goto IL_0dab_2;
																																case 7:
																																	goto IL_0db9_2;
																																case 18:
																																case 34:
																																case 41:
																																case 45:
																																case 65:
																																case 75:
																																case 78:
																																case 79:
																																case 81:
																																case 89:
																																case 113:
																																case 118:
																																case 126:
																																case 132:
																																case 144:
																																case 149:
																																case 151:
																																case 154:
																																case 187:
																																case 190:
																																case 191:
																																case 198:
																																case 199:
																																case 210:
																																case 213:
																																	goto IL_0dc7_2;
																																case 16:
																																	ptr2 = ptr;
																																	goto IL_0dc7_2;
																																case 196:
																																	ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnboxCaseSensitive.DoubleQuoteGetPackagePropertyFlags);
																																	goto case 16;
																																case 1:
																																	array7 = new object[10];
																																	goto case 196;
																																case 195:
																																	array6 = new long[4];
																																	goto case 1;
																																case 216:
																																	array5 = new int[6];
																																	goto case 195;
																																case 115:
																																	array4 = new int[4];
																																	num = 216;
																																	goto case 216;
																																case 28:
																																	array3 = new object[4];
																																	num = 115;
																																	goto case 115;
																																case 11:
																																	array2 = new byte[4];
																																	goto case 28;
																																case 54:
																																	num4 = num2 * 8;
																																	goto case 11;
																																case 84:
																																	num3 = num2 * 4;
																																	goto case 54;
																																case 105:
																																	num2 = 1;
																																	goto case 84;
																																case 106:
																																	goto end_IL_096b;
																																case 48:
																																case 61:
																																	goto IL_0e9c_2;
																																}
																																continue;
																															}
																															array3[num6] = array3[num6 - 1];
																															goto IL_0b1c_2;
																															IL_0b1c_2:
																															num6++;
																															goto IL_0dc7_2;
																															continue;
																															end_IL_038b_2:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_059a_2;
																											continue;
																											end_IL_0407_2:
																											break;
																											IL_0407_2:;
																										}
																										break;
																										IL_0417_2:;
																									}
																									break;
																								}
																								goto IL_0b2f_2;
																								IL_0b6f_2:
																								array2[num6 - 1] = 5;
																								goto IL_0dc7_2;
																								IL_0b2f_2:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_0b3d_2;
																								IL_0b3d_2:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								num = 202;
																								goto IL_0b6f_2;
																							}
																							break;
																						}
																						goto IL_0830_2;
																						IL_08b4_2:
																						array8 = array3;
																						num7 = num6;
																						if (array == null)
																						{
																							goto IL_08c3_2;
																						}
																						goto IL_08d1;
																						IL_0830_2:
																						if (14 <= b)
																						{
																							goto IL_083b_2;
																						}
																						goto IL_087a_2;
																						IL_083b_2:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_0859_2;
																						IL_0859_2:
																						ptr2 += 8;
																						goto IL_0867_2;
																						IL_0867_2:
																						num6--;
																						goto IL_0dc7_2;
																						IL_087a_2:
																						if (12 >= b)
																						{
																							goto IL_0885_2;
																						}
																						goto IL_0898_2;
																						IL_0885_2:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_0dc7_2;
																						IL_0898_2:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_08a6_2;
																						IL_08a6_2:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_08b4_2;
																					}
																					break;
																				}
																				goto IL_0b88_2;
																				IL_0bbc_2:
																				ptr2 += 8;
																				goto IL_0dc7_2;
																				IL_0b88_2:
																				array2[num6] = 5;
																				goto IL_0b96_2;
																				IL_0b96_2:
																				array3[num6] = array7[*(int*)(ptr2 + num3)];
																				goto IL_0bae_2;
																				IL_0bae_2:
																				num6++;
																				goto IL_0bbc_2;
																			}
																			break;
																		}
																		goto IL_0bcf_2;
																		IL_0d66_2:
																		num6++;
																		goto IL_0d74_2;
																		IL_0bcf_2:
																		if (20 < b)
																		{
																			goto IL_0bda_2;
																		}
																		goto IL_0c43_2;
																		IL_0bda_2:
																		if (21 < b)
																		{
																			goto IL_0be5_2;
																		}
																		goto IL_0c1d_2;
																		IL_0be5_2:
																		if (22 < b)
																		{
																			break;
																		}
																		goto IL_0bf3_2;
																		IL_0bf3_2:
																		if (22 > b)
																		{
																			break;
																		}
																		goto IL_0c01_2;
																		IL_0c01_2:
																		num10 = ptr2;
																		num11 = -200;
																		num5 = 1;
																		ptr2 = num10 + num11;
																		goto IL_0dc7_2;
																		IL_0c1d_2:
																		if (21 > b)
																		{
																			break;
																		}
																		goto IL_0c2b_2;
																		IL_0c2b_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto IL_0dc7_2;
																		IL_0c43_2:
																		if (20 > b)
																		{
																			goto IL_0c51_2;
																		}
																		num = 137;
																		goto IL_0d3f_2;
																		IL_0c51_2:
																		if (18 >= b)
																		{
																			goto IL_0c5c_2;
																		}
																		goto IL_0cbb_2;
																		IL_0c5c_2:
																		if (18 > b)
																		{
																			break;
																		}
																		goto IL_0c6a_2;
																		IL_0c6a_2:
																		((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																		goto IL_0ca8_2;
																		IL_0ca8_2:
																		num6 -= 3;
																		goto IL_0dc7_2;
																		IL_0cbb_2:
																		if (19 < b)
																		{
																			break;
																		}
																		goto IL_0cc9_2;
																		IL_0cc9_2:
																		if (19 > b)
																		{
																			break;
																		}
																		goto IL_0cd7_2;
																		IL_0cd7_2:
																		array2[num6 - 1] = 5;
																		goto IL_0ceb_2;
																		IL_0ceb_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)AbortRequestedAppDomainInitializer[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_0d23_2;
																		IL_0d23_2:
																		ptr2 += 8;
																		goto IL_0dc7_2;
																		IL_0d74_2:
																		ptr2 += 16;
																		goto IL_0dc7_2;
																		IL_0d3f_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_0d58_2;
																		IL_0d58_2:
																		array2[num6] = 1;
																		goto IL_0d66_2;
																	}
																	break;
																}
																goto IL_04b8_2;
																IL_0739_2:
																num6--;
																goto IL_0dc7_2;
																IL_04b8_2:
																if (11 > b)
																{
																	goto IL_04c6_2;
																}
																goto IL_0817_2;
																IL_04c6_2:
																if (5 < b)
																{
																	goto IL_04d4_2;
																}
																goto IL_0557_2;
																IL_04d4_2:
																if (8 < b)
																{
																	goto IL_04e2_2;
																}
																goto IL_05d4_2;
																IL_04e2_2:
																if (9 >= b)
																{
																	goto IL_04f0_2;
																}
																goto IL_0786_2;
																IL_04f0_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_04fe_2;
																IL_04fe_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_053e_2;
																IL_053e_2:
																array2[num6 - 2] = 0;
																goto IL_06d2_2;
																IL_06d2_2:
																num6--;
																goto IL_0dc7_2;
																IL_0786_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_0794_2;
																IL_0794_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_07a2_2;
																IL_07a2_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0804_2;
																IL_0804_2:
																num6 -= 2;
																goto IL_0dc7_2;
																IL_05d4_2:
																if (8 > b)
																{
																	goto IL_05e2_2;
																}
																goto IL_074c_2;
																IL_05e2_2:
																if (6 < b)
																{
																	goto IL_05f0_2;
																}
																goto IL_0a45_2;
																IL_05f0_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_05fe_2;
																IL_05fe_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_060c_2;
																IL_060c_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_075f_2;
																IL_075f_2:
																array2[num6 - 2] = 0;
																goto IL_0773_2;
																IL_0773_2:
																num6--;
																goto IL_0dc7_2;
																IL_0a45_2:
																if (6 > b)
																{
																	break;
																}
																goto IL_0a53_2;
																IL_0a53_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0a93_2;
																IL_0a93_2:
																array2[num6 - 2] = 0;
																goto IL_0aa7_2;
																IL_0aa7_2:
																num6--;
																goto IL_0dc7_2;
																IL_074c_2:
																num6--;
																goto IL_0dc7_2;
																IL_0557_2:
																if (5 > b)
																{
																	goto IL_0565_2;
																}
																goto IL_06e5_2;
																IL_0565_2:
																if (2 < b)
																{
																	goto IL_0570_2;
																}
																num = 166;
																goto IL_059a_2;
																IL_0570_2:
																if (3 >= b)
																{
																	goto IL_057e_2;
																}
																goto IL_0651_2;
																IL_057e_2:
																if (3 > b)
																{
																	break;
																}
																goto IL_0aba_2;
																IL_0aba_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0ae3_2;
																IL_0ae3_2:
																ptr2 += 8;
																goto IL_0af1_2;
																IL_0af1_2:
																num6--;
																goto IL_0dc7_2;
																IL_0651_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_065f_2;
																IL_065f_2:
																if (4 > b)
																{
																	break;
																}
																num = 169;
																goto IL_0676_2;
																IL_09f3_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)AbortRequestedAppDomainInitializer[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_0a32_2;
																IL_0676_2:
																array2[num6] = 0;
																goto IL_0684_2;
																IL_0684_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																goto IL_06a7_2;
																IL_06a7_2:
																array3[num6] = null;
																goto IL_06b1_2;
																IL_06b1_2:
																num6++;
																goto IL_06bf_2;
																IL_06bf_2:
																ptr2 += 8;
																goto IL_0dc7_2;
																IL_0817_2:
																array2[num6 - 1] = 0;
																goto IL_09f3_2;
																IL_059a_2:
																if (2 > b)
																{
																	goto IL_05a5_2;
																}
																num = 209;
																goto IL_098c_2;
																IL_05a5_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_05b3_2;
																IL_05b3_2:
																if (1 > b)
																{
																}
																break;
																IL_0a32_2:
																ptr2 += 8;
																goto IL_0dc7_2;
																IL_098c_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_09cc_2;
																IL_09cc_2:
																array2[num6 - 2] = 0;
																goto IL_09e0_2;
																IL_09e0_2:
																num6--;
																goto IL_0dc7_2;
																IL_06e5_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0725_2;
																IL_0725_2:
																array2[num6 - 2] = 0;
																goto IL_0739_2;
															}
															break;
															IL_0474_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0d9d_2;
													IL_0db9_2:
													ptr2 += 8;
													goto IL_0dc7_2;
													IL_0dab_2:
													num6++;
													goto IL_0db9_2;
													IL_0d9d_2:
													array2[num6] = 0;
													goto IL_0dab_2;
													continue;
													end_IL_0484_2:
													break;
												}
												continue;
												end_IL_0494:
												break;
											}
											continue;
											end_IL_04ad:
											break;
										}
										break;
									}
									goto IL_0e9c_2;
									IL_0e9c_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_096b:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0379, IL_038c, IL_039f, IL_03ac, IL_03bc, IL_03cc, IL_03d9, IL_03e9, IL_03f9, IL_0409, IL_0414, IL_041f, IL_042d, IL_0445, IL_0453, IL_0461, IL_046f, IL_0478, IL_0486, IL_0491, IL_04a4, IL_04ad, IL_04bb, IL_04c9, IL_04d7, IL_04fa, IL_0504, IL_0512, IL_0525, IL_0530, IL_053e, IL_0551, IL_0591, IL_05a5, IL_05b8, IL_0601, IL_0615, IL_0628, IL_0636, IL_0641, IL_064f, IL_0662, IL_0670, IL_06b0, IL_06c4, IL_06d7, IL_06e2, IL_06f5, IL_0700, IL_070e, IL_074e, IL_0762, IL_0775, IL_0783, IL_0791, IL_07d1, IL_07e5, IL_07f8, IL_085a, IL_086d, IL_0896, IL_08ad, IL_08c0, IL_08ce, IL_08ea, IL_08f8, IL_0903, IL_0911, IL_091f, IL_0933, IL_096b, IL_097e, IL_098c, IL_09ca, IL_09dd, IL_09ff, IL_0a0d, IL_0a1b, IL_0a2e, IL_0a39, IL_0a47, IL_0a5f, IL_0a76, IL_0a89, IL_0a92, IL_0aa0, IL_0aae, IL_0abc, IL_0aca, IL_0ae7, IL_0b36, IL_0b40, IL_0b6d, IL_0b81, IL_0b8f, IL_0ba2, IL_0bc0, IL_0bce, IL_0be1, IL_0bef, IL_0bfd, IL_0c0b, IL_0c2c, IL_0c4a, IL_0c6e, IL_0c86, IL_0c99, IL_0ca4, IL_0ccd, IL_0ce3, IL_0cfc, IL_0d0a, IL_0d18, IL_0d26, IL_0d39, IL_0d43, IL_0d4e, IL_0d5e, IL_0d77, IL_0d87, IL_0d97, IL_0da7, IL_0db7, IL_0dc7, IL_0dd7, IL_0dfb are reachable both inside and outside the pinned region starting at IL_0dec. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 79;
			int num5 = default(int);
			int num8 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				byte* num6;
				int num7;
				object[] array8;
				int num9;
				byte* num10;
				int __rxRef9 = default(int);
				ref int reference = ref __rxRef9;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					num = 78;
					while (true)
					{
						IL_0dd7:
						num2 = 1;
						while (true)
						{
							IL_0dc7:
							num3 = num2 * 4;
							while (true)
							{
								IL_0db7:
								num4 = num2 * 8;
								while (true)
								{
									IL_0da7:
									array2 = new byte[4];
									while (true)
									{
										IL_0d97:
										array3 = new object[4];
										while (true)
										{
											IL_0d87:
											array4 = new int[4];
											while (true)
											{
												IL_0d77:
												array5 = new int[6];
												while (true)
												{
													IL_0d5e:
													array6 = new long[4];
													num = 164;
													while (true)
													{
														IL_0d4e:
														array7 = new object[16];
														while (true)
														{
															IL_0d43:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCultureNamesetNumberNegativePattern.getCultureNamesetNumberNegativePattern_0);
															while (true)
															{
																IL_0d39:
																ptr2 = ptr;
																while (true)
																{
																	IL_0d26:
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_0409:
																			byte b = *ptr2;
																			while (true)
																			{
																				IL_03f9:
																				ptr2++;
																				while (true)
																				{
																					IL_03e9:
																					if (b >= 1)
																					{
																						while (b <= 21)
																						{
																							while (true)
																							{
																								IL_03cc:
																								if (11 < b)
																								{
																									while (true)
																									{
																										IL_03bc:
																										if (16 < b)
																										{
																											while (true)
																											{
																												IL_03ac:
																												if (19 < b)
																												{
																													while (true)
																													{
																														IL_039f:
																														if (20 < b)
																														{
																															while (21 >= b)
																															{
																																num = 215;
																																while (true)
																																{
																																	if (num != 215)
																																	{
																																		if (num != 1196)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 79:
																																			break;
																																		default:
																																			continue;
																																		case 109:
																																			goto IL_038c;
																																		case 20:
																																		case 31:
																																			goto IL_039f;
																																		case 24:
																																		case 145:
																																			goto IL_03ac;
																																		case 149:
																																			goto IL_03bc;
																																		case 48:
																																			goto IL_03cc;
																																		case 138:
																																			goto IL_03d9;
																																		case 154:
																																			goto IL_03e9;
																																		case 203:
																																			goto IL_03f9;
																																		case 107:
																																		case 181:
																																			goto IL_0409;
																																		case 93:
																																			goto IL_041f;
																																		case 140:
																																		case 171:
																																			goto IL_042d;
																																		case 202:
																																			goto IL_0445;
																																		case 30:
																																			goto IL_0453;
																																		case 10:
																																			goto IL_0461;
																																		case 38:
																																		case 160:
																																			goto IL_0478;
																																		case 0:
																																		case 191:
																																			goto IL_0486;
																																		case 12:
																																			goto IL_0491;
																																		case 89:
																																		case 102:
																																			goto IL_04ad;
																																		case 52:
																																			goto IL_04bb;
																																		case 126:
																																		case 167:
																																			goto IL_04c9;
																																		case 146:
																																			goto IL_04d7;
																																		case 42:
																																			goto IL_04fa;
																																		case 119:
																																			goto IL_0504;
																																		case 6:
																																			goto IL_0512;
																																		case 72:
																																			goto IL_0525;
																																		case 33:
																																		case 199:
																																			goto IL_0530;
																																		case 75:
																																			goto IL_053e;
																																		case 11:
																																		case 40:
																																			goto IL_0551;
																																		case 83:
																																			goto IL_0591;
																																		case 90:
																																			goto IL_05a5;
																																		case 108:
																																		case 139:
																																			goto IL_05b8;
																																		case 94:
																																			goto IL_0601;
																																		case 178:
																																			goto IL_0615;
																																		case 123:
																																			goto IL_0628;
																																		case 5:
																																		case 76:
																																			goto IL_0636;
																																		case 156:
																																		case 194:
																																			goto IL_0641;
																																		case 162:
																																			goto IL_064f;
																																		case 3:
																																			goto IL_0662;
																																		case 88:
																																		case 128:
																																			goto IL_0670;
																																		case 46:
																																			goto IL_06b0;
																																		case 26:
																																			goto IL_06c4;
																																		case 47:
																																			goto IL_06d7;
																																		case 136:
																																		case 196:
																																			goto end_IL_0379;
																																		case 121:
																																			goto IL_06f5;
																																		case 141:
																																			goto IL_0700;
																																		case 69:
																																		case 142:
																																			goto IL_070e;
																																		case 163:
																																			goto IL_074e;
																																		case 127:
																																			goto IL_0762;
																																		case 113:
																																			goto IL_0775;
																																		case 106:
																																			goto IL_0783;
																																		case 58:
																																		case 198:
																																			goto IL_0791;
																																		case 176:
																																			goto IL_07d1;
																																		case 159:
																																			goto IL_07e5;
																																		case 87:
																																		case 204:
																																			goto IL_07f8;
																																		case 100:
																																			goto IL_085a;
																																		case 56:
																																		case 206:
																																			goto IL_086d;
																																		case 17:
																																			goto IL_0896;
																																		case 195:
																																			goto IL_08ad;
																																		case 118:
																																		case 208:
																																			goto IL_08ce;
																																		case 168:
																																			goto IL_08ea;
																																		case 114:
																																		case 187:
																																			goto IL_08f8;
																																		case 55:
																																		case 122:
																																			goto IL_0903;
																																		case 137:
																																			goto IL_0911;
																																		case 155:
																																		case 157:
																																			goto IL_091f;
																																		case 148:
																																			goto IL_0933;
																																		case 175:
																																			goto IL_096b;
																																		case 62:
																																			goto IL_097e;
																																		case 67:
																																		case 110:
																																			goto IL_098c;
																																		case 39:
																																			goto IL_09ca;
																																		case 36:
																																		case 51:
																																			goto IL_09dd;
																																		case 63:
																																			goto IL_09ff;
																																		case 43:
																																			goto IL_0a0d;
																																		case 95:
																																			goto IL_0a1b;
																																		case 166:
																																			goto IL_0a2e;
																																		case 27:
																																		case 125:
																																			goto IL_0a39;
																																		case 104:
																																			goto IL_0a47;
																																		case 179:
																																			goto IL_0a5f;
																																		case 29:
																																			goto IL_0a76;
																																		case 177:
																																		case 193:
																																			goto IL_0a92;
																																		case 13:
																																			goto IL_0aa0;
																																		case 4:
																																			goto IL_0aae;
																																		case 66:
																																			goto IL_0abc;
																																		case 98:
																																		case 173:
																																			goto IL_0aca;
																																		case 1:
																																			goto IL_0b81;
																																		case 2:
																																			goto IL_0b8f;
																																		case 91:
																																		case 165:
																																			goto IL_0ba2;
																																		case 18:
																																			goto IL_0bc0;
																																		case 77:
																																			goto IL_0bce;
																																		case 120:
																																		case 201:
																																			goto IL_0be1;
																																		case 49:
																																		case 68:
																																			goto IL_0bef;
																																		case 184:
																																			goto IL_0bfd;
																																		case 60:
																																		case 70:
																																			goto IL_0c0b;
																																		case 84:
																																			goto IL_0c2c;
																																		case 22:
																																			goto IL_0c4a;
																																		case 169:
																																			goto IL_0c6e;
																																		case 57:
																																			goto IL_0c86;
																																		case 112:
																																			goto IL_0c99;
																																		case 15:
																																		case 132:
																																			goto IL_0ca4;
																																		case 92:
																																			goto IL_0ccd;
																																		case 7:
																																		case 9:
																																		case 14:
																																		case 16:
																																		case 21:
																																		case 23:
																																		case 25:
																																		case 28:
																																		case 34:
																																		case 35:
																																		case 41:
																																		case 45:
																																		case 54:
																																		case 71:
																																		case 74:
																																		case 82:
																																		case 85:
																																		case 86:
																																		case 115:
																																		case 129:
																																		case 130:
																																		case 133:
																																		case 134:
																																		case 135:
																																		case 143:
																																		case 144:
																																		case 151:
																																		case 172:
																																		case 180:
																																		case 182:
																																		case 183:
																																		case 186:
																																		case 188:
																																		case 192:
																																		case 200:
																																		case 207:
																																			goto end_IL_038c;
																																		case 189:
																																			goto IL_0cfc;
																																		case 97:
																																			goto IL_0d0a;
																																		case 150:
																																			goto IL_0d18;
																																		case 32:
																																		case 44:
																																		case 50:
																																		case 53:
																																		case 59:
																																		case 61:
																																		case 64:
																																		case 65:
																																		case 80:
																																		case 81:
																																		case 96:
																																		case 99:
																																		case 105:
																																		case 111:
																																		case 124:
																																		case 131:
																																		case 152:
																																		case 153:
																																		case 158:
																																		case 161:
																																		case 170:
																																		case 185:
																																		case 190:
																																		case 197:
																																			goto IL_0d26;
																																		case 101:
																																			goto IL_0d39;
																																		case 174:
																																			goto IL_0d43;
																																		case 164:
																																			goto IL_0d4e;
																																		case 73:
																																			goto IL_0d5e;
																																		case 19:
																																			goto IL_0d77;
																																		case 205:
																																			goto IL_0d87;
																																		case 116:
																																			goto IL_0d97;
																																		case 103:
																																			goto IL_0da7;
																																		case 37:
																																			goto IL_0db7;
																																		case 8:
																																			goto IL_0dc7;
																																		case 78:
																																			goto IL_0dd7;
																																		case 117:
																																		case 147:
																																			goto IL_0dfb;
																																		}
																																		goto end_IL_03e9;
																																	}
																																	if (21 > b)
																																	{
																																		goto end_IL_038c;
																																	}
																																	goto IL_08ce;
																																	IL_08ce:
																																	num6 = ptr2;
																																	num7 = -200;
																																	num5 = 1;
																																	ptr2 = num6 + num7;
																																	goto IL_0d26;
																																	continue;
																																	end_IL_0379:
																																	break;
																																}
																																goto IL_06e2;
																																continue;
																																end_IL_038c:
																																break;
																																IL_038c:;
																															}
																															break;
																														}
																														goto IL_041f;
																														IL_042d:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														goto IL_0d26;
																														IL_041f:
																														if (20 > b)
																														{
																															break;
																														}
																														goto IL_042d;
																													}
																													break;
																												}
																												goto IL_08ea;
																												IL_0a1b:
																												ptr2 += 16;
																												goto IL_0d26;
																												IL_08ea:
																												if (19 > b)
																												{
																													goto IL_08f8;
																												}
																												goto IL_09dd;
																												IL_08f8:
																												if (17 < b)
																												{
																													goto IL_0903;
																												}
																												goto IL_097e;
																												IL_0903:
																												if (18 < b)
																												{
																													break;
																												}
																												goto IL_0911;
																												IL_0911:
																												if (18 > b)
																												{
																													break;
																												}
																												goto IL_091f;
																												IL_091f:
																												array2[num8 - 1] = 5;
																												goto IL_0933;
																												IL_0933:
																												array3[num8 - 1] = ((delegate*<string[], string>)ProgIdRedirectionEntryStoreOperationMetadataProperty[*(int*)(ptr2 + num3)])((string[])array3[num8 - 1]);
																												goto IL_096b;
																												IL_096b:
																												ptr2 += 8;
																												goto IL_0d26;
																												IL_097e:
																												if (17 > b)
																												{
																													break;
																												}
																												goto IL_098c;
																												IL_098c:
																												((string[])array3[num8 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2])] = (string)array3[num8 - 1];
																												goto IL_09ca;
																												IL_09ca:
																												num8 -= 3;
																												goto IL_0d26;
																												IL_09dd:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)(ptr2 + num4);
																												num = 63;
																												goto IL_09ff;
																												IL_09ff:
																												array2[num8] = 1;
																												goto IL_0a0d;
																												IL_0a0d:
																												num8++;
																												goto IL_0a1b;
																											}
																											break;
																										}
																										goto IL_0a2e;
																										IL_0c6e:
																										array3[num8] = array3[num8 - 1];
																										goto IL_0c86;
																										IL_0a2e:
																										if (16 <= b)
																										{
																											goto IL_0a39;
																										}
																										num = 193;
																										goto IL_0a92;
																										IL_0a39:
																										array2[num8] = 5;
																										goto IL_0a47;
																										IL_0a47:
																										array3[num8] = array7[*(int*)(ptr2 + num3)];
																										goto IL_0a5f;
																										IL_0a5f:
																										num8++;
																										num = 29;
																										goto IL_0a76;
																										IL_0a76:
																										ptr2 += 8;
																										goto IL_0d26;
																										IL_0c86:
																										num8++;
																										goto IL_0d26;
																										IL_0a92:
																										if (13 >= b)
																										{
																											goto IL_0aa0;
																										}
																										goto IL_0be1;
																										IL_0aa0:
																										if (13 > b)
																										{
																											goto IL_0aae;
																										}
																										goto IL_0ba2;
																										IL_0aae:
																										if (12 < b)
																										{
																											break;
																										}
																										goto IL_0abc;
																										IL_0abc:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0aca;
																										IL_0aca:
																										array8 = array3;
																										num9 = num8;
																										if (array == null)
																										{
																											goto IL_0ad9;
																										}
																										num10 = ptr2;
																										byte b2 = *num10;
																										ptr2 = num10 + 4;
																										int num11 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num11;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_0b81;
																										IL_0c99:
																										if (14 > b)
																										{
																											break;
																										}
																										goto IL_0ca4;
																										IL_0ca4:
																										array3[num8 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])];
																										goto IL_0ccd;
																										IL_0ccd:
																										array2[num8 - 1] = 5;
																										goto IL_0d26;
																										IL_0b81:
																										array2[num8] = 5;
																										goto IL_0b8f;
																										IL_0b8f:
																										num8++;
																										goto IL_0d26;
																										IL_0ba2:
																										array7[*(int*)(ptr2 + num3)] = array3[num8 - 1];
																										goto IL_0bc0;
																										IL_0bc0:
																										ptr2 += 8;
																										goto IL_0bce;
																										IL_0bce:
																										num8--;
																										goto IL_0d26;
																										IL_0be1:
																										if (14 < b)
																										{
																											goto IL_0bef;
																										}
																										goto IL_0c99;
																										IL_0bef:
																										if (15 < b)
																										{
																											break;
																										}
																										goto IL_0bfd;
																										IL_0bfd:
																										if (15 > b)
																										{
																											break;
																										}
																										goto IL_0c0b;
																										IL_0c0b:
																										array2[num8] = array2[num8 - 1];
																										num = 84;
																										goto IL_0c2c;
																										IL_0c2c:
																										array4[num8 - 0] = array4[num8 - 1];
																										goto IL_0c4a;
																										IL_0c4a:
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																										goto IL_0c6e;
																									}
																									break;
																								}
																								num = 202;
																								goto IL_0445;
																								IL_0783:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0791;
																								IL_0791:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_07d1;
																								IL_0445:
																								if (11 <= b)
																								{
																									goto IL_0d26;
																								}
																								goto IL_0453;
																								IL_0453:
																								if (5 >= b)
																								{
																									goto IL_0461;
																								}
																								goto IL_0628;
																								IL_0461:
																								if (5 > b)
																								{
																									num = 38;
																									goto IL_0478;
																								}
																								goto IL_05b8;
																								IL_07d1:
																								array2[num8 - 2] = 0;
																								goto IL_07e5;
																								IL_0478:
																								if (2 < b)
																								{
																									goto IL_0486;
																								}
																								goto IL_0525;
																								IL_0486:
																								if (3 >= b)
																								{
																									goto IL_0491;
																								}
																								num = 89;
																								goto IL_04ad;
																								IL_0491:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_086d;
																								IL_086d:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_0896;
																								IL_0896:
																								ptr2 += 8;
																								num = 195;
																								goto IL_08ad;
																								IL_08ad:
																								num8--;
																								goto IL_0d26;
																								IL_07e5:
																								num8--;
																								goto IL_0d26;
																								IL_04ad:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_04bb;
																								IL_04bb:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_04c9;
																								IL_04c9:
																								array2[num8] = 0;
																								goto IL_04d7;
																								IL_04d7:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = array5[*(int*)(ptr2 + num3)];
																								goto IL_04fa;
																								IL_04fa:
																								array3[num8] = null;
																								goto IL_0504;
																								IL_0504:
																								num8++;
																								goto IL_0512;
																								IL_0512:
																								ptr2 += 8;
																								goto IL_0d26;
																								IL_0525:
																								if (2 > b)
																								{
																									goto IL_0530;
																								}
																								goto IL_0551;
																								IL_0530:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_053e;
																								IL_053e:
																								if (1 <= b)
																								{
																								}
																								break;
																								IL_0551:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_0591;
																								IL_0591:
																								array2[num8 - 2] = 0;
																								goto IL_05a5;
																								IL_05a5:
																								num8--;
																								goto IL_0d26;
																								IL_05b8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								num = 94;
																								goto IL_0601;
																								IL_0601:
																								array2[num8 - 2] = 0;
																								goto IL_0615;
																								IL_0615:
																								num8--;
																								goto IL_0d26;
																								IL_0628:
																								if (8 < b)
																								{
																									goto IL_0636;
																								}
																								goto IL_06d7;
																								IL_0636:
																								if (9 < b)
																								{
																									goto IL_0641;
																								}
																								goto IL_0662;
																								IL_0641:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_064f;
																								IL_064f:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_07f8;
																								IL_07f8:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_085a;
																								IL_085a:
																								num8 -= 2;
																								goto IL_0d26;
																								IL_0662:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0670;
																								IL_0670:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_06b0;
																								IL_06b0:
																								array2[num8 - 2] = 0;
																								goto IL_06c4;
																								IL_06c4:
																								num8--;
																								goto IL_0d26;
																								IL_06d7:
																								if (8 <= b)
																								{
																									goto IL_06e2;
																								}
																								goto IL_06f5;
																								IL_06e2:
																								num8--;
																								goto IL_0d26;
																								IL_06f5:
																								if (6 >= b)
																								{
																									goto IL_0700;
																								}
																								goto IL_0775;
																								IL_0700:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_070e;
																								IL_070e:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																								goto IL_074e;
																								IL_074e:
																								array2[num8 - 2] = 0;
																								goto IL_0762;
																								IL_0762:
																								num8--;
																								goto IL_0d26;
																								IL_0775:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_0783;
																							}
																							break;
																							IL_03d9:;
																						}
																					}
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(int*)(ptr2 + num3);
																					goto IL_0cfc;
																					IL_0d18:
																					ptr2 += 8;
																					goto IL_0d26;
																					IL_0d0a:
																					num8++;
																					goto IL_0d18;
																					IL_0cfc:
																					array2[num8] = 0;
																					goto IL_0d0a;
																					continue;
																					end_IL_03e9:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	goto IL_0dfb;
																	IL_0dfb:
																	return (string)array3[num8 - 1];
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0ad9:
				while (true)
				{
					IL_0ad9_2:
					array = new byte[4];
					while (true)
					{
						IL_0ae7:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num8] = 5;
							while (true)
							{
								IL_0b8f_2:
								num8++;
								while (true)
								{
									IL_0d26_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_03e9_2:
													if (b >= 1)
													{
														while (b <= 21)
														{
															while (true)
															{
																IL_03cc_2:
																if (11 < b)
																{
																	while (true)
																	{
																		IL_03bc_2:
																		if (16 < b)
																		{
																			while (true)
																			{
																				IL_03ac_2:
																				if (19 < b)
																				{
																					while (true)
																					{
																						IL_039f_2:
																						if (20 < b)
																						{
																							while (21 >= b)
																							{
																								num = 215;
																								while (true)
																								{
																									if (num != 215)
																									{
																										if (num != 1196)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 109:
																											goto IL_038c_2;
																										case 20:
																										case 31:
																											goto IL_039f_2;
																										case 24:
																										case 145:
																											goto IL_03ac_2;
																										case 149:
																											goto IL_03bc_2;
																										case 48:
																											goto IL_03cc_2;
																										case 138:
																											goto IL_03d9_2;
																										case 154:
																											goto IL_03e9_2;
																										case 203:
																											goto end_IL_03e9_2;
																										case 107:
																										case 181:
																											goto end_IL_03f9;
																										case 93:
																											goto IL_041f_2;
																										case 140:
																										case 171:
																											goto IL_042d_2;
																										case 202:
																											goto IL_0445_2;
																										case 30:
																											goto IL_0453_2;
																										case 10:
																											goto IL_0461_2;
																										case 38:
																										case 160:
																											goto IL_0478_2;
																										case 0:
																										case 191:
																											goto IL_0486_2;
																										case 12:
																											goto IL_0491_2;
																										case 89:
																										case 102:
																											goto IL_04ad_2;
																										case 52:
																											goto IL_04bb_2;
																										case 126:
																										case 167:
																											goto IL_04c9_2;
																										case 146:
																											goto IL_04d7_2;
																										case 42:
																											goto IL_04fa_2;
																										case 119:
																											goto IL_0504_2;
																										case 6:
																											goto IL_0512_2;
																										case 72:
																											goto IL_0525_2;
																										case 33:
																										case 199:
																											goto IL_0530_2;
																										case 75:
																											goto IL_053e_2;
																										case 11:
																										case 40:
																											goto IL_0551_2;
																										case 83:
																											goto IL_0591_2;
																										case 90:
																											goto IL_05a5_2;
																										case 108:
																										case 139:
																											goto IL_05b8_2;
																										case 94:
																											goto IL_0601_2;
																										case 178:
																											goto IL_0615_2;
																										case 123:
																											goto IL_0628_2;
																										case 5:
																										case 76:
																											goto IL_0636_2;
																										case 156:
																										case 194:
																											goto IL_0641_2;
																										case 162:
																											goto IL_064f_2;
																										case 3:
																											goto IL_0662_2;
																										case 88:
																										case 128:
																											goto IL_0670_2;
																										case 46:
																											goto IL_06b0_2;
																										case 26:
																											goto IL_06c4_2;
																										case 47:
																											goto IL_06d7_2;
																										case 136:
																										case 196:
																											goto end_IL_0379_2;
																										case 121:
																											goto IL_06f5_2;
																										case 141:
																											goto IL_0700_2;
																										case 69:
																										case 142:
																											goto IL_070e_2;
																										case 163:
																											goto IL_074e_2;
																										case 127:
																											goto IL_0762_2;
																										case 113:
																											goto IL_0775_2;
																										case 106:
																											goto IL_0783_2;
																										case 58:
																										case 198:
																											goto IL_0791_2;
																										case 176:
																											goto IL_07d1_2;
																										case 159:
																											goto IL_07e5_2;
																										case 87:
																										case 204:
																											goto IL_07f8_2;
																										case 100:
																											goto IL_085a_2;
																										case 56:
																										case 206:
																											goto IL_086d_2;
																										case 17:
																											goto IL_0896_2;
																										case 195:
																											goto IL_08ad_2;
																										case 118:
																										case 208:
																											goto IL_08ce_2;
																										case 168:
																											goto IL_08ea_2;
																										case 114:
																										case 187:
																											goto IL_08f8_2;
																										case 55:
																										case 122:
																											goto IL_0903_2;
																										case 137:
																											goto IL_0911_2;
																										case 155:
																										case 157:
																											goto IL_091f_2;
																										case 148:
																											goto IL_0933_2;
																										case 175:
																											goto IL_096b_2;
																										case 62:
																											goto IL_097e_2;
																										case 67:
																										case 110:
																											goto IL_098c_2;
																										case 39:
																											goto IL_09ca_2;
																										case 36:
																										case 51:
																											goto IL_09dd_2;
																										case 63:
																											goto IL_09ff_2;
																										case 43:
																											goto IL_0a0d_2;
																										case 95:
																											goto IL_0a1b_2;
																										case 166:
																											goto IL_0a2e_2;
																										case 27:
																										case 125:
																											goto IL_0a39_2;
																										case 104:
																											goto IL_0a47_2;
																										case 179:
																											goto IL_0a5f_2;
																										case 29:
																											goto IL_0a76_2;
																										case 177:
																										case 193:
																											goto IL_0a92_2;
																										case 13:
																											goto IL_0aa0_2;
																										case 4:
																											goto IL_0aae_2;
																										case 66:
																											goto IL_0abc_2;
																										case 98:
																										case 173:
																											goto IL_0aca_2;
																										case 1:
																											goto end_IL_0409;
																										case 2:
																											goto IL_0b8f_2;
																										case 91:
																										case 165:
																											goto IL_0ba2_2;
																										case 18:
																											goto IL_0bc0_2;
																										case 77:
																											goto IL_0bce_2;
																										case 120:
																										case 201:
																											goto IL_0be1_2;
																										case 49:
																										case 68:
																											goto IL_0bef_2;
																										case 184:
																											goto IL_0bfd_2;
																										case 60:
																										case 70:
																											goto IL_0c0b_2;
																										case 84:
																											goto IL_0c2c_2;
																										case 22:
																											goto IL_0c4a_2;
																										case 169:
																											goto IL_0c6e_2;
																										case 57:
																											goto IL_0c86_2;
																										case 112:
																											goto IL_0c99_2;
																										case 15:
																										case 132:
																											goto IL_0ca4_2;
																										case 92:
																											goto IL_0ccd_2;
																										case 7:
																										case 9:
																										case 14:
																										case 16:
																										case 21:
																										case 23:
																										case 25:
																										case 28:
																										case 34:
																										case 35:
																										case 41:
																										case 45:
																										case 54:
																										case 71:
																										case 74:
																										case 82:
																										case 85:
																										case 86:
																										case 115:
																										case 129:
																										case 130:
																										case 133:
																										case 134:
																										case 135:
																										case 143:
																										case 144:
																										case 151:
																										case 172:
																										case 180:
																										case 182:
																										case 183:
																										case 186:
																										case 188:
																										case 192:
																										case 200:
																										case 207:
																											goto end_IL_038c_2;
																										case 189:
																											goto IL_0cfc_2;
																										case 97:
																											goto IL_0d0a_2;
																										case 150:
																											goto IL_0d18_2;
																										case 32:
																										case 44:
																										case 50:
																										case 53:
																										case 59:
																										case 61:
																										case 64:
																										case 65:
																										case 80:
																										case 81:
																										case 96:
																										case 99:
																										case 105:
																										case 111:
																										case 124:
																										case 131:
																										case 152:
																										case 153:
																										case 158:
																										case 161:
																										case 170:
																										case 185:
																										case 190:
																										case 197:
																											goto IL_0d26_2;
																										case 101:
																											ptr2 = ptr;
																											goto IL_0d26_2;
																										case 174:
																											ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCultureNamesetNumberNegativePattern.getCultureNamesetNumberNegativePattern_0);
																											goto case 101;
																										case 164:
																											array7 = new object[16];
																											goto case 174;
																										case 73:
																											array6 = new long[4];
																											num = 164;
																											goto case 164;
																										case 19:
																											array5 = new int[6];
																											goto case 73;
																										case 205:
																											array4 = new int[4];
																											goto case 19;
																										case 116:
																											array3 = new object[4];
																											goto case 205;
																										case 103:
																											array2 = new byte[4];
																											goto case 116;
																										case 37:
																											num4 = num2 * 8;
																											goto case 103;
																										case 8:
																											num3 = num2 * 4;
																											goto case 37;
																										case 78:
																											num2 = 1;
																											goto case 8;
																										case 79:
																											goto end_IL_0b81;
																										case 117:
																										case 147:
																											goto IL_0dfb_2;
																										}
																										continue;
																									}
																									if (21 > b)
																									{
																										goto end_IL_038c_2;
																									}
																									goto IL_08ce_2;
																									IL_08ce_2:
																									num6 = ptr2;
																									num7 = -200;
																									num5 = 1;
																									ptr2 = num6 + num7;
																									goto IL_0d26_2;
																									continue;
																									end_IL_0379_2:
																									break;
																								}
																								goto IL_06e2_2;
																								continue;
																								end_IL_038c_2:
																								break;
																								IL_038c_2:;
																							}
																							break;
																						}
																						goto IL_041f_2;
																						IL_042d_2:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_0d26_2;
																						IL_041f_2:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_042d_2;
																					}
																					break;
																				}
																				goto IL_08ea_2;
																				IL_0a1b_2:
																				ptr2 += 16;
																				goto IL_0d26_2;
																				IL_08ea_2:
																				if (19 > b)
																				{
																					goto IL_08f8_2;
																				}
																				goto IL_09dd_2;
																				IL_08f8_2:
																				if (17 < b)
																				{
																					goto IL_0903_2;
																				}
																				goto IL_097e_2;
																				IL_0903_2:
																				if (18 < b)
																				{
																					break;
																				}
																				goto IL_0911_2;
																				IL_0911_2:
																				if (18 > b)
																				{
																					break;
																				}
																				goto IL_091f_2;
																				IL_091f_2:
																				array2[num8 - 1] = 5;
																				goto IL_0933_2;
																				IL_0933_2:
																				array3[num8 - 1] = ((delegate*<string[], string>)ProgIdRedirectionEntryStoreOperationMetadataProperty[*(int*)(ptr2 + num3)])((string[])array3[num8 - 1]);
																				goto IL_096b_2;
																				IL_096b_2:
																				ptr2 += 8;
																				goto IL_0d26_2;
																				IL_097e_2:
																				if (17 > b)
																				{
																					break;
																				}
																				goto IL_098c_2;
																				IL_098c_2:
																				((string[])array3[num8 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2])] = (string)array3[num8 - 1];
																				goto IL_09ca_2;
																				IL_09ca_2:
																				num8 -= 3;
																				goto IL_0d26_2;
																				IL_09dd_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)(ptr2 + num4);
																				num = 63;
																				goto IL_09ff_2;
																				IL_09ff_2:
																				array2[num8] = 1;
																				goto IL_0a0d_2;
																				IL_0a0d_2:
																				num8++;
																				goto IL_0a1b_2;
																			}
																			break;
																		}
																		goto IL_0a2e_2;
																		IL_0ca4_2:
																		array3[num8 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])];
																		goto IL_0ccd_2;
																		IL_0a2e_2:
																		if (16 <= b)
																		{
																			goto IL_0a39_2;
																		}
																		num = 193;
																		goto IL_0a92_2;
																		IL_0a39_2:
																		array2[num8] = 5;
																		goto IL_0a47_2;
																		IL_0a47_2:
																		array3[num8] = array7[*(int*)(ptr2 + num3)];
																		goto IL_0a5f_2;
																		IL_0a5f_2:
																		num8++;
																		num = 29;
																		goto IL_0a76_2;
																		IL_0a76_2:
																		ptr2 += 8;
																		goto IL_0d26_2;
																		IL_0ccd_2:
																		array2[num8 - 1] = 5;
																		goto IL_0d26_2;
																		IL_0a92_2:
																		if (13 >= b)
																		{
																			goto IL_0aa0_2;
																		}
																		goto IL_0be1_2;
																		IL_0aa0_2:
																		if (13 > b)
																		{
																			goto IL_0aae_2;
																		}
																		goto IL_0ba2_2;
																		IL_0aae_2:
																		if (12 < b)
																		{
																			break;
																		}
																		goto IL_0abc_2;
																		IL_0abc_2:
																		if (12 > b)
																		{
																			break;
																		}
																		goto IL_0aca_2;
																		IL_0aca_2:
																		array8 = array3;
																		num9 = num8;
																		if (array == null)
																		{
																			goto IL_0ad9_2;
																		}
																		goto IL_0ae7;
																		IL_0ba2_2:
																		array7[*(int*)(ptr2 + num3)] = array3[num8 - 1];
																		goto IL_0bc0_2;
																		IL_0bc0_2:
																		ptr2 += 8;
																		goto IL_0bce_2;
																		IL_0bce_2:
																		num8--;
																		goto IL_0d26_2;
																		IL_0be1_2:
																		if (14 < b)
																		{
																			goto IL_0bef_2;
																		}
																		goto IL_0c99_2;
																		IL_0bef_2:
																		if (15 < b)
																		{
																			break;
																		}
																		goto IL_0bfd_2;
																		IL_0bfd_2:
																		if (15 > b)
																		{
																			break;
																		}
																		goto IL_0c0b_2;
																		IL_0c0b_2:
																		array2[num8] = array2[num8 - 1];
																		num = 84;
																		goto IL_0c2c_2;
																		IL_0c2c_2:
																		array4[num8 - 0] = array4[num8 - 1];
																		goto IL_0c4a_2;
																		IL_0c4a_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																		goto IL_0c6e_2;
																		IL_0c6e_2:
																		array3[num8] = array3[num8 - 1];
																		goto IL_0c86_2;
																		IL_0c86_2:
																		num8++;
																		goto IL_0d26_2;
																		IL_0c99_2:
																		if (14 > b)
																		{
																			break;
																		}
																		goto IL_0ca4_2;
																	}
																	break;
																}
																num = 202;
																goto IL_0445_2;
																IL_0783_2:
																if (7 > b)
																{
																	break;
																}
																goto IL_0791_2;
																IL_0791_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_07d1_2;
																IL_0445_2:
																if (11 <= b)
																{
																	goto IL_0d26_2;
																}
																goto IL_0453_2;
																IL_0453_2:
																if (5 >= b)
																{
																	goto IL_0461_2;
																}
																goto IL_0628_2;
																IL_0461_2:
																if (5 > b)
																{
																	num = 38;
																	goto IL_0478_2;
																}
																goto IL_05b8_2;
																IL_07d1_2:
																array2[num8 - 2] = 0;
																goto IL_07e5_2;
																IL_0478_2:
																if (2 < b)
																{
																	goto IL_0486_2;
																}
																goto IL_0525_2;
																IL_0486_2:
																if (3 >= b)
																{
																	goto IL_0491_2;
																}
																num = 89;
																goto IL_04ad_2;
																IL_0491_2:
																if (3 > b)
																{
																	break;
																}
																goto IL_086d_2;
																IL_086d_2:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_0896_2;
																IL_0896_2:
																ptr2 += 8;
																num = 195;
																goto IL_08ad_2;
																IL_08ad_2:
																num8--;
																goto IL_0d26_2;
																IL_07e5_2:
																num8--;
																goto IL_0d26_2;
																IL_04ad_2:
																if (4 < b)
																{
																	break;
																}
																goto IL_04bb_2;
																IL_04bb_2:
																if (4 > b)
																{
																	break;
																}
																goto IL_04c9_2;
																IL_04c9_2:
																array2[num8] = 0;
																goto IL_04d7_2;
																IL_04d7_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = array5[*(int*)(ptr2 + num3)];
																goto IL_04fa_2;
																IL_04fa_2:
																array3[num8] = null;
																goto IL_0504_2;
																IL_0504_2:
																num8++;
																goto IL_0512_2;
																IL_0512_2:
																ptr2 += 8;
																goto IL_0d26_2;
																IL_0525_2:
																if (2 > b)
																{
																	goto IL_0530_2;
																}
																goto IL_0551_2;
																IL_0530_2:
																if (1 < b)
																{
																	break;
																}
																goto IL_053e_2;
																IL_053e_2:
																if (1 <= b)
																{
																}
																break;
																IL_0551_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_0591_2;
																IL_0591_2:
																array2[num8 - 2] = 0;
																goto IL_05a5_2;
																IL_05a5_2:
																num8--;
																goto IL_0d26_2;
																IL_05b8_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																num = 94;
																goto IL_0601_2;
																IL_0601_2:
																array2[num8 - 2] = 0;
																goto IL_0615_2;
																IL_0615_2:
																num8--;
																goto IL_0d26_2;
																IL_0628_2:
																if (8 < b)
																{
																	goto IL_0636_2;
																}
																goto IL_06d7_2;
																IL_0636_2:
																if (9 < b)
																{
																	goto IL_0641_2;
																}
																goto IL_0662_2;
																IL_0641_2:
																if (10 < b)
																{
																	break;
																}
																goto IL_064f_2;
																IL_064f_2:
																if (10 > b)
																{
																	break;
																}
																goto IL_07f8_2;
																IL_07f8_2:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_085a_2;
																IL_085a_2:
																num8 -= 2;
																goto IL_0d26_2;
																IL_0662_2:
																if (9 > b)
																{
																	break;
																}
																goto IL_0670_2;
																IL_0670_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_06b0_2;
																IL_06b0_2:
																array2[num8 - 2] = 0;
																goto IL_06c4_2;
																IL_06c4_2:
																num8--;
																goto IL_0d26_2;
																IL_06d7_2:
																if (8 <= b)
																{
																	goto IL_06e2_2;
																}
																goto IL_06f5_2;
																IL_06e2_2:
																num8--;
																goto IL_0d26_2;
																IL_06f5_2:
																if (6 >= b)
																{
																	goto IL_0700_2;
																}
																goto IL_0775_2;
																IL_0700_2:
																if (6 > b)
																{
																	break;
																}
																goto IL_070e_2;
																IL_070e_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8 - 1]);
																goto IL_074e_2;
																IL_074e_2:
																array2[num8 - 2] = 0;
																goto IL_0762_2;
																IL_0762_2:
																num8--;
																goto IL_0d26_2;
																IL_0775_2:
																if (7 < b)
																{
																	break;
																}
																goto IL_0783_2;
															}
															break;
															IL_03d9_2:;
														}
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num8]) = *(int*)(ptr2 + num3);
													goto IL_0cfc_2;
													IL_0d18_2:
													ptr2 += 8;
													goto IL_0d26_2;
													IL_0d0a_2:
													num8++;
													goto IL_0d18_2;
													IL_0cfc_2:
													array2[num8] = 0;
													goto IL_0d0a_2;
													continue;
													end_IL_03e9_2:
													break;
												}
												continue;
												end_IL_03f9:
												break;
											}
											continue;
											end_IL_0409:
											break;
										}
										break;
									}
									goto IL_0dfb_2;
									IL_0dfb_2:
									return (string)array3[num8 - 1];
								}
								break;
							}
							continue;
							end_IL_0b81:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class103()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_13(int int_3)
	{
		int num = 32;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 31;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetDeclaredStaticMethodgetXmlSegment.CreateAttributeCallbackCos);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_028e:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_027e:
																		if (b <= 11)
																		{
																			while (true)
																			{
																				IL_0271:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0261:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0254:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0247:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (5 <= b)
																												{
																													while (true)
																													{
																														IL_020e:
																														array[num5] = 0;
																														num = 123;
																														while (true)
																														{
																															if (num != 123)
																															{
																																if (num != 1104)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 60:
																																case 69:
																																	goto IL_020e;
																																case 49:
																																	goto IL_0227;
																																case 13:
																																	goto IL_0237;
																																case 95:
																																	goto IL_0247;
																																case 74:
																																case 97:
																																	goto IL_0254;
																																case 28:
																																	goto IL_0261;
																																case 46:
																																	goto IL_0271;
																																case 23:
																																	goto IL_027e;
																																case 84:
																																	goto IL_028e;
																																case 82:
																																	goto end_IL_028e;
																																case 73:
																																case 81:
																																	goto end_IL_029e;
																																case 25:
																																	goto IL_02b9;
																																case 59:
																																	goto IL_02cc;
																																case 3:
																																case 24:
																																	goto IL_02da;
																																case 1:
																																case 70:
																																	goto IL_02f2;
																																case 38:
																																	goto IL_02fd;
																																case 37:
																																	goto IL_0316;
																																case 0:
																																	goto IL_0321;
																																case 15:
																																case 75:
																																	goto IL_032f;
																																case 85:
																																	goto IL_034b;
																																case 56:
																																case 106:
																																	goto IL_0367;
																																case 21:
																																case 66:
																																	goto IL_0372;
																																case 98:
																																	goto end_IL_01fb;
																																case 27:
																																case 76:
																																	goto IL_038e;
																																case 71:
																																	goto IL_03b1;
																																case 48:
																																	goto IL_03bf;
																																case 6:
																																	goto IL_03db;
																																case 54:
																																case 87:
																																	goto IL_03e9;
																																case 40:
																																	goto IL_0429;
																																case 61:
																																	goto IL_043d;
																																case 107:
																																	goto IL_0450;
																																case 44:
																																case 108:
																																	goto IL_0463;
																																case 20:
																																	goto IL_04c5;
																																case 109:
																																	goto IL_04d8;
																																case 72:
																																case 111:
																																	goto IL_04eb;
																																case 33:
																																case 45:
																																	goto IL_04f6;
																																case 92:
																																	goto IL_0504;
																																case 14:
																																case 30:
																																	goto IL_0512;
																																case 110:
																																	goto IL_053d;
																																case 41:
																																case 63:
																																	goto IL_054b;
																																case 62:
																																	goto IL_0564;
																																case 17:
																																	goto IL_0572;
																																case 93:
																																	goto IL_0580;
																																case 116:
																																	goto IL_0593;
																																case 103:
																																	goto IL_05a1;
																																case 26:
																																	goto IL_05d7;
																																case 79:
																																	goto IL_05ea;
																																case 89:
																																	goto IL_05f8;
																																case 9:
																																case 22:
																																	goto IL_060b;
																																case 55:
																																	goto IL_064b;
																																case 16:
																																	goto IL_065f;
																																case 5:
																																case 7:
																																case 8:
																																case 10:
																																case 18:
																																case 19:
																																case 34:
																																case 36:
																																case 39:
																																case 43:
																																case 50:
																																case 51:
																																case 58:
																																case 64:
																																case 65:
																																case 67:
																																case 78:
																																case 80:
																																case 83:
																																case 90:
																																case 94:
																																case 102:
																																case 114:
																																	goto end_IL_0227;
																																case 4:
																																case 12:
																																case 47:
																																case 53:
																																case 57:
																																case 68:
																																case 77:
																																case 86:
																																case 88:
																																case 96:
																																case 104:
																																case 112:
																																case 113:
																																case 115:
																																	goto end_IL_02ae;
																																case 99:
																																	goto end_IL_068b;
																																case 29:
																																	goto end_IL_069e;
																																case 11:
																																	goto end_IL_06a8;
																																case 91:
																																	goto end_IL_06b3;
																																case 2:
																																case 105:
																																	goto end_IL_06c8;
																																case 52:
																																	goto end_IL_06d8;
																																case 100:
																																case 101:
																																	goto end_IL_06e8;
																																case 31:
																																	goto end_IL_06f8;
																																case 32:
																																	goto end_IL_0708;
																																case 35:
																																case 42:
																																	goto IL_072c;
																																}
																																continue;
																															}
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																															goto IL_05d7;
																															IL_05d7:
																															array2[num5] = null;
																															num = 79;
																															goto IL_05ea;
																															IL_05f8:
																															ptr2 += 8;
																															goto end_IL_02ae;
																															IL_05ea:
																															num5++;
																															goto IL_05f8;
																															continue;
																															end_IL_01fb:
																															break;
																														}
																														break;
																													}
																													goto IL_0380;
																													continue;
																													end_IL_0227:
																													break;
																													IL_0227:;
																												}
																												break;
																												IL_0237:;
																											}
																											break;
																										}
																										goto IL_02b9;
																										IL_02b9:
																										if (4 > b)
																										{
																											break;
																										}
																										goto end_IL_02ae;
																									}
																									break;
																								}
																								goto IL_02cc;
																								IL_0580:
																								ptr2 += 8;
																								goto end_IL_02ae;
																								IL_02cc:
																								if (3 <= b)
																								{
																									goto IL_02da;
																								}
																								goto IL_04eb;
																								IL_02da:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02ae;
																								IL_04eb:
																								if (1 < b)
																								{
																									goto IL_04f6;
																								}
																								goto IL_053d;
																								IL_04f6:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_0504;
																								IL_0504:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_0512;
																								IL_0512:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0593;
																								IL_0593:
																								ptr2 += 8;
																								goto IL_05a1;
																								IL_05a1:
																								num5--;
																								goto end_IL_02ae;
																								IL_053d:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_054b;
																								IL_054b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_0564;
																								IL_0564:
																								array[num5] = 0;
																								goto IL_0572;
																								IL_0572:
																								num5++;
																								goto IL_0580;
																							}
																							break;
																						}
																						goto IL_060b;
																						IL_065f:
																						num5--;
																						goto end_IL_02ae;
																						IL_060b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_064b;
																						IL_064b:
																						array[num5 - 2] = 0;
																						goto IL_065f;
																					}
																					break;
																				}
																				goto IL_02f2;
																				IL_034b:
																				if (11 < b)
																				{
																					break;
																				}
																				num = 107;
																				goto IL_0450;
																				IL_02f2:
																				if (9 >= b)
																				{
																					goto IL_02fd;
																				}
																				goto IL_0316;
																				IL_02fd:
																				if (9 > b)
																				{
																					num = 106;
																					goto IL_0367;
																				}
																				goto IL_0463;
																				IL_0450:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_0367:
																				if (7 < b)
																				{
																					goto IL_0372;
																				}
																				goto IL_03db;
																				IL_0372:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0380;
																				IL_0380:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_038e;
																				IL_038e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03b1;
																				IL_03b1:
																				array[num5] = 0;
																				goto IL_03bf;
																				IL_03bf:
																				num5++;
																				num = 109;
																				goto IL_04d8;
																				IL_04d8:
																				ptr2 += 8;
																				goto end_IL_02ae;
																				IL_03db:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_03e9;
																				IL_03e9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0429;
																				IL_0429:
																				array[num5 - 2] = 0;
																				goto IL_043d;
																				IL_043d:
																				num5--;
																				goto end_IL_02ae;
																				IL_0463:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_04c5;
																				IL_04c5:
																				num5 -= 2;
																				goto end_IL_02ae;
																				IL_0316:
																				if (10 >= b)
																				{
																					goto IL_0321;
																				}
																				goto IL_034b;
																				IL_0321:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_032f;
																				IL_032f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02ae;
																			}
																		}
																		else
																		{
																			num = 36;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02ae;
																continue;
																end_IL_028e:
																break;
															}
															continue;
															end_IL_029e:
															break;
														}
														continue;
														end_IL_02ae:
														break;
													}
													continue;
												}
												goto IL_072c;
												IL_072c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_068b:
												break;
											}
											continue;
											end_IL_069e:
											break;
										}
										continue;
										end_IL_06a8:
										break;
									}
									continue;
									end_IL_06b3:
									break;
								}
								continue;
								end_IL_06c8:
								break;
							}
							continue;
							end_IL_06d8:
							break;
						}
						continue;
						end_IL_06e8:
						break;
					}
					continue;
					end_IL_06f8:
					break;
				}
				continue;
				end_IL_0708:
				break;
			}
		}
	}

	private unsafe static int smethod_14()
	{
		int num = 114;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									num = 20;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TrimFreeSizeOKsetArgs.SoapStructuralEqualityComparer);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_036d:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0350:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_0340:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_0330:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_0320:
																									if (10 < b)
																									{
																										while (11 >= b)
																										{
																											while (11 <= b)
																											{
																												num = 143;
																												while (true)
																												{
																													IL_02b7:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													while (true)
																													{
																														IL_0298:
																														array[num5 - 2] = 0;
																														num = 154;
																														while (true)
																														{
																															if (num != 154)
																															{
																																if (num != 1135)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 89:
																																	goto IL_0298;
																																case 9:
																																case 143:
																																	goto IL_02b7;
																																case 26:
																																	goto IL_02fd;
																																case 52:
																																	goto IL_0310;
																																case 36:
																																case 81:
																																	goto IL_0320;
																																case 78:
																																	goto IL_0330;
																																case 98:
																																	goto IL_0340;
																																case 43:
																																	goto IL_0350;
																																case 72:
																																	goto IL_035d;
																																case 18:
																																	goto IL_036d;
																																case 71:
																																	goto end_IL_036d;
																																case 24:
																																case 73:
																																	goto end_IL_037d;
																																case 14:
																																	goto IL_0398;
																																case 42:
																																	goto IL_03a6;
																																case 85:
																																	goto IL_03b6;
																																case 84:
																																case 87:
																																	goto IL_03c4;
																																case 44:
																																	goto IL_03d2;
																																case 2:
																																	goto IL_03f5;
																																case 56:
																																	goto IL_03ff;
																																case 17:
																																	goto IL_0416;
																																case 109:
																																	goto IL_0429;
																																case 1:
																																case 16:
																																	goto IL_0434;
																																case 68:
																																	goto IL_0442;
																																case 46:
																																	goto IL_045e;
																																case 63:
																																case 126:
																																	goto IL_046c;
																																case 21:
																																	goto IL_047a;
																																case 3:
																																case 5:
																																	goto IL_0488;
																																case 76:
																																	goto IL_0496;
																																case 93:
																																	goto IL_04ae;
																																case 60:
																																	goto IL_04bc;
																																case 130:
																																	goto IL_04cf;
																																case 54:
																																	goto IL_04dd;
																																case 125:
																																	goto IL_04eb;
																																case 32:
																																case 91:
																																	goto IL_04f6;
																																case 123:
																																	goto IL_0536;
																																case 45:
																																	goto IL_054a;
																																case 58:
																																case 122:
																																	goto IL_055d;
																																case 124:
																																	goto IL_0574;
																																case 100:
																																case 102:
																																	goto IL_0582;
																																case 23:
																																	goto IL_059b;
																																case 27:
																																	goto IL_05a9;
																																case 94:
																																	goto IL_05b7;
																																case 40:
																																case 75:
																																	goto IL_05ca;
																																case 19:
																																	goto IL_05f1;
																																case 8:
																																	goto IL_05ff;
																																case 74:
																																case 134:
																																	goto IL_0612;
																																case 38:
																																	goto IL_0620;
																																case 55:
																																case 140:
																																	goto IL_0633;
																																case 62:
																																	goto IL_0672;
																																case 95:
																																case 142:
																																	goto IL_0685;
																																case 37:
																																case 144:
																																	goto IL_069d;
																																case 112:
																																	goto IL_06c6;
																																case 92:
																																	goto IL_06d4;
																																case 147:
																																	goto IL_06e7;
																																case 69:
																																	goto IL_06f5;
																																case 50:
																																case 86:
																																	goto IL_0703;
																																case 104:
																																	goto IL_072c;
																																case 28:
																																case 108:
																																	goto IL_0761;
																																case 139:
																																	goto IL_07a1;
																																case 77:
																																	goto IL_07b5;
																																case 83:
																																	goto IL_07c8;
																																case 90:
																																	goto IL_07d6;
																																case 12:
																																case 141:
																																	goto IL_07e4;
																																case 67:
																																	goto IL_07f2;
																																case 6:
																																case 34:
																																	goto IL_0800;
																																case 88:
																																	goto IL_086b;
																																case 107:
																																case 117:
																																	goto IL_087b;
																																case 79:
																																case 127:
																																	goto IL_089d;
																																case 116:
																																	goto IL_08a8;
																																case 4:
																																case 7:
																																case 11:
																																case 13:
																																case 15:
																																case 25:
																																case 39:
																																case 41:
																																case 49:
																																case 53:
																																case 61:
																																case 65:
																																case 66:
																																case 70:
																																case 82:
																																case 103:
																																case 105:
																																case 106:
																																case 110:
																																case 111:
																																case 119:
																																case 120:
																																case 121:
																																case 128:
																																case 131:
																																case 135:
																																case 145:
																																	goto end_IL_0285;
																																case 10:
																																case 22:
																																case 30:
																																case 33:
																																case 35:
																																case 47:
																																case 57:
																																case 59:
																																case 64:
																																case 80:
																																case 97:
																																case 101:
																																case 115:
																																case 118:
																																case 129:
																																case 133:
																																case 138:
																																case 146:
																																	goto end_IL_038d;
																																case 96:
																																	goto end_IL_08cf;
																																case 20:
																																	goto end_IL_08e2;
																																case 137:
																																	goto end_IL_08ec;
																																case 136:
																																	goto end_IL_08f7;
																																case 48:
																																case 99:
																																	goto end_IL_0910;
																																case 0:
																																	goto end_IL_0920;
																																case 29:
																																case 31:
																																	goto end_IL_0930;
																																case 113:
																																	goto end_IL_0940;
																																case 114:
																																	goto end_IL_0950;
																																case 51:
																																case 132:
																																	goto IL_096b;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_038d;
																															continue;
																															end_IL_0285:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																												IL_02fd:;
																											}
																											break;
																											IL_0310:;
																										}
																										break;
																									}
																									goto IL_03b6;
																									IL_0620:
																									if (9 <= b)
																									{
																										goto end_IL_038d;
																									}
																									break;
																									IL_03b6:
																									if (10 <= b)
																									{
																										goto IL_03c4;
																									}
																									goto IL_0612;
																									IL_03c4:
																									array[num5] = 0;
																									goto IL_03d2;
																									IL_03d2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_03f5;
																									IL_03f5:
																									array2[num5] = null;
																									goto IL_03ff;
																									IL_03ff:
																									num5++;
																									num = 17;
																									goto IL_0416;
																									IL_0416:
																									ptr2 += 8;
																									goto end_IL_038d;
																									IL_0612:
																									if (9 < b)
																									{
																										break;
																									}
																									goto IL_0620;
																								}
																								break;
																							}
																							goto IL_0761;
																							IL_07b5:
																							num5--;
																							goto end_IL_038d;
																							IL_0761:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07a1;
																							IL_07a1:
																							array[num5 - 2] = 0;
																							goto IL_07b5;
																						}
																						break;
																					}
																					goto IL_07c8;
																					IL_089d:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_08a8;
																					IL_07c8:
																					if (14 >= b)
																					{
																						goto IL_07d6;
																					}
																					num = 127;
																					goto IL_089d;
																					IL_07d6:
																					if (14 > b)
																					{
																						goto IL_07e4;
																					}
																					goto IL_087b;
																					IL_07e4:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_07f2;
																					IL_07f2:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_0800;
																					IL_0800:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 88;
																					goto IL_086b;
																					IL_086b:
																					num5 -= 2;
																					goto end_IL_038d;
																					IL_087b:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_038d;
																					IL_08a8:
																					if (15 > b)
																					{
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_0398;
																			IL_0633:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0672;
																			IL_0398:
																			if (8 > b)
																			{
																				goto IL_03a6;
																			}
																			goto IL_0685;
																			IL_03a6:
																			if (4 < b)
																			{
																				goto IL_0429;
																			}
																			goto IL_04cf;
																			IL_04cf:
																			if (4 > b)
																			{
																				goto IL_04dd;
																			}
																			goto IL_05ca;
																			IL_04dd:
																			if (2 >= b)
																			{
																				goto IL_04eb;
																			}
																			goto IL_06e7;
																			IL_04eb:
																			if (2 <= b)
																			{
																				goto IL_04f6;
																			}
																			goto IL_055d;
																			IL_04f6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0536;
																			IL_0536:
																			array[num5 - 2] = 0;
																			goto IL_054a;
																			IL_054a:
																			num5--;
																			goto end_IL_038d;
																			IL_055d:
																			if (1 < b)
																			{
																				break;
																			}
																			num = 124;
																			goto IL_0574;
																			IL_0672:
																			num5 -= 3;
																			goto end_IL_038d;
																			IL_0574:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0582;
																			IL_0582:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_059b;
																			IL_059b:
																			array[num5] = 0;
																			goto IL_05a9;
																			IL_05a9:
																			num5++;
																			goto IL_05b7;
																			IL_05b7:
																			ptr2 += 8;
																			goto end_IL_038d;
																			IL_06e7:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_06f5;
																			IL_06f5:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0703;
																			IL_0703:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_072c;
																			IL_072c:
																			array[num5 - 1] = 5;
																			num = 59;
																			goto end_IL_038d;
																			IL_05ca:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			num = 19;
																			goto IL_05f1;
																			IL_05f1:
																			ptr2 += 8;
																			goto IL_05ff;
																			IL_05ff:
																			num5--;
																			goto end_IL_038d;
																			IL_0429:
																			if (6 < b)
																			{
																				goto IL_0434;
																			}
																			goto IL_045e;
																			IL_0434:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0442;
																			IL_0442:
																			if (7 > b)
																			{
																				break;
																			}
																			num = 37;
																			goto IL_069d;
																			IL_0685:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_038d;
																			IL_069d:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06c6;
																			IL_06c6:
																			ptr2 += 8;
																			goto IL_06d4;
																			IL_06d4:
																			num5--;
																			goto end_IL_038d;
																			IL_045e:
																			if (6 > b)
																			{
																				goto IL_046c;
																			}
																			goto IL_0633;
																			IL_046c:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_047a;
																			IL_047a:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0488;
																			IL_0488:
																			array[num5] = 5;
																			goto IL_0496;
																			IL_0496:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_04ae;
																			IL_04ae:
																			num5++;
																			goto IL_04bc;
																			IL_04bc:
																			ptr2 += 8;
																			goto end_IL_038d;
																		}
																		break;
																		IL_035d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 133;
																goto end_IL_038d;
																continue;
																end_IL_036d:
																break;
															}
															continue;
															end_IL_037d:
															break;
														}
														continue;
														end_IL_038d:
														break;
													}
													continue;
												}
												goto IL_096b;
												IL_096b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08cf:
												break;
											}
											continue;
											end_IL_08e2:
											break;
										}
										continue;
										end_IL_08ec:
										break;
									}
									continue;
									end_IL_08f7:
									break;
								}
								continue;
								end_IL_0910:
								break;
							}
							continue;
							end_IL_0920:
							break;
						}
						continue;
						end_IL_0930:
						break;
					}
					continue;
					end_IL_0940:
					break;
				}
				continue;
				end_IL_0950:
				break;
			}
		}
	}

	private unsafe static int smethod_15()
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReadCacheDefaultRoleClaimType.VTIgetXmlTypeName);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0399:
														byte b = *ptr2;
														while (true)
														{
															IL_0389:
															ptr2++;
															while (true)
															{
																IL_0379:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		num = 136;
																		while (true)
																		{
																			IL_0356:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_0346:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_0336:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_0329:
																									if (10 < b)
																									{
																										while (11 >= b)
																										{
																											while (11 <= b)
																											{
																												while (true)
																												{
																													IL_02c3:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													while (true)
																													{
																														IL_02a4:
																														array[num5 - 2] = 0;
																														num = 157;
																														while (true)
																														{
																															if (num != 157)
																															{
																																if (num != 1138)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 104:
																																	goto IL_02a4;
																																case 61:
																																case 143:
																																	goto IL_02c3;
																																case 115:
																																	goto IL_0309;
																																case 110:
																																	goto IL_0319;
																																case 11:
																																case 140:
																																	goto IL_0329;
																																case 54:
																																	goto IL_0336;
																																case 57:
																																case 107:
																																	goto IL_0346;
																																case 136:
																																	goto IL_0356;
																																case 0:
																																	goto IL_0366;
																																case 50:
																																	goto IL_0379;
																																case 67:
																																	goto IL_0389;
																																case 21:
																																case 91:
																																	goto IL_0399;
																																case 63:
																																	goto IL_03a4;
																																case 122:
																																	goto IL_03af;
																																case 14:
																																	goto IL_03bd;
																																case 43:
																																case 144:
																																	goto IL_03d0;
																																case 81:
																																	goto IL_03de;
																																case 15:
																																	goto IL_0401;
																																case 7:
																																	goto IL_040b;
																																case 82:
																																	goto IL_0419;
																																case 106:
																																case 124:
																																	goto IL_043f;
																																case 146:
																																	goto IL_047f;
																																case 76:
																																	goto IL_0493;
																																case 148:
																																case 150:
																																	goto IL_04a6;
																																case 17:
																																case 60:
																																	goto IL_04b1;
																																case 64:
																																	goto IL_04bf;
																																case 96:
																																	goto IL_04d2;
																																case 89:
																																	goto IL_04e0;
																																case 137:
																																	goto IL_04ee;
																																case 40:
																																case 58:
																																	goto IL_04fc;
																																case 127:
																																	goto IL_055e;
																																case 125:
																																case 130:
																																	goto IL_0588;
																																case 75:
																																	goto IL_05a4;
																																case 27:
																																case 86:
																																	goto IL_05af;
																																case 13:
																																	goto IL_05c7;
																																case 59:
																																case 132:
																																	goto IL_05d5;
																																case 116:
																																	goto IL_05e3;
																																case 9:
																																case 98:
																																	goto IL_05ee;
																																case 39:
																																	goto IL_062d;
																																case 128:
																																	goto IL_0640;
																																case 133:
																																	goto IL_064e;
																																case 56:
																																case 141:
																																	goto IL_065c;
																																case 73:
																																	goto IL_066a;
																																case 123:
																																	goto IL_0682;
																																case 147:
																																	goto IL_0699;
																																case 105:
																																	goto IL_06ac;
																																case 28:
																																	goto IL_06ba;
																																case 12:
																																case 129:
																																	goto IL_06c5;
																																case 72:
																																	goto IL_06ee;
																																case 23:
																																	goto IL_06fc;
																																case 10:
																																	goto IL_071d;
																																case 112:
																																case 149:
																																	goto IL_072b;
																																case 45:
																																	goto IL_0739;
																																case 1:
																																case 93:
																																	goto IL_0744;
																																case 25:
																																	goto IL_0784;
																																case 120:
																																	goto IL_0798;
																																case 65:
																																case 79:
																																	goto IL_07b4;
																																case 69:
																																	goto IL_07c2;
																																case 90:
																																case 121:
																																	goto IL_07d0;
																																case 26:
																																	goto IL_07f2;
																																case 19:
																																	goto IL_0800;
																																case 22:
																																	goto IL_080e;
																																case 55:
																																case 62:
																																	goto IL_082a;
																																case 99:
																																	goto IL_0838;
																																case 24:
																																case 87:
																																	goto IL_0843;
																																case 47:
																																	goto IL_086c;
																																case 101:
																																case 135:
																																	goto IL_0882;
																																case 68:
																																	goto IL_08a0;
																																case 108:
																																	goto IL_08ae;
																																case 3:
																																case 4:
																																case 31:
																																case 36:
																																case 37:
																																case 41:
																																case 42:
																																case 46:
																																case 48:
																																case 49:
																																case 51:
																																case 53:
																																case 70:
																																case 74:
																																case 78:
																																case 80:
																																case 83:
																																case 84:
																																case 85:
																																case 95:
																																case 97:
																																case 109:
																																case 117:
																																case 118:
																																case 131:
																																case 138:
																																case 139:
																																case 142:
																																case 145:
																																	goto end_IL_0309;
																																case 5:
																																case 6:
																																case 8:
																																case 16:
																																case 18:
																																case 20:
																																case 33:
																																case 34:
																																case 44:
																																case 52:
																																case 66:
																																case 88:
																																case 92:
																																case 102:
																																case 111:
																																case 114:
																																case 119:
																																case 134:
																																	goto end_IL_0291;
																																case 77:
																																	goto end_IL_08d1;
																																case 32:
																																	goto end_IL_08e4;
																																case 35:
																																	goto end_IL_08ee;
																																case 103:
																																	goto end_IL_08f9;
																																case 71:
																																case 100:
																																	goto end_IL_0909;
																																case 113:
																																	goto end_IL_0919;
																																case 94:
																																case 126:
																																	goto end_IL_0929;
																																case 29:
																																	goto end_IL_0939;
																																case 30:
																																	goto end_IL_0949;
																																case 2:
																																case 38:
																																	goto IL_0964;
																																}
																																continue;
																															}
																															num5--;
																															break;
																															continue;
																															end_IL_0291:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_0379;
																												continue;
																												end_IL_0309:
																												break;
																												IL_0309:;
																											}
																											break;
																											IL_0319:;
																										}
																										break;
																									}
																									goto IL_03a4;
																									IL_0419:
																									ptr2 += 8;
																									goto end_IL_0379;
																									IL_03a4:
																									if (10 > b)
																									{
																										goto IL_03af;
																									}
																									goto IL_03d0;
																									IL_03af:
																									if (9 < b)
																									{
																										break;
																									}
																									goto IL_03bd;
																									IL_03bd:
																									if (9 > b)
																									{
																										break;
																									}
																									goto end_IL_0379;
																									IL_03d0:
																									array[num5] = 0;
																									goto IL_03de;
																									IL_03de:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0401;
																									IL_0401:
																									array2[num5] = null;
																									goto IL_040b;
																									IL_040b:
																									num5++;
																									goto IL_0419;
																								}
																								break;
																							}
																							goto IL_043f;
																							IL_0493:
																							num5--;
																							goto end_IL_0379;
																							IL_043f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_047f;
																							IL_047f:
																							array[num5 - 2] = 0;
																							goto IL_0493;
																						}
																						break;
																					}
																					goto IL_04a6;
																					IL_0588:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0379;
																					IL_04a6:
																					if (14 < b)
																					{
																						goto IL_04b1;
																					}
																					goto IL_04d2;
																					IL_04b1:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_04bf;
																					IL_04bf:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_04d2:
																					if (14 > b)
																					{
																						goto IL_04e0;
																					}
																					num = 125;
																					goto IL_0588;
																					IL_04e0:
																					if (13 < b)
																					{
																						num = 95;
																						break;
																					}
																					goto IL_04ee;
																					IL_04ee:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_04fc;
																					IL_04fc:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_055e;
																					IL_055e:
																					num5 -= 2;
																					goto end_IL_0379;
																				}
																				break;
																			}
																			goto IL_05a4;
																			IL_086c:
																			array[num5 - 1] = 5;
																			goto end_IL_0379;
																			IL_05a4:
																			if (8 <= b)
																			{
																				goto IL_05af;
																			}
																			goto IL_05c7;
																			IL_05af:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0379;
																			IL_05c7:
																			if (4 < b)
																			{
																				goto IL_05d5;
																			}
																			goto IL_071d;
																			IL_05d5:
																			if (6 >= b)
																			{
																				goto IL_05e3;
																			}
																			goto IL_06ac;
																			IL_05e3:
																			if (6 <= b)
																			{
																				goto IL_05ee;
																			}
																			goto IL_0640;
																			IL_05ee:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_062d;
																			IL_062d:
																			num5 -= 3;
																			goto end_IL_0379;
																			IL_0640:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_064e;
																			IL_064e:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_065c;
																			IL_065c:
																			array[num5] = 5;
																			goto IL_066a;
																			IL_066a:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0682;
																			IL_0682:
																			num5++;
																			num = 147;
																			goto IL_0699;
																			IL_0699:
																			ptr2 += 8;
																			goto end_IL_0379;
																			IL_06ac:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_06ba;
																			IL_06ba:
																			if (7 > b)
																			{
																				num = 4;
																				break;
																			}
																			goto IL_06c5;
																			IL_06c5:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06ee;
																			IL_06ee:
																			ptr2 += 8;
																			goto IL_06fc;
																			IL_06fc:
																			num5--;
																			goto end_IL_0379;
																			IL_0882:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_08a0;
																			IL_071d:
																			if (4 > b)
																			{
																				goto IL_072b;
																			}
																			goto IL_0882;
																			IL_072b:
																			if (2 >= b)
																			{
																				goto IL_0739;
																			}
																			num = 62;
																			goto IL_082a;
																			IL_0739:
																			if (2 <= b)
																			{
																				goto IL_0744;
																			}
																			num = 65;
																			goto IL_07b4;
																			IL_0744:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0784;
																			IL_0784:
																			array[num5 - 2] = 0;
																			goto IL_0798;
																			IL_0798:
																			num5--;
																			goto end_IL_0379;
																			IL_08ae:
																			num5--;
																			goto end_IL_0379;
																			IL_07b4:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_07c2;
																			IL_07c2:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_07d0;
																			IL_07d0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 26;
																			goto IL_07f2;
																			IL_07f2:
																			array[num5] = 0;
																			goto IL_0800;
																			IL_0800:
																			num5++;
																			goto IL_080e;
																			IL_080e:
																			ptr2 += 8;
																			goto end_IL_0379;
																			IL_08a0:
																			ptr2 += 8;
																			goto IL_08ae;
																			IL_082a:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0838;
																			IL_0838:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0843;
																			IL_0843:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_086c;
																		}
																		break;
																		IL_0366:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0379:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0964;
												IL_0964:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08d1:
												break;
											}
											continue;
											end_IL_08e4:
											break;
										}
										continue;
										end_IL_08ee:
										break;
									}
									continue;
									end_IL_08f9:
									break;
								}
								continue;
								end_IL_0909:
								break;
							}
							continue;
							end_IL_0919:
							break;
						}
						continue;
						end_IL_0929:
						break;
					}
					continue;
					end_IL_0939:
					break;
				}
				continue;
				end_IL_0949:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_3)
	{
		int num = 23;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref XdrStringAlphaBool.getCurrencyGroupSeparatorBelowNormal);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0291:
														byte b = *ptr2;
														while (true)
														{
															IL_0281:
															ptr2++;
															while (true)
															{
																IL_0271:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_0261:
																		if (b <= 10)
																		{
																			while (true)
																			{
																				IL_0251:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0244:
																						if (5 <= b)
																						{
																							while (true)
																							{
																								IL_0234:
																								array[num5] = 0;
																								while (true)
																								{
																									IL_020f:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									while (true)
																									{
																										IL_0203:
																										array2[num5] = null;
																										while (true)
																										{
																											IL_01f3:
																											num5++;
																											while (true)
																											{
																												IL_01da:
																												ptr2 += 8;
																												num = 110;
																												while (num != 110)
																												{
																													if (num != 1091)
																													{
																														goto IL_0281;
																													}
																													switch (num)
																													{
																													case 30:
																														goto IL_01da;
																													case 64:
																														goto IL_01f3;
																													case 68:
																														goto IL_0203;
																													case 45:
																														goto IL_020f;
																													case 63:
																													case 84:
																														goto IL_0234;
																													case 15:
																														goto IL_0244;
																													case 43:
																														goto IL_0251;
																													case 21:
																														goto IL_0261;
																													case 8:
																														goto IL_0271;
																													case 94:
																														goto IL_0281;
																													case 54:
																													case 56:
																														goto IL_0291;
																													case 10:
																													case 58:
																														goto IL_029c;
																													case 13:
																														goto IL_02a7;
																													case 48:
																													case 53:
																														goto IL_02b5;
																													case 26:
																														goto IL_02c3;
																													case 42:
																													case 75:
																														goto IL_02d6;
																													case 9:
																														goto IL_02e1;
																													case 6:
																														goto IL_02f1;
																													case 14:
																														goto IL_02ff;
																													case 3:
																													case 78:
																														goto IL_031b;
																													case 89:
																													case 99:
																														goto IL_033c;
																													case 47:
																														goto IL_0365;
																													case 79:
																														goto IL_0373;
																													case 98:
																													case 100:
																														goto IL_0386;
																													case 74:
																														goto IL_039f;
																													case 70:
																														goto IL_03b6;
																													case 18:
																														goto IL_03c4;
																													case 35:
																													case 65:
																														goto IL_03d7;
																													case 71:
																														goto IL_03e5;
																													case 72:
																													case 83:
																														goto IL_03f0;
																													case 17:
																														goto IL_0452;
																													case 61:
																														goto IL_0465;
																													case 82:
																													case 101:
																														goto IL_0470;
																													case 12:
																														goto IL_047e;
																													case 31:
																													case 76:
																														goto IL_048c;
																													case 0:
																														goto IL_04af;
																													case 92:
																														goto IL_04bd;
																													case 66:
																														goto IL_04cb;
																													case 7:
																														goto IL_04de;
																													case 41:
																													case 91:
																														goto IL_04f5;
																													case 52:
																														goto IL_0535;
																													case 39:
																														goto IL_0549;
																													case 77:
																														goto IL_0559;
																													case 81:
																														goto IL_0564;
																													case 44:
																													case 55:
																														goto IL_056f;
																													case 85:
																														goto IL_0588;
																													case 87:
																														goto IL_0593;
																													case 5:
																													case 24:
																													case 32:
																													case 33:
																													case 34:
																													case 36:
																													case 37:
																													case 38:
																													case 40:
																													case 46:
																													case 49:
																													case 50:
																													case 67:
																													case 80:
																													case 86:
																													case 88:
																													case 90:
																													case 93:
																														goto IL_05b4;
																													case 1:
																													case 2:
																													case 4:
																													case 11:
																													case 16:
																													case 28:
																													case 57:
																													case 69:
																													case 73:
																													case 95:
																													case 97:
																													case 102:
																														goto end_IL_01c7;
																													case 59:
																														goto end_IL_05c7;
																													case 20:
																														goto end_IL_05da;
																													case 62:
																														goto end_IL_05e4;
																													case 96:
																														goto end_IL_05ef;
																													case 19:
																													case 25:
																														goto end_IL_0604;
																													case 29:
																														goto end_IL_0614;
																													case 51:
																													case 60:
																														goto end_IL_0624;
																													case 22:
																														goto end_IL_0634;
																													case 23:
																														goto end_IL_0644;
																													case 27:
																													case 103:
																														goto IL_065f;
																													}
																													continue;
																													end_IL_01c7:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_029c;
																						IL_02ff:
																						if (4 <= b)
																						{
																							num = 95;
																							break;
																						}
																						goto IL_05b4;
																						IL_029c:
																						if (2 >= b)
																						{
																							goto IL_02a7;
																						}
																						goto IL_02d6;
																						IL_02a7:
																						if (2 > b)
																						{
																							goto IL_02b5;
																						}
																						goto IL_033c;
																						IL_02b5:
																						if (1 >= b)
																						{
																							goto IL_02c3;
																						}
																						goto IL_05b4;
																						IL_02c3:
																						if (1 <= b)
																						{
																							goto IL_0386;
																						}
																						goto IL_05b4;
																						IL_0386:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_039f;
																						IL_039f:
																						array[num5] = 0;
																						num = 70;
																						goto IL_03b6;
																						IL_03b6:
																						num5++;
																						goto IL_03c4;
																						IL_03c4:
																						ptr2 += 8;
																						break;
																						IL_033c:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0365;
																						IL_0365:
																						ptr2 += 8;
																						goto IL_0373;
																						IL_0373:
																						num5--;
																						break;
																						IL_02d6:
																						if (3 >= b)
																						{
																							goto IL_02e1;
																						}
																						goto IL_02f1;
																						IL_02e1:
																						if (3 <= b)
																						{
																							goto IL_031b;
																						}
																						goto IL_05b4;
																						IL_031b:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						num = 57;
																						break;
																						IL_02f1:
																						if (4 >= b)
																						{
																							goto IL_02ff;
																						}
																						goto IL_05b4;
																					}
																					break;
																				}
																				goto IL_03d7;
																				IL_0588:
																				if (10 >= b)
																				{
																					goto IL_0593;
																				}
																				goto IL_05b4;
																				IL_03d7:
																				if (8 >= b)
																				{
																					goto IL_03e5;
																				}
																				goto IL_0559;
																				IL_03e5:
																				if (8 <= b)
																				{
																					goto IL_03f0;
																				}
																				goto IL_0465;
																				IL_03f0:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0452;
																				IL_0452:
																				num5 -= 2;
																				break;
																				IL_0465:
																				if (6 < b)
																				{
																					goto IL_0470;
																				}
																				goto IL_04de;
																				IL_0470:
																				if (7 >= b)
																				{
																					goto IL_047e;
																				}
																				goto IL_05b4;
																				IL_047e:
																				if (7 <= b)
																				{
																					goto IL_048c;
																				}
																				goto IL_05b4;
																				IL_048c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04af;
																				IL_04af:
																				array[num5] = 0;
																				goto IL_04bd;
																				IL_04bd:
																				num5++;
																				goto IL_04cb;
																				IL_04cb:
																				ptr2 += 8;
																				break;
																				IL_04de:
																				if (6 <= b)
																				{
																					num = 91;
																					goto IL_04f5;
																				}
																				goto IL_05b4;
																				IL_0593:
																				if (10 > b)
																				{
																				}
																				goto IL_05b4;
																				IL_04f5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0535;
																				IL_0535:
																				array[num5 - 2] = 0;
																				goto IL_0549;
																				IL_0549:
																				num5--;
																				break;
																				IL_0559:
																				if (9 >= b)
																				{
																					goto IL_0564;
																				}
																				goto IL_0588;
																				IL_0564:
																				if (9 <= b)
																				{
																					goto IL_056f;
																				}
																				goto IL_05b4;
																				IL_056f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																			}
																			break;
																		}
																		num = 32;
																		goto IL_05b4;
																	}
																	break;
																}
																num = 93;
																goto IL_05b4;
																IL_05b4:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_065f;
												IL_065f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05c7:
												break;
											}
											continue;
											end_IL_05da:
											break;
										}
										continue;
										end_IL_05e4:
										break;
									}
									continue;
									end_IL_05ef:
									break;
								}
								continue;
								end_IL_0604:
								break;
							}
							continue;
							end_IL_0614:
							break;
						}
						continue;
						end_IL_0624:
						break;
					}
					continue;
					end_IL_0634:
					break;
				}
				continue;
				end_IL_0644:
				break;
			}
		}
	}

	private unsafe static int smethod_17(int int_3)
	{
		int num = 47;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getPriorityStringBuilder.getAreAuditRulesProtectedEndChildren);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 107;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 100;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_028b:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_026b:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_025b:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_024b:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_023b:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_022b:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														num = 122;
																														while (true)
																														{
																															if (num != 122)
																															{
																																if (num != 1103)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 17:
																																case 89:
																																	goto IL_0218;
																																case 7:
																																case 110:
																																	goto IL_022b;
																																case 18:
																																	goto IL_023b;
																																case 69:
																																case 71:
																																	goto IL_024b;
																																case 28:
																																	goto IL_025b;
																																case 86:
																																	goto IL_026b;
																																case 91:
																																	goto IL_027b;
																																case 85:
																																	goto IL_028b;
																																case 24:
																																	goto end_IL_028b;
																																case 100:
																																	goto end_IL_029b;
																																case 5:
																																	goto end_IL_02ab;
																																case 12:
																																case 113:
																																	goto IL_02cf;
																																case 4:
																																	goto IL_02f8;
																																case 45:
																																	goto IL_030f;
																																case 115:
																																	goto IL_0322;
																																case 61:
																																case 90:
																																	goto IL_0330;
																																case 38:
																																	goto IL_0349;
																																case 41:
																																	goto IL_0357;
																																case 74:
																																	goto IL_0365;
																																case 3:
																																case 48:
																																	goto IL_0378;
																																case 30:
																																	goto IL_0390;
																																case 82:
																																	goto IL_039b;
																																case 6:
																																	goto IL_03ae;
																																case 32:
																																	goto IL_03bc;
																																case 37:
																																case 67:
																																	goto IL_03ca;
																																case 111:
																																	goto IL_03d8;
																																case 55:
																																	goto IL_03fb;
																																case 8:
																																	goto IL_0405;
																																case 105:
																																	goto IL_0413;
																																case 59:
																																case 72:
																																	goto IL_0426;
																																case 20:
																																	goto IL_0466;
																																case 42:
																																	goto IL_047a;
																																case 57:
																																	goto IL_048d;
																																case 44:
																																case 60:
																																	goto IL_0498;
																																case 35:
																																	goto IL_04a3;
																																case 23:
																																case 27:
																																	goto IL_04b1;
																																case 102:
																																	goto IL_04cd;
																																case 29:
																																	goto IL_04db;
																																case 16:
																																	goto IL_04ee;
																																case 25:
																																case 83:
																																	goto IL_0505;
																																case 76:
																																	goto IL_0510;
																																case 13:
																																case 79:
																																	goto IL_051e;
																																case 73:
																																	goto IL_055e;
																																case 2:
																																	goto IL_0572;
																																case 9:
																																case 33:
																																	goto IL_058e;
																																case 75:
																																	goto IL_0599;
																																case 19:
																																case 70:
																																	goto IL_05a4;
																																case 98:
																																	goto IL_05c7;
																																case 109:
																																	goto IL_05d5;
																																case 39:
																																	goto IL_05e3;
																																case 0:
																																case 11:
																																case 15:
																																case 31:
																																case 34:
																																case 43:
																																case 50:
																																case 51:
																																case 56:
																																case 62:
																																case 65:
																																case 66:
																																case 78:
																																case 80:
																																case 84:
																																case 88:
																																case 93:
																																case 97:
																																case 99:
																																case 104:
																																case 108:
																																case 112:
																																	goto end_IL_0205;
																																case 14:
																																case 96:
																																	goto IL_060b;
																																case 22:
																																	goto IL_066d;
																																case 1:
																																case 10:
																																case 36:
																																case 40:
																																case 49:
																																case 52:
																																case 54:
																																case 58:
																																case 63:
																																case 94:
																																case 101:
																																case 106:
																																case 107:
																																case 114:
																																	goto end_IL_02b6;
																																case 87:
																																	goto end_IL_067b;
																																case 53:
																																	goto end_IL_068e;
																																case 95:
																																	goto end_IL_06a1;
																																case 92:
																																	goto end_IL_06ac;
																																case 26:
																																case 77:
																																	goto end_IL_06c1;
																																case 81:
																																	goto end_IL_06d1;
																																case 21:
																																case 68:
																																	goto end_IL_06e1;
																																case 46:
																																	goto end_IL_06f1;
																																case 47:
																																	goto end_IL_0701;
																																case 64:
																																case 103:
																																	goto IL_071c;
																																}
																																continue;
																															}
																															if (2 > b)
																															{
																																break;
																															}
																															goto IL_02cf;
																															IL_02cf:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_02f8;
																															IL_030f:
																															num5--;
																															goto end_IL_02b6;
																															IL_02f8:
																															ptr2 += 8;
																															num = 45;
																															goto IL_030f;
																															continue;
																															end_IL_0205:
																															break;
																														}
																														break;
																														IL_0218:;
																													}
																													break;
																												}
																												goto IL_0322;
																												IL_0365:
																												ptr2 += 8;
																												goto end_IL_02b6;
																												IL_0322:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_0330;
																												IL_0330:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_0349;
																												IL_0349:
																												array[num5] = 0;
																												goto IL_0357;
																												IL_0357:
																												num5++;
																												goto IL_0365;
																											}
																											break;
																										}
																										goto IL_0378;
																										IL_0378:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02b6;
																									}
																									break;
																								}
																								goto IL_0390;
																								IL_0413:
																								ptr2 += 8;
																								goto end_IL_02b6;
																								IL_0390:
																								if (4 >= b)
																								{
																									goto IL_039b;
																								}
																								goto IL_03ae;
																								IL_039b:
																								if (4 <= b)
																								{
																									goto end_IL_02b6;
																								}
																								break;
																								IL_03ae:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_03bc;
																								IL_03bc:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_03ca;
																								IL_03ca:
																								array[num5] = 0;
																								goto IL_03d8;
																								IL_03d8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03fb;
																								IL_03fb:
																								array2[num5] = null;
																								goto IL_0405;
																								IL_0405:
																								num5++;
																								goto IL_0413;
																							}
																							break;
																						}
																						goto IL_0426;
																						IL_047a:
																						num5--;
																						goto end_IL_02b6;
																						IL_0426:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0466;
																						IL_0466:
																						array[num5 - 2] = 0;
																						goto IL_047a;
																					}
																					break;
																				}
																				goto IL_048d;
																				IL_05e3:
																				ptr2 += 8;
																				goto end_IL_02b6;
																				IL_048d:
																				if (9 < b)
																				{
																					goto IL_0498;
																				}
																				goto IL_04ee;
																				IL_0498:
																				if (10 >= b)
																				{
																					goto IL_04a3;
																				}
																				goto IL_04cd;
																				IL_04a3:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_04b1;
																				IL_04b1:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02b6;
																				IL_04cd:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_04db;
																				IL_04db:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_04ee:
																				if (9 > b)
																				{
																					num = 25;
																					goto IL_0505;
																				}
																				goto IL_060b;
																				IL_060b:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_066d;
																				IL_0505:
																				if (7 >= b)
																				{
																					goto IL_0510;
																				}
																				num = 9;
																				goto IL_058e;
																				IL_0510:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_051e;
																				IL_051e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_055e;
																				IL_055e:
																				array[num5 - 2] = 0;
																				goto IL_0572;
																				IL_0572:
																				num5--;
																				goto end_IL_02b6;
																				IL_066d:
																				num5 -= 2;
																				goto end_IL_02b6;
																				IL_058e:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0599;
																				IL_0599:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_05a4;
																				IL_05a4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_05c7;
																				IL_05c7:
																				array[num5] = 0;
																				goto IL_05d5;
																				IL_05d5:
																				num5++;
																				goto IL_05e3;
																			}
																			break;
																			IL_027b:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02b6;
																	continue;
																	end_IL_028b:
																	break;
																}
																continue;
																end_IL_029b:
																break;
															}
															continue;
															end_IL_02ab:
															break;
														}
														continue;
														end_IL_02b6:
														break;
													}
													continue;
												}
												goto IL_071c;
												IL_071c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067b:
												break;
											}
											continue;
											end_IL_068e:
											break;
										}
										continue;
										end_IL_06a1:
										break;
									}
									continue;
									end_IL_06ac:
									break;
								}
								continue;
								end_IL_06c1:
								break;
							}
							continue;
							end_IL_06d1:
							break;
						}
						continue;
						end_IL_06e1:
						break;
					}
					continue;
					end_IL_06f1:
					break;
				}
				continue;
				end_IL_0701:
				break;
			}
		}
	}

	private static int smethod_18(int int_3)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num6;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_3;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_3;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		num4 = 36;
		num6 = 3;
		num4 = 12;
		int num7 = smethod_17(12);
		num4 = num7;
		return num;
	}

	private unsafe static int smethod_19(int int_3)
	{
		int num = 25;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getFeaturegetAvailableFreeSpace.MetadataSectionContentTypeGetMaxThreads);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 45;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_025f:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		num = 96;
																		while (true)
																		{
																			IL_023f:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_022f:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_0222:
																							if (10 < b)
																							{
																								while (true)
																								{
																									IL_0212:
																									if (11 < b)
																									{
																										num = 117;
																										while (num != 117)
																										{
																											if (num != 1098)
																											{
																												goto IL_048e;
																											}
																											switch (num)
																											{
																											case 58:
																												goto IL_0212;
																											case 4:
																											case 47:
																												goto IL_0222;
																											case 55:
																												goto IL_022f;
																											case 96:
																												goto IL_023f;
																											case 53:
																												goto IL_024c;
																											case 19:
																												goto IL_025f;
																											case 92:
																												goto end_IL_025f;
																											case 32:
																											case 35:
																												goto end_IL_026f;
																											case 29:
																												goto IL_028a;
																											case 41:
																												goto IL_029d;
																											case 75:
																												goto IL_02b0;
																											case 21:
																											case 44:
																												goto IL_02bb;
																											case 68:
																												goto IL_02fb;
																											case 81:
																												goto IL_030f;
																											case 90:
																												goto IL_0322;
																											case 13:
																												goto IL_0330;
																											case 9:
																											case 14:
																												goto IL_033b;
																											case 88:
																												goto IL_0353;
																											case 15:
																											case 17:
																												goto IL_035e;
																											case 82:
																												goto IL_036c;
																											case 26:
																											case 77:
																												goto IL_037a;
																											case 6:
																												goto IL_03a3;
																											case 86:
																												goto IL_03b1;
																											case 27:
																												goto IL_03c4;
																											case 84:
																											case 87:
																												goto IL_03d2;
																											case 7:
																												goto IL_03eb;
																											case 5:
																												goto IL_03fe;
																											case 79:
																											case 85:
																												goto IL_0409;
																											case 62:
																												goto IL_0417;
																											case 69:
																												goto IL_0427;
																											case 38:
																											case 98:
																												goto IL_043a;
																											case 93:
																												goto IL_0448;
																											case 20:
																												goto IL_046b;
																											case 80:
																												goto IL_0475;
																											case 100:
																											case 101:
																												goto IL_048e;
																											case 104:
																												goto IL_04aa;
																											case 8:
																												goto IL_04b8;
																											case 110:
																												goto IL_04cb;
																											case 71:
																												goto IL_04de;
																											case 40:
																											case 42:
																												goto IL_04ec;
																											case 52:
																												goto IL_04f7;
																											case 31:
																											case 36:
																												goto IL_050e;
																											case 70:
																												goto IL_054e;
																											case 106:
																												goto IL_0562;
																											case 103:
																												goto IL_0575;
																											case 18:
																												goto IL_058c;
																											case 56:
																											case 78:
																												goto IL_059a;
																											case 76:
																												goto IL_05bd;
																											case 39:
																												goto IL_05cb;
																											case 73:
																												goto IL_05d9;
																											case 57:
																											case 105:
																												goto IL_05ec;
																											case 22:
																												goto IL_064e;
																											case 1:
																											case 2:
																											case 10:
																											case 12:
																											case 28:
																											case 37:
																											case 43:
																											case 50:
																											case 51:
																											case 54:
																											case 59:
																											case 61:
																											case 67:
																											case 74:
																											case 83:
																											case 91:
																											case 95:
																											case 108:
																												goto end_IL_01ff;
																											case 0:
																											case 3:
																											case 16:
																											case 30:
																											case 45:
																											case 46:
																											case 49:
																											case 72:
																											case 89:
																											case 94:
																											case 97:
																											case 99:
																											case 107:
																											case 109:
																												goto end_IL_027f;
																											case 66:
																												goto end_IL_067a;
																											case 65:
																												goto end_IL_068d;
																											case 64:
																												goto end_IL_06a0;
																											case 11:
																												goto end_IL_06ab;
																											case 34:
																											case 63:
																												goto end_IL_06c0;
																											case 60:
																												goto end_IL_06d0;
																											case 23:
																											case 102:
																												goto end_IL_06e0;
																											case 24:
																												goto end_IL_06f0;
																											case 25:
																												goto end_IL_0700;
																											case 33:
																											case 48:
																												goto IL_071b;
																											}
																											continue;
																											end_IL_01ff:
																											break;
																										}
																										break;
																									}
																									goto IL_029d;
																									IL_029d:
																									if (11 <= b)
																									{
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_028a;
																							IL_048e:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_027f;
																							IL_028a:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_048e;
																						}
																						break;
																					}
																					goto IL_04de;
																					IL_05d9:
																					ptr2 += 8;
																					goto end_IL_027f;
																					IL_04de:
																					if (9 > b)
																					{
																						goto IL_04ec;
																					}
																					goto IL_05ec;
																					IL_04ec:
																					if (7 >= b)
																					{
																						goto IL_04f7;
																					}
																					goto IL_0575;
																					IL_04f7:
																					if (7 > b)
																					{
																						break;
																					}
																					num = 36;
																					goto IL_050e;
																					IL_05ec:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_064e;
																					IL_050e:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_054e;
																					IL_054e:
																					array[num6 - 2] = 0;
																					goto IL_0562;
																					IL_0562:
																					num6--;
																					goto end_IL_027f;
																					IL_0575:
																					if (8 < b)
																					{
																						break;
																					}
																					num = 18;
																					goto IL_058c;
																					IL_064e:
																					num6 -= 2;
																					goto end_IL_027f;
																					IL_058c:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_059a;
																					IL_059a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05bd;
																					IL_05bd:
																					array[num6] = 0;
																					goto IL_05cb;
																					IL_05cb:
																					num6++;
																					goto IL_05d9;
																				}
																				break;
																			}
																			goto IL_02b0;
																			IL_0427:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_027f;
																			IL_02b0:
																			if (6 <= b)
																			{
																				goto IL_02bb;
																			}
																			goto IL_0322;
																			IL_02bb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_02fb;
																			IL_02fb:
																			array[num6 - 2] = 0;
																			goto IL_030f;
																			IL_030f:
																			num6--;
																			goto end_IL_027f;
																			IL_0322:
																			if (3 >= b)
																			{
																				goto IL_0330;
																			}
																			goto IL_03fe;
																			IL_0330:
																			if (3 <= b)
																			{
																				goto IL_033b;
																			}
																			goto IL_0353;
																			IL_033b:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_027f;
																			IL_0353:
																			if (1 < b)
																			{
																				goto IL_035e;
																			}
																			goto IL_03c4;
																			IL_035e:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_036c;
																			IL_036c:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_037a;
																			IL_037a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_03a3;
																			IL_03a3:
																			ptr2 += 8;
																			goto IL_03b1;
																			IL_03b1:
																			num6--;
																			goto end_IL_027f;
																			IL_03c4:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_03d2;
																			IL_03d2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_03eb;
																			IL_03eb:
																			array[num6] = 0;
																			goto IL_04aa;
																			IL_04aa:
																			num6++;
																			goto IL_04b8;
																			IL_04b8:
																			ptr2 += 8;
																			goto end_IL_027f;
																			IL_03fe:
																			if (4 < b)
																			{
																				goto IL_0409;
																			}
																			goto IL_0427;
																			IL_0409:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0417;
																			IL_0417:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_043a;
																			IL_043a:
																			array[num6] = 0;
																			goto IL_0448;
																			IL_0448:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_046b;
																			IL_046b:
																			array2[num6] = null;
																			goto IL_0475;
																			IL_0475:
																			num6++;
																			num = 110;
																			goto IL_04cb;
																			IL_04cb:
																			ptr2 += 8;
																			goto end_IL_027f;
																		}
																		break;
																		IL_024c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 72;
																goto end_IL_027f;
																continue;
																end_IL_025f:
																break;
															}
															continue;
															end_IL_026f:
															break;
														}
														continue;
														end_IL_027f:
														break;
													}
													continue;
												}
												goto IL_071b;
												IL_071b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_067a:
												break;
											}
											continue;
											end_IL_068d:
											break;
										}
										continue;
										end_IL_06a0:
										break;
									}
									continue;
									end_IL_06ab:
									break;
								}
								continue;
								end_IL_06c0:
								break;
							}
							continue;
							end_IL_06d0:
							break;
						}
						continue;
						end_IL_06e0:
						break;
					}
					continue;
					end_IL_06f0:
					break;
				}
				continue;
				end_IL_0700:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_3)
	{
		int num = 101;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct74.CeqTrademark);
										num = 54;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02f0:
														byte b = *ptr2;
														while (true)
														{
															IL_02e0:
															ptr2++;
															while (true)
															{
																IL_02d0:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02c0:
																		if (b <= 11)
																		{
																			while (true)
																			{
																				IL_02b0:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_02a0:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0293:
																								if (9 > b)
																								{
																									while (true)
																									{
																										IL_0283:
																										if (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_0231:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_021b:
																														array[num5 - 2] = 0;
																														while (true)
																														{
																															IL_0202:
																															num5--;
																															num = 120;
																															while (num != 120)
																															{
																																if (num != 1101)
																																{
																																	goto IL_053c;
																																}
																																switch (num)
																																{
																																case 5:
																																	goto IL_0202;
																																case 36:
																																	goto IL_021b;
																																case 45:
																																case 94:
																																	goto IL_0231;
																																case 108:
																																	goto IL_0273;
																																case 98:
																																	goto IL_0283;
																																case 104:
																																	goto IL_0293;
																																case 113:
																																	goto IL_02a0;
																																case 13:
																																	goto IL_02b0;
																																case 33:
																																	goto IL_02c0;
																																case 109:
																																	goto IL_02d0;
																																case 20:
																																	goto IL_02e0;
																																case 29:
																																case 99:
																																	goto IL_02f0;
																																case 97:
																																case 102:
																																	goto IL_02fb;
																																case 21:
																																	goto IL_035d;
																																case 106:
																																	goto IL_0370;
																																case 17:
																																case 59:
																																	goto IL_037b;
																																case 60:
																																	goto IL_03bb;
																																case 47:
																																	goto IL_03d8;
																																case 55:
																																case 107:
																																	goto IL_03eb;
																																case 7:
																																case 49:
																																	goto IL_03f9;
																																case 41:
																																	goto IL_0404;
																																case 62:
																																	goto IL_0417;
																																case 67:
																																	goto IL_0425;
																																case 6:
																																case 69:
																																	goto IL_0430;
																																case 42:
																																	goto IL_043e;
																																case 58:
																																	goto IL_0461;
																																case 93:
																																	goto IL_046b;
																																case 71:
																																	goto IL_0479;
																																case 22:
																																	goto IL_049a;
																																case 72:
																																case 89:
																																	goto IL_04a5;
																																case 26:
																																case 53:
																																	goto IL_04b0;
																																case 19:
																																	goto IL_04be;
																																case 12:
																																case 35:
																																	goto IL_04cc;
																																case 78:
																																	goto IL_04f5;
																																case 65:
																																	goto IL_0503;
																																case 56:
																																case 64:
																																	goto IL_0516;
																																case 111:
																																	goto IL_052e;
																																case 43:
																																case 80:
																																	goto IL_053c;
																																case 51:
																																	goto IL_0555;
																																case 37:
																																	goto IL_0563;
																																case 105:
																																	goto IL_0571;
																																case 8:
																																	goto IL_0584;
																																case 9:
																																	goto IL_0592;
																																case 24:
																																case 40:
																																	goto IL_05a0;
																																case 74:
																																	goto IL_05c3;
																																case 3:
																																	goto IL_05d1;
																																case 10:
																																	goto IL_05df;
																																case 30:
																																	goto IL_05ef;
																																case 31:
																																case 90:
																																	goto IL_05fa;
																																case 87:
																																	goto IL_0605;
																																case 34:
																																	goto IL_0612;
																																case 61:
																																case 91:
																																	goto IL_061d;
																																case 1:
																																case 4:
																																case 16:
																																case 27:
																																case 28:
																																case 32:
																																case 39:
																																case 46:
																																case 48:
																																case 50:
																																case 52:
																																case 63:
																																case 66:
																																case 73:
																																case 75:
																																case 76:
																																case 81:
																																case 85:
																																case 88:
																																case 92:
																																case 95:
																																	goto end_IL_0273;
																																case 0:
																																case 2:
																																case 14:
																																case 23:
																																case 44:
																																case 57:
																																case 79:
																																case 82:
																																case 84:
																																case 86:
																																case 96:
																																case 103:
																																case 110:
																																	goto end_IL_01ef;
																																case 54:
																																	goto end_IL_0652;
																																case 25:
																																	goto end_IL_0665;
																																case 68:
																																	goto end_IL_066f;
																																case 83:
																																	goto end_IL_0683;
																																case 11:
																																case 77:
																																	goto end_IL_0698;
																																case 70:
																																	goto end_IL_06a8;
																																case 15:
																																case 112:
																																	goto end_IL_06b8;
																																case 100:
																																	goto end_IL_06c8;
																																case 101:
																																	goto end_IL_06d8;
																																case 18:
																																case 38:
																																	goto IL_06f3;
																																}
																																continue;
																																end_IL_01ef:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_02d0;
																												continue;
																												end_IL_0273:
																												break;
																												IL_0273:;
																											}
																											break;
																										}
																										goto IL_0584;
																										IL_05df:
																										ptr2 += 8;
																										goto end_IL_02d0;
																										IL_0584:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_0592;
																										IL_0592:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_05a0;
																										IL_05a0:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_05c3;
																										IL_05c3:
																										array[num5] = 0;
																										goto IL_05d1;
																										IL_05d1:
																										num5++;
																										goto IL_05df;
																									}
																									break;
																								}
																								goto IL_02fb;
																								IL_035d:
																								num5 -= 2;
																								goto end_IL_02d0;
																								IL_02fb:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_035d;
																							}
																							break;
																						}
																						goto IL_05ef;
																						IL_061d:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02d0;
																						IL_05ef:
																						if (10 < b)
																						{
																							goto IL_05fa;
																						}
																						goto IL_0612;
																						IL_05fa:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_0605;
																						IL_0605:
																						if (11 > b)
																						{
																						}
																						break;
																						IL_0612:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_061d;
																					}
																					break;
																				}
																				goto IL_0370;
																				IL_0571:
																				ptr2 += 8;
																				goto end_IL_02d0;
																				IL_0370:
																				if (6 <= b)
																				{
																					goto IL_037b;
																				}
																				goto IL_03eb;
																				IL_037b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03bb;
																				IL_03bb:
																				array[num5 - 2] = 0;
																				num = 47;
																				goto IL_03d8;
																				IL_03d8:
																				num5--;
																				goto end_IL_02d0;
																				IL_03eb:
																				if (3 < b)
																				{
																					goto IL_03f9;
																				}
																				goto IL_049a;
																				IL_03f9:
																				if (4 >= b)
																				{
																					goto IL_0404;
																				}
																				goto IL_0417;
																				IL_0404:
																				if (4 > b)
																				{
																					break;
																				}
																				goto end_IL_02d0;
																				IL_0417:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0425;
																				IL_0425:
																				if (5 > b)
																				{
																					num = 32;
																					break;
																				}
																				goto IL_0430;
																				IL_0430:
																				array[num5] = 0;
																				goto IL_043e;
																				IL_043e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0461;
																				IL_0461:
																				array2[num5] = null;
																				goto IL_046b;
																				IL_046b:
																				num5++;
																				goto IL_0479;
																				IL_0479:
																				ptr2 += 8;
																				goto end_IL_02d0;
																				IL_0516:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_02d0;
																				IL_049a:
																				if (3 > b)
																				{
																					goto IL_04a5;
																				}
																				goto IL_0516;
																				IL_04a5:
																				if (1 < b)
																				{
																					goto IL_04b0;
																				}
																				goto IL_052e;
																				IL_04b0:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_04be;
																				IL_04be:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_04cc;
																				IL_04cc:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04f5;
																				IL_04f5:
																				ptr2 += 8;
																				goto IL_0503;
																				IL_0503:
																				num5--;
																				goto end_IL_02d0;
																				IL_052e:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_053c;
																				IL_053c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0555;
																				IL_0555:
																				array[num5] = 0;
																				goto IL_0563;
																				IL_0563:
																				num5++;
																				goto IL_0571;
																			}
																		}
																		else
																		{
																			num = 16;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_02d0:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06f3;
												IL_06f3:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0652:
												break;
											}
											continue;
											end_IL_0665:
											break;
										}
										continue;
										end_IL_066f:
										break;
									}
									continue;
									end_IL_0683:
									break;
								}
								continue;
								end_IL_0698:
								break;
							}
							continue;
							end_IL_06a8:
							break;
						}
						continue;
						end_IL_06b8:
						break;
					}
					continue;
					end_IL_06c8:
					break;
				}
				continue;
				end_IL_06d8:
				break;
			}
		}
	}

	static Class103()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 5:
								goto end_IL_0039;
							case 2:
								goto end_IL_0046;
							case 3:
								goto end_IL_0052;
							case 0:
								return;
							case 1:
								return;
							case 4:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					continue;
					end_IL_0046:
					break;
				}
				continue;
				end_IL_0052:
				break;
			}
		}
	}
}
