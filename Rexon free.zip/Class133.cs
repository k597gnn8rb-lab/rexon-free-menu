using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Menu Hand: Right", "Settings", "Toggle menu between left and right hand.", false, 16, ModType.const_1, false)]
internal class Class133 : MonoBehaviour
{
	public static bool bool_0;

	private static bool bool_1;

	private static int int_0;

	private static float float_0;

	private static int int_1;

	private static IntPtr[] getControlDomainPolicyIsTypeSpec;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_04cd, IL_04e0, IL_04f3, IL_0503, IL_0513, IL_0523, IL_0533, IL_0543, IL_0553, IL_0563, IL_0573, IL_0583, IL_0593, IL_059e, IL_05a9, IL_05b7, IL_05c5, IL_05dd, IL_05fd, IL_0626, IL_063f, IL_0663, IL_067b, IL_068e, IL_06ac, IL_06ba, IL_06cd, IL_06db, IL_06e9, IL_06f7, IL_0705, IL_0713, IL_075c, IL_0779, IL_078c, IL_07ee, IL_0801, IL_080f, IL_0822, IL_083f, IL_088e, IL_0898, IL_08c5, IL_08d9, IL_08e7, IL_08fa, IL_0903, IL_0911, IL_091f, IL_092d, IL_093b, IL_0949, IL_0957, IL_0960, IL_09a9, IL_09bd, IL_09d0, IL_0a10, IL_0a24, IL_0a37, IL_0a45, IL_0a53, IL_0a93, IL_0aa7, IL_0aba, IL_0ac5, IL_0ad3, IL_0af6, IL_0b00, IL_0b0e, IL_0b21, IL_0b2c, IL_0b3a, IL_0b48, IL_0b71, IL_0b7f, IL_0b92, IL_0b9d, IL_0bdd, IL_0bf1, IL_0c04, IL_0c12, IL_0c20, IL_0c39, IL_0c47, IL_0c55, IL_0c68, IL_0c7b, IL_0c89, IL_0ca1, IL_0caf, IL_0cc2, IL_0cd0, IL_0cde, IL_0ce9, IL_0d01, IL_0d0f, IL_0d26, IL_0d42, IL_0d4d, IL_0d5b, IL_0d69, IL_0d7e, IL_0d91, IL_0d9a, IL_0da5, IL_0db3, IL_0dc1, IL_0dea, IL_0df8, IL_0e0b, IL_0e20, IL_0e33, IL_0e3e, IL_0e4c, IL_0e5f, IL_0e6a, IL_0e78, IL_0e86, IL_0eaf, IL_0ebd, IL_0ed0, IL_0eec, IL_0efa, IL_0f08, IL_0f16, IL_0f21, IL_0f2f, IL_0f3d, IL_0f61, IL_0f6f, IL_0f86, IL_0f99, IL_0fa4, IL_0fb2, IL_0fbb, IL_0fc9, IL_1010, IL_1023, IL_1037, IL_1078, IL_108b, IL_10cc, IL_10e0, IL_10f3, IL_10fe, IL_110c, IL_111a, IL_1132, IL_113d, IL_114b, IL_1159, IL_1173, IL_1186, IL_11e4, IL_11f7, IL_1200, IL_1214, IL_1260, IL_126e, IL_127e, IL_1291, IL_12a4, IL_12ae, IL_12b9, IL_12c9, IL_12e2, IL_12f2, IL_1302, IL_1312, IL_132b, IL_133b, IL_134b are reachable both inside and outside the pinned region starting at IL_1360. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 68;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num6;
			byte* num7;
			int __rxRef48 = default(int);
			ref int reference = ref __rxRef48;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_134b:
					num2 = 1;
					while (true)
					{
						IL_133b:
						num3 = num2 * 4;
						while (true)
						{
							IL_132b:
							array2 = new byte[4];
							while (true)
							{
								IL_1312:
								array3 = new object[4];
								num = 36;
								while (true)
								{
									IL_1302:
									array4 = new int[4];
									while (true)
									{
										IL_12f2:
										array5 = new int[6];
										while (true)
										{
											IL_12e2:
											array6 = new long[4];
											while (true)
											{
												IL_12c9:
												array7 = new object[20];
												num = 140;
												while (true)
												{
													IL_12b9:
													array7[0] = this;
													while (true)
													{
														IL_12ae:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HaveYearUnicodeByteArray.SequentialAllocateBufferFromNotGen);
														while (true)
														{
															IL_12a4:
															ptr2 = ptr;
															while (true)
															{
																IL_1291:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_059e:
																	num = 244;
																	while (true)
																	{
																		IL_0593:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0583:
																			ptr2++;
																			while (true)
																			{
																				IL_0573:
																				if (b >= 1)
																				{
																					while (b <= 31)
																					{
																						while (true)
																						{
																							IL_0553:
																							if (16 >= b)
																							{
																								while (true)
																								{
																									IL_0543:
																									if (16 > b)
																									{
																										while (true)
																										{
																											IL_0533:
																											if (8 < b)
																											{
																												while (true)
																												{
																													IL_0523:
																													if (12 < b)
																													{
																														while (true)
																														{
																															IL_0513:
																															if (14 >= b)
																															{
																																while (true)
																																{
																																	IL_0503:
																																	if (14 > b)
																																	{
																																		while (13 >= b)
																																		{
																																			while (13 <= b)
																																			{
																																				num = 300;
																																				while (true)
																																				{
																																					if (num != 300)
																																					{
																																						if (num != 1281)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 68:
																																							break;
																																						default:
																																							continue;
																																						case 199:
																																							goto IL_04e0;
																																						case 115:
																																							goto IL_04f3;
																																						case 258:
																																							goto IL_0503;
																																						case 24:
																																						case 231:
																																							goto IL_0513;
																																						case 101:
																																							goto IL_0523;
																																						case 144:
																																						case 279:
																																							goto IL_0533;
																																						case 6:
																																							goto IL_0543;
																																						case 179:
																																							goto IL_0553;
																																						case 157:
																																							goto IL_0563;
																																						case 12:
																																							goto IL_0573;
																																						case 213:
																																							goto IL_0583;
																																						case 244:
																																							goto IL_0593;
																																						case 58:
																																							goto IL_059e;
																																						case 108:
																																						case 209:
																																							goto IL_05a9;
																																						case 196:
																																							goto IL_05b7;
																																						case 104:
																																						case 255:
																																							goto IL_05c5;
																																						case 227:
																																							goto IL_05dd;
																																						case 210:
																																						case 269:
																																							goto IL_05fd;
																																						case 16:
																																							goto IL_0626;
																																						case 274:
																																							goto IL_063f;
																																						case 4:
																																							goto IL_0663;
																																						case 185:
																																							goto IL_067b;
																																						case 225:
																																							goto IL_068e;
																																						case 145:
																																							goto IL_06ac;
																																						case 18:
																																							goto IL_06ba;
																																						case 26:
																																							goto IL_06cd;
																																						case 44:
																																						case 103:
																																							goto IL_06db;
																																						case 223:
																																							goto IL_06e9;
																																						case 262:
																																							goto IL_06f7;
																																						case 149:
																																							goto IL_0705;
																																						case 201:
																																						case 245:
																																							goto IL_0713;
																																						case 136:
																																							goto IL_075c;
																																						case 82:
																																							goto IL_0779;
																																						case 46:
																																						case 189:
																																							goto IL_078c;
																																						case 102:
																																							goto IL_07ee;
																																						case 156:
																																							goto IL_0801;
																																						case 11:
																																							goto IL_080f;
																																						case 148:
																																						case 181:
																																							goto IL_0822;
																																						case 147:
																																							goto IL_08d9;
																																						case 40:
																																							goto IL_08e7;
																																						case 203:
																																							goto IL_0903;
																																						case 0:
																																						case 143:
																																							goto IL_0911;
																																						case 211:
																																						case 234:
																																							goto IL_091f;
																																						case 47:
																																							goto IL_092d;
																																						case 170:
																																						case 242:
																																							goto end_IL_04cd;
																																						case 165:
																																							goto IL_0949;
																																						case 128:
																																						case 288:
																																							goto IL_0960;
																																						case 21:
																																							goto IL_09a9;
																																						case 232:
																																							goto IL_09bd;
																																						case 52:
																																						case 135:
																																							goto IL_09d0;
																																						case 118:
																																							goto IL_0a10;
																																						case 2:
																																							goto IL_0a24;
																																						case 249:
																																							goto IL_0a37;
																																						case 226:
																																							goto IL_0a45;
																																						case 17:
																																						case 122:
																																							goto IL_0a53;
																																						case 204:
																																							goto IL_0a93;
																																						case 66:
																																							goto IL_0aa7;
																																						case 138:
																																							goto IL_0aba;
																																						case 32:
																																						case 41:
																																							goto IL_0ac5;
																																						case 292:
																																							goto IL_0ad3;
																																						case 151:
																																							goto IL_0af6;
																																						case 154:
																																							goto IL_0b00;
																																						case 1:
																																							goto IL_0b0e;
																																						case 51:
																																							goto IL_0b21;
																																						case 215:
																																						case 293:
																																							goto IL_0b2c;
																																						case 130:
																																							goto IL_0b3a;
																																						case 107:
																																						case 137:
																																							goto IL_0b48;
																																						case 75:
																																							goto IL_0b71;
																																						case 166:
																																							goto IL_0b7f;
																																						case 273:
																																							goto IL_0b92;
																																						case 56:
																																						case 238:
																																							goto IL_0b9d;
																																						case 202:
																																							goto IL_0bdd;
																																						case 177:
																																							goto IL_0bf1;
																																						case 80:
																																						case 275:
																																							goto IL_0c04;
																																						case 45:
																																							goto IL_0c12;
																																						case 116:
																																						case 261:
																																							goto IL_0c20;
																																						case 57:
																																							goto IL_0c39;
																																						case 218:
																																							goto IL_0c47;
																																						case 150:
																																							goto IL_0c55;
																																						case 50:
																																						case 235:
																																							goto IL_0c68;
																																						case 174:
																																						case 285:
																																							goto IL_0c7b;
																																						case 195:
																																							goto IL_0c89;
																																						case 256:
																																							goto IL_0ca1;
																																						case 84:
																																							goto IL_0caf;
																																						case 27:
																																							goto IL_0cc2;
																																						case 29:
																																							goto IL_0cd0;
																																						case 219:
																																							goto IL_0cde;
																																						case 31:
																																						case 198:
																																							goto IL_0ce9;
																																						case 252:
																																							goto IL_0d01;
																																						case 221:
																																							goto IL_0d0f;
																																						case 187:
																																							goto IL_0d26;
																																						case 43:
																																						case 220:
																																							goto IL_0d42;
																																						case 162:
																																							goto IL_0d4d;
																																						case 124:
																																							goto IL_0d5b;
																																						case 164:
																																						case 251:
																																							goto IL_0d69;
																																						case 49:
																																							goto IL_0d7e;
																																						case 62:
																																							goto IL_0d9a;
																																						case 168:
																																						case 205:
																																							goto IL_0da5;
																																						case 243:
																																							goto IL_0db3;
																																						case 109:
																																						case 259:
																																							goto IL_0dc1;
																																						case 169:
																																							goto IL_0dea;
																																						case 250:
																																							goto IL_0df8;
																																						case 178:
																																						case 212:
																																							goto IL_0e0b;
																																						case 48:
																																							goto IL_0e20;
																																						case 71:
																																							goto IL_0e33;
																																						case 90:
																																						case 233:
																																							goto IL_0e3e;
																																						case 190:
																																							goto IL_0e4c;
																																						case 281:
																																							goto IL_0e5f;
																																						case 8:
																																							goto IL_0e6a;
																																						case 100:
																																							goto IL_0e78;
																																						case 60:
																																						case 186:
																																							goto IL_0e86;
																																						case 290:
																																							goto IL_0eaf;
																																						case 120:
																																							goto IL_0ebd;
																																						case 76:
																																						case 217:
																																							goto IL_0ed0;
																																						case 228:
																																							goto IL_0eec;
																																						case 176:
																																							goto IL_0efa;
																																						case 246:
																																							goto IL_0f08;
																																						case 7:
																																						case 95:
																																							goto IL_0f16;
																																						case 61:
																																						case 264:
																																							goto IL_0f21;
																																						case 114:
																																							goto IL_0f2f;
																																						case 77:
																																						case 105:
																																							goto IL_0f3d;
																																						case 216:
																																							goto IL_0f61;
																																						case 64:
																																							goto IL_0f6f;
																																						case 10:
																																							goto IL_0f86;
																																						case 222:
																																							goto IL_0f99;
																																						case 23:
																																						case 54:
																																							goto IL_0fa4;
																																						case 127:
																																							goto IL_0fbb;
																																						case 69:
																																						case 123:
																																							goto IL_0fc9;
																																						case 89:
																																							goto IL_1010;
																																						case 141:
																																						case 265:
																																							goto IL_1023;
																																						case 117:
																																							goto IL_1037;
																																						case 78:
																																							goto IL_1078;
																																						case 20:
																																						case 253:
																																							goto IL_108b;
																																						case 194:
																																							goto IL_10cc;
																																						case 291:
																																							goto IL_10e0;
																																						case 289:
																																							goto IL_10f3;
																																						case 106:
																																						case 239:
																																							goto IL_10fe;
																																						case 206:
																																							goto IL_110c;
																																						case 92:
																																						case 112:
																																							goto IL_111a;
																																						case 192:
																																							goto IL_1132;
																																						case 72:
																																						case 278:
																																							goto IL_113d;
																																						case 200:
																																							goto IL_114b;
																																						case 25:
																																						case 260:
																																							goto IL_1159;
																																						case 33:
																																							goto IL_1173;
																																						case 160:
																																						case 270:
																																							goto IL_1186;
																																						case 91:
																																							goto IL_11e4;
																																						case 37:
																																						case 159:
																																							goto IL_1200;
																																						case 283:
																																							goto IL_1214;
																																						case 99:
																																							goto IL_1260;
																																						case 55:
																																							goto IL_126e;
																																						case 9:
																																						case 14:
																																						case 15:
																																						case 22:
																																						case 28:
																																						case 34:
																																						case 35:
																																						case 38:
																																						case 42:
																																						case 59:
																																						case 81:
																																						case 83:
																																						case 85:
																																						case 86:
																																						case 88:
																																						case 94:
																																						case 96:
																																						case 97:
																																						case 111:
																																						case 113:
																																						case 119:
																																						case 129:
																																						case 133:
																																						case 134:
																																						case 146:
																																						case 152:
																																						case 153:
																																						case 155:
																																						case 158:
																																						case 161:
																																						case 167:
																																						case 171:
																																						case 180:
																																						case 183:
																																						case 188:
																																						case 208:
																																						case 224:
																																						case 237:
																																						case 240:
																																						case 247:
																																						case 248:
																																						case 254:
																																						case 263:
																																						case 266:
																																						case 267:
																																						case 276:
																																						case 277:
																																						case 280:
																																						case 286:
																																						case 287:
																																							goto end_IL_04e0;
																																						case 13:
																																						case 30:
																																						case 39:
																																						case 53:
																																						case 63:
																																						case 65:
																																						case 70:
																																						case 73:
																																						case 79:
																																						case 87:
																																						case 93:
																																						case 98:
																																						case 110:
																																						case 121:
																																						case 125:
																																						case 126:
																																						case 132:
																																						case 142:
																																						case 163:
																																						case 173:
																																						case 182:
																																						case 184:
																																						case 191:
																																						case 193:
																																						case 197:
																																						case 207:
																																						case 214:
																																						case 229:
																																						case 230:
																																						case 236:
																																						case 241:
																																						case 268:
																																						case 271:
																																						case 284:
																																							goto IL_1291;
																																						case 172:
																																							goto IL_12a4;
																																						case 139:
																																							goto IL_12ae;
																																						case 140:
																																							goto IL_12b9;
																																						case 74:
																																							goto IL_12c9;
																																						case 282:
																																							goto IL_12e2;
																																						case 5:
																																							goto IL_12f2;
																																						case 36:
																																							goto IL_1302;
																																						case 257:
																																							goto IL_1312;
																																						case 19:
																																						case 131:
																																							goto IL_132b;
																																						case 175:
																																							goto IL_133b;
																																						case 67:
																																							goto IL_134b;
																																						case 3:
																																						case 272:
																																							return;
																																						}
																																						goto end_IL_0573;
																																					}
																																					goto IL_068e;
																																					IL_06ac:
																																					ptr2 += 8;
																																					goto IL_06ba;
																																					IL_06ba:
																																					num5--;
																																					goto IL_1291;
																																					IL_068e:
																																					array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																																					goto IL_06ac;
																																					continue;
																																					end_IL_04cd:
																																					break;
																																				}
																																				goto IL_093b;
																																				continue;
																																				end_IL_04e0:
																																				break;
																																				IL_04e0:;
																																			}
																																			break;
																																			IL_04f3:;
																																		}
																																		break;
																																	}
																																	goto IL_05fd;
																																	IL_0626:
																																	array2[num5 - 1] = 5;
																																	goto IL_1291;
																																	IL_05fd:
																																	array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																																	goto IL_0626;
																																}
																																break;
																															}
																															goto IL_05a9;
																															IL_067b:
																															num5++;
																															goto IL_1291;
																															IL_05a9:
																															if (15 < b)
																															{
																																break;
																															}
																															goto IL_05b7;
																															IL_05b7:
																															if (15 > b)
																															{
																																break;
																															}
																															goto IL_05c5;
																															IL_05c5:
																															array2[num5] = array2[num5 - 1];
																															goto IL_05dd;
																															IL_05dd:
																															array4[num5 - 0] = array4[num5 - 1];
																															goto IL_063f;
																															IL_063f:
																															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																															goto IL_0663;
																															IL_0663:
																															array3[num5] = array3[num5 - 1];
																															goto IL_067b;
																														}
																														break;
																													}
																													goto IL_06cd;
																													IL_08d9:
																													array2[num5] = 5;
																													goto IL_08e7;
																													IL_06cd:
																													if (12 > b)
																													{
																														goto IL_06db;
																													}
																													goto IL_0822;
																													IL_06db:
																													if (10 >= b)
																													{
																														goto IL_06e9;
																													}
																													goto IL_0801;
																													IL_06e9:
																													if (10 > b)
																													{
																														goto IL_06f7;
																													}
																													goto IL_078c;
																													IL_06f7:
																													if (9 < b)
																													{
																														break;
																													}
																													goto IL_0705;
																													IL_0705:
																													if (9 > b)
																													{
																														break;
																													}
																													goto IL_0713;
																													IL_0713:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																													num = 136;
																													goto IL_075c;
																													IL_075c:
																													array2[num5 - 2] = 0;
																													num = 82;
																													goto IL_0779;
																													IL_0779:
																													num5--;
																													goto IL_1291;
																													IL_078c:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_07ee;
																													IL_07ee:
																													num5 -= 2;
																													goto IL_1291;
																													IL_0801:
																													if (11 < b)
																													{
																														break;
																													}
																													goto IL_080f;
																													IL_080f:
																													if (11 > b)
																													{
																														break;
																													}
																													goto IL_1291;
																													IL_0822:
																													array8 = array3;
																													num6 = num5;
																													if (array == null)
																													{
																														goto IL_0831;
																													}
																													num7 = ptr2;
																													byte b2 = *num7;
																													ptr2 = num7 + 4;
																													int num8 = *(int*)(ptr2 + num3);
																													ptr2 += 8;
																													byte* ptr3 = ptr2 + num8;
																													byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																													while (ptr2 != ptr3)
																													{
																														*ptr4 = (byte)(*ptr2 ^ b2);
																														ptr2++;
																														ptr4++;
																													}
																													array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																													goto IL_08d9;
																													IL_08e7:
																													num5++;
																													goto IL_1291;
																												}
																												break;
																											}
																											num = 203;
																											goto IL_0903;
																											IL_0c47:
																											num5++;
																											goto IL_0c55;
																											IL_0c55:
																											ptr2 += 8;
																											goto IL_1291;
																											IL_0903:
																											if (8 > b)
																											{
																												goto IL_0911;
																											}
																											goto IL_0c68;
																											IL_0911:
																											if (4 < b)
																											{
																												goto IL_091f;
																											}
																											goto IL_0aba;
																											IL_091f:
																											if (6 >= b)
																											{
																												goto IL_092d;
																											}
																											goto IL_0a37;
																											IL_092d:
																											if (6 > b)
																											{
																												goto IL_093b;
																											}
																											goto IL_09d0;
																											IL_093b:
																											if (5 < b)
																											{
																												break;
																											}
																											goto IL_0949;
																											IL_0949:
																											if (5 > b)
																											{
																												break;
																											}
																											num = 288;
																											goto IL_0960;
																											IL_0c68:
																											num5--;
																											goto IL_1291;
																											IL_0960:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											num = 21;
																											goto IL_09a9;
																											IL_09a9:
																											array2[num5 - 2] = 0;
																											goto IL_09bd;
																											IL_09bd:
																											num5--;
																											goto IL_1291;
																											IL_09d0:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_0a10;
																											IL_0a10:
																											array2[num5 - 2] = 0;
																											goto IL_0a24;
																											IL_0a24:
																											num5--;
																											goto IL_1291;
																											IL_0a37:
																											if (7 < b)
																											{
																												break;
																											}
																											goto IL_0a45;
																											IL_0a45:
																											if (7 > b)
																											{
																												break;
																											}
																											goto IL_0a53;
																											IL_0a53:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_0a93;
																											IL_0a93:
																											array2[num5 - 2] = 0;
																											goto IL_0aa7;
																											IL_0aa7:
																											num5--;
																											goto IL_1291;
																											IL_0aba:
																											if (4 <= b)
																											{
																												goto IL_0ac5;
																											}
																											goto IL_0b21;
																											IL_0ac5:
																											array2[num5] = 0;
																											goto IL_0ad3;
																											IL_0ad3:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_0af6;
																											IL_0af6:
																											array3[num5] = null;
																											goto IL_0b00;
																											IL_0b00:
																											num5++;
																											goto IL_0b0e;
																											IL_0b0e:
																											ptr2 += 8;
																											goto IL_1291;
																											IL_0b21:
																											if (2 < b)
																											{
																												goto IL_0b2c;
																											}
																											goto IL_0b92;
																											IL_0b2c:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_0b3a;
																											IL_0b3a:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_0b48;
																											IL_0b48:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_0b71;
																											IL_0b71:
																											ptr2 += 8;
																											goto IL_0b7f;
																											IL_0b7f:
																											num5--;
																											goto IL_1291;
																											IL_0b92:
																											if (2 <= b)
																											{
																												goto IL_0b9d;
																											}
																											goto IL_0c04;
																											IL_0b9d:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_0bdd;
																											IL_0bdd:
																											array2[num5 - 2] = 0;
																											goto IL_0bf1;
																											IL_0bf1:
																											num5--;
																											goto IL_1291;
																											IL_0c04:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_0c12;
																											IL_0c12:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0c20;
																											IL_0c20:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0c39;
																											IL_0c39:
																											array2[num5] = 0;
																											goto IL_0c47;
																										}
																										break;
																									}
																									goto IL_0c7b;
																									IL_0caf:
																									ptr2 += 8;
																									goto IL_1291;
																									IL_0c7b:
																									array2[num5] = 5;
																									goto IL_0c89;
																									IL_0c89:
																									array3[num5] = array7[*(int*)(ptr2 + num3)];
																									goto IL_0ca1;
																									IL_0ca1:
																									num5++;
																									goto IL_0caf;
																								}
																								break;
																							}
																							goto IL_0cc2;
																							IL_1200:
																							array2[num5 - 2] = 5;
																							goto IL_1214;
																							IL_0cc2:
																							if (24 < b)
																							{
																								goto IL_0cd0;
																							}
																							goto IL_0eec;
																							IL_0cd0:
																							if (28 >= b)
																							{
																								goto IL_0cde;
																							}
																							goto IL_0e33;
																							IL_0cde:
																							if (28 <= b)
																							{
																								goto IL_0ce9;
																							}
																							goto IL_0d42;
																							IL_0ce9:
																							array3[num5] = array7[*(int*)(ptr2 + num3)];
																							goto IL_0d01;
																							IL_0d01:
																							array2[num5] = 5;
																							goto IL_0d0f;
																							IL_0d0f:
																							num5++;
																							num = 187;
																							goto IL_0d26;
																							IL_0d26:
																							ptr2 += 8;
																							num = 39;
																							goto IL_1291;
																							IL_0d42:
																							if (26 < b)
																							{
																								goto IL_0d4d;
																							}
																							num = 62;
																							goto IL_0d9a;
																							IL_0d4d:
																							if (27 < b)
																							{
																								break;
																							}
																							goto IL_0d5b;
																							IL_0d5b:
																							if (27 > b)
																							{
																								break;
																							}
																							goto IL_0d69;
																							IL_0d69:
																							((delegate*<void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])();
																							goto IL_0d7e;
																							IL_0d7e:
																							ptr2 += 8;
																							goto IL_1291;
																							IL_1214:
																							array3[num5 - 2] = ((delegate*<string, string, string>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																							goto IL_1260;
																							IL_0d9a:
																							if (26 > b)
																							{
																								goto IL_0da5;
																							}
																							goto IL_0e0b;
																							IL_0da5:
																							if (25 < b)
																							{
																								break;
																							}
																							goto IL_0db3;
																							IL_0db3:
																							if (25 > b)
																							{
																								break;
																							}
																							goto IL_0dc1;
																							IL_0dc1:
																							((delegate*<string, void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																							goto IL_0dea;
																							IL_0dea:
																							num5--;
																							goto IL_0df8;
																							IL_0df8:
																							ptr2 += 8;
																							goto IL_1291;
																							IL_0e0b:
																							((delegate*<void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])();
																							goto IL_0e20;
																							IL_0e20:
																							ptr2 += 8;
																							goto IL_1291;
																							IL_0e33:
																							if (30 < b)
																							{
																								goto IL_0e3e;
																							}
																							goto IL_0e5f;
																							IL_0e3e:
																							if (31 < b)
																							{
																								break;
																							}
																							goto IL_0e4c;
																							IL_0e4c:
																							if (31 <= b)
																							{
																							}
																							break;
																							IL_0e5f:
																							if (30 > b)
																							{
																								goto IL_0e6a;
																							}
																							goto IL_0ed0;
																							IL_0e6a:
																							if (29 < b)
																							{
																								break;
																							}
																							goto IL_0e78;
																							IL_0e78:
																							if (29 > b)
																							{
																								break;
																							}
																							goto IL_0e86;
																							IL_0e86:
																							((delegate*<UnityEngine.Object, void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((Class133)array3[num5 - 1]);
																							goto IL_0eaf;
																							IL_0eaf:
																							num5--;
																							goto IL_0ebd;
																							IL_0ebd:
																							ptr2 += 8;
																							goto IL_1291;
																							IL_0ed0:
																							num9 = ptr2;
																							num10 = -200;
																							num4 = 1;
																							ptr2 = num9 + num10;
																							goto IL_1291;
																							IL_0eec:
																							if (24 > b)
																							{
																								goto IL_0efa;
																							}
																							num = 159;
																							goto IL_1200;
																							IL_0efa:
																							if (20 >= b)
																							{
																								goto IL_0f08;
																							}
																							goto IL_10f3;
																							IL_0f08:
																							if (20 > b)
																							{
																								goto IL_0f16;
																							}
																							goto IL_108b;
																							IL_0f16:
																							if (18 < b)
																							{
																								goto IL_0f21;
																							}
																							goto IL_0f99;
																							IL_0f21:
																							if (19 < b)
																							{
																								break;
																							}
																							goto IL_0f2f;
																							IL_0f2f:
																							if (19 > b)
																							{
																								break;
																							}
																							goto IL_0f3d;
																							IL_0f3d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_0f61;
																							IL_0f61:
																							array2[num5] = 0;
																							goto IL_0f6f;
																							IL_0f6f:
																							num5++;
																							num = 10;
																							goto IL_0f86;
																							IL_0f86:
																							ptr2 += 8;
																							goto IL_1291;
																							IL_0f99:
																							if (18 > b)
																							{
																								goto IL_0fa4;
																							}
																							goto IL_1023;
																							IL_0fa4:
																							if (17 < b)
																							{
																								break;
																							}
																							num = 127;
																							goto IL_0fbb;
																							IL_126e:
																							ptr2 += 8;
																							goto IL_1291;
																							IL_0fbb:
																							if (17 > b)
																							{
																								break;
																							}
																							goto IL_0fc9;
																							IL_0fc9:
																							((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																							num = 89;
																							goto IL_1010;
																							IL_1010:
																							num5 -= 3;
																							goto IL_1291;
																							IL_1023:
																							array2[num5 - 1] = 5;
																							goto IL_1037;
																							IL_1037:
																							array3[num5 - 1] = ((delegate*<string[], string>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																							num = 78;
																							goto IL_1078;
																							IL_1078:
																							ptr2 += 8;
																							goto IL_1291;
																							IL_108b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0);
																							goto IL_10cc;
																							IL_10cc:
																							array2[num5 - 2] = 0;
																							goto IL_10e0;
																							IL_10e0:
																							num5--;
																							goto IL_1291;
																							IL_10f3:
																							if (22 < b)
																							{
																								goto IL_10fe;
																							}
																							goto IL_1132;
																							IL_10fe:
																							if (23 < b)
																							{
																								break;
																							}
																							goto IL_110c;
																							IL_110c:
																							if (23 > b)
																							{
																								break;
																							}
																							goto IL_111a;
																							IL_111a:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_1291;
																							IL_1132:
																							if (22 > b)
																							{
																								goto IL_113d;
																							}
																							goto IL_1186;
																							IL_113d:
																							if (21 < b)
																							{
																								break;
																							}
																							goto IL_114b;
																							IL_114b:
																							if (21 > b)
																							{
																								break;
																							}
																							goto IL_1159;
																							IL_1159:
																							bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) != 0;
																							goto IL_1173;
																							IL_1173:
																							num5--;
																							goto IL_1291;
																							IL_1186:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_11e4;
																							IL_11e4:
																							num5--;
																							goto IL_1291;
																							IL_1260:
																							num5--;
																							goto IL_126e;
																						}
																						break;
																						IL_0563:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_1291;
																				continue;
																				end_IL_0573:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0831:
			while (true)
			{
				IL_0831_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_08d9_2:
						array2[num5] = 5;
						while (true)
						{
							IL_08e7_2:
							num5++;
							while (true)
							{
								IL_1291_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									num = 244;
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_0573_2:
												if (b >= 1)
												{
													while (b <= 31)
													{
														while (true)
														{
															IL_0553_2:
															if (16 >= b)
															{
																while (true)
																{
																	IL_0543_2:
																	if (16 > b)
																	{
																		while (true)
																		{
																			IL_0533_2:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_0523_2:
																					if (12 < b)
																					{
																						while (true)
																						{
																							IL_0513_2:
																							if (14 >= b)
																							{
																								while (true)
																								{
																									IL_0503_2:
																									if (14 > b)
																									{
																										while (13 >= b)
																										{
																											while (13 <= b)
																											{
																												num = 300;
																												while (true)
																												{
																													if (num != 300)
																													{
																														if (num != 1281)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 199:
																															goto IL_04e0_2;
																														case 115:
																															goto IL_04f3_2;
																														case 258:
																															goto IL_0503_2;
																														case 24:
																														case 231:
																															goto IL_0513_2;
																														case 101:
																															goto IL_0523_2;
																														case 144:
																														case 279:
																															goto IL_0533_2;
																														case 6:
																															goto IL_0543_2;
																														case 179:
																															goto IL_0553_2;
																														case 157:
																															goto IL_0563_2;
																														case 12:
																															goto IL_0573_2;
																														case 213:
																															goto end_IL_0573_2;
																														case 244:
																															goto end_IL_0583;
																														case 58:
																															goto end_IL_0593;
																														case 108:
																														case 209:
																															goto IL_05a9_2;
																														case 196:
																															goto IL_05b7_2;
																														case 104:
																														case 255:
																															goto IL_05c5_2;
																														case 227:
																															goto IL_05dd_2;
																														case 210:
																														case 269:
																															goto IL_05fd_2;
																														case 16:
																															goto IL_0626_2;
																														case 274:
																															goto IL_063f_2;
																														case 4:
																															goto IL_0663_2;
																														case 185:
																															goto IL_067b_2;
																														case 225:
																															goto IL_068e_2;
																														case 145:
																															goto IL_06ac_2;
																														case 18:
																															goto IL_06ba_2;
																														case 26:
																															goto IL_06cd_2;
																														case 44:
																														case 103:
																															goto IL_06db_2;
																														case 223:
																															goto IL_06e9_2;
																														case 262:
																															goto IL_06f7_2;
																														case 149:
																															goto IL_0705_2;
																														case 201:
																														case 245:
																															goto IL_0713_2;
																														case 136:
																															goto IL_075c_2;
																														case 82:
																															goto IL_0779_2;
																														case 46:
																														case 189:
																															goto IL_078c_2;
																														case 102:
																															goto IL_07ee_2;
																														case 156:
																															goto IL_0801_2;
																														case 11:
																															goto IL_080f_2;
																														case 148:
																														case 181:
																															goto end_IL_059e;
																														case 147:
																															goto IL_08d9_2;
																														case 40:
																															goto IL_08e7_2;
																														case 203:
																															goto IL_0903_2;
																														case 0:
																														case 143:
																															goto IL_0911_2;
																														case 211:
																														case 234:
																															goto IL_091f_2;
																														case 47:
																															goto IL_092d_2;
																														case 170:
																														case 242:
																															goto end_IL_04cd_2;
																														case 165:
																															goto IL_0949_2;
																														case 128:
																														case 288:
																															goto IL_0960_2;
																														case 21:
																															goto IL_09a9_2;
																														case 232:
																															goto IL_09bd_2;
																														case 52:
																														case 135:
																															goto IL_09d0_2;
																														case 118:
																															goto IL_0a10_2;
																														case 2:
																															goto IL_0a24_2;
																														case 249:
																															goto IL_0a37_2;
																														case 226:
																															goto IL_0a45_2;
																														case 17:
																														case 122:
																															goto IL_0a53_2;
																														case 204:
																															goto IL_0a93_2;
																														case 66:
																															goto IL_0aa7_2;
																														case 138:
																															goto IL_0aba_2;
																														case 32:
																														case 41:
																															goto IL_0ac5_2;
																														case 292:
																															goto IL_0ad3_2;
																														case 151:
																															goto IL_0af6_2;
																														case 154:
																															goto IL_0b00_2;
																														case 1:
																															goto IL_0b0e_2;
																														case 51:
																															goto IL_0b21_2;
																														case 215:
																														case 293:
																															goto IL_0b2c_2;
																														case 130:
																															goto IL_0b3a_2;
																														case 107:
																														case 137:
																															goto IL_0b48_2;
																														case 75:
																															goto IL_0b71_2;
																														case 166:
																															goto IL_0b7f_2;
																														case 273:
																															goto IL_0b92_2;
																														case 56:
																														case 238:
																															goto IL_0b9d_2;
																														case 202:
																															goto IL_0bdd_2;
																														case 177:
																															goto IL_0bf1_2;
																														case 80:
																														case 275:
																															goto IL_0c04_2;
																														case 45:
																															goto IL_0c12_2;
																														case 116:
																														case 261:
																															goto IL_0c20_2;
																														case 57:
																															goto IL_0c39_2;
																														case 218:
																															goto IL_0c47_2;
																														case 150:
																															goto IL_0c55_2;
																														case 50:
																														case 235:
																															goto IL_0c68_2;
																														case 174:
																														case 285:
																															goto IL_0c7b_2;
																														case 195:
																															goto IL_0c89_2;
																														case 256:
																															goto IL_0ca1_2;
																														case 84:
																															goto IL_0caf_2;
																														case 27:
																															goto IL_0cc2_2;
																														case 29:
																															goto IL_0cd0_2;
																														case 219:
																															goto IL_0cde_2;
																														case 31:
																														case 198:
																															goto IL_0ce9_2;
																														case 252:
																															goto IL_0d01_2;
																														case 221:
																															goto IL_0d0f_2;
																														case 187:
																															goto IL_0d26_2;
																														case 43:
																														case 220:
																															goto IL_0d42_2;
																														case 162:
																															goto IL_0d4d_2;
																														case 124:
																															goto IL_0d5b_2;
																														case 164:
																														case 251:
																															goto IL_0d69_2;
																														case 49:
																															goto IL_0d7e_2;
																														case 62:
																															goto IL_0d9a_2;
																														case 168:
																														case 205:
																															goto IL_0da5_2;
																														case 243:
																															goto IL_0db3_2;
																														case 109:
																														case 259:
																															goto IL_0dc1_2;
																														case 169:
																															goto IL_0dea_2;
																														case 250:
																															goto IL_0df8_2;
																														case 178:
																														case 212:
																															goto IL_0e0b_2;
																														case 48:
																															goto IL_0e20_2;
																														case 71:
																															goto IL_0e33_2;
																														case 90:
																														case 233:
																															goto IL_0e3e_2;
																														case 190:
																															goto IL_0e4c_2;
																														case 281:
																															goto IL_0e5f_2;
																														case 8:
																															goto IL_0e6a_2;
																														case 100:
																															goto IL_0e78_2;
																														case 60:
																														case 186:
																															goto IL_0e86_2;
																														case 290:
																															goto IL_0eaf_2;
																														case 120:
																															goto IL_0ebd_2;
																														case 76:
																														case 217:
																															goto IL_0ed0_2;
																														case 228:
																															goto IL_0eec_2;
																														case 176:
																															goto IL_0efa_2;
																														case 246:
																															goto IL_0f08_2;
																														case 7:
																														case 95:
																															goto IL_0f16_2;
																														case 61:
																														case 264:
																															goto IL_0f21_2;
																														case 114:
																															goto IL_0f2f_2;
																														case 77:
																														case 105:
																															goto IL_0f3d_2;
																														case 216:
																															goto IL_0f61_2;
																														case 64:
																															goto IL_0f6f_2;
																														case 10:
																															goto IL_0f86_2;
																														case 222:
																															goto IL_0f99_2;
																														case 23:
																														case 54:
																															goto IL_0fa4_2;
																														case 127:
																															goto IL_0fbb_2;
																														case 69:
																														case 123:
																															goto IL_0fc9_2;
																														case 89:
																															goto IL_1010_2;
																														case 141:
																														case 265:
																															goto IL_1023_2;
																														case 117:
																															goto IL_1037_2;
																														case 78:
																															goto IL_1078_2;
																														case 20:
																														case 253:
																															goto IL_108b_2;
																														case 194:
																															goto IL_10cc_2;
																														case 291:
																															goto IL_10e0_2;
																														case 289:
																															goto IL_10f3_2;
																														case 106:
																														case 239:
																															goto IL_10fe_2;
																														case 206:
																															goto IL_110c_2;
																														case 92:
																														case 112:
																															goto IL_111a_2;
																														case 192:
																															goto IL_1132_2;
																														case 72:
																														case 278:
																															goto IL_113d_2;
																														case 200:
																															goto IL_114b_2;
																														case 25:
																														case 260:
																															goto IL_1159_2;
																														case 33:
																															goto IL_1173_2;
																														case 160:
																														case 270:
																															goto IL_1186_2;
																														case 91:
																															goto IL_11e4_2;
																														case 37:
																														case 159:
																															goto IL_1200_2;
																														case 283:
																															goto IL_1214_2;
																														case 99:
																															goto IL_1260_2;
																														case 55:
																															goto IL_126e_2;
																														case 9:
																														case 14:
																														case 15:
																														case 22:
																														case 28:
																														case 34:
																														case 35:
																														case 38:
																														case 42:
																														case 59:
																														case 81:
																														case 83:
																														case 85:
																														case 86:
																														case 88:
																														case 94:
																														case 96:
																														case 97:
																														case 111:
																														case 113:
																														case 119:
																														case 129:
																														case 133:
																														case 134:
																														case 146:
																														case 152:
																														case 153:
																														case 155:
																														case 158:
																														case 161:
																														case 167:
																														case 171:
																														case 180:
																														case 183:
																														case 188:
																														case 208:
																														case 224:
																														case 237:
																														case 240:
																														case 247:
																														case 248:
																														case 254:
																														case 263:
																														case 266:
																														case 267:
																														case 276:
																														case 277:
																														case 280:
																														case 286:
																														case 287:
																															goto end_IL_04e0_2;
																														case 13:
																														case 30:
																														case 39:
																														case 53:
																														case 63:
																														case 65:
																														case 70:
																														case 73:
																														case 79:
																														case 87:
																														case 93:
																														case 98:
																														case 110:
																														case 121:
																														case 125:
																														case 126:
																														case 132:
																														case 142:
																														case 163:
																														case 173:
																														case 182:
																														case 184:
																														case 191:
																														case 193:
																														case 197:
																														case 207:
																														case 214:
																														case 229:
																														case 230:
																														case 236:
																														case 241:
																														case 268:
																														case 271:
																														case 284:
																															goto IL_1291_2;
																														case 172:
																															ptr2 = ptr;
																															goto IL_1291_2;
																														case 139:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HaveYearUnicodeByteArray.SequentialAllocateBufferFromNotGen);
																															goto case 172;
																														case 140:
																															array7[0] = this;
																															goto case 139;
																														case 74:
																															array7 = new object[20];
																															num = 140;
																															goto case 140;
																														case 282:
																															array6 = new long[4];
																															goto case 74;
																														case 5:
																															array5 = new int[6];
																															goto case 282;
																														case 36:
																															array4 = new int[4];
																															goto case 5;
																														case 257:
																															array3 = new object[4];
																															num = 36;
																															goto case 36;
																														case 19:
																														case 131:
																															array2 = new byte[4];
																															goto case 257;
																														case 175:
																															num3 = num2 * 4;
																															goto case 19;
																														case 67:
																															num2 = 1;
																															goto case 175;
																														case 68:
																															goto end_IL_083f;
																														case 3:
																														case 272:
																															return;
																														}
																														continue;
																													}
																													goto IL_068e_2;
																													IL_06ac_2:
																													ptr2 += 8;
																													goto IL_06ba_2;
																													IL_06ba_2:
																													num5--;
																													goto IL_1291_2;
																													IL_068e_2:
																													array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																													goto IL_06ac_2;
																													continue;
																													end_IL_04cd_2:
																													break;
																												}
																												goto IL_093b_2;
																												continue;
																												end_IL_04e0_2:
																												break;
																												IL_04e0_2:;
																											}
																											break;
																											IL_04f3_2:;
																										}
																										break;
																									}
																									goto IL_05fd_2;
																									IL_0626_2:
																									array2[num5 - 1] = 5;
																									goto IL_1291_2;
																									IL_05fd_2:
																									array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																									goto IL_0626_2;
																								}
																								break;
																							}
																							goto IL_05a9_2;
																							IL_067b_2:
																							num5++;
																							goto IL_1291_2;
																							IL_05a9_2:
																							if (15 < b)
																							{
																								break;
																							}
																							goto IL_05b7_2;
																							IL_05b7_2:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_05c5_2;
																							IL_05c5_2:
																							array2[num5] = array2[num5 - 1];
																							goto IL_05dd_2;
																							IL_05dd_2:
																							array4[num5 - 0] = array4[num5 - 1];
																							goto IL_063f_2;
																							IL_063f_2:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																							goto IL_0663_2;
																							IL_0663_2:
																							array3[num5] = array3[num5 - 1];
																							goto IL_067b_2;
																						}
																						break;
																					}
																					goto IL_06cd_2;
																					IL_080f_2:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_1291_2;
																					IL_06cd_2:
																					if (12 <= b)
																					{
																						goto end_IL_059e;
																					}
																					goto IL_06db_2;
																					IL_06db_2:
																					if (10 >= b)
																					{
																						goto IL_06e9_2;
																					}
																					goto IL_0801_2;
																					IL_06e9_2:
																					if (10 > b)
																					{
																						goto IL_06f7_2;
																					}
																					goto IL_078c_2;
																					IL_06f7_2:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0705_2;
																					IL_0705_2:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0713_2;
																					IL_0713_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					num = 136;
																					goto IL_075c_2;
																					IL_075c_2:
																					array2[num5 - 2] = 0;
																					num = 82;
																					goto IL_0779_2;
																					IL_0779_2:
																					num5--;
																					goto IL_1291_2;
																					IL_078c_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_07ee_2;
																					IL_07ee_2:
																					num5 -= 2;
																					goto IL_1291_2;
																					IL_0801_2:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_080f_2;
																				}
																				break;
																			}
																			num = 203;
																			goto IL_0903_2;
																			IL_0c47_2:
																			num5++;
																			goto IL_0c55_2;
																			IL_0c55_2:
																			ptr2 += 8;
																			goto IL_1291_2;
																			IL_0903_2:
																			if (8 > b)
																			{
																				goto IL_0911_2;
																			}
																			goto IL_0c68_2;
																			IL_0911_2:
																			if (4 < b)
																			{
																				goto IL_091f_2;
																			}
																			goto IL_0aba_2;
																			IL_091f_2:
																			if (6 >= b)
																			{
																				goto IL_092d_2;
																			}
																			goto IL_0a37_2;
																			IL_092d_2:
																			if (6 > b)
																			{
																				goto IL_093b_2;
																			}
																			goto IL_09d0_2;
																			IL_093b_2:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0949_2;
																			IL_0949_2:
																			if (5 > b)
																			{
																				break;
																			}
																			num = 288;
																			goto IL_0960_2;
																			IL_0c68_2:
																			num5--;
																			goto IL_1291_2;
																			IL_0960_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			num = 21;
																			goto IL_09a9_2;
																			IL_09a9_2:
																			array2[num5 - 2] = 0;
																			goto IL_09bd_2;
																			IL_09bd_2:
																			num5--;
																			goto IL_1291_2;
																			IL_09d0_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0a10_2;
																			IL_0a10_2:
																			array2[num5 - 2] = 0;
																			goto IL_0a24_2;
																			IL_0a24_2:
																			num5--;
																			goto IL_1291_2;
																			IL_0a37_2:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0a45_2;
																			IL_0a45_2:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0a53_2;
																			IL_0a53_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0a93_2;
																			IL_0a93_2:
																			array2[num5 - 2] = 0;
																			goto IL_0aa7_2;
																			IL_0aa7_2:
																			num5--;
																			goto IL_1291_2;
																			IL_0aba_2:
																			if (4 <= b)
																			{
																				goto IL_0ac5_2;
																			}
																			goto IL_0b21_2;
																			IL_0ac5_2:
																			array2[num5] = 0;
																			goto IL_0ad3_2;
																			IL_0ad3_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_0af6_2;
																			IL_0af6_2:
																			array3[num5] = null;
																			goto IL_0b00_2;
																			IL_0b00_2:
																			num5++;
																			goto IL_0b0e_2;
																			IL_0b0e_2:
																			ptr2 += 8;
																			goto IL_1291_2;
																			IL_0b21_2:
																			if (2 < b)
																			{
																				goto IL_0b2c_2;
																			}
																			goto IL_0b92_2;
																			IL_0b2c_2:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_0b3a_2;
																			IL_0b3a_2:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0b48_2;
																			IL_0b48_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0b71_2;
																			IL_0b71_2:
																			ptr2 += 8;
																			goto IL_0b7f_2;
																			IL_0b7f_2:
																			num5--;
																			goto IL_1291_2;
																			IL_0b92_2:
																			if (2 <= b)
																			{
																				goto IL_0b9d_2;
																			}
																			goto IL_0c04_2;
																			IL_0b9d_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																			goto IL_0bdd_2;
																			IL_0bdd_2:
																			array2[num5 - 2] = 0;
																			goto IL_0bf1_2;
																			IL_0bf1_2:
																			num5--;
																			goto IL_1291_2;
																			IL_0c04_2:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0c12_2;
																			IL_0c12_2:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0c20_2;
																			IL_0c20_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0c39_2;
																			IL_0c39_2:
																			array2[num5] = 0;
																			goto IL_0c47_2;
																		}
																		break;
																	}
																	goto IL_0c7b_2;
																	IL_0caf_2:
																	ptr2 += 8;
																	goto IL_1291_2;
																	IL_0c7b_2:
																	array2[num5] = 5;
																	goto IL_0c89_2;
																	IL_0c89_2:
																	array3[num5] = array7[*(int*)(ptr2 + num3)];
																	goto IL_0ca1_2;
																	IL_0ca1_2:
																	num5++;
																	goto IL_0caf_2;
																}
																break;
															}
															goto IL_0cc2_2;
															IL_1200_2:
															array2[num5 - 2] = 5;
															goto IL_1214_2;
															IL_0cc2_2:
															if (24 < b)
															{
																goto IL_0cd0_2;
															}
															goto IL_0eec_2;
															IL_0cd0_2:
															if (28 >= b)
															{
																goto IL_0cde_2;
															}
															goto IL_0e33_2;
															IL_0cde_2:
															if (28 <= b)
															{
																goto IL_0ce9_2;
															}
															goto IL_0d42_2;
															IL_0ce9_2:
															array3[num5] = array7[*(int*)(ptr2 + num3)];
															goto IL_0d01_2;
															IL_0d01_2:
															array2[num5] = 5;
															goto IL_0d0f_2;
															IL_0d0f_2:
															num5++;
															num = 187;
															goto IL_0d26_2;
															IL_0d26_2:
															ptr2 += 8;
															num = 39;
															goto IL_1291_2;
															IL_0d42_2:
															if (26 < b)
															{
																goto IL_0d4d_2;
															}
															num = 62;
															goto IL_0d9a_2;
															IL_0d4d_2:
															if (27 < b)
															{
																break;
															}
															goto IL_0d5b_2;
															IL_0d5b_2:
															if (27 > b)
															{
																break;
															}
															goto IL_0d69_2;
															IL_0d69_2:
															((delegate*<void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])();
															goto IL_0d7e_2;
															IL_0d7e_2:
															ptr2 += 8;
															goto IL_1291_2;
															IL_1214_2:
															array3[num5 - 2] = ((delegate*<string, string, string>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
															goto IL_1260_2;
															IL_0d9a_2:
															if (26 > b)
															{
																goto IL_0da5_2;
															}
															goto IL_0e0b_2;
															IL_0da5_2:
															if (25 < b)
															{
																break;
															}
															goto IL_0db3_2;
															IL_0db3_2:
															if (25 > b)
															{
																break;
															}
															goto IL_0dc1_2;
															IL_0dc1_2:
															((delegate*<string, void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
															goto IL_0dea_2;
															IL_0dea_2:
															num5--;
															goto IL_0df8_2;
															IL_0df8_2:
															ptr2 += 8;
															goto IL_1291_2;
															IL_0e0b_2:
															((delegate*<void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])();
															goto IL_0e20_2;
															IL_0e20_2:
															ptr2 += 8;
															goto IL_1291_2;
															IL_0e33_2:
															if (30 < b)
															{
																goto IL_0e3e_2;
															}
															goto IL_0e5f_2;
															IL_0e3e_2:
															if (31 < b)
															{
																break;
															}
															goto IL_0e4c_2;
															IL_0e4c_2:
															if (31 <= b)
															{
															}
															break;
															IL_0e5f_2:
															if (30 > b)
															{
																goto IL_0e6a_2;
															}
															goto IL_0ed0_2;
															IL_0e6a_2:
															if (29 < b)
															{
																break;
															}
															goto IL_0e78_2;
															IL_0e78_2:
															if (29 > b)
															{
																break;
															}
															goto IL_0e86_2;
															IL_0e86_2:
															((delegate*<UnityEngine.Object, void>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((Class133)array3[num5 - 1]);
															goto IL_0eaf_2;
															IL_0eaf_2:
															num5--;
															goto IL_0ebd_2;
															IL_0ebd_2:
															ptr2 += 8;
															goto IL_1291_2;
															IL_0ed0_2:
															num9 = ptr2;
															num10 = -200;
															num4 = 1;
															ptr2 = num9 + num10;
															goto IL_1291_2;
															IL_0eec_2:
															if (24 > b)
															{
																goto IL_0efa_2;
															}
															num = 159;
															goto IL_1200_2;
															IL_0efa_2:
															if (20 >= b)
															{
																goto IL_0f08_2;
															}
															goto IL_10f3_2;
															IL_0f08_2:
															if (20 > b)
															{
																goto IL_0f16_2;
															}
															goto IL_108b_2;
															IL_0f16_2:
															if (18 < b)
															{
																goto IL_0f21_2;
															}
															goto IL_0f99_2;
															IL_0f21_2:
															if (19 < b)
															{
																break;
															}
															goto IL_0f2f_2;
															IL_0f2f_2:
															if (19 > b)
															{
																break;
															}
															goto IL_0f3d_2;
															IL_0f3d_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = (((delegate*<bool>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])() ? 1 : 0);
															goto IL_0f61_2;
															IL_0f61_2:
															array2[num5] = 0;
															goto IL_0f6f_2;
															IL_0f6f_2:
															num5++;
															num = 10;
															goto IL_0f86_2;
															IL_0f86_2:
															ptr2 += 8;
															goto IL_1291_2;
															IL_0f99_2:
															if (18 > b)
															{
																goto IL_0fa4_2;
															}
															goto IL_1023_2;
															IL_0fa4_2:
															if (17 < b)
															{
																break;
															}
															num = 127;
															goto IL_0fbb_2;
															IL_126e_2:
															ptr2 += 8;
															goto IL_1291_2;
															IL_0fbb_2:
															if (17 > b)
															{
																break;
															}
															goto IL_0fc9_2;
															IL_0fc9_2:
															((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
															num = 89;
															goto IL_1010_2;
															IL_1010_2:
															num5 -= 3;
															goto IL_1291_2;
															IL_1023_2:
															array2[num5 - 1] = 5;
															goto IL_1037_2;
															IL_1037_2:
															array3[num5 - 1] = ((delegate*<string[], string>)getControlDomainPolicyIsTypeSpec[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
															num = 78;
															goto IL_1078_2;
															IL_1078_2:
															ptr2 += 8;
															goto IL_1291_2;
															IL_108b_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0);
															goto IL_10cc_2;
															IL_10cc_2:
															array2[num5 - 2] = 0;
															goto IL_10e0_2;
															IL_10e0_2:
															num5--;
															goto IL_1291_2;
															IL_10f3_2:
															if (22 < b)
															{
																goto IL_10fe_2;
															}
															goto IL_1132_2;
															IL_10fe_2:
															if (23 < b)
															{
																break;
															}
															goto IL_110c_2;
															IL_110c_2:
															if (23 > b)
															{
																break;
															}
															goto IL_111a_2;
															IL_111a_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_1291_2;
															IL_1132_2:
															if (22 > b)
															{
																goto IL_113d_2;
															}
															goto IL_1186_2;
															IL_113d_2:
															if (21 < b)
															{
																break;
															}
															goto IL_114b_2;
															IL_114b_2:
															if (21 > b)
															{
																break;
															}
															goto IL_1159_2;
															IL_1159_2:
															bool_0 = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) != 0;
															goto IL_1173_2;
															IL_1173_2:
															num5--;
															goto IL_1291_2;
															IL_1186_2:
															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_11e4_2;
															IL_11e4_2:
															num5--;
															goto IL_1291_2;
															IL_1260_2:
															num5--;
															goto IL_126e_2;
														}
														break;
														IL_0563_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_1291_2;
												continue;
												end_IL_0573_2:
												break;
											}
											continue;
											end_IL_0583:
											break;
										}
										continue;
										end_IL_0593:
										break;
									}
									continue;
									end_IL_059e:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_0831_2;
					}
					continue;
					end_IL_083f:
					break;
				}
				break;
			}
		}
	}

	public Class133()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 111;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AccessControlTypeOutAttribute.StrongNameErrorInfogetRequiredContract);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0303:
																if (b >= 1)
																{
																	while (true)
																	{
																		IL_02f6:
																		if (b <= 15)
																		{
																			while (true)
																			{
																				IL_02e6:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02d6:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02c9:
																								if (12 <= b)
																								{
																									while (true)
																									{
																										IL_027e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 151;
																										while (true)
																										{
																											if (num != 151)
																											{
																												if (num != 1132)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 62:
																												case 114:
																													goto IL_027e;
																												case 15:
																													goto IL_02c9;
																												case 4:
																													goto IL_02d6;
																												case 132:
																													goto IL_02e6;
																												case 116:
																													goto IL_02f6;
																												case 117:
																													goto IL_0303;
																												case 65:
																													goto end_IL_0303;
																												case 94:
																												case 106:
																													goto end_IL_0313;
																												case 31:
																												case 59:
																													goto IL_033c;
																												case 98:
																													goto IL_0347;
																												case 45:
																													goto IL_0355;
																												case 35:
																												case 46:
																													goto IL_0363;
																												case 115:
																													goto IL_03a7;
																												case 122:
																													goto IL_03bd;
																												case 126:
																													goto IL_03d0;
																												case 127:
																													goto IL_03e3;
																												case 73:
																													goto IL_03f1;
																												case 9:
																													goto IL_03ff;
																												case 16:
																												case 84:
																													goto IL_0413;
																												case 64:
																													goto IL_0431;
																												case 83:
																													goto IL_043f;
																												case 11:
																													goto IL_0452;
																												case 39:
																												case 118:
																													goto IL_0460;
																												case 12:
																													goto IL_046e;
																												case 24:
																												case 107:
																													goto IL_047c;
																												case 34:
																													goto IL_04a5;
																												case 5:
																													goto IL_04be;
																												case 76:
																													goto IL_04cc;
																												case 89:
																												case 92:
																													goto IL_04d7;
																												case 100:
																													goto IL_04e5;
																												case 43:
																												case 80:
																													goto IL_0501;
																												case 38:
																													goto IL_0540;
																												case 8:
																												case 121:
																													goto IL_055c;
																												case 128:
																													goto IL_0574;
																												case 109:
																													goto IL_0582;
																												case 67:
																												case 86:
																													goto IL_0590;
																												case 88:
																													goto IL_05b9;
																												case 55:
																													goto IL_05c7;
																												case 33:
																												case 129:
																													goto IL_05e3;
																												case 63:
																													goto IL_05f1;
																												case 68:
																													goto IL_0609;
																												case 85:
																													goto IL_0617;
																												case 105:
																												case 131:
																													goto IL_062a;
																												case 99:
																													goto IL_0638;
																												case 78:
																												case 134:
																													goto IL_064b;
																												case 108:
																													goto IL_0659;
																												case 81:
																													goto IL_067c;
																												case 140:
																													goto IL_0686;
																												case 48:
																													goto IL_0694;
																												case 142:
																													goto IL_06a7;
																												case 6:
																												case 77:
																													goto IL_06b2;
																												case 50:
																													goto IL_06c0;
																												case 2:
																												case 54:
																													goto IL_06ce;
																												case 136:
																													goto IL_06e7;
																												case 32:
																													goto IL_06f5;
																												case 137:
																													goto IL_0703;
																												case 20:
																												case 112:
																													goto IL_0716;
																												case 119:
																													goto IL_0756;
																												case 91:
																													goto IL_076a;
																												case 123:
																													goto IL_0791;
																												case 0:
																													goto IL_07a4;
																												case 18:
																												case 96:
																													goto IL_07af;
																												case 53:
																													goto IL_07bd;
																												case 21:
																													goto IL_07d0;
																												case 102:
																												case 124:
																													goto IL_07db;
																												case 130:
																													goto IL_07f7;
																												case 95:
																													goto IL_0805;
																												case 101:
																												case 138:
																													goto IL_081b;
																												case 139:
																													goto IL_087d;
																												case 7:
																												case 10:
																												case 13:
																												case 17:
																												case 19:
																												case 22:
																												case 23:
																												case 25:
																												case 27:
																												case 30:
																												case 36:
																												case 42:
																												case 47:
																												case 52:
																												case 56:
																												case 69:
																												case 74:
																												case 75:
																												case 93:
																												case 97:
																												case 103:
																												case 110:
																												case 113:
																												case 125:
																												case 133:
																													goto end_IL_026b;
																												case 3:
																												case 14:
																												case 26:
																												case 28:
																												case 29:
																												case 37:
																												case 40:
																												case 44:
																												case 57:
																												case 58:
																												case 70:
																												case 79:
																												case 87:
																												case 90:
																												case 120:
																												case 141:
																												case 143:
																												case 144:
																													goto end_IL_0323;
																												case 51:
																													goto end_IL_08a0;
																												case 49:
																													goto end_IL_08b3;
																												case 1:
																													goto end_IL_08bd;
																												case 111:
																													goto end_IL_08c8;
																												case 41:
																												case 104:
																													goto end_IL_08d8;
																												case 135:
																													goto end_IL_08e8;
																												case 66:
																												case 71:
																													goto end_IL_0901;
																												case 60:
																													goto end_IL_0911;
																												case 61:
																													goto end_IL_0921;
																												case 72:
																												case 82:
																													goto IL_093c;
																												}
																												continue;
																											}
																											array[num5 - 2] = 0;
																											goto IL_0791;
																											IL_0791:
																											num5--;
																											goto end_IL_0323;
																											continue;
																											end_IL_026b:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_033c;
																								IL_0694:
																								ptr2 += 8;
																								goto end_IL_0323;
																								IL_033c:
																								if (10 < b)
																								{
																									goto IL_0347;
																								}
																								goto IL_03bd;
																								IL_0347:
																								if (11 < b)
																								{
																									break;
																								}
																								goto IL_0355;
																								IL_0355:
																								if (11 > b)
																								{
																									break;
																								}
																								goto IL_0363;
																								IL_0363:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_03a7;
																								IL_03a7:
																								array[num5 - 2] = 0;
																								goto IL_03d0;
																								IL_03d0:
																								num5--;
																								goto end_IL_0323;
																								IL_03bd:
																								if (10 > b)
																								{
																									goto IL_062a;
																								}
																								goto IL_064b;
																								IL_062a:
																								if (9 < b)
																								{
																									break;
																								}
																								goto IL_0638;
																								IL_0638:
																								if (9 <= b)
																								{
																									goto end_IL_0323;
																								}
																								break;
																								IL_064b:
																								array[num5] = 0;
																								goto IL_0659;
																								IL_0659:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_067c;
																								IL_067c:
																								array2[num5] = null;
																								goto IL_0686;
																								IL_0686:
																								num5++;
																								goto IL_0694;
																							}
																							break;
																						}
																						goto IL_07a4;
																						IL_081b:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_087d;
																						IL_07a4:
																						if (14 < b)
																						{
																							goto IL_07af;
																						}
																						goto IL_07d0;
																						IL_07af:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_07bd;
																						IL_07bd:
																						if (15 > b)
																						{
																						}
																						break;
																						IL_07d0:
																						if (14 <= b)
																						{
																							goto IL_07db;
																						}
																						goto IL_07f7;
																						IL_07db:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0323;
																						IL_07f7:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_0805;
																						IL_0805:
																						if (13 > b)
																						{
																							num = 93;
																							break;
																						}
																						goto IL_081b;
																						IL_087d:
																						num5 -= 2;
																						goto end_IL_0323;
																					}
																					break;
																				}
																				goto IL_03e3;
																				IL_05b9:
																				ptr2 += 8;
																				goto IL_05c7;
																				IL_03e3:
																				if (8 > b)
																				{
																					goto IL_03f1;
																				}
																				num = 121;
																				goto IL_055c;
																				IL_03f1:
																				if (4 >= b)
																				{
																					goto IL_03ff;
																				}
																				goto IL_04be;
																				IL_03ff:
																				if (4 <= b)
																				{
																					num = 16;
																					goto IL_0413;
																				}
																				goto IL_0452;
																				IL_05c7:
																				num5--;
																				num = 144;
																				goto end_IL_0323;
																				IL_0413:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_0431;
																				IL_0431:
																				ptr2 += 8;
																				goto IL_043f;
																				IL_043f:
																				num5--;
																				goto end_IL_0323;
																				IL_0452:
																				if (2 < b)
																				{
																					goto IL_0460;
																				}
																				goto IL_06a7;
																				IL_0460:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_046e;
																				IL_046e:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_047c;
																				IL_047c:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_04a5;
																				IL_04a5:
																				array[num5 - 1] = 5;
																				goto end_IL_0323;
																				IL_06a7:
																				if (2 > b)
																				{
																					goto IL_06b2;
																				}
																				goto IL_0716;
																				IL_06b2:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_06c0;
																				IL_06c0:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_06ce;
																				IL_06ce:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_06e7;
																				IL_06e7:
																				array[num5] = 0;
																				goto IL_06f5;
																				IL_06f5:
																				num5++;
																				goto IL_0703;
																				IL_0703:
																				ptr2 += 8;
																				goto end_IL_0323;
																				IL_0716:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0756;
																				IL_0756:
																				array[num5 - 2] = 0;
																				goto IL_076a;
																				IL_076a:
																				num5--;
																				goto end_IL_0323;
																				IL_04be:
																				if (6 >= b)
																				{
																					goto IL_04cc;
																				}
																				goto IL_0574;
																				IL_04cc:
																				if (6 > b)
																				{
																					goto IL_04d7;
																				}
																				goto IL_0501;
																				IL_04d7:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_04e5;
																				IL_04e5:
																				if (5 > b)
																				{
																					num = 125;
																					break;
																				}
																				goto IL_05e3;
																				IL_055c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0323;
																				IL_05e3:
																				array[num5] = 5;
																				goto IL_05f1;
																				IL_05f1:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0609;
																				IL_0609:
																				num5++;
																				goto IL_0617;
																				IL_0617:
																				ptr2 += 8;
																				goto end_IL_0323;
																				IL_0501:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0540;
																				IL_0540:
																				num5 -= 3;
																				goto end_IL_0323;
																				IL_0574:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0582;
																				IL_0582:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0590;
																				IL_0590:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05b9;
																			}
																		}
																		else
																		{
																			num = 7;
																		}
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0323;
																continue;
																end_IL_0303:
																break;
															}
															continue;
															end_IL_0313:
															break;
														}
														continue;
														end_IL_0323:
														break;
													}
													continue;
												}
												goto IL_093c;
												IL_093c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a0:
												break;
											}
											continue;
											end_IL_08b3:
											break;
										}
										continue;
										end_IL_08bd:
										break;
									}
									continue;
									end_IL_08c8:
									break;
								}
								continue;
								end_IL_08d8:
								break;
							}
							continue;
							end_IL_08e8:
							break;
						}
						continue;
						end_IL_0901:
						break;
					}
					continue;
					end_IL_0911:
					break;
				}
				continue;
				end_IL_0921:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 93;
		byte b = default(byte);
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 42;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DaytimeDurationCollectionCount.ReflectionTypeLoadExceptionAssemblyNameProxy);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 110;
											while (true)
											{
												if (num == 110)
												{
													goto IL_0271;
												}
												if (num != 1091)
												{
													goto IL_03b2;
												}
												switch (num)
												{
												case 73:
													goto end_IL_01c7;
												case 1:
													goto end_IL_01da;
												case 42:
													goto end_IL_01ed;
												case 33:
													goto end_IL_01f8;
												case 43:
												case 52:
													goto end_IL_020d;
												case 15:
													goto end_IL_0226;
												case 9:
												case 77:
													goto end_IL_0236;
												case 92:
													goto end_IL_0246;
												case 93:
													goto end_IL_0256;
												case 34:
												case 44:
												case 48:
												case 54:
												case 56:
												case 57:
												case 59:
												case 65:
												case 72:
												case 75:
												case 86:
												case 87:
													goto IL_0271;
												case 20:
												case 35:
													goto IL_0281;
												case 60:
													goto IL_028a;
												case 19:
													goto IL_0298;
												case 91:
													goto IL_02a6;
												case 46:
													goto IL_02bd;
												case 5:
												case 14:
													goto IL_02cb;
												case 39:
													goto IL_02d9;
												case 3:
												case 74:
													goto IL_02e4;
												case 71:
													goto IL_0346;
												case 99:
													goto IL_0359;
												case 78:
													goto IL_0364;
												case 16:
												case 38:
													goto IL_0372;
												case 96:
													goto IL_03b2;
												case 58:
													goto IL_03cf;
												case 66:
													goto IL_03e2;
												case 69:
													goto IL_03f0;
												case 21:
												case 101:
													goto IL_03fe;
												case 27:
													goto IL_0421;
												case 53:
													goto IL_042f;
												case 45:
													goto IL_0446;
												case 8:
													goto IL_0459;
												case 55:
												case 83:
													goto IL_0464;
												case 81:
													goto IL_0472;
												case 84:
													goto IL_0485;
												case 85:
												case 90:
													goto IL_049e;
												case 26:
													goto IL_04ba;
												case 13:
												case 36:
													goto IL_04c5;
												case 10:
													goto IL_04d3;
												case 61:
													goto IL_04f6;
												case 50:
													goto IL_0500;
												case 76:
													goto IL_0517;
												case 6:
												case 25:
													goto IL_053c;
												case 31:
													goto IL_054a;
												case 11:
													goto IL_0555;
												case 18:
													goto IL_0563;
												case 40:
												case 94:
													goto IL_0571;
												case 41:
													goto IL_058a;
												case 28:
													goto IL_0598;
												case 62:
													goto IL_05a6;
												case 17:
												case 64:
													goto IL_05b9;
												case 0:
													goto IL_05e2;
												case 24:
													goto IL_05f0;
												case 82:
													goto IL_0603;
												case 79:
													goto IL_060e;
												case 4:
												case 100:
													goto IL_0619;
												case 7:
													goto IL_0631;
												case 80:
													goto IL_063c;
												case 2:
												case 12:
												case 22:
												case 23:
												case 29:
												case 30:
												case 37:
												case 47:
												case 49:
												case 51:
												case 63:
												case 67:
												case 68:
												case 70:
												case 88:
												case 89:
												case 95:
												case 97:
												case 98:
												case 102:
													goto IL_064a;
												case 32:
												case 103:
													goto IL_0662;
												}
												continue;
												IL_060e:
												if (3 <= b)
												{
													goto IL_0619;
												}
												goto IL_064a;
												IL_0619:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0271;
												IL_0271:
												if (num4 != 1)
												{
													goto IL_0281;
												}
												goto IL_0662;
												IL_0662:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												IL_0281:
												b = *ptr2;
												goto IL_028a;
												IL_028a:
												ptr2++;
												goto IL_0298;
												IL_0298:
												if (b >= 1)
												{
													goto IL_02a6;
												}
												goto IL_064a;
												IL_02a6:
												if (b <= 10)
												{
													num = 46;
													goto IL_02bd;
												}
												goto IL_064a;
												IL_0631:
												if (4 >= b)
												{
													goto IL_063c;
												}
												goto IL_064a;
												IL_02bd:
												if (5 < b)
												{
													goto IL_02cb;
												}
												goto IL_04ba;
												IL_02cb:
												if (8 >= b)
												{
													goto IL_02d9;
												}
												goto IL_0459;
												IL_02d9:
												if (8 <= b)
												{
													goto IL_02e4;
												}
												goto IL_0359;
												IL_02e4:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0346;
												IL_0346:
												num5 -= 2;
												goto IL_0271;
												IL_0359:
												if (6 >= b)
												{
													goto IL_0364;
												}
												goto IL_03e2;
												IL_0364:
												if (6 <= b)
												{
													goto IL_0372;
												}
												goto IL_064a;
												IL_0372:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_03b2;
												IL_03b2:
												array[num5 - 2] = 0;
												num = 58;
												goto IL_03cf;
												IL_03cf:
												num5--;
												goto IL_0271;
												IL_03e2:
												if (7 >= b)
												{
													goto IL_03f0;
												}
												goto IL_064a;
												IL_03f0:
												if (7 <= b)
												{
													goto IL_03fe;
												}
												goto IL_064a;
												IL_03fe:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_0421;
												IL_0421:
												array[num5] = 0;
												goto IL_042f;
												IL_042f:
												num5++;
												num = 45;
												goto IL_0446;
												IL_0446:
												ptr2 += 8;
												goto IL_0271;
												IL_0459:
												if (9 < b)
												{
													goto IL_0464;
												}
												goto IL_0485;
												IL_0464:
												if (10 >= b)
												{
													goto IL_0472;
												}
												goto IL_064a;
												IL_0472:
												if (10 <= b)
												{
												}
												goto IL_064a;
												IL_0485:
												if (9 <= b)
												{
													goto IL_049e;
												}
												num = 51;
												goto IL_064a;
												IL_063c:
												if (4 <= b)
												{
													goto IL_0271;
												}
												goto IL_064a;
												IL_049e:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												goto IL_0271;
												IL_04ba:
												if (5 <= b)
												{
													goto IL_04c5;
												}
												num = 25;
												goto IL_053c;
												IL_04c5:
												array[num5] = 0;
												goto IL_04d3;
												IL_04d3:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_04f6;
												IL_04f6:
												array2[num5] = null;
												goto IL_0500;
												IL_0500:
												num5++;
												num = 76;
												goto IL_0517;
												IL_0517:
												ptr2 += 8;
												num = 87;
												goto IL_0271;
												IL_064a:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0271;
												IL_053c:
												if (2 >= b)
												{
													goto IL_054a;
												}
												goto IL_0603;
												IL_054a:
												if (2 > b)
												{
													goto IL_0555;
												}
												goto IL_05b9;
												IL_0555:
												if (1 >= b)
												{
													goto IL_0563;
												}
												goto IL_064a;
												IL_0563:
												if (1 <= b)
												{
													goto IL_0571;
												}
												goto IL_064a;
												IL_0571:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_058a;
												IL_058a:
												array[num5] = 0;
												goto IL_0598;
												IL_0598:
												num5++;
												goto IL_05a6;
												IL_05a6:
												ptr2 += 8;
												goto IL_0271;
												IL_05b9:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_05e2;
												IL_05e2:
												ptr2 += 8;
												goto IL_05f0;
												IL_05f0:
												num5--;
												goto IL_0271;
												IL_0603:
												if (3 >= b)
												{
													goto IL_060e;
												}
												goto IL_0631;
												continue;
												end_IL_01c7:
												break;
											}
											continue;
											end_IL_01da:
											break;
										}
										continue;
										end_IL_01ed:
										break;
									}
									continue;
									end_IL_01f8:
									break;
								}
								continue;
								end_IL_020d:
								break;
							}
							continue;
							end_IL_0226:
							break;
						}
						continue;
						end_IL_0236:
						break;
					}
					continue;
					end_IL_0246:
					break;
				}
				continue;
				end_IL_0256:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									num = 43;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetDeclaredPropertyLeaveS.EnsureByteCapacityBinder);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 44;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0263:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0243:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0233:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0226:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_0216:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_01e2:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												num = 112;
																												while (true)
																												{
																													if (num != 112)
																													{
																														if (num != 1093)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 75:
																														case 87:
																															goto IL_01e2;
																														case 71:
																															goto IL_0216;
																														case 10:
																														case 49:
																															goto IL_0226;
																														case 77:
																															goto IL_0233;
																														case 34:
																															goto IL_0243;
																														case 94:
																															goto IL_0253;
																														case 23:
																															goto IL_0263;
																														case 76:
																															goto end_IL_0263;
																														case 44:
																															goto end_IL_0273;
																														case 16:
																															goto end_IL_0283;
																														case 90:
																														case 96:
																															goto IL_0299;
																														case 53:
																														case 86:
																															goto IL_02a4;
																														case 74:
																															goto IL_02b4;
																														case 20:
																														case 101:
																															goto IL_02c2;
																														case 104:
																															goto IL_02da;
																														case 31:
																															goto IL_02fb;
																														case 42:
																															goto IL_030e;
																														case 63:
																															goto IL_031c;
																														case 21:
																														case 99:
																															goto IL_032a;
																														case 81:
																															goto IL_034c;
																														case 28:
																															goto IL_035a;
																														case 41:
																															goto IL_0368;
																														case 19:
																														case 103:
																															goto IL_037b;
																														case 56:
																															goto IL_0389;
																														case 0:
																															goto IL_03ac;
																														case 61:
																															goto IL_03b6;
																														case 9:
																															goto IL_03c4;
																														case 73:
																															goto IL_03d7;
																														case 40:
																															goto IL_03e5;
																														case 12:
																														case 62:
																															goto IL_03f0;
																														case 35:
																															goto IL_0452;
																														case 8:
																															goto IL_0465;
																														case 85:
																															goto IL_047c;
																														case 1:
																														case 46:
																															goto IL_0487;
																														case 39:
																															goto IL_04c7;
																														case 88:
																															goto IL_04db;
																														case 70:
																															goto IL_04fc;
																														case 5:
																															goto IL_050a;
																														case 18:
																														case 22:
																															goto IL_0521;
																														case 84:
																															goto IL_0544;
																														case 97:
																															goto IL_0552;
																														case 38:
																															goto IL_0560;
																														case 32:
																															goto IL_0570;
																														case 51:
																														case 57:
																															goto IL_057b;
																														case 82:
																															goto IL_0586;
																														case 93:
																															goto IL_059c;
																														case 25:
																														case 54:
																															goto IL_05a7;
																														case 2:
																														case 7:
																														case 11:
																														case 14:
																														case 15:
																														case 17:
																														case 24:
																														case 27:
																														case 29:
																														case 30:
																														case 33:
																														case 45:
																														case 47:
																														case 50:
																														case 58:
																														case 72:
																														case 78:
																														case 83:
																														case 91:
																														case 92:
																														case 102:
																															goto end_IL_01cf;
																														case 4:
																														case 13:
																														case 26:
																														case 37:
																														case 48:
																														case 59:
																														case 64:
																														case 67:
																														case 69:
																														case 79:
																														case 89:
																														case 98:
																														case 100:
																															goto end_IL_028e;
																														case 68:
																															goto end_IL_05d3;
																														case 43:
																															goto end_IL_05e6;
																														case 95:
																															goto end_IL_05f0;
																														case 3:
																															goto end_IL_05fb;
																														case 36:
																														case 105:
																															goto end_IL_0619;
																														case 55:
																															goto end_IL_0629;
																														case 52:
																														case 80:
																															goto end_IL_0639;
																														case 65:
																															goto end_IL_0649;
																														case 66:
																															goto end_IL_0659;
																														case 6:
																														case 60:
																															goto IL_0674;
																														}
																														continue;
																													}
																													ptr2 += 8;
																													goto IL_02fb;
																													IL_02fb:
																													num5--;
																													goto end_IL_028e;
																													continue;
																													end_IL_01cf:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_030e;
																										IL_0368:
																										ptr2 += 8;
																										goto end_IL_028e;
																										IL_030e:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_031c;
																										IL_031c:
																										if (1 > b)
																										{
																											break;
																										}
																										goto IL_032a;
																										IL_032a:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										num = 81;
																										goto IL_034c;
																										IL_034c:
																										array[num5] = 0;
																										goto IL_035a;
																										IL_035a:
																										num5++;
																										goto IL_0368;
																									}
																									break;
																								}
																								goto IL_0299;
																								IL_02c2:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_028e;
																								IL_0299:
																								if (3 < b)
																								{
																									goto IL_02a4;
																								}
																								goto IL_02b4;
																								IL_02a4:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_02da;
																								IL_02da:
																								if (4 <= b)
																								{
																									goto end_IL_028e;
																								}
																								break;
																								IL_02b4:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_02c2;
																							}
																							break;
																						}
																						goto IL_037b;
																						IL_03c4:
																						ptr2 += 8;
																						goto end_IL_028e;
																						IL_037b:
																						array[num5] = 0;
																						goto IL_0389;
																						IL_0389:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03ac;
																						IL_03ac:
																						array2[num5] = null;
																						goto IL_03b6;
																						IL_03b6:
																						num5++;
																						goto IL_03c4;
																					}
																					break;
																				}
																				goto IL_03d7;
																				IL_057b:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0586;
																				IL_03d7:
																				if (8 >= b)
																				{
																					goto IL_03e5;
																				}
																				goto IL_0570;
																				IL_03e5:
																				if (8 <= b)
																				{
																					goto IL_03f0;
																				}
																				goto IL_0465;
																				IL_03f0:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0452;
																				IL_0452:
																				num5 -= 2;
																				goto end_IL_028e;
																				IL_0465:
																				if (6 >= b)
																				{
																					num = 85;
																					goto IL_047c;
																				}
																				goto IL_04fc;
																				IL_0586:
																				if (10 > b)
																				{
																					num = 14;
																				}
																				break;
																				IL_047c:
																				if (6 > b)
																				{
																					num = 45;
																					break;
																				}
																				goto IL_0487;
																				IL_0487:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04c7;
																				IL_04c7:
																				array[num5 - 2] = 0;
																				goto IL_04db;
																				IL_04db:
																				num5--;
																				goto end_IL_028e;
																				IL_05a7:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_028e;
																				IL_04fc:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_050a;
																				IL_050a:
																				if (7 > b)
																				{
																					break;
																				}
																				num = 18;
																				goto IL_0521;
																				IL_059c:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_05a7;
																				IL_0521:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0544;
																				IL_0544:
																				array[num5] = 0;
																				goto IL_0552;
																				IL_0552:
																				num5++;
																				goto IL_0560;
																				IL_0560:
																				ptr2 += 8;
																				goto end_IL_028e;
																				IL_0570:
																				if (9 < b)
																				{
																					goto IL_057b;
																				}
																				goto IL_059c;
																			}
																			break;
																			IL_0253:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_028e;
																	continue;
																	end_IL_0263:
																	break;
																}
																continue;
																end_IL_0273:
																break;
															}
															continue;
															end_IL_0283:
															break;
														}
														continue;
														end_IL_028e:
														break;
													}
													continue;
												}
												goto IL_0674;
												IL_0674:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d3:
												break;
											}
											continue;
											end_IL_05e6:
											break;
										}
										continue;
										end_IL_05f0:
										break;
									}
									continue;
									end_IL_05fb:
									break;
								}
								continue;
								end_IL_0619:
								break;
							}
							continue;
							end_IL_0629:
							break;
						}
						continue;
						end_IL_0639:
						break;
					}
					continue;
					end_IL_0649:
					break;
				}
				continue;
				end_IL_0659:
				break;
			}
		}
	}

	private static int smethod_3(int int_2)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		int num4;
		while (true)
		{
			num = num3;
			num4 = int_2;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		num = num2;
		int num5 = smethod_0();
		num4 = num5;
		return num;
	}

	private unsafe static int smethod_4()
	{
		int num = 70;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CreatedgetActivator.ResIdDigestAuthenticationSid);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 58;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0300:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02e0:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_02d0:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02c0:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02b3:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02a0:
																											if (2 >= b)
																											{
																												num = 156;
																												while (true)
																												{
																													if (num != 156)
																													{
																														if (num != 1137)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 22:
																															goto IL_02a0;
																														case 39:
																															goto IL_02b3;
																														case 23:
																														case 96:
																															goto IL_02c0;
																														case 73:
																															goto IL_02d0;
																														case 135:
																															goto IL_02e0;
																														case 89:
																															goto IL_02f0;
																														case 53:
																															goto IL_0300;
																														case 80:
																															goto end_IL_0300;
																														case 44:
																														case 85:
																															goto end_IL_0310;
																														case 40:
																														case 61:
																															goto IL_032b;
																														case 86:
																															goto IL_034b;
																														case 19:
																															goto IL_0359;
																														case 87:
																															goto IL_0369;
																														case 18:
																														case 90:
																															goto IL_037c;
																														case 2:
																															goto IL_0387;
																														case 56:
																															goto IL_0395;
																														case 66:
																														case 91:
																															goto IL_03a8;
																														case 63:
																														case 101:
																															goto IL_03bb;
																														case 1:
																															goto IL_03e4;
																														case 102:
																															goto IL_03fd;
																														case 35:
																														case 83:
																															goto IL_040b;
																														case 46:
																															goto IL_0416;
																														case 103:
																															goto IL_0426;
																														case 104:
																															goto IL_0442;
																														case 110:
																															goto IL_0452;
																														case 9:
																														case 93:
																															goto IL_0460;
																														case 32:
																															goto IL_04ad;
																														case 116:
																															goto IL_04c6;
																														case 38:
																															goto IL_04d4;
																														case 3:
																														case 120:
																															goto IL_04f0;
																														case 111:
																															goto IL_0507;
																														case 57:
																															goto IL_052a;
																														case 81:
																															goto IL_0534;
																														case 45:
																														case 125:
																															goto IL_0547;
																														case 76:
																														case 128:
																															goto IL_055a;
																														case 82:
																														case 129:
																															goto IL_0576;
																														case 37:
																															goto IL_0584;
																														case 48:
																														case 74:
																															goto IL_0592;
																														case 13:
																															goto IL_05bb;
																														case 27:
																															goto IL_05c9;
																														case 115:
																														case 133:
																															goto IL_05dc;
																														case 14:
																														case 134:
																															goto IL_05f4;
																														case 137:
																															goto IL_0639;
																														case 0:
																														case 55:
																															goto IL_0644;
																														case 77:
																															goto IL_0683;
																														case 29:
																														case 131:
																															goto IL_0696;
																														case 142:
																															goto IL_06a6;
																														case 143:
																															goto IL_06b9;
																														case 138:
																															goto IL_06cd;
																														case 144:
																															goto IL_06e0;
																														case 15:
																														case 24:
																															goto IL_06ee;
																														case 75:
																															goto IL_06fc;
																														case 5:
																															goto IL_0714;
																														case 126:
																															goto IL_0722;
																														case 145:
																															goto IL_0735;
																														case 31:
																														case 146:
																															goto IL_0748;
																														case 17:
																															goto IL_0756;
																														case 10:
																														case 12:
																															goto IL_0764;
																														case 147:
																															goto IL_07c8;
																														case 148:
																															goto IL_07db;
																														case 100:
																															goto IL_07f9;
																														case 130:
																															goto IL_0807;
																														case 26:
																														case 51:
																															goto IL_0815;
																														case 141:
																															goto IL_082e;
																														case 122:
																															goto IL_083c;
																														case 34:
																															goto IL_084a;
																														case 41:
																														case 97:
																															goto IL_085d;
																														case 60:
																															goto IL_08a6;
																														case 114:
																															goto IL_08ba;
																														case 6:
																														case 8:
																														case 20:
																														case 21:
																														case 28:
																														case 30:
																														case 33:
																														case 36:
																														case 43:
																														case 49:
																														case 50:
																														case 54:
																														case 64:
																														case 65:
																														case 67:
																														case 68:
																														case 72:
																														case 79:
																														case 88:
																														case 92:
																														case 99:
																														case 105:
																														case 108:
																														case 118:
																														case 121:
																														case 123:
																														case 136:
																														case 149:
																															goto end_IL_028d;
																														case 4:
																														case 11:
																														case 16:
																														case 25:
																														case 42:
																														case 47:
																														case 52:
																														case 58:
																														case 78:
																														case 84:
																														case 94:
																														case 107:
																														case 109:
																														case 112:
																														case 113:
																														case 117:
																														case 127:
																														case 139:
																															goto end_IL_0320;
																														case 98:
																															goto end_IL_08dd;
																														case 71:
																															goto end_IL_08f0;
																														case 95:
																															goto end_IL_0903;
																														case 140:
																															goto end_IL_090e;
																														case 119:
																														case 124:
																															goto end_IL_091e;
																														case 62:
																															goto end_IL_092e;
																														case 59:
																														case 132:
																															goto end_IL_093e;
																														case 69:
																															goto end_IL_094e;
																														case 70:
																															goto end_IL_095e;
																														case 7:
																														case 106:
																															goto IL_0979;
																														}
																														continue;
																													}
																													if (2 > b)
																													{
																														goto IL_07f9;
																													}
																													goto IL_085d;
																													IL_085d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 60;
																													goto IL_08a6;
																													IL_08ba:
																													num5--;
																													goto end_IL_0320;
																													IL_08a6:
																													array[num5 - 2] = 0;
																													goto IL_08ba;
																													IL_07f9:
																													if (1 < b)
																													{
																														break;
																													}
																													goto IL_0807;
																													IL_0807:
																													if (1 > b)
																													{
																														break;
																													}
																													goto IL_0815;
																													IL_0815:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_082e;
																													IL_082e:
																													array[num5] = 0;
																													goto IL_083c;
																													IL_083c:
																													num5++;
																													goto IL_084a;
																													IL_084a:
																													ptr2 += 8;
																													goto end_IL_0320;
																													continue;
																													end_IL_028d:
																													break;
																												}
																												break;
																											}
																											goto IL_034b;
																											IL_03bb:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_03e4;
																											IL_03e4:
																											array[num5 - 1] = 5;
																											goto end_IL_0320;
																											IL_034b:
																											if (3 < b)
																											{
																												break;
																											}
																											goto IL_0359;
																											IL_0359:
																											if (3 > b)
																											{
																												break;
																											}
																											goto IL_03bb;
																										}
																										break;
																									}
																									goto IL_032b;
																									IL_0426:
																									num5--;
																									num = 52;
																									goto end_IL_0320;
																									IL_032b:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_0369;
																									IL_0369:
																									ptr2 += 8;
																									goto IL_0426;
																								}
																								break;
																							}
																							goto IL_03a8;
																							IL_0722:
																							ptr2 += 8;
																							goto end_IL_0320;
																							IL_03a8:
																							if (6 < b)
																							{
																								goto IL_0576;
																							}
																							goto IL_0639;
																							IL_0576:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0584;
																							IL_0584:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0592;
																							IL_0592:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05bb;
																							IL_05bb:
																							ptr2 += 8;
																							goto IL_05c9;
																							IL_05c9:
																							num5--;
																							goto end_IL_0320;
																							IL_0639:
																							if (6 <= b)
																							{
																								goto IL_0644;
																							}
																							goto IL_0696;
																							IL_0644:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0683;
																							IL_0683:
																							num5 -= 3;
																							goto end_IL_0320;
																							IL_0696:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_06e0;
																							IL_06e0:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_06ee;
																							IL_06ee:
																							array[num5] = 5;
																							goto IL_06fc;
																							IL_06fc:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_0714;
																							IL_0714:
																							num5++;
																							goto IL_0722;
																						}
																						break;
																					}
																					goto IL_05dc;
																					IL_05dc:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0320;
																				}
																				break;
																			}
																			goto IL_037c;
																			IL_06b9:
																			array[num5 - 2] = 0;
																			goto IL_06cd;
																			IL_037c:
																			if (12 < b)
																			{
																				goto IL_0387;
																			}
																			goto IL_03fd;
																			IL_0387:
																			if (14 >= b)
																			{
																				goto IL_0395;
																			}
																			goto IL_0547;
																			IL_0395:
																			if (14 <= b)
																			{
																				goto IL_055a;
																			}
																			goto IL_0748;
																			IL_055a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0320;
																			IL_0748:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0756;
																			IL_0756:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0764;
																			IL_0764:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_07db;
																			IL_07db:
																			num5 -= 2;
																			goto end_IL_0320;
																			IL_0547:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0735;
																			IL_0735:
																			if (15 <= b)
																			{
																			}
																			break;
																			IL_03fd:
																			if (12 > b)
																			{
																				goto IL_040b;
																			}
																			goto IL_05f4;
																			IL_040b:
																			if (10 < b)
																			{
																				goto IL_0416;
																			}
																			goto IL_0442;
																			IL_0416:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0452;
																			IL_0452:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0460;
																			IL_0460:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			num = 32;
																			goto IL_04ad;
																			IL_04ad:
																			array[num5 - 2] = 0;
																			goto IL_06a6;
																			IL_06a6:
																			num5--;
																			goto end_IL_0320;
																			IL_0442:
																			if (10 > b)
																			{
																				goto IL_04c6;
																			}
																			goto IL_04f0;
																			IL_04f0:
																			array[num5] = 0;
																			num = 111;
																			goto IL_0507;
																			IL_0507:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_052a;
																			IL_052a:
																			array2[num5] = null;
																			goto IL_0534;
																			IL_0534:
																			num5++;
																			goto IL_07c8;
																			IL_07c8:
																			ptr2 += 8;
																			goto end_IL_0320;
																			IL_04c6:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_04d4;
																			IL_04d4:
																			if (9 <= b)
																			{
																				goto end_IL_0320;
																			}
																			num = 43;
																			break;
																			IL_06cd:
																			num5--;
																			goto end_IL_0320;
																			IL_05f4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06b9;
																		}
																		break;
																		IL_02f0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0320;
																continue;
																end_IL_0300:
																break;
															}
															continue;
															end_IL_0310:
															break;
														}
														continue;
														end_IL_0320:
														break;
													}
													continue;
												}
												goto IL_0979;
												IL_0979:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08dd:
												break;
											}
											continue;
											end_IL_08f0:
											break;
										}
										continue;
										end_IL_0903:
										break;
									}
									continue;
									end_IL_090e:
									break;
								}
								continue;
								end_IL_091e:
								break;
							}
							continue;
							end_IL_092e:
							break;
						}
						continue;
						end_IL_093e:
						break;
					}
					continue;
					end_IL_094e:
					break;
				}
				continue;
				end_IL_095e:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 14;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									num = 105;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setTargetTypeNamectime.ITupleInternalGetKeyAlgorithmParametersString);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02f0:
															num = 70;
															while (true)
															{
																IL_02e5:
																byte b = *ptr2;
																while (true)
																{
																	IL_02d5:
																	ptr2++;
																	while (true)
																	{
																		IL_02c5:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_02b5:
																				if (b <= 9)
																				{
																					while (true)
																					{
																						IL_02a5:
																						if (5 >= b)
																						{
																							while (true)
																							{
																								IL_0298:
																								if (5 > b)
																								{
																									while (true)
																									{
																										IL_028b:
																										if (2 < b)
																										{
																											while (true)
																											{
																												IL_027b:
																												if (3 < b)
																												{
																													while (4 >= b)
																													{
																														while (4 <= b)
																														{
																															while (true)
																															{
																																IL_0219:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																while (true)
																																{
																																	IL_0203:
																																	array[num5 - 2] = 0;
																																	while (true)
																																	{
																																		IL_01ea:
																																		num5--;
																																		num = 114;
																																		while (num != 114)
																																		{
																																			if (num != 1095)
																																			{
																																				goto IL_03a3;
																																			}
																																			switch (num)
																																			{
																																			case 44:
																																				goto IL_01ea;
																																			case 19:
																																				goto IL_0203;
																																			case 69:
																																			case 80:
																																				goto IL_0219;
																																			case 84:
																																				goto IL_025b;
																																			case 46:
																																			case 62:
																																				goto IL_026b;
																																			case 21:
																																			case 102:
																																				goto IL_027b;
																																			case 48:
																																				goto IL_028b;
																																			case 101:
																																				goto IL_0298;
																																			case 96:
																																				goto IL_02a5;
																																			case 81:
																																				goto IL_02b5;
																																			case 98:
																																				goto IL_02c5;
																																			case 50:
																																				goto IL_02d5;
																																			case 70:
																																				goto IL_02e5;
																																			case 88:
																																				goto IL_02f0;
																																			case 3:
																																			case 17:
																																				goto IL_02fb;
																																			case 41:
																																				goto IL_030e;
																																			case 32:
																																			case 55:
																																				goto IL_0319;
																																			case 5:
																																			case 76:
																																				goto IL_0329;
																																			case 85:
																																				goto IL_0369;
																																			case 60:
																																				goto IL_037d;
																																			case 93:
																																				goto IL_0390;
																																			case 100:
																																				goto IL_03a3;
																																			case 95:
																																				goto IL_03c6;
																																			case 90:
																																				goto IL_03d9;
																																			case 82:
																																				goto IL_03e7;
																																			case 34:
																																			case 106:
																																				goto IL_03fa;
																																			case 23:
																																			case 30:
																																				goto IL_0408;
																																			case 47:
																																			case 86:
																																				goto IL_0413;
																																			case 25:
																																				goto IL_0421;
																																			case 52:
																																			case 63:
																																				goto IL_042f;
																																			case 15:
																																				goto IL_044b;
																																			case 28:
																																			case 75:
																																				goto IL_0462;
																																			case 51:
																																				goto IL_04a2;
																																			case 71:
																																				goto IL_04b6;
																																			case 16:
																																				goto IL_04c9;
																																			case 57:
																																			case 104:
																																				goto IL_04d7;
																																			case 42:
																																				goto IL_04e5;
																																			case 6:
																																			case 33:
																																				goto IL_04f3;
																																			case 73:
																																				goto IL_0533;
																																			case 72:
																																				goto IL_0550;
																																			case 2:
																																			case 68:
																																				goto IL_0563;
																																			case 78:
																																				goto IL_057c;
																																			case 49:
																																				goto IL_058a;
																																			case 22:
																																				goto IL_0598;
																																			case 24:
																																				goto IL_05b4;
																																			case 18:
																																			case 64:
																																				goto IL_05bf;
																																			case 97:
																																				goto IL_05e8;
																																			case 66:
																																				goto IL_05f6;
																																			case 1:
																																			case 9:
																																			case 10:
																																			case 12:
																																			case 29:
																																			case 31:
																																			case 39:
																																			case 40:
																																			case 45:
																																			case 56:
																																			case 58:
																																			case 83:
																																			case 89:
																																			case 91:
																																			case 92:
																																			case 94:
																																			case 103:
																																			case 107:
																																				goto end_IL_025b;
																																			case 67:
																																				goto IL_0632;
																																			case 36:
																																				goto IL_0640;
																																			case 7:
																																				goto IL_064e;
																																			case 4:
																																			case 11:
																																			case 26:
																																			case 35:
																																			case 38:
																																			case 53:
																																			case 54:
																																			case 61:
																																			case 79:
																																			case 87:
																																				goto end_IL_01d7;
																																			case 74:
																																				goto end_IL_065c;
																																			case 43:
																																				goto end_IL_066f;
																																			case 105:
																																				goto end_IL_0679;
																																			case 20:
																																				goto end_IL_0684;
																																			case 27:
																																				goto end_IL_0699;
																																			case 59:
																																			case 65:
																																				goto end_IL_06b7;
																																			case 77:
																																				goto end_IL_06c7;
																																			case 0:
																																			case 37:
																																				goto end_IL_06d7;
																																			case 13:
																																				goto end_IL_06e7;
																																			case 14:
																																				goto end_IL_06f7;
																																			case 8:
																																			case 99:
																																				goto IL_0712;
																																			}
																																			continue;
																																			end_IL_01d7:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_02c5;
																															continue;
																															end_IL_025b:
																															break;
																															IL_025b:;
																														}
																														break;
																														IL_026b:;
																													}
																													break;
																												}
																												goto IL_05b4;
																												IL_05f6:
																												num5--;
																												goto end_IL_02c5;
																												IL_05b4:
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_05bf;
																												IL_05bf:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_05e8;
																												IL_05e8:
																												ptr2 += 8;
																												goto IL_05f6;
																											}
																											break;
																										}
																										goto IL_030e;
																										IL_037d:
																										num5--;
																										goto end_IL_02c5;
																										IL_030e:
																										if (2 > b)
																										{
																											goto IL_0319;
																										}
																										goto IL_0329;
																										IL_0319:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_0390;
																										IL_0390:
																										if (1 > b)
																										{
																										}
																										break;
																										IL_0329:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0369;
																										IL_0369:
																										array[num5 - 2] = 0;
																										goto IL_037d;
																									}
																									break;
																								}
																								goto IL_02fb;
																								IL_03e7:
																								ptr2 += 8;
																								goto end_IL_02c5;
																								IL_02fb:
																								array[num5] = 0;
																								goto IL_03a3;
																								IL_03a3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_03c6;
																								IL_03c6:
																								array2[num5] = null;
																								num = 90;
																								goto IL_03d9;
																								IL_03d9:
																								num5++;
																								goto IL_03e7;
																							}
																							break;
																						}
																						goto IL_03fa;
																						IL_058a:
																						num5++;
																						goto IL_0598;
																						IL_03fa:
																						if (7 < b)
																						{
																							goto IL_0408;
																						}
																						goto IL_04c9;
																						IL_0408:
																						if (8 < b)
																						{
																							goto IL_0413;
																						}
																						goto IL_044b;
																						IL_0413:
																						if (9 < b)
																						{
																							break;
																						}
																						goto IL_0421;
																						IL_0421:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_042f;
																						IL_042f:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_02c5;
																						IL_044b:
																						if (8 > b)
																						{
																							break;
																						}
																						num = 28;
																						goto IL_0462;
																						IL_0598:
																						ptr2 += 8;
																						num = 87;
																						goto end_IL_02c5;
																						IL_0462:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04a2;
																						IL_04a2:
																						array[num5 - 2] = 0;
																						goto IL_04b6;
																						IL_04b6:
																						num5--;
																						goto end_IL_02c5;
																						IL_04c9:
																						if (7 > b)
																						{
																							goto IL_04d7;
																						}
																						goto IL_0563;
																						IL_04d7:
																						if (6 < b)
																						{
																							break;
																						}
																						goto IL_04e5;
																						IL_04e5:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_04f3;
																						IL_04f3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0533;
																						IL_0533:
																						array[num5 - 2] = 0;
																						num = 72;
																						goto IL_0550;
																						IL_0550:
																						num5--;
																						goto end_IL_02c5;
																						IL_0563:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_057c;
																						IL_057c:
																						array[num5] = 0;
																						goto IL_058a;
																					}
																				}
																				else
																				{
																					num = 45;
																				}
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0632;
																		IL_064e:
																		ptr2 += 8;
																		break;
																		IL_0640:
																		num5++;
																		goto IL_064e;
																		IL_0632:
																		array[num5] = 0;
																		goto IL_0640;
																		continue;
																		end_IL_02c5:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0712;
													IL_0712:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_065c:
													break;
												}
												continue;
												end_IL_066f:
												break;
											}
											continue;
											end_IL_0679:
											break;
										}
										continue;
										end_IL_0684:
										break;
									}
									continue;
									end_IL_0699:
									break;
								}
								continue;
								end_IL_06b7:
								break;
							}
							continue;
							end_IL_06c7:
							break;
						}
						continue;
						end_IL_06d7:
						break;
					}
					continue;
					end_IL_06e7:
					break;
				}
				continue;
				end_IL_06f7:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 82;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 84;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							num = 99;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FriendlyNameAllowWhiteSpaces.GacInstalledgetPrivateBinPath);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 77;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0275:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0255:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0248:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0238:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_022b:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												while (true)
																												{
																													IL_0208:
																													if (5 > b)
																													{
																														num = 118;
																														while (num != 118)
																														{
																															if (num != 1099)
																															{
																																goto IL_05a8;
																															}
																															switch (num)
																															{
																															case 38:
																																goto IL_0208;
																															case 34:
																																goto IL_021b;
																															case 93:
																																goto IL_022b;
																															case 61:
																																goto IL_0238;
																															case 76:
																																goto IL_0248;
																															case 24:
																																goto IL_0255;
																															case 91:
																																goto IL_0265;
																															case 12:
																																goto IL_0275;
																															case 77:
																																goto end_IL_0275;
																															case 9:
																															case 52:
																																goto end_IL_0285;
																															case 28:
																																goto IL_02a9;
																															case 78:
																															case 85:
																																goto IL_02bc;
																															case 35:
																															case 87:
																																goto IL_0307;
																															case 96:
																																goto IL_031a;
																															case 98:
																																goto IL_0333;
																															case 14:
																															case 68:
																																goto IL_0341;
																															case 27:
																																goto IL_034c;
																															case 29:
																																goto IL_035a;
																															case 69:
																																goto IL_036a;
																															case 54:
																															case 67:
																																goto IL_0381;
																															case 89:
																																goto IL_039a;
																															case 59:
																																goto IL_03a8;
																															case 17:
																																goto IL_03b6;
																															case 1:
																															case 56:
																																goto IL_03c9;
																															case 74:
																															case 103:
																																goto IL_03e1;
																															case 18:
																																goto IL_040a;
																															case 0:
																																goto IL_0418;
																															case 107:
																																goto IL_042b;
																															case 4:
																																goto IL_044e;
																															case 40:
																																goto IL_0458;
																															case 51:
																																goto IL_0466;
																															case 111:
																																goto IL_0479;
																															case 6:
																																goto IL_048c;
																															case 88:
																																goto IL_049a;
																															case 66:
																																goto IL_04a8;
																															case 47:
																																goto IL_04b3;
																															case 105:
																															case 109:
																																goto IL_04c1;
																															case 101:
																																goto IL_0501;
																															case 15:
																																goto IL_0515;
																															case 97:
																																goto IL_0528;
																															case 53:
																																goto IL_0536;
																															case 83:
																															case 102:
																																goto IL_0544;
																															case 100:
																																goto IL_0567;
																															case 92:
																																goto IL_0575;
																															case 30:
																																goto IL_058c;
																															case 16:
																															case 72:
																																goto IL_05a8;
																															case 95:
																																goto IL_060a;
																															case 44:
																																goto IL_061a;
																															case 3:
																																goto IL_0625;
																															case 42:
																															case 94:
																																goto IL_0630;
																															case 25:
																																goto IL_0649;
																															case 10:
																																goto IL_0654;
																															case 2:
																															case 5:
																															case 8:
																															case 11:
																															case 20:
																															case 21:
																															case 22:
																															case 23:
																															case 33:
																															case 36:
																															case 37:
																															case 41:
																															case 43:
																															case 45:
																															case 46:
																															case 48:
																															case 55:
																															case 62:
																															case 71:
																															case 75:
																															case 86:
																															case 106:
																																goto end_IL_01f5;
																															case 13:
																															case 31:
																															case 32:
																															case 39:
																															case 57:
																															case 58:
																															case 60:
																															case 63:
																															case 64:
																															case 65:
																															case 70:
																															case 80:
																															case 104:
																															case 110:
																																goto end_IL_0295;
																															case 108:
																																goto end_IL_067b;
																															case 7:
																																goto end_IL_068e;
																															case 19:
																																goto end_IL_0698;
																															case 26:
																																goto end_IL_06a3;
																															case 90:
																															case 99:
																																goto end_IL_06b8;
																															case 73:
																																goto end_IL_06c8;
																															case 84:
																																goto end_IL_06d8;
																															case 50:
																																goto end_IL_06f1;
																															case 81:
																																goto end_IL_0701;
																															case 82:
																																goto end_IL_070c;
																															case 49:
																															case 79:
																																goto IL_0727;
																															}
																															continue;
																															end_IL_01f5:
																															break;
																														}
																														break;
																													}
																													goto IL_0307;
																													IL_0458:
																													num5++;
																													goto IL_0466;
																													IL_0466:
																													ptr2 += 8;
																													goto end_IL_0295;
																													IL_0307:
																													array[num5] = 0;
																													goto IL_042b;
																													IL_042b:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_044e;
																													IL_044e:
																													array2[num5] = null;
																													goto IL_0458;
																												}
																												break;
																												IL_021b:;
																											}
																											break;
																										}
																										goto IL_02a9;
																										IL_02a9:
																										if (4 <= b)
																										{
																											goto end_IL_0295;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0333;
																								IL_03b6:
																								ptr2 += 8;
																								goto end_IL_0295;
																								IL_0333:
																								if (3 > b)
																								{
																									goto IL_0341;
																								}
																								goto IL_03c9;
																								IL_0341:
																								if (1 < b)
																								{
																									goto IL_034c;
																								}
																								goto IL_036a;
																								IL_034c:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_035a;
																								IL_035a:
																								if (2 > b)
																								{
																									break;
																								}
																								goto IL_03e1;
																								IL_03e1:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_040a;
																								IL_040a:
																								ptr2 += 8;
																								goto IL_0418;
																								IL_0418:
																								num5--;
																								goto end_IL_0295;
																								IL_036a:
																								if (1 > b)
																								{
																									break;
																								}
																								num = 67;
																								goto IL_0381;
																								IL_03c9:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_0295;
																								IL_0381:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_039a;
																								IL_039a:
																								array[num5] = 0;
																								goto IL_03a8;
																								IL_03a8:
																								num5++;
																								goto IL_03b6;
																							}
																							break;
																						}
																						goto IL_02bc;
																						IL_0479:
																						num5--;
																						goto end_IL_0295;
																						IL_02bc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 96;
																						goto IL_031a;
																						IL_031a:
																						array[num5 - 2] = 0;
																						goto IL_0479;
																					}
																					break;
																				}
																				goto IL_048c;
																				IL_0649:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0654;
																				IL_048c:
																				if (9 >= b)
																				{
																					goto IL_049a;
																				}
																				goto IL_061a;
																				IL_049a:
																				if (9 > b)
																				{
																					goto IL_04a8;
																				}
																				num = 72;
																				goto IL_05a8;
																				IL_04a8:
																				if (7 >= b)
																				{
																					goto IL_04b3;
																				}
																				goto IL_0528;
																				IL_04b3:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04c1;
																				IL_04c1:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0501;
																				IL_0501:
																				array[num5 - 2] = 0;
																				goto IL_0515;
																				IL_0515:
																				num5--;
																				goto end_IL_0295;
																				IL_0528:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0536;
																				IL_0536:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0544;
																				IL_0544:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0567;
																				IL_0567:
																				array[num5] = 0;
																				goto IL_0575;
																				IL_0575:
																				num5++;
																				num = 30;
																				goto IL_058c;
																				IL_058c:
																				ptr2 += 8;
																				goto end_IL_0295;
																				IL_0654:
																				if (11 > b)
																				{
																				}
																				break;
																				IL_05a8:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_060a;
																				IL_060a:
																				num5 -= 2;
																				goto end_IL_0295;
																				IL_061a:
																				if (10 >= b)
																				{
																					goto IL_0625;
																				}
																				goto IL_0649;
																				IL_0625:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0630;
																				IL_0630:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0295;
																			}
																			break;
																			IL_0265:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 80;
																	goto end_IL_0295;
																	continue;
																	end_IL_0275:
																	break;
																}
																continue;
																end_IL_0285:
																break;
															}
															continue;
															end_IL_0295:
															break;
														}
														continue;
													}
													goto IL_0727;
													IL_0727:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_067b:
													break;
												}
												continue;
												end_IL_068e:
												break;
											}
											continue;
											end_IL_0698:
											break;
										}
										continue;
										end_IL_06a3:
										break;
									}
									continue;
									end_IL_06b8:
									break;
								}
								continue;
								end_IL_06c8:
								break;
							}
							continue;
							end_IL_06d8:
							break;
						}
						continue;
						end_IL_06f1:
						break;
					}
					continue;
					end_IL_0701:
					break;
				}
				continue;
				end_IL_070c:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 25;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MaximumConcurrencyLevelSystemAclPresent.ResolvedAssemblyFilesSpinOnce);
											num = 44;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 8;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02ac:
																		if (b >= 1)
																		{
																			while (b <= 11)
																			{
																				while (true)
																				{
																					IL_028c:
																					if (6 >= b)
																					{
																						while (true)
																						{
																							IL_027c:
																							if (6 > b)
																							{
																								while (true)
																								{
																									IL_026c:
																									if (3 >= b)
																									{
																										while (true)
																										{
																											IL_025f:
																											if (3 > b)
																											{
																												while (true)
																												{
																													IL_0252:
																													if (1 >= b)
																													{
																														while (1 <= b)
																														{
																															while (true)
																															{
																																IL_0227:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																																while (true)
																																{
																																	IL_0217:
																																	array[num5] = 0;
																																	while (true)
																																	{
																																		IL_01fe:
																																		num5++;
																																		num = 119;
																																		while (true)
																																		{
																																			if (num != 119)
																																			{
																																				if (num != 1100)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 79:
																																					goto IL_01fe;
																																				case 73:
																																					goto IL_0217;
																																				case 7:
																																				case 63:
																																					goto IL_0227;
																																				case 50:
																																					goto IL_0242;
																																				case 14:
																																					goto IL_0252;
																																				case 47:
																																					goto IL_025f;
																																				case 9:
																																				case 45:
																																					goto IL_026c;
																																				case 106:
																																					goto IL_027c;
																																				case 16:
																																					goto IL_028c;
																																				case 88:
																																					goto IL_029c;
																																				case 4:
																																					goto IL_02ac;
																																				case 69:
																																					goto end_IL_02ac;
																																				case 62:
																																				case 109:
																																					goto end_IL_02bc;
																																				case 15:
																																					goto IL_02d7;
																																				case 13:
																																				case 42:
																																					goto IL_02ea;
																																				case 11:
																																				case 51:
																																					goto IL_0302;
																																				case 32:
																																				case 33:
																																					goto IL_030d;
																																				case 56:
																																					goto IL_031d;
																																				case 77:
																																					goto IL_0330;
																																				case 18:
																																				case 30:
																																					goto IL_033b;
																																				case 90:
																																					goto IL_0359;
																																				case 64:
																																					goto IL_037c;
																																				case 83:
																																					goto IL_0386;
																																				case 93:
																																					goto IL_0394;
																																				case 112:
																																					goto IL_03a7;
																																				case 65:
																																				case 110:
																																					goto IL_03b5;
																																				case 49:
																																					goto IL_03e7;
																																				case 6:
																																					goto IL_03f5;
																																				case 28:
																																				case 41:
																																					goto IL_0424;
																																				case 40:
																																					goto IL_0464;
																																				case 58:
																																					goto IL_0478;
																																				case 76:
																																					goto IL_048b;
																																				case 81:
																																					goto IL_0499;
																																				case 31:
																																				case 75:
																																					goto IL_04a4;
																																				case 20:
																																					goto IL_0506;
																																				case 3:
																																				case 70:
																																					goto IL_0522;
																																				case 91:
																																					goto IL_052d;
																																				case 38:
																																				case 103:
																																					goto IL_053b;
																																				case 55:
																																					goto IL_057b;
																																				case 12:
																																					goto IL_058f;
																																				case 37:
																																				case 54:
																																					goto IL_05a2;
																																				case 111:
																																					goto IL_05b0;
																																				case 78:
																																				case 86:
																																					goto end_IL_01eb;
																																				case 102:
																																					goto IL_05e1;
																																				case 82:
																																					goto IL_05ef;
																																				case 48:
																																					goto IL_05fd;
																																				case 35:
																																					goto IL_060d;
																																				case 98:
																																					goto IL_0618;
																																				case 46:
																																				case 53:
																																					goto IL_0623;
																																				case 39:
																																					goto IL_063c;
																																				case 43:
																																					goto IL_0647;
																																				case 5:
																																				case 10:
																																				case 19:
																																				case 24:
																																				case 27:
																																				case 29:
																																				case 57:
																																				case 66:
																																				case 67:
																																				case 68:
																																				case 74:
																																				case 80:
																																				case 89:
																																				case 92:
																																				case 94:
																																				case 97:
																																				case 100:
																																				case 101:
																																				case 107:
																																				case 108:
																																					goto end_IL_0242;
																																				case 0:
																																				case 1:
																																				case 2:
																																				case 8:
																																				case 21:
																																				case 23:
																																				case 26:
																																				case 61:
																																				case 84:
																																				case 85:
																																				case 87:
																																				case 95:
																																				case 96:
																																					goto end_IL_02cc;
																																				case 59:
																																					goto end_IL_066e;
																																				case 44:
																																					goto end_IL_0681;
																																				case 22:
																																					goto end_IL_068c;
																																				case 105:
																																					goto end_IL_0696;
																																				case 17:
																																					goto end_IL_06aa;
																																				case 36:
																																				case 52:
																																					goto end_IL_06bf;
																																				case 34:
																																					goto end_IL_06cf;
																																				case 25:
																																					goto end_IL_06df;
																																				case 104:
																																					goto end_IL_06ef;
																																				case 71:
																																					goto end_IL_06ff;
																																				case 72:
																																					goto end_IL_070a;
																																				case 60:
																																				case 99:
																																					goto IL_0725;
																																				}
																																				continue;
																																			}
																																			ptr2 += 8;
																																			goto end_IL_02cc;
																																			continue;
																																			end_IL_01eb:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_05be;
																															continue;
																															end_IL_0242:
																															break;
																															IL_0242:;
																														}
																														break;
																													}
																													goto IL_02d7;
																													IL_03f5:
																													num5--;
																													num = 95;
																													goto end_IL_02cc;
																													IL_02d7:
																													if (2 < b)
																													{
																														break;
																													}
																													goto IL_03a7;
																													IL_03a7:
																													if (2 > b)
																													{
																														break;
																													}
																													goto IL_03b5;
																													IL_03b5:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 49;
																													goto IL_03e7;
																													IL_03e7:
																													ptr2 += 8;
																													goto IL_03f5;
																												}
																												break;
																											}
																											goto IL_02ea;
																											IL_02ea:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto end_IL_02cc;
																										}
																										break;
																									}
																									goto IL_0302;
																									IL_031d:
																									if (4 <= b)
																									{
																										goto end_IL_02cc;
																									}
																									break;
																									IL_0302:
																									if (4 < b)
																									{
																										goto IL_030d;
																									}
																									goto IL_031d;
																									IL_030d:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_0330;
																									IL_0330:
																									if (5 > b)
																									{
																										num = 74;
																										break;
																									}
																									goto IL_033b;
																									IL_033b:
																									array[num5] = 0;
																									goto IL_0359;
																									IL_0359:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_037c;
																									IL_037c:
																									array2[num5] = null;
																									goto IL_0386;
																									IL_0386:
																									num5++;
																									goto IL_0394;
																									IL_0394:
																									ptr2 += 8;
																									goto end_IL_02cc;
																								}
																								break;
																							}
																							goto IL_0424;
																							IL_0478:
																							num5--;
																							goto end_IL_02cc;
																							IL_0424:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0464;
																							IL_0464:
																							array[num5 - 2] = 0;
																							goto IL_0478;
																						}
																						break;
																					}
																					goto IL_048b;
																					IL_0647:
																					if (11 <= b)
																					{
																					}
																					break;
																					IL_048b:
																					if (9 >= b)
																					{
																						goto IL_0499;
																					}
																					goto IL_060d;
																					IL_0499:
																					if (9 <= b)
																					{
																						goto IL_04a4;
																					}
																					goto IL_0522;
																					IL_04a4:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0506;
																					IL_0506:
																					num5 -= 2;
																					num = 61;
																					goto end_IL_02cc;
																					IL_0522:
																					if (7 >= b)
																					{
																						goto IL_052d;
																					}
																					goto IL_05a2;
																					IL_052d:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_053b;
																					IL_053b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_057b;
																					IL_057b:
																					array[num5 - 2] = 0;
																					goto IL_058f;
																					IL_058f:
																					num5--;
																					goto end_IL_02cc;
																					IL_05a2:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_05b0;
																					IL_05b0:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_05be;
																					IL_05be:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_05e1;
																					IL_05e1:
																					array[num5] = 0;
																					goto IL_05ef;
																					IL_05ef:
																					num5++;
																					goto IL_05fd;
																					IL_05fd:
																					ptr2 += 8;
																					goto end_IL_02cc;
																					IL_060d:
																					if (10 >= b)
																					{
																						goto IL_0618;
																					}
																					goto IL_063c;
																					IL_0618:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_0623;
																					IL_0623:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02cc;
																					IL_063c:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0647;
																				}
																				break;
																				IL_029c:;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 87;
																		goto end_IL_02cc;
																		continue;
																		end_IL_02ac:
																		break;
																	}
																	continue;
																	end_IL_02bc:
																	break;
																}
																continue;
																end_IL_02cc:
																break;
															}
															continue;
														}
														goto IL_0725;
														IL_0725:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_066e:
														break;
													}
													continue;
													end_IL_0681:
													break;
												}
												continue;
												end_IL_068c:
												break;
											}
											continue;
											end_IL_0696:
											break;
										}
										continue;
										end_IL_06aa:
										break;
									}
									continue;
									end_IL_06bf:
									break;
								}
								continue;
								end_IL_06cf:
								break;
							}
							continue;
							end_IL_06df:
							break;
						}
						continue;
						end_IL_06ef:
						break;
					}
					continue;
					end_IL_06ff:
					break;
				}
				continue;
				end_IL_070a:
				break;
			}
		}
	}

	static Class133()
	{
		int num = 4;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 11;
				while (true)
				{
					if (num == 11 || num != 992)
					{
						return;
					}
					switch (num)
					{
					case 3:
						goto end_IL_0035;
					case 4:
						goto end_IL_0042;
					case 0:
						return;
					case 1:
						return;
					case 2:
						return;
					}
					continue;
					end_IL_0035:
					break;
				}
				continue;
				end_IL_0042:
				break;
			}
		}
	}
}
