using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Write Name Gun", "Super Infection/Casual [MASTERCLIENT]", "Writes your name with gadgets.", false, 35, ModType.const_0, false)]
internal class Class123 : MonoBehaviour
{
	private static string string_0;

	private float float_0;

	private List<(Vector3 position, Quaternion rotation)> list_0;

	private static string[] string_1;

	private static Dictionary<string, bool[][]> dictionary_0;

	private static bool bool_0;

	private static float float_1;

	private static double double_0;

	private static int int_0;

	private static float float_2;

	private static double double_1;

	private static Class8.GunResult setDeploymentIdStrongName;

	private static Vector3 AddClaimsSourcePath;

	private static Quaternion OwnerDefaultThreadCurrentUICulture;

	private static List<(Vector3, Quaternion)>.Enumerator AssemblyReferenceDependentAssemblyEntrysetApplicationUrl;

	private static (Vector3, Quaternion) HostAppDomainEvidenceUnregisterAssembly;

	private static GameEntityCreateData getNInamesetRng;

	private static IntPtr[] UnsafeQueueUserWorkItemBinaryArray;

	private static IntPtr[] ValueFixupEnumFormatSingle;

	private static IntPtr[] MethodImplAttributePeekChar;

	private static IntPtr[] CopyToAsyncCreateOriginSchemeAccess;

	private unsafe void OnDisable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_03e1, IL_03f4, IL_0428, IL_0438, IL_0448, IL_0458, IL_0468, IL_0478, IL_0488, IL_0498, IL_04a8, IL_04bc, IL_04cf, IL_050d, IL_0520, IL_052e, IL_0541, IL_0554, IL_0562, IL_057f, IL_05ce, IL_05d8, IL_0605, IL_061e, IL_062c, IL_063a, IL_0652, IL_0660, IL_0673, IL_067e, IL_068e, IL_069c, IL_06e1, IL_06ec, IL_06ff, IL_070a, IL_0718, IL_072c, IL_076b, IL_077e, IL_078c, IL_07a0, IL_07b3, IL_07c1, IL_07cc, IL_07da, IL_0801, IL_0814, IL_0822, IL_0835, IL_0897, IL_08aa, IL_08b8, IL_08c6, IL_08d4, IL_08e2, IL_0922, IL_0936, IL_0949, IL_0957, IL_0965, IL_0988, IL_0992, IL_09a0, IL_09b3, IL_09be, IL_09e7, IL_09f5, IL_0a08, IL_0a16, IL_0a24, IL_0a2d, IL_0a3b, IL_0a7b, IL_0a8f, IL_0aa2, IL_0ab5, IL_0ac8, IL_0ad6, IL_0aee, IL_0b0c, IL_0b30, IL_0b48, IL_0b5b, IL_0b66, IL_0ba6, IL_0bba, IL_0bcd, IL_0bd8, IL_0be6, IL_0c26, IL_0c3a, IL_0c4d, IL_0c5b, IL_0c66, IL_0c79, IL_0c87, IL_0ca0, IL_0cae, IL_0cb9, IL_0cf1, IL_0d05, IL_0d18, IL_0d23, IL_0d31, IL_0d45, IL_0d7d, IL_0d90, IL_0d9e, IL_0dac, IL_0db5, IL_0dcd, IL_0ddb, IL_0de9, IL_0dfc, IL_0e0a, IL_0e15, IL_0e3e, IL_0e55, IL_0e68, IL_0e76, IL_0e81, IL_0eaa, IL_0eb8, IL_0ec8, IL_0ed3, IL_0ede, IL_0ef7, IL_0f10, IL_0f1e, IL_0f2c, IL_0f3a, IL_0f4d, IL_0f57, IL_0f62, IL_0f72, IL_0f82, IL_0f92, IL_0fa2, IL_0fb2, IL_0fc2, IL_0fd2, IL_0fe2 are reachable both inside and outside the pinned region starting at IL_0ff7. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 104;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			int __rxRef36 = default(int);
			ref int reference = ref __rxRef36;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0fe2:
					num2 = 1;
					while (true)
					{
						IL_0fd2:
						num3 = num2 * 4;
						while (true)
						{
							IL_0fc2:
							array2 = new byte[4];
							while (true)
							{
								IL_0fb2:
								array3 = new object[4];
								while (true)
								{
									IL_0fa2:
									array4 = new int[4];
									while (true)
									{
										IL_0f92:
										array5 = new int[6];
										while (true)
										{
											IL_0f82:
											array6 = new long[4];
											while (true)
											{
												IL_0f72:
												array7 = new object[13];
												while (true)
												{
													IL_0f62:
													array7[0] = this;
													while (true)
													{
														IL_0f57:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ToStringHelperFuncgetConsumptionScope.CurrencyEnumHelper);
														while (true)
														{
															IL_0f4d:
															ptr2 = ptr;
															while (true)
															{
																IL_0f3a:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_04a8:
																	byte b = *ptr2;
																	num = 195;
																	while (true)
																	{
																		IL_0498:
																		ptr2++;
																		while (true)
																		{
																			IL_0488:
																			if (b >= 1)
																			{
																				while (b <= 24)
																				{
																					while (true)
																					{
																						IL_0468:
																						if (12 < b)
																						{
																							while (true)
																							{
																								IL_0458:
																								if (18 >= b)
																								{
																									while (true)
																									{
																										IL_0448:
																										if (18 > b)
																										{
																											num = 160;
																											while (true)
																											{
																												IL_0438:
																												if (15 >= b)
																												{
																													while (true)
																													{
																														IL_0428:
																														if (15 <= b)
																														{
																															while (true)
																															{
																																IL_03f4:
																																array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																																num = 241;
																																while (true)
																																{
																																	if (num != 241)
																																	{
																																		if (num != 1222)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 104:
																																			break;
																																		default:
																																			continue;
																																		case 18:
																																		case 55:
																																			goto IL_03f4;
																																		case 150:
																																			goto IL_0428;
																																		case 129:
																																		case 160:
																																			goto IL_0438;
																																		case 95:
																																			goto IL_0448;
																																		case 76:
																																			goto IL_0458;
																																		case 177:
																																			goto IL_0468;
																																		case 56:
																																			goto IL_0478;
																																		case 16:
																																			goto IL_0488;
																																		case 195:
																																			goto IL_0498;
																																		case 36:
																																		case 199:
																																			goto IL_04a8;
																																		case 69:
																																			goto IL_04bc;
																																		case 6:
																																		case 73:
																																			goto IL_04cf;
																																		case 50:
																																			goto IL_050d;
																																		case 119:
																																		case 137:
																																			goto IL_0520;
																																		case 58:
																																			goto IL_052e;
																																		case 141:
																																			goto IL_0541;
																																		case 145:
																																			goto IL_0554;
																																		case 13:
																																		case 108:
																																			goto IL_0562;
																																		case 146:
																																			goto IL_061e;
																																		case 7:
																																		case 81:
																																			goto IL_062c;
																																		case 75:
																																			goto IL_063a;
																																		case 158:
																																			goto IL_0652;
																																		case 122:
																																			goto IL_0660;
																																		case 184:
																																			goto IL_0673;
																																		case 5:
																																		case 106:
																																			goto IL_067e;
																																		case 188:
																																			goto IL_068e;
																																		case 77:
																																		case 186:
																																			goto IL_069c;
																																		case 203:
																																			goto IL_06e1;
																																		case 32:
																																			goto IL_06ec;
																																		case 105:
																																			goto IL_06ff;
																																		case 113:
																																			goto IL_070a;
																																		case 123:
																																		case 169:
																																			goto IL_0718;
																																		case 193:
																																			goto IL_072c;
																																		case 53:
																																			goto IL_076b;
																																		case 206:
																																			goto IL_078c;
																																		case 49:
																																			goto IL_07a0;
																																		case 197:
																																		case 211:
																																			goto IL_07b3;
																																		case 124:
																																			goto IL_07c1;
																																		case 28:
																																		case 189:
																																			goto IL_07da;
																																		case 111:
																																			goto IL_0801;
																																		case 213:
																																			goto IL_0814;
																																		case 3:
																																			goto IL_0822;
																																		case 14:
																																		case 218:
																																			goto IL_0835;
																																		case 84:
																																			goto IL_0897;
																																		case 92:
																																		case 224:
																																			goto IL_08aa;
																																		case 38:
																																		case 180:
																																			goto IL_08b8;
																																		case 168:
																																		case 215:
																																			goto IL_08c6;
																																		case 204:
																																			goto IL_08d4;
																																		case 68:
																																		case 117:
																																			goto IL_08e2;
																																		case 167:
																																			goto IL_0922;
																																		case 45:
																																			goto IL_0936;
																																		case 44:
																																			goto IL_0949;
																																		case 29:
																																		case 179:
																																			goto IL_0957;
																																		case 192:
																																			goto IL_0965;
																																		case 209:
																																			goto IL_0988;
																																		case 93:
																																			goto IL_0992;
																																		case 110:
																																			goto IL_09a0;
																																		case 4:
																																			goto IL_09b3;
																																		case 1:
																																		case 46:
																																			goto IL_09be;
																																		case 61:
																																			goto IL_09e7;
																																		case 78:
																																			goto IL_09f5;
																																		case 30:
																																			goto IL_0a08;
																																		case 138:
																																		case 144:
																																			goto IL_0a16;
																																		case 100:
																																			goto IL_0a2d;
																																		case 112:
																																		case 135:
																																			goto IL_0a3b;
																																		case 22:
																																			goto IL_0a7b;
																																		case 178:
																																			goto IL_0a8f;
																																		case 86:
																																			goto IL_0aa2;
																																		case 226:
																																			goto IL_0ab5;
																																		case 230:
																																			goto IL_0ac8;
																																		case 8:
																																		case 198:
																																			goto IL_0ad6;
																																		case 118:
																																			goto IL_0aee;
																																		case 229:
																																			goto IL_0b0c;
																																		case 41:
																																			goto IL_0b30;
																																		case 214:
																																			goto IL_0b48;
																																		case 234:
																																			goto IL_0b5b;
																																		case 24:
																																		case 187:
																																			goto IL_0b66;
																																		case 191:
																																			goto IL_0ba6;
																																		case 212:
																																			goto IL_0bba;
																																		case 64:
																																			goto IL_0bcd;
																																		case 140:
																																			goto IL_0bd8;
																																		case 89:
																																		case 232:
																																			goto IL_0be6;
																																		case 151:
																																			goto IL_0c26;
																																		case 63:
																																			goto IL_0c3a;
																																		case 98:
																																			goto end_IL_03e1;
																																		case 222:
																																			goto IL_0c5b;
																																		case 71:
																																		case 172:
																																			goto IL_0c66;
																																		case 216:
																																			goto IL_0ca0;
																																		case 147:
																																			goto IL_0cae;
																																		case 2:
																																		case 130:
																																			goto IL_0cb9;
																																		case 102:
																																			goto IL_0cf1;
																																		case 182:
																																			goto IL_0d05;
																																		case 223:
																																			goto IL_0d18;
																																		case 134:
																																			goto IL_0d23;
																																		case 54:
																																		case 205:
																																			goto IL_0d31;
																																		case 62:
																																			goto IL_0d45;
																																		case 74:
																																			goto IL_0d7d;
																																		case 17:
																																			goto IL_0d90;
																																		case 128:
																																			goto IL_0d9e;
																																		case 219:
																																		case 228:
																																			goto IL_0db5;
																																		case 143:
																																			goto IL_0dcd;
																																		case 162:
																																			goto IL_0ddb;
																																		case 227:
																																			goto IL_0de9;
																																		case 220:
																																			goto IL_0dfc;
																																		case 31:
																																			goto IL_0e0a;
																																		case 57:
																																		case 85:
																																			goto IL_0e15;
																																		case 59:
																																			goto IL_0e3e;
																																		case 33:
																																			goto IL_0e55;
																																		case 142:
																																			goto IL_0e68;
																																		case 25:
																																			goto IL_0e76;
																																		case 87:
																																		case 94:
																																			goto IL_0e81;
																																		case 90:
																																			goto IL_0eaa;
																																		case 79:
																																			goto IL_0eb8;
																																		case 175:
																																			goto IL_0ec8;
																																		case 196:
																																			goto IL_0ed3;
																																		case 48:
																																		case 233:
																																			goto IL_0ede;
																																		case 0:
																																		case 9:
																																		case 10:
																																		case 12:
																																		case 15:
																																		case 23:
																																		case 26:
																																		case 35:
																																		case 37:
																																		case 40:
																																		case 42:
																																		case 51:
																																		case 60:
																																		case 67:
																																		case 70:
																																		case 83:
																																		case 107:
																																		case 109:
																																		case 115:
																																		case 116:
																																		case 125:
																																		case 131:
																																		case 132:
																																		case 136:
																																		case 139:
																																		case 149:
																																		case 154:
																																		case 156:
																																		case 161:
																																		case 164:
																																		case 165:
																																		case 166:
																																		case 171:
																																		case 173:
																																		case 174:
																																		case 176:
																																		case 183:
																																		case 185:
																																		case 190:
																																		case 202:
																																		case 210:
																																		case 225:
																																		case 231:
																																			goto end_IL_0478;
																																		case 11:
																																			goto IL_0f10;
																																		case 66:
																																			goto IL_0f1e;
																																		case 207:
																																			goto IL_0f2c;
																																		case 19:
																																		case 20:
																																		case 21:
																																		case 27:
																																		case 34:
																																		case 47:
																																		case 52:
																																		case 65:
																																		case 72:
																																		case 88:
																																		case 99:
																																		case 101:
																																		case 114:
																																		case 120:
																																		case 121:
																																		case 133:
																																		case 152:
																																		case 155:
																																		case 157:
																																		case 159:
																																		case 170:
																																		case 181:
																																		case 194:
																																		case 200:
																																		case 201:
																																		case 217:
																																		case 221:
																																			goto IL_0f3a;
																																		case 163:
																																			goto IL_0f4d;
																																		case 39:
																																			goto IL_0f57;
																																		case 97:
																																			goto IL_0f62;
																																		case 43:
																																			goto IL_0f72;
																																		case 96:
																																			goto IL_0f82;
																																		case 126:
																																			goto IL_0f92;
																																		case 82:
																																			goto IL_0fa2;
																																		case 148:
																																			goto IL_0fb2;
																																		case 127:
																																		case 208:
																																			goto IL_0fc2;
																																		case 80:
																																			goto IL_0fd2;
																																		case 103:
																																			goto IL_0fe2;
																																		case 91:
																																		case 153:
																																			return;
																																		}
																																		goto end_IL_0468;
																																	}
																																	array2[num5 - 1] = 5;
																																	goto IL_0f3a;
																																	continue;
																																	end_IL_03e1:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_04bc;
																														IL_0822:
																														num5++;
																														goto IL_0f3a;
																														IL_04bc:
																														if (13 >= b)
																														{
																															goto IL_0554;
																														}
																														goto IL_07b3;
																														IL_07b3:
																														if (14 < b)
																														{
																															goto end_IL_0478;
																														}
																														goto IL_07c1;
																														IL_07c1:
																														if (14 > b)
																														{
																															num = 35;
																															goto end_IL_0478;
																														}
																														goto IL_07da;
																														IL_0814:
																														array2[num5] = 5;
																														goto IL_0822;
																														IL_07da:
																														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																														num = 111;
																														goto IL_0801;
																														IL_0801:
																														ptr2 += 8;
																														goto IL_0ab5;
																														IL_0ab5:
																														num5--;
																														goto IL_0f3a;
																														IL_0554:
																														if (13 > b)
																														{
																															goto end_IL_0478;
																														}
																														goto IL_0562;
																														IL_0562:
																														array8 = array3;
																														num6 = num5;
																														if (array == null)
																														{
																															goto IL_0571;
																														}
																														num7 = ptr2;
																														byte b2 = *num7;
																														ptr2 = num7 + 4;
																														int num8 = *(int*)(ptr2 + num3);
																														ptr2 += 8;
																														byte* ptr3 = ptr2 + num8;
																														byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																														while (ptr2 != ptr3)
																														{
																															*ptr4 = (byte)(*ptr2 ^ b2);
																															ptr2++;
																															ptr4++;
																														}
																														array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																														goto IL_0814;
																													}
																													break;
																												}
																												goto IL_0520;
																												IL_0b48:
																												num5++;
																												goto IL_0f3a;
																												IL_0520:
																												if (16 < b)
																												{
																													goto IL_052e;
																												}
																												goto IL_0ac8;
																												IL_052e:
																												if (17 < b)
																												{
																													goto end_IL_0478;
																												}
																												goto IL_061e;
																												IL_061e:
																												if (17 > b)
																												{
																													goto end_IL_0478;
																												}
																												goto IL_062c;
																												IL_062c:
																												array2[num5] = 5;
																												goto IL_063a;
																												IL_063a:
																												array3[num5] = array7[*(int*)(ptr2 + num3)];
																												goto IL_0652;
																												IL_0652:
																												num5++;
																												goto IL_0660;
																												IL_0660:
																												ptr2 += 8;
																												goto IL_0f3a;
																												IL_0ac8:
																												if (16 > b)
																												{
																													goto end_IL_0478;
																												}
																												goto IL_0ad6;
																												IL_0ad6:
																												array2[num5] = array2[num5 - 1];
																												goto IL_0aee;
																												IL_0aee:
																												array4[num5 - 0] = array4[num5 - 1];
																												goto IL_0b0c;
																												IL_0b0c:
																												*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																												goto IL_0b30;
																												IL_0b30:
																												array3[num5] = array3[num5 - 1];
																												goto IL_0b48;
																											}
																											break;
																										}
																										goto IL_04cf;
																										IL_04cf:
																										((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																										goto IL_050d;
																										IL_050d:
																										num5 -= 3;
																										goto IL_0f3a;
																									}
																									break;
																								}
																								goto IL_0ca0;
																								IL_0ed3:
																								if (24 > b)
																								{
																									goto end_IL_0478;
																								}
																								goto IL_0ede;
																								IL_0ca0:
																								if (21 >= b)
																								{
																									goto IL_0cae;
																								}
																								goto IL_0dfc;
																								IL_0cae:
																								if (21 <= b)
																								{
																									goto IL_0cb9;
																								}
																								goto IL_0d18;
																								IL_0cb9:
																								array3[num5 - 1] = ((delegate*<Class123, List<(Vector3, Quaternion)>>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((Class123)array3[num5 - 1]);
																								goto IL_0cf1;
																								IL_0cf1:
																								array2[num5 - 1] = 5;
																								goto IL_0d05;
																								IL_0d05:
																								ptr2 += 8;
																								goto IL_0f3a;
																								IL_0d18:
																								if (19 >= b)
																								{
																									goto IL_0d23;
																								}
																								goto IL_0d90;
																								IL_0d23:
																								if (19 > b)
																								{
																									goto end_IL_0478;
																								}
																								goto IL_0d31;
																								IL_0d31:
																								array2[num5 - 1] = 5;
																								goto IL_0d45;
																								IL_0d45:
																								array3[num5 - 1] = ((delegate*<string[], string>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																								goto IL_0d7d;
																								IL_0d7d:
																								ptr2 += 8;
																								goto IL_0f3a;
																								IL_0d90:
																								if (20 < b)
																								{
																									goto end_IL_0478;
																								}
																								goto IL_0d9e;
																								IL_0d9e:
																								if (20 > b)
																								{
																									goto end_IL_0478;
																								}
																								num = 219;
																								goto IL_0db5;
																								IL_0ede:
																								num9 = ptr2;
																								num10 = -200;
																								num4 = 1;
																								ptr2 = num9 + num10;
																								goto IL_0f3a;
																								IL_0db5:
																								array3[num5] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0dcd;
																								IL_0dcd:
																								array2[num5] = 5;
																								goto IL_0ddb;
																								IL_0ddb:
																								num5++;
																								goto IL_0de9;
																								IL_0de9:
																								ptr2 += 8;
																								goto IL_0f3a;
																								IL_0dfc:
																								if (23 >= b)
																								{
																									goto IL_0e0a;
																								}
																								goto IL_0ec8;
																								IL_0e0a:
																								if (23 <= b)
																								{
																									goto IL_0e15;
																								}
																								goto IL_0e68;
																								IL_0e15:
																								((delegate*<string, void>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																								goto IL_0e3e;
																								IL_0e3e:
																								num5--;
																								num = 33;
																								goto IL_0e55;
																								IL_0e55:
																								ptr2 += 8;
																								goto IL_0f3a;
																								IL_0e68:
																								if (22 < b)
																								{
																									goto end_IL_0478;
																								}
																								goto IL_0e76;
																								IL_0e76:
																								if (22 > b)
																								{
																									goto end_IL_0478;
																								}
																								goto IL_0e81;
																								IL_0e81:
																								((delegate*<List<(Vector3, Quaternion)>, void>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((List<(Vector3, Quaternion)>)array3[num5 - 1]);
																								goto IL_0eaa;
																								IL_0eaa:
																								num5--;
																								goto IL_0eb8;
																								IL_0eb8:
																								ptr2 += 8;
																								goto IL_0f3a;
																								IL_0ec8:
																								if (24 < b)
																								{
																									goto end_IL_0478;
																								}
																								goto IL_0ed3;
																							}
																							goto IL_0c4d;
																						}
																						goto IL_0541;
																						IL_0a3b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0a7b;
																						IL_0541:
																						if (12 <= b)
																						{
																							goto IL_0f3a;
																						}
																						goto IL_0673;
																						IL_0673:
																						if (6 < b)
																						{
																							goto IL_067e;
																						}
																						goto IL_068e;
																						IL_067e:
																						if (9 < b)
																						{
																							goto IL_06e1;
																						}
																						goto IL_0b5b;
																						IL_0b5b:
																						if (9 <= b)
																						{
																							goto IL_0b66;
																						}
																						goto IL_0bcd;
																						IL_0b66:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0ba6;
																						IL_0ba6:
																						array2[num5 - 2] = 0;
																						goto IL_0bba;
																						IL_0bba:
																						num5--;
																						goto IL_0f3a;
																						IL_0bcd:
																						if (7 >= b)
																						{
																							goto IL_0bd8;
																						}
																						goto IL_0c4d;
																						IL_0bd8:
																						if (7 > b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_0be6;
																						IL_0be6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0c26;
																						IL_0c26:
																						array2[num5 - 2] = 0;
																						goto IL_0c3a;
																						IL_0c3a:
																						num5--;
																						goto IL_0f3a;
																						IL_0c4d:
																						if (8 < b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_0c5b;
																						IL_0c5b:
																						if (8 > b)
																						{
																							num = 60;
																							goto end_IL_0478;
																						}
																						goto IL_0c66;
																						IL_0c66:
																						num5--;
																						goto IL_0f3a;
																						IL_0a7b:
																						array2[num5 - 2] = 0;
																						goto IL_0a8f;
																						IL_06e1:
																						if (10 >= b)
																						{
																							goto IL_06ec;
																						}
																						goto IL_06ff;
																						IL_06ec:
																						if (10 > b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_0835;
																						IL_0835:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0897;
																						IL_0897:
																						num5 -= 2;
																						goto IL_0f3a;
																						IL_06ff:
																						if (11 < b)
																						{
																							num = 115;
																							goto end_IL_0478;
																						}
																						goto IL_070a;
																						IL_070a:
																						if (11 > b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_0718;
																						IL_0718:
																						array2[num5 - 1] = 0;
																						goto IL_072c;
																						IL_072c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_076b;
																						IL_076b:
																						ptr2 += 8;
																						goto IL_0f3a;
																						IL_0a8f:
																						num5--;
																						goto IL_0f3a;
																						IL_068e:
																						if (6 <= b)
																						{
																							goto IL_069c;
																						}
																						goto IL_08aa;
																						IL_069c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_078c;
																						IL_078c:
																						array2[num5 - 2] = 0;
																						goto IL_07a0;
																						IL_07a0:
																						num5--;
																						goto IL_0f3a;
																						IL_08aa:
																						if (3 < b)
																						{
																							goto IL_08b8;
																						}
																						goto IL_09b3;
																						IL_08b8:
																						if (4 < b)
																						{
																							goto IL_08c6;
																						}
																						goto IL_0949;
																						IL_08c6:
																						if (5 < b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_08d4;
																						IL_08d4:
																						if (5 > b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_08e2;
																						IL_08e2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0922;
																						IL_0922:
																						array2[num5 - 2] = 0;
																						goto IL_0936;
																						IL_0936:
																						num5--;
																						goto IL_0f3a;
																						IL_0949:
																						if (4 > b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_0957;
																						IL_0957:
																						array2[num5] = 0;
																						goto IL_0965;
																						IL_0965:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0988;
																						IL_0988:
																						array3[num5] = null;
																						goto IL_0992;
																						IL_0992:
																						num5++;
																						goto IL_09a0;
																						IL_09a0:
																						ptr2 += 8;
																						goto IL_0f3a;
																						IL_09b3:
																						if (3 <= b)
																						{
																							goto IL_09be;
																						}
																						goto IL_0a08;
																						IL_09be:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_09e7;
																						IL_09e7:
																						ptr2 += 8;
																						goto IL_09f5;
																						IL_09f5:
																						num5--;
																						goto IL_0f3a;
																						IL_0a08:
																						if (1 < b)
																						{
																							goto IL_0a16;
																						}
																						goto IL_0aa2;
																						IL_0a16:
																						if (2 < b)
																						{
																							goto end_IL_0478;
																						}
																						num = 100;
																						goto IL_0a2d;
																						IL_0aa2:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0478;
																						IL_0a2d:
																						if (2 > b)
																						{
																							goto end_IL_0478;
																						}
																						goto IL_0a3b;
																						continue;
																						end_IL_0468:
																						break;
																					}
																					goto end_IL_0488;
																					continue;
																					end_IL_0478:
																					break;
																					IL_0478:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0f10;
																			IL_0f2c:
																			ptr2 += 8;
																			goto IL_0f3a;
																			IL_0f1e:
																			num5++;
																			goto IL_0f2c;
																			IL_0f10:
																			array2[num5] = 0;
																			goto IL_0f1e;
																			continue;
																			end_IL_0488:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0571:
			while (true)
			{
				IL_0571_2:
				array = new byte[4];
				while (true)
				{
					IL_057f:
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num5] = 5;
						while (true)
						{
							IL_0822_2:
							num5++;
							while (true)
							{
								IL_0f3a_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									num = 195;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0488_2:
											if (b >= 1)
											{
												while (b <= 24)
												{
													while (true)
													{
														IL_0468_2:
														if (12 < b)
														{
															while (true)
															{
																IL_0458_2:
																if (18 >= b)
																{
																	while (true)
																	{
																		IL_0448_2:
																		if (18 > b)
																		{
																			num = 160;
																			while (true)
																			{
																				IL_0438_2:
																				if (15 >= b)
																				{
																					while (true)
																					{
																						IL_0428_2:
																						if (15 <= b)
																						{
																							while (true)
																							{
																								IL_03f4_2:
																								array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																								num = 241;
																								while (true)
																								{
																									if (num != 241)
																									{
																										if (num != 1222)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 18:
																										case 55:
																											goto IL_03f4_2;
																										case 150:
																											goto IL_0428_2;
																										case 129:
																										case 160:
																											goto IL_0438_2;
																										case 95:
																											goto IL_0448_2;
																										case 76:
																											goto IL_0458_2;
																										case 177:
																											goto IL_0468_2;
																										case 56:
																											goto end_IL_0468_2;
																										case 16:
																											goto IL_0488_2;
																										case 195:
																											goto end_IL_0488_2;
																										case 36:
																										case 199:
																											goto end_IL_0498;
																										case 69:
																											goto IL_04bc_2;
																										case 6:
																										case 73:
																											goto IL_04cf_2;
																										case 50:
																											goto IL_050d_2;
																										case 119:
																										case 137:
																											goto IL_0520_2;
																										case 58:
																											goto IL_052e_2;
																										case 141:
																											goto IL_0541_2;
																										case 145:
																											goto IL_0554_2;
																										case 13:
																										case 108:
																											goto IL_0562_2;
																										case 146:
																											goto IL_061e_2;
																										case 7:
																										case 81:
																											goto IL_062c_2;
																										case 75:
																											goto IL_063a_2;
																										case 158:
																											goto IL_0652_2;
																										case 122:
																											goto IL_0660_2;
																										case 184:
																											goto IL_0673_2;
																										case 5:
																										case 106:
																											goto IL_067e_2;
																										case 188:
																											goto IL_068e_2;
																										case 77:
																										case 186:
																											goto IL_069c_2;
																										case 203:
																											goto IL_06e1_2;
																										case 32:
																											goto IL_06ec_2;
																										case 105:
																											goto IL_06ff_2;
																										case 113:
																											goto IL_070a_2;
																										case 123:
																										case 169:
																											goto IL_0718_2;
																										case 193:
																											goto IL_072c_2;
																										case 53:
																											goto IL_076b_2;
																										case 206:
																											goto IL_078c_2;
																										case 49:
																											goto IL_07a0_2;
																										case 197:
																										case 211:
																											goto IL_07b3_2;
																										case 124:
																											goto IL_07c1_2;
																										case 28:
																										case 189:
																											goto IL_07da_2;
																										case 111:
																											goto IL_0801_2;
																										case 213:
																											goto end_IL_04a8;
																										case 3:
																											goto IL_0822_2;
																										case 14:
																										case 218:
																											goto IL_0835_2;
																										case 84:
																											goto IL_0897_2;
																										case 92:
																										case 224:
																											goto IL_08aa_2;
																										case 38:
																										case 180:
																											goto IL_08b8_2;
																										case 168:
																										case 215:
																											goto IL_08c6_2;
																										case 204:
																											goto IL_08d4_2;
																										case 68:
																										case 117:
																											goto IL_08e2_2;
																										case 167:
																											goto IL_0922_2;
																										case 45:
																											goto IL_0936_2;
																										case 44:
																											goto IL_0949_2;
																										case 29:
																										case 179:
																											goto IL_0957_2;
																										case 192:
																											goto IL_0965_2;
																										case 209:
																											goto IL_0988_2;
																										case 93:
																											goto IL_0992_2;
																										case 110:
																											goto IL_09a0_2;
																										case 4:
																											goto IL_09b3_2;
																										case 1:
																										case 46:
																											goto IL_09be_2;
																										case 61:
																											goto IL_09e7_2;
																										case 78:
																											goto IL_09f5_2;
																										case 30:
																											goto IL_0a08_2;
																										case 138:
																										case 144:
																											goto IL_0a16_2;
																										case 100:
																											goto IL_0a2d_2;
																										case 112:
																										case 135:
																											goto IL_0a3b_2;
																										case 22:
																											goto IL_0a7b_2;
																										case 178:
																											goto IL_0a8f_2;
																										case 86:
																											goto IL_0aa2_2;
																										case 226:
																											goto IL_0ab5_2;
																										case 230:
																											goto IL_0ac8_2;
																										case 8:
																										case 198:
																											goto IL_0ad6_2;
																										case 118:
																											goto IL_0aee_2;
																										case 229:
																											goto IL_0b0c_2;
																										case 41:
																											goto IL_0b30_2;
																										case 214:
																											goto IL_0b48_2;
																										case 234:
																											goto IL_0b5b_2;
																										case 24:
																										case 187:
																											goto IL_0b66_2;
																										case 191:
																											goto IL_0ba6_2;
																										case 212:
																											goto IL_0bba_2;
																										case 64:
																											goto IL_0bcd_2;
																										case 140:
																											goto IL_0bd8_2;
																										case 89:
																										case 232:
																											goto IL_0be6_2;
																										case 151:
																											goto IL_0c26_2;
																										case 63:
																											goto IL_0c3a_2;
																										case 98:
																											goto end_IL_03e1_2;
																										case 222:
																											goto IL_0c5b_2;
																										case 71:
																										case 172:
																											goto IL_0c66_2;
																										case 216:
																											goto IL_0ca0_2;
																										case 147:
																											goto IL_0cae_2;
																										case 2:
																										case 130:
																											goto IL_0cb9_2;
																										case 102:
																											goto IL_0cf1_2;
																										case 182:
																											goto IL_0d05_2;
																										case 223:
																											goto IL_0d18_2;
																										case 134:
																											goto IL_0d23_2;
																										case 54:
																										case 205:
																											goto IL_0d31_2;
																										case 62:
																											goto IL_0d45_2;
																										case 74:
																											goto IL_0d7d_2;
																										case 17:
																											goto IL_0d90_2;
																										case 128:
																											goto IL_0d9e_2;
																										case 219:
																										case 228:
																											goto IL_0db5_2;
																										case 143:
																											goto IL_0dcd_2;
																										case 162:
																											goto IL_0ddb_2;
																										case 227:
																											goto IL_0de9_2;
																										case 220:
																											goto IL_0dfc_2;
																										case 31:
																											goto IL_0e0a_2;
																										case 57:
																										case 85:
																											goto IL_0e15_2;
																										case 59:
																											goto IL_0e3e_2;
																										case 33:
																											goto IL_0e55_2;
																										case 142:
																											goto IL_0e68_2;
																										case 25:
																											goto IL_0e76_2;
																										case 87:
																										case 94:
																											goto IL_0e81_2;
																										case 90:
																											goto IL_0eaa_2;
																										case 79:
																											goto IL_0eb8_2;
																										case 175:
																											goto IL_0ec8_2;
																										case 196:
																											goto IL_0ed3_2;
																										case 48:
																										case 233:
																											goto IL_0ede_2;
																										case 0:
																										case 9:
																										case 10:
																										case 12:
																										case 15:
																										case 23:
																										case 26:
																										case 35:
																										case 37:
																										case 40:
																										case 42:
																										case 51:
																										case 60:
																										case 67:
																										case 70:
																										case 83:
																										case 107:
																										case 109:
																										case 115:
																										case 116:
																										case 125:
																										case 131:
																										case 132:
																										case 136:
																										case 139:
																										case 149:
																										case 154:
																										case 156:
																										case 161:
																										case 164:
																										case 165:
																										case 166:
																										case 171:
																										case 173:
																										case 174:
																										case 176:
																										case 183:
																										case 185:
																										case 190:
																										case 202:
																										case 210:
																										case 225:
																										case 231:
																											goto end_IL_0478_2;
																										case 11:
																											goto IL_0f10_2;
																										case 66:
																											goto IL_0f1e_2;
																										case 207:
																											goto IL_0f2c_2;
																										case 19:
																										case 20:
																										case 21:
																										case 27:
																										case 34:
																										case 47:
																										case 52:
																										case 65:
																										case 72:
																										case 88:
																										case 99:
																										case 101:
																										case 114:
																										case 120:
																										case 121:
																										case 133:
																										case 152:
																										case 155:
																										case 157:
																										case 159:
																										case 170:
																										case 181:
																										case 194:
																										case 200:
																										case 201:
																										case 217:
																										case 221:
																											goto IL_0f3a_2;
																										case 163:
																											ptr2 = ptr;
																											goto IL_0f3a_2;
																										case 39:
																											ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ToStringHelperFuncgetConsumptionScope.CurrencyEnumHelper);
																											goto case 163;
																										case 97:
																											array7[0] = this;
																											goto case 39;
																										case 43:
																											array7 = new object[13];
																											goto case 97;
																										case 96:
																											array6 = new long[4];
																											goto case 43;
																										case 126:
																											array5 = new int[6];
																											goto case 96;
																										case 82:
																											array4 = new int[4];
																											goto case 126;
																										case 148:
																											array3 = new object[4];
																											goto case 82;
																										case 127:
																										case 208:
																											array2 = new byte[4];
																											goto case 148;
																										case 80:
																											num3 = num2 * 4;
																											goto case 127;
																										case 103:
																											num2 = 1;
																											goto case 80;
																										case 104:
																											goto end_IL_0814;
																										case 91:
																										case 153:
																											return;
																										}
																										continue;
																									}
																									array2[num5 - 1] = 5;
																									goto IL_0f3a_2;
																									continue;
																									end_IL_03e1_2:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_04bc_2;
																						IL_0554_2:
																						if (13 > b)
																						{
																							goto end_IL_0478_2;
																						}
																						goto IL_0562_2;
																						IL_04bc_2:
																						if (13 >= b)
																						{
																							goto IL_0554_2;
																						}
																						goto IL_07b3_2;
																						IL_07b3_2:
																						if (14 < b)
																						{
																							goto end_IL_0478_2;
																						}
																						goto IL_07c1_2;
																						IL_07c1_2:
																						if (14 > b)
																						{
																							num = 35;
																							goto end_IL_0478_2;
																						}
																						goto IL_07da_2;
																						IL_0562_2:
																						array8 = array3;
																						num6 = num5;
																						if (array == null)
																						{
																							goto IL_0571_2;
																						}
																						goto IL_057f;
																						IL_07da_2:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						num = 111;
																						goto IL_0801_2;
																						IL_0801_2:
																						ptr2 += 8;
																						goto IL_0ab5_2;
																						IL_0ab5_2:
																						num5--;
																						goto IL_0f3a_2;
																					}
																					break;
																				}
																				goto IL_0520_2;
																				IL_0b48_2:
																				num5++;
																				goto IL_0f3a_2;
																				IL_0520_2:
																				if (16 < b)
																				{
																					goto IL_052e_2;
																				}
																				goto IL_0ac8_2;
																				IL_052e_2:
																				if (17 < b)
																				{
																					goto end_IL_0478_2;
																				}
																				goto IL_061e_2;
																				IL_061e_2:
																				if (17 > b)
																				{
																					goto end_IL_0478_2;
																				}
																				goto IL_062c_2;
																				IL_062c_2:
																				array2[num5] = 5;
																				goto IL_063a_2;
																				IL_063a_2:
																				array3[num5] = array7[*(int*)(ptr2 + num3)];
																				goto IL_0652_2;
																				IL_0652_2:
																				num5++;
																				goto IL_0660_2;
																				IL_0660_2:
																				ptr2 += 8;
																				goto IL_0f3a_2;
																				IL_0ac8_2:
																				if (16 > b)
																				{
																					goto end_IL_0478_2;
																				}
																				goto IL_0ad6_2;
																				IL_0ad6_2:
																				array2[num5] = array2[num5 - 1];
																				goto IL_0aee_2;
																				IL_0aee_2:
																				array4[num5 - 0] = array4[num5 - 1];
																				goto IL_0b0c_2;
																				IL_0b0c_2:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																				goto IL_0b30_2;
																				IL_0b30_2:
																				array3[num5] = array3[num5 - 1];
																				goto IL_0b48_2;
																			}
																			break;
																		}
																		goto IL_04cf_2;
																		IL_04cf_2:
																		((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																		goto IL_050d_2;
																		IL_050d_2:
																		num5 -= 3;
																		goto IL_0f3a_2;
																	}
																	break;
																}
																goto IL_0ca0_2;
																IL_0ed3_2:
																if (24 > b)
																{
																	goto end_IL_0478_2;
																}
																goto IL_0ede_2;
																IL_0ca0_2:
																if (21 >= b)
																{
																	goto IL_0cae_2;
																}
																goto IL_0dfc_2;
																IL_0cae_2:
																if (21 <= b)
																{
																	goto IL_0cb9_2;
																}
																goto IL_0d18_2;
																IL_0cb9_2:
																array3[num5 - 1] = ((delegate*<Class123, List<(Vector3, Quaternion)>>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((Class123)array3[num5 - 1]);
																goto IL_0cf1_2;
																IL_0cf1_2:
																array2[num5 - 1] = 5;
																goto IL_0d05_2;
																IL_0d05_2:
																ptr2 += 8;
																goto IL_0f3a_2;
																IL_0d18_2:
																if (19 >= b)
																{
																	goto IL_0d23_2;
																}
																goto IL_0d90_2;
																IL_0d23_2:
																if (19 > b)
																{
																	goto end_IL_0478_2;
																}
																goto IL_0d31_2;
																IL_0d31_2:
																array2[num5 - 1] = 5;
																goto IL_0d45_2;
																IL_0d45_2:
																array3[num5 - 1] = ((delegate*<string[], string>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																goto IL_0d7d_2;
																IL_0d7d_2:
																ptr2 += 8;
																goto IL_0f3a_2;
																IL_0d90_2:
																if (20 < b)
																{
																	goto end_IL_0478_2;
																}
																goto IL_0d9e_2;
																IL_0d9e_2:
																if (20 > b)
																{
																	goto end_IL_0478_2;
																}
																num = 219;
																goto IL_0db5_2;
																IL_0ede_2:
																num9 = ptr2;
																num10 = -200;
																num4 = 1;
																ptr2 = num9 + num10;
																goto IL_0f3a_2;
																IL_0db5_2:
																array3[num5] = array7[*(int*)(ptr2 + num3)];
																goto IL_0dcd_2;
																IL_0dcd_2:
																array2[num5] = 5;
																goto IL_0ddb_2;
																IL_0ddb_2:
																num5++;
																goto IL_0de9_2;
																IL_0de9_2:
																ptr2 += 8;
																goto IL_0f3a_2;
																IL_0dfc_2:
																if (23 >= b)
																{
																	goto IL_0e0a_2;
																}
																goto IL_0ec8_2;
																IL_0e0a_2:
																if (23 <= b)
																{
																	goto IL_0e15_2;
																}
																goto IL_0e68_2;
																IL_0e15_2:
																((delegate*<string, void>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																goto IL_0e3e_2;
																IL_0e3e_2:
																num5--;
																num = 33;
																goto IL_0e55_2;
																IL_0e55_2:
																ptr2 += 8;
																goto IL_0f3a_2;
																IL_0e68_2:
																if (22 < b)
																{
																	goto end_IL_0478_2;
																}
																goto IL_0e76_2;
																IL_0e76_2:
																if (22 > b)
																{
																	goto end_IL_0478_2;
																}
																goto IL_0e81_2;
																IL_0e81_2:
																((delegate*<List<(Vector3, Quaternion)>, void>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])((List<(Vector3, Quaternion)>)array3[num5 - 1]);
																goto IL_0eaa_2;
																IL_0eaa_2:
																num5--;
																goto IL_0eb8_2;
																IL_0eb8_2:
																ptr2 += 8;
																goto IL_0f3a_2;
																IL_0ec8_2:
																if (24 < b)
																{
																	goto end_IL_0478_2;
																}
																goto IL_0ed3_2;
															}
															goto IL_0c4d_2;
														}
														goto IL_0541_2;
														IL_0a3b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0a7b_2;
														IL_0541_2:
														if (12 <= b)
														{
															goto IL_0f3a_2;
														}
														goto IL_0673_2;
														IL_0673_2:
														if (6 < b)
														{
															goto IL_067e_2;
														}
														goto IL_068e_2;
														IL_067e_2:
														if (9 < b)
														{
															goto IL_06e1_2;
														}
														goto IL_0b5b_2;
														IL_0b5b_2:
														if (9 <= b)
														{
															goto IL_0b66_2;
														}
														goto IL_0bcd_2;
														IL_0b66_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0ba6_2;
														IL_0ba6_2:
														array2[num5 - 2] = 0;
														goto IL_0bba_2;
														IL_0bba_2:
														num5--;
														goto IL_0f3a_2;
														IL_0bcd_2:
														if (7 >= b)
														{
															goto IL_0bd8_2;
														}
														goto IL_0c4d_2;
														IL_0bd8_2:
														if (7 > b)
														{
															goto end_IL_0478_2;
														}
														goto IL_0be6_2;
														IL_0be6_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0c26_2;
														IL_0c26_2:
														array2[num5 - 2] = 0;
														goto IL_0c3a_2;
														IL_0c3a_2:
														num5--;
														goto IL_0f3a_2;
														IL_0c4d_2:
														if (8 < b)
														{
															goto end_IL_0478_2;
														}
														goto IL_0c5b_2;
														IL_0c5b_2:
														if (8 > b)
														{
															num = 60;
															goto end_IL_0478_2;
														}
														goto IL_0c66_2;
														IL_0c66_2:
														num5--;
														goto IL_0f3a_2;
														IL_0a7b_2:
														array2[num5 - 2] = 0;
														goto IL_0a8f_2;
														IL_06e1_2:
														if (10 >= b)
														{
															goto IL_06ec_2;
														}
														goto IL_06ff_2;
														IL_06ec_2:
														if (10 > b)
														{
															goto end_IL_0478_2;
														}
														goto IL_0835_2;
														IL_0835_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0897_2;
														IL_0897_2:
														num5 -= 2;
														goto IL_0f3a_2;
														IL_06ff_2:
														if (11 < b)
														{
															num = 115;
															goto end_IL_0478_2;
														}
														goto IL_070a_2;
														IL_070a_2:
														if (11 > b)
														{
															goto end_IL_0478_2;
														}
														goto IL_0718_2;
														IL_0718_2:
														array2[num5 - 1] = 0;
														goto IL_072c_2;
														IL_072c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)ValueFixupEnumFormatSingle[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_076b_2;
														IL_076b_2:
														ptr2 += 8;
														goto IL_0f3a_2;
														IL_0a8f_2:
														num5--;
														goto IL_0f3a_2;
														IL_068e_2:
														if (6 <= b)
														{
															goto IL_069c_2;
														}
														goto IL_08aa_2;
														IL_069c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_078c_2;
														IL_078c_2:
														array2[num5 - 2] = 0;
														goto IL_07a0_2;
														IL_07a0_2:
														num5--;
														goto IL_0f3a_2;
														IL_08aa_2:
														if (3 < b)
														{
															goto IL_08b8_2;
														}
														goto IL_09b3_2;
														IL_08b8_2:
														if (4 < b)
														{
															goto IL_08c6_2;
														}
														goto IL_0949_2;
														IL_08c6_2:
														if (5 < b)
														{
															goto end_IL_0478_2;
														}
														goto IL_08d4_2;
														IL_08d4_2:
														if (5 > b)
														{
															goto end_IL_0478_2;
														}
														goto IL_08e2_2;
														IL_08e2_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0922_2;
														IL_0922_2:
														array2[num5 - 2] = 0;
														goto IL_0936_2;
														IL_0936_2:
														num5--;
														goto IL_0f3a_2;
														IL_0949_2:
														if (4 > b)
														{
															goto end_IL_0478_2;
														}
														goto IL_0957_2;
														IL_0957_2:
														array2[num5] = 0;
														goto IL_0965_2;
														IL_0965_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0988_2;
														IL_0988_2:
														array3[num5] = null;
														goto IL_0992_2;
														IL_0992_2:
														num5++;
														goto IL_09a0_2;
														IL_09a0_2:
														ptr2 += 8;
														goto IL_0f3a_2;
														IL_09b3_2:
														if (3 <= b)
														{
															goto IL_09be_2;
														}
														goto IL_0a08_2;
														IL_09be_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_09e7_2;
														IL_09e7_2:
														ptr2 += 8;
														goto IL_09f5_2;
														IL_09f5_2:
														num5--;
														goto IL_0f3a_2;
														IL_0a08_2:
														if (1 < b)
														{
															goto IL_0a16_2;
														}
														goto IL_0aa2_2;
														IL_0a16_2:
														if (2 < b)
														{
															goto end_IL_0478_2;
														}
														num = 100;
														goto IL_0a2d_2;
														IL_0aa2_2:
														if (1 > b)
														{
														}
														goto end_IL_0478_2;
														IL_0a2d_2:
														if (2 > b)
														{
															goto end_IL_0478_2;
														}
														goto IL_0a3b_2;
														continue;
														end_IL_0468_2:
														break;
													}
													continue;
													end_IL_0478_2:
													break;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_0f10_2;
											IL_0f2c_2:
											ptr2 += 8;
											goto IL_0f3a_2;
											IL_0f1e_2:
											num5++;
											goto IL_0f2c_2;
											IL_0f10_2:
											array2[num5] = 0;
											goto IL_0f1e_2;
											continue;
											end_IL_0488_2:
											break;
										}
										continue;
										end_IL_0498:
										break;
									}
									continue;
									end_IL_04a8:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0814:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 18;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 73;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MatchExactVersiongetLongLength.LongRunningFrameSecurityDescriptorWithResolver);
										while (true)
										{
											IL_0686:
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02e0:
														byte b = *ptr2;
														while (true)
														{
															IL_02d0:
															ptr2++;
															while (true)
															{
																IL_02c0:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_02a3:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0293:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0283:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0276:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0266:
																											if (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_023b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														while (true)
																														{
																															IL_022b:
																															array[num5] = 0;
																															while (true)
																															{
																																IL_021b:
																																num5++;
																																while (true)
																																{
																																	IL_0202:
																																	ptr2 += 8;
																																	num = 120;
																																	while (num != 120)
																																	{
																																		if (num != 1101)
																																		{
																																			goto end_IL_0673;
																																		}
																																		switch (num)
																																		{
																																		case 19:
																																			goto IL_0202;
																																		case 60:
																																			goto IL_021b;
																																		case 27:
																																			goto IL_022b;
																																		case 30:
																																		case 39:
																																			goto IL_023b;
																																		case 41:
																																			goto IL_0256;
																																		case 25:
																																		case 53:
																																			goto IL_0266;
																																		case 49:
																																			goto IL_0276;
																																		case 94:
																																		case 107:
																																			goto IL_0283;
																																		case 15:
																																			goto IL_0293;
																																		case 45:
																																			goto IL_02a3;
																																		case 20:
																																			goto IL_02b0;
																																		case 111:
																																			goto IL_02c0;
																																		case 110:
																																			goto IL_02d0;
																																		case 83:
																																		case 109:
																																			goto IL_02e0;
																																		case 35:
																																		case 47:
																																			goto IL_02eb;
																																		case 5:
																																		case 72:
																																			goto IL_0303;
																																		case 56:
																																			goto IL_030e;
																																		case 23:
																																		case 55:
																																			goto IL_031c;
																																		case 13:
																																			goto IL_032a;
																																		case 33:
																																			goto IL_033d;
																																		case 14:
																																		case 52:
																																			goto IL_034b;
																																		case 82:
																																			goto IL_03ad;
																																		case 88:
																																			goto IL_03c0;
																																		case 61:
																																		case 77:
																																			goto IL_03ce;
																																		case 63:
																																		case 96:
																																			goto IL_03ea;
																																		case 6:
																																			goto IL_03f5;
																																		case 22:
																																		case 70:
																																			goto IL_0403;
																																		case 24:
																																			goto IL_0443;
																																		case 44:
																																			goto IL_0462;
																																		case 46:
																																			goto IL_0470;
																																		case 7:
																																		case 102:
																																			goto IL_047e;
																																		case 112:
																																			goto IL_04a3;
																																		case 113:
																																			goto IL_04b6;
																																		case 38:
																																			goto IL_04c4;
																																		case 21:
																																			goto IL_04d2;
																																		case 103:
																																			goto IL_04e5;
																																		case 59:
																																			goto IL_04f3;
																																		case 74:
																																		case 99:
																																			goto IL_0501;
																																		case 69:
																																			goto IL_052a;
																																		case 87:
																																			goto IL_0538;
																																		case 104:
																																			goto IL_054b;
																																		case 1:
																																		case 64:
																																			goto IL_0559;
																																		case 98:
																																			goto IL_0567;
																																		case 37:
																																		case 80:
																																			goto IL_057e;
																																		case 108:
																																			goto IL_058c;
																																		case 2:
																																			goto IL_05af;
																																		case 3:
																																			goto IL_05b9;
																																		case 43:
																																			goto IL_05c7;
																																		case 4:
																																			goto IL_05da;
																																		case 29:
																																		case 75:
																																			goto IL_05f3;
																																		case 92:
																																			goto IL_0633;
																																		case 76:
																																			goto IL_0647;
																																		case 0:
																																		case 9:
																																		case 28:
																																		case 31:
																																		case 34:
																																		case 36:
																																		case 40:
																																		case 48:
																																		case 50:
																																		case 58:
																																		case 68:
																																		case 71:
																																		case 78:
																																		case 89:
																																		case 91:
																																		case 93:
																																		case 97:
																																		case 100:
																																		case 105:
																																		case 106:
																																			goto end_IL_0256;
																																		case 8:
																																		case 11:
																																		case 12:
																																		case 16:
																																		case 51:
																																		case 54:
																																		case 57:
																																		case 65:
																																		case 66:
																																		case 79:
																																		case 81:
																																		case 86:
																																		case 101:
																																			goto end_IL_01ef;
																																		case 10:
																																			goto IL_0686;
																																		case 95:
																																			goto end_IL_0673;
																																		case 90:
																																			goto end_IL_0690;
																																		case 32:
																																			goto end_IL_069b;
																																		case 26:
																																		case 85:
																																			goto end_IL_06b0;
																																		case 73:
																																			goto end_IL_06c0;
																																		case 42:
																																		case 84:
																																			goto end_IL_06d0;
																																		case 17:
																																			goto end_IL_06e0;
																																		case 18:
																																			goto end_IL_06f9;
																																		case 62:
																																		case 67:
																																			goto IL_0714;
																																		}
																																		continue;
																																		end_IL_01ef:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_02c0;
																													continue;
																													end_IL_0256:
																													break;
																													IL_0256:;
																												}
																												break;
																											}
																											goto IL_04e5;
																											IL_0538:
																											num5--;
																											goto end_IL_02c0;
																											IL_04e5:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_04f3;
																											IL_04f3:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0501;
																											IL_0501:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_052a;
																											IL_052a:
																											ptr2 += 8;
																											goto IL_0538;
																										}
																										break;
																									}
																									goto IL_02eb;
																									IL_02eb:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02c0;
																								}
																								break;
																							}
																							goto IL_054b;
																							IL_05c7:
																							ptr2 += 8;
																							goto end_IL_02c0;
																							IL_054b:
																							if (4 < b)
																							{
																								goto IL_0559;
																							}
																							goto IL_05da;
																							IL_0559:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0567;
																							IL_0567:
																							if (5 > b)
																							{
																								break;
																							}
																							num = 80;
																							goto IL_057e;
																							IL_05da:
																							if (4 > b)
																							{
																								break;
																							}
																							num = 8;
																							goto end_IL_02c0;
																							IL_057e:
																							array[num5] = 0;
																							goto IL_058c;
																							IL_058c:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05af;
																							IL_05af:
																							array2[num5] = null;
																							goto IL_05b9;
																							IL_05b9:
																							num5++;
																							goto IL_05c7;
																						}
																						break;
																					}
																					goto IL_05f3;
																					IL_0647:
																					num5--;
																					goto end_IL_02c0;
																					IL_05f3:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0633;
																					IL_0633:
																					array[num5 - 2] = 0;
																					goto IL_0647;
																				}
																				break;
																			}
																			goto IL_0303;
																			IL_04d2:
																			ptr2 += 8;
																			goto end_IL_02c0;
																			IL_0303:
																			if (9 < b)
																			{
																				goto IL_030e;
																			}
																			goto IL_033d;
																			IL_030e:
																			if (10 < b)
																			{
																				goto IL_031c;
																			}
																			goto IL_03c0;
																			IL_031c:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_032a;
																			IL_032a:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_03c0:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_03ce;
																			IL_03ce:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02c0;
																			IL_033d:
																			if (9 <= b)
																			{
																				goto IL_034b;
																			}
																			goto IL_03ea;
																			IL_034b:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03ad;
																			IL_03ad:
																			num5 -= 2;
																			goto end_IL_02c0;
																			IL_03ea:
																			if (7 >= b)
																			{
																				goto IL_03f5;
																			}
																			goto IL_0462;
																			IL_03f5:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0403;
																			IL_0403:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0443;
																			IL_0443:
																			array[num5 - 2] = 0;
																			num = 112;
																			goto IL_04a3;
																			IL_04a3:
																			num5--;
																			goto end_IL_02c0;
																			IL_0462:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0470;
																			IL_0470:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_047e;
																			IL_047e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04b6;
																			IL_04b6:
																			array[num5] = 0;
																			goto IL_04c4;
																			IL_04c4:
																			num5++;
																			goto IL_04d2;
																		}
																		break;
																		IL_02b0:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 54;
																break;
																continue;
																end_IL_02c0:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0714;
												IL_0714:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0673:
												break;
											}
											break;
										}
										continue;
										end_IL_0690:
										break;
									}
									continue;
									end_IL_069b:
									break;
								}
								continue;
								end_IL_06b0:
								break;
							}
							continue;
							end_IL_06c0:
							break;
						}
						continue;
						end_IL_06d0:
						break;
					}
					continue;
					end_IL_06e0:
					break;
				}
				continue;
				end_IL_06f9:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_1)
	{
		int num = 34;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 33;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getRestrictedMemberAccessPOLICYCREATEACCOUNT.AuthenticationInstantgetEventHandle);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0279:
														byte b = *ptr2;
														while (true)
														{
															IL_0260:
															ptr2++;
															num = 64;
															while (true)
															{
																IL_0250:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0230:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0220:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_0213:
																							if (10 >= b)
																							{
																								while (10 <= b)
																								{
																									num = 116;
																									while (true)
																									{
																										if (num != 116)
																										{
																											if (num != 1097)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 106:
																												goto IL_0200;
																											case 45:
																											case 54:
																												goto IL_0213;
																											case 13:
																											case 43:
																												goto IL_0220;
																											case 77:
																												goto IL_0230;
																											case 71:
																												goto IL_0240;
																											case 64:
																												goto IL_0250;
																											case 109:
																												goto IL_0260;
																											case 58:
																											case 61:
																												goto IL_0279;
																											case 6:
																											case 56:
																												goto IL_0284;
																											case 37:
																												goto IL_0292;
																											case 27:
																												goto IL_02a5;
																											case 74:
																												goto IL_02c1;
																											case 41:
																												goto IL_02cf;
																											case 51:
																												goto IL_02da;
																											case 22:
																											case 32:
																												goto IL_02e8;
																											case 50:
																												goto IL_0328;
																											case 67:
																												goto IL_033c;
																											case 48:
																												goto IL_034f;
																											case 1:
																												goto IL_035d;
																											case 89:
																											case 108:
																												goto IL_036b;
																											case 100:
																												goto IL_038e;
																											case 59:
																												goto IL_039c;
																											case 24:
																												goto IL_03aa;
																											case 30:
																											case 81:
																												goto IL_03bd;
																											case 21:
																												goto IL_041f;
																											case 39:
																												goto IL_0432;
																											case 83:
																											case 86:
																												goto IL_0440;
																											case 85:
																												goto IL_044e;
																											case 94:
																											case 107:
																												goto IL_045c;
																											case 44:
																												goto IL_0467;
																											case 66:
																											case 93:
																												goto IL_0475;
																											case 23:
																												goto IL_048e;
																											case 57:
																												goto IL_049c;
																											case 101:
																												goto IL_04aa;
																											case 49:
																												goto IL_04bd;
																											case 25:
																												goto IL_04cb;
																											case 65:
																											case 70:
																												goto IL_04d9;
																											case 2:
																												goto IL_0502;
																											case 17:
																												goto IL_0510;
																											case 68:
																											case 91:
																												goto IL_0523;
																											case 103:
																												goto IL_053b;
																											case 53:
																												goto IL_0546;
																											case 102:
																												goto IL_0556;
																											case 19:
																												goto IL_0561;
																											case 29:
																											case 62:
																												goto IL_056c;
																											case 99:
																												goto IL_057a;
																											case 8:
																												goto IL_059d;
																											case 55:
																												goto IL_05a7;
																											case 104:
																												goto IL_05b5;
																											case 4:
																											case 7:
																											case 9:
																											case 14:
																											case 16:
																											case 31:
																											case 36:
																											case 40:
																											case 46:
																											case 69:
																											case 73:
																											case 75:
																											case 79:
																											case 84:
																											case 88:
																											case 97:
																											case 98:
																												goto end_IL_0200;
																											case 63:
																											case 105:
																												goto IL_05da;
																											case 76:
																												goto IL_061a;
																											case 10:
																												goto IL_062e;
																											case 0:
																											case 3:
																											case 5:
																											case 12:
																											case 15:
																											case 26:
																											case 28:
																											case 38:
																											case 42:
																											case 52:
																											case 60:
																											case 72:
																											case 82:
																											case 90:
																												goto end_IL_01ed;
																											case 87:
																												goto end_IL_063c;
																											case 92:
																												goto end_IL_064f;
																											case 35:
																												goto end_IL_0659;
																											case 20:
																												goto end_IL_0664;
																											case 11:
																											case 47:
																												goto end_IL_0679;
																											case 78:
																												goto end_IL_0689;
																											case 80:
																											case 95:
																												goto end_IL_0699;
																											case 33:
																												goto end_IL_06a9;
																											case 34:
																												goto end_IL_06b9;
																											case 18:
																											case 96:
																												goto IL_06dd;
																											}
																											continue;
																										}
																										goto IL_02a5;
																										IL_02a5:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										break;
																										continue;
																										end_IL_01ed:
																										break;
																									}
																									goto end_IL_0250;
																									continue;
																									end_IL_0200:
																									break;
																									IL_0200:;
																								}
																								break;
																							}
																							goto IL_0284;
																							IL_0292:
																							if (11 > b)
																							{
																							}
																							break;
																							IL_0284:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_0292;
																						}
																						break;
																					}
																					goto IL_02c1;
																					IL_041f:
																					num6 -= 2;
																					goto end_IL_0250;
																					IL_02c1:
																					if (9 > b)
																					{
																						goto IL_02cf;
																					}
																					goto IL_03bd;
																					IL_02cf:
																					if (7 >= b)
																					{
																						goto IL_02da;
																					}
																					goto IL_034f;
																					IL_02da:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_02e8;
																					IL_02e8:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0328;
																					IL_0328:
																					array[num6 - 2] = 0;
																					goto IL_033c;
																					IL_033c:
																					num6--;
																					goto end_IL_0250;
																					IL_034f:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_035d;
																					IL_035d:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_036b;
																					IL_036b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_038e;
																					IL_038e:
																					array[num6] = 0;
																					goto IL_039c;
																					IL_039c:
																					num6++;
																					goto IL_03aa;
																					IL_03aa:
																					ptr2 += 8;
																					goto end_IL_0250;
																					IL_03bd:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_041f;
																				}
																				break;
																			}
																			goto IL_0432;
																			IL_062e:
																			num6--;
																			goto end_IL_0250;
																			IL_0432:
																			if (6 > b)
																			{
																				goto IL_0440;
																			}
																			goto IL_05da;
																			IL_0440:
																			if (3 >= b)
																			{
																				goto IL_044e;
																			}
																			goto IL_053b;
																			IL_044e:
																			if (3 > b)
																			{
																				goto IL_045c;
																			}
																			goto IL_0523;
																			IL_045c:
																			if (1 >= b)
																			{
																				goto IL_0467;
																			}
																			goto IL_04bd;
																			IL_0467:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0475;
																			IL_0475:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_048e;
																			IL_048e:
																			array[num6] = 0;
																			goto IL_049c;
																			IL_049c:
																			num6++;
																			goto IL_04aa;
																			IL_04aa:
																			ptr2 += 8;
																			goto end_IL_0250;
																			IL_04bd:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04cb;
																			IL_04cb:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_04d9;
																			IL_04d9:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0502;
																			IL_0502:
																			ptr2 += 8;
																			goto IL_0510;
																			IL_0510:
																			num6--;
																			goto end_IL_0250;
																			IL_0523:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0250;
																			IL_053b:
																			if (4 >= b)
																			{
																				goto IL_0546;
																			}
																			goto IL_0556;
																			IL_0546:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0250;
																			IL_0556:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0561;
																			IL_0561:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_056c;
																			IL_056c:
																			array[num6] = 0;
																			goto IL_057a;
																			IL_057a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_059d;
																			IL_059d:
																			array2[num6] = null;
																			goto IL_05a7;
																			IL_05a7:
																			num6++;
																			goto IL_05b5;
																			IL_05b5:
																			ptr2 += 8;
																			goto end_IL_0250;
																			IL_05da:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_061a;
																			IL_061a:
																			array[num6 - 2] = 0;
																			goto IL_062e;
																		}
																		break;
																		IL_0240:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0250:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06dd;
												IL_06dd:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_063c:
												break;
											}
											continue;
											end_IL_064f:
											break;
										}
										continue;
										end_IL_0659:
										break;
									}
									continue;
									end_IL_0664:
									break;
								}
								continue;
								end_IL_0679:
								break;
							}
							continue;
							end_IL_0689:
							break;
						}
						continue;
						end_IL_0699:
						break;
					}
					continue;
					end_IL_06a9:
					break;
				}
				continue;
				end_IL_06b9:
				break;
			}
		}
	}

	unsafe static Class123()
	{
		//The blocks IL_000e, IL_001e, IL_0677, IL_068a, IL_06a3, IL_06b8, IL_06c8, IL_06d8, IL_06e5, IL_06f5, IL_0705, IL_0715, IL_0725, IL_0735, IL_0749, IL_0754, IL_0767, IL_0775, IL_0788, IL_0793, IL_07a1, IL_07af, IL_07da, IL_07e3, IL_07ee, IL_0801, IL_080f, IL_0827, IL_0835, IL_0848, IL_0861, IL_086f, IL_087d, IL_088b, IL_0899, IL_08f3, IL_0901, IL_0914, IL_0922, IL_0935, IL_0943, IL_0956, IL_0961, IL_09a0, IL_09b3, IL_09be, IL_09cc, IL_0a12, IL_0a20, IL_0a33, IL_0a3c, IL_0a4a, IL_0a58, IL_0a96, IL_0aa9, IL_0ab7, IL_0ac5, IL_0aee, IL_0b07, IL_0b12, IL_0b30, IL_0b3e, IL_0b51, IL_0b5f, IL_0b72, IL_0b80, IL_0b8e, IL_0b99, IL_0bac, IL_0bba, IL_0bcd, IL_0bd8, IL_0be6, IL_0bf9, IL_0c07, IL_0c1a, IL_0c28, IL_0c31, IL_0c3f, IL_0c52, IL_0c60, IL_0c73, IL_0c7e, IL_0c8c, IL_0c97, IL_0ca5, IL_0cc1, IL_0ccf, IL_0ce8, IL_0cfb, IL_0d09, IL_0d17, IL_0d22, IL_0d35, IL_0d43, IL_0d56, IL_0d64, IL_0d72, IL_0d85, IL_0d93, IL_0da6, IL_0db1, IL_0dbf, IL_0dd2, IL_0de0, IL_0df3, IL_0e01, IL_0e0f, IL_0e22, IL_0e30, IL_0e43, IL_0e56, IL_0e64, IL_0e80, IL_0e8e, IL_0e9c, IL_0eaa, IL_0eb8, IL_0ec6, IL_0ed4, IL_0ee2, IL_0ef0, IL_0f30, IL_0f44, IL_0f57, IL_0f65, IL_0f73, IL_0f94, IL_0fa2, IL_0fb5, IL_0fc3, IL_0fd1, IL_0fdf, IL_0fed, IL_1005, IL_1023, IL_1047, IL_105f, IL_1072, IL_1080, IL_10a9, IL_10c2, IL_10e0, IL_10ee, IL_1101, IL_110f, IL_111d, IL_1128, IL_1136, IL_1144, IL_1152, IL_1165, IL_117c, IL_118f, IL_1198, IL_11a6, IL_11bb, IL_11ce, IL_11d9, IL_11e7, IL_11fa, IL_120f, IL_1222, IL_123b, IL_1249, IL_1257, IL_1273, IL_12ad, IL_12c0, IL_12ce, IL_12dc, IL_12e7, IL_12f5, IL_1303, IL_130c, IL_132e, IL_1341, IL_134a, IL_1358, IL_136c, IL_13a4, IL_13b7, IL_13c5, IL_13d0, IL_13de, IL_13ec, IL_13fa, IL_1412, IL_1420, IL_1433, IL_1441, IL_146a, IL_1483, IL_14c1, IL_14dd, IL_14eb, IL_14f9, IL_1504, IL_1512, IL_1520, IL_153e, IL_154c, IL_155f, IL_156d, IL_158a, IL_15d9, IL_15e3, IL_1610, IL_1624, IL_1632, IL_1645, IL_1650, IL_16ab, IL_16be, IL_16c7, IL_16d5, IL_16e3, IL_16f7, IL_1738, IL_174b, IL_178b, IL_179f, IL_17b8, IL_17c6, IL_17e4, IL_17f2, IL_1802, IL_1817, IL_1825, IL_1838, IL_1843, IL_184d, IL_1858, IL_1868, IL_1878, IL_1888, IL_18a1, IL_18ba, IL_18ca, IL_18eb, IL_18f2 are reachable both inside and outside the pinned region starting at IL_18df. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 275;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2;
					int num3;
					byte[] array2;
					object[] array3;
					int[] array4;
					long[] array5;
					object[] array6;
					byte* ptr;
					byte* num6;
					int num7;
					object[] array7;
					int num8;
					byte* num9;
					byte* ptr2;
					byte[] array = new byte[4];
					if (true)
					{
						while (true)
						{
							IL_18ca:
							num2 = 1;
							while (true)
							{
								IL_18ba:
								num3 = num2 * 4;
								while (true)
								{
									IL_18a1:
									array2 = new byte[9];
									num = 301;
									while (true)
									{
										IL_1888:
										array3 = new object[9];
										num = 223;
										while (true)
										{
											IL_1878:
											array4 = new int[9];
											while (true)
											{
												IL_1868:
												array5 = new long[9];
												while (true)
												{
													IL_1858:
													array6 = new object[32];
													while (true)
													{
														IL_184d:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OptionalParamBindingConstructorCallMessage.SecurityContextFrameShadowCopyFiles);
														while (true)
														{
															IL_1843:
															ptr2 = ptr;
															while (true)
															{
																IL_1838:
																num = 147;
																while (true)
																{
																	IL_1825:
																	if (num4 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0749:
																		num = 298;
																		while (true)
																		{
																			IL_0735:
																			byte b = *ptr2;
																			num = 96;
																			while (true)
																			{
																				IL_0725:
																				ptr2++;
																				while (true)
																				{
																					IL_0715:
																					if (b >= 1)
																					{
																						while (b <= 43)
																						{
																							while (true)
																							{
																								IL_06f5:
																								if (22 < b)
																								{
																									while (true)
																									{
																										IL_06e5:
																										if (33 >= b)
																										{
																											while (true)
																											{
																												IL_06d8:
																												if (33 > b)
																												{
																													while (true)
																													{
																														IL_06c8:
																														if (27 >= b)
																														{
																															while (true)
																															{
																																IL_06b8:
																																if (27 <= b)
																																{
																																	while (true)
																																	{
																																		IL_06a3:
																																		array3[num5] = default(RuntimeFieldHandle);
																																		while (true)
																																		{
																																			IL_068a:
																																			array2[num5] = 4;
																																			num = 410;
																																			while (true)
																																			{
																																				if (num != 410)
																																				{
																																					if (num != 1391)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 356:
																																						break;
																																					default:
																																						continue;
																																					case 32:
																																						goto IL_068a;
																																					case 58:
																																					case 204:
																																						goto IL_06a3;
																																					case 140:
																																						goto IL_06b8;
																																					case 113:
																																						goto IL_06c8;
																																					case 67:
																																						goto IL_06d8;
																																					case 41:
																																					case 175:
																																						goto IL_06e5;
																																					case 107:
																																						goto IL_06f5;
																																					case 176:
																																						goto IL_0705;
																																					case 68:
																																						goto IL_0715;
																																					case 96:
																																						goto IL_0725;
																																					case 298:
																																						goto IL_0735;
																																					case 70:
																																						goto IL_0749;
																																					case 153:
																																					case 353:
																																						goto IL_0754;
																																					case 179:
																																						goto IL_0767;
																																					case 245:
																																						goto IL_0775;
																																					case 358:
																																					case 362:
																																						goto IL_0788;
																																					case 247:
																																						goto IL_0793;
																																					case 287:
																																						goto IL_07a1;
																																					case 33:
																																					case 302:
																																						goto IL_07af;
																																					case 228:
																																						goto IL_07e3;
																																					case 53:
																																						goto IL_07ee;
																																					case 164:
																																					case 258:
																																						goto IL_0801;
																																					case 216:
																																						goto IL_080f;
																																					case 105:
																																						goto IL_0827;
																																					case 253:
																																						goto IL_0835;
																																					case 380:
																																						goto IL_0848;
																																					case 143:
																																					case 384:
																																						goto IL_0861;
																																					case 36:
																																					case 101:
																																						goto IL_086f;
																																					case 177:
																																					case 343:
																																						goto IL_087d;
																																					case 130:
																																						goto IL_088b;
																																					case 232:
																																					case 269:
																																						goto IL_0899;
																																					case 37:
																																						goto IL_08f3;
																																					case 112:
																																						goto IL_0901;
																																					case 261:
																																						goto IL_0914;
																																					case 124:
																																					case 374:
																																						goto IL_0922;
																																					case 270:
																																						goto IL_0935;
																																					case 359:
																																						goto IL_0943;
																																					case 320:
																																						goto IL_0956;
																																					case 104:
																																					case 151:
																																						goto IL_0961;
																																					case 197:
																																						goto IL_09a0;
																																					case 310:
																																						goto IL_09b3;
																																					case 281:
																																						goto IL_09be;
																																					case 167:
																																					case 379:
																																						goto IL_09cc;
																																					case 87:
																																						goto IL_0a12;
																																					case 333:
																																						goto IL_0a20;
																																					case 77:
																																					case 357:
																																						goto IL_0a3c;
																																					case 142:
																																						goto IL_0a4a;
																																					case 71:
																																					case 73:
																																						goto IL_0a58;
																																					case 309:
																																						goto IL_0a96;
																																					case 388:
																																						goto IL_0aa9;
																																					case 134:
																																						goto IL_0ab7;
																																					case 18:
																																					case 59:
																																						goto IL_0ac5;
																																					case 214:
																																						goto IL_0aee;
																																					case 399:
																																						goto IL_0b07;
																																					case 186:
																																					case 189:
																																						goto IL_0b12;
																																					case 307:
																																						goto IL_0b30;
																																					case 203:
																																						goto IL_0b3e;
																																					case 366:
																																						goto IL_0b72;
																																					case 108:
																																					case 342:
																																						goto IL_0b80;
																																					case 225:
																																						goto IL_0b8e;
																																					case 85:
																																					case 401:
																																						goto IL_0b99;
																																					case 125:
																																						goto IL_0bac;
																																					case 340:
																																						goto IL_0bba;
																																					case 400:
																																						goto IL_0bcd;
																																					case 132:
																																						goto IL_0bd8;
																																					case 25:
																																					case 323:
																																						goto IL_0be6;
																																					case 100:
																																						goto IL_0bf9;
																																					case 93:
																																						goto IL_0c07;
																																					case 26:
																																						goto IL_0c1a;
																																					case 255:
																																						goto IL_0c31;
																																					case 61:
																																					case 91:
																																						goto IL_0c3f;
																																					case 83:
																																						goto IL_0c52;
																																					case 57:
																																						goto IL_0c60;
																																					case 272:
																																						goto IL_0c73;
																																					case 40:
																																					case 103:
																																						goto IL_0c7e;
																																					case 137:
																																						goto IL_0c8c;
																																					case 72:
																																					case 397:
																																						goto IL_0ca5;
																																					case 82:
																																						goto IL_0cc1;
																																					case 202:
																																					case 215:
																																						goto IL_0ccf;
																																					case 98:
																																						goto IL_0ce8;
																																					case 174:
																																						goto IL_0cfb;
																																					case 191:
																																					case 381:
																																						goto IL_0d09;
																																					case 23:
																																						goto IL_0d17;
																																					case 201:
																																					case 251:
																																						goto IL_0d22;
																																					case 138:
																																						goto IL_0d35;
																																					case 64:
																																						goto IL_0d43;
																																					case 348:
																																						goto IL_0d56;
																																					case 390:
																																						goto IL_0d64;
																																					case 182:
																																					case 315:
																																						goto IL_0d72;
																																					case 52:
																																						goto IL_0d85;
																																					case 55:
																																						goto IL_0d93;
																																					case 171:
																																						goto IL_0da6;
																																					case 297:
																																						goto IL_0db1;
																																					case 121:
																																					case 291:
																																						goto IL_0dbf;
																																					case 319:
																																						goto IL_0dd2;
																																					case 265:
																																						goto IL_0de0;
																																					case 304:
																																						goto IL_0df3;
																																					case 243:
																																						goto IL_0e01;
																																					case 1:
																																					case 227:
																																						goto IL_0e0f;
																																					case 219:
																																						goto IL_0e22;
																																					case 88:
																																						goto IL_0e30;
																																					case 46:
																																					case 279:
																																						goto IL_0e43;
																																					case 361:
																																						goto IL_0e56;
																																					case 349:
																																						goto IL_0e64;
																																					case 231:
																																						goto IL_0e80;
																																					case 190:
																																					case 391:
																																						goto IL_0e8e;
																																					case 0:
																																						goto IL_0e9c;
																																					case 47:
																																					case 238:
																																						goto IL_0eaa;
																																					case 122:
																																					case 271:
																																						goto IL_0eb8;
																																					case 39:
																																					case 180:
																																						goto IL_0ec6;
																																					case 66:
																																					case 246:
																																						goto IL_0ed4;
																																					case 392:
																																						goto IL_0ee2;
																																					case 249:
																																					case 282:
																																						goto IL_0ef0;
																																					case 268:
																																						goto IL_0f30;
																																					case 6:
																																						goto IL_0f44;
																																					case 341:
																																						goto IL_0f57;
																																					case 38:
																																					case 54:
																																						goto IL_0f65;
																																					case 239:
																																						goto IL_0f73;
																																					case 169:
																																						goto IL_0f94;
																																					case 119:
																																						goto IL_0fa2;
																																					case 195:
																																						goto IL_0fb5;
																																					case 218:
																																					case 329:
																																						goto IL_0fc3;
																																					case 50:
																																					case 117:
																																						goto IL_0fd1;
																																					case 241:
																																						goto IL_0fdf;
																																					case 34:
																																					case 248:
																																						goto IL_0fed;
																																					case 224:
																																						goto IL_1005;
																																					case 133:
																																						goto IL_1023;
																																					case 19:
																																						goto IL_1047;
																																					case 127:
																																						goto IL_105f;
																																					case 260:
																																						goto IL_1072;
																																					case 148:
																																					case 230:
																																						goto IL_1080;
																																					case 393:
																																						goto IL_10a9;
																																					case 276:
																																					case 305:
																																						goto IL_10c2;
																																					case 313:
																																						goto IL_10e0;
																																					case 326:
																																						goto IL_10ee;
																																					case 352:
																																						goto IL_1101;
																																					case 3:
																																						goto IL_110f;
																																					case 237:
																																					case 321:
																																						goto IL_111d;
																																					case 149:
																																						goto IL_1128;
																																					case 330:
																																						goto IL_1136;
																																					case 76:
																																					case 240:
																																						goto IL_1144;
																																					case 339:
																																						goto IL_1152;
																																					case 335:
																																						goto IL_1165;
																																					case 28:
																																						goto IL_117c;
																																					case 29:
																																						goto IL_1198;
																																					case 97:
																																					case 347:
																																						goto IL_11a6;
																																					case 17:
																																						goto IL_11bb;
																																					case 48:
																																						goto IL_11ce;
																																					case 118:
																																					case 383:
																																						goto IL_11d9;
																																					case 106:
																																						goto IL_11e7;
																																					case 183:
																																					case 257:
																																						goto IL_11fa;
																																					case 16:
																																						goto IL_120f;
																																					case 65:
																																					case 250:
																																						goto IL_1222;
																																					case 209:
																																						goto IL_123b;
																																					case 168:
																																						goto IL_1249;
																																					case 99:
																																						goto IL_1257;
																																					case 262:
																																					case 290:
																																						goto IL_1273;
																																					case 198:
																																						goto IL_12ad;
																																					case 135:
																																						goto IL_12c0;
																																					case 286:
																																					case 394:
																																						goto IL_12ce;
																																					case 79:
																																					case 213:
																																						goto IL_12dc;
																																					case 30:
																																						goto IL_12e7;
																																					case 123:
																																						goto IL_12f5;
																																					case 120:
																																					case 221:
																																						goto IL_130c;
																																					case 181:
																																						goto IL_132e;
																																					case 280:
																																						goto IL_134a;
																																					case 13:
																																					case 256:
																																						goto IL_1358;
																																					case 234:
																																						goto IL_136c;
																																					case 210:
																																						goto IL_13a4;
																																					case 284:
																																						goto IL_13b7;
																																					case 81:
																																					case 299:
																																						goto IL_13c5;
																																					case 116:
																																					case 371:
																																						goto IL_13d0;
																																					case 378:
																																						goto IL_13de;
																																					case 4:
																																					case 263:
																																						goto IL_13ec;
																																					case 78:
																																						goto IL_13fa;
																																					case 312:
																																						goto IL_1412;
																																					case 322:
																																						goto IL_1420;
																																					case 373:
																																						goto IL_1433;
																																					case 51:
																																					case 402:
																																						goto IL_1441;
																																					case 267:
																																						goto IL_146a;
																																					case 145:
																																					case 159:
																																						goto IL_1483;
																																					case 75:
																																						goto IL_14c1;
																																					case 172:
																																						goto IL_14dd;
																																					case 80:
																																					case 212:
																																						goto IL_14eb;
																																					case 126:
																																					case 129:
																																						goto IL_14f9;
																																					case 345:
																																					case 395:
																																						goto IL_1504;
																																					case 161:
																																						goto IL_1512;
																																					case 15:
																																					case 60:
																																						goto IL_1520;
																																					case 44:
																																						goto IL_153e;
																																					case 208:
																																						goto IL_154c;
																																					case 12:
																																						goto IL_155f;
																																					case 294:
																																					case 314:
																																						goto IL_156d;
																																					case 344:
																																						goto IL_1624;
																																					case 355:
																																						goto IL_1632;
																																					case 295:
																																						goto IL_1645;
																																					case 114:
																																					case 382:
																																						goto IL_1650;
																																					case 338:
																																						goto IL_16ab;
																																					case 365:
																																					case 375:
																																						goto IL_16c7;
																																					case 331:
																																						goto IL_16d5;
																																					case 10:
																																					case 141:
																																						goto IL_16e3;
																																					case 200:
																																						goto IL_16f7;
																																					case 21:
																																						goto IL_1738;
																																					case 211:
																																					case 370:
																																						goto IL_174b;
																																					case 242:
																																						goto IL_178b;
																																					case 184:
																																						goto IL_179f;
																																					case 31:
																																					case 35:
																																						goto IL_17b8;
																																					case 199:
																																						goto IL_17c6;
																																					case 367:
																																						goto IL_17e4;
																																					case 157:
																																						goto IL_17f2;
																																					case 2:
																																					case 7:
																																					case 9:
																																					case 14:
																																					case 20:
																																					case 22:
																																					case 24:
																																					case 42:
																																					case 43:
																																					case 45:
																																					case 62:
																																					case 69:
																																					case 90:
																																					case 92:
																																					case 94:
																																					case 95:
																																					case 102:
																																					case 111:
																																					case 128:
																																					case 131:
																																					case 139:
																																					case 152:
																																					case 156:
																																					case 158:
																																					case 160:
																																					case 162:
																																					case 165:
																																					case 166:
																																					case 170:
																																					case 173:
																																					case 178:
																																					case 185:
																																					case 187:
																																					case 188:
																																					case 194:
																																					case 196:
																																					case 222:
																																					case 229:
																																					case 233:
																																					case 236:
																																					case 244:
																																					case 259:
																																					case 266:
																																					case 278:
																																					case 283:
																																					case 285:
																																					case 293:
																																					case 303:
																																					case 308:
																																					case 316:
																																					case 324:
																																					case 325:
																																					case 327:
																																					case 332:
																																					case 334:
																																					case 346:
																																					case 351:
																																					case 354:
																																					case 369:
																																					case 372:
																																					case 385:
																																					case 386:
																																					case 396:
																																					case 398:
																																						goto end_IL_0677;
																																					case 273:
																																						goto IL_1817;
																																					case 8:
																																					case 11:
																																					case 27:
																																					case 49:
																																					case 63:
																																					case 74:
																																					case 84:
																																					case 86:
																																					case 89:
																																					case 109:
																																					case 144:
																																					case 146:
																																					case 147:
																																					case 150:
																																					case 154:
																																					case 155:
																																					case 163:
																																					case 192:
																																					case 193:
																																					case 205:
																																					case 207:
																																					case 217:
																																					case 220:
																																					case 226:
																																					case 235:
																																					case 252:
																																					case 254:
																																					case 264:
																																					case 277:
																																					case 288:
																																					case 292:
																																					case 296:
																																					case 300:
																																					case 306:
																																					case 318:
																																					case 336:
																																					case 337:
																																					case 360:
																																					case 363:
																																					case 364:
																																					case 376:
																																					case 377:
																																					case 389:
																																					case 403:
																																						goto IL_1825;
																																					case 368:
																																						goto IL_1838;
																																					case 206:
																																						goto IL_1843;
																																					case 317:
																																						goto IL_184d;
																																					case 5:
																																						goto IL_1858;
																																					case 115:
																																						goto IL_1868;
																																					case 223:
																																						goto IL_1878;
																																					case 301:
																																						goto IL_1888;
																																					case 136:
																																					case 311:
																																						goto IL_18a1;
																																					case 289:
																																						goto IL_18ba;
																																					case 56:
																																						goto IL_18ca;
																																					case 110:
																																						break;
																																					case 387:
																																						break;
																																					case 274:
																																						Class300.smethod_0();
																																						break;
																																					case 275:
																																						Class296.Aw4EYyy3h();
																																						goto case 274;
																																					case 328:
																																					case 350:
																																						return;
																																					}
																																					goto end_IL_0715;
																																				}
																																				num5++;
																																				goto IL_1825;
																																				continue;
																																				end_IL_0677:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0788;
																																IL_080f:
																																array3[num5] = array6[*(int*)(ptr2 + num3)];
																																goto IL_0827;
																																IL_0788:
																																if (24 < b)
																																{
																																	goto IL_0793;
																																}
																																num = 228;
																																goto IL_07e3;
																																IL_0793:
																																if (25 >= b)
																																{
																																	goto IL_07a1;
																																}
																																goto IL_0aa9;
																																IL_07a1:
																																if (25 > b)
																																{
																																	break;
																																}
																																goto IL_07af;
																																IL_07af:
																																array3[num5 - 1] = new bool[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])][];
																																goto IL_0848;
																																IL_0848:
																																array2[num5 - 1] = 5;
																																goto IL_1825;
																																IL_0aa9:
																																if (26 < b)
																																{
																																	break;
																																}
																																goto IL_0ab7;
																																IL_0ab7:
																																if (26 > b)
																																{
																																	break;
																																}
																																goto IL_0ac5;
																																IL_0ac5:
																																array3[num5 - 1] = new bool[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																																goto IL_0aee;
																																IL_0aee:
																																array2[num5 - 1] = 5;
																																goto IL_1825;
																																IL_0827:
																																num5++;
																																goto IL_0835;
																																IL_07e3:
																																if (24 > b)
																																{
																																	goto IL_07ee;
																																}
																																goto IL_0801;
																																IL_07ee:
																																if (23 < b)
																																{
																																	break;
																																}
																																goto IL_0b07;
																																IL_0b07:
																																if (23 > b)
																																{
																																	num = 20;
																																	break;
																																}
																																goto IL_0b12;
																																IL_0b12:
																																array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																																goto IL_0b30;
																																IL_0b30:
																																ptr2 += 8;
																																goto IL_0b3e;
																																IL_0b3e:
																																num5--;
																																goto IL_1825;
																																IL_0835:
																																ptr2 += 8;
																																goto IL_1825;
																																IL_0801:
																																array2[num5] = 5;
																																goto IL_080f;
																															}
																															break;
																														}
																														goto IL_0861;
																														IL_0a58:
																														((bool[][])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (bool[])array3[num5 - 1];
																														goto IL_0a96;
																														IL_0861:
																														if (30 < b)
																														{
																															goto IL_086f;
																														}
																														goto IL_0956;
																														IL_086f:
																														if (31 < b)
																														{
																															goto IL_087d;
																														}
																														goto IL_0914;
																														IL_087d:
																														if (32 < b)
																														{
																															break;
																														}
																														goto IL_088b;
																														IL_088b:
																														if (32 > b)
																														{
																															break;
																														}
																														goto IL_0899;
																														IL_0899:
																														((delegate*<Dictionary<string, bool[][]>, string, bool[][], void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((Dictionary<string, bool[][]>)array3[num5 - 3], (string)array3[num5 - 2], (bool[][])array3[num5 - 1]);
																														num = 37;
																														goto IL_08f3;
																														IL_08f3:
																														num5 -= 3;
																														goto IL_0901;
																														IL_0901:
																														ptr2 += 8;
																														goto IL_1825;
																														IL_0914:
																														if (31 > b)
																														{
																															break;
																														}
																														goto IL_0922;
																														IL_0922:
																														array3[num5] = default(RuntimeFieldHandle);
																														goto IL_0935;
																														IL_0935:
																														array2[num5] = 4;
																														goto IL_0943;
																														IL_0943:
																														num5++;
																														goto IL_1825;
																														IL_0956:
																														if (30 <= b)
																														{
																															goto IL_0961;
																														}
																														goto IL_09b3;
																														IL_0961:
																														((bool[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0;
																														goto IL_09a0;
																														IL_09a0:
																														num5 -= 3;
																														goto IL_1825;
																														IL_09b3:
																														if (28 >= b)
																														{
																															goto IL_09be;
																														}
																														num = 77;
																														goto IL_0a3c;
																														IL_09be:
																														if (28 > b)
																														{
																															break;
																														}
																														goto IL_09cc;
																														IL_09cc:
																														((delegate*<Array, RuntimeFieldHandle, void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((bool[])array3[num5 - 2], (RuntimeFieldHandle)array3[num5 - 1]);
																														num = 87;
																														goto IL_0a12;
																														IL_0a12:
																														num5 -= 2;
																														goto IL_0a20;
																														IL_0a20:
																														ptr2 += 8;
																														goto IL_1825;
																														IL_0a96:
																														num5 -= 3;
																														goto IL_1825;
																														IL_0a3c:
																														if (29 < b)
																														{
																															break;
																														}
																														goto IL_0a4a;
																														IL_0a4a:
																														if (29 > b)
																														{
																															break;
																														}
																														goto IL_0a58;
																													}
																													break;
																												}
																												goto IL_0754;
																												IL_0775:
																												num5++;
																												goto IL_1825;
																												IL_0754:
																												array3[num5] = default(RuntimeFieldHandle);
																												goto IL_0767;
																												IL_0767:
																												array2[num5] = 4;
																												goto IL_0775;
																											}
																											break;
																										}
																										goto IL_0b72;
																										IL_0e43:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0e56;
																										IL_0b72:
																										if (38 < b)
																										{
																											goto IL_0b80;
																										}
																										goto IL_0cfb;
																										IL_0b80:
																										if (41 >= b)
																										{
																											goto IL_0b8e;
																										}
																										goto IL_0c73;
																										IL_0b8e:
																										if (41 <= b)
																										{
																											goto IL_0b99;
																										}
																										goto IL_0bcd;
																										IL_0b99:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0bac;
																										IL_0bac:
																										array2[num5] = 4;
																										goto IL_0bba;
																										IL_0bba:
																										num5++;
																										goto IL_1825;
																										IL_0bcd:
																										if (39 >= b)
																										{
																											goto IL_0bd8;
																										}
																										goto IL_0c1a;
																										IL_0bd8:
																										if (39 > b)
																										{
																											break;
																										}
																										goto IL_0be6;
																										IL_0be6:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0bf9;
																										IL_0bf9:
																										array2[num5] = 4;
																										goto IL_0c07;
																										IL_0c07:
																										num5++;
																										goto IL_1825;
																										IL_0c1a:
																										if (40 < b)
																										{
																											break;
																										}
																										num = 255;
																										goto IL_0c31;
																										IL_0e56:
																										array2[num5] = 4;
																										goto IL_0e64;
																										IL_0c31:
																										if (40 > b)
																										{
																											break;
																										}
																										goto IL_0c3f;
																										IL_0c3f:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0c52;
																										IL_0c52:
																										array2[num5] = 4;
																										goto IL_0c60;
																										IL_0c60:
																										num5++;
																										goto IL_1825;
																										IL_0c73:
																										if (42 < b)
																										{
																											goto IL_0c7e;
																										}
																										goto IL_0cc1;
																										IL_0c7e:
																										if (43 < b)
																										{
																											break;
																										}
																										goto IL_0c8c;
																										IL_0c8c:
																										if (43 > b)
																										{
																											num = 139;
																											break;
																										}
																										goto IL_0ca5;
																										IL_0e64:
																										num5++;
																										num = 109;
																										goto IL_1825;
																										IL_0ca5:
																										num6 = ptr2;
																										num7 = -200;
																										num4 = 1;
																										ptr2 = num6 + num7;
																										goto IL_1825;
																										IL_0cc1:
																										if (42 > b)
																										{
																											break;
																										}
																										goto IL_0ccf;
																										IL_0ccf:
																										dictionary_0 = (Dictionary<string, bool[][]>)array3[num5 - 1];
																										goto IL_0ce8;
																										IL_0ce8:
																										num5--;
																										goto IL_1825;
																										IL_0cfb:
																										if (38 > b)
																										{
																											goto IL_0d09;
																										}
																										goto IL_0e43;
																										IL_0d09:
																										if (35 >= b)
																										{
																											goto IL_0d17;
																										}
																										goto IL_0da6;
																										IL_0d17:
																										if (35 <= b)
																										{
																											goto IL_0d22;
																										}
																										goto IL_0d56;
																										IL_0d22:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0d35;
																										IL_0d35:
																										array2[num5] = 4;
																										goto IL_0d43;
																										IL_0d43:
																										num5++;
																										goto IL_1825;
																										IL_0d56:
																										if (34 < b)
																										{
																											break;
																										}
																										goto IL_0d64;
																										IL_0d64:
																										if (34 > b)
																										{
																											break;
																										}
																										goto IL_0d72;
																										IL_0d72:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0d85;
																										IL_0d85:
																										array2[num5] = 4;
																										goto IL_0d93;
																										IL_0d93:
																										num5++;
																										goto IL_1825;
																										IL_0da6:
																										if (36 >= b)
																										{
																											goto IL_0db1;
																										}
																										goto IL_0df3;
																										IL_0db1:
																										if (36 > b)
																										{
																											break;
																										}
																										goto IL_0dbf;
																										IL_0dbf:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0dd2;
																										IL_0dd2:
																										array2[num5] = 4;
																										goto IL_0de0;
																										IL_0de0:
																										num5++;
																										goto IL_1825;
																										IL_0df3:
																										if (37 < b)
																										{
																											break;
																										}
																										goto IL_0e01;
																										IL_0e01:
																										if (37 > b)
																										{
																											break;
																										}
																										goto IL_0e0f;
																										IL_0e0f:
																										array3[num5] = default(RuntimeFieldHandle);
																										goto IL_0e22;
																										IL_0e22:
																										array2[num5] = 4;
																										goto IL_0e30;
																										IL_0e30:
																										num5++;
																										goto IL_1825;
																									}
																									break;
																								}
																								goto IL_0e80;
																								IL_1738:
																								ptr2 += 8;
																								goto IL_1825;
																								IL_0e80:
																								if (22 > b)
																								{
																									goto IL_0e8e;
																								}
																								goto IL_17b8;
																								IL_0e8e:
																								if (11 >= b)
																								{
																									goto IL_0e9c;
																								}
																								goto IL_12c0;
																								IL_0e9c:
																								if (11 > b)
																								{
																									goto IL_0eaa;
																								}
																								goto IL_1273;
																								IL_0eaa:
																								if (5 < b)
																								{
																									goto IL_0eb8;
																								}
																								goto IL_1101;
																								IL_0eb8:
																								if (8 < b)
																								{
																									goto IL_0ec6;
																								}
																								goto IL_0fb5;
																								IL_0ec6:
																								if (9 < b)
																								{
																									goto IL_0ed4;
																								}
																								goto IL_0f57;
																								IL_0ed4:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_0ee2;
																								IL_0ee2:
																								if (10 > b)
																								{
																									break;
																								}
																								goto IL_0ef0;
																								IL_0ef0:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_0f30;
																								IL_0f30:
																								array2[num5 - 2] = 0;
																								goto IL_0f44;
																								IL_0f44:
																								num5--;
																								goto IL_1825;
																								IL_0f57:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0f65;
																								IL_0f65:
																								array2[num5] = 5;
																								goto IL_0f73;
																								IL_0f73:
																								array3[num5] = array6[*(int*)(ptr2 + num3)];
																								num = 169;
																								goto IL_0f94;
																								IL_0f94:
																								num5++;
																								goto IL_0fa2;
																								IL_0fa2:
																								ptr2 += 8;
																								goto IL_1825;
																								IL_0fb5:
																								if (8 > b)
																								{
																									goto IL_0fc3;
																								}
																								goto IL_10c2;
																								IL_0fc3:
																								if (6 < b)
																								{
																									goto IL_0fd1;
																								}
																								goto IL_1072;
																								IL_0fd1:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_0fdf;
																								IL_0fdf:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0fed;
																								IL_0fed:
																								array2[num5] = array2[num5 - 1];
																								goto IL_1005;
																								IL_1005:
																								array4[num5 - 0] = array4[num5 - 1];
																								goto IL_1023;
																								IL_1023:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_1047;
																								IL_1047:
																								array3[num5] = array3[num5 - 1];
																								goto IL_105f;
																								IL_105f:
																								num5++;
																								goto IL_1825;
																								IL_1072:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_1080;
																								IL_1080:
																								array3[num5 - 1] = new char[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																								goto IL_10a9;
																								IL_10a9:
																								array2[num5 - 1] = 5;
																								goto IL_1825;
																								IL_10c2:
																								array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																								goto IL_10e0;
																								IL_10e0:
																								ptr2 += 8;
																								goto IL_10ee;
																								IL_10ee:
																								num5--;
																								goto IL_1825;
																								IL_1101:
																								if (5 > b)
																								{
																									goto IL_110f;
																								}
																								goto IL_1222;
																								IL_110f:
																								if (2 < b)
																								{
																									goto IL_111d;
																								}
																								goto IL_11ce;
																								IL_111d:
																								if (3 < b)
																								{
																									goto IL_1128;
																								}
																								num = 29;
																								goto IL_1198;
																								IL_1128:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_1136;
																								IL_1136:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_1144;
																								IL_1144:
																								array2[num5] = 15;
																								goto IL_1152;
																								IL_1152:
																								array4[num5] = *(int*)(ptr2 + num3);
																								goto IL_1165;
																								IL_1165:
																								ptr2 += 8;
																								num = 28;
																								goto IL_117c;
																								IL_117c:
																								num5++;
																								goto IL_1825;
																								IL_174b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																								goto IL_178b;
																								IL_1198:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_11a6;
																								IL_11a6:
																								((delegate*<void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
																								goto IL_11bb;
																								IL_11bb:
																								ptr2 += 8;
																								goto IL_1825;
																								IL_11ce:
																								if (2 > b)
																								{
																									goto IL_11d9;
																								}
																								goto IL_11fa;
																								IL_11d9:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_11e7;
																								IL_11e7:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_11fa:
																								((delegate*<void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
																								goto IL_120f;
																								IL_120f:
																								ptr2 += 8;
																								goto IL_1825;
																								IL_1222:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																								goto IL_123b;
																								IL_123b:
																								array2[num5] = 0;
																								goto IL_1249;
																								IL_1249:
																								num5++;
																								goto IL_1257;
																								IL_1257:
																								ptr2 += 8;
																								num = 63;
																								goto IL_1825;
																								IL_1273:
																								((short[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (short)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																								goto IL_12ad;
																								IL_12ad:
																								num5 -= 3;
																								goto IL_1825;
																								IL_12c0:
																								if (16 < b)
																								{
																									goto IL_12ce;
																								}
																								goto IL_14dd;
																								IL_12ce:
																								if (19 < b)
																								{
																									goto IL_12dc;
																								}
																								goto IL_13b7;
																								IL_12dc:
																								if (20 < b)
																								{
																									goto IL_12e7;
																								}
																								num = 280;
																								goto IL_134a;
																								IL_12e7:
																								if (21 < b)
																								{
																									break;
																								}
																								goto IL_12f5;
																								IL_12f5:
																								if (21 > b)
																								{
																									break;
																								}
																								num = 120;
																								goto IL_130c;
																								IL_179f:
																								num5--;
																								num = 277;
																								goto IL_1825;
																								IL_130c:
																								string_1 = (string[])array3[num5 - 1];
																								num = 181;
																								goto IL_132e;
																								IL_132e:
																								num5--;
																								goto IL_1825;
																								IL_178b:
																								array2[num5 - 2] = 0;
																								goto IL_179f;
																								IL_134a:
																								if (20 > b)
																								{
																									break;
																								}
																								goto IL_1358;
																								IL_1358:
																								array2[num5 - 1] = 5;
																								goto IL_136c;
																								IL_136c:
																								array3[num5 - 1] = ((delegate*<string[], string>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																								goto IL_13a4;
																								IL_13a4:
																								ptr2 += 8;
																								goto IL_1825;
																								IL_13b7:
																								if (19 > b)
																								{
																									goto IL_13c5;
																								}
																								goto IL_1483;
																								IL_13c5:
																								if (17 < b)
																								{
																									goto IL_13d0;
																								}
																								goto IL_1433;
																								IL_13d0:
																								if (18 < b)
																								{
																									break;
																								}
																								goto IL_13de;
																								IL_13de:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_13ec;
																								IL_13ec:
																								array2[num5] = 5;
																								goto IL_13fa;
																								IL_13fa:
																								array3[num5] = array6[*(int*)(ptr2 + num3)];
																								goto IL_1412;
																								IL_1412:
																								num5++;
																								goto IL_1420;
																								IL_1420:
																								ptr2 += 8;
																								goto IL_1825;
																								IL_1433:
																								if (17 > b)
																								{
																									break;
																								}
																								goto IL_1441;
																								IL_1441:
																								array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																								goto IL_146a;
																								IL_146a:
																								array2[num5 - 1] = 5;
																								goto IL_1825;
																								IL_1483:
																								((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																								goto IL_14c1;
																								IL_14c1:
																								num5 -= 3;
																								num = 192;
																								goto IL_1825;
																								IL_14dd:
																								if (16 > b)
																								{
																									goto IL_14eb;
																								}
																								goto IL_174b;
																								IL_14eb:
																								if (13 < b)
																								{
																									goto IL_14f9;
																								}
																								goto IL_1645;
																								IL_14f9:
																								if (14 < b)
																								{
																									goto IL_1504;
																								}
																								goto IL_155f;
																								IL_1504:
																								if (15 < b)
																								{
																									break;
																								}
																								goto IL_1512;
																								IL_1512:
																								if (15 > b)
																								{
																									break;
																								}
																								goto IL_1520;
																								IL_1520:
																								array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																								goto IL_153e;
																								IL_153e:
																								ptr2 += 8;
																								goto IL_154c;
																								IL_154c:
																								num5--;
																								goto IL_1825;
																								IL_155f:
																								if (14 > b)
																								{
																									break;
																								}
																								goto IL_156d;
																								IL_156d:
																								array7 = array3;
																								num8 = num5;
																								if (array == null)
																								{
																									goto IL_157c;
																								}
																								num9 = ptr2;
																								byte b2 = *num9;
																								ptr2 = num9 + 4;
																								int num10 = *(int*)(ptr2 + num3);
																								ptr2 += 8;
																								byte* ptr3 = ptr2 + num10;
																								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																								while (ptr2 != ptr3)
																								{
																									*ptr4 = (byte)(*ptr2 ^ b2);
																									ptr2++;
																									ptr4++;
																								}
																								array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																								goto IL_1624;
																								IL_17b8:
																								array2[num5] = 5;
																								goto IL_17c6;
																								IL_17c6:
																								array3[num5] = ((delegate*<Dictionary<string, bool[][]>>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
																								goto IL_17e4;
																								IL_17e4:
																								num5++;
																								goto IL_17f2;
																								IL_1624:
																								array2[num5] = 5;
																								goto IL_1632;
																								IL_1632:
																								num5++;
																								goto IL_1825;
																								IL_1645:
																								if (13 <= b)
																								{
																									goto IL_1650;
																								}
																								num = 375;
																								goto IL_16c7;
																								IL_1650:
																								((delegate*<object, IntPtr, object[], ref string>)CopyToAsyncCreateOriginSchemeAccess[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6) = (string)array3[num5 - 1];
																								goto IL_16ab;
																								IL_16ab:
																								num5 -= 2;
																								goto IL_1825;
																								IL_17f2:
																								ptr2 += 8;
																								goto IL_1825;
																								IL_16c7:
																								if (12 < b)
																								{
																									break;
																								}
																								goto IL_16d5;
																								IL_16d5:
																								if (12 > b)
																								{
																									break;
																								}
																								goto IL_16e3;
																								IL_16e3:
																								array2[num5 - 1] = 5;
																								goto IL_16f7;
																								IL_16f7:
																								array3[num5 - 1] = ((delegate*<char[], string>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((char[])array3[num5 - 1]);
																								num = 21;
																								goto IL_1738;
																							}
																							break;
																							IL_0705:;
																						}
																					}
																					((delegate*<void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
																					goto IL_1817;
																					IL_1817:
																					ptr2 += 8;
																					goto IL_1825;
																					continue;
																					end_IL_0715:
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
					}
					continue;
					IL_157c:
					while (true)
					{
						IL_157c_2:
						array = new byte[4];
						while (true)
						{
							IL_158a:
							num9 = ptr2;
							byte b2 = *num9;
							ptr2 = num9 + 4;
							int num10 = *(int*)(ptr2 + num3);
							ptr2 += 8;
							byte* ptr3 = ptr2 + num10;
							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
							while (ptr2 != ptr3)
							{
								*ptr4 = (byte)(*ptr2 ^ b2);
								ptr2++;
								ptr4++;
							}
							array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
							while (true)
							{
								array2[num5] = 5;
								while (true)
								{
									IL_1632_2:
									num5++;
									while (true)
									{
										IL_1825_2:
										if (num4 == 1)
										{
											return;
										}
										while (true)
										{
											num = 298;
											while (true)
											{
												byte b = *ptr2;
												num = 96;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_0715_2:
														if (b >= 1)
														{
															while (b <= 43)
															{
																while (true)
																{
																	IL_06f5_2:
																	if (22 < b)
																	{
																		while (true)
																		{
																			IL_06e5_2:
																			if (33 >= b)
																			{
																				while (true)
																				{
																					IL_06d8_2:
																					if (33 > b)
																					{
																						while (true)
																						{
																							IL_06c8_2:
																							if (27 >= b)
																							{
																								while (true)
																								{
																									IL_06b8_2:
																									if (27 <= b)
																									{
																										while (true)
																										{
																											IL_06a3_2:
																											array3[num5] = default(RuntimeFieldHandle);
																											while (true)
																											{
																												IL_068a_2:
																												array2[num5] = 4;
																												num = 410;
																												while (true)
																												{
																													if (num != 410)
																													{
																														if (num != 1391)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 32:
																															goto IL_068a_2;
																														case 58:
																														case 204:
																															goto IL_06a3_2;
																														case 140:
																															goto IL_06b8_2;
																														case 113:
																															goto IL_06c8_2;
																														case 67:
																															goto IL_06d8_2;
																														case 41:
																														case 175:
																															goto IL_06e5_2;
																														case 107:
																															goto IL_06f5_2;
																														case 176:
																															goto IL_0705_2;
																														case 68:
																															goto IL_0715_2;
																														case 96:
																															goto end_IL_0715_2;
																														case 298:
																															goto end_IL_0725;
																														case 70:
																															goto end_IL_0735;
																														case 153:
																														case 353:
																															goto IL_0754_2;
																														case 179:
																															goto IL_0767_2;
																														case 245:
																															goto IL_0775_2;
																														case 358:
																														case 362:
																															goto IL_0788_2;
																														case 247:
																															goto IL_0793_2;
																														case 287:
																															goto IL_07a1_2;
																														case 33:
																														case 302:
																															goto IL_07af_2;
																														case 228:
																															goto IL_07e3_2;
																														case 53:
																															goto IL_07ee_2;
																														case 164:
																														case 258:
																															goto IL_0801_2;
																														case 216:
																															goto IL_080f_2;
																														case 105:
																															goto IL_0827_2;
																														case 253:
																															goto IL_0835_2;
																														case 380:
																															goto IL_0848_2;
																														case 143:
																														case 384:
																															goto IL_0861_2;
																														case 36:
																														case 101:
																															goto IL_086f_2;
																														case 177:
																														case 343:
																															goto IL_087d_2;
																														case 130:
																															goto IL_088b_2;
																														case 232:
																														case 269:
																															goto IL_0899_2;
																														case 37:
																															goto IL_08f3_2;
																														case 112:
																															goto IL_0901_2;
																														case 261:
																															goto IL_0914_2;
																														case 124:
																														case 374:
																															goto IL_0922_2;
																														case 270:
																															goto IL_0935_2;
																														case 359:
																															goto IL_0943_2;
																														case 320:
																															goto IL_0956_2;
																														case 104:
																														case 151:
																															goto IL_0961_2;
																														case 197:
																															goto IL_09a0_2;
																														case 310:
																															goto IL_09b3_2;
																														case 281:
																															goto IL_09be_2;
																														case 167:
																														case 379:
																															goto IL_09cc_2;
																														case 87:
																															goto IL_0a12_2;
																														case 333:
																															goto IL_0a20_2;
																														case 77:
																														case 357:
																															goto IL_0a3c_2;
																														case 142:
																															goto IL_0a4a_2;
																														case 71:
																														case 73:
																															goto IL_0a58_2;
																														case 309:
																															goto IL_0a96_2;
																														case 388:
																															goto IL_0aa9_2;
																														case 134:
																															goto IL_0ab7_2;
																														case 18:
																														case 59:
																															goto IL_0ac5_2;
																														case 214:
																															goto IL_0aee_2;
																														case 399:
																															goto IL_0b07_2;
																														case 186:
																														case 189:
																															goto IL_0b12_2;
																														case 307:
																															goto IL_0b30_2;
																														case 203:
																															goto IL_0b3e_2;
																														case 366:
																															goto IL_0b72_2;
																														case 108:
																														case 342:
																															goto IL_0b80_2;
																														case 225:
																															goto IL_0b8e_2;
																														case 85:
																														case 401:
																															goto IL_0b99_2;
																														case 125:
																															goto IL_0bac_2;
																														case 340:
																															goto IL_0bba_2;
																														case 400:
																															goto IL_0bcd_2;
																														case 132:
																															goto IL_0bd8_2;
																														case 25:
																														case 323:
																															goto IL_0be6_2;
																														case 100:
																															goto IL_0bf9_2;
																														case 93:
																															goto IL_0c07_2;
																														case 26:
																															goto IL_0c1a_2;
																														case 255:
																															goto IL_0c31_2;
																														case 61:
																														case 91:
																															goto IL_0c3f_2;
																														case 83:
																															goto IL_0c52_2;
																														case 57:
																															goto IL_0c60_2;
																														case 272:
																															goto IL_0c73_2;
																														case 40:
																														case 103:
																															goto IL_0c7e_2;
																														case 137:
																															goto IL_0c8c_2;
																														case 72:
																														case 397:
																															goto IL_0ca5_2;
																														case 82:
																															goto IL_0cc1_2;
																														case 202:
																														case 215:
																															goto IL_0ccf_2;
																														case 98:
																															goto IL_0ce8_2;
																														case 174:
																															goto IL_0cfb_2;
																														case 191:
																														case 381:
																															goto IL_0d09_2;
																														case 23:
																															goto IL_0d17_2;
																														case 201:
																														case 251:
																															goto IL_0d22_2;
																														case 138:
																															goto IL_0d35_2;
																														case 64:
																															goto IL_0d43_2;
																														case 348:
																															goto IL_0d56_2;
																														case 390:
																															goto IL_0d64_2;
																														case 182:
																														case 315:
																															goto IL_0d72_2;
																														case 52:
																															goto IL_0d85_2;
																														case 55:
																															goto IL_0d93_2;
																														case 171:
																															goto IL_0da6_2;
																														case 297:
																															goto IL_0db1_2;
																														case 121:
																														case 291:
																															goto IL_0dbf_2;
																														case 319:
																															goto IL_0dd2_2;
																														case 265:
																															goto IL_0de0_2;
																														case 304:
																															goto IL_0df3_2;
																														case 243:
																															goto IL_0e01_2;
																														case 1:
																														case 227:
																															goto IL_0e0f_2;
																														case 219:
																															goto IL_0e22_2;
																														case 88:
																															goto IL_0e30_2;
																														case 46:
																														case 279:
																															goto IL_0e43_2;
																														case 361:
																															goto IL_0e56_2;
																														case 349:
																															goto IL_0e64_2;
																														case 231:
																															goto IL_0e80_2;
																														case 190:
																														case 391:
																															goto IL_0e8e_2;
																														case 0:
																															goto IL_0e9c_2;
																														case 47:
																														case 238:
																															goto IL_0eaa_2;
																														case 122:
																														case 271:
																															goto IL_0eb8_2;
																														case 39:
																														case 180:
																															goto IL_0ec6_2;
																														case 66:
																														case 246:
																															goto IL_0ed4_2;
																														case 392:
																															goto IL_0ee2_2;
																														case 249:
																														case 282:
																															goto IL_0ef0_2;
																														case 268:
																															goto IL_0f30_2;
																														case 6:
																															goto IL_0f44_2;
																														case 341:
																															goto IL_0f57_2;
																														case 38:
																														case 54:
																															goto IL_0f65_2;
																														case 239:
																															goto IL_0f73_2;
																														case 169:
																															goto IL_0f94_2;
																														case 119:
																															goto IL_0fa2_2;
																														case 195:
																															goto IL_0fb5_2;
																														case 218:
																														case 329:
																															goto IL_0fc3_2;
																														case 50:
																														case 117:
																															goto IL_0fd1_2;
																														case 241:
																															goto IL_0fdf_2;
																														case 34:
																														case 248:
																															goto IL_0fed_2;
																														case 224:
																															goto IL_1005_2;
																														case 133:
																															goto IL_1023_2;
																														case 19:
																															goto IL_1047_2;
																														case 127:
																															goto IL_105f_2;
																														case 260:
																															goto IL_1072_2;
																														case 148:
																														case 230:
																															goto IL_1080_2;
																														case 393:
																															goto IL_10a9_2;
																														case 276:
																														case 305:
																															goto IL_10c2_2;
																														case 313:
																															goto IL_10e0_2;
																														case 326:
																															goto IL_10ee_2;
																														case 352:
																															goto IL_1101_2;
																														case 3:
																															goto IL_110f_2;
																														case 237:
																														case 321:
																															goto IL_111d_2;
																														case 149:
																															goto IL_1128_2;
																														case 330:
																															goto IL_1136_2;
																														case 76:
																														case 240:
																															goto IL_1144_2;
																														case 339:
																															goto IL_1152_2;
																														case 335:
																															goto IL_1165_2;
																														case 28:
																															goto IL_117c_2;
																														case 29:
																															goto IL_1198_2;
																														case 97:
																														case 347:
																															goto IL_11a6_2;
																														case 17:
																															goto IL_11bb_2;
																														case 48:
																															goto IL_11ce_2;
																														case 118:
																														case 383:
																															goto IL_11d9_2;
																														case 106:
																															goto IL_11e7_2;
																														case 183:
																														case 257:
																															goto IL_11fa_2;
																														case 16:
																															goto IL_120f_2;
																														case 65:
																														case 250:
																															goto IL_1222_2;
																														case 209:
																															goto IL_123b_2;
																														case 168:
																															goto IL_1249_2;
																														case 99:
																															goto IL_1257_2;
																														case 262:
																														case 290:
																															goto IL_1273_2;
																														case 198:
																															goto IL_12ad_2;
																														case 135:
																															goto IL_12c0_2;
																														case 286:
																														case 394:
																															goto IL_12ce_2;
																														case 79:
																														case 213:
																															goto IL_12dc_2;
																														case 30:
																															goto IL_12e7_2;
																														case 123:
																															goto IL_12f5_2;
																														case 120:
																														case 221:
																															goto IL_130c_2;
																														case 181:
																															goto IL_132e_2;
																														case 280:
																															goto IL_134a_2;
																														case 13:
																														case 256:
																															goto IL_1358_2;
																														case 234:
																															goto IL_136c_2;
																														case 210:
																															goto IL_13a4_2;
																														case 284:
																															goto IL_13b7_2;
																														case 81:
																														case 299:
																															goto IL_13c5_2;
																														case 116:
																														case 371:
																															goto IL_13d0_2;
																														case 378:
																															goto IL_13de_2;
																														case 4:
																														case 263:
																															goto IL_13ec_2;
																														case 78:
																															goto IL_13fa_2;
																														case 312:
																															goto IL_1412_2;
																														case 322:
																															goto IL_1420_2;
																														case 373:
																															goto IL_1433_2;
																														case 51:
																														case 402:
																															goto IL_1441_2;
																														case 267:
																															goto IL_146a_2;
																														case 145:
																														case 159:
																															goto IL_1483_2;
																														case 75:
																															goto IL_14c1_2;
																														case 172:
																															goto IL_14dd_2;
																														case 80:
																														case 212:
																															goto IL_14eb_2;
																														case 126:
																														case 129:
																															goto IL_14f9_2;
																														case 345:
																														case 395:
																															goto IL_1504_2;
																														case 161:
																															goto IL_1512_2;
																														case 15:
																														case 60:
																															goto IL_1520_2;
																														case 44:
																															goto IL_153e_2;
																														case 208:
																															goto IL_154c_2;
																														case 12:
																															goto IL_155f_2;
																														case 294:
																														case 314:
																															goto IL_156d_2;
																														case 344:
																															goto end_IL_0749;
																														case 355:
																															goto IL_1632_2;
																														case 295:
																															goto IL_1645_2;
																														case 114:
																														case 382:
																															goto IL_1650_2;
																														case 338:
																															goto IL_16ab_2;
																														case 365:
																														case 375:
																															goto IL_16c7_2;
																														case 331:
																															goto IL_16d5_2;
																														case 10:
																														case 141:
																															goto IL_16e3_2;
																														case 200:
																															goto IL_16f7_2;
																														case 21:
																															goto IL_1738_2;
																														case 211:
																														case 370:
																															goto IL_174b_2;
																														case 242:
																															goto IL_178b_2;
																														case 184:
																															goto IL_179f_2;
																														case 31:
																														case 35:
																															goto IL_17b8_2;
																														case 199:
																															goto IL_17c6_2;
																														case 367:
																															goto IL_17e4_2;
																														case 157:
																															goto IL_17f2_2;
																														case 2:
																														case 7:
																														case 9:
																														case 14:
																														case 20:
																														case 22:
																														case 24:
																														case 42:
																														case 43:
																														case 45:
																														case 62:
																														case 69:
																														case 90:
																														case 92:
																														case 94:
																														case 95:
																														case 102:
																														case 111:
																														case 128:
																														case 131:
																														case 139:
																														case 152:
																														case 156:
																														case 158:
																														case 160:
																														case 162:
																														case 165:
																														case 166:
																														case 170:
																														case 173:
																														case 178:
																														case 185:
																														case 187:
																														case 188:
																														case 194:
																														case 196:
																														case 222:
																														case 229:
																														case 233:
																														case 236:
																														case 244:
																														case 259:
																														case 266:
																														case 278:
																														case 283:
																														case 285:
																														case 293:
																														case 303:
																														case 308:
																														case 316:
																														case 324:
																														case 325:
																														case 327:
																														case 332:
																														case 334:
																														case 346:
																														case 351:
																														case 354:
																														case 369:
																														case 372:
																														case 385:
																														case 386:
																														case 396:
																														case 398:
																															goto end_IL_0677_2;
																														case 273:
																															goto IL_1817_2;
																														case 8:
																														case 11:
																														case 27:
																														case 49:
																														case 63:
																														case 74:
																														case 84:
																														case 86:
																														case 89:
																														case 109:
																														case 144:
																														case 146:
																														case 147:
																														case 150:
																														case 154:
																														case 155:
																														case 163:
																														case 192:
																														case 193:
																														case 205:
																														case 207:
																														case 217:
																														case 220:
																														case 226:
																														case 235:
																														case 252:
																														case 254:
																														case 264:
																														case 277:
																														case 288:
																														case 292:
																														case 296:
																														case 300:
																														case 306:
																														case 318:
																														case 336:
																														case 337:
																														case 360:
																														case 363:
																														case 364:
																														case 376:
																														case 377:
																														case 389:
																														case 403:
																															goto IL_1825_2;
																														case 368:
																															num = 147;
																															goto IL_1825_2;
																														case 206:
																															ptr2 = ptr;
																															goto case 368;
																														case 317:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OptionalParamBindingConstructorCallMessage.SecurityContextFrameShadowCopyFiles);
																															goto case 206;
																														case 5:
																															array6 = new object[32];
																															goto case 317;
																														case 115:
																															array5 = new long[9];
																															goto case 5;
																														case 223:
																															array4 = new int[9];
																															goto case 115;
																														case 301:
																															array3 = new object[9];
																															num = 223;
																															goto case 223;
																														case 136:
																														case 311:
																															array2 = new byte[9];
																															num = 301;
																															goto case 301;
																														case 289:
																															num3 = num2 * 4;
																															goto case 136;
																														case 56:
																															num2 = 1;
																															goto case 289;
																														case 110:
																														case 356:
																														case 387:
																															goto end_IL_1624;
																														case 274:
																															goto end_IL_18d5;
																														case 275:
																															goto end_IL_18eb;
																														case 328:
																														case 350:
																															return;
																														}
																														continue;
																													}
																													num5++;
																													goto IL_1825_2;
																													continue;
																													end_IL_0677_2:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0788_2;
																									IL_080f_2:
																									array3[num5] = array6[*(int*)(ptr2 + num3)];
																									goto IL_0827_2;
																									IL_0788_2:
																									if (24 < b)
																									{
																										goto IL_0793_2;
																									}
																									num = 228;
																									goto IL_07e3_2;
																									IL_0793_2:
																									if (25 >= b)
																									{
																										goto IL_07a1_2;
																									}
																									goto IL_0aa9_2;
																									IL_07a1_2:
																									if (25 > b)
																									{
																										break;
																									}
																									goto IL_07af_2;
																									IL_07af_2:
																									array3[num5 - 1] = new bool[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])][];
																									goto IL_0848_2;
																									IL_0848_2:
																									array2[num5 - 1] = 5;
																									goto IL_1825_2;
																									IL_0aa9_2:
																									if (26 < b)
																									{
																										break;
																									}
																									goto IL_0ab7_2;
																									IL_0ab7_2:
																									if (26 > b)
																									{
																										break;
																									}
																									goto IL_0ac5_2;
																									IL_0ac5_2:
																									array3[num5 - 1] = new bool[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																									goto IL_0aee_2;
																									IL_0aee_2:
																									array2[num5 - 1] = 5;
																									goto IL_1825_2;
																									IL_0827_2:
																									num5++;
																									goto IL_0835_2;
																									IL_07e3_2:
																									if (24 > b)
																									{
																										goto IL_07ee_2;
																									}
																									goto IL_0801_2;
																									IL_07ee_2:
																									if (23 < b)
																									{
																										break;
																									}
																									goto IL_0b07_2;
																									IL_0b07_2:
																									if (23 > b)
																									{
																										num = 20;
																										break;
																									}
																									goto IL_0b12_2;
																									IL_0b12_2:
																									array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																									goto IL_0b30_2;
																									IL_0b30_2:
																									ptr2 += 8;
																									goto IL_0b3e_2;
																									IL_0b3e_2:
																									num5--;
																									goto IL_1825_2;
																									IL_0835_2:
																									ptr2 += 8;
																									goto IL_1825_2;
																									IL_0801_2:
																									array2[num5] = 5;
																									goto IL_080f_2;
																								}
																								break;
																							}
																							goto IL_0861_2;
																							IL_0a58_2:
																							((bool[][])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (bool[])array3[num5 - 1];
																							goto IL_0a96_2;
																							IL_0861_2:
																							if (30 < b)
																							{
																								goto IL_086f_2;
																							}
																							goto IL_0956_2;
																							IL_086f_2:
																							if (31 < b)
																							{
																								goto IL_087d_2;
																							}
																							goto IL_0914_2;
																							IL_087d_2:
																							if (32 < b)
																							{
																								break;
																							}
																							goto IL_088b_2;
																							IL_088b_2:
																							if (32 > b)
																							{
																								break;
																							}
																							goto IL_0899_2;
																							IL_0899_2:
																							((delegate*<Dictionary<string, bool[][]>, string, bool[][], void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((Dictionary<string, bool[][]>)array3[num5 - 3], (string)array3[num5 - 2], (bool[][])array3[num5 - 1]);
																							num = 37;
																							goto IL_08f3_2;
																							IL_08f3_2:
																							num5 -= 3;
																							goto IL_0901_2;
																							IL_0901_2:
																							ptr2 += 8;
																							goto IL_1825_2;
																							IL_0914_2:
																							if (31 > b)
																							{
																								break;
																							}
																							goto IL_0922_2;
																							IL_0922_2:
																							array3[num5] = default(RuntimeFieldHandle);
																							goto IL_0935_2;
																							IL_0935_2:
																							array2[num5] = 4;
																							goto IL_0943_2;
																							IL_0943_2:
																							num5++;
																							goto IL_1825_2;
																							IL_0956_2:
																							if (30 <= b)
																							{
																								goto IL_0961_2;
																							}
																							goto IL_09b3_2;
																							IL_0961_2:
																							((bool[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])) != 0;
																							goto IL_09a0_2;
																							IL_09a0_2:
																							num5 -= 3;
																							goto IL_1825_2;
																							IL_09b3_2:
																							if (28 >= b)
																							{
																								goto IL_09be_2;
																							}
																							num = 77;
																							goto IL_0a3c_2;
																							IL_09be_2:
																							if (28 > b)
																							{
																								break;
																							}
																							goto IL_09cc_2;
																							IL_09cc_2:
																							((delegate*<Array, RuntimeFieldHandle, void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((bool[])array3[num5 - 2], (RuntimeFieldHandle)array3[num5 - 1]);
																							num = 87;
																							goto IL_0a12_2;
																							IL_0a12_2:
																							num5 -= 2;
																							goto IL_0a20_2;
																							IL_0a20_2:
																							ptr2 += 8;
																							goto IL_1825_2;
																							IL_0a96_2:
																							num5 -= 3;
																							goto IL_1825_2;
																							IL_0a3c_2:
																							if (29 < b)
																							{
																								break;
																							}
																							goto IL_0a4a_2;
																							IL_0a4a_2:
																							if (29 > b)
																							{
																								break;
																							}
																							goto IL_0a58_2;
																						}
																						break;
																					}
																					goto IL_0754_2;
																					IL_0775_2:
																					num5++;
																					goto IL_1825_2;
																					IL_0754_2:
																					array3[num5] = default(RuntimeFieldHandle);
																					goto IL_0767_2;
																					IL_0767_2:
																					array2[num5] = 4;
																					goto IL_0775_2;
																				}
																				break;
																			}
																			goto IL_0b72_2;
																			IL_0e43_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0e56_2;
																			IL_0b72_2:
																			if (38 < b)
																			{
																				goto IL_0b80_2;
																			}
																			goto IL_0cfb_2;
																			IL_0b80_2:
																			if (41 >= b)
																			{
																				goto IL_0b8e_2;
																			}
																			goto IL_0c73_2;
																			IL_0b8e_2:
																			if (41 <= b)
																			{
																				goto IL_0b99_2;
																			}
																			goto IL_0bcd_2;
																			IL_0b99_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0bac_2;
																			IL_0bac_2:
																			array2[num5] = 4;
																			goto IL_0bba_2;
																			IL_0bba_2:
																			num5++;
																			goto IL_1825_2;
																			IL_0bcd_2:
																			if (39 >= b)
																			{
																				goto IL_0bd8_2;
																			}
																			goto IL_0c1a_2;
																			IL_0bd8_2:
																			if (39 > b)
																			{
																				break;
																			}
																			goto IL_0be6_2;
																			IL_0be6_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0bf9_2;
																			IL_0bf9_2:
																			array2[num5] = 4;
																			goto IL_0c07_2;
																			IL_0c07_2:
																			num5++;
																			goto IL_1825_2;
																			IL_0c1a_2:
																			if (40 < b)
																			{
																				break;
																			}
																			num = 255;
																			goto IL_0c31_2;
																			IL_0e56_2:
																			array2[num5] = 4;
																			goto IL_0e64_2;
																			IL_0c31_2:
																			if (40 > b)
																			{
																				break;
																			}
																			goto IL_0c3f_2;
																			IL_0c3f_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0c52_2;
																			IL_0c52_2:
																			array2[num5] = 4;
																			goto IL_0c60_2;
																			IL_0c60_2:
																			num5++;
																			goto IL_1825_2;
																			IL_0c73_2:
																			if (42 < b)
																			{
																				goto IL_0c7e_2;
																			}
																			goto IL_0cc1_2;
																			IL_0c7e_2:
																			if (43 < b)
																			{
																				break;
																			}
																			goto IL_0c8c_2;
																			IL_0c8c_2:
																			if (43 > b)
																			{
																				num = 139;
																				break;
																			}
																			goto IL_0ca5_2;
																			IL_0e64_2:
																			num5++;
																			num = 109;
																			goto IL_1825_2;
																			IL_0ca5_2:
																			num6 = ptr2;
																			num7 = -200;
																			num4 = 1;
																			ptr2 = num6 + num7;
																			goto IL_1825_2;
																			IL_0cc1_2:
																			if (42 > b)
																			{
																				break;
																			}
																			goto IL_0ccf_2;
																			IL_0ccf_2:
																			dictionary_0 = (Dictionary<string, bool[][]>)array3[num5 - 1];
																			goto IL_0ce8_2;
																			IL_0ce8_2:
																			num5--;
																			goto IL_1825_2;
																			IL_0cfb_2:
																			if (38 > b)
																			{
																				goto IL_0d09_2;
																			}
																			goto IL_0e43_2;
																			IL_0d09_2:
																			if (35 >= b)
																			{
																				goto IL_0d17_2;
																			}
																			goto IL_0da6_2;
																			IL_0d17_2:
																			if (35 <= b)
																			{
																				goto IL_0d22_2;
																			}
																			goto IL_0d56_2;
																			IL_0d22_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0d35_2;
																			IL_0d35_2:
																			array2[num5] = 4;
																			goto IL_0d43_2;
																			IL_0d43_2:
																			num5++;
																			goto IL_1825_2;
																			IL_0d56_2:
																			if (34 < b)
																			{
																				break;
																			}
																			goto IL_0d64_2;
																			IL_0d64_2:
																			if (34 > b)
																			{
																				break;
																			}
																			goto IL_0d72_2;
																			IL_0d72_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0d85_2;
																			IL_0d85_2:
																			array2[num5] = 4;
																			goto IL_0d93_2;
																			IL_0d93_2:
																			num5++;
																			goto IL_1825_2;
																			IL_0da6_2:
																			if (36 >= b)
																			{
																				goto IL_0db1_2;
																			}
																			goto IL_0df3_2;
																			IL_0db1_2:
																			if (36 > b)
																			{
																				break;
																			}
																			goto IL_0dbf_2;
																			IL_0dbf_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0dd2_2;
																			IL_0dd2_2:
																			array2[num5] = 4;
																			goto IL_0de0_2;
																			IL_0de0_2:
																			num5++;
																			goto IL_1825_2;
																			IL_0df3_2:
																			if (37 < b)
																			{
																				break;
																			}
																			goto IL_0e01_2;
																			IL_0e01_2:
																			if (37 > b)
																			{
																				break;
																			}
																			goto IL_0e0f_2;
																			IL_0e0f_2:
																			array3[num5] = default(RuntimeFieldHandle);
																			goto IL_0e22_2;
																			IL_0e22_2:
																			array2[num5] = 4;
																			goto IL_0e30_2;
																			IL_0e30_2:
																			num5++;
																			goto IL_1825_2;
																		}
																		break;
																	}
																	goto IL_0e80_2;
																	IL_179f_2:
																	num5--;
																	num = 277;
																	goto IL_1825_2;
																	IL_0e80_2:
																	if (22 > b)
																	{
																		goto IL_0e8e_2;
																	}
																	goto IL_17b8_2;
																	IL_0e8e_2:
																	if (11 >= b)
																	{
																		goto IL_0e9c_2;
																	}
																	goto IL_12c0_2;
																	IL_0e9c_2:
																	if (11 > b)
																	{
																		goto IL_0eaa_2;
																	}
																	goto IL_1273_2;
																	IL_0eaa_2:
																	if (5 < b)
																	{
																		goto IL_0eb8_2;
																	}
																	goto IL_1101_2;
																	IL_0eb8_2:
																	if (8 < b)
																	{
																		goto IL_0ec6_2;
																	}
																	goto IL_0fb5_2;
																	IL_0ec6_2:
																	if (9 < b)
																	{
																		goto IL_0ed4_2;
																	}
																	goto IL_0f57_2;
																	IL_0ed4_2:
																	if (10 < b)
																	{
																		break;
																	}
																	goto IL_0ee2_2;
																	IL_0ee2_2:
																	if (10 > b)
																	{
																		break;
																	}
																	goto IL_0ef0_2;
																	IL_0ef0_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																	goto IL_0f30_2;
																	IL_0f30_2:
																	array2[num5 - 2] = 0;
																	goto IL_0f44_2;
																	IL_0f44_2:
																	num5--;
																	goto IL_1825_2;
																	IL_0f57_2:
																	if (9 > b)
																	{
																		break;
																	}
																	goto IL_0f65_2;
																	IL_0f65_2:
																	array2[num5] = 5;
																	goto IL_0f73_2;
																	IL_0f73_2:
																	array3[num5] = array6[*(int*)(ptr2 + num3)];
																	num = 169;
																	goto IL_0f94_2;
																	IL_0f94_2:
																	num5++;
																	goto IL_0fa2_2;
																	IL_0fa2_2:
																	ptr2 += 8;
																	goto IL_1825_2;
																	IL_0fb5_2:
																	if (8 > b)
																	{
																		goto IL_0fc3_2;
																	}
																	goto IL_10c2_2;
																	IL_0fc3_2:
																	if (6 < b)
																	{
																		goto IL_0fd1_2;
																	}
																	goto IL_1072_2;
																	IL_0fd1_2:
																	if (7 < b)
																	{
																		break;
																	}
																	goto IL_0fdf_2;
																	IL_0fdf_2:
																	if (7 > b)
																	{
																		break;
																	}
																	goto IL_0fed_2;
																	IL_0fed_2:
																	array2[num5] = array2[num5 - 1];
																	goto IL_1005_2;
																	IL_1005_2:
																	array4[num5 - 0] = array4[num5 - 1];
																	goto IL_1023_2;
																	IL_1023_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																	goto IL_1047_2;
																	IL_1047_2:
																	array3[num5] = array3[num5 - 1];
																	goto IL_105f_2;
																	IL_105f_2:
																	num5++;
																	goto IL_1825_2;
																	IL_1072_2:
																	if (6 > b)
																	{
																		break;
																	}
																	goto IL_1080_2;
																	IL_1080_2:
																	array3[num5 - 1] = new char[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																	goto IL_10a9_2;
																	IL_10a9_2:
																	array2[num5 - 1] = 5;
																	goto IL_1825_2;
																	IL_10c2_2:
																	array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																	goto IL_10e0_2;
																	IL_10e0_2:
																	ptr2 += 8;
																	goto IL_10ee_2;
																	IL_10ee_2:
																	num5--;
																	goto IL_1825_2;
																	IL_1101_2:
																	if (5 > b)
																	{
																		goto IL_110f_2;
																	}
																	goto IL_1222_2;
																	IL_110f_2:
																	if (2 < b)
																	{
																		goto IL_111d_2;
																	}
																	goto IL_11ce_2;
																	IL_111d_2:
																	if (3 < b)
																	{
																		goto IL_1128_2;
																	}
																	num = 29;
																	goto IL_1198_2;
																	IL_1128_2:
																	if (4 < b)
																	{
																		break;
																	}
																	goto IL_1136_2;
																	IL_1136_2:
																	if (4 > b)
																	{
																		break;
																	}
																	goto IL_1144_2;
																	IL_1144_2:
																	array2[num5] = 15;
																	goto IL_1152_2;
																	IL_1152_2:
																	array4[num5] = *(int*)(ptr2 + num3);
																	goto IL_1165_2;
																	IL_1165_2:
																	ptr2 += 8;
																	num = 28;
																	goto IL_117c_2;
																	IL_117c_2:
																	num5++;
																	goto IL_1825_2;
																	IL_17b8_2:
																	array2[num5] = 5;
																	goto IL_17c6_2;
																	IL_1198_2:
																	if (3 > b)
																	{
																		break;
																	}
																	goto IL_11a6_2;
																	IL_11a6_2:
																	((delegate*<void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
																	goto IL_11bb_2;
																	IL_11bb_2:
																	ptr2 += 8;
																	goto IL_1825_2;
																	IL_11ce_2:
																	if (2 > b)
																	{
																		goto IL_11d9_2;
																	}
																	goto IL_11fa_2;
																	IL_11d9_2:
																	if (1 < b)
																	{
																		break;
																	}
																	goto IL_11e7_2;
																	IL_11e7_2:
																	if (1 > b)
																	{
																	}
																	break;
																	IL_11fa_2:
																	((delegate*<void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
																	goto IL_120f_2;
																	IL_120f_2:
																	ptr2 += 8;
																	goto IL_1825_2;
																	IL_1222_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5]) = *(int*)(ptr2 + num3);
																	goto IL_123b_2;
																	IL_123b_2:
																	array2[num5] = 0;
																	goto IL_1249_2;
																	IL_1249_2:
																	num5++;
																	goto IL_1257_2;
																	IL_1257_2:
																	ptr2 += 8;
																	num = 63;
																	goto IL_1825_2;
																	IL_1273_2:
																	((short[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (short)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]));
																	goto IL_12ad_2;
																	IL_12ad_2:
																	num5 -= 3;
																	goto IL_1825_2;
																	IL_12c0_2:
																	if (16 < b)
																	{
																		goto IL_12ce_2;
																	}
																	goto IL_14dd_2;
																	IL_12ce_2:
																	if (19 < b)
																	{
																		goto IL_12dc_2;
																	}
																	goto IL_13b7_2;
																	IL_12dc_2:
																	if (20 < b)
																	{
																		goto IL_12e7_2;
																	}
																	num = 280;
																	goto IL_134a_2;
																	IL_12e7_2:
																	if (21 < b)
																	{
																		break;
																	}
																	goto IL_12f5_2;
																	IL_12f5_2:
																	if (21 > b)
																	{
																		break;
																	}
																	num = 120;
																	goto IL_130c_2;
																	IL_17e4_2:
																	num5++;
																	goto IL_17f2_2;
																	IL_130c_2:
																	string_1 = (string[])array3[num5 - 1];
																	num = 181;
																	goto IL_132e_2;
																	IL_132e_2:
																	num5--;
																	goto IL_1825_2;
																	IL_17c6_2:
																	array3[num5] = ((delegate*<Dictionary<string, bool[][]>>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
																	goto IL_17e4_2;
																	IL_134a_2:
																	if (20 > b)
																	{
																		break;
																	}
																	goto IL_1358_2;
																	IL_1358_2:
																	array2[num5 - 1] = 5;
																	goto IL_136c_2;
																	IL_136c_2:
																	array3[num5 - 1] = ((delegate*<string[], string>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																	goto IL_13a4_2;
																	IL_13a4_2:
																	ptr2 += 8;
																	goto IL_1825_2;
																	IL_13b7_2:
																	if (19 > b)
																	{
																		goto IL_13c5_2;
																	}
																	goto IL_1483_2;
																	IL_13c5_2:
																	if (17 < b)
																	{
																		goto IL_13d0_2;
																	}
																	goto IL_1433_2;
																	IL_13d0_2:
																	if (18 < b)
																	{
																		break;
																	}
																	goto IL_13de_2;
																	IL_13de_2:
																	if (18 > b)
																	{
																		break;
																	}
																	goto IL_13ec_2;
																	IL_13ec_2:
																	array2[num5] = 5;
																	goto IL_13fa_2;
																	IL_13fa_2:
																	array3[num5] = array6[*(int*)(ptr2 + num3)];
																	goto IL_1412_2;
																	IL_1412_2:
																	num5++;
																	goto IL_1420_2;
																	IL_1420_2:
																	ptr2 += 8;
																	goto IL_1825_2;
																	IL_1433_2:
																	if (17 > b)
																	{
																		break;
																	}
																	goto IL_1441_2;
																	IL_1441_2:
																	array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1])];
																	goto IL_146a_2;
																	IL_146a_2:
																	array2[num5 - 1] = 5;
																	goto IL_1825_2;
																	IL_1483_2:
																	((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])] = (string)array3[num5 - 1];
																	goto IL_14c1_2;
																	IL_14c1_2:
																	num5 -= 3;
																	num = 192;
																	goto IL_1825_2;
																	IL_14dd_2:
																	if (16 > b)
																	{
																		goto IL_14eb_2;
																	}
																	goto IL_174b_2;
																	IL_14eb_2:
																	if (13 < b)
																	{
																		goto IL_14f9_2;
																	}
																	goto IL_1645_2;
																	IL_14f9_2:
																	if (14 < b)
																	{
																		goto IL_1504_2;
																	}
																	goto IL_155f_2;
																	IL_1504_2:
																	if (15 < b)
																	{
																		break;
																	}
																	goto IL_1512_2;
																	IL_1512_2:
																	if (15 > b)
																	{
																		break;
																	}
																	goto IL_1520_2;
																	IL_1520_2:
																	array6[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																	goto IL_153e_2;
																	IL_153e_2:
																	ptr2 += 8;
																	goto IL_154c_2;
																	IL_154c_2:
																	num5--;
																	goto IL_1825_2;
																	IL_155f_2:
																	if (14 > b)
																	{
																		break;
																	}
																	goto IL_156d_2;
																	IL_156d_2:
																	array7 = array3;
																	num8 = num5;
																	if (array == null)
																	{
																		goto IL_157c_2;
																	}
																	goto IL_158a;
																	IL_1645_2:
																	if (13 <= b)
																	{
																		goto IL_1650_2;
																	}
																	num = 375;
																	goto IL_16c7_2;
																	IL_1650_2:
																	((delegate*<object, IntPtr, object[], ref string>)CopyToAsyncCreateOriginSchemeAccess[array4[num5 - 2]])(array3[num5 - 2], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2])), array6) = (string)array3[num5 - 1];
																	goto IL_16ab_2;
																	IL_16ab_2:
																	num5 -= 2;
																	goto IL_1825_2;
																	IL_17f2_2:
																	ptr2 += 8;
																	goto IL_1825_2;
																	IL_16c7_2:
																	if (12 < b)
																	{
																		break;
																	}
																	goto IL_16d5_2;
																	IL_16d5_2:
																	if (12 > b)
																	{
																		break;
																	}
																	goto IL_16e3_2;
																	IL_16e3_2:
																	array2[num5 - 1] = 5;
																	goto IL_16f7_2;
																	IL_16f7_2:
																	array3[num5 - 1] = ((delegate*<char[], string>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])((char[])array3[num5 - 1]);
																	num = 21;
																	goto IL_1738_2;
																	IL_1738_2:
																	ptr2 += 8;
																	goto IL_1825_2;
																	IL_174b_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num5 - 1]);
																	goto IL_178b_2;
																	IL_178b_2:
																	array2[num5 - 2] = 0;
																	goto IL_179f_2;
																}
																break;
																IL_0705_2:;
															}
														}
														((delegate*<void>)CopyToAsyncCreateOriginSchemeAccess[*(int*)(ptr2 + num3)])();
														goto IL_1817_2;
														IL_1817_2:
														ptr2 += 8;
														goto IL_1825_2;
														continue;
														end_IL_0715_2:
														break;
													}
													continue;
													end_IL_0725:
													break;
												}
												continue;
												end_IL_0735:
												break;
											}
											continue;
											end_IL_0749:
											break;
										}
										break;
									}
									break;
								}
								continue;
								end_IL_1624:
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_18d5:
					break;
				}
				continue;
				end_IL_18eb:
				break;
			}
		}
	}

	private unsafe void Update()
	{
		byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getResourceSetTypesetNumberGroupSizes.OIServerFault);
		int num = 4;
		int num2 = 0;
		int num3 = 0;
		num3 = 0;
		int try0013_dispatch = -1;
		object[] array = default(object[]);
		Type[] array2 = default(Type[]);
		RuntimeTypeHandle[] array3 = default(RuntimeTypeHandle[]);
		Exception ex = default(Exception);
		int num22 = default(int);
		Exception ex2 = default(Exception);
		int num23 = default(int);
		int num25 = default(int);
		int num26 = default(int);
		int num27 = default(int);
		int num28 = default(int);
		int num29 = default(int);
		int num30 = default(int);
		int num31 = default(int);
		object obj3 = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		string text22 = default(string);
		string text23 = default(string);
		string text24 = default(string);
		string text25 = default(string);
		string text26 = default(string);
		string text27 = default(string);
		string text28 = default(string);
		string text29 = default(string);
		string text30 = default(string);
		string text31 = default(string);
		string text32 = default(string);
		string text33 = default(string);
		string text34 = default(string);
		string text35 = default(string);
		Class8.GunResult gunResult = default(Class8.GunResult);
		string text36 = default(string);
		Vector3 vector = default(Vector3);
		Quaternion quaternion = default(Quaternion);
		float num32 = default(float);
		float num33 = default(float);
		int num34 = default(int);
		char c = default(char);
		string text37 = default(string);
		bool[][] array6 = default(bool[][]);
		int num35 = default(int);
		bool[] array7 = default(bool[]);
		int num36 = default(int);
		Vector3 vector2 = default(Vector3);
		Vector3 vector3 = default(Vector3);
		List<GameEntityCreateData> list = default(List<GameEntityCreateData>);
		string[] array8 = default(string[]);
		int num37 = default(int);
		string text38 = default(string);
		int num38 = default(int);
		List<(Vector3, Quaternion)>.Enumerator enumerator = default(List<(Vector3, Quaternion)>.Enumerator);
		(Vector3, Quaternion) tuple = default((Vector3, Quaternion));
		GameEntityCreateData gameEntityCreateData = default(GameEntityCreateData);
		while (true)
		{
			try
			{
				/*Note: ILSpy has introduced the following switch to emulate a goto from catch-block to try-block*/;
				switch (try0013_dispatch)
				{
				case 2376:
					while (true)
					{
						int num4 = num2;
						int num5 = num4;
						int num6 = 0;
						int num7 = 2;
						int num10;
						int num9;
						int num8;
						while (true)
						{
							num8 = (num6 + num7) / 2;
							num9 = *(int*)(ptr + 152 + num8 * 48 + 24 + num);
							num10 = *(int*)(ptr + 152 + num8 * 48 + 16 + num);
							if (num5 >= num9 + num10)
							{
								num6 = num8 + 1;
								continue;
							}
							if (num9 <= num5)
							{
								break;
							}
							num7 = num8 - 1;
						}
						int num11 = num8;
						int num12 = *(int*)(ptr + 152 + num11 * 48 + num);
						int num13 = num12;
						int num14 = num13;
						int num21;
						int num17;
						while (true)
						{
							if (array != null)
							{
								if ((int)array[4] == 1)
								{
									int num15 = (int)array[1];
									int num16;
									if (num13 == -1)
									{
										num16 = -1;
									}
									else
									{
										num17 = *(int*)(ptr + num13 + num);
										num10 = 0;
										num9 = 2;
										while (true)
										{
											num8 = (num10 + num9) / 2;
											num7 = *(int*)(ptr + 296 + num8 * 40 + 16 + num);
											num6 = *(int*)(ptr + 296 + num8 * 40 + 8 + num);
											if (num17 >= num7 + num6)
											{
												num10 = num8 + 1;
												continue;
											}
											if (num7 <= num17)
											{
												break;
											}
											num9 = num8 - 1;
										}
										num12 = num8;
										num11 = *(int*)(ptr + 296 + num12 * 40 + num);
										num16 = num11;
									}
									if (num15 != num16)
									{
										array = (object[])array[3];
										continue;
									}
								}
								else
								{
									int num18 = (int)array[0];
									if (num18 != 2 && num18 != 1 && num18 == 0)
									{
										break;
									}
									int num19 = (int)array[1];
									int num20;
									if (num13 == -1)
									{
										num20 = -1;
									}
									else
									{
										num5 = *(int*)(ptr + num13 + num);
										num6 = 0;
										num7 = 2;
										while (true)
										{
											num8 = (num6 + num7) / 2;
											num9 = *(int*)(ptr + 296 + num8 * 40 + 16 + num);
											num10 = *(int*)(ptr + 296 + num8 * 40 + 8 + num);
											if (num5 >= num9 + num10)
											{
												num6 = num8 + 1;
												continue;
											}
											if (num9 <= num5)
											{
												break;
											}
											num7 = num8 - 1;
										}
										num11 = num8;
										num12 = *(int*)(ptr + 296 + num11 * 40 + num);
										num20 = num12;
									}
									if (num19 != num20)
									{
										array = (object[])array[3];
										continue;
									}
								}
							}
							if (-1 == num13)
							{
								goto IL_095b;
							}
							num21 = *(int*)(ptr + num13 + 24 + num);
							num5 = num21;
							while (num5 != -1)
							{
								num7 = *(int*)(ptr + num5 + 24 + num);
								if (2 != num7)
								{
									goto IL_08a2;
								}
								num6 = *(int*)(ptr + num5 + 8 + num);
								if (num6 != -1)
								{
									object obj = array2[num6];
									if (obj == null)
									{
										array2[num6] = Type.GetTypeFromHandle(array3[num6]);
										obj = array2[num6];
									}
									if (!((Type)obj).IsInstanceOfType((object)ex))
									{
										num5 = *(int*)(ptr + num5 + 72 + num);
										continue;
									}
								}
								goto IL_09ea;
							}
							num13 = *(int*)(ptr + num13 + 32 + num);
							continue;
							IL_08a2:
							if (1 != num7)
							{
								num13 = *(int*)(ptr + num13 + 32 + num);
								continue;
							}
							goto IL_0991;
						}
						object[] array4 = array;
						num4 = *(int*)(ptr + (int)array4[1] + 72 + num);
						while (num4 != -1)
						{
							num21 = *(int*)(ptr + num4 + 24 + num);
							if (2 != num21)
							{
								goto IL_05f3;
							}
							num13 = *(int*)(ptr + num4 + 8 + num);
							if (num13 != -1)
							{
								object obj2 = array2[num13];
								if (obj2 == null)
								{
									array2[num13] = Type.GetTypeFromHandle(array3[num13]);
									obj2 = array2[num13];
								}
								if (!((Type)obj2).IsInstanceOfType(array4[2]))
								{
									num4 = *(int*)(ptr + num4 + 72 + num);
									continue;
								}
							}
							goto IL_0b70;
						}
						goto IL_05fb;
						IL_05fb:
						array = (object[])array[3];
						ex = (Exception)array4[2];
						num22 = (int)array4[7];
						continue;
						IL_09ea:
						num17 = num5;
						num10 = *(int*)(ptr + *(int*)(ptr + num17 + 40 + num) + 32 + num);
						num9 = (num14 - num22) * ((num22 == -1) ? 1 : 0) + num22;
						while (true)
						{
							if (num9 != num10)
							{
								num8 = *(int*)(ptr + num9 + 8 + num);
								if (num8 == -1)
								{
									num9 = *(int*)(ptr + num9 + 32 + num);
									continue;
								}
								array4 = new object[8];
								array4[4] = 0;
								array4[3] = array;
								array4[2] = ex;
								array4[7] = num14;
								array4[1] = num8;
								array4[6] = num17;
								array4[0] = 1;
								array = array4;
								num2 = *(int*)(ptr + num8 + num);
								break;
							}
							ex2 = ex;
							array4 = new object[8];
							array4[4] = 0;
							array4[3] = array;
							array4[2] = ex;
							array4[7] = num14;
							array4[1] = num17;
							array4[0] = 2;
							array = array4;
							num2 = *(int*)(ptr + num17 + num);
							break;
						}
						break;
						IL_0b70:
						num12 = num4;
						num11 = *(int*)(ptr + *(int*)(ptr + num12 + 40 + num) + 32 + num);
						num14 = (int)array4[7];
						while (true)
						{
							object[] array5;
							if (num14 != num11)
							{
								int num18 = *(int*)(ptr + num14 + 8 + num);
								if (num18 == -1)
								{
									num14 = *(int*)(ptr + num14 + 32 + num);
									continue;
								}
								num5 = *(int*)(ptr + num18 + num);
								array = (object[])array[3];
								array5 = new object[8];
								array5[4] = 0;
								array5[3] = array;
								array5[2] = array4[2];
								array5[7] = (int)array4[7];
								array5[1] = num18;
								array5[6] = num12;
								array5[0] = 1;
								array = array5;
								num2 = *(int*)(ptr + num18 + num);
								break;
							}
							num5 = *(int*)(ptr + num12 + num);
							ex2 = (Exception)array4[2];
							array = (object[])array[3];
							array5 = new object[8];
							array5[4] = 0;
							array5[3] = array;
							array5[2] = array4[2];
							array5[7] = (int)array4[7];
							array5[1] = num12;
							array5[0] = 2;
							array = array5;
							num2 = *(int*)(ptr + num12 + num);
							break;
						}
						break;
						IL_0991:
						ex2 = ex;
						array4 = new object[8];
						array4[4] = 0;
						array4[3] = array;
						array4[2] = ex;
						array4[7] = num14;
						array4[1] = num5;
						array4[0] = 0;
						array = array4;
						num2 = *(int*)(ptr + num5 + 32 + num);
						break;
						IL_095b:
						num12 = num14;
						while (true)
						{
							if (num12 != -1)
							{
								num11 = *(int*)(ptr + num12 + 8 + num);
								if (num11 != -1)
								{
									break;
								}
								num12 = *(int*)(ptr + num12 + 32 + num);
								continue;
							}
							num23 = 1;
							throw ex;
						}
						num17 = *(int*)(ptr + num11 + num);
						array4 = new object[8];
						array4[4] = 0;
						array4[3] = array;
						array4[2] = ex;
						array4[7] = num14;
						array4[1] = -1;
						array4[6] = -1;
						array4[0] = 2;
						array = array4;
						num2 = *(int*)(ptr + num11 + num);
						break;
						IL_05f3:
						if (1 == num21)
						{
							num5 = *(int*)(ptr + num4 + 32 + num);
							ex2 = (Exception)array4[2];
							array = (object[])array[3];
							object[] array5 = new object[8];
							array5[4] = 0;
							array5[3] = array;
							array5[2] = array4[2];
							array5[7] = (int)array4[7];
							array5[1] = num4;
							array5[0] = 0;
							array = array5;
							num2 = *(int*)(ptr + num4 + 32 + num);
							break;
						}
						goto IL_05fb;
					}
					break;
				}
				while (num3 != 46)
				{
					int num24;
					int num18;
					int num8;
					int num14;
					int num9;
					int num21;
					int num13;
					if (num3 == 49)
					{
						num3 = 0;
						if ((int)array[4] != 1)
						{
							num9 = (int)array[6];
							if (num9 == -1)
							{
								num21 = -1;
								num14 = -1;
							}
							else
							{
								num21 = *(int*)(ptr + num9 + 40 + num);
								num14 = *(int*)(ptr + *(int*)(ptr + (int)array[1] + 40 + num) + 32 + num);
							}
							while (true)
							{
								if (num14 != num21)
								{
									num8 = *(int*)(ptr + num14 + 8 + num);
									if (num8 == -1)
									{
										num14 = *(int*)(ptr + num14 + 32 + num);
										continue;
									}
									num18 = *(int*)(ptr + num8 + num);
									array[1] = num8;
									array[0] = 1;
									num2 = *(int*)(ptr + num8 + num);
									break;
								}
								if (num9 != -1)
								{
									Exception ex3 = (Exception)array[2];
									num18 = *(int*)(ptr + num9 + num);
									ex2 = ex3;
									array = (object[])array[3];
									object[] array4 = new object[8];
									array4[4] = 0;
									array4[3] = array;
									array4[2] = ex3;
									array4[1] = num9;
									array4[0] = 2;
									array = array4;
									num2 = *(int*)(ptr + num9 + num);
									break;
								}
								num23 = 1;
								throw ex;
							}
							continue;
						}
						num13 = (int)array[5];
						array = (object[])array[3];
						num24 = num13;
					}
					else
					{
						if (num3 != 51)
						{
							((delegate*<ref int, ref int, ref int, Exception, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref Class8.GunResult, ref string, ref Vector3, ref Quaternion, ref float, ref float, ref int, ref char, ref string, ref bool[][], ref int, ref bool[], ref int, ref Vector3, ref Vector3, ref List<GameEntityCreateData>, ref string[], ref int, ref string, ref int, ref List<(Vector3, Quaternion)>.Enumerator, ref (Vector3, Quaternion), ref GameEntityCreateData, Class123, void>)UnsafeQueueUserWorkItemBinaryArray[num2])(ref num2, ref num3, ref num25, ex2, ref num26, ref num27, ref num28, ref num29, ref num30, ref num31, ref obj3, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref text24, ref text25, ref text26, ref text27, ref text28, ref text29, ref text30, ref text31, ref text32, ref text33, ref text34, ref text35, ref gunResult, ref text36, ref vector, ref quaternion, ref num32, ref num33, ref num34, ref c, ref text37, ref array6, ref num35, ref array7, ref num36, ref vector2, ref vector3, ref list, ref array8, ref num37, ref text38, ref num38, ref enumerator, ref tuple, ref gameEntityCreateData, this);
							continue;
						}
						num3 = 0;
						num8 = num25;
						num24 = num8;
					}
					int num11 = num2;
					num21 = num11;
					num13 = 0;
					int num4 = 2;
					int num7;
					int num6;
					int num5;
					while (true)
					{
						num5 = (num13 + num4) / 2;
						num6 = *(int*)(ptr + 152 + num5 * 48 + 24 + num);
						num7 = *(int*)(ptr + 152 + num5 * 48 + 16 + num);
						if (num21 >= num6 + num7)
						{
							num13 = num5 + 1;
							continue;
						}
						if (num6 <= num21)
						{
							break;
						}
						num4 = num5 - 1;
					}
					num14 = num5;
					num18 = *(int*)(ptr + 152 + num14 * 48 + num);
					int num12 = num18;
					num7 = num24;
					num6 = 0;
					num5 = 2;
					while (true)
					{
						num4 = (num6 + num5) / 2;
						num13 = *(int*)(ptr + 152 + num4 * 48 + 24 + num);
						num21 = *(int*)(ptr + 152 + num4 * 48 + 16 + num);
						if (num7 >= num13 + num21)
						{
							num6 = num4 + 1;
							continue;
						}
						if (num13 <= num7)
						{
							break;
						}
						num5 = num4 - 1;
					}
					num14 = num4;
					num8 = *(int*)(ptr + 152 + num14 * 48 + num);
					num18 = num8;
					num21 = num24;
					num13 = 0;
					num4 = 2;
					while (true)
					{
						num5 = (num13 + num4) / 2;
						num6 = *(int*)(ptr + 296 + num5 * 40 + 16 + num);
						num7 = *(int*)(ptr + 296 + num5 * 40 + 8 + num);
						if (num21 >= num6 + num7)
						{
							num13 = num5 + 1;
							continue;
						}
						if (num6 <= num21)
						{
							break;
						}
						num4 = num5 - 1;
					}
					num14 = num5;
					num9 = *(int*)(ptr + 296 + num14 * 40 + num);
					num8 = num9;
					while (true)
					{
						if (array == null || (int)array[4] == 1)
						{
							num21 = num18;
							while (num21 != num12)
							{
								if (num21 != -1)
								{
									num21 = *(int*)(ptr + num21 + 32 + num);
									continue;
								}
								goto IL_0327;
							}
							num2 = num24;
							break;
						}
						int num39 = (int)array[1];
						int num40;
						if (num12 == -1)
						{
							num40 = -1;
						}
						else
						{
							int num10 = *(int*)(ptr + num12 + num);
							num7 = 0;
							num6 = 2;
							while (true)
							{
								num5 = (num7 + num6) / 2;
								num4 = *(int*)(ptr + 296 + num5 * 40 + 16 + num);
								num13 = *(int*)(ptr + 296 + num5 * 40 + 8 + num);
								if (num10 >= num4 + num13)
								{
									num7 = num5 + 1;
									continue;
								}
								if (num4 <= num10)
								{
									break;
								}
								num6 = num5 - 1;
							}
							num9 = num5;
							num14 = *(int*)(ptr + 296 + num9 * 40 + num);
							num40 = num14;
						}
						if (num39 == num40)
						{
							num14 = num18;
							while (num14 != num12)
							{
								if (num14 != -1)
								{
									num14 = *(int*)(ptr + num14 + 32 + num);
									continue;
								}
								goto IL_0417;
							}
							num2 = num24;
							break;
						}
						if ((int)array[1] != num8)
						{
							array = (object[])array[3];
							continue;
						}
						num2 = num24;
						break;
						IL_0417:
						num9 = *(int*)(ptr + num12 + 8 + num);
						if (num9 == -1)
						{
							num12 = *(int*)(ptr + num12 + 32 + num);
							continue;
						}
						num21 = *(int*)(ptr + num9 + num);
						object[] array4 = new object[8];
						array4[4] = 1;
						array4[3] = array;
						array4[5] = num24;
						array4[1] = num9;
						array4[0] = 1;
						array = array4;
						num2 = *(int*)(ptr + num9 + num);
						break;
						IL_0327:
						num13 = *(int*)(ptr + num12 + 8 + num);
						if (num13 == -1)
						{
							num12 = *(int*)(ptr + num12 + 32 + num);
							continue;
						}
						num4 = *(int*)(ptr + num13 + num);
						array4 = new object[8];
						array4[4] = 1;
						array4[3] = array;
						array4[5] = num24;
						array4[1] = num13;
						array4[0] = 1;
						array = array4;
						num2 = *(int*)(ptr + num13 + num);
						break;
					}
				}
				num3 = 0;
				break;
			}
			catch (Exception ex4)
			{
				if (num23 == 1)
				{
					throw ex4;
				}
				ex = ex4;
				num22 = -1;
				try0013_dispatch = 2376;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 62;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ObjectWithMapAssemIdGetAnonymous.TypeIPersistFile);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_022d:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0210:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0203:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_01f0:
																								if (7 > b)
																								{
																									num = 112;
																									while (true)
																									{
																										if (num != 112)
																										{
																											if (num != 1093)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 46:
																												goto IL_01f0;
																											case 63:
																												goto IL_0203;
																											case 45:
																												goto IL_0210;
																											case 94:
																												goto end_IL_0210;
																											case 3:
																												goto IL_022d;
																											case 17:
																												goto end_IL_022d;
																											case 13:
																											case 83:
																												goto end_IL_023d;
																											case 14:
																												goto IL_0258;
																											case 40:
																												goto IL_0268;
																											case 27:
																											case 41:
																												goto IL_0278;
																											case 2:
																											case 55:
																												goto IL_0288;
																											case 28:
																												goto IL_02a1;
																											case 50:
																												goto IL_02af;
																											case 57:
																												goto IL_02cb;
																											case 21:
																											case 72:
																												goto IL_02f0;
																											case 23:
																												goto IL_02fe;
																											case 16:
																											case 22:
																												goto IL_030c;
																											case 76:
																												goto IL_0328;
																											case 88:
																												goto IL_0338;
																											case 54:
																												goto IL_0342;
																											case 29:
																												goto IL_0350;
																											case 18:
																											case 95:
																												goto IL_0363;
																											case 86:
																												goto IL_03a3;
																											case 32:
																												goto IL_03b7;
																											case 101:
																												goto IL_03ca;
																											case 69:
																												goto IL_03d8;
																											case 15:
																											case 92:
																												goto IL_03e3;
																											case 70:
																												goto IL_03f1;
																											case 26:
																											case 97:
																												goto end_IL_01dd;
																											case 102:
																												goto IL_044f;
																											case 104:
																												goto IL_0462;
																											case 100:
																												goto IL_0476;
																											case 105:
																												goto IL_0489;
																											case 33:
																												goto IL_0494;
																											case 0:
																											case 53:
																												goto IL_04a2;
																											case 12:
																												goto IL_04cb;
																											case 73:
																												goto IL_04d9;
																											case 39:
																												goto IL_04ec;
																											case 47:
																												goto IL_04fa;
																											case 89:
																											case 103:
																												goto IL_0508;
																											case 31:
																												goto IL_0548;
																											case 25:
																												goto IL_0565;
																											case 91:
																												goto IL_0578;
																											case 60:
																												goto IL_0583;
																											case 19:
																											case 58:
																												goto IL_058e;
																											case 99:
																												goto IL_05ce;
																											case 6:
																												goto IL_05e2;
																											case 4:
																											case 24:
																											case 30:
																											case 35:
																											case 36:
																											case 38:
																											case 42:
																											case 43:
																											case 48:
																											case 59:
																											case 64:
																											case 65:
																											case 67:
																											case 68:
																											case 82:
																											case 84:
																											case 85:
																											case 87:
																											case 93:
																											case 96:
																												goto end_IL_021d;
																											case 81:
																												goto IL_0615;
																											case 20:
																												goto IL_0623;
																											case 77:
																												goto IL_0631;
																											case 1:
																											case 5:
																											case 11:
																											case 44:
																											case 51:
																											case 52:
																											case 56:
																											case 74:
																											case 75:
																											case 78:
																											case 79:
																												goto end_IL_024d;
																											case 66:
																												goto end_IL_0648;
																											case 90:
																												goto end_IL_065b;
																											case 10:
																												goto end_IL_0665;
																											case 80:
																												goto end_IL_0670;
																											case 37:
																												goto end_IL_0685;
																											case 8:
																											case 9:
																												goto end_IL_069a;
																											case 71:
																												goto end_IL_06aa;
																											case 7:
																											case 98:
																												goto end_IL_06ba;
																											case 61:
																												goto end_IL_06ca;
																											case 62:
																												goto end_IL_06da;
																											case 34:
																											case 49:
																												goto IL_06f5;
																											}
																											continue;
																										}
																										goto IL_0578;
																										IL_05ce:
																										array[num5 - 2] = 0;
																										goto IL_05e2;
																										IL_05e2:
																										num5--;
																										goto end_IL_024d;
																										IL_0578:
																										if (6 < b)
																										{
																											goto end_IL_021d;
																										}
																										goto IL_0583;
																										IL_0583:
																										if (6 > b)
																										{
																											goto end_IL_021d;
																										}
																										goto IL_058e;
																										IL_058e:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_05ce;
																										continue;
																										end_IL_01dd:
																										break;
																									}
																									break;
																								}
																								goto IL_0288;
																								IL_02af:
																								num5++;
																								num = 102;
																								goto IL_044f;
																								IL_044f:
																								ptr2 += 8;
																								goto end_IL_024d;
																								IL_0288:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_02a1;
																								IL_02a1:
																								array[num5] = 0;
																								goto IL_02af;
																							}
																							break;
																						}
																						goto IL_0268;
																						IL_03b7:
																						num5--;
																						goto end_IL_024d;
																						IL_0268:
																						if (8 < b)
																						{
																							goto IL_02f0;
																						}
																						goto IL_0328;
																						IL_02f0:
																						if (9 < b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_02fe;
																						IL_02fe:
																						if (9 > b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_030c;
																						IL_030c:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_024d;
																						IL_0328:
																						if (8 > b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_0363;
																						IL_0363:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03a3;
																						IL_03a3:
																						array[num5 - 2] = 0;
																						goto IL_03b7;
																					}
																					goto IL_040d;
																				}
																				goto IL_0258;
																				IL_0548:
																				array[num5 - 2] = 0;
																				num = 25;
																				goto IL_0565;
																				IL_0258:
																				if (5 <= b)
																				{
																					goto IL_0278;
																				}
																				goto IL_03ca;
																				IL_0278:
																				array[num5] = 0;
																				goto IL_02cb;
																				IL_02cb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0338;
																				IL_0338:
																				array2[num5] = null;
																				goto IL_0342;
																				IL_0342:
																				num5++;
																				goto IL_0350;
																				IL_0350:
																				ptr2 += 8;
																				goto end_IL_024d;
																				IL_03ca:
																				if (2 >= b)
																				{
																					goto IL_03d8;
																				}
																				goto IL_0489;
																				IL_03d8:
																				if (2 > b)
																				{
																					goto IL_03e3;
																				}
																				goto IL_040d;
																				IL_03e3:
																				if (1 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_03f1;
																				IL_03f1:
																				if (1 > b)
																				{
																					num = 24;
																				}
																				goto end_IL_021d;
																				IL_0565:
																				num5--;
																				goto end_IL_024d;
																				IL_040d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0462;
																				IL_0462:
																				array[num5 - 2] = 0;
																				goto IL_0476;
																				IL_0476:
																				num5--;
																				goto end_IL_024d;
																				IL_0489:
																				if (3 >= b)
																				{
																					goto IL_0494;
																				}
																				goto IL_04ec;
																				IL_0494:
																				if (3 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_04a2;
																				IL_04a2:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04cb;
																				IL_04cb:
																				ptr2 += 8;
																				goto IL_04d9;
																				IL_04d9:
																				num5--;
																				goto end_IL_024d;
																				IL_04ec:
																				if (4 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_04fa;
																				IL_04fa:
																				if (4 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_0508;
																				IL_0508:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0548;
																				continue;
																				end_IL_0210:
																				break;
																			}
																			continue;
																			end_IL_021d:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0615;
																	IL_0631:
																	ptr2 += 8;
																	num = 5;
																	goto end_IL_024d;
																	IL_0623:
																	num5++;
																	goto IL_0631;
																	IL_0615:
																	array[num5] = 0;
																	goto IL_0623;
																	continue;
																	end_IL_022d:
																	break;
																}
																continue;
																end_IL_023d:
																break;
															}
															continue;
															end_IL_024d:
															break;
														}
														continue;
													}
													goto IL_06f5;
													IL_06f5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0648:
													break;
												}
												continue;
												end_IL_065b:
												break;
											}
											continue;
											end_IL_0665:
											break;
										}
										continue;
										end_IL_0670:
										break;
									}
									continue;
									end_IL_0685:
									break;
								}
								continue;
								end_IL_069a:
								break;
							}
							continue;
							end_IL_06aa:
							break;
						}
						continue;
						end_IL_06ba:
						break;
					}
					continue;
					end_IL_06ca:
					break;
				}
				continue;
				end_IL_06da:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 69;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsFamilysetActivator.EventActivityOptionsgetEventSection);
										num = 63;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 82;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 112;
															while (true)
															{
																if (num != 112)
																{
																	if (num != 1093)
																	{
																		goto IL_0420;
																	}
																	switch (num)
																	{
																	case 62:
																		goto end_IL_01cf;
																	case 19:
																		goto IL_01f3;
																	case 100:
																		goto IL_0201;
																	case 80:
																		goto IL_020f;
																	case 24:
																		goto IL_021d;
																	case 21:
																	case 91:
																		goto IL_022b;
																	case 97:
																		goto IL_0239;
																	case 36:
																		goto IL_0247;
																	case 28:
																	case 89:
																		goto IL_0252;
																	case 64:
																		goto IL_0260;
																	case 42:
																	case 53:
																		goto IL_026e;
																	case 86:
																		goto IL_0291;
																	case 54:
																		goto IL_029f;
																	case 10:
																		goto IL_02ad;
																	case 6:
																		goto IL_02c0;
																	case 14:
																	case 33:
																		goto IL_02ce;
																	case 44:
																		goto IL_030e;
																	case 85:
																		goto IL_0322;
																	case 8:
																	case 35:
																		goto IL_033e;
																	case 4:
																		goto IL_03a9;
																	case 87:
																		goto IL_03bc;
																	case 96:
																		goto IL_03c7;
																	case 7:
																	case 38:
																		goto IL_03d5;
																	case 47:
																		goto IL_03f1;
																	case 23:
																		goto IL_03ff;
																	case 2:
																		goto IL_0412;
																	case 15:
																	case 66:
																		goto IL_0420;
																	case 0:
																	case 73:
																		goto IL_042b;
																	case 20:
																		goto IL_0436;
																	case 74:
																	case 105:
																		goto IL_0444;
																	case 5:
																	case 57:
																		goto IL_0465;
																	case 77:
																		goto IL_0473;
																	case 51:
																		goto IL_0486;
																	case 9:
																	case 92:
																		goto IL_0491;
																	case 56:
																		goto IL_049f;
																	case 40:
																	case 41:
																		goto IL_04ad;
																	case 48:
																		goto IL_04c6;
																	case 29:
																		goto IL_04d4;
																	case 55:
																		goto IL_04e2;
																	case 1:
																	case 3:
																		goto IL_04f5;
																	case 103:
																		goto IL_051e;
																	case 46:
																		goto IL_052c;
																	case 50:
																	case 98:
																		goto IL_053c;
																	case 30:
																		goto IL_054a;
																	case 70:
																		goto IL_056d;
																	case 60:
																		goto IL_0580;
																	case 101:
																		goto IL_058e;
																	case 11:
																	case 12:
																	case 16:
																	case 25:
																	case 31:
																	case 32:
																	case 39:
																	case 43:
																	case 52:
																	case 58:
																	case 59:
																	case 61:
																	case 79:
																	case 83:
																	case 84:
																	case 88:
																	case 94:
																	case 99:
																	case 102:
																		goto IL_05a7;
																	case 18:
																	case 26:
																	case 34:
																	case 37:
																	case 49:
																	case 72:
																	case 76:
																	case 78:
																	case 81:
																	case 82:
																	case 93:
																	case 104:
																		goto end_IL_01df;
																	case 67:
																		goto end_IL_05ba;
																	case 63:
																		goto end_IL_05cd;
																	case 45:
																		goto end_IL_05d8;
																	case 90:
																		goto end_IL_05e2;
																	case 27:
																		goto end_IL_05f6;
																	case 17:
																	case 71:
																		goto end_IL_060b;
																	case 65:
																		goto end_IL_061b;
																	case 22:
																	case 95:
																		goto end_IL_062b;
																	case 68:
																		goto end_IL_063b;
																	case 69:
																		goto end_IL_064b;
																	case 13:
																	case 75:
																		goto IL_0666;
																	}
																	continue;
																}
																b = *ptr2;
																goto IL_01f3;
																IL_054a:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_056d;
																IL_0580:
																num5++;
																goto IL_058e;
																IL_056d:
																array2[num5] = null;
																num = 60;
																goto IL_0580;
																IL_01f3:
																ptr2++;
																goto IL_0201;
																IL_0201:
																if (b >= 1)
																{
																	goto IL_020f;
																}
																num = 32;
																goto IL_05a7;
																IL_020f:
																if (b <= 10)
																{
																	goto IL_021d;
																}
																goto IL_05a7;
																IL_021d:
																if (5 < b)
																{
																	goto IL_022b;
																}
																goto IL_0412;
																IL_022b:
																if (8 >= b)
																{
																	goto IL_0239;
																}
																goto IL_03bc;
																IL_0239:
																if (8 > b)
																{
																	goto IL_0247;
																}
																num = 35;
																goto IL_033e;
																IL_0247:
																if (6 < b)
																{
																	goto IL_0252;
																}
																goto IL_02c0;
																IL_0252:
																if (7 >= b)
																{
																	goto IL_0260;
																}
																goto IL_05a7;
																IL_0260:
																if (7 <= b)
																{
																	goto IL_026e;
																}
																goto IL_05a7;
																IL_026e:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0291;
																IL_0291:
																array[num5] = 0;
																goto IL_029f;
																IL_029f:
																num5++;
																goto IL_02ad;
																IL_02ad:
																ptr2 += 8;
																goto end_IL_01df;
																IL_02c0:
																if (6 <= b)
																{
																	goto IL_02ce;
																}
																goto IL_05a7;
																IL_02ce:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_030e;
																IL_030e:
																array[num5 - 2] = 0;
																goto IL_0322;
																IL_0322:
																num5--;
																goto end_IL_01df;
																IL_058e:
																ptr2 += 8;
																goto end_IL_01df;
																IL_033e:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																num = 4;
																goto IL_03a9;
																IL_03a9:
																num5 -= 2;
																goto end_IL_01df;
																IL_03bc:
																if (9 >= b)
																{
																	goto IL_03c7;
																}
																goto IL_03f1;
																IL_03c7:
																if (9 <= b)
																{
																	goto IL_03d5;
																}
																goto IL_05a7;
																IL_03d5:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_01df;
																IL_03f1:
																if (10 >= b)
																{
																	goto IL_03ff;
																}
																goto IL_05a7;
																IL_03ff:
																if (10 > b)
																{
																}
																goto IL_05a7;
																IL_0412:
																if (5 > b)
																{
																	goto IL_0420;
																}
																goto IL_053c;
																IL_0420:
																if (2 < b)
																{
																	goto IL_042b;
																}
																goto IL_0486;
																IL_042b:
																if (3 >= b)
																{
																	goto IL_0436;
																}
																num = 57;
																goto IL_0465;
																IL_0436:
																if (3 <= b)
																{
																	goto IL_0444;
																}
																goto IL_05a7;
																IL_0444:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_01df;
																IL_05a7:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_01df;
																IL_0465:
																if (4 >= b)
																{
																	goto IL_0473;
																}
																goto IL_05a7;
																IL_0473:
																if (4 <= b)
																{
																	goto end_IL_01df;
																}
																goto IL_05a7;
																IL_0486:
																if (2 > b)
																{
																	goto IL_0491;
																}
																goto IL_04f5;
																IL_0491:
																if (1 >= b)
																{
																	goto IL_049f;
																}
																goto IL_05a7;
																IL_049f:
																if (1 <= b)
																{
																	goto IL_04ad;
																}
																goto IL_05a7;
																IL_04ad:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_04c6;
																IL_04c6:
																array[num5] = 0;
																goto IL_04d4;
																IL_04d4:
																num5++;
																goto IL_04e2;
																IL_04e2:
																ptr2 += 8;
																goto end_IL_01df;
																IL_04f5:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_051e;
																IL_051e:
																ptr2 += 8;
																goto IL_052c;
																IL_052c:
																num5--;
																goto end_IL_01df;
																IL_053c:
																array[num5] = 0;
																goto IL_054a;
																continue;
																end_IL_01cf:
																break;
															}
															continue;
															end_IL_01df:
															break;
														}
														continue;
													}
													goto IL_0666;
													IL_0666:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05ba:
													break;
												}
												continue;
												end_IL_05cd:
												break;
											}
											continue;
											end_IL_05d8:
											break;
										}
										continue;
										end_IL_05e2:
										break;
									}
									continue;
									end_IL_05f6:
									break;
								}
								continue;
								end_IL_060b:
								break;
							}
							continue;
							end_IL_061b:
							break;
						}
						continue;
						end_IL_062b:
						break;
					}
					continue;
					end_IL_063b:
					break;
				}
				continue;
				end_IL_064b:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 5;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 13;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CrossAppDomainDelegateCheckTypeSecurity.getASCIIgetExternalProcessMgmt);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_025c:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_023c:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_022c:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_021f:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_020f:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												num = 111;
																												while (true)
																												{
																													if (num != 111)
																													{
																														if (num != 1092)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 101:
																															goto IL_01ec;
																														case 51:
																														case 102:
																															goto IL_01ff;
																														case 17:
																															goto IL_020f;
																														case 41:
																															goto IL_021f;
																														case 6:
																														case 84:
																															goto IL_022c;
																														case 89:
																															goto IL_023c;
																														case 9:
																															goto IL_024c;
																														case 100:
																															goto IL_025c;
																														case 38:
																															goto end_IL_025c;
																														case 59:
																														case 86:
																															goto end_IL_026c;
																														case 31:
																														case 82:
																															goto IL_0287;
																														case 81:
																															goto IL_02e9;
																														case 87:
																															goto IL_02fc;
																														case 56:
																															goto IL_031f;
																														case 92:
																															goto IL_032d;
																														case 67:
																															goto IL_0344;
																														case 93:
																															goto IL_0357;
																														case 32:
																														case 35:
																															goto IL_0365;
																														case 43:
																															goto IL_03a5;
																														case 14:
																															goto IL_03b9;
																														case 50:
																															goto IL_03cc;
																														case 72:
																														case 76:
																															goto IL_03d7;
																														case 16:
																															goto IL_03e5;
																														case 18:
																															goto IL_03f8;
																														case 22:
																														case 90:
																															goto IL_0406;
																														case 39:
																															goto IL_042b;
																														case 61:
																															goto IL_0439;
																														case 11:
																															goto IL_0447;
																														case 28:
																															goto IL_0452;
																														case 30:
																															goto IL_0460;
																														case 23:
																														case 27:
																															goto IL_046e;
																														case 73:
																															goto IL_0487;
																														case 79:
																															goto IL_049e;
																														case 91:
																															goto IL_04ac;
																														case 12:
																														case 88:
																															goto IL_04c8;
																														case 96:
																															goto IL_04f1;
																														case 65:
																															goto IL_04ff;
																														case 80:
																														case 95:
																															goto IL_0512;
																														case 29:
																															goto IL_0526;
																														case 42:
																														case 62:
																															goto IL_0534;
																														case 7:
																															goto IL_054c;
																														case 71:
																															goto IL_0557;
																														case 20:
																														case 47:
																															goto end_IL_01d9;
																														case 66:
																															goto IL_057b;
																														case 36:
																															goto IL_059e;
																														case 78:
																															goto IL_05a8;
																														case 74:
																															goto IL_05b6;
																														case 3:
																														case 8:
																														case 10:
																														case 15:
																														case 21:
																														case 26:
																														case 34:
																														case 37:
																														case 44:
																														case 48:
																														case 53:
																														case 54:
																														case 60:
																														case 63:
																														case 64:
																														case 68:
																														case 75:
																														case 77:
																														case 94:
																														case 98:
																															goto end_IL_01ec;
																														case 1:
																														case 24:
																														case 25:
																														case 33:
																														case 40:
																														case 45:
																														case 52:
																														case 55:
																														case 57:
																														case 69:
																														case 83:
																														case 97:
																														case 104:
																															goto end_IL_027c;
																														case 46:
																															goto end_IL_05d9;
																														case 103:
																															goto end_IL_05ec;
																														case 13:
																															goto end_IL_05f6;
																														case 0:
																															goto end_IL_0601;
																														case 49:
																														case 70:
																															goto end_IL_0616;
																														case 99:
																															goto end_IL_062f;
																														case 19:
																														case 85:
																															goto end_IL_063f;
																														case 4:
																															goto end_IL_064f;
																														case 5:
																															goto end_IL_065f;
																														case 2:
																														case 58:
																															goto IL_067a;
																														}
																														continue;
																													}
																													goto IL_02fc;
																													IL_032d:
																													num5++;
																													num = 67;
																													goto IL_0344;
																													IL_0344:
																													ptr2 += 8;
																													goto end_IL_027c;
																													IL_02fc:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_031f;
																													IL_031f:
																													array[num5] = 0;
																													goto IL_032d;
																													continue;
																													end_IL_01d9:
																													break;
																												}
																												goto IL_056d;
																												continue;
																												end_IL_01ec:
																												break;
																												IL_01ec:;
																											}
																											break;
																											IL_01ff:;
																										}
																										break;
																									}
																									goto IL_0357;
																									IL_03b9:
																									num5--;
																									goto end_IL_027c;
																									IL_0357:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_0365;
																									IL_0365:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03a5;
																									IL_03a5:
																									array[num5 - 2] = 0;
																									goto IL_03b9;
																								}
																								break;
																							}
																							goto IL_0287;
																							IL_02e9:
																							num5 -= 2;
																							goto end_IL_027c;
																							IL_0287:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_02e9;
																						}
																						break;
																					}
																					goto IL_03cc;
																					IL_0406:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					num = 25;
																					goto end_IL_027c;
																					IL_03cc:
																					if (9 < b)
																					{
																						goto IL_03d7;
																					}
																					goto IL_03f8;
																					IL_03d7:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_03e5;
																					IL_03e5:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_03f8:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0406;
																				}
																				break;
																			}
																			goto IL_042b;
																			IL_057b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_059e;
																			IL_042b:
																			if (5 > b)
																			{
																				goto IL_0439;
																			}
																			num = 47;
																			goto IL_056d;
																			IL_0439:
																			if (2 >= b)
																			{
																				goto IL_0447;
																			}
																			goto IL_0512;
																			IL_0447:
																			if (2 > b)
																			{
																				goto IL_0452;
																			}
																			num = 12;
																			goto IL_04c8;
																			IL_0452:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0460;
																			IL_0460:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_046e;
																			IL_046e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0487;
																			IL_0487:
																			array[num5] = 0;
																			num = 79;
																			goto IL_049e;
																			IL_049e:
																			num5++;
																			goto IL_04ac;
																			IL_04ac:
																			ptr2 += 8;
																			goto end_IL_027c;
																			IL_05a8:
																			num5++;
																			goto IL_05b6;
																			IL_04c8:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04f1;
																			IL_04f1:
																			ptr2 += 8;
																			goto IL_04ff;
																			IL_04ff:
																			num5--;
																			goto end_IL_027c;
																			IL_0512:
																			if (3 >= b)
																			{
																				num = 29;
																				goto IL_0526;
																			}
																			goto IL_054c;
																			IL_05b6:
																			ptr2 += 8;
																			goto end_IL_027c;
																			IL_0526:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0534;
																			IL_0534:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_027c;
																			IL_054c:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0557;
																			IL_0557:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_027c;
																			IL_059e:
																			array2[num5] = null;
																			goto IL_05a8;
																			IL_056d:
																			array[num5] = 0;
																			goto IL_057b;
																		}
																		break;
																		IL_024c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_027c;
																continue;
																end_IL_025c:
																break;
															}
															continue;
															end_IL_026c:
															break;
														}
														continue;
														end_IL_027c:
														break;
													}
													continue;
												}
												goto IL_067a;
												IL_067a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05d9:
												break;
											}
											continue;
											end_IL_05ec:
											break;
										}
										continue;
										end_IL_05f6:
										break;
									}
									continue;
									end_IL_0601:
									break;
								}
								continue;
								end_IL_0616:
								break;
							}
							continue;
							end_IL_062f:
							break;
						}
						continue;
						end_IL_063f:
						break;
					}
					continue;
					end_IL_064f:
					break;
				}
				continue;
				end_IL_065f:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 51;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ManifestFlagsIBindableIterator.GuidParseThrowStyleOther);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03b5:
														byte b = *ptr2;
														while (true)
														{
															IL_039c:
															ptr2++;
															num = 22;
															while (true)
															{
																IL_038c:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_036c:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_035c:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_034c:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_033f:
																									if (10 < b)
																									{
																										while (11 >= b)
																										{
																											while (11 <= b)
																											{
																												while (true)
																												{
																													IL_02d9:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																													while (true)
																													{
																														IL_02c3:
																														array[num5 - 2] = 0;
																														while (true)
																														{
																															IL_02aa:
																															num5--;
																															num = 162;
																															while (num != 162)
																															{
																																if (num != 1143)
																																{
																																	goto IL_07eb;
																																}
																																switch (num)
																																{
																																case 34:
																																	goto IL_02aa;
																																case 116:
																																	goto IL_02c3;
																																case 66:
																																case 93:
																																	goto IL_02d9;
																																case 32:
																																	goto IL_031f;
																																case 91:
																																case 97:
																																	goto IL_032f;
																																case 57:
																																case 122:
																																	goto IL_033f;
																																case 18:
																																	goto IL_034c;
																																case 45:
																																case 86:
																																	goto IL_035c;
																																case 130:
																																	goto IL_036c;
																																case 6:
																																	goto IL_037c;
																																case 22:
																																	goto IL_038c;
																																case 129:
																																	goto IL_039c;
																																case 81:
																																case 100:
																																	goto IL_03b5;
																																case 0:
																																	goto IL_03c0;
																																case 90:
																																case 115:
																																	goto IL_03cb;
																																case 109:
																																	goto IL_03d9;
																																case 4:
																																case 118:
																																	goto IL_03ec;
																																case 5:
																																	goto IL_03fa;
																																case 148:
																																	goto IL_041d;
																																case 127:
																																	goto IL_0427;
																																case 152:
																																	goto IL_0435;
																																case 83:
																																case 138:
																																	goto IL_0448;
																																case 96:
																																	goto IL_0491;
																																case 64:
																																	goto IL_04a5;
																																case 59:
																																case 70:
																																	goto IL_04b8;
																																case 9:
																																case 36:
																																	goto IL_04c3;
																																case 49:
																																	goto IL_04d1;
																																case 87:
																																	goto IL_04e4;
																																case 132:
																																case 153:
																																	goto IL_04f2;
																																case 123:
																																	goto IL_0500;
																																case 72:
																																case 137:
																																	goto IL_050e;
																																case 71:
																																	goto IL_0570;
																																case 68:
																																case 142:
																																	goto IL_0583;
																																case 143:
																																	goto IL_059f;
																																case 99:
																																	goto IL_05ad;
																																case 54:
																																	goto IL_05bb;
																																case 133:
																																case 140:
																																	goto IL_05c9;
																																case 41:
																																	goto IL_05d7;
																																case 114:
																																case 139:
																																	goto IL_05e2;
																																case 126:
																																	goto IL_05f0;
																																case 94:
																																case 128:
																																	goto IL_05fe;
																																case 37:
																																	goto IL_0617;
																																case 85:
																																	goto IL_0625;
																																case 21:
																																	goto IL_0633;
																																case 19:
																																case 25:
																																	goto IL_0646;
																																case 117:
																																	goto IL_068f;
																																case 52:
																																	goto IL_06a3;
																																case 98:
																																	goto IL_06b6;
																																case 23:
																																	goto IL_06c4;
																																case 92:
																																case 95:
																																	goto IL_06d2;
																																case 67:
																																	goto IL_06fb;
																																case 33:
																																case 42:
																																	goto IL_0714;
																																case 46:
																																	goto IL_0732;
																																case 35:
																																	goto IL_0740;
																																case 44:
																																	goto IL_0753;
																																case 27:
																																case 84:
																																	goto IL_075e;
																																case 62:
																																	goto IL_076c;
																																case 2:
																																case 77:
																																	goto IL_077a;
																																case 12:
																																	goto IL_07a3;
																																case 131:
																																	goto IL_07b1;
																																case 1:
																																	goto IL_07c4;
																																case 55:
																																case 147:
																																	goto IL_07cf;
																																case 136:
																																	goto IL_07dd;
																																case 75:
																																case 110:
																																	goto IL_07eb;
																																case 24:
																																	goto IL_07f9;
																																case 17:
																																	goto IL_0811;
																																case 79:
																																	goto IL_081f;
																																case 20:
																																case 135:
																																	goto IL_082f;
																																case 73:
																																	goto IL_086e;
																																case 56:
																																case 155:
																																	goto IL_087e;
																																case 3:
																																case 8:
																																case 11:
																																case 13:
																																case 26:
																																case 28:
																																case 29:
																																case 38:
																																case 43:
																																case 47:
																																case 58:
																																case 61:
																																case 63:
																																case 78:
																																case 80:
																																case 82:
																																case 101:
																																case 103:
																																case 104:
																																case 107:
																																case 111:
																																case 113:
																																case 119:
																																case 120:
																																case 124:
																																case 141:
																																case 144:
																																case 145:
																																case 146:
																																case 149:
																																case 150:
																																	goto end_IL_031f;
																																case 7:
																																case 10:
																																case 14:
																																case 15:
																																case 16:
																																case 30:
																																case 31:
																																case 39:
																																case 48:
																																case 65:
																																case 89:
																																case 105:
																																case 106:
																																case 108:
																																case 121:
																																case 134:
																																case 154:
																																	goto end_IL_0297;
																																case 112:
																																	goto end_IL_08a6;
																																case 53:
																																	goto end_IL_08b9;
																																case 74:
																																	goto end_IL_08c3;
																																case 88:
																																	goto end_IL_08ce;
																																case 40:
																																case 76:
																																	goto end_IL_08de;
																																case 69:
																																	goto end_IL_08ee;
																																case 125:
																																case 151:
																																	goto end_IL_08fe;
																																case 50:
																																	goto end_IL_090e;
																																case 51:
																																	goto end_IL_091e;
																																case 60:
																																case 102:
																																	goto IL_0939;
																																}
																																continue;
																																end_IL_0297:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto end_IL_038c;
																												continue;
																												end_IL_031f:
																												break;
																												IL_031f:;
																											}
																											break;
																											IL_032f:;
																										}
																										break;
																									}
																									goto IL_03c0;
																									IL_0435:
																									ptr2 += 8;
																									goto end_IL_038c;
																									IL_03c0:
																									if (10 > b)
																									{
																										goto IL_03cb;
																									}
																									goto IL_03ec;
																									IL_03cb:
																									if (9 < b)
																									{
																										break;
																									}
																									goto IL_03d9;
																									IL_03d9:
																									if (9 <= b)
																									{
																										goto end_IL_038c;
																									}
																									break;
																									IL_03ec:
																									array[num5] = 0;
																									goto IL_03fa;
																									IL_03fa:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_041d;
																									IL_041d:
																									array2[num5] = null;
																									goto IL_0427;
																									IL_0427:
																									num5++;
																									goto IL_0435;
																								}
																								break;
																							}
																							goto IL_0448;
																							IL_04a5:
																							num5--;
																							goto end_IL_038c;
																							IL_0448:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 96;
																							goto IL_0491;
																							IL_0491:
																							array[num5 - 2] = 0;
																							goto IL_04a5;
																						}
																						break;
																					}
																					goto IL_04b8;
																					IL_0583:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_038c;
																					IL_04b8:
																					if (14 < b)
																					{
																						goto IL_04c3;
																					}
																					goto IL_04e4;
																					IL_04c3:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_04d1;
																					IL_04d1:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_04e4:
																					if (14 > b)
																					{
																						goto IL_04f2;
																					}
																					goto IL_0583;
																					IL_04f2:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_0500;
																					IL_0500:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_050e;
																					IL_050e:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0570;
																					IL_0570:
																					num5 -= 2;
																					goto end_IL_038c;
																				}
																				break;
																			}
																			goto IL_059f;
																			IL_087e:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_038c;
																			IL_059f:
																			if (8 > b)
																			{
																				goto IL_05ad;
																			}
																			goto IL_087e;
																			IL_05ad:
																			if (4 >= b)
																			{
																				goto IL_05bb;
																			}
																			goto IL_0753;
																			IL_05bb:
																			if (4 > b)
																			{
																				goto IL_05c9;
																			}
																			goto IL_0714;
																			IL_05c9:
																			if (2 >= b)
																			{
																				goto IL_05d7;
																			}
																			goto IL_06b6;
																			IL_05d7:
																			if (2 > b)
																			{
																				goto IL_05e2;
																			}
																			goto IL_0646;
																			IL_05e2:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_05f0;
																			IL_05f0:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_05fe;
																			IL_05fe:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0617;
																			IL_0617:
																			array[num5] = 0;
																			goto IL_0625;
																			IL_0625:
																			num5++;
																			goto IL_0633;
																			IL_0633:
																			ptr2 += 8;
																			goto end_IL_038c;
																			IL_0646:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 117;
																			goto IL_068f;
																			IL_068f:
																			array[num5 - 2] = 0;
																			goto IL_06a3;
																			IL_06a3:
																			num5--;
																			goto end_IL_038c;
																			IL_06b6:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_06c4;
																			IL_06c4:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_06d2;
																			IL_06d2:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06fb;
																			IL_06fb:
																			array[num5 - 1] = 5;
																			goto end_IL_038c;
																			IL_0714:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0732;
																			IL_0732:
																			ptr2 += 8;
																			goto IL_0740;
																			IL_0740:
																			num5--;
																			goto end_IL_038c;
																			IL_0753:
																			if (6 < b)
																			{
																				goto IL_075e;
																			}
																			goto IL_07c4;
																			IL_075e:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_076c;
																			IL_076c:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_077a;
																			IL_077a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07a3;
																			IL_07a3:
																			ptr2 += 8;
																			goto IL_07b1;
																			IL_07b1:
																			num5--;
																			goto end_IL_038c;
																			IL_07c4:
																			if (6 > b)
																			{
																				goto IL_07cf;
																			}
																			goto IL_082f;
																			IL_07cf:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_07dd;
																			IL_07dd:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_07eb;
																			IL_07eb:
																			array[num5] = 5;
																			goto IL_07f9;
																			IL_07f9:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0811;
																			IL_0811:
																			num5++;
																			goto IL_081f;
																			IL_081f:
																			ptr2 += 8;
																			goto end_IL_038c;
																			IL_082f:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_086e;
																			IL_086e:
																			num5 -= 3;
																			goto end_IL_038c;
																		}
																		break;
																		IL_037c:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_038c:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0939;
												IL_0939:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a6:
												break;
											}
											continue;
											end_IL_08b9:
											break;
										}
										continue;
										end_IL_08c3:
										break;
									}
									continue;
									end_IL_08ce:
									break;
								}
								continue;
								end_IL_08de:
								break;
							}
							continue;
							end_IL_08ee:
							break;
						}
						continue;
						end_IL_08fe:
						break;
					}
					continue;
					end_IL_090e:
					break;
				}
				continue;
				end_IL_091e:
				break;
			}
		}
	}

	public Class123()
	{
		object obj = this;
		List<(Vector3, Quaternion)> list = new List<(Vector3, Quaternion)>();
		((Class123)obj).list_0 = list;
	}

	private unsafe void method_0()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0491, IL_04a4, IL_04b7, IL_04c7, IL_04d7, IL_04e7, IL_04f7, IL_0507, IL_0514, IL_0524, IL_0534, IL_0544, IL_054f, IL_055a, IL_0565, IL_0578, IL_0586, IL_0594, IL_05a7, IL_05b0, IL_05ee, IL_0601, IL_0614, IL_0622, IL_0630, IL_063e, IL_0651, IL_0697, IL_06af, IL_06bd, IL_06cb, IL_06de, IL_06ec, IL_0753, IL_0761, IL_0774, IL_0791, IL_07e0, IL_07ea, IL_0817, IL_082b, IL_0839, IL_084c, IL_085a, IL_0868, IL_08a8, IL_08bc, IL_08cf, IL_08da, IL_08f3, IL_0901, IL_090f, IL_0922, IL_0935, IL_0949, IL_095c, IL_096a, IL_0978, IL_0990, IL_09ae, IL_09d2, IL_09ea, IL_09fd, IL_0a0b, IL_0a19, IL_0a27, IL_0a3f, IL_0a52, IL_0a60, IL_0a6e, IL_0a7c, IL_0a87, IL_0ac7, IL_0adb, IL_0aee, IL_0afc, IL_0b0a, IL_0b2c, IL_0b3a, IL_0b48, IL_0b5b, IL_0b69, IL_0b77, IL_0b80, IL_0ba9, IL_0bb7, IL_0bd3, IL_0bea, IL_0c0d, IL_0c20, IL_0c2e, IL_0c41, IL_0c4f, IL_0c5a, IL_0c9a, IL_0cae, IL_0cc1, IL_0ccf, IL_0cdd, IL_0d1d, IL_0d31, IL_0d44, IL_0d52, IL_0d5b, IL_0d69, IL_0da9, IL_0dbd, IL_0dd0, IL_0dde, IL_0df2, IL_0e2a, IL_0e3d, IL_0e66, IL_0e7f, IL_0e92, IL_0eb0, IL_0ebe, IL_0ed1, IL_0ee4, IL_0ef2, IL_0f0a, IL_0f18, IL_0f23, IL_0f4c, IL_0f5a, IL_0f6d, IL_0f7b, IL_0f89, IL_0fdb, IL_0fee, IL_0ffc, IL_100a, IL_1035, IL_104e, IL_105c, IL_1067, IL_107b, IL_10ba, IL_10cd, IL_10d8, IL_10e6, IL_10f4, IL_110d, IL_111b, IL_1129, IL_113c, IL_1147, IL_1150, IL_1179, IL_1187, IL_119a, IL_11a8, IL_11b6, IL_11f7, IL_120b, IL_121e, IL_122c, IL_1237, IL_124b, IL_128a, IL_129d, IL_12ab, IL_12b4, IL_12c2, IL_1302, IL_1316, IL_1326, IL_1331, IL_133c, IL_1349, IL_1352, IL_135d, IL_1376, IL_1392, IL_13a5, IL_13af, IL_13ba, IL_13d3, IL_13e3, IL_13f3, IL_1403, IL_141c, IL_142c, IL_143c, IL_144c, IL_145c are reachable both inside and outside the pinned region starting at IL_1471. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 186;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef37 = default(int);
			ref int reference = ref __rxRef37;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_145c:
					num2 = 1;
					while (true)
					{
						IL_144c:
						num3 = num2 * 4;
						while (true)
						{
							IL_143c:
							num4 = num2 * 8;
							while (true)
							{
								IL_142c:
								array2 = new byte[4];
								while (true)
								{
									IL_141c:
									array3 = new object[4];
									while (true)
									{
										IL_1403:
										array4 = new int[4];
										num = 246;
										while (true)
										{
											IL_13f3:
											array5 = new int[7];
											while (true)
											{
												IL_13e3:
												array6 = new long[4];
												while (true)
												{
													IL_13d3:
													array7 = new object[13];
													while (true)
													{
														IL_13ba:
														array7[0] = this;
														num = 272;
														while (true)
														{
															IL_13af:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSSCHEMAVERSIONVgetRefusedSet.getAvailableWaitHandlegetResponseXmlNamespace);
															while (true)
															{
																IL_13a5:
																ptr2 = ptr;
																while (true)
																{
																	IL_1392:
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0544:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0534:
																			ptr2++;
																			while (true)
																			{
																				IL_0524:
																				if (b >= 1)
																				{
																					while (b <= 33)
																					{
																						while (true)
																						{
																							IL_0507:
																							if (17 < b)
																							{
																								while (true)
																								{
																									IL_04f7:
																									if (25 >= b)
																									{
																										while (true)
																										{
																											IL_04e7:
																											if (25 > b)
																											{
																												while (true)
																												{
																													IL_04d7:
																													if (21 >= b)
																													{
																														while (true)
																														{
																															IL_04c7:
																															if (21 > b)
																															{
																																while (true)
																																{
																																	IL_04b7:
																																	if (19 < b)
																																	{
																																		while (20 >= b)
																																		{
																																			num = 285;
																																			while (true)
																																			{
																																				if (num != 285)
																																				{
																																					if (num != 1266)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 186:
																																						break;
																																					default:
																																						continue;
																																					case 122:
																																						goto IL_04a4;
																																					case 138:
																																						goto IL_04b7;
																																					case 23:
																																						goto IL_04c7;
																																					case 95:
																																						goto IL_04d7;
																																					case 132:
																																						goto IL_04e7;
																																					case 254:
																																						goto IL_04f7;
																																					case 4:
																																						goto IL_0507;
																																					case 157:
																																						goto IL_0514;
																																					case 219:
																																						goto IL_0524;
																																					case 216:
																																						goto IL_0534;
																																					case 80:
																																					case 166:
																																						goto IL_0544;
																																					case 125:
																																						goto IL_054f;
																																					case 19:
																																						goto IL_055a;
																																					case 52:
																																						goto IL_0565;
																																					case 65:
																																						goto IL_0578;
																																					case 24:
																																						goto IL_0586;
																																					case 30:
																																						goto IL_0594;
																																					case 47:
																																					case 104:
																																						goto IL_05b0;
																																					case 153:
																																						goto IL_05ee;
																																					case 120:
																																					case 159:
																																						goto IL_0601;
																																					case 164:
																																						goto IL_0614;
																																					case 131:
																																						goto IL_0622;
																																					case 67:
																																						goto IL_0630;
																																					case 56:
																																						goto IL_063e;
																																					case 100:
																																					case 169:
																																						goto IL_0651;
																																					case 130:
																																					case 170:
																																						goto IL_0697;
																																					case 116:
																																						goto IL_06af;
																																					case 119:
																																						goto IL_06bd;
																																					case 14:
																																						goto IL_06cb;
																																					case 205:
																																						goto IL_06de;
																																					case 2:
																																					case 33:
																																						goto IL_06ec;
																																					case 212:
																																						goto IL_0753;
																																					case 88:
																																						goto IL_0761;
																																					case 148:
																																					case 224:
																																						goto IL_0774;
																																					case 41:
																																						goto IL_082b;
																																					case 5:
																																						goto IL_0839;
																																					case 227:
																																						goto IL_084c;
																																					case 86:
																																						goto IL_085a;
																																					case 106:
																																					case 207:
																																						goto IL_0868;
																																					case 62:
																																						goto IL_08a8;
																																					case 118:
																																						goto IL_08bc;
																																					case 228:
																																						goto IL_08cf;
																																					case 81:
																																					case 173:
																																						goto IL_08da;
																																					case 45:
																																						goto IL_08f3;
																																					case 9:
																																						goto IL_0901;
																																					case 110:
																																						goto IL_090f;
																																					case 48:
																																						goto IL_0922;
																																					case 249:
																																						goto IL_0935;
																																					case 54:
																																						goto IL_0949;
																																					case 252:
																																						goto IL_095c;
																																					case 174:
																																						goto IL_096a;
																																					case 55:
																																					case 152:
																																						goto IL_0978;
																																					case 44:
																																						goto IL_0990;
																																					case 188:
																																						goto IL_09ae;
																																					case 71:
																																						goto IL_09d2;
																																					case 83:
																																						goto IL_09ea;
																																					case 237:
																																						goto IL_09fd;
																																					case 58:
																																						goto IL_0a0b;
																																					case 34:
																																					case 117:
																																						goto IL_0a19;
																																					case 250:
																																						goto IL_0a27;
																																					case 135:
																																						goto IL_0a3f;
																																					case 269:
																																						goto IL_0a52;
																																					case 70:
																																						goto IL_0a60;
																																					case 229:
																																						goto IL_0a6e;
																																					case 63:
																																						goto IL_0a7c;
																																					case 92:
																																					case 171:
																																						goto IL_0a87;
																																					case 179:
																																						goto IL_0ac7;
																																					case 260:
																																						goto IL_0adb;
																																					case 165:
																																						goto IL_0aee;
																																					case 267:
																																						goto IL_0afc;
																																					case 82:
																																					case 202:
																																						goto IL_0b0a;
																																					case 244:
																																						goto IL_0b2c;
																																					case 255:
																																						goto IL_0b3a;
																																					case 15:
																																						goto IL_0b48;
																																					case 3:
																																						goto IL_0b5b;
																																					case 264:
																																						goto IL_0b69;
																																					case 85:
																																					case 177:
																																						goto IL_0b80;
																																					case 142:
																																						goto IL_0ba9;
																																					case 223:
																																						goto IL_0bb7;
																																					case 134:
																																					case 261:
																																						goto IL_0bd3;
																																					case 114:
																																						goto IL_0bea;
																																					case 233:
																																						goto IL_0c0d;
																																					case 42:
																																						goto IL_0c20;
																																					case 68:
																																						goto IL_0c2e;
																																					case 57:
																																						goto IL_0c41;
																																					case 209:
																																						goto IL_0c4f;
																																					case 178:
																																					case 190:
																																						goto IL_0c5a;
																																					case 198:
																																						goto IL_0c9a;
																																					case 156:
																																						goto IL_0cae;
																																					case 10:
																																						goto IL_0cc1;
																																					case 72:
																																						goto IL_0ccf;
																																					case 99:
																																					case 121:
																																						goto IL_0cdd;
																																					case 38:
																																						goto IL_0d1d;
																																					case 203:
																																						goto IL_0d31;
																																					case 113:
																																						goto IL_0d44;
																																					case 235:
																																						goto IL_0d5b;
																																					case 172:
																																					case 218:
																																						goto IL_0d69;
																																					case 140:
																																						goto IL_0da9;
																																					case 193:
																																						goto IL_0dbd;
																																					case 271:
																																						goto IL_0dd0;
																																					case 43:
																																					case 239:
																																						goto IL_0dde;
																																					case 213:
																																						goto IL_0df2;
																																					case 231:
																																						goto IL_0e2a;
																																					case 76:
																																					case 273:
																																						goto IL_0e3d;
																																					case 189:
																																						goto IL_0e66;
																																					case 274:
																																						goto IL_0e7f;
																																					case 128:
																																					case 275:
																																						goto IL_0e92;
																																					case 154:
																																						goto IL_0eb0;
																																					case 268:
																																						goto IL_0ebe;
																																					case 277:
																																						goto IL_0ed1;
																																					case 75:
																																					case 266:
																																						goto IL_0ef2;
																																					case 141:
																																						goto IL_0f0a;
																																					case 241:
																																						goto IL_0f18;
																																					case 28:
																																					case 230:
																																						goto IL_0f23;
																																					case 111:
																																						goto IL_0f4c;
																																					case 74:
																																						goto IL_0f5a;
																																					case 215:
																																						goto IL_0f6d;
																																					case 232:
																																						goto IL_0f7b;
																																					case 84:
																																					case 262:
																																						goto IL_0f89;
																																					case 144:
																																						goto IL_0fdb;
																																					case 211:
																																						goto IL_0fee;
																																					case 49:
																																						goto IL_0ffc;
																																					case 97:
																																					case 107:
																																						goto IL_100a;
																																					case 29:
																																						goto IL_1035;
																																					case 32:
																																						goto IL_104e;
																																					case 16:
																																						goto IL_105c;
																																					case 8:
																																					case 27:
																																						goto IL_1067;
																																					case 37:
																																						goto IL_107b;
																																					case 197:
																																						goto IL_10ba;
																																					case 248:
																																						goto IL_10cd;
																																					case 35:
																																						goto IL_10d8;
																																					case 143:
																																						goto IL_10e6;
																																					case 13:
																																					case 126:
																																						goto IL_10f4;
																																					case 276:
																																						goto IL_110d;
																																					case 192:
																																						goto IL_111b;
																																					case 59:
																																						goto IL_1129;
																																					case 251:
																																						goto IL_113c;
																																					case 36:
																																					case 195:
																																						goto IL_1150;
																																					case 50:
																																						goto IL_1179;
																																					case 214:
																																						goto IL_1187;
																																					case 105:
																																						goto IL_119a;
																																					case 149:
																																						goto IL_11a8;
																																					case 87:
																																					case 167:
																																						goto IL_11b6;
																																					case 151:
																																						goto IL_11f7;
																																					case 7:
																																						goto IL_120b;
																																					case 91:
																																						goto IL_121e;
																																					case 191:
																																						goto IL_122c;
																																					case 108:
																																					case 136:
																																						goto IL_1237;
																																					case 77:
																																						goto IL_124b;
																																					case 187:
																																						goto IL_128a;
																																					case 161:
																																						goto IL_129d;
																																					case 39:
																																						goto IL_12b4;
																																					case 73:
																																					case 263:
																																						goto IL_12c2;
																																					case 40:
																																						goto IL_1302;
																																					case 256:
																																						goto IL_1316;
																																					case 245:
																																						goto IL_1326;
																																					case 124:
																																						goto end_IL_0491;
																																					case 25:
																																						goto IL_133c;
																																					case 168:
																																						goto IL_1352;
																																					case 123:
																																					case 176:
																																						goto IL_135d;
																																					case 6:
																																					case 11:
																																					case 18:
																																					case 20:
																																					case 22:
																																					case 46:
																																					case 60:
																																					case 64:
																																					case 94:
																																					case 96:
																																					case 102:
																																					case 112:
																																					case 129:
																																					case 133:
																																					case 137:
																																					case 139:
																																					case 145:
																																					case 146:
																																					case 150:
																																					case 162:
																																					case 163:
																																					case 180:
																																					case 181:
																																					case 183:
																																					case 184:
																																					case 196:
																																					case 210:
																																					case 220:
																																					case 221:
																																					case 238:
																																					case 240:
																																					case 247:
																																					case 257:
																																					case 265:
																																					case 270:
																																					case 278:
																																						goto end_IL_04a4;
																																					case 0:
																																					case 1:
																																					case 17:
																																					case 21:
																																					case 31:
																																					case 51:
																																					case 53:
																																					case 61:
																																					case 66:
																																					case 69:
																																					case 79:
																																					case 89:
																																					case 90:
																																					case 93:
																																					case 98:
																																					case 101:
																																					case 103:
																																					case 109:
																																					case 115:
																																					case 155:
																																					case 158:
																																					case 160:
																																					case 175:
																																					case 182:
																																					case 194:
																																					case 199:
																																					case 201:
																																					case 204:
																																					case 206:
																																					case 225:
																																					case 226:
																																					case 236:
																																					case 242:
																																					case 243:
																																					case 253:
																																					case 259:
																																						goto IL_1392;
																																					case 222:
																																						goto IL_13a5;
																																					case 272:
																																						goto IL_13af;
																																					case 127:
																																						goto IL_13ba;
																																					case 12:
																																						goto IL_13d3;
																																					case 217:
																																						goto IL_13e3;
																																					case 246:
																																						goto IL_13f3;
																																					case 200:
																																						goto IL_1403;
																																					case 78:
																																						goto IL_141c;
																																					case 234:
																																						goto IL_142c;
																																					case 208:
																																						goto IL_143c;
																																					case 26:
																																						goto IL_144c;
																																					case 185:
																																						goto IL_145c;
																																					case 147:
																																					case 258:
																																						return;
																																					}
																																					goto end_IL_0524;
																																				}
																																				if (20 > b)
																																				{
																																					goto end_IL_04a4;
																																				}
																																				goto IL_0ef2;
																																				IL_0ef2:
																																				ptr2 = ptr + *(int*)(ptr2 + num3);
																																				goto IL_1392;
																																				continue;
																																				end_IL_0491:
																																				break;
																																			}
																																			goto IL_1331;
																																			continue;
																																			end_IL_04a4:
																																			break;
																																			IL_04a4:;
																																		}
																																		break;
																																	}
																																	goto IL_08cf;
																																	IL_0e2a:
																																	ptr2 += 8;
																																	goto IL_1392;
																																	IL_08cf:
																																	if (19 <= b)
																																	{
																																		goto IL_08da;
																																	}
																																	goto IL_0922;
																																	IL_08da:
																																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																																	goto IL_08f3;
																																	IL_08f3:
																																	array2[num6] = 1;
																																	goto IL_0901;
																																	IL_0901:
																																	num6++;
																																	goto IL_090f;
																																	IL_090f:
																																	ptr2 += 16;
																																	goto IL_1392;
																																	IL_0922:
																																	if (18 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0dd0;
																																	IL_0dd0:
																																	if (18 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0dde;
																																	IL_0dde:
																																	array2[num6 - 1] = 5;
																																	goto IL_0df2;
																																	IL_0df2:
																																	array3[num6 - 1] = ((delegate*<string[], string>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																																	goto IL_0e2a;
																																}
																																break;
																															}
																															goto IL_0651;
																															IL_0949:
																															num6--;
																															goto IL_1392;
																															IL_0651:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																															goto IL_0935;
																															IL_0935:
																															array2[num6 - 2] = 0;
																															goto IL_0949;
																														}
																														break;
																													}
																													goto IL_0f0a;
																													IL_1035:
																													array2[num6 - 1] = 0;
																													goto IL_1392;
																													IL_0f0a:
																													if (23 >= b)
																													{
																														goto IL_0f18;
																													}
																													goto IL_0fee;
																													IL_0f18:
																													if (23 <= b)
																													{
																														goto IL_0f23;
																													}
																													goto IL_0f6d;
																													IL_0f23:
																													((delegate*<string, void>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																													goto IL_0f4c;
																													IL_0f4c:
																													num6--;
																													goto IL_0f5a;
																													IL_0f5a:
																													ptr2 += 8;
																													goto IL_1392;
																													IL_0f6d:
																													if (22 < b)
																													{
																														break;
																													}
																													goto IL_0f7b;
																													IL_0f7b:
																													if (22 > b)
																													{
																														break;
																													}
																													goto IL_0f89;
																													IL_0f89:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0fdb;
																													IL_0fdb:
																													num6--;
																													goto IL_1392;
																													IL_0fee:
																													if (24 < b)
																													{
																														break;
																													}
																													goto IL_0ffc;
																													IL_0ffc:
																													if (24 > b)
																													{
																														break;
																													}
																													goto IL_100a;
																													IL_100a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_1035;
																												}
																												break;
																											}
																											goto IL_0697;
																											IL_06cb:
																											ptr2 += 8;
																											goto IL_1392;
																											IL_0697:
																											array3[num6] = array7[*(int*)(ptr2 + num3)];
																											goto IL_06af;
																											IL_06af:
																											array2[num6] = 5;
																											goto IL_06bd;
																											IL_06bd:
																											num6++;
																											goto IL_06cb;
																										}
																										break;
																									}
																									goto IL_104e;
																									IL_133c:
																									if (33 > b)
																									{
																									}
																									break;
																									IL_104e:
																									if (29 >= b)
																									{
																										goto IL_105c;
																									}
																									goto IL_121e;
																									IL_105c:
																									if (29 <= b)
																									{
																										goto IL_1067;
																									}
																									goto IL_10cd;
																									IL_1067:
																									array2[num6 - 1] = 3;
																									goto IL_107b;
																									IL_107b:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_10ba;
																									IL_10ba:
																									ptr2 += 8;
																									goto IL_1392;
																									IL_10cd:
																									if (27 < b)
																									{
																										goto IL_10d8;
																									}
																									goto IL_113c;
																									IL_10d8:
																									if (28 < b)
																									{
																										break;
																									}
																									goto IL_10e6;
																									IL_10e6:
																									if (28 > b)
																									{
																										break;
																									}
																									goto IL_10f4;
																									IL_10f4:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																									goto IL_110d;
																									IL_110d:
																									array2[num6] = 3;
																									goto IL_111b;
																									IL_111b:
																									num6++;
																									goto IL_1129;
																									IL_1129:
																									ptr2 += 16;
																									goto IL_1392;
																									IL_113c:
																									if (27 <= b)
																									{
																										num = 195;
																										goto IL_1150;
																									}
																									goto IL_119a;
																									IL_135d:
																									num7 = ptr2;
																									num8 = -200;
																									num5 = 1;
																									ptr2 = num7 + num8;
																									goto IL_1392;
																									IL_1150:
																									((delegate*<List<(Vector3, Quaternion)>, void>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((List<(Vector3, Quaternion)>)array3[num6 - 1]);
																									goto IL_1179;
																									IL_1179:
																									num6--;
																									goto IL_1187;
																									IL_1187:
																									ptr2 += 8;
																									goto IL_1392;
																									IL_119a:
																									if (26 < b)
																									{
																										break;
																									}
																									goto IL_11a8;
																									IL_11a8:
																									if (26 > b)
																									{
																										break;
																									}
																									goto IL_11b6;
																									IL_11b6:
																									array3[num6 - 1] = ((delegate*<Class123, List<(Vector3, Quaternion)>>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((Class123)array3[num6 - 1]);
																									num = 151;
																									goto IL_11f7;
																									IL_11f7:
																									array2[num6 - 1] = 5;
																									goto IL_120b;
																									IL_120b:
																									ptr2 += 8;
																									goto IL_1392;
																									IL_121e:
																									if (31 >= b)
																									{
																										goto IL_122c;
																									}
																									goto IL_1326;
																									IL_122c:
																									if (31 <= b)
																									{
																										goto IL_1237;
																									}
																									goto IL_129d;
																									IL_1237:
																									array2[num6 - 1] = 0;
																									goto IL_124b;
																									IL_124b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																									goto IL_128a;
																									IL_128a:
																									ptr2 += 8;
																									goto IL_1392;
																									IL_129d:
																									if (30 < b)
																									{
																										break;
																									}
																									num = 39;
																									goto IL_12b4;
																									IL_1352:
																									if (32 > b)
																									{
																										break;
																									}
																									goto IL_135d;
																									IL_12b4:
																									if (30 > b)
																									{
																										break;
																									}
																									goto IL_12c2;
																									IL_12c2:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_1302;
																									IL_1302:
																									array2[num6 - 2] = 3;
																									goto IL_1316;
																									IL_1316:
																									num6--;
																									goto IL_1392;
																									IL_1326:
																									if (32 < b)
																									{
																										goto IL_1331;
																									}
																									num = 168;
																									goto IL_1352;
																									IL_1331:
																									if (33 < b)
																									{
																										break;
																									}
																									goto IL_133c;
																								}
																								break;
																							}
																							goto IL_054f;
																							IL_05b0:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_05ee;
																							IL_054f:
																							if (17 > b)
																							{
																								goto IL_055a;
																							}
																							num = 104;
																							goto IL_05b0;
																							IL_055a:
																							if (8 >= b)
																							{
																								goto IL_0565;
																							}
																							goto IL_0578;
																							IL_0565:
																							if (8 <= b)
																							{
																								goto IL_0601;
																							}
																							goto IL_0a52;
																							IL_0601:
																							num6--;
																							goto IL_1392;
																							IL_0a52:
																							if (4 >= b)
																							{
																								goto IL_0a60;
																							}
																							goto IL_0c41;
																							IL_0a60:
																							if (4 > b)
																							{
																								goto IL_0a6e;
																							}
																							goto IL_0bd3;
																							IL_0a6e:
																							if (2 >= b)
																							{
																								goto IL_0a7c;
																							}
																							goto IL_0b5b;
																							IL_0a7c:
																							if (2 <= b)
																							{
																								goto IL_0a87;
																							}
																							goto IL_0aee;
																							IL_0a87:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0ac7;
																							IL_0ac7:
																							array2[num6 - 2] = 0;
																							goto IL_0adb;
																							IL_0adb:
																							num6--;
																							goto IL_1392;
																							IL_0aee:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0afc;
																							IL_0afc:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0b0a;
																							IL_0b0a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							num = 244;
																							goto IL_0b2c;
																							IL_0b2c:
																							array2[num6] = 0;
																							goto IL_0b3a;
																							IL_0b3a:
																							num6++;
																							goto IL_0b48;
																							IL_0b48:
																							ptr2 += 8;
																							goto IL_1392;
																							IL_0b5b:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0b69;
																							IL_0b69:
																							if (3 > b)
																							{
																								break;
																							}
																							num = 177;
																							goto IL_0b80;
																							IL_082b:
																							array2[num6] = 5;
																							goto IL_0839;
																							IL_0b80:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0ba9;
																							IL_0ba9:
																							ptr2 += 8;
																							goto IL_0bb7;
																							IL_0bb7:
																							num6--;
																							num = 115;
																							goto IL_1392;
																							IL_0bd3:
																							array2[num6] = 0;
																							num = 114;
																							goto IL_0bea;
																							IL_0bea:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0c0d;
																							IL_0c0d:
																							array3[num6] = null;
																							num = 42;
																							goto IL_0c20;
																							IL_0c20:
																							num6++;
																							goto IL_0c2e;
																							IL_0c2e:
																							ptr2 += 8;
																							goto IL_1392;
																							IL_0c41:
																							if (6 >= b)
																							{
																								goto IL_0c4f;
																							}
																							goto IL_0d44;
																							IL_0c4f:
																							if (6 <= b)
																							{
																								goto IL_0c5a;
																							}
																							goto IL_0cc1;
																							IL_0c5a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0c9a;
																							IL_0c9a:
																							array2[num6 - 2] = 0;
																							goto IL_0cae;
																							IL_0cae:
																							num6--;
																							goto IL_1392;
																							IL_0cc1:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0ccf;
																							IL_0ccf:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0cdd;
																							IL_0cdd:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0d1d;
																							IL_0d1d:
																							array2[num6 - 2] = 0;
																							goto IL_0d31;
																							IL_0d31:
																							num6--;
																							goto IL_1392;
																							IL_0d44:
																							if (7 < b)
																							{
																								break;
																							}
																							num = 235;
																							goto IL_0d5b;
																							IL_0839:
																							num6++;
																							goto IL_1392;
																							IL_0d5b:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0d69;
																							IL_0d69:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0da9;
																							IL_0da9:
																							array2[num6 - 2] = 0;
																							goto IL_0dbd;
																							IL_0dbd:
																							num6--;
																							goto IL_1392;
																							IL_0578:
																							if (12 < b)
																							{
																								goto IL_0586;
																							}
																							goto IL_0614;
																							IL_0586:
																							if (14 >= b)
																							{
																								goto IL_0594;
																							}
																							goto IL_095c;
																							IL_0594:
																							if (14 > b)
																							{
																								goto IL_0753;
																							}
																							goto IL_0e3d;
																							IL_0e3d:
																							array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_0e66;
																							IL_0e66:
																							array2[num6 - 1] = 5;
																							goto IL_1392;
																							IL_0753:
																							if (13 < b)
																							{
																								break;
																							}
																							goto IL_0761;
																							IL_0761:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_0e92;
																							IL_0e92:
																							array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																							goto IL_0eb0;
																							IL_0eb0:
																							ptr2 += 8;
																							goto IL_0ebe;
																							IL_0ebe:
																							num6--;
																							goto IL_1392;
																							IL_095c:
																							if (15 >= b)
																							{
																								goto IL_096a;
																							}
																							goto IL_09fd;
																							IL_096a:
																							if (15 > b)
																							{
																								break;
																							}
																							goto IL_0978;
																							IL_0978:
																							array2[num6] = array2[num6 - 1];
																							goto IL_0990;
																							IL_0990:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_09ae;
																							IL_09ae:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_09d2;
																							IL_09d2:
																							array3[num6] = array3[num6 - 1];
																							goto IL_09ea;
																							IL_09ea:
																							num6++;
																							goto IL_1392;
																							IL_09fd:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_0a0b;
																							IL_0a0b:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_0a19;
																							IL_0a19:
																							array2[num6] = 5;
																							goto IL_0a27;
																							IL_0a27:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_0a3f;
																							IL_0a3f:
																							num6++;
																							goto IL_0e7f;
																							IL_0e7f:
																							ptr2 += 8;
																							goto IL_1392;
																							IL_0614:
																							if (12 > b)
																							{
																								goto IL_0622;
																							}
																							goto IL_0774;
																							IL_0622:
																							if (10 < b)
																							{
																								goto IL_0630;
																							}
																							goto IL_06de;
																							IL_0630:
																							if (11 < b)
																							{
																								break;
																							}
																							goto IL_063e;
																							IL_063e:
																							if (11 > b)
																							{
																								break;
																							}
																							goto IL_1392;
																							IL_06de:
																							if (10 <= b)
																							{
																								goto IL_06ec;
																							}
																							goto IL_084c;
																							IL_06ec:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0ed1;
																							IL_0ed1:
																							num6 -= 2;
																							goto IL_1392;
																							IL_084c:
																							if (9 < b)
																							{
																								break;
																							}
																							goto IL_085a;
																							IL_085a:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_0868;
																							IL_0868:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_08a8;
																							IL_08a8:
																							array2[num6 - 2] = 0;
																							goto IL_08bc;
																							IL_08bc:
																							num6--;
																							goto IL_1392;
																							IL_0774:
																							array8 = array3;
																							num9 = num6;
																							if (array == null)
																							{
																								goto IL_0783;
																							}
																							num10 = ptr2;
																							byte b2 = *num10;
																							ptr2 = num10 + 4;
																							int num11 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num11;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_082b;
																							IL_05ee:
																							num6 -= 3;
																							goto IL_1392;
																						}
																						break;
																						IL_0514:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 17;
																				goto IL_1392;
																				continue;
																				end_IL_0524:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0783:
			while (true)
			{
				IL_0783_2:
				array = new byte[4];
				while (true)
				{
					IL_0791:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						while (true)
						{
							IL_0839_2:
							num6++;
							while (true)
							{
								IL_1392_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0524_2:
											if (b >= 1)
											{
												while (b <= 33)
												{
													while (true)
													{
														IL_0507_2:
														if (17 < b)
														{
															while (true)
															{
																IL_04f7_2:
																if (25 >= b)
																{
																	while (true)
																	{
																		IL_04e7_2:
																		if (25 > b)
																		{
																			while (true)
																			{
																				IL_04d7_2:
																				if (21 >= b)
																				{
																					while (true)
																					{
																						IL_04c7_2:
																						if (21 > b)
																						{
																							while (true)
																							{
																								IL_04b7_2:
																								if (19 < b)
																								{
																									while (20 >= b)
																									{
																										num = 285;
																										while (true)
																										{
																											if (num != 285)
																											{
																												if (num != 1266)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 122:
																													goto IL_04a4_2;
																												case 138:
																													goto IL_04b7_2;
																												case 23:
																													goto IL_04c7_2;
																												case 95:
																													goto IL_04d7_2;
																												case 132:
																													goto IL_04e7_2;
																												case 254:
																													goto IL_04f7_2;
																												case 4:
																													goto IL_0507_2;
																												case 157:
																													goto IL_0514_2;
																												case 219:
																													goto IL_0524_2;
																												case 216:
																													goto end_IL_0524_2;
																												case 80:
																												case 166:
																													goto end_IL_0534;
																												case 125:
																													goto IL_054f_2;
																												case 19:
																													goto IL_055a_2;
																												case 52:
																													goto IL_0565_2;
																												case 65:
																													goto IL_0578_2;
																												case 24:
																													goto IL_0586_2;
																												case 30:
																													goto IL_0594_2;
																												case 47:
																												case 104:
																													goto IL_05b0_2;
																												case 153:
																													goto IL_05ee_2;
																												case 120:
																												case 159:
																													goto IL_0601_2;
																												case 164:
																													goto IL_0614_2;
																												case 131:
																													goto IL_0622_2;
																												case 67:
																													goto IL_0630_2;
																												case 56:
																													goto IL_063e_2;
																												case 100:
																												case 169:
																													goto IL_0651_2;
																												case 130:
																												case 170:
																													goto IL_0697_2;
																												case 116:
																													goto IL_06af_2;
																												case 119:
																													goto IL_06bd_2;
																												case 14:
																													goto IL_06cb_2;
																												case 205:
																													goto IL_06de_2;
																												case 2:
																												case 33:
																													goto IL_06ec_2;
																												case 212:
																													goto IL_0753_2;
																												case 88:
																													goto IL_0761_2;
																												case 148:
																												case 224:
																													goto IL_0774_2;
																												case 41:
																													goto end_IL_0544;
																												case 5:
																													goto IL_0839_2;
																												case 227:
																													goto IL_084c_2;
																												case 86:
																													goto IL_085a_2;
																												case 106:
																												case 207:
																													goto IL_0868_2;
																												case 62:
																													goto IL_08a8_2;
																												case 118:
																													goto IL_08bc_2;
																												case 228:
																													goto IL_08cf_2;
																												case 81:
																												case 173:
																													goto IL_08da_2;
																												case 45:
																													goto IL_08f3_2;
																												case 9:
																													goto IL_0901_2;
																												case 110:
																													goto IL_090f_2;
																												case 48:
																													goto IL_0922_2;
																												case 249:
																													goto IL_0935_2;
																												case 54:
																													goto IL_0949_2;
																												case 252:
																													goto IL_095c_2;
																												case 174:
																													goto IL_096a_2;
																												case 55:
																												case 152:
																													goto IL_0978_2;
																												case 44:
																													goto IL_0990_2;
																												case 188:
																													goto IL_09ae_2;
																												case 71:
																													goto IL_09d2_2;
																												case 83:
																													goto IL_09ea_2;
																												case 237:
																													goto IL_09fd_2;
																												case 58:
																													goto IL_0a0b_2;
																												case 34:
																												case 117:
																													goto IL_0a19_2;
																												case 250:
																													goto IL_0a27_2;
																												case 135:
																													goto IL_0a3f_2;
																												case 269:
																													goto IL_0a52_2;
																												case 70:
																													goto IL_0a60_2;
																												case 229:
																													goto IL_0a6e_2;
																												case 63:
																													goto IL_0a7c_2;
																												case 92:
																												case 171:
																													goto IL_0a87_2;
																												case 179:
																													goto IL_0ac7_2;
																												case 260:
																													goto IL_0adb_2;
																												case 165:
																													goto IL_0aee_2;
																												case 267:
																													goto IL_0afc_2;
																												case 82:
																												case 202:
																													goto IL_0b0a_2;
																												case 244:
																													goto IL_0b2c_2;
																												case 255:
																													goto IL_0b3a_2;
																												case 15:
																													goto IL_0b48_2;
																												case 3:
																													goto IL_0b5b_2;
																												case 264:
																													goto IL_0b69_2;
																												case 85:
																												case 177:
																													goto IL_0b80_2;
																												case 142:
																													goto IL_0ba9_2;
																												case 223:
																													goto IL_0bb7_2;
																												case 134:
																												case 261:
																													goto IL_0bd3_2;
																												case 114:
																													goto IL_0bea_2;
																												case 233:
																													goto IL_0c0d_2;
																												case 42:
																													goto IL_0c20_2;
																												case 68:
																													goto IL_0c2e_2;
																												case 57:
																													goto IL_0c41_2;
																												case 209:
																													goto IL_0c4f_2;
																												case 178:
																												case 190:
																													goto IL_0c5a_2;
																												case 198:
																													goto IL_0c9a_2;
																												case 156:
																													goto IL_0cae_2;
																												case 10:
																													goto IL_0cc1_2;
																												case 72:
																													goto IL_0ccf_2;
																												case 99:
																												case 121:
																													goto IL_0cdd_2;
																												case 38:
																													goto IL_0d1d_2;
																												case 203:
																													goto IL_0d31_2;
																												case 113:
																													goto IL_0d44_2;
																												case 235:
																													goto IL_0d5b_2;
																												case 172:
																												case 218:
																													goto IL_0d69_2;
																												case 140:
																													goto IL_0da9_2;
																												case 193:
																													goto IL_0dbd_2;
																												case 271:
																													goto IL_0dd0_2;
																												case 43:
																												case 239:
																													goto IL_0dde_2;
																												case 213:
																													goto IL_0df2_2;
																												case 231:
																													goto IL_0e2a_2;
																												case 76:
																												case 273:
																													goto IL_0e3d_2;
																												case 189:
																													goto IL_0e66_2;
																												case 274:
																													goto IL_0e7f_2;
																												case 128:
																												case 275:
																													goto IL_0e92_2;
																												case 154:
																													goto IL_0eb0_2;
																												case 268:
																													goto IL_0ebe_2;
																												case 277:
																													goto IL_0ed1_2;
																												case 75:
																												case 266:
																													goto IL_0ef2_2;
																												case 141:
																													goto IL_0f0a_2;
																												case 241:
																													goto IL_0f18_2;
																												case 28:
																												case 230:
																													goto IL_0f23_2;
																												case 111:
																													goto IL_0f4c_2;
																												case 74:
																													goto IL_0f5a_2;
																												case 215:
																													goto IL_0f6d_2;
																												case 232:
																													goto IL_0f7b_2;
																												case 84:
																												case 262:
																													goto IL_0f89_2;
																												case 144:
																													goto IL_0fdb_2;
																												case 211:
																													goto IL_0fee_2;
																												case 49:
																													goto IL_0ffc_2;
																												case 97:
																												case 107:
																													goto IL_100a_2;
																												case 29:
																													goto IL_1035_2;
																												case 32:
																													goto IL_104e_2;
																												case 16:
																													goto IL_105c_2;
																												case 8:
																												case 27:
																													goto IL_1067_2;
																												case 37:
																													goto IL_107b_2;
																												case 197:
																													goto IL_10ba_2;
																												case 248:
																													goto IL_10cd_2;
																												case 35:
																													goto IL_10d8_2;
																												case 143:
																													goto IL_10e6_2;
																												case 13:
																												case 126:
																													goto IL_10f4_2;
																												case 276:
																													goto IL_110d_2;
																												case 192:
																													goto IL_111b_2;
																												case 59:
																													goto IL_1129_2;
																												case 251:
																													goto IL_113c_2;
																												case 36:
																												case 195:
																													goto IL_1150_2;
																												case 50:
																													goto IL_1179_2;
																												case 214:
																													goto IL_1187_2;
																												case 105:
																													goto IL_119a_2;
																												case 149:
																													goto IL_11a8_2;
																												case 87:
																												case 167:
																													goto IL_11b6_2;
																												case 151:
																													goto IL_11f7_2;
																												case 7:
																													goto IL_120b_2;
																												case 91:
																													goto IL_121e_2;
																												case 191:
																													goto IL_122c_2;
																												case 108:
																												case 136:
																													goto IL_1237_2;
																												case 77:
																													goto IL_124b_2;
																												case 187:
																													goto IL_128a_2;
																												case 161:
																													goto IL_129d_2;
																												case 39:
																													goto IL_12b4_2;
																												case 73:
																												case 263:
																													goto IL_12c2_2;
																												case 40:
																													goto IL_1302_2;
																												case 256:
																													goto IL_1316_2;
																												case 245:
																													goto IL_1326_2;
																												case 124:
																													goto end_IL_0491_2;
																												case 25:
																													goto IL_133c_2;
																												case 168:
																													goto IL_1352_2;
																												case 123:
																												case 176:
																													goto IL_135d_2;
																												case 6:
																												case 11:
																												case 18:
																												case 20:
																												case 22:
																												case 46:
																												case 60:
																												case 64:
																												case 94:
																												case 96:
																												case 102:
																												case 112:
																												case 129:
																												case 133:
																												case 137:
																												case 139:
																												case 145:
																												case 146:
																												case 150:
																												case 162:
																												case 163:
																												case 180:
																												case 181:
																												case 183:
																												case 184:
																												case 196:
																												case 210:
																												case 220:
																												case 221:
																												case 238:
																												case 240:
																												case 247:
																												case 257:
																												case 265:
																												case 270:
																												case 278:
																													goto end_IL_04a4_2;
																												case 0:
																												case 1:
																												case 17:
																												case 21:
																												case 31:
																												case 51:
																												case 53:
																												case 61:
																												case 66:
																												case 69:
																												case 79:
																												case 89:
																												case 90:
																												case 93:
																												case 98:
																												case 101:
																												case 103:
																												case 109:
																												case 115:
																												case 155:
																												case 158:
																												case 160:
																												case 175:
																												case 182:
																												case 194:
																												case 199:
																												case 201:
																												case 204:
																												case 206:
																												case 225:
																												case 226:
																												case 236:
																												case 242:
																												case 243:
																												case 253:
																												case 259:
																													goto IL_1392_2;
																												case 222:
																													ptr2 = ptr;
																													goto IL_1392_2;
																												case 272:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSSCHEMAVERSIONVgetRefusedSet.getAvailableWaitHandlegetResponseXmlNamespace);
																													goto case 222;
																												case 127:
																													array7[0] = this;
																													num = 272;
																													goto case 272;
																												case 12:
																													array7 = new object[13];
																													goto case 127;
																												case 217:
																													array6 = new long[4];
																													goto case 12;
																												case 246:
																													array5 = new int[7];
																													goto case 217;
																												case 200:
																													array4 = new int[4];
																													num = 246;
																													goto case 246;
																												case 78:
																													array3 = new object[4];
																													goto case 200;
																												case 234:
																													array2 = new byte[4];
																													goto case 78;
																												case 208:
																													num4 = num2 * 8;
																													goto case 234;
																												case 26:
																													num3 = num2 * 4;
																													goto case 208;
																												case 185:
																													num2 = 1;
																													goto case 26;
																												case 186:
																													goto end_IL_082b;
																												case 147:
																												case 258:
																													return;
																												}
																												continue;
																											}
																											if (20 > b)
																											{
																												goto end_IL_04a4_2;
																											}
																											goto IL_0ef2_2;
																											IL_0ef2_2:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto IL_1392_2;
																											continue;
																											end_IL_0491_2:
																											break;
																										}
																										goto IL_1331_2;
																										continue;
																										end_IL_04a4_2:
																										break;
																										IL_04a4_2:;
																									}
																									break;
																								}
																								goto IL_08cf_2;
																								IL_0e2a_2:
																								ptr2 += 8;
																								goto IL_1392_2;
																								IL_08cf_2:
																								if (19 <= b)
																								{
																									goto IL_08da_2;
																								}
																								goto IL_0922_2;
																								IL_08da_2:
																								*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																								goto IL_08f3_2;
																								IL_08f3_2:
																								array2[num6] = 1;
																								goto IL_0901_2;
																								IL_0901_2:
																								num6++;
																								goto IL_090f_2;
																								IL_090f_2:
																								ptr2 += 16;
																								goto IL_1392_2;
																								IL_0922_2:
																								if (18 < b)
																								{
																									break;
																								}
																								goto IL_0dd0_2;
																								IL_0dd0_2:
																								if (18 > b)
																								{
																									break;
																								}
																								goto IL_0dde_2;
																								IL_0dde_2:
																								array2[num6 - 1] = 5;
																								goto IL_0df2_2;
																								IL_0df2_2:
																								array3[num6 - 1] = ((delegate*<string[], string>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																								goto IL_0e2a_2;
																							}
																							break;
																						}
																						goto IL_0651_2;
																						IL_0949_2:
																						num6--;
																						goto IL_1392_2;
																						IL_0651_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_0935_2;
																						IL_0935_2:
																						array2[num6 - 2] = 0;
																						goto IL_0949_2;
																					}
																					break;
																				}
																				goto IL_0f0a_2;
																				IL_1035_2:
																				array2[num6 - 1] = 0;
																				goto IL_1392_2;
																				IL_0f0a_2:
																				if (23 >= b)
																				{
																					goto IL_0f18_2;
																				}
																				goto IL_0fee_2;
																				IL_0f18_2:
																				if (23 <= b)
																				{
																					goto IL_0f23_2;
																				}
																				goto IL_0f6d_2;
																				IL_0f23_2:
																				((delegate*<string, void>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																				goto IL_0f4c_2;
																				IL_0f4c_2:
																				num6--;
																				goto IL_0f5a_2;
																				IL_0f5a_2:
																				ptr2 += 8;
																				goto IL_1392_2;
																				IL_0f6d_2:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_0f7b_2;
																				IL_0f7b_2:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_0f89_2;
																				IL_0f89_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0fdb_2;
																				IL_0fdb_2:
																				num6--;
																				goto IL_1392_2;
																				IL_0fee_2:
																				if (24 < b)
																				{
																					break;
																				}
																				goto IL_0ffc_2;
																				IL_0ffc_2:
																				if (24 > b)
																				{
																					break;
																				}
																				goto IL_100a_2;
																				IL_100a_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_1035_2;
																			}
																			break;
																		}
																		goto IL_0697_2;
																		IL_06cb_2:
																		ptr2 += 8;
																		goto IL_1392_2;
																		IL_0697_2:
																		array3[num6] = array7[*(int*)(ptr2 + num3)];
																		goto IL_06af_2;
																		IL_06af_2:
																		array2[num6] = 5;
																		goto IL_06bd_2;
																		IL_06bd_2:
																		num6++;
																		goto IL_06cb_2;
																	}
																	break;
																}
																goto IL_104e_2;
																IL_133c_2:
																if (33 > b)
																{
																}
																break;
																IL_104e_2:
																if (29 >= b)
																{
																	goto IL_105c_2;
																}
																goto IL_121e_2;
																IL_105c_2:
																if (29 <= b)
																{
																	goto IL_1067_2;
																}
																goto IL_10cd_2;
																IL_1067_2:
																array2[num6 - 1] = 3;
																goto IL_107b_2;
																IL_107b_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_10ba_2;
																IL_10ba_2:
																ptr2 += 8;
																goto IL_1392_2;
																IL_10cd_2:
																if (27 < b)
																{
																	goto IL_10d8_2;
																}
																goto IL_113c_2;
																IL_10d8_2:
																if (28 < b)
																{
																	break;
																}
																goto IL_10e6_2;
																IL_10e6_2:
																if (28 > b)
																{
																	break;
																}
																goto IL_10f4_2;
																IL_10f4_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																goto IL_110d_2;
																IL_110d_2:
																array2[num6] = 3;
																goto IL_111b_2;
																IL_111b_2:
																num6++;
																goto IL_1129_2;
																IL_1129_2:
																ptr2 += 16;
																goto IL_1392_2;
																IL_113c_2:
																if (27 <= b)
																{
																	num = 195;
																	goto IL_1150_2;
																}
																goto IL_119a_2;
																IL_135d_2:
																num7 = ptr2;
																num8 = -200;
																num5 = 1;
																ptr2 = num7 + num8;
																goto IL_1392_2;
																IL_1150_2:
																((delegate*<List<(Vector3, Quaternion)>, void>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((List<(Vector3, Quaternion)>)array3[num6 - 1]);
																goto IL_1179_2;
																IL_1179_2:
																num6--;
																goto IL_1187_2;
																IL_1187_2:
																ptr2 += 8;
																goto IL_1392_2;
																IL_119a_2:
																if (26 < b)
																{
																	break;
																}
																goto IL_11a8_2;
																IL_11a8_2:
																if (26 > b)
																{
																	break;
																}
																goto IL_11b6_2;
																IL_11b6_2:
																array3[num6 - 1] = ((delegate*<Class123, List<(Vector3, Quaternion)>>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])((Class123)array3[num6 - 1]);
																num = 151;
																goto IL_11f7_2;
																IL_11f7_2:
																array2[num6 - 1] = 5;
																goto IL_120b_2;
																IL_120b_2:
																ptr2 += 8;
																goto IL_1392_2;
																IL_121e_2:
																if (31 >= b)
																{
																	goto IL_122c_2;
																}
																goto IL_1326_2;
																IL_122c_2:
																if (31 <= b)
																{
																	goto IL_1237_2;
																}
																goto IL_129d_2;
																IL_1237_2:
																array2[num6 - 1] = 0;
																goto IL_124b_2;
																IL_124b_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)MethodImplAttributePeekChar[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_128a_2;
																IL_128a_2:
																ptr2 += 8;
																goto IL_1392_2;
																IL_129d_2:
																if (30 < b)
																{
																	break;
																}
																num = 39;
																goto IL_12b4_2;
																IL_1352_2:
																if (32 > b)
																{
																	break;
																}
																goto IL_135d_2;
																IL_12b4_2:
																if (30 > b)
																{
																	break;
																}
																goto IL_12c2_2;
																IL_12c2_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_1302_2;
																IL_1302_2:
																array2[num6 - 2] = 3;
																goto IL_1316_2;
																IL_1316_2:
																num6--;
																goto IL_1392_2;
																IL_1326_2:
																if (32 < b)
																{
																	goto IL_1331_2;
																}
																num = 168;
																goto IL_1352_2;
																IL_1331_2:
																if (33 < b)
																{
																	break;
																}
																goto IL_133c_2;
															}
															break;
														}
														goto IL_054f_2;
														IL_0774_2:
														array8 = array3;
														num9 = num6;
														if (array == null)
														{
															goto IL_0783_2;
														}
														goto IL_0791;
														IL_054f_2:
														if (17 > b)
														{
															goto IL_055a_2;
														}
														num = 104;
														goto IL_05b0_2;
														IL_055a_2:
														if (8 >= b)
														{
															goto IL_0565_2;
														}
														goto IL_0578_2;
														IL_0565_2:
														if (8 <= b)
														{
															goto IL_0601_2;
														}
														goto IL_0a52_2;
														IL_0601_2:
														num6--;
														goto IL_1392_2;
														IL_0a52_2:
														if (4 >= b)
														{
															goto IL_0a60_2;
														}
														goto IL_0c41_2;
														IL_0a60_2:
														if (4 > b)
														{
															goto IL_0a6e_2;
														}
														goto IL_0bd3_2;
														IL_0a6e_2:
														if (2 >= b)
														{
															goto IL_0a7c_2;
														}
														goto IL_0b5b_2;
														IL_0a7c_2:
														if (2 <= b)
														{
															goto IL_0a87_2;
														}
														goto IL_0aee_2;
														IL_0a87_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0ac7_2;
														IL_0ac7_2:
														array2[num6 - 2] = 0;
														goto IL_0adb_2;
														IL_0adb_2:
														num6--;
														goto IL_1392_2;
														IL_0aee_2:
														if (1 < b)
														{
															break;
														}
														goto IL_0afc_2;
														IL_0afc_2:
														if (1 > b)
														{
															break;
														}
														goto IL_0b0a_2;
														IL_0b0a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														num = 244;
														goto IL_0b2c_2;
														IL_0b2c_2:
														array2[num6] = 0;
														goto IL_0b3a_2;
														IL_0b3a_2:
														num6++;
														goto IL_0b48_2;
														IL_0b48_2:
														ptr2 += 8;
														goto IL_1392_2;
														IL_0b5b_2:
														if (3 < b)
														{
															break;
														}
														goto IL_0b69_2;
														IL_0b69_2:
														if (3 > b)
														{
															break;
														}
														num = 177;
														goto IL_0b80_2;
														IL_05b0_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_05ee_2;
														IL_0b80_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0ba9_2;
														IL_0ba9_2:
														ptr2 += 8;
														goto IL_0bb7_2;
														IL_0bb7_2:
														num6--;
														num = 115;
														goto IL_1392_2;
														IL_0bd3_2:
														array2[num6] = 0;
														num = 114;
														goto IL_0bea_2;
														IL_0bea_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0c0d_2;
														IL_0c0d_2:
														array3[num6] = null;
														num = 42;
														goto IL_0c20_2;
														IL_0c20_2:
														num6++;
														goto IL_0c2e_2;
														IL_0c2e_2:
														ptr2 += 8;
														goto IL_1392_2;
														IL_0c41_2:
														if (6 >= b)
														{
															goto IL_0c4f_2;
														}
														goto IL_0d44_2;
														IL_0c4f_2:
														if (6 <= b)
														{
															goto IL_0c5a_2;
														}
														goto IL_0cc1_2;
														IL_0c5a_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0c9a_2;
														IL_0c9a_2:
														array2[num6 - 2] = 0;
														goto IL_0cae_2;
														IL_0cae_2:
														num6--;
														goto IL_1392_2;
														IL_0cc1_2:
														if (5 < b)
														{
															break;
														}
														goto IL_0ccf_2;
														IL_0ccf_2:
														if (5 > b)
														{
															break;
														}
														goto IL_0cdd_2;
														IL_0cdd_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0d1d_2;
														IL_0d1d_2:
														array2[num6 - 2] = 0;
														goto IL_0d31_2;
														IL_0d31_2:
														num6--;
														goto IL_1392_2;
														IL_0d44_2:
														if (7 < b)
														{
															break;
														}
														num = 235;
														goto IL_0d5b_2;
														IL_05ee_2:
														num6 -= 3;
														goto IL_1392_2;
														IL_0d5b_2:
														if (7 > b)
														{
															break;
														}
														goto IL_0d69_2;
														IL_0d69_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0da9_2;
														IL_0da9_2:
														array2[num6 - 2] = 0;
														goto IL_0dbd_2;
														IL_0dbd_2:
														num6--;
														goto IL_1392_2;
														IL_0578_2:
														if (12 < b)
														{
															goto IL_0586_2;
														}
														goto IL_0614_2;
														IL_0586_2:
														if (14 >= b)
														{
															goto IL_0594_2;
														}
														goto IL_095c_2;
														IL_0594_2:
														if (14 > b)
														{
															goto IL_0753_2;
														}
														goto IL_0e3d_2;
														IL_0e3d_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_0e66_2;
														IL_0e66_2:
														array2[num6 - 1] = 5;
														goto IL_1392_2;
														IL_0753_2:
														if (13 < b)
														{
															break;
														}
														goto IL_0761_2;
														IL_0761_2:
														if (13 > b)
														{
															break;
														}
														goto IL_0e92_2;
														IL_0e92_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_0eb0_2;
														IL_0eb0_2:
														ptr2 += 8;
														goto IL_0ebe_2;
														IL_0ebe_2:
														num6--;
														goto IL_1392_2;
														IL_095c_2:
														if (15 >= b)
														{
															goto IL_096a_2;
														}
														goto IL_09fd_2;
														IL_096a_2:
														if (15 > b)
														{
															break;
														}
														goto IL_0978_2;
														IL_0978_2:
														array2[num6] = array2[num6 - 1];
														goto IL_0990_2;
														IL_0990_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_09ae_2;
														IL_09ae_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_09d2_2;
														IL_09d2_2:
														array3[num6] = array3[num6 - 1];
														goto IL_09ea_2;
														IL_09ea_2:
														num6++;
														goto IL_1392_2;
														IL_09fd_2:
														if (16 < b)
														{
															break;
														}
														goto IL_0a0b_2;
														IL_0a0b_2:
														if (16 > b)
														{
															break;
														}
														goto IL_0a19_2;
														IL_0a19_2:
														array2[num6] = 5;
														goto IL_0a27_2;
														IL_0a27_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_0a3f_2;
														IL_0a3f_2:
														num6++;
														goto IL_0e7f_2;
														IL_0e7f_2:
														ptr2 += 8;
														goto IL_1392_2;
														IL_0614_2:
														if (12 > b)
														{
															goto IL_0622_2;
														}
														goto IL_0774_2;
														IL_0622_2:
														if (10 < b)
														{
															goto IL_0630_2;
														}
														goto IL_06de_2;
														IL_0630_2:
														if (11 < b)
														{
															break;
														}
														goto IL_063e_2;
														IL_063e_2:
														if (11 > b)
														{
															break;
														}
														goto IL_1392_2;
														IL_06de_2:
														if (10 <= b)
														{
															goto IL_06ec_2;
														}
														goto IL_084c_2;
														IL_06ec_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0ed1_2;
														IL_0ed1_2:
														num6 -= 2;
														goto IL_1392_2;
														IL_084c_2:
														if (9 < b)
														{
															break;
														}
														goto IL_085a_2;
														IL_085a_2:
														if (9 > b)
														{
															break;
														}
														goto IL_0868_2;
														IL_0868_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_08a8_2;
														IL_08a8_2:
														array2[num6 - 2] = 0;
														goto IL_08bc_2;
														IL_08bc_2:
														num6--;
														goto IL_1392_2;
													}
													break;
													IL_0514_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											num = 17;
											goto IL_1392_2;
											continue;
											end_IL_0524_2:
											break;
										}
										continue;
										end_IL_0534:
										break;
									}
									continue;
									end_IL_0544:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_082b:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 103;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 54;
				while (true)
				{
					byte[] array = new byte[4];
					num = 123;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 122;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CompletedsetAbbreviatedMonthNames.DaylightBiasInterfaceIsIDispatch);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 128;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 71;
																while (true)
																{
																	IL_0320:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0300:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_02f3:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_02e3:
																								if (4 >= b)
																								{
																									while (true)
																									{
																										IL_02d3:
																										if (4 > b)
																										{
																											while (true)
																											{
																												IL_02c3:
																												if (2 < b)
																												{
																													while (3 >= b)
																													{
																														while (3 <= b)
																														{
																															num = 156;
																															while (true)
																															{
																																if (num != 156)
																																{
																																	if (num != 1137)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 19:
																																		goto IL_02a0;
																																	case 5:
																																		goto IL_02b3;
																																	case 121:
																																		goto IL_02c3;
																																	case 26:
																																		goto IL_02d3;
																																	case 120:
																																		goto IL_02e3;
																																	case 48:
																																		goto IL_02f3;
																																	case 15:
																																		goto IL_0300;
																																	case 20:
																																		goto IL_0310;
																																	case 71:
																																		goto IL_0320;
																																	case 2:
																																		goto end_IL_0320;
																																	case 30:
																																	case 126:
																																		goto end_IL_0330;
																																	case 35:
																																		goto IL_0362;
																																	case 36:
																																		goto IL_0370;
																																	case 49:
																																	case 55:
																																		goto IL_0380;
																																	case 58:
																																		goto IL_039e;
																																	case 98:
																																		goto IL_03ac;
																																	case 114:
																																		goto IL_03bf;
																																	case 73:
																																	case 83:
																																		goto IL_03cd;
																																	case 32:
																																		goto IL_03e6;
																																	case 129:
																																		goto IL_03f4;
																																	case 25:
																																	case 133:
																																		goto IL_0407;
																																	case 88:
																																	case 135:
																																		goto IL_0428;
																																	case 92:
																																		goto IL_0468;
																																	case 12:
																																		goto IL_047c;
																																	case 142:
																																		goto IL_048f;
																																	case 72:
																																		goto IL_04a2;
																																	case 105:
																																		goto IL_04cb;
																																	case 116:
																																		goto IL_04e4;
																																	case 68:
																																		goto IL_04f2;
																																	case 78:
																																	case 93:
																																		goto IL_04fd;
																																	case 47:
																																		goto IL_053c;
																																	case 1:
																																	case 96:
																																		goto IL_054f;
																																	case 77:
																																		goto IL_055d;
																																	case 10:
																																	case 29:
																																		goto IL_056b;
																																	case 97:
																																		goto IL_0579;
																																	case 140:
																																		goto IL_0591;
																																	case 107:
																																		goto IL_059f;
																																	case 119:
																																		goto IL_05b2;
																																	case 31:
																																		goto IL_05c0;
																																	case 104:
																																	case 125:
																																		goto IL_05ce;
																																	case 53:
																																		goto IL_05f7;
																																	case 4:
																																		goto IL_0605;
																																	case 82:
																																	case 110:
																																		goto IL_0621;
																																	case 39:
																																	case 64:
																																		goto IL_062f;
																																	case 45:
																																	case 130:
																																		goto IL_063a;
																																	case 14:
																																		goto end_IL_028d;
																																	case 59:
																																		goto IL_0666;
																																	case 136:
																																	case 139:
																																		goto IL_0671;
																																	case 127:
																																		goto IL_068d;
																																	case 66:
																																		goto IL_069b;
																																	case 61:
																																	case 76:
																																		goto IL_06a9;
																																	case 75:
																																		goto IL_0714;
																																	case 115:
																																		goto IL_0727;
																																	case 34:
																																	case 62:
																																		goto IL_0735;
																																	case 13:
																																		goto IL_0743;
																																	case 7:
																																	case 95:
																																		goto IL_074e;
																																	case 0:
																																		goto IL_0759;
																																	case 132:
																																	case 146:
																																		goto IL_077a;
																																	case 24:
																																		goto IL_0788;
																																	case 131:
																																		goto IL_07ab;
																																	case 74:
																																		goto IL_07b5;
																																	case 9:
																																		goto IL_07c3;
																																	case 16:
																																	case 118:
																																		goto IL_07d6;
																																	case 41:
																																		goto IL_07e4;
																																	case 40:
																																	case 148:
																																		goto IL_07f2;
																																	case 44:
																																		goto IL_0836;
																																	case 67:
																																		goto IL_084a;
																																	case 46:
																																	case 60:
																																		goto IL_085d;
																																	case 91:
																																		goto IL_089d;
																																	case 70:
																																		goto IL_08b1;
																																	case 6:
																																	case 8:
																																	case 18:
																																	case 21:
																																	case 22:
																																	case 37:
																																	case 38:
																																	case 42:
																																	case 56:
																																	case 57:
																																	case 80:
																																	case 81:
																																	case 84:
																																	case 85:
																																	case 89:
																																	case 94:
																																	case 99:
																																	case 101:
																																	case 106:
																																	case 108:
																																	case 111:
																																	case 113:
																																	case 117:
																																	case 134:
																																	case 138:
																																	case 143:
																																	case 144:
																																	case 147:
																																	case 149:
																																		goto end_IL_02a0;
																																	case 17:
																																	case 23:
																																	case 27:
																																	case 28:
																																	case 33:
																																	case 43:
																																	case 50:
																																	case 51:
																																	case 65:
																																	case 79:
																																	case 87:
																																	case 100:
																																	case 109:
																																	case 112:
																																	case 124:
																																	case 128:
																																	case 137:
																																		goto end_IL_0349;
																																	case 11:
																																		goto end_IL_08dd;
																																	case 145:
																																		goto end_IL_08f0;
																																	case 141:
																																		goto end_IL_08fb;
																																	case 63:
																																		goto end_IL_0905;
																																	case 122:
																																		goto end_IL_0910;
																																	case 3:
																																	case 90:
																																		goto end_IL_0920;
																																	case 123:
																																		goto end_IL_0930;
																																	case 54:
																																	case 86:
																																		goto end_IL_0949;
																																	case 102:
																																		goto end_IL_0959;
																																	case 103:
																																		goto end_IL_0972;
																																	case 52:
																																	case 69:
																																		goto IL_0996;
																																	}
																																	continue;
																																}
																																goto IL_04a2;
																																IL_04a2:
																																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																																goto IL_04cb;
																																IL_04cb:
																																array[num5 - 1] = 5;
																																goto end_IL_0349;
																																continue;
																																end_IL_028d:
																																break;
																															}
																															goto IL_0653;
																															continue;
																															end_IL_02a0:
																															break;
																															IL_02a0:;
																														}
																														break;
																														IL_02b3:;
																													}
																													break;
																												}
																												goto IL_0362;
																												IL_047c:
																												num5--;
																												goto end_IL_0349;
																												IL_0362:
																												if (2 > b)
																												{
																													goto IL_0370;
																												}
																												goto IL_0428;
																												IL_0370:
																												if (1 < b)
																												{
																													break;
																												}
																												goto IL_03bf;
																												IL_03bf:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_03cd;
																												IL_03cd:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_03e6;
																												IL_03e6:
																												array[num5] = 0;
																												goto IL_03f4;
																												IL_03f4:
																												num5++;
																												goto IL_048f;
																												IL_048f:
																												ptr2 += 8;
																												goto end_IL_0349;
																												IL_0428:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0468;
																												IL_0468:
																												array[num5 - 2] = 0;
																												goto IL_047c;
																											}
																											break;
																										}
																										goto IL_0380;
																										IL_03ac:
																										num5--;
																										goto end_IL_0349;
																										IL_0380:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										goto IL_039e;
																										IL_039e:
																										ptr2 += 8;
																										goto IL_03ac;
																									}
																									break;
																								}
																								goto IL_04e4;
																								IL_0605:
																								num5--;
																								goto end_IL_0349;
																								IL_04e4:
																								if (6 >= b)
																								{
																									goto IL_04f2;
																								}
																								goto IL_05b2;
																								IL_04f2:
																								if (6 <= b)
																								{
																									goto IL_04fd;
																								}
																								goto IL_054f;
																								IL_04fd:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_053c;
																								IL_053c:
																								num5 -= 3;
																								goto end_IL_0349;
																								IL_054f:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_055d;
																								IL_055d:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_056b;
																								IL_056b:
																								array[num5] = 5;
																								goto IL_0579;
																								IL_0579:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_0591;
																								IL_0591:
																								num5++;
																								goto IL_059f;
																								IL_059f:
																								ptr2 += 8;
																								goto end_IL_0349;
																								IL_05b2:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_05c0;
																								IL_05c0:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_05ce;
																								IL_05ce:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_05f7;
																								IL_05f7:
																								ptr2 += 8;
																								goto IL_0605;
																							}
																							break;
																						}
																						num = 25;
																						goto IL_0407;
																						IL_0407:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						num = 137;
																						goto end_IL_0349;
																					}
																					break;
																				}
																				num = 110;
																				goto IL_0621;
																				IL_084a:
																				num5--;
																				goto end_IL_0349;
																				IL_085d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_089d;
																				IL_0621:
																				if (12 < b)
																				{
																					goto IL_062f;
																				}
																				goto IL_0727;
																				IL_062f:
																				if (14 < b)
																				{
																					goto IL_063a;
																				}
																				goto IL_0666;
																				IL_063a:
																				if (15 < b)
																				{
																					num = 108;
																					break;
																				}
																				goto IL_0653;
																				IL_089d:
																				array[num5 - 2] = 0;
																				goto IL_08b1;
																				IL_0653:
																				if (15 <= b)
																				{
																				}
																				break;
																				IL_0666:
																				if (14 <= b)
																				{
																					goto IL_0671;
																				}
																				goto IL_068d;
																				IL_0671:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0349;
																				IL_068d:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_069b;
																				IL_069b:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_06a9;
																				IL_06a9:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 75;
																				goto IL_0714;
																				IL_0714:
																				num5 -= 2;
																				goto end_IL_0349;
																				IL_0727:
																				if (12 > b)
																				{
																					goto IL_0735;
																				}
																				goto IL_085d;
																				IL_0735:
																				if (10 >= b)
																				{
																					goto IL_0743;
																				}
																				goto IL_07d6;
																				IL_0743:
																				if (10 > b)
																				{
																					goto IL_074e;
																				}
																				goto IL_077a;
																				IL_074e:
																				if (9 < b)
																				{
																					num = 80;
																					break;
																				}
																				goto IL_0759;
																				IL_0759:
																				if (9 > b)
																				{
																					break;
																				}
																				goto end_IL_0349;
																				IL_08b1:
																				num5--;
																				goto end_IL_0349;
																				IL_077a:
																				array[num5] = 0;
																				goto IL_0788;
																				IL_0788:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_07ab;
																				IL_07ab:
																				array2[num5] = null;
																				goto IL_07b5;
																				IL_07b5:
																				num5++;
																				goto IL_07c3;
																				IL_07c3:
																				ptr2 += 8;
																				goto end_IL_0349;
																				IL_07d6:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_07e4;
																				IL_07e4:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_07f2;
																				IL_07f2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0836;
																				IL_0836:
																				array[num5 - 2] = 0;
																				goto IL_084a;
																			}
																			break;
																			IL_0310:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 51;
																	goto end_IL_0349;
																	continue;
																	end_IL_0320:
																	break;
																}
																continue;
																end_IL_0330:
																break;
															}
															continue;
															end_IL_0349:
															break;
														}
														continue;
													}
													goto IL_0996;
													IL_0996:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08dd:
													break;
												}
												continue;
												end_IL_08f0:
												break;
											}
											continue;
											end_IL_08fb:
											break;
										}
										continue;
										end_IL_0905:
										break;
									}
									continue;
									end_IL_0910:
									break;
								}
								continue;
								end_IL_0920:
								break;
							}
							continue;
							end_IL_0930:
							break;
						}
						continue;
						end_IL_0949:
						break;
					}
					continue;
					end_IL_0959:
					break;
				}
				continue;
				end_IL_0972:
				break;
			}
		}
	}

	private unsafe static int smethod_9()
	{
		int num = 11;
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeEntryDaylightName.AllocateBufferFreeListEmptyTypeAnalysis);
										num = 152;
										while (true)
										{
											if (num != 152)
											{
												if (num != 1133)
												{
													goto IL_0911;
												}
												switch (num)
												{
												case 117:
													goto end_IL_026f;
												case 66:
													goto end_IL_0282;
												case 39:
													goto end_IL_0296;
												case 59:
												case 118:
													goto end_IL_02a6;
												case 132:
													goto end_IL_02b6;
												case 1:
												case 73:
													goto end_IL_02c6;
												case 10:
													goto end_IL_02d6;
												case 11:
													goto end_IL_02e6;
												case 13:
												case 28:
												case 36:
												case 40:
												case 42:
												case 45:
												case 53:
												case 57:
												case 63:
												case 65:
												case 68:
												case 85:
												case 97:
												case 106:
												case 109:
												case 119:
												case 128:
												case 138:
													goto IL_0309;
												case 100:
												case 143:
													goto IL_0319;
												case 6:
													goto IL_0322;
												case 25:
													goto IL_0330;
												case 27:
													goto IL_033e;
												case 50:
													goto IL_034c;
												case 130:
													goto IL_035a;
												case 115:
													goto IL_0368;
												case 92:
												case 110:
													goto IL_0373;
												case 91:
													goto IL_03b3;
												case 86:
													goto IL_03c7;
												case 135:
													goto IL_03da;
												case 121:
													goto IL_03e8;
												case 38:
												case 141:
													goto IL_03f3;
												case 55:
													goto IL_0401;
												case 83:
												case 123:
													goto IL_0414;
												case 62:
													goto IL_0422;
												case 114:
													goto IL_0445;
												case 107:
													goto IL_044f;
												case 21:
													goto IL_0466;
												case 22:
													goto IL_0479;
												case 43:
													goto IL_0487;
												case 49:
												case 144:
													goto IL_0495;
												case 52:
													goto IL_04d9;
												case 51:
													goto IL_04ed;
												case 34:
													goto IL_0500;
												case 48:
													goto IL_050e;
												case 31:
													goto IL_051c;
												case 103:
													goto IL_052a;
												case 87:
												case 104:
													goto IL_0538;
												case 111:
													goto IL_059a;
												case 24:
												case 120:
													goto IL_05ad;
												case 101:
													goto IL_05c9;
												case 96:
													goto IL_05d7;
												case 99:
													goto IL_05f3;
												case 14:
												case 20:
													goto IL_05fe;
												case 37:
													goto IL_0616;
												case 18:
													goto IL_0624;
												case 23:
												case 77:
													goto IL_0632;
												case 140:
													goto IL_0640;
												case 71:
												case 74:
													goto IL_064b;
												case 29:
													goto IL_068b;
												case 15:
													goto IL_069f;
												case 2:
												case 95:
													goto IL_06bb;
												case 35:
													goto IL_06c9;
												case 80:
												case 134:
													goto IL_06d7;
												case 142:
													goto IL_06f0;
												case 90:
													goto IL_06fe;
												case 84:
													goto IL_0715;
												case 93:
													goto IL_0728;
												case 112:
													goto IL_0736;
												case 12:
												case 32:
													goto IL_0744;
												case 127:
													goto IL_076d;
												case 102:
												case 116:
													goto IL_0786;
												case 137:
													goto IL_07a4;
												case 33:
													goto IL_07b2;
												case 81:
													goto IL_07c5;
												case 30:
												case 126:
													goto IL_07d0;
												case 82:
													goto IL_07de;
												case 9:
												case 16:
													goto IL_07ec;
												case 72:
													goto IL_0815;
												case 139:
													goto IL_0823;
												case 76:
													goto IL_0836;
												case 4:
												case 5:
													goto IL_0841;
												case 3:
													goto IL_084f;
												case 26:
												case 79:
													goto IL_0866;
												case 58:
													goto IL_0874;
												case 41:
													goto IL_088c;
												case 0:
													goto IL_089a;
												case 47:
												case 133:
													goto IL_08ad;
												case 145:
													goto IL_08f5;
												case 7:
												case 8:
												case 19:
												case 44:
												case 46:
												case 54:
												case 56:
												case 60:
												case 61:
												case 64:
												case 67:
												case 69:
												case 70:
												case 75:
												case 88:
												case 89:
												case 94:
												case 98:
												case 105:
												case 108:
												case 113:
												case 122:
												case 124:
												case 125:
												case 129:
												case 131:
												case 136:
													goto IL_0911;
												case 17:
												case 78:
													goto IL_0929;
												}
												continue;
											}
											ptr2 = ptr;
											goto IL_0309;
											IL_0874:
											array2[num4] = array5[*(int*)(ptr2 + num3)];
											goto IL_088c;
											IL_089a:
											ptr2 += 8;
											goto IL_0309;
											IL_088c:
											num4++;
											goto IL_089a;
											IL_0309:
											if (num5 != 1)
											{
												goto IL_0319;
											}
											goto IL_0929;
											IL_0929:
											return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											IL_0319:
											b = *ptr2;
											goto IL_0322;
											IL_0322:
											ptr2++;
											goto IL_0330;
											IL_0330:
											if (b >= 1)
											{
												goto IL_033e;
											}
											goto IL_0911;
											IL_033e:
											if (b <= 15)
											{
												goto IL_034c;
											}
											goto IL_0911;
											IL_034c:
											if (8 < b)
											{
												goto IL_035a;
											}
											num = 99;
											goto IL_05f3;
											IL_035a:
											if (12 >= b)
											{
												goto IL_0368;
											}
											goto IL_0500;
											IL_0368:
											if (12 <= b)
											{
												goto IL_0373;
											}
											goto IL_03da;
											IL_0373:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_03b3;
											IL_03b3:
											array[num4 - 2] = 0;
											goto IL_03c7;
											IL_03c7:
											num4--;
											goto IL_0309;
											IL_03da:
											if (10 >= b)
											{
												goto IL_03e8;
											}
											goto IL_0479;
											IL_03e8:
											if (10 > b)
											{
												goto IL_03f3;
											}
											goto IL_0414;
											IL_03f3:
											if (9 >= b)
											{
												goto IL_0401;
											}
											goto IL_0911;
											IL_0401:
											if (9 <= b)
											{
												goto IL_0309;
											}
											goto IL_0911;
											IL_0414:
											array[num4] = 0;
											goto IL_0422;
											IL_0422:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
											goto IL_0445;
											IL_0445:
											array2[num4] = null;
											goto IL_044f;
											IL_044f:
											num4++;
											num = 21;
											goto IL_0466;
											IL_0466:
											ptr2 += 8;
											goto IL_0309;
											IL_0479:
											if (11 >= b)
											{
												goto IL_0487;
											}
											goto IL_0911;
											IL_0487:
											if (11 <= b)
											{
												goto IL_0495;
											}
											goto IL_0911;
											IL_0495:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = ((int[])array2[num4 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
											goto IL_04d9;
											IL_04d9:
											array[num4 - 2] = 0;
											goto IL_04ed;
											IL_04ed:
											num4--;
											goto IL_0309;
											IL_0500:
											if (14 >= b)
											{
												goto IL_050e;
											}
											goto IL_05c9;
											IL_050e:
											if (14 > b)
											{
												goto IL_051c;
											}
											goto IL_05ad;
											IL_051c:
											if (13 >= b)
											{
												goto IL_052a;
											}
											goto IL_0911;
											IL_052a:
											if (13 <= b)
											{
												goto IL_0538;
											}
											goto IL_0911;
											IL_0538:
											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
											goto IL_059a;
											IL_059a:
											num4 -= 2;
											goto IL_0309;
											IL_05ad:
											byte* num6 = ptr2;
											num5 = 1;
											ptr2 = num6 + -200;
											goto IL_0309;
											IL_05c9:
											if (15 >= b)
											{
												goto IL_05d7;
											}
											goto IL_0911;
											IL_05d7:
											if (15 <= b)
											{
											}
											goto IL_0911;
											IL_08ad:
											((int[])array2[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											num = 145;
											goto IL_08f5;
											IL_05f3:
											if (8 <= b)
											{
												goto IL_05fe;
											}
											goto IL_0616;
											IL_05fe:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0309;
											IL_0616:
											if (4 >= b)
											{
												goto IL_0624;
											}
											goto IL_07c5;
											IL_0624:
											if (4 > b)
											{
												goto IL_0632;
											}
											goto IL_0786;
											IL_0632:
											if (2 >= b)
											{
												goto IL_0640;
											}
											goto IL_0728;
											IL_0640:
											if (2 <= b)
											{
												goto IL_064b;
											}
											num = 2;
											goto IL_06bb;
											IL_064b:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_068b;
											IL_068b:
											array[num4 - 2] = 0;
											goto IL_069f;
											IL_069f:
											num4--;
											goto IL_0309;
											IL_08f5:
											num4 -= 3;
											num = 138;
											goto IL_0309;
											IL_06bb:
											if (1 >= b)
											{
												goto IL_06c9;
											}
											goto IL_0911;
											IL_06c9:
											if (1 <= b)
											{
												goto IL_06d7;
											}
											goto IL_0911;
											IL_06d7:
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
											goto IL_06f0;
											IL_06f0:
											array[num4] = 0;
											goto IL_06fe;
											IL_06fe:
											num4++;
											num = 84;
											goto IL_0715;
											IL_0715:
											ptr2 += 8;
											goto IL_0309;
											IL_0728:
											if (3 >= b)
											{
												goto IL_0736;
											}
											goto IL_0911;
											IL_0736:
											if (3 <= b)
											{
												goto IL_0744;
											}
											goto IL_0911;
											IL_0744:
											array2[num4 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])];
											goto IL_076d;
											IL_076d:
											array[num4 - 1] = 5;
											goto IL_0309;
											IL_0786:
											array5[*(int*)(ptr2 + num3)] = array2[num4 - 1];
											goto IL_07a4;
											IL_07a4:
											ptr2 += 8;
											goto IL_07b2;
											IL_07b2:
											num4--;
											goto IL_0309;
											IL_07c5:
											if (6 < b)
											{
												goto IL_07d0;
											}
											goto IL_0836;
											IL_07d0:
											if (7 >= b)
											{
												goto IL_07de;
											}
											goto IL_0911;
											IL_07de:
											if (7 <= b)
											{
												goto IL_07ec;
											}
											goto IL_0911;
											IL_07ec:
											ref int reference = ref array3[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
											goto IL_0815;
											IL_0815:
											ptr2 += 8;
											goto IL_0823;
											IL_0823:
											num4--;
											goto IL_0309;
											IL_0836:
											if (6 > b)
											{
												goto IL_0841;
											}
											goto IL_08ad;
											IL_0841:
											if (5 >= b)
											{
												goto IL_084f;
											}
											goto IL_0911;
											IL_084f:
											if (5 <= b)
											{
												num = 79;
												goto IL_0866;
											}
											goto IL_0911;
											IL_0911:
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_0309;
											IL_0866:
											array[num4] = 5;
											goto IL_0874;
											continue;
											end_IL_026f:
											break;
										}
										continue;
										end_IL_0282:
										break;
									}
									continue;
									end_IL_0296:
									break;
								}
								continue;
								end_IL_02a6:
								break;
							}
							continue;
							end_IL_02b6:
							break;
						}
						continue;
						end_IL_02c6:
						break;
					}
					continue;
					end_IL_02d6:
					break;
				}
				continue;
				end_IL_02e6:
				break;
			}
		}
	}
}
