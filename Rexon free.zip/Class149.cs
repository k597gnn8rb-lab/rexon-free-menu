using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Anti Report Type", "Safety", "", true, 3, ModType.const_1, false)]
internal class Class149 : MonoBehaviour
{
	private static int int_0;

	private static int int_1;

	private static double double_0;

	private static double double_1;

	private static bool bool_0;

	private static int int_2;

	private static bool bool_1;

	private static IntPtr[] DynamicTimeZoneInformationMTAThreadAttribute;

	private static IntPtr[] CryptoStreamModeCurrentThreadActivityId;

	private static IntPtr[] AssemblyAttributesGoHereDebuggerStepperBoundaryAttribute;

	private static IntPtr[] StoreOperationScavengegetDynamicBase;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_04dd, IL_04f0, IL_0503, IL_0513, IL_0520, IL_0530, IL_0540, IL_0550, IL_0560, IL_0570, IL_0580, IL_058b, IL_0599, IL_05bd, IL_05cb, IL_05de, IL_05f1, IL_05ff, IL_060d, IL_0618, IL_0626, IL_0634, IL_0642, IL_065c, IL_066f, IL_067d, IL_068b, IL_069f, IL_06f4, IL_0702, IL_0715, IL_0743, IL_0756, IL_0794, IL_07a2, IL_07ad, IL_07bb, IL_07c9, IL_07d7, IL_07ef, IL_07fd, IL_0810, IL_0853, IL_085c, IL_086a, IL_0878, IL_0886, IL_0899, IL_08ac, IL_08c0, IL_08d3, IL_08e1, IL_08ea, IL_08f5, IL_0903, IL_091f, IL_092d, IL_093b, IL_0966, IL_097f, IL_098a, IL_09a8, IL_09b6, IL_09c4, IL_09d7, IL_09e5, IL_09f3, IL_0a07, IL_0a3f, IL_0a52, IL_0a6e, IL_0a79, IL_0aa2, IL_0ab0, IL_0ac3, IL_0ad1, IL_0adf, IL_0af7, IL_0b05, IL_0b13, IL_0b26, IL_0b50, IL_0b69, IL_0ba9, IL_0bbd, IL_0bd0, IL_0bde, IL_0bec, IL_0bfa, IL_0c08, IL_0c16, IL_0c24, IL_0c2f, IL_0c6f, IL_0c83, IL_0c9f, IL_0cad, IL_0cc0, IL_0cce, IL_0cdc, IL_0d05, IL_0d13, IL_0d26, IL_0d2f, IL_0d3d, IL_0d60, IL_0d6a, IL_0d78, IL_0d8b, IL_0d99, IL_0da7, IL_0db5, IL_0df5, IL_0e09, IL_0e1c, IL_0e2a, IL_0e38, IL_0e46, IL_0e8f, IL_0ea3, IL_0eb6, IL_0eff, IL_0f13, IL_0f26, IL_0f39, IL_0f47, IL_0f55, IL_0f60, IL_0f7e, IL_0f8c, IL_0f9f, IL_0fad, IL_0fbb, IL_0fd8, IL_1027, IL_1031, IL_105e, IL_1072, IL_1080, IL_1093, IL_10a1, IL_10af, IL_10d8, IL_10f1, IL_10ff, IL_110d, IL_1118, IL_117a, IL_118d, IL_119b, IL_11a9, IL_11e9, IL_11fd, IL_1210, IL_121e, IL_122c, IL_1240, IL_127f, IL_1292, IL_12b3, IL_12da, IL_12fe, IL_1316, IL_1326, IL_133f, IL_1356, IL_1364, IL_1372, IL_1385, IL_138f, IL_139a, IL_13aa, IL_13ba, IL_13ca, IL_13da, IL_13ea, IL_13fa, IL_140a, IL_141a are reachable both inside and outside the pinned region starting at IL_142f. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 128;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num6;
			int num7;
			int __rxRef64 = default(int);
			ref int reference = ref __rxRef64;
			object[] array8;
			int num8;
			byte* num9;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_141a:
					num2 = 1;
					while (true)
					{
						IL_140a:
						num3 = num2 * 4;
						while (true)
						{
							IL_13fa:
							array2 = new byte[4];
							while (true)
							{
								IL_13ea:
								array3 = new object[4];
								while (true)
								{
									IL_13da:
									array4 = new int[4];
									while (true)
									{
										IL_13ca:
										array5 = new int[6];
										while (true)
										{
											IL_13ba:
											array6 = new long[4];
											while (true)
											{
												IL_13aa:
												array7 = new object[15];
												while (true)
												{
													IL_139a:
													array7[0] = this;
													while (true)
													{
														IL_138f:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RelativePathToCallContext.AddFieldImporterCallback);
														while (true)
														{
															IL_1385:
															ptr2 = ptr;
															while (true)
															{
																IL_1372:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0580:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0570:
																		ptr2++;
																		while (true)
																		{
																			IL_0560:
																			if (b >= 1)
																			{
																				while (b <= 31)
																				{
																					while (true)
																					{
																						IL_0540:
																						if (16 < b)
																						{
																							while (true)
																							{
																								IL_0530:
																								if (24 >= b)
																								{
																									while (true)
																									{
																										IL_0520:
																										if (24 > b)
																										{
																											while (true)
																											{
																												IL_0513:
																												if (20 < b)
																												{
																													while (true)
																													{
																														IL_0503:
																														if (22 >= b)
																														{
																															while (true)
																															{
																																IL_04f0:
																																if (22 <= b)
																																{
																																	num = 304;
																																	while (true)
																																	{
																																		if (num != 304)
																																		{
																																			if (num != 1285)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 128:
																																				break;
																																			default:
																																				continue;
																																			case 246:
																																				goto IL_04f0;
																																			case 269:
																																				goto IL_0503;
																																			case 167:
																																			case 187:
																																				goto IL_0513;
																																			case 196:
																																				goto IL_0520;
																																			case 140:
																																			case 188:
																																				goto IL_0530;
																																			case 170:
																																				goto IL_0540;
																																			case 16:
																																				goto IL_0550;
																																			case 56:
																																				goto IL_0560;
																																			case 114:
																																				goto IL_0570;
																																			case 177:
																																			case 257:
																																				goto IL_0580;
																																			case 85:
																																				goto IL_058b;
																																			case 17:
																																			case 97:
																																				goto IL_0599;
																																			case 20:
																																				goto IL_05bd;
																																			case 57:
																																				goto IL_05cb;
																																			case 205:
																																				goto IL_05de;
																																			case 220:
																																			case 231:
																																				goto IL_05f1;
																																			case 169:
																																				goto IL_05ff;
																																			case 204:
																																				goto IL_060d;
																																			case 3:
																																				goto IL_0618;
																																			case 136:
																																				goto IL_0626;
																																			case 72:
																																				goto IL_0634;
																																			case 121:
																																			case 211:
																																				goto IL_0642;
																																			case 147:
																																				goto IL_065c;
																																			case 135:
																																			case 182:
																																				goto IL_066f;
																																			case 68:
																																				goto IL_067d;
																																			case 82:
																																			case 217:
																																				goto IL_068b;
																																			case 49:
																																				goto IL_069f;
																																			case 117:
																																				goto IL_06f4;
																																			case 199:
																																				goto IL_0702;
																																			case 151:
																																			case 185:
																																				goto IL_0715;
																																			case 195:
																																				goto IL_0743;
																																			case 186:
																																			case 232:
																																				goto IL_0756;
																																			case 236:
																																				goto IL_0794;
																																			case 180:
																																				goto end_IL_04dd;
																																			case 101:
																																				goto IL_07ad;
																																			case 154:
																																				goto IL_07bb;
																																			case 29:
																																			case 215:
																																				goto IL_07c9;
																																			case 71:
																																				goto IL_07d7;
																																			case 144:
																																				goto IL_07ef;
																																			case 96:
																																				goto IL_07fd;
																																			case 161:
																																			case 219:
																																				goto IL_0810;
																																			case 107:
																																			case 111:
																																				goto IL_085c;
																																			case 245:
																																				goto IL_0878;
																																			case 67:
																																				goto IL_0886;
																																			case 249:
																																				goto IL_0899;
																																			case 262:
																																				goto IL_08ac;
																																			case 173:
																																				goto IL_08c0;
																																			case 272:
																																				goto IL_08d3;
																																			case 174:
																																				goto IL_08ea;
																																			case 132:
																																			case 141:
																																				goto IL_0903;
																																			case 120:
																																			case 278:
																																				goto IL_091f;
																																			case 265:
																																				goto IL_092d;
																																			case 12:
																																			case 240:
																																				goto IL_093b;
																																			case 122:
																																				goto IL_0966;
																																			case 290:
																																				goto IL_097f;
																																			case 2:
																																			case 230:
																																				goto IL_098a;
																																			case 13:
																																				goto IL_09a8;
																																			case 252:
																																				goto IL_09b6;
																																			case 7:
																																				goto IL_09c4;
																																			case 291:
																																				goto IL_09e5;
																																			case 15:
																																			case 292:
																																				goto IL_09f3;
																																			case 93:
																																				goto IL_0a07;
																																			case 88:
																																				goto IL_0a3f;
																																			case 295:
																																				goto IL_0a52;
																																			case 296:
																																				goto IL_0a6e;
																																			case 162:
																																			case 178:
																																				goto IL_0a79;
																																			case 149:
																																				goto IL_0aa2;
																																			case 283:
																																				goto IL_0ab0;
																																			case 289:
																																				goto IL_0ac3;
																																			case 95:
																																				goto IL_0ad1;
																																			case 26:
																																			case 104:
																																				goto IL_0adf;
																																			case 123:
																																				goto IL_0af7;
																																			case 293:
																																				goto IL_0b05;
																																			case 39:
																																				goto IL_0b13;
																																			case 276:
																																				goto IL_0b26;
																																			case 47:
																																				goto IL_0b50;
																																			case 83:
																																			case 158:
																																				goto IL_0b69;
																																			case 273:
																																				goto IL_0ba9;
																																			case 223:
																																				goto IL_0bbd;
																																			case 22:
																																				goto IL_0bd0;
																																			case 115:
																																				goto IL_0bde;
																																			case 213:
																																				goto IL_0bec;
																																			case 77:
																																			case 238:
																																				goto IL_0bfa;
																																			case 288:
																																				goto IL_0c08;
																																			case 6:
																																				goto IL_0c16;
																																			case 119:
																																				goto IL_0c24;
																																			case 80:
																																			case 152:
																																				goto IL_0c2f;
																																			case 90:
																																				goto IL_0c6f;
																																			case 183:
																																				goto IL_0c83;
																																			case 69:
																																			case 222:
																																				goto IL_0c9f;
																																			case 254:
																																				goto IL_0cad;
																																			case 261:
																																				goto IL_0cc0;
																																			case 285:
																																				goto IL_0cce;
																																			case 241:
																																			case 267:
																																				goto IL_0cdc;
																																			case 51:
																																				goto IL_0d05;
																																			case 212:
																																				goto IL_0d13;
																																			case 124:
																																			case 134:
																																				goto IL_0d2f;
																																			case 73:
																																				goto IL_0d3d;
																																			case 55:
																																				goto IL_0d60;
																																			case 264:
																																				goto IL_0d6a;
																																			case 284:
																																				goto IL_0d78;
																																			case 54:
																																				goto IL_0d8b;
																																			case 50:
																																			case 153:
																																				goto IL_0d99;
																																			case 184:
																																				goto IL_0da7;
																																			case 190:
																																			case 253:
																																				goto IL_0db5;
																																			case 66:
																																				goto IL_0df5;
																																			case 176:
																																				goto IL_0e09;
																																			case 279:
																																				goto IL_0e1c;
																																			case 103:
																																			case 175:
																																				goto IL_0e2a;
																																			case 229:
																																				goto IL_0e38;
																																			case 130:
																																			case 225:
																																				goto IL_0e46;
																																			case 286:
																																				goto IL_0e8f;
																																			case 268:
																																				goto IL_0ea3;
																																			case 48:
																																			case 287:
																																				goto IL_0eb6;
																																			case 5:
																																				goto IL_0eff;
																																			case 53:
																																				goto IL_0f13;
																																			case 94:
																																			case 270:
																																				goto IL_0f26;
																																			case 168:
																																			case 247:
																																				goto IL_0f39;
																																			case 0:
																																			case 24:
																																				goto IL_0f47;
																																			case 81:
																																				goto IL_0f55;
																																			case 10:
																																			case 113:
																																				goto IL_0f60;
																																			case 44:
																																				goto IL_0f7e;
																																			case 32:
																																				goto IL_0f8c;
																																			case 89:
																																			case 102:
																																				goto IL_0f9f;
																																			case 164:
																																				goto IL_0fad;
																																			case 19:
																																			case 79:
																																				goto IL_0fbb;
																																			case 108:
																																				goto IL_1072;
																																			case 64:
																																				goto IL_1080;
																																			case 30:
																																			case 34:
																																				goto IL_1093;
																																			case 160:
																																				goto IL_10a1;
																																			case 201:
																																			case 297:
																																				goto IL_10af;
																																			case 126:
																																				goto IL_10d8;
																																			case 91:
																																				goto IL_10f1;
																																			case 27:
																																			case 145:
																																				goto IL_10ff;
																																			case 99:
																																				goto IL_110d;
																																			case 25:
																																			case 75:
																																				goto IL_1118;
																																			case 200:
																																				goto IL_117a;
																																			case 43:
																																				goto IL_118d;
																																			case 106:
																																				goto IL_119b;
																																			case 52:
																																			case 138:
																																				goto IL_11a9;
																																			case 218:
																																				goto IL_11e9;
																																			case 37:
																																				goto IL_11fd;
																																			case 112:
																																			case 227:
																																				goto IL_1210;
																																			case 235:
																																				goto IL_121e;
																																			case 62:
																																			case 237:
																																				goto IL_122c;
																																			case 233:
																																				goto IL_1240;
																																			case 234:
																																				goto IL_127f;
																																			case 31:
																																			case 110:
																																				goto IL_1292;
																																			case 4:
																																				goto IL_12b3;
																																			case 146:
																																				goto IL_12da;
																																			case 98:
																																				goto IL_12fe;
																																			case 41:
																																				goto IL_1316;
																																			case 1:
																																			case 8:
																																			case 18:
																																			case 33:
																																			case 42:
																																			case 45:
																																			case 46:
																																			case 58:
																																			case 59:
																																			case 61:
																																			case 65:
																																			case 70:
																																			case 76:
																																			case 84:
																																			case 87:
																																			case 92:
																																			case 100:
																																			case 118:
																																			case 125:
																																			case 129:
																																			case 131:
																																			case 139:
																																			case 150:
																																			case 155:
																																			case 156:
																																			case 165:
																																			case 171:
																																			case 172:
																																			case 179:
																																			case 181:
																																			case 191:
																																			case 192:
																																			case 194:
																																			case 202:
																																			case 206:
																																			case 210:
																																			case 214:
																																			case 224:
																																			case 242:
																																			case 244:
																																			case 248:
																																			case 258:
																																			case 259:
																																			case 260:
																																			case 263:
																																			case 274:
																																			case 275:
																																			case 280:
																																			case 282:
																																				goto end_IL_0550;
																																			case 78:
																																				goto IL_133f;
																																			case 221:
																																				goto IL_1356;
																																			case 159:
																																				goto IL_1364;
																																			case 9:
																																			case 11:
																																			case 14:
																																			case 23:
																																			case 28:
																																			case 35:
																																			case 36:
																																			case 38:
																																			case 40:
																																			case 60:
																																			case 63:
																																			case 74:
																																			case 105:
																																			case 109:
																																			case 137:
																																			case 142:
																																			case 143:
																																			case 157:
																																			case 166:
																																			case 189:
																																			case 193:
																																			case 197:
																																			case 207:
																																			case 209:
																																			case 216:
																																			case 226:
																																			case 228:
																																			case 239:
																																			case 243:
																																			case 250:
																																			case 251:
																																			case 256:
																																			case 266:
																																			case 281:
																																				goto IL_1372;
																																			case 203:
																																				goto IL_1385;
																																			case 21:
																																				goto IL_138f;
																																			case 277:
																																				goto IL_139a;
																																			case 163:
																																				goto IL_13aa;
																																			case 255:
																																				goto IL_13ba;
																																			case 294:
																																				goto IL_13ca;
																																			case 198:
																																				goto IL_13da;
																																			case 271:
																																				goto IL_13ea;
																																			case 116:
																																			case 148:
																																				goto IL_13fa;
																																			case 133:
																																				goto IL_140a;
																																			case 127:
																																				goto IL_141a;
																																			case 86:
																																			case 208:
																																				return;
																																			}
																																			goto end_IL_0513;
																																		}
																																		goto IL_0b26;
																																		IL_0b26:
																																		*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
																																		goto IL_0b50;
																																		IL_0b50:
																																		array2[num5 - 1] = 2;
																																		goto IL_1372;
																																		continue;
																																		end_IL_04dd:
																																		break;
																																	}
																																	break;
																																}
																																goto IL_05de;
																																IL_09b6:
																																num5++;
																																goto IL_09c4;
																																IL_09c4:
																																ptr2 += 8;
																																goto IL_1372;
																																IL_05de:
																																if (21 < b)
																																{
																																	goto end_IL_0550;
																																}
																																goto IL_097f;
																																IL_097f:
																																if (21 > b)
																																{
																																	num = 131;
																																	goto end_IL_0550;
																																}
																																goto IL_098a;
																																IL_098a:
																																array3[num5] = ((delegate*<string[]>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])();
																																goto IL_09a8;
																																IL_09a8:
																																array2[num5] = 5;
																																goto IL_09b6;
																															}
																															break;
																														}
																														goto IL_091f;
																														IL_0966:
																														array2[num5 - 1] = 0;
																														goto IL_1372;
																														IL_091f:
																														if (23 < b)
																														{
																															goto end_IL_0550;
																														}
																														goto IL_092d;
																														IL_092d:
																														if (23 > b)
																														{
																															goto end_IL_0550;
																														}
																														goto IL_093b;
																														IL_093b:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																														goto IL_0966;
																													}
																													goto IL_07a2;
																												}
																												goto IL_058b;
																												IL_09f3:
																												array2[num5 - 1] = 5;
																												goto IL_0a07;
																												IL_058b:
																												if (20 <= b)
																												{
																													goto IL_0599;
																												}
																												goto IL_0794;
																												IL_0599:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])();
																												goto IL_05bd;
																												IL_05bd:
																												array2[num5] = 0;
																												goto IL_05cb;
																												IL_05cb:
																												num5++;
																												goto IL_0899;
																												IL_0899:
																												ptr2 += 8;
																												goto IL_1372;
																												IL_0794:
																												if (18 >= b)
																												{
																													goto IL_07a2;
																												}
																												num = 111;
																												goto IL_085c;
																												IL_07a2:
																												if (18 > b)
																												{
																													goto IL_07ad;
																												}
																												goto IL_0810;
																												IL_07ad:
																												if (17 < b)
																												{
																													goto end_IL_0550;
																												}
																												goto IL_07bb;
																												IL_07bb:
																												if (17 > b)
																												{
																													goto end_IL_0550;
																												}
																												goto IL_07c9;
																												IL_07c9:
																												array2[num5] = 5;
																												goto IL_07d7;
																												IL_07d7:
																												array3[num5] = array7[*(int*)(ptr2 + num3)];
																												goto IL_07ef;
																												IL_07ef:
																												num5++;
																												goto IL_07fd;
																												IL_07fd:
																												ptr2 += 8;
																												goto IL_1372;
																												IL_0810:
																												((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																												goto IL_0a52;
																												IL_0a52:
																												num5 -= 3;
																												num = 38;
																												goto IL_1372;
																												IL_0a07:
																												array3[num5 - 1] = ((delegate*<string[], string>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																												goto IL_0a3f;
																												IL_085c:
																												if (19 < b)
																												{
																													num = 76;
																													goto end_IL_0550;
																												}
																												goto IL_09e5;
																												IL_0a3f:
																												ptr2 += 8;
																												goto IL_1372;
																												IL_09e5:
																												if (19 > b)
																												{
																													goto end_IL_0550;
																												}
																												goto IL_09f3;
																												continue;
																												end_IL_0513:
																												break;
																											}
																											break;
																										}
																										goto IL_0b69;
																										IL_0bbd:
																										num5--;
																										goto IL_1372;
																										IL_0b69:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_0ba9;
																										IL_0ba9:
																										array2[num5 - 2] = 0;
																										goto IL_0bbd;
																									}
																									break;
																								}
																								goto IL_05f1;
																								IL_08ea:
																								if (31 > b)
																								{
																									num = 171;
																									goto end_IL_0550;
																								}
																								goto IL_0903;
																								IL_05f1:
																								if (28 >= b)
																								{
																									goto IL_05ff;
																								}
																								goto IL_0743;
																								IL_05ff:
																								if (28 > b)
																								{
																									goto IL_060d;
																								}
																								goto IL_0715;
																								IL_060d:
																								if (26 >= b)
																								{
																									goto IL_0618;
																								}
																								goto IL_066f;
																								IL_0618:
																								if (26 > b)
																								{
																									goto IL_0626;
																								}
																								goto IL_0756;
																								IL_0626:
																								if (25 < b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_0634;
																								IL_0634:
																								if (25 > b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_0642;
																								IL_0642:
																								Class147.int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								goto IL_065c;
																								IL_065c:
																								num5--;
																								goto IL_1372;
																								IL_0756:
																								array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																								goto IL_08ac;
																								IL_08ac:
																								array2[num5 - 2] = 5;
																								goto IL_08c0;
																								IL_08c0:
																								num5--;
																								goto IL_1372;
																								IL_066f:
																								if (27 < b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_067d;
																								IL_067d:
																								if (27 > b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_068b;
																								IL_068b:
																								array2[num5 - 2] = 5;
																								goto IL_069f;
																								IL_069f:
																								array3[num5 - 2] = ((delegate*<string, string, string>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																								num = 117;
																								goto IL_06f4;
																								IL_06f4:
																								num5--;
																								goto IL_0702;
																								IL_0702:
																								ptr2 += 8;
																								goto IL_1372;
																								IL_0715:
																								((delegate*<string, void>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																								goto IL_0878;
																								IL_0878:
																								num5--;
																								goto IL_0886;
																								IL_0886:
																								ptr2 += 8;
																								goto IL_1372;
																								IL_0743:
																								if (30 < b)
																								{
																									goto IL_08d3;
																								}
																								goto IL_0a6e;
																								IL_0a6e:
																								if (30 <= b)
																								{
																									goto IL_0a79;
																								}
																								goto IL_0ac3;
																								IL_0a79:
																								((delegate*<UnityEngine.Object, void>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((Class149)array3[num5 - 1]);
																								goto IL_0aa2;
																								IL_0aa2:
																								num5--;
																								goto IL_0ab0;
																								IL_0ab0:
																								ptr2 += 8;
																								goto IL_1372;
																								IL_0ac3:
																								if (29 < b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_0ad1;
																								IL_0ad1:
																								if (29 > b)
																								{
																									goto end_IL_0550;
																								}
																								goto IL_0adf;
																								IL_0adf:
																								array3[num5] = array7[*(int*)(ptr2 + num3)];
																								goto IL_0af7;
																								IL_0af7:
																								array2[num5] = 5;
																								goto IL_0b05;
																								IL_0b05:
																								num5++;
																								goto IL_0b13;
																								IL_0b13:
																								ptr2 += 8;
																								goto IL_1372;
																								IL_08d3:
																								if (31 < b)
																								{
																									goto end_IL_0550;
																								}
																								num = 174;
																								goto IL_08ea;
																								IL_0903:
																								num6 = ptr2;
																								num7 = -200;
																								num4 = 1;
																								ptr2 = num6 + num7;
																								goto IL_1372;
																							}
																							break;
																						}
																						goto IL_0bd0;
																						IL_1292:
																						array2[num5] = array2[num5 - 1];
																						num = 4;
																						goto IL_12b3;
																						IL_0bd0:
																						if (16 > b)
																						{
																							goto IL_0bde;
																						}
																						goto IL_1292;
																						IL_0bde:
																						if (8 >= b)
																						{
																							goto IL_0bec;
																						}
																						goto IL_0f39;
																						IL_0bec:
																						if (8 > b)
																						{
																							goto IL_0bfa;
																						}
																						goto IL_0f26;
																						IL_0bfa:
																						if (4 >= b)
																						{
																							goto IL_0c08;
																						}
																						goto IL_0d8b;
																						IL_0c08:
																						if (4 > b)
																						{
																							goto IL_0c16;
																						}
																						num = 134;
																						goto IL_0d2f;
																						IL_0c16:
																						if (2 >= b)
																						{
																							goto IL_0c24;
																						}
																						goto IL_0cc0;
																						IL_0c24:
																						if (2 <= b)
																						{
																							goto IL_0c2f;
																						}
																						goto IL_0c9f;
																						IL_0c2f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0c6f;
																						IL_0c6f:
																						array2[num5 - 2] = 0;
																						goto IL_0c83;
																						IL_0c83:
																						num5--;
																						num = 197;
																						goto IL_1372;
																						IL_0c9f:
																						if (1 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0cad;
																						IL_0cad:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0550;
																						IL_0cc0:
																						if (3 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0cce;
																						IL_0cce:
																						if (3 > b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0cdc;
																						IL_0cdc:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0d05;
																						IL_0d05:
																						ptr2 += 8;
																						goto IL_0d13;
																						IL_0d13:
																						num5--;
																						goto IL_1372;
																						IL_12b3:
																						array4[num5 - 0] = array4[num5 - 1];
																						num = 146;
																						goto IL_12da;
																						IL_0d2f:
																						array2[num5] = 0;
																						goto IL_0d3d;
																						IL_0d3d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0d60;
																						IL_0d60:
																						array3[num5] = null;
																						goto IL_0d6a;
																						IL_0d6a:
																						num5++;
																						goto IL_0d78;
																						IL_0d78:
																						ptr2 += 8;
																						goto IL_1372;
																						IL_0d8b:
																						if (6 < b)
																						{
																							goto IL_0d99;
																						}
																						goto IL_0e1c;
																						IL_0d99:
																						if (7 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0da7;
																						IL_0da7:
																						if (7 > b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0db5;
																						IL_0db5:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0df5;
																						IL_0df5:
																						array2[num5 - 2] = 0;
																						goto IL_0e09;
																						IL_0e09:
																						num5--;
																						goto IL_1372;
																						IL_0e1c:
																						if (6 > b)
																						{
																							goto IL_0e2a;
																						}
																						goto IL_0eb6;
																						IL_0e2a:
																						if (5 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0e38;
																						IL_0e38:
																						if (5 > b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0e46;
																						IL_0e46:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						num = 286;
																						goto IL_0e8f;
																						IL_0e8f:
																						array2[num5 - 2] = 0;
																						goto IL_0ea3;
																						IL_0ea3:
																						num5--;
																						goto IL_1372;
																						IL_0eb6:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						num = 5;
																						goto IL_0eff;
																						IL_0eff:
																						array2[num5 - 2] = 0;
																						goto IL_0f13;
																						IL_0f13:
																						num5--;
																						goto IL_1372;
																						IL_0f26:
																						num5--;
																						goto IL_1372;
																						IL_0f39:
																						if (12 < b)
																						{
																							goto IL_0f47;
																						}
																						goto IL_10f1;
																						IL_0f47:
																						if (14 >= b)
																						{
																							goto IL_0f55;
																						}
																						goto IL_1093;
																						IL_0f55:
																						if (14 <= b)
																						{
																							goto IL_0f60;
																						}
																						goto IL_0f9f;
																						IL_0f60:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_0f7e;
																						IL_0f7e:
																						ptr2 += 8;
																						goto IL_0f8c;
																						IL_0f8c:
																						num5--;
																						goto IL_1372;
																						IL_0f9f:
																						if (13 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0fad;
																						IL_0fad:
																						if (13 > b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_0fbb;
																						IL_0fbb:
																						array8 = array3;
																						num8 = num5;
																						if (array == null)
																						{
																							goto IL_0fca;
																						}
																						num9 = ptr2;
																						byte b2 = *num9;
																						ptr2 = num9 + 4;
																						int num10 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num10;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_1072;
																						IL_12da:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_12fe;
																						IL_12fe:
																						array3[num5] = array3[num5 - 1];
																						goto IL_1316;
																						IL_1316:
																						num5++;
																						goto IL_1372;
																						IL_1072:
																						array2[num5] = 5;
																						goto IL_1080;
																						IL_1080:
																						num5++;
																						goto IL_1372;
																						IL_1093:
																						if (15 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_10a1;
																						IL_10a1:
																						if (15 > b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_10af;
																						IL_10af:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_10d8;
																						IL_10d8:
																						array2[num5 - 1] = 5;
																						goto IL_1372;
																						IL_10f1:
																						if (12 <= b)
																						{
																							goto IL_1372;
																						}
																						goto IL_10ff;
																						IL_10ff:
																						if (10 >= b)
																						{
																							goto IL_110d;
																						}
																						goto IL_1210;
																						IL_110d:
																						if (10 <= b)
																						{
																							goto IL_1118;
																						}
																						goto IL_118d;
																						IL_1118:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_117a;
																						IL_117a:
																						num5 -= 2;
																						goto IL_1372;
																						IL_118d:
																						if (9 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_119b;
																						IL_119b:
																						if (9 > b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_11a9;
																						IL_11a9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_11e9;
																						IL_11e9:
																						array2[num5 - 2] = 0;
																						goto IL_11fd;
																						IL_11fd:
																						num5--;
																						goto IL_1372;
																						IL_1210:
																						if (11 < b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_121e;
																						IL_121e:
																						if (11 > b)
																						{
																							goto end_IL_0550;
																						}
																						goto IL_122c;
																						IL_122c:
																						array2[num5 - 1] = 0;
																						goto IL_1240;
																						IL_1240:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_127f;
																						IL_127f:
																						ptr2 += 8;
																						goto IL_1372;
																					}
																					goto end_IL_0560;
																					continue;
																					end_IL_0550:
																					break;
																					IL_0550:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_133f;
																			IL_1364:
																			ptr2 += 8;
																			goto IL_1372;
																			IL_1356:
																			num5++;
																			goto IL_1364;
																			IL_133f:
																			array2[num5] = 0;
																			num = 221;
																			goto IL_1356;
																			continue;
																			end_IL_0560:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0fca:
			while (true)
			{
				IL_0fca_2:
				array = new byte[4];
				while (true)
				{
					IL_0fd8:
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num5] = 5;
						while (true)
						{
							IL_1080_2:
							num5++;
							while (true)
							{
								IL_1372_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0560_2:
											if (b >= 1)
											{
												while (b <= 31)
												{
													while (true)
													{
														if (16 < b)
														{
															while (true)
															{
																if (24 >= b)
																{
																	while (true)
																	{
																		if (24 > b)
																		{
																			while (true)
																			{
																				IL_0513_2:
																				if (20 < b)
																				{
																					while (true)
																					{
																						IL_0503_2:
																						if (22 >= b)
																						{
																							while (true)
																							{
																								IL_04f0_2:
																								if (22 <= b)
																								{
																									num = 304;
																									while (true)
																									{
																										if (num != 304)
																										{
																											if (num != 1285)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 246:
																												goto IL_04f0_2;
																											case 269:
																												goto IL_0503_2;
																											case 167:
																											case 187:
																												goto IL_0513_2;
																											case 196:
																												goto end_IL_0513_2;
																											case 140:
																											case 188:
																												goto end_IL_0520;
																											case 170:
																												goto end_IL_0530;
																											case 16:
																												goto end_IL_0540;
																											case 56:
																												goto IL_0560_2;
																											case 114:
																												goto end_IL_0560_2;
																											case 177:
																											case 257:
																												goto end_IL_0570;
																											case 85:
																												goto IL_058b_2;
																											case 17:
																											case 97:
																												goto IL_0599_2;
																											case 20:
																												goto IL_05bd_2;
																											case 57:
																												goto IL_05cb_2;
																											case 205:
																												goto IL_05de_2;
																											case 220:
																											case 231:
																												goto IL_05f1_2;
																											case 169:
																												goto IL_05ff_2;
																											case 204:
																												goto IL_060d_2;
																											case 3:
																												goto IL_0618_2;
																											case 136:
																												goto IL_0626_2;
																											case 72:
																												goto IL_0634_2;
																											case 121:
																											case 211:
																												goto IL_0642_2;
																											case 147:
																												goto IL_065c_2;
																											case 135:
																											case 182:
																												goto IL_066f_2;
																											case 68:
																												goto IL_067d_2;
																											case 82:
																											case 217:
																												goto IL_068b_2;
																											case 49:
																												goto IL_069f_2;
																											case 117:
																												goto IL_06f4_2;
																											case 199:
																												goto IL_0702_2;
																											case 151:
																											case 185:
																												goto IL_0715_2;
																											case 195:
																												goto IL_0743_2;
																											case 186:
																											case 232:
																												goto IL_0756_2;
																											case 236:
																												goto IL_0794_2;
																											case 180:
																												goto end_IL_04dd_2;
																											case 101:
																												goto IL_07ad_2;
																											case 154:
																												goto IL_07bb_2;
																											case 29:
																											case 215:
																												goto IL_07c9_2;
																											case 71:
																												goto IL_07d7_2;
																											case 144:
																												goto IL_07ef_2;
																											case 96:
																												goto IL_07fd_2;
																											case 161:
																											case 219:
																												goto IL_0810_2;
																											case 107:
																											case 111:
																												goto IL_085c_2;
																											case 245:
																												goto IL_0878_2;
																											case 67:
																												goto IL_0886_2;
																											case 249:
																												goto IL_0899_2;
																											case 262:
																												goto IL_08ac_2;
																											case 173:
																												goto IL_08c0_2;
																											case 272:
																												goto IL_08d3_2;
																											case 174:
																												goto IL_08ea_2;
																											case 132:
																											case 141:
																												goto IL_0903_2;
																											case 120:
																											case 278:
																												goto IL_091f_2;
																											case 265:
																												goto IL_092d_2;
																											case 12:
																											case 240:
																												goto IL_093b_2;
																											case 122:
																												goto IL_0966_2;
																											case 290:
																												goto IL_097f_2;
																											case 2:
																											case 230:
																												goto IL_098a_2;
																											case 13:
																												goto IL_09a8_2;
																											case 252:
																												goto IL_09b6_2;
																											case 7:
																												goto IL_09c4_2;
																											case 291:
																												goto IL_09e5_2;
																											case 15:
																											case 292:
																												goto IL_09f3_2;
																											case 93:
																												goto IL_0a07_2;
																											case 88:
																												goto IL_0a3f_2;
																											case 295:
																												goto IL_0a52_2;
																											case 296:
																												goto IL_0a6e_2;
																											case 162:
																											case 178:
																												goto IL_0a79_2;
																											case 149:
																												goto IL_0aa2_2;
																											case 283:
																												goto IL_0ab0_2;
																											case 289:
																												goto IL_0ac3_2;
																											case 95:
																												goto IL_0ad1_2;
																											case 26:
																											case 104:
																												goto IL_0adf_2;
																											case 123:
																												goto IL_0af7_2;
																											case 293:
																												goto IL_0b05_2;
																											case 39:
																												goto IL_0b13_2;
																											case 276:
																												goto IL_0b26_2;
																											case 47:
																												goto IL_0b50_2;
																											case 83:
																											case 158:
																												goto IL_0b69_2;
																											case 273:
																												goto IL_0ba9_2;
																											case 223:
																												goto IL_0bbd_2;
																											case 22:
																												goto IL_0bd0_2;
																											case 115:
																												goto IL_0bde_2;
																											case 213:
																												goto IL_0bec_2;
																											case 77:
																											case 238:
																												goto IL_0bfa_2;
																											case 288:
																												goto IL_0c08_2;
																											case 6:
																												goto IL_0c16_2;
																											case 119:
																												goto IL_0c24_2;
																											case 80:
																											case 152:
																												goto IL_0c2f_2;
																											case 90:
																												goto IL_0c6f_2;
																											case 183:
																												goto IL_0c83_2;
																											case 69:
																											case 222:
																												goto IL_0c9f_2;
																											case 254:
																												goto IL_0cad_2;
																											case 261:
																												goto IL_0cc0_2;
																											case 285:
																												goto IL_0cce_2;
																											case 241:
																											case 267:
																												goto IL_0cdc_2;
																											case 51:
																												goto IL_0d05_2;
																											case 212:
																												goto IL_0d13_2;
																											case 124:
																											case 134:
																												goto IL_0d2f_2;
																											case 73:
																												goto IL_0d3d_2;
																											case 55:
																												goto IL_0d60_2;
																											case 264:
																												goto IL_0d6a_2;
																											case 284:
																												goto IL_0d78_2;
																											case 54:
																												goto IL_0d8b_2;
																											case 50:
																											case 153:
																												goto IL_0d99_2;
																											case 184:
																												goto IL_0da7_2;
																											case 190:
																											case 253:
																												goto IL_0db5_2;
																											case 66:
																												goto IL_0df5_2;
																											case 176:
																												goto IL_0e09_2;
																											case 279:
																												goto IL_0e1c_2;
																											case 103:
																											case 175:
																												goto IL_0e2a_2;
																											case 229:
																												goto IL_0e38_2;
																											case 130:
																											case 225:
																												goto IL_0e46_2;
																											case 286:
																												goto IL_0e8f_2;
																											case 268:
																												goto IL_0ea3_2;
																											case 48:
																											case 287:
																												goto IL_0eb6_2;
																											case 5:
																												goto IL_0eff_2;
																											case 53:
																												goto IL_0f13_2;
																											case 94:
																											case 270:
																												goto IL_0f26_2;
																											case 168:
																											case 247:
																												goto IL_0f39_2;
																											case 0:
																											case 24:
																												goto IL_0f47_2;
																											case 81:
																												goto IL_0f55_2;
																											case 10:
																											case 113:
																												goto IL_0f60_2;
																											case 44:
																												goto IL_0f7e_2;
																											case 32:
																												goto IL_0f8c_2;
																											case 89:
																											case 102:
																												goto IL_0f9f_2;
																											case 164:
																												goto IL_0fad_2;
																											case 19:
																											case 79:
																												goto IL_0fbb_2;
																											case 108:
																												goto end_IL_0580;
																											case 64:
																												goto IL_1080_2;
																											case 30:
																											case 34:
																												goto IL_1093_2;
																											case 160:
																												goto IL_10a1_2;
																											case 201:
																											case 297:
																												goto IL_10af_2;
																											case 126:
																												goto IL_10d8_2;
																											case 91:
																												goto IL_10f1_2;
																											case 27:
																											case 145:
																												goto IL_10ff_2;
																											case 99:
																												goto IL_110d_2;
																											case 25:
																											case 75:
																												goto IL_1118_2;
																											case 200:
																												goto IL_117a_2;
																											case 43:
																												goto IL_118d_2;
																											case 106:
																												goto IL_119b_2;
																											case 52:
																											case 138:
																												goto IL_11a9_2;
																											case 218:
																												goto IL_11e9_2;
																											case 37:
																												goto IL_11fd_2;
																											case 112:
																											case 227:
																												goto IL_1210_2;
																											case 235:
																												goto IL_121e_2;
																											case 62:
																											case 237:
																												goto IL_122c_2;
																											case 233:
																												goto IL_1240_2;
																											case 234:
																												goto IL_127f_2;
																											case 31:
																											case 110:
																												goto IL_1292_2;
																											case 4:
																												goto IL_12b3_2;
																											case 146:
																												goto IL_12da_2;
																											case 98:
																												goto IL_12fe_2;
																											case 41:
																												goto IL_1316_2;
																											case 1:
																											case 8:
																											case 18:
																											case 33:
																											case 42:
																											case 45:
																											case 46:
																											case 58:
																											case 59:
																											case 61:
																											case 65:
																											case 70:
																											case 76:
																											case 84:
																											case 87:
																											case 92:
																											case 100:
																											case 118:
																											case 125:
																											case 129:
																											case 131:
																											case 139:
																											case 150:
																											case 155:
																											case 156:
																											case 165:
																											case 171:
																											case 172:
																											case 179:
																											case 181:
																											case 191:
																											case 192:
																											case 194:
																											case 202:
																											case 206:
																											case 210:
																											case 214:
																											case 224:
																											case 242:
																											case 244:
																											case 248:
																											case 258:
																											case 259:
																											case 260:
																											case 263:
																											case 274:
																											case 275:
																											case 280:
																											case 282:
																												goto end_IL_0550_2;
																											case 78:
																												goto IL_133f_2;
																											case 221:
																												goto IL_1356_2;
																											case 159:
																												goto IL_1364_2;
																											case 9:
																											case 11:
																											case 14:
																											case 23:
																											case 28:
																											case 35:
																											case 36:
																											case 38:
																											case 40:
																											case 60:
																											case 63:
																											case 74:
																											case 105:
																											case 109:
																											case 137:
																											case 142:
																											case 143:
																											case 157:
																											case 166:
																											case 189:
																											case 193:
																											case 197:
																											case 207:
																											case 209:
																											case 216:
																											case 226:
																											case 228:
																											case 239:
																											case 243:
																											case 250:
																											case 251:
																											case 256:
																											case 266:
																											case 281:
																												goto IL_1372_2;
																											case 203:
																												ptr2 = ptr;
																												goto IL_1372_2;
																											case 21:
																												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RelativePathToCallContext.AddFieldImporterCallback);
																												goto case 203;
																											case 277:
																												array7[0] = this;
																												goto case 21;
																											case 163:
																												array7 = new object[15];
																												goto case 277;
																											case 255:
																												array6 = new long[4];
																												goto case 163;
																											case 294:
																												array5 = new int[6];
																												goto case 255;
																											case 198:
																												array4 = new int[4];
																												goto case 294;
																											case 271:
																												array3 = new object[4];
																												goto case 198;
																											case 116:
																											case 148:
																												array2 = new byte[4];
																												goto case 271;
																											case 133:
																												num3 = num2 * 4;
																												goto case 116;
																											case 127:
																												num2 = 1;
																												goto case 133;
																											case 128:
																												goto end_IL_1072;
																											case 86:
																											case 208:
																												return;
																											}
																											continue;
																										}
																										goto IL_0b26_2;
																										IL_0b26_2:
																										*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (nint)((string[])array3[num5 - 1]).LongLength;
																										goto IL_0b50_2;
																										IL_0b50_2:
																										array2[num5 - 1] = 2;
																										goto IL_1372_2;
																										continue;
																										end_IL_04dd_2:
																										break;
																									}
																									break;
																								}
																								goto IL_05de_2;
																								IL_09b6_2:
																								num5++;
																								goto IL_09c4_2;
																								IL_09c4_2:
																								ptr2 += 8;
																								goto IL_1372_2;
																								IL_05de_2:
																								if (21 < b)
																								{
																									goto end_IL_0550_2;
																								}
																								goto IL_097f_2;
																								IL_097f_2:
																								if (21 > b)
																								{
																									num = 131;
																									goto end_IL_0550_2;
																								}
																								goto IL_098a_2;
																								IL_098a_2:
																								array3[num5] = ((delegate*<string[]>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])();
																								goto IL_09a8_2;
																								IL_09a8_2:
																								array2[num5] = 5;
																								goto IL_09b6_2;
																							}
																							break;
																						}
																						goto IL_091f_2;
																						IL_0966_2:
																						array2[num5 - 1] = 0;
																						goto IL_1372_2;
																						IL_091f_2:
																						if (23 < b)
																						{
																							goto end_IL_0550_2;
																						}
																						goto IL_092d_2;
																						IL_092d_2:
																						if (23 > b)
																						{
																							goto end_IL_0550_2;
																						}
																						goto IL_093b_2;
																						IL_093b_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_0966_2;
																					}
																					goto IL_07a2_2;
																				}
																				goto IL_058b_2;
																				IL_09f3_2:
																				array2[num5 - 1] = 5;
																				goto IL_0a07_2;
																				IL_058b_2:
																				if (20 <= b)
																				{
																					goto IL_0599_2;
																				}
																				goto IL_0794_2;
																				IL_0599_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])();
																				goto IL_05bd_2;
																				IL_05bd_2:
																				array2[num5] = 0;
																				goto IL_05cb_2;
																				IL_05cb_2:
																				num5++;
																				goto IL_0899_2;
																				IL_0899_2:
																				ptr2 += 8;
																				goto IL_1372_2;
																				IL_0794_2:
																				if (18 >= b)
																				{
																					goto IL_07a2_2;
																				}
																				num = 111;
																				goto IL_085c_2;
																				IL_07a2_2:
																				if (18 > b)
																				{
																					goto IL_07ad_2;
																				}
																				goto IL_0810_2;
																				IL_07ad_2:
																				if (17 < b)
																				{
																					goto end_IL_0550_2;
																				}
																				goto IL_07bb_2;
																				IL_07bb_2:
																				if (17 > b)
																				{
																					goto end_IL_0550_2;
																				}
																				goto IL_07c9_2;
																				IL_07c9_2:
																				array2[num5] = 5;
																				goto IL_07d7_2;
																				IL_07d7_2:
																				array3[num5] = array7[*(int*)(ptr2 + num3)];
																				goto IL_07ef_2;
																				IL_07ef_2:
																				num5++;
																				goto IL_07fd_2;
																				IL_07fd_2:
																				ptr2 += 8;
																				goto IL_1372_2;
																				IL_0810_2:
																				((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																				goto IL_0a52_2;
																				IL_0a52_2:
																				num5 -= 3;
																				num = 38;
																				goto IL_1372_2;
																				IL_0a07_2:
																				array3[num5 - 1] = ((delegate*<string[], string>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																				goto IL_0a3f_2;
																				IL_085c_2:
																				if (19 < b)
																				{
																					num = 76;
																					goto end_IL_0550_2;
																				}
																				goto IL_09e5_2;
																				IL_0a3f_2:
																				ptr2 += 8;
																				goto IL_1372_2;
																				IL_09e5_2:
																				if (19 > b)
																				{
																					goto end_IL_0550_2;
																				}
																				goto IL_09f3_2;
																				continue;
																				end_IL_0513_2:
																				break;
																			}
																			continue;
																		}
																		goto IL_0b69_2;
																		IL_0bbd_2:
																		num5--;
																		goto IL_1372_2;
																		IL_0b69_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0ba9_2;
																		IL_0ba9_2:
																		array2[num5 - 2] = 0;
																		goto IL_0bbd_2;
																		continue;
																		end_IL_0520:
																		break;
																	}
																	continue;
																}
																goto IL_05f1_2;
																IL_08ea_2:
																if (31 > b)
																{
																	num = 171;
																	goto end_IL_0550_2;
																}
																goto IL_0903_2;
																IL_05f1_2:
																if (28 >= b)
																{
																	goto IL_05ff_2;
																}
																goto IL_0743_2;
																IL_05ff_2:
																if (28 > b)
																{
																	goto IL_060d_2;
																}
																goto IL_0715_2;
																IL_060d_2:
																if (26 >= b)
																{
																	goto IL_0618_2;
																}
																goto IL_066f_2;
																IL_0618_2:
																if (26 > b)
																{
																	goto IL_0626_2;
																}
																goto IL_0756_2;
																IL_0626_2:
																if (25 < b)
																{
																	goto end_IL_0550_2;
																}
																goto IL_0634_2;
																IL_0634_2:
																if (25 > b)
																{
																	goto end_IL_0550_2;
																}
																goto IL_0642_2;
																IL_0642_2:
																Class147.int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																goto IL_065c_2;
																IL_065c_2:
																num5--;
																goto IL_1372_2;
																IL_0756_2:
																array3[num5 - 2] = ((string[])array3[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																goto IL_08ac_2;
																IL_08ac_2:
																array2[num5 - 2] = 5;
																goto IL_08c0_2;
																IL_08c0_2:
																num5--;
																goto IL_1372_2;
																IL_066f_2:
																if (27 < b)
																{
																	goto end_IL_0550_2;
																}
																goto IL_067d_2;
																IL_067d_2:
																if (27 > b)
																{
																	goto end_IL_0550_2;
																}
																goto IL_068b_2;
																IL_068b_2:
																array2[num5 - 2] = 5;
																goto IL_069f_2;
																IL_069f_2:
																array3[num5 - 2] = ((delegate*<string, string, string>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((string)array3[num5 - 2], (string)array3[num5 - 1]);
																num = 117;
																goto IL_06f4_2;
																IL_06f4_2:
																num5--;
																goto IL_0702_2;
																IL_0702_2:
																ptr2 += 8;
																goto IL_1372_2;
																IL_0715_2:
																((delegate*<string, void>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																goto IL_0878_2;
																IL_0878_2:
																num5--;
																goto IL_0886_2;
																IL_0886_2:
																ptr2 += 8;
																goto IL_1372_2;
																IL_0743_2:
																if (30 < b)
																{
																	goto IL_08d3_2;
																}
																goto IL_0a6e_2;
																IL_0a6e_2:
																if (30 <= b)
																{
																	goto IL_0a79_2;
																}
																goto IL_0ac3_2;
																IL_0a79_2:
																((delegate*<UnityEngine.Object, void>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])((Class149)array3[num5 - 1]);
																goto IL_0aa2_2;
																IL_0aa2_2:
																num5--;
																goto IL_0ab0_2;
																IL_0ab0_2:
																ptr2 += 8;
																goto IL_1372_2;
																IL_0ac3_2:
																if (29 < b)
																{
																	goto end_IL_0550_2;
																}
																goto IL_0ad1_2;
																IL_0ad1_2:
																if (29 > b)
																{
																	goto end_IL_0550_2;
																}
																goto IL_0adf_2;
																IL_0adf_2:
																array3[num5] = array7[*(int*)(ptr2 + num3)];
																goto IL_0af7_2;
																IL_0af7_2:
																array2[num5] = 5;
																goto IL_0b05_2;
																IL_0b05_2:
																num5++;
																goto IL_0b13_2;
																IL_0b13_2:
																ptr2 += 8;
																goto IL_1372_2;
																IL_08d3_2:
																if (31 < b)
																{
																	goto end_IL_0550_2;
																}
																num = 174;
																goto IL_08ea_2;
																IL_0903_2:
																num6 = ptr2;
																num7 = -200;
																num4 = 1;
																ptr2 = num6 + num7;
																goto IL_1372_2;
																continue;
																end_IL_0530:
																break;
															}
															continue;
														}
														goto IL_0bd0_2;
														IL_12fe_2:
														array3[num5] = array3[num5 - 1];
														goto IL_1316_2;
														IL_0bd0_2:
														if (16 > b)
														{
															goto IL_0bde_2;
														}
														goto IL_1292_2;
														IL_0bde_2:
														if (8 >= b)
														{
															goto IL_0bec_2;
														}
														goto IL_0f39_2;
														IL_0bec_2:
														if (8 > b)
														{
															goto IL_0bfa_2;
														}
														goto IL_0f26_2;
														IL_0bfa_2:
														if (4 >= b)
														{
															goto IL_0c08_2;
														}
														goto IL_0d8b_2;
														IL_0c08_2:
														if (4 > b)
														{
															goto IL_0c16_2;
														}
														num = 134;
														goto IL_0d2f_2;
														IL_0c16_2:
														if (2 >= b)
														{
															goto IL_0c24_2;
														}
														goto IL_0cc0_2;
														IL_0c24_2:
														if (2 <= b)
														{
															goto IL_0c2f_2;
														}
														goto IL_0c9f_2;
														IL_0c2f_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0c6f_2;
														IL_0c6f_2:
														array2[num5 - 2] = 0;
														goto IL_0c83_2;
														IL_0c83_2:
														num5--;
														num = 197;
														goto IL_1372_2;
														IL_0c9f_2:
														if (1 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0cad_2;
														IL_0cad_2:
														if (1 > b)
														{
														}
														goto end_IL_0550_2;
														IL_0cc0_2:
														if (3 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0cce_2;
														IL_0cce_2:
														if (3 > b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0cdc_2;
														IL_0cdc_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0d05_2;
														IL_0d05_2:
														ptr2 += 8;
														goto IL_0d13_2;
														IL_0d13_2:
														num5--;
														goto IL_1372_2;
														IL_1316_2:
														num5++;
														goto IL_1372_2;
														IL_0d2f_2:
														array2[num5] = 0;
														goto IL_0d3d_2;
														IL_0d3d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0d60_2;
														IL_0d60_2:
														array3[num5] = null;
														goto IL_0d6a_2;
														IL_0d6a_2:
														num5++;
														goto IL_0d78_2;
														IL_0d78_2:
														ptr2 += 8;
														goto IL_1372_2;
														IL_0d8b_2:
														if (6 < b)
														{
															goto IL_0d99_2;
														}
														goto IL_0e1c_2;
														IL_0d99_2:
														if (7 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0da7_2;
														IL_0da7_2:
														if (7 > b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0db5_2;
														IL_0db5_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0df5_2;
														IL_0df5_2:
														array2[num5 - 2] = 0;
														goto IL_0e09_2;
														IL_0e09_2:
														num5--;
														goto IL_1372_2;
														IL_0e1c_2:
														if (6 > b)
														{
															goto IL_0e2a_2;
														}
														goto IL_0eb6_2;
														IL_0e2a_2:
														if (5 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0e38_2;
														IL_0e38_2:
														if (5 > b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0e46_2;
														IL_0e46_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 286;
														goto IL_0e8f_2;
														IL_0e8f_2:
														array2[num5 - 2] = 0;
														goto IL_0ea3_2;
														IL_0ea3_2:
														num5--;
														goto IL_1372_2;
														IL_0eb6_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 5;
														goto IL_0eff_2;
														IL_0eff_2:
														array2[num5 - 2] = 0;
														goto IL_0f13_2;
														IL_0f13_2:
														num5--;
														goto IL_1372_2;
														IL_0f26_2:
														num5--;
														goto IL_1372_2;
														IL_0f39_2:
														if (12 < b)
														{
															goto IL_0f47_2;
														}
														goto IL_10f1_2;
														IL_0f47_2:
														if (14 >= b)
														{
															goto IL_0f55_2;
														}
														goto IL_1093_2;
														IL_0f55_2:
														if (14 <= b)
														{
															goto IL_0f60_2;
														}
														goto IL_0f9f_2;
														IL_0f60_2:
														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
														goto IL_0f7e_2;
														IL_0f7e_2:
														ptr2 += 8;
														goto IL_0f8c_2;
														IL_0f8c_2:
														num5--;
														goto IL_1372_2;
														IL_0f9f_2:
														if (13 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0fad_2;
														IL_0fad_2:
														if (13 > b)
														{
															goto end_IL_0550_2;
														}
														goto IL_0fbb_2;
														IL_0fbb_2:
														array8 = array3;
														num8 = num5;
														if (array == null)
														{
															goto IL_0fca_2;
														}
														goto IL_0fd8;
														IL_1093_2:
														if (15 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_10a1_2;
														IL_10a1_2:
														if (15 > b)
														{
															goto end_IL_0550_2;
														}
														goto IL_10af_2;
														IL_10af_2:
														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_10d8_2;
														IL_10d8_2:
														array2[num5 - 1] = 5;
														goto IL_1372_2;
														IL_10f1_2:
														if (12 <= b)
														{
															goto IL_1372_2;
														}
														goto IL_10ff_2;
														IL_10ff_2:
														if (10 >= b)
														{
															goto IL_110d_2;
														}
														goto IL_1210_2;
														IL_110d_2:
														if (10 <= b)
														{
															goto IL_1118_2;
														}
														goto IL_118d_2;
														IL_1118_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_117a_2;
														IL_117a_2:
														num5 -= 2;
														goto IL_1372_2;
														IL_118d_2:
														if (9 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_119b_2;
														IL_119b_2:
														if (9 > b)
														{
															goto end_IL_0550_2;
														}
														goto IL_11a9_2;
														IL_11a9_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_11e9_2;
														IL_11e9_2:
														array2[num5 - 2] = 0;
														goto IL_11fd_2;
														IL_11fd_2:
														num5--;
														goto IL_1372_2;
														IL_1210_2:
														if (11 < b)
														{
															goto end_IL_0550_2;
														}
														goto IL_121e_2;
														IL_121e_2:
														if (11 > b)
														{
															goto end_IL_0550_2;
														}
														goto IL_122c_2;
														IL_122c_2:
														array2[num5 - 1] = 0;
														goto IL_1240_2;
														IL_1240_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]) = ((delegate*<int, int>)DynamicTimeZoneInformationMTAThreadAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_127f_2;
														IL_127f_2:
														ptr2 += 8;
														goto IL_1372_2;
														IL_1292_2:
														array2[num5] = array2[num5 - 1];
														num = 4;
														goto IL_12b3_2;
														IL_12b3_2:
														array4[num5 - 0] = array4[num5 - 1];
														num = 146;
														goto IL_12da_2;
														IL_12da_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_12fe_2;
														continue;
														end_IL_0540:
														break;
													}
													continue;
													end_IL_0550_2:
													break;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_133f_2;
											IL_1364_2:
											ptr2 += 8;
											goto IL_1372_2;
											IL_1356_2:
											num5++;
											goto IL_1364_2;
											IL_133f_2:
											array2[num5] = 0;
											num = 221;
											goto IL_1356_2;
											continue;
											end_IL_0560_2:
											break;
										}
										continue;
										end_IL_0570:
										break;
									}
									continue;
									end_IL_0580:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_1072:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public Class149()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3, int int_4)
	{
		int num = 35;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 107;
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_3;
										while (true)
										{
											array3[1] = int_4;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSaltPreLoadEntry.setCurrencyGroupSeparatorIMPLTYPEFLAGFSOURCE);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02b1:
																		if (b >= 1)
																		{
																			num = 102;
																			while (b <= 11)
																			{
																				while (true)
																				{
																					IL_0294:
																					if (6 >= b)
																					{
																						while (true)
																						{
																							IL_0284:
																							if (6 > b)
																							{
																								while (true)
																								{
																									IL_0274:
																									if (3 >= b)
																									{
																										while (true)
																										{
																											IL_0264:
																											if (3 <= b)
																											{
																												while (true)
																												{
																													IL_0230:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 128;
																													while (true)
																													{
																														if (num != 128)
																														{
																															if (num != 1109)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 32:
																															case 109:
																																goto IL_0230;
																															case 120:
																																goto IL_0264;
																															case 88:
																															case 117:
																																goto IL_0274;
																															case 33:
																																goto IL_0284;
																															case 28:
																																goto IL_0294;
																															case 102:
																																goto end_IL_0294;
																															case 121:
																																goto IL_02b1;
																															case 27:
																																goto end_IL_02b1;
																															case 18:
																															case 58:
																																goto end_IL_02c4;
																															case 13:
																															case 57:
																																goto IL_02df;
																															case 31:
																															case 44:
																																goto IL_02ea;
																															case 61:
																																goto IL_02f8;
																															case 67:
																																goto IL_030b;
																															case 71:
																																goto IL_0319;
																															case 22:
																																goto IL_0327;
																															case 98:
																																goto IL_033a;
																															case 15:
																																goto IL_0348;
																															case 56:
																															case 96:
																																goto IL_0356;
																															case 68:
																																goto IL_036f;
																															case 3:
																															case 12:
																																goto IL_037d;
																															case 90:
																																goto IL_03bd;
																															case 76:
																																goto IL_03d1;
																															case 10:
																																goto IL_03e4;
																															case 26:
																															case 37:
																																goto IL_03f2;
																															case 85:
																																goto IL_040b;
																															case 23:
																																goto IL_0422;
																															case 97:
																																goto IL_0430;
																															case 87:
																															case 103:
																																goto end_IL_021d;
																															case 83:
																																goto IL_0451;
																															case 93:
																																goto IL_0475;
																															case 9:
																																goto IL_0483;
																															case 52:
																															case 108:
																																goto IL_0496;
																															case 79:
																																goto IL_04a4;
																															case 78:
																															case 110:
																																goto IL_04b2;
																															case 29:
																															case 112:
																																goto IL_04ce;
																															case 24:
																																goto IL_050e;
																															case 111:
																																goto IL_0522;
																															case 113:
																																goto IL_0535;
																															case 101:
																																goto IL_0540;
																															case 94:
																																goto IL_0553;
																															case 92:
																																goto IL_0561;
																															case 70:
																															case 99:
																																goto IL_056f;
																															case 6:
																																goto IL_057d;
																															case 49:
																																goto IL_05a0;
																															case 40:
																																goto IL_05aa;
																															case 41:
																																goto IL_05b8;
																															case 77:
																															case 115:
																																goto IL_05cb;
																															case 116:
																																goto IL_05de;
																															case 100:
																															case 119:
																																goto IL_05f1;
																															case 84:
																																goto IL_063a;
																															case 21:
																																goto IL_064e;
																															case 2:
																																goto IL_066f;
																															case 69:
																															case 80:
																																goto IL_0682;
																															case 65:
																																goto IL_06cb;
																															case 118:
																																goto IL_06e8;
																															case 1:
																															case 7:
																															case 8:
																															case 19:
																															case 25:
																															case 39:
																															case 43:
																															case 45:
																															case 46:
																															case 50:
																															case 51:
																															case 59:
																															case 62:
																															case 63:
																															case 66:
																															case 75:
																															case 81:
																															case 86:
																															case 89:
																															case 95:
																															case 114:
																																goto end_IL_02a1;
																															case 55:
																																goto IL_0724;
																															case 53:
																																goto IL_0732;
																															case 106:
																																goto IL_0749;
																															case 4:
																															case 5:
																															case 14:
																															case 16:
																															case 42:
																															case 60:
																															case 64:
																															case 72:
																															case 73:
																															case 74:
																															case 82:
																															case 104:
																															case 105:
																																goto end_IL_02d4;
																															case 91:
																																goto end_IL_0757;
																															case 30:
																																goto end_IL_076a;
																															case 36:
																																goto end_IL_0774;
																															case 17:
																																goto end_IL_077f;
																															case 47:
																																goto end_IL_0794;
																															case 107:
																																goto end_IL_07a9;
																															case 11:
																																goto end_IL_07b9;
																															case 54:
																																goto end_IL_07c9;
																															case 38:
																															case 48:
																																goto end_IL_07d4;
																															case 34:
																																goto end_IL_07e4;
																															case 35:
																																goto end_IL_07f4;
																															case 0:
																															case 20:
																																goto IL_080f;
																															}
																															continue;
																														}
																														ptr2 += 8;
																														goto IL_066f;
																														IL_066f:
																														num5--;
																														goto end_IL_02d4;
																														continue;
																														end_IL_021d:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_030b;
																											IL_05de:
																											if (1 <= b)
																											{
																											}
																											goto end_IL_02a1;
																											IL_030b:
																											if (1 < b)
																											{
																												goto IL_0319;
																											}
																											goto IL_05de;
																											IL_0319:
																											if (2 < b)
																											{
																												goto end_IL_02a1;
																											}
																											goto IL_0327;
																											IL_0327:
																											if (2 > b)
																											{
																												goto end_IL_02a1;
																											}
																											goto IL_04ce;
																											IL_04ce:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_050e;
																											IL_050e:
																											array[num5 - 2] = 0;
																											goto IL_0522;
																											IL_0522:
																											num5--;
																											goto end_IL_02d4;
																										}
																										break;
																									}
																									goto IL_0535;
																									IL_05b8:
																									ptr2 += 8;
																									goto end_IL_02d4;
																									IL_0535:
																									if (4 >= b)
																									{
																										goto IL_0540;
																									}
																									goto IL_0553;
																									IL_0540:
																									if (4 > b)
																									{
																										goto end_IL_02a1;
																									}
																									goto IL_05f1;
																									IL_05f1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 84;
																									goto IL_063a;
																									IL_063a:
																									array[num5 - 2] = 0;
																									goto IL_064e;
																									IL_064e:
																									num5--;
																									goto end_IL_02d4;
																									IL_0553:
																									if (5 < b)
																									{
																										goto end_IL_02a1;
																									}
																									goto IL_0561;
																									IL_0561:
																									if (5 > b)
																									{
																										goto end_IL_02a1;
																									}
																									goto IL_056f;
																									IL_056f:
																									array[num5] = 0;
																									goto IL_057d;
																									IL_057d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_05a0;
																									IL_05a0:
																									array2[num5] = null;
																									goto IL_05aa;
																									IL_05aa:
																									num5++;
																									goto IL_05b8;
																								}
																								break;
																							}
																							goto IL_0682;
																							IL_06e8:
																							num5--;
																							num = 42;
																							goto end_IL_02d4;
																							IL_0682:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 65;
																							goto IL_06cb;
																							IL_06cb:
																							array[num5 - 2] = 0;
																							num = 118;
																							goto IL_06e8;
																						}
																						goto IL_0443;
																					}
																					goto IL_02df;
																					IL_0475:
																					num5++;
																					goto IL_0483;
																					IL_02df:
																					if (9 < b)
																					{
																						goto IL_02ea;
																					}
																					goto IL_033a;
																					IL_02ea:
																					if (10 >= b)
																					{
																						goto IL_02f8;
																					}
																					goto IL_0496;
																					IL_02f8:
																					if (10 > b)
																					{
																						goto end_IL_02a1;
																					}
																					goto IL_05cb;
																					IL_05cb:
																					num5--;
																					goto end_IL_02d4;
																					IL_0496:
																					if (11 < b)
																					{
																						goto end_IL_02a1;
																					}
																					goto IL_04a4;
																					IL_04a4:
																					if (11 > b)
																					{
																						goto end_IL_02a1;
																					}
																					goto IL_04b2;
																					IL_04b2:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02d4;
																					IL_033a:
																					if (9 > b)
																					{
																						goto IL_0348;
																					}
																					goto IL_0443;
																					IL_0348:
																					if (7 < b)
																					{
																						goto IL_0356;
																					}
																					goto IL_03e4;
																					IL_0356:
																					if (8 < b)
																					{
																						num = 75;
																						goto end_IL_02a1;
																					}
																					goto IL_036f;
																					IL_0483:
																					ptr2 += 8;
																					goto end_IL_02d4;
																					IL_036f:
																					if (8 > b)
																					{
																						goto end_IL_02a1;
																					}
																					goto IL_037d;
																					IL_037d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03bd;
																					IL_03bd:
																					array[num5 - 2] = 0;
																					goto IL_03d1;
																					IL_03d1:
																					num5--;
																					goto end_IL_02d4;
																					IL_03e4:
																					if (7 > b)
																					{
																						goto end_IL_02a1;
																					}
																					goto IL_03f2;
																					IL_03f2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_040b;
																					IL_040b:
																					array[num5] = 0;
																					num = 23;
																					goto IL_0422;
																					IL_0422:
																					num5++;
																					goto IL_0430;
																					IL_0430:
																					ptr2 += 8;
																					goto end_IL_02d4;
																					IL_0443:
																					array[num5] = 0;
																					goto IL_0451;
																					IL_0451:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)CryptoStreamModeCurrentThreadActivityId[*(int*)(ptr2 + num3)])();
																					goto IL_0475;
																					continue;
																					end_IL_0294:
																					break;
																				}
																				continue;
																				end_IL_02a1:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0724;
																		IL_0732:
																		num5++;
																		num = 106;
																		goto IL_0749;
																		IL_0749:
																		ptr2 += 8;
																		goto end_IL_02d4;
																		IL_0724:
																		array[num5] = 0;
																		goto IL_0732;
																		continue;
																		end_IL_02b1:
																		break;
																	}
																	continue;
																	end_IL_02c4:
																	break;
																}
																continue;
																end_IL_02d4:
																break;
															}
															continue;
														}
														goto IL_080f;
														IL_080f:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0757:
														break;
													}
													continue;
													end_IL_076a:
													break;
												}
												continue;
												end_IL_0774:
												break;
											}
											continue;
											end_IL_077f:
											break;
										}
										continue;
										end_IL_0794:
										break;
									}
									continue;
									end_IL_07a9:
									break;
								}
								continue;
								end_IL_07b9:
								break;
							}
							continue;
							end_IL_07c9:
							break;
						}
						continue;
						end_IL_07d4:
						break;
					}
					continue;
					end_IL_07e4:
					break;
				}
				continue;
				end_IL_07f4:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_3)
	{
		int num = 38;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 37;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InfrastructureelemdescVar.ReadFromUnderlyingStreamAsyncdIEEERemainder);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_029c:
														byte b = *ptr2;
														while (true)
														{
															IL_028c:
															ptr2++;
															while (true)
															{
																IL_027f:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_025f:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_024f:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_023f:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_0232:
																									if (2 <= b)
																									{
																										while (true)
																										{
																											IL_0207:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											while (true)
																											{
																												IL_01f7:
																												ptr2 += 8;
																												while (true)
																												{
																													IL_01de:
																													num5--;
																													num = 111;
																													while (num != 111)
																													{
																														if (num != 1092)
																														{
																															goto IL_0584;
																														}
																														switch (num)
																														{
																														case 52:
																															goto IL_01de;
																														case 47:
																															goto IL_01f7;
																														case 16:
																														case 62:
																															goto IL_0207;
																														case 66:
																															goto IL_0232;
																														case 22:
																															goto IL_023f;
																														case 57:
																															goto IL_024f;
																														case 87:
																															goto IL_025f;
																														case 86:
																															goto IL_026f;
																														case 58:
																															goto IL_027f;
																														case 53:
																															goto IL_028c;
																														case 6:
																														case 71:
																															goto IL_029c;
																														case 0:
																														case 90:
																															goto IL_02b5;
																														case 44:
																															goto IL_02c3;
																														case 55:
																														case 76:
																															goto IL_02d1;
																														case 46:
																															goto IL_02f3;
																														case 39:
																															goto IL_0301;
																														case 67:
																															goto IL_030f;
																														case 41:
																														case 96:
																															goto IL_0322;
																														case 73:
																															goto IL_0330;
																														case 3:
																															goto IL_0353;
																														case 7:
																															goto IL_035d;
																														case 104:
																															goto IL_036b;
																														case 48:
																															goto IL_037e;
																														case 68:
																														case 94:
																															goto IL_0389;
																														case 30:
																															goto IL_0397;
																														case 2:
																															goto IL_03aa;
																														case 35:
																														case 78:
																															goto IL_03b8;
																														case 25:
																															goto IL_03d0;
																														case 20:
																															goto IL_03de;
																														case 74:
																														case 84:
																															goto IL_03ec;
																														case 97:
																															goto IL_03f7;
																														case 27:
																														case 91:
																															goto IL_0405;
																														case 50:
																															goto IL_0445;
																														case 18:
																															goto IL_0459;
																														case 70:
																															goto IL_046c;
																														case 98:
																															goto IL_047a;
																														case 11:
																														case 93:
																															goto IL_0488;
																														case 95:
																															goto IL_04ab;
																														case 54:
																															goto IL_04b9;
																														case 29:
																															goto IL_04c7;
																														case 28:
																														case 85:
																															goto IL_04da;
																														case 77:
																															goto IL_053c;
																														case 17:
																														case 101:
																															goto IL_0555;
																														case 69:
																															goto IL_0560;
																														case 21:
																														case 23:
																															goto IL_056b;
																														case 100:
																															goto IL_0584;
																														case 99:
																															goto IL_058f;
																														case 4:
																														case 8:
																														case 10:
																														case 12:
																														case 13:
																														case 14:
																														case 19:
																														case 26:
																														case 34:
																														case 45:
																														case 49:
																														case 51:
																														case 59:
																														case 61:
																														case 64:
																														case 75:
																														case 80:
																														case 81:
																														case 89:
																														case 102:
																															goto end_IL_026f;
																														case 1:
																														case 9:
																														case 15:
																														case 24:
																														case 31:
																														case 33:
																														case 43:
																														case 60:
																														case 65:
																														case 72:
																														case 79:
																														case 88:
																															goto end_IL_01cb;
																														case 32:
																															goto end_IL_05ad;
																														case 36:
																															goto end_IL_05c0;
																														case 83:
																															goto end_IL_05ca;
																														case 42:
																															goto end_IL_05d5;
																														case 63:
																														case 82:
																															goto end_IL_05ea;
																														case 40:
																															goto end_IL_05fa;
																														case 5:
																														case 103:
																															goto end_IL_060a;
																														case 37:
																															goto end_IL_061a;
																														case 38:
																															goto end_IL_062a;
																														case 56:
																														case 92:
																															goto IL_064e;
																														}
																														continue;
																														end_IL_01cb:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_02b5;
																									IL_030f:
																									ptr2 += 8;
																									break;
																									IL_02b5:
																									if (1 < b)
																									{
																										goto end_IL_026f;
																									}
																									goto IL_02c3;
																									IL_02c3:
																									if (1 > b)
																									{
																										goto end_IL_026f;
																									}
																									goto IL_02d1;
																									IL_02d1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									num = 46;
																									goto IL_02f3;
																									IL_02f3:
																									array[num5] = 0;
																									goto IL_0301;
																									IL_0301:
																									num5++;
																									goto IL_030f;
																								}
																								break;
																							}
																							goto IL_037e;
																							IL_03b8:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							break;
																							IL_037e:
																							if (3 < b)
																							{
																								goto IL_0389;
																							}
																							goto IL_03aa;
																							IL_0389:
																							if (4 < b)
																							{
																								goto end_IL_026f;
																							}
																							goto IL_0397;
																							IL_0397:
																							if (4 > b)
																							{
																								goto end_IL_026f;
																							}
																							break;
																							IL_03aa:
																							if (3 > b)
																							{
																								goto end_IL_026f;
																							}
																							goto IL_03b8;
																						}
																						break;
																					}
																					goto IL_0322;
																					IL_036b:
																					ptr2 += 8;
																					break;
																					IL_0322:
																					array[num5] = 0;
																					goto IL_0330;
																					IL_0330:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0353;
																					IL_0353:
																					array2[num5] = null;
																					goto IL_035d;
																					IL_035d:
																					num5++;
																					goto IL_036b;
																				}
																				break;
																			}
																			goto IL_03d0;
																			IL_0584:
																			if (10 < b)
																			{
																				goto end_IL_026f;
																			}
																			goto IL_058f;
																			IL_03d0:
																			if (8 >= b)
																			{
																				goto IL_03de;
																			}
																			num = 17;
																			goto IL_0555;
																			IL_03de:
																			if (8 > b)
																			{
																				goto IL_03ec;
																			}
																			goto IL_04da;
																			IL_03ec:
																			if (6 >= b)
																			{
																				goto IL_03f7;
																			}
																			goto IL_046c;
																			IL_03f7:
																			if (6 > b)
																			{
																				goto end_IL_026f;
																			}
																			goto IL_0405;
																			IL_0405:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0445;
																			IL_0445:
																			array[num5 - 2] = 0;
																			goto IL_0459;
																			IL_0459:
																			num5--;
																			break;
																			IL_046c:
																			if (7 < b)
																			{
																				goto end_IL_026f;
																			}
																			goto IL_047a;
																			IL_047a:
																			if (7 > b)
																			{
																				goto end_IL_026f;
																			}
																			goto IL_0488;
																			IL_0488:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04ab;
																			IL_04ab:
																			array[num5] = 0;
																			goto IL_04b9;
																			IL_04b9:
																			num5++;
																			goto IL_04c7;
																			IL_04c7:
																			ptr2 += 8;
																			break;
																			IL_04da:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_053c;
																			IL_053c:
																			num5 -= 2;
																			break;
																			IL_058f:
																			if (10 <= b)
																			{
																			}
																			goto end_IL_026f;
																			IL_0555:
																			if (9 >= b)
																			{
																				goto IL_0560;
																			}
																			goto IL_0584;
																			IL_0560:
																			if (9 > b)
																			{
																				goto end_IL_026f;
																			}
																			goto IL_056b;
																			IL_056b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																		}
																		goto end_IL_027f;
																		continue;
																		end_IL_026f:
																		break;
																		IL_026f:;
																	}
																}
																else
																{
																	num = 14;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_027f:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_064e;
												IL_064e:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ad:
												break;
											}
											continue;
											end_IL_05c0:
											break;
										}
										continue;
										end_IL_05ca:
										break;
									}
									continue;
									end_IL_05d5:
									break;
								}
								continue;
								end_IL_05ea:
								break;
							}
							continue;
							end_IL_05fa:
							break;
						}
						continue;
						end_IL_060a:
						break;
					}
					continue;
					end_IL_061a:
					break;
				}
				continue;
				end_IL_062a:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 83;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 112;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReferenceEqualsParseFailureKind.getMessageIdCompatibleFrameworksMetadataSupportUrl);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0342:
														byte b = *ptr2;
														while (true)
														{
															IL_0332:
															ptr2++;
															while (true)
															{
																IL_031f:
																if (b >= 1)
																{
																	num = 21;
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_02ff:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_02e2:
																						if (4 < b)
																						{
																							while (true)
																							{
																								IL_02d2:
																								if (6 < b)
																								{
																									num = 165;
																									while (true)
																									{
																										if (num != 165)
																										{
																											if (num != 1146)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 110:
																												goto IL_02d2;
																											case 88:
																												goto IL_02e2;
																											case 89:
																												goto IL_02ef;
																											case 64:
																												goto IL_02ff;
																											case 21:
																												goto IL_030f;
																											case 98:
																												goto IL_031f;
																											case 54:
																												goto IL_0332;
																											case 69:
																											case 74:
																												goto IL_0342;
																											case 9:
																												goto IL_034d;
																											case 66:
																												goto IL_0360;
																											case 78:
																												goto IL_036b;
																											case 30:
																												goto IL_0376;
																											case 8:
																												goto IL_0384;
																											case 80:
																												goto IL_0392;
																											case 23:
																											case 108:
																												goto IL_03ae;
																											case 12:
																												goto IL_03cc;
																											case 38:
																												goto IL_03da;
																											case 136:
																												goto IL_03ed;
																											case 107:
																												goto IL_03fb;
																											case 3:
																											case 133:
																												goto IL_0409;
																											case 114:
																												goto IL_0432;
																											case 102:
																											case 137:
																												goto IL_044b;
																											case 14:
																												goto IL_048a;
																											case 19:
																											case 151:
																												goto IL_049d;
																											case 93:
																												goto IL_04dd;
																											case 134:
																												goto IL_04f1;
																											case 92:
																											case 154:
																												goto IL_0504;
																											case 42:
																												goto IL_051d;
																											case 153:
																												goto IL_052b;
																											case 7:
																												goto IL_0539;
																											case 10:
																											case 158:
																												goto IL_054c;
																											case 70:
																												goto IL_055a;
																											case 57:
																											case 96:
																												goto IL_0568;
																											case 72:
																												goto IL_0576;
																											case 152:
																												goto IL_058e;
																											case 56:
																												goto IL_059c;
																											case 61:
																												goto IL_05af;
																											case 24:
																											case 52:
																												goto IL_05ba;
																											case 2:
																												goto IL_05c8;
																											case 104:
																											case 128:
																												goto IL_05d6;
																											case 141:
																												goto IL_05ee;
																											case 35:
																											case 75:
																												goto IL_05fc;
																											case 142:
																												goto IL_0625;
																											case 106:
																												goto IL_0633;
																											case 118:
																												goto IL_0646;
																											case 13:
																											case 46:
																												goto IL_0654;
																											case 36:
																												goto IL_0662;
																											case 28:
																											case 32:
																												goto IL_0670;
																											case 68:
																												goto IL_067e;
																											case 37:
																											case 130:
																												goto IL_068c;
																											case 135:
																												goto IL_06a0;
																											case 33:
																												goto IL_06f4;
																											case 105:
																												goto IL_0702;
																											case 63:
																											case 115:
																												goto IL_0715;
																											case 16:
																											case 97:
																												goto IL_0728;
																											case 34:
																											case 120:
																												goto IL_0733;
																											case 140:
																												goto IL_0741;
																											case 27:
																												goto IL_0754;
																											case 31:
																											case 117:
																												goto IL_0762;
																											case 15:
																												goto IL_077e;
																											case 85:
																												goto IL_078c;
																											case 59:
																												goto IL_079a;
																											case 119:
																												goto IL_07a8;
																											case 127:
																											case 144:
																												goto IL_07b6;
																											case 79:
																												goto IL_07f6;
																											case 103:
																												goto IL_080a;
																											case 148:
																												goto IL_0826;
																											case 84:
																											case 99:
																												goto IL_0834;
																											case 40:
																												goto IL_0842;
																											case 65:
																											case 77:
																												goto IL_0859;
																											case 87:
																												goto IL_0867;
																											case 123:
																												goto IL_088a;
																											case 91:
																												goto IL_0894;
																											case 90:
																												goto IL_08a2;
																											case 132:
																											case 155:
																												goto IL_08b5;
																											case 100:
																												goto IL_08f9;
																											case 43:
																												goto IL_090d;
																											case 101:
																											case 147:
																												goto IL_0920;
																											case 121:
																												goto IL_0982;
																											case 1:
																											case 4:
																											case 5:
																											case 18:
																											case 26:
																											case 39:
																											case 41:
																											case 47:
																											case 48:
																											case 51:
																											case 55:
																											case 73:
																											case 76:
																											case 81:
																											case 95:
																											case 109:
																											case 113:
																											case 122:
																											case 124:
																											case 125:
																											case 126:
																											case 145:
																											case 150:
																											case 156:
																												goto end_IL_02bf;
																											case 0:
																											case 6:
																											case 22:
																											case 25:
																											case 29:
																											case 44:
																											case 45:
																											case 50:
																											case 53:
																											case 60:
																											case 67:
																											case 86:
																											case 94:
																											case 116:
																											case 131:
																											case 138:
																											case 139:
																											case 146:
																											case 149:
																											case 157:
																												goto end_IL_02ef;
																											case 62:
																												goto end_IL_09ae;
																											case 111:
																												goto end_IL_09c1;
																											case 71:
																												goto end_IL_09cb;
																											case 58:
																												goto end_IL_09d6;
																											case 11:
																											case 129:
																												goto end_IL_09e6;
																											case 49:
																												goto end_IL_09f6;
																											case 20:
																											case 112:
																												goto end_IL_0a06;
																											case 82:
																												goto end_IL_0a16;
																											case 83:
																												goto end_IL_0a26;
																											case 17:
																											case 143:
																												goto IL_0a4a;
																											}
																											continue;
																										}
																										goto IL_05af;
																										IL_0625:
																										ptr2 += 8;
																										goto IL_0633;
																										IL_0633:
																										num5--;
																										goto end_IL_02ef;
																										IL_05af:
																										if (7 < b)
																										{
																											goto IL_05ba;
																										}
																										goto IL_05ee;
																										IL_05ba:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_05c8;
																										IL_05c8:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_05d6;
																										IL_05d6:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_02ef;
																										IL_05ee:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_05fc;
																										IL_05fc:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0625;
																										continue;
																										end_IL_02bf:
																										break;
																									}
																									break;
																								}
																								goto IL_034d;
																								IL_044b:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_048a;
																								IL_048a:
																								num5 -= 3;
																								goto end_IL_02ef;
																								IL_034d:
																								if (6 <= b)
																								{
																									goto IL_044b;
																								}
																								goto IL_054c;
																								IL_054c:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_055a;
																								IL_055a:
																								if (5 > b)
																								{
																									break;
																								}
																								goto IL_0568;
																								IL_0568:
																								array[num5] = 5;
																								goto IL_0576;
																								IL_0576:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_058e;
																								IL_058e:
																								num5++;
																								goto IL_059c;
																								IL_059c:
																								ptr2 += 8;
																								goto end_IL_02ef;
																							}
																							break;
																						}
																						goto IL_0360;
																						IL_03cc:
																						ptr2 += 8;
																						goto IL_03da;
																						IL_0360:
																						if (4 > b)
																						{
																							goto IL_036b;
																						}
																						goto IL_03ae;
																						IL_036b:
																						if (2 >= b)
																						{
																							goto IL_0376;
																						}
																						goto IL_03ed;
																						IL_0376:
																						if (2 > b)
																						{
																							goto IL_0384;
																						}
																						goto IL_049d;
																						IL_0384:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_0392;
																						IL_0392:
																						if (1 > b)
																						{
																							break;
																						}
																						num = 154;
																						goto IL_0504;
																						IL_03da:
																						num5--;
																						goto end_IL_02ef;
																						IL_0504:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_051d;
																						IL_051d:
																						array[num5] = 0;
																						goto IL_052b;
																						IL_052b:
																						num5++;
																						goto IL_0539;
																						IL_0539:
																						ptr2 += 8;
																						goto end_IL_02ef;
																						IL_049d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04dd;
																						IL_04dd:
																						array[num5 - 2] = 0;
																						goto IL_04f1;
																						IL_04f1:
																						num5--;
																						goto end_IL_02ef;
																						IL_03ed:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_03fb;
																						IL_03fb:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_0409;
																						IL_0409:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_0432;
																						IL_0432:
																						array[num5 - 1] = 5;
																						goto end_IL_02ef;
																						IL_03ae:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_03cc;
																					}
																					goto end_IL_030f;
																					continue;
																					end_IL_02ef:
																					break;
																					IL_02ef:;
																				}
																				break;
																			}
																			goto IL_0646;
																			IL_0920:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0982;
																			IL_0646:
																			if (13 < b)
																			{
																				goto IL_0654;
																			}
																			goto IL_077e;
																			IL_0654:
																			if (15 >= b)
																			{
																				goto IL_0662;
																			}
																			goto IL_0728;
																			IL_0662:
																			if (15 > b)
																			{
																				goto IL_0670;
																			}
																			goto IL_0715;
																			IL_0670:
																			if (14 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_067e;
																			IL_067e:
																			if (14 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_068c;
																			IL_068c:
																			array[num5 - 2] = 0;
																			goto IL_06a0;
																			IL_06a0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)AssemblyAttributesGoHereDebuggerStepperBoundaryAttribute[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_06f4;
																			IL_06f4:
																			num5--;
																			goto IL_0702;
																			IL_0702:
																			ptr2 += 8;
																			break;
																			IL_0715:
																			num5--;
																			break;
																			IL_0728:
																			if (16 < b)
																			{
																				goto IL_0733;
																			}
																			goto IL_0754;
																			IL_0733:
																			if (17 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_0741;
																			IL_0741:
																			if (17 > b)
																			{
																			}
																			goto end_IL_030f;
																			IL_0754:
																			if (16 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_0762;
																			IL_0762:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_077e:
																			if (13 > b)
																			{
																				goto IL_078c;
																			}
																			goto IL_0920;
																			IL_078c:
																			if (11 < b)
																			{
																				goto IL_079a;
																			}
																			goto IL_0826;
																			IL_079a:
																			if (12 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_07a8;
																			IL_07a8:
																			if (12 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_07b6;
																			IL_07b6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07f6;
																			IL_07f6:
																			array[num5 - 2] = 0;
																			goto IL_080a;
																			IL_080a:
																			num5--;
																			num = 60;
																			break;
																			IL_0826:
																			if (11 > b)
																			{
																				goto IL_0834;
																			}
																			goto IL_08b5;
																			IL_0834:
																			if (10 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_0842;
																			IL_0842:
																			if (10 > b)
																			{
																				goto end_IL_030f;
																			}
																			num = 65;
																			goto IL_0859;
																			IL_0982:
																			num5 -= 2;
																			break;
																			IL_0859:
																			array[num5] = 0;
																			goto IL_0867;
																			IL_0867:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_088a;
																			IL_088a:
																			array2[num5] = null;
																			goto IL_0894;
																			IL_0894:
																			num5++;
																			goto IL_08a2;
																			IL_08a2:
																			ptr2 += 8;
																			break;
																			IL_08b5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_08f9;
																			IL_08f9:
																			array[num5 - 2] = 0;
																			goto IL_090d;
																			IL_090d:
																			num5--;
																			break;
																		}
																		goto end_IL_031f;
																		continue;
																		end_IL_030f:
																		break;
																		IL_030f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 53;
																break;
																continue;
																end_IL_031f:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a4a;
												IL_0a4a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09ae:
												break;
											}
											continue;
											end_IL_09c1:
											break;
										}
										continue;
										end_IL_09cb:
										break;
									}
									continue;
									end_IL_09d6:
									break;
								}
								continue;
								end_IL_09e6:
								break;
							}
							continue;
							end_IL_09f6:
							break;
						}
						continue;
						end_IL_0a06:
						break;
					}
					continue;
					end_IL_0a16:
					break;
				}
				continue;
				end_IL_0a26:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 146;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 91;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 68;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SafeAccessTokenHandlegetAreAccessRulesCanonical.UnstartedgetPositiveSign);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_033d:
															byte b = *ptr2;
															while (true)
															{
																IL_032d:
																ptr2++;
																while (true)
																{
																	IL_0320:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0300:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02f0:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02e0:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_02d3:
																										if (10 >= b)
																										{
																											while (true)
																											{
																												IL_02c3:
																												if (10 > b)
																												{
																													while (9 >= b)
																													{
																														while (9 > b)
																														{
																															num = 156;
																															while (num != 156)
																															{
																																if (num != 1137)
																																{
																																	goto IL_0788;
																																}
																																switch (num)
																																{
																																case 32:
																																	goto IL_02a0;
																																case 6:
																																case 55:
																																	goto IL_02b3;
																																case 63:
																																	goto IL_02c3;
																																case 16:
																																case 60:
																																	goto IL_02d3;
																																case 139:
																																	goto IL_02e0;
																																case 2:
																																case 35:
																																	goto IL_02f0;
																																case 23:
																																	goto IL_0300;
																																case 144:
																																	goto IL_0310;
																																case 45:
																																	goto IL_0320;
																																case 141:
																																	goto IL_032d;
																																case 29:
																																case 80:
																																	goto IL_033d;
																																case 58:
																																case 87:
																																	goto IL_0356;
																																case 51:
																																	goto IL_0364;
																																case 84:
																																case 88:
																																	goto IL_0372;
																																case 4:
																																	goto IL_03b6;
																																case 86:
																																	goto IL_03ca;
																																case 109:
																																case 127:
																																	goto IL_03dd;
																																case 114:
																																	goto IL_03eb;
																																case 66:
																																	goto IL_040e;
																																case 116:
																																	goto IL_0418;
																																case 70:
																																	goto IL_0426;
																																case 102:
																																case 149:
																																	goto IL_0439;
																																case 106:
																																	goto IL_0479;
																																case 37:
																																	goto IL_048d;
																																case 123:
																																	goto IL_04a0;
																																case 131:
																																case 140:
																																	goto IL_04ab;
																																case 64:
																																	goto IL_04b9;
																																case 27:
																																	goto IL_04cc;
																																case 20:
																																case 85:
																																	goto IL_04da;
																																case 71:
																																	goto IL_04e8;
																																case 19:
																																case 75:
																																	goto IL_04f6;
																																case 119:
																																	goto IL_0558;
																																case 72:
																																case 118:
																																	goto IL_056b;
																																case 98:
																																	goto IL_0587;
																																case 99:
																																case 148:
																																	goto IL_0592;
																																case 40:
																																	goto IL_05aa;
																																case 8:
																																	goto IL_05b8;
																																case 81:
																																case 112:
																																	goto IL_05c3;
																																case 76:
																																	goto IL_05d1;
																																case 42:
																																case 49:
																																	goto IL_05e8;
																																case 136:
																																	goto IL_0611;
																																case 83:
																																	goto IL_0628;
																																case 79:
																																	goto IL_063b;
																																case 17:
																																case 134:
																																	goto IL_0646;
																																case 126:
																																	goto IL_0685;
																																case 1:
																																case 82:
																																	goto IL_06a1;
																																case 11:
																																	goto IL_06af;
																																case 47:
																																case 77:
																																	goto IL_06bd;
																																case 9:
																																	goto IL_06cb;
																																case 13:
																																	goto IL_06e3;
																																case 97:
																																	goto IL_06f1;
																																case 21:
																																	goto IL_070d;
																																case 107:
																																case 117:
																																	goto IL_071b;
																																case 62:
																																	goto IL_0729;
																																case 34:
																																case 142:
																																	goto IL_0734;
																																case 120:
																																	goto IL_0774;
																																case 52:
																																	goto IL_0788;
																																case 90:
																																	goto IL_079b;
																																case 67:
																																	goto IL_07a9;
																																case 10:
																																case 78:
																																	goto IL_07b7;
																																case 129:
																																	goto IL_07d0;
																																case 39:
																																	goto IL_07de;
																																case 12:
																																	goto IL_07ec;
																																case 96:
																																	goto IL_07ff;
																																case 0:
																																	goto IL_080d;
																																case 31:
																																case 95:
																																	goto IL_081b;
																																case 43:
																																	goto IL_084d;
																																case 100:
																																case 104:
																																	goto IL_0863;
																																case 125:
																																	goto IL_0881;
																																case 5:
																																	goto IL_088f;
																																case 14:
																																case 18:
																																case 22:
																																case 25:
																																case 26:
																																case 28:
																																case 36:
																																case 41:
																																case 44:
																																case 56:
																																case 57:
																																case 61:
																																case 69:
																																case 73:
																																case 93:
																																case 94:
																																case 105:
																																case 110:
																																case 115:
																																case 122:
																																case 128:
																																case 132:
																																case 133:
																																case 135:
																																case 137:
																																case 138:
																																	goto end_IL_028d;
																																case 3:
																																case 7:
																																case 15:
																																case 24:
																																case 30:
																																case 46:
																																case 48:
																																case 50:
																																case 53:
																																case 54:
																																case 59:
																																case 65:
																																case 74:
																																case 89:
																																case 101:
																																case 103:
																																case 113:
																																case 147:
																																	goto end_IL_02a0;
																																case 38:
																																	goto end_IL_08b2;
																																case 124:
																																	goto end_IL_08c5;
																																case 121:
																																	goto end_IL_08cf;
																																case 143:
																																	goto end_IL_08da;
																																case 68:
																																	goto end_IL_08ea;
																																case 33:
																																	goto end_IL_08fa;
																																case 91:
																																	goto end_IL_090a;
																																case 92:
																																case 108:
																																	goto end_IL_0915;
																																case 145:
																																	goto end_IL_0925;
																																case 146:
																																	goto end_IL_093e;
																																case 111:
																																case 130:
																																	goto IL_0959;
																																}
																																continue;
																																end_IL_028d:
																																break;
																															}
																															goto end_IL_02b3;
																															continue;
																															end_IL_02a0:
																															break;
																															IL_02a0:;
																														}
																														goto end_IL_0320;
																														continue;
																														end_IL_02b3:
																														break;
																														IL_02b3:;
																													}
																													break;
																												}
																												goto IL_03dd;
																												IL_0426:
																												ptr2 += 8;
																												goto end_IL_0320;
																												IL_03dd:
																												array[num5] = 0;
																												goto IL_03eb;
																												IL_03eb:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_040e;
																												IL_040e:
																												array2[num5] = null;
																												goto IL_0418;
																												IL_0418:
																												num5++;
																												goto IL_0426;
																											}
																											break;
																										}
																										goto IL_0356;
																										IL_03ca:
																										num5--;
																										goto end_IL_0320;
																										IL_0356:
																										if (11 < b)
																										{
																											break;
																										}
																										goto IL_0364;
																										IL_0364:
																										if (11 > b)
																										{
																											break;
																										}
																										goto IL_0372;
																										IL_0372:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_03b6;
																										IL_03b6:
																										array[num5 - 2] = 0;
																										goto IL_03ca;
																									}
																									break;
																								}
																								goto IL_0439;
																								IL_048d:
																								num5--;
																								goto end_IL_0320;
																								IL_0439:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0479;
																								IL_0479:
																								array[num5 - 2] = 0;
																								goto IL_048d;
																							}
																							break;
																						}
																						goto IL_04a0;
																						IL_056b:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0320;
																						IL_04a0:
																						if (14 < b)
																						{
																							goto IL_04ab;
																						}
																						goto IL_04cc;
																						IL_04ab:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_04b9;
																						IL_04b9:
																						if (15 <= b)
																						{
																						}
																						break;
																						IL_04cc:
																						if (14 > b)
																						{
																							goto IL_04da;
																						}
																						goto IL_056b;
																						IL_04da:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_04e8;
																						IL_04e8:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_04f6;
																						IL_04f6:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0558;
																						IL_0558:
																						num5 -= 2;
																						goto end_IL_0320;
																					}
																					break;
																				}
																				goto IL_0587;
																				IL_084d:
																				array[num5 - 1] = 5;
																				goto end_IL_0320;
																				IL_0587:
																				if (8 <= b)
																				{
																					goto IL_0592;
																				}
																				goto IL_05aa;
																				IL_0592:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0320;
																				IL_05aa:
																				if (4 < b)
																				{
																					goto IL_05b8;
																				}
																				num = 21;
																				goto IL_070d;
																				IL_05b8:
																				if (6 < b)
																				{
																					goto IL_05c3;
																				}
																				goto IL_063b;
																				IL_05c3:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_05d1;
																				IL_05d1:
																				if (7 > b)
																				{
																					break;
																				}
																				num = 49;
																				goto IL_05e8;
																				IL_0881:
																				ptr2 += 8;
																				goto IL_088f;
																				IL_05e8:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0611;
																				IL_0611:
																				ptr2 += 8;
																				num = 83;
																				goto IL_0628;
																				IL_0628:
																				num5--;
																				goto end_IL_0320;
																				IL_063b:
																				if (6 <= b)
																				{
																					goto IL_0646;
																				}
																				num = 82;
																				goto IL_06a1;
																				IL_0646:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0685;
																				IL_0685:
																				num5 -= 3;
																				goto end_IL_0320;
																				IL_088f:
																				num5--;
																				goto end_IL_0320;
																				IL_06a1:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_06af;
																				IL_06af:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_06bd;
																				IL_06bd:
																				array[num5] = 5;
																				goto IL_06cb;
																				IL_06cb:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_06e3;
																				IL_06e3:
																				num5++;
																				goto IL_06f1;
																				IL_06f1:
																				ptr2 += 8;
																				goto end_IL_0320;
																				IL_0863:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_0881;
																				IL_070d:
																				if (4 > b)
																				{
																					goto IL_071b;
																				}
																				goto IL_0863;
																				IL_071b:
																				if (2 >= b)
																				{
																					goto IL_0729;
																				}
																				goto IL_07ff;
																				IL_0729:
																				if (2 <= b)
																				{
																					goto IL_0734;
																				}
																				goto IL_079b;
																				IL_0734:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0774;
																				IL_0774:
																				array[num5 - 2] = 0;
																				goto IL_0788;
																				IL_0788:
																				num5--;
																				goto end_IL_0320;
																				IL_079b:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_07a9;
																				IL_07a9:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_07b7;
																				IL_07b7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_07d0;
																				IL_07d0:
																				array[num5] = 0;
																				goto IL_07de;
																				IL_07de:
																				num5++;
																				goto IL_07ec;
																				IL_07ec:
																				ptr2 += 8;
																				goto end_IL_0320;
																				IL_07ff:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_080d;
																				IL_080d:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_081b;
																				IL_081b:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				num = 43;
																				goto IL_084d;
																			}
																			break;
																			IL_0310:;
																		}
																	}
																	else
																	{
																		num = 14;
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0320:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0959;
													IL_0959:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08b2:
													break;
												}
												continue;
												end_IL_08c5:
												break;
											}
											continue;
											end_IL_08cf:
											break;
										}
										continue;
										end_IL_08da:
										break;
									}
									continue;
									end_IL_08ea:
									break;
								}
								continue;
								end_IL_08fa:
								break;
							}
							continue;
							end_IL_090a:
							break;
						}
						continue;
						end_IL_0915:
						break;
					}
					continue;
					end_IL_0925:
					break;
				}
				continue;
				end_IL_093e:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3, int int_4)
	{
		int num = 93;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								num = 74;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsSerializableInstallerReference.RuntimeFieldHandlegetCurrencySymbol);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0268:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_023b:
																						if (9 < b)
																						{
																							goto IL_05d3;
																						}
																						while (true)
																						{
																							IL_0228:
																							if (9 <= b)
																							{
																								num = 126;
																								while (true)
																								{
																									if (num != 126)
																									{
																										if (num != 1107)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 20:
																											goto IL_0228;
																										case 77:
																											goto IL_023b;
																										case 46:
																											goto end_IL_023b;
																										case 114:
																											goto end_IL_024b;
																										case 54:
																											goto IL_0268;
																										case 100:
																											goto end_IL_0268;
																										case 4:
																										case 104:
																											goto end_IL_0278;
																										case 73:
																											goto IL_0293;
																										case 103:
																											goto IL_02ac;
																										case 8:
																										case 90:
																											goto IL_02b7;
																										case 38:
																										case 63:
																											goto IL_02c2;
																										case 60:
																											goto IL_02d0;
																										case 15:
																										case 86:
																											goto IL_02de;
																										case 44:
																											goto IL_02f6;
																										case 72:
																											goto IL_0309;
																										case 16:
																										case 52:
																											goto IL_0314;
																										case 76:
																											goto IL_0354;
																										case 36:
																											goto IL_036d;
																										case 101:
																											goto IL_0378;
																										case 57:
																											goto IL_038b;
																										case 41:
																											goto IL_0399;
																										case 11:
																										case 24:
																											goto IL_03a7;
																										case 88:
																											goto IL_0415;
																										case 2:
																										case 111:
																											goto IL_0436;
																										case 6:
																											goto IL_045f;
																										case 96:
																											goto IL_046d;
																										case 117:
																											goto IL_0480;
																										case 47:
																											goto IL_0493;
																										case 48:
																											goto IL_04d3;
																										case 79:
																											goto IL_04e7;
																										case 108:
																											goto IL_04fa;
																										case 32:
																											goto IL_0505;
																										case 43:
																										case 91:
																											goto IL_0513;
																										case 19:
																											goto IL_0521;
																										case 53:
																											goto IL_0544;
																										case 34:
																											goto IL_054e;
																										case 9:
																											goto IL_055c;
																										case 35:
																											goto IL_056f;
																										case 66:
																											goto IL_057d;
																										case 83:
																										case 87:
																											goto IL_058b;
																										case 37:
																											goto IL_05a4;
																										case 65:
																											goto IL_05b2;
																										case 1:
																											goto IL_05c0;
																										case 75:
																											goto IL_05d3;
																										case 27:
																											goto IL_05e1;
																										case 5:
																											goto end_IL_0215;
																										case 102:
																											goto IL_0606;
																										case 58:
																										case 68:
																											goto IL_0614;
																										case 110:
																											goto IL_0628;
																										case 84:
																											goto IL_0667;
																										case 50:
																										case 85:
																											goto IL_067a;
																										case 109:
																											goto IL_0693;
																										case 3:
																											goto IL_069e;
																										case 29:
																										case 55:
																											goto IL_06a9;
																										case 13:
																										case 17:
																										case 18:
																										case 22:
																										case 26:
																										case 30:
																										case 31:
																										case 33:
																										case 45:
																										case 49:
																										case 51:
																										case 56:
																										case 61:
																										case 64:
																										case 71:
																										case 80:
																										case 81:
																										case 82:
																										case 98:
																										case 106:
																										case 115:
																										case 116:
																											goto end_IL_0258;
																										case 62:
																											goto IL_06e5;
																										case 112:
																											goto IL_06f3;
																										case 23:
																											goto IL_0701;
																										case 0:
																										case 12:
																										case 14:
																										case 25:
																										case 28:
																										case 40:
																										case 42:
																										case 59:
																										case 67:
																										case 70:
																										case 95:
																										case 99:
																										case 105:
																										case 113:
																										case 119:
																											goto end_IL_0288;
																										case 89:
																											goto end_IL_070f;
																										case 118:
																											goto end_IL_0722;
																										case 78:
																											goto end_IL_072c;
																										case 74:
																											goto end_IL_0737;
																										case 39:
																											goto end_IL_074c;
																										case 69:
																										case 107:
																											goto end_IL_0761;
																										case 94:
																											goto end_IL_077a;
																										case 10:
																										case 21:
																											goto end_IL_078a;
																										case 92:
																											goto end_IL_079a;
																										case 93:
																											goto end_IL_07aa;
																										case 7:
																										case 97:
																											goto IL_07c5;
																										}
																										continue;
																									}
																									goto IL_0493;
																									IL_04d3:
																									array[num5 - 2] = 0;
																									goto IL_04e7;
																									IL_04e7:
																									num5--;
																									goto end_IL_0288;
																									IL_0493:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04d3;
																									continue;
																									end_IL_0215:
																									break;
																								}
																								break;
																							}
																							goto IL_04fa;
																							IL_05b2:
																							num5++;
																							goto IL_05c0;
																							IL_05c0:
																							ptr2 += 8;
																							goto end_IL_0288;
																							IL_04fa:
																							if (7 >= b)
																							{
																								goto IL_0505;
																							}
																							goto IL_056f;
																							IL_0505:
																							if (7 > b)
																							{
																								goto end_IL_0258;
																							}
																							goto IL_0513;
																							IL_0513:
																							array[num5] = 0;
																							goto IL_0521;
																							IL_0521:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0544;
																							IL_0544:
																							array2[num5] = null;
																							goto IL_054e;
																							IL_054e:
																							num5++;
																							goto IL_055c;
																							IL_055c:
																							ptr2 += 8;
																							goto end_IL_0288;
																							IL_056f:
																							if (8 < b)
																							{
																								goto end_IL_0258;
																							}
																							goto IL_057d;
																							IL_057d:
																							if (8 > b)
																							{
																								goto end_IL_0258;
																							}
																							goto IL_058b;
																							IL_058b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_05a4;
																							IL_05a4:
																							array[num5] = 0;
																							goto IL_05b2;
																						}
																						goto IL_05ef;
																						IL_069e:
																						if (12 > b)
																						{
																							goto end_IL_0258;
																						}
																						goto IL_06a9;
																						IL_05d3:
																						if (11 >= b)
																						{
																							goto IL_05e1;
																						}
																						goto IL_0693;
																						IL_05e1:
																						if (11 > b)
																						{
																							goto IL_05ef;
																						}
																						goto IL_067a;
																						IL_05ef:
																						if (10 < b)
																						{
																							goto end_IL_0258;
																						}
																						num = 102;
																						goto IL_0606;
																						IL_06a9:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0288;
																						IL_0606:
																						if (10 > b)
																						{
																							goto end_IL_0258;
																						}
																						goto IL_0614;
																						IL_0614:
																						array[num5 - 1] = 0;
																						goto IL_0628;
																						IL_0628:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)StoreOperationScavengegetDynamicBase[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																						goto IL_0667;
																						IL_0667:
																						ptr2 += 8;
																						goto end_IL_0288;
																						IL_067a:
																						num5--;
																						num = 12;
																						goto end_IL_0288;
																						IL_0693:
																						if (12 < b)
																						{
																							goto end_IL_0258;
																						}
																						goto IL_069e;
																						continue;
																						end_IL_023b:
																						break;
																					}
																					continue;
																				}
																				goto IL_0293;
																				IL_03a7:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0415;
																				IL_0293:
																				if (6 <= b)
																				{
																					num = 113;
																					goto end_IL_0288;
																				}
																				goto IL_02ac;
																				IL_0415:
																				num5 -= 2;
																				goto end_IL_0288;
																				IL_02ac:
																				if (3 < b)
																				{
																					goto IL_02b7;
																				}
																				goto IL_0309;
																				IL_02b7:
																				if (4 < b)
																				{
																					goto IL_02c2;
																				}
																				goto IL_02f6;
																				IL_02c2:
																				if (5 < b)
																				{
																					goto end_IL_0258;
																				}
																				goto IL_02d0;
																				IL_02d0:
																				if (5 > b)
																				{
																					goto end_IL_0258;
																				}
																				goto IL_02de;
																				IL_02de:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0288;
																				IL_02f6:
																				if (4 > b)
																				{
																					goto end_IL_0258;
																				}
																				goto IL_0436;
																				IL_0436:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_045f;
																				IL_045f:
																				ptr2 += 8;
																				goto IL_046d;
																				IL_046d:
																				num5--;
																				goto end_IL_0288;
																				IL_0309:
																				if (3 <= b)
																				{
																					goto IL_0314;
																				}
																				goto IL_036d;
																				IL_0314:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0354;
																				IL_0354:
																				array[num5 - 2] = 0;
																				goto IL_0480;
																				IL_0480:
																				num5--;
																				goto end_IL_0288;
																				IL_036d:
																				if (1 >= b)
																				{
																					goto IL_0378;
																				}
																				goto IL_038b;
																				IL_0378:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_0258;
																				IL_038b:
																				if (2 < b)
																				{
																					goto end_IL_0258;
																				}
																				goto IL_0399;
																				IL_0399:
																				if (2 > b)
																				{
																					num = 81;
																					goto end_IL_0258;
																				}
																				goto IL_03a7;
																				continue;
																				end_IL_024b:
																				break;
																			}
																			continue;
																			end_IL_0258:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06e5;
																	IL_0701:
																	ptr2 += 8;
																	goto end_IL_0288;
																	IL_06f3:
																	num5++;
																	goto IL_0701;
																	IL_06e5:
																	array[num5] = 0;
																	goto IL_06f3;
																	continue;
																	end_IL_0268:
																	break;
																}
																continue;
																end_IL_0278:
																break;
															}
															continue;
															end_IL_0288:
															break;
														}
														continue;
													}
													goto IL_07c5;
													IL_07c5:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_070f:
													break;
												}
												continue;
												end_IL_0722:
												break;
											}
											continue;
											end_IL_072c:
											break;
										}
										continue;
										end_IL_0737:
										break;
									}
									continue;
									end_IL_074c:
									break;
								}
								continue;
								end_IL_0761:
								break;
							}
							continue;
							end_IL_077a:
							break;
						}
						continue;
						end_IL_078a:
						break;
					}
					continue;
					end_IL_079a:
					break;
				}
				continue;
				end_IL_07aa:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_3)
	{
		int num = 87;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							num = 80;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OtherArraydwHelpContext.TokenizerStreamModeJIS);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_02a8:
														byte b = *ptr2;
														while (true)
														{
															IL_0298:
															ptr2++;
															while (true)
															{
																IL_0288:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_026b:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_025b:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_024b:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_023e:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_022e:
																											if (1 >= b)
																											{
																												while (1 <= b)
																												{
																													while (true)
																													{
																														IL_01fa:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																														num = 118;
																														while (true)
																														{
																															if (num != 118)
																															{
																																if (num != 1099)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 11:
																																case 77:
																																	goto IL_01fa;
																																case 18:
																																	goto IL_021e;
																																case 24:
																																	goto IL_022e;
																																case 40:
																																	goto IL_023e;
																																case 27:
																																	goto IL_024b;
																																case 91:
																																	goto IL_025b;
																																case 73:
																																	goto IL_026b;
																																case 103:
																																	goto IL_0278;
																																case 39:
																																	goto IL_0288;
																																case 58:
																																	goto IL_0298;
																																case 8:
																																case 31:
																																	goto IL_02a8;
																																case 19:
																																case 25:
																																	goto IL_02b3;
																																case 30:
																																case 65:
																																	goto IL_02cb;
																																case 3:
																																	goto IL_02d6;
																																case 55:
																																case 56:
																																	goto IL_02e4;
																																case 34:
																																	goto IL_0348;
																																case 63:
																																	goto IL_0353;
																																case 4:
																																	goto IL_0366;
																																case 21:
																																	goto IL_0374;
																																case 71:
																																	goto IL_0387;
																																case 44:
																																case 92:
																																	goto IL_039a;
																																case 35:
																																	goto IL_03a5;
																																case 59:
																																case 93:
																																	goto IL_03b8;
																																case 6:
																																	goto IL_03c3;
																																case 51:
																																	goto IL_03d1;
																																case 94:
																																	goto IL_03e4;
																																case 48:
																																case 99:
																																	goto IL_03f7;
																																case 70:
																																	goto IL_0405;
																																case 7:
																																case 57:
																																	goto IL_0413;
																																case 41:
																																	goto IL_0421;
																																case 23:
																																	goto IL_0444;
																																case 43:
																																	goto IL_0457;
																																case 10:
																																	goto IL_0465;
																																case 88:
																																case 104:
																																	goto IL_0478;
																																case 61:
																																	goto IL_049b;
																																case 2:
																																	goto IL_04a9;
																																case 82:
																																	goto IL_04b7;
																																case 5:
																																case 106:
																																	goto IL_04ca;
																																case 45:
																																case 108:
																																	goto IL_04e6;
																																case 17:
																																	goto IL_04f4;
																																case 68:
																																case 84:
																																	goto IL_0502;
																																case 50:
																																	goto IL_052b;
																																case 74:
																																	goto IL_0542;
																																case 14:
																																case 111:
																																	goto IL_0555;
																																case 72:
																																	goto IL_0595;
																																case 67:
																																	goto IL_05a9;
																																case 49:
																																	goto IL_05ca;
																																case 96:
																																	goto IL_05d8;
																																case 79:
																																case 100:
																																	goto IL_05eb;
																																case 95:
																																	goto IL_0634;
																																case 1:
																																	goto IL_0648;
																																case 0:
																																case 13:
																																case 16:
																																case 20:
																																case 33:
																																case 42:
																																case 46:
																																case 52:
																																case 53:
																																case 62:
																																case 64:
																																case 66:
																																case 69:
																																case 78:
																																case 89:
																																case 90:
																																case 98:
																																case 101:
																																case 110:
																																	goto end_IL_021e;
																																case 12:
																																case 15:
																																case 28:
																																case 29:
																																case 32:
																																case 36:
																																case 37:
																																case 38:
																																case 47:
																																case 54:
																																case 75:
																																case 97:
																																case 102:
																																case 109:
																																	goto end_IL_01e7;
																																case 107:
																																	goto end_IL_066b;
																																case 22:
																																	goto end_IL_067e;
																																case 60:
																																	goto end_IL_0688;
																																case 80:
																																	goto end_IL_0693;
																																case 9:
																																case 76:
																																	goto end_IL_06a8;
																																case 85:
																																	goto end_IL_06b8;
																																case 81:
																																case 105:
																																	goto end_IL_06d1;
																																case 86:
																																	goto end_IL_06e1;
																																case 87:
																																	goto end_IL_06f1;
																																case 26:
																																case 83:
																																	goto IL_070c;
																																}
																																continue;
																															}
																															array[num5] = 0;
																															goto IL_05ca;
																															IL_05ca:
																															num5++;
																															goto IL_05d8;
																															IL_05d8:
																															ptr2 += 8;
																															break;
																															continue;
																															end_IL_01e7:
																															break;
																														}
																														break;
																													}
																													goto end_IL_0288;
																													continue;
																													end_IL_021e:
																													break;
																													IL_021e:;
																												}
																												break;
																											}
																											goto IL_04e6;
																											IL_0542:
																											num5--;
																											goto end_IL_0288;
																											IL_04e6:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_04f4;
																											IL_04f4:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_0502;
																											IL_0502:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_052b;
																											IL_052b:
																											ptr2 += 8;
																											num = 74;
																											goto IL_0542;
																										}
																										break;
																									}
																									goto IL_02b3;
																									IL_02b3:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0288;
																								}
																								break;
																							}
																							goto IL_039a;
																							IL_0465:
																							ptr2 += 8;
																							goto end_IL_0288;
																							IL_039a:
																							if (4 >= b)
																							{
																								goto IL_03a5;
																							}
																							goto IL_03f7;
																							IL_03a5:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_0288;
																							IL_03f7:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0405;
																							IL_0405:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0413;
																							IL_0413:
																							array[num5] = 0;
																							goto IL_0421;
																							IL_0421:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0444;
																							IL_0444:
																							array2[num5] = null;
																							num = 43;
																							goto IL_0457;
																							IL_0457:
																							num5++;
																							goto IL_0465;
																						}
																						break;
																					}
																					goto IL_05eb;
																					IL_0648:
																					num5--;
																					goto end_IL_0288;
																					IL_05eb:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					num = 95;
																					goto IL_0634;
																					IL_0634:
																					array[num5 - 2] = 0;
																					goto IL_0648;
																				}
																				break;
																			}
																			goto IL_02cb;
																			IL_0374:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_02cb:
																			if (9 >= b)
																			{
																				goto IL_02d6;
																			}
																			goto IL_0348;
																			IL_02d6:
																			if (9 <= b)
																			{
																				goto IL_02e4;
																			}
																			goto IL_03b8;
																			IL_02e4:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0387;
																			IL_0387:
																			num5 -= 2;
																			goto end_IL_0288;
																			IL_03b8:
																			if (7 < b)
																			{
																				goto IL_03c3;
																			}
																			goto IL_03e4;
																			IL_03c3:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_03d1;
																			IL_03d1:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0478;
																			IL_0478:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_049b;
																			IL_049b:
																			array[num5] = 0;
																			goto IL_04a9;
																			IL_04a9:
																			num5++;
																			goto IL_04b7;
																			IL_04b7:
																			ptr2 += 8;
																			goto end_IL_0288;
																			IL_03e4:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0555;
																			IL_0555:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0595;
																			IL_0595:
																			array[num5 - 2] = 0;
																			goto IL_05a9;
																			IL_05a9:
																			num5--;
																			goto end_IL_0288;
																			IL_0348:
																			if (10 >= b)
																			{
																				goto IL_0353;
																			}
																			goto IL_0366;
																			IL_0353:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_04ca;
																			IL_04ca:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0288;
																			IL_0366:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0374;
																		}
																		break;
																		IL_0278:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0288:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_070c;
												IL_070c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_066b:
												break;
											}
											continue;
											end_IL_067e:
											break;
										}
										continue;
										end_IL_0688:
										break;
									}
									continue;
									end_IL_0693:
									break;
								}
								continue;
								end_IL_06a8:
								break;
							}
							continue;
							end_IL_06b8:
							break;
						}
						continue;
						end_IL_06d1:
						break;
					}
					continue;
					end_IL_06e1:
					break;
				}
				continue;
				end_IL_06f1:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_3, int int_4)
	{
		int num = 9;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				IL_0586:
				int num3 = num2 * 4;
				while (true)
				{
					IL_0576:
					byte[] array = new byte[2];
					while (true)
					{
						IL_0566:
						object[] array2 = new object[2];
						while (true)
						{
							IL_0556:
							int[] array3 = new int[3];
							while (true)
							{
								IL_0546:
								long[] array4 = new long[2];
								while (true)
								{
									IL_0531:
									array3[0] = int_3;
									while (true)
									{
										IL_051c:
										array3[1] = int_4;
										while (true)
										{
											IL_0511:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getControlPrincipalgetPermissionSetSection.GetMethodInfoReRegisterForFinalize);
											while (true)
											{
												IL_0507:
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0239:
															byte b = *ptr2;
															while (true)
															{
																IL_0229:
																ptr2++;
																while (true)
																{
																	IL_0219:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01fc:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01ec:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								while (5 >= b)
																								{
																									while (5 <= b)
																									{
																										while (true)
																										{
																											IL_019e:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											num = 95;
																											while (num != 95)
																											{
																												if (num != 1076)
																												{
																													goto end_IL_04f4;
																												}
																												switch (num)
																												{
																												case 37:
																												case 61:
																													goto IL_019e;
																												case 84:
																													goto IL_01bc;
																												case 52:
																													goto IL_01cc;
																												case 15:
																													goto IL_01dc;
																												case 24:
																													goto IL_01ec;
																												case 81:
																													goto IL_01fc;
																												case 1:
																													goto IL_0209;
																												case 72:
																													goto IL_0219;
																												case 14:
																													goto IL_0229;
																												case 56:
																												case 85:
																													goto IL_0239;
																												case 29:
																													goto IL_0244;
																												case 10:
																												case 31:
																													goto IL_025a;
																												case 22:
																													goto IL_0283;
																												case 28:
																												case 43:
																													goto IL_0296;
																												case 18:
																													goto IL_02a1;
																												case 12:
																												case 44:
																													goto IL_02b1;
																												case 17:
																												case 47:
																													goto IL_02c4;
																												case 39:
																													goto IL_0332;
																												case 51:
																													goto IL_0345;
																												case 41:
																												case 76:
																													goto IL_0358;
																												case 46:
																													goto IL_0366;
																												case 87:
																													goto IL_0379;
																												case 2:
																												case 77:
																													goto IL_0387;
																												case 3:
																													goto IL_03c7;
																												case 13:
																													goto IL_03db;
																												case 36:
																													goto IL_03ee;
																												case 67:
																													goto IL_03f9;
																												case 38:
																													goto IL_0407;
																												case 16:
																												case 79:
																													goto IL_0415;
																												case 58:
																													goto IL_0431;
																												case 21:
																												case 48:
																													goto IL_0445;
																												case 88:
																													goto IL_0453;
																												case 80:
																													goto IL_0476;
																												case 30:
																													goto IL_0480;
																												case 27:
																													goto IL_048e;
																												case 0:
																												case 4:
																												case 5:
																												case 6:
																												case 7:
																												case 19:
																												case 25:
																												case 35:
																												case 40:
																												case 45:
																												case 49:
																												case 54:
																												case 55:
																												case 63:
																												case 64:
																												case 68:
																												case 71:
																													goto end_IL_01bc;
																												case 78:
																													goto IL_04ca;
																												case 57:
																													goto IL_04d8;
																												case 34:
																													goto IL_04e6;
																												case 11:
																												case 26:
																												case 33:
																												case 50:
																												case 53:
																												case 59:
																												case 65:
																												case 69:
																												case 75:
																												case 86:
																													goto end_IL_018b;
																												case 32:
																													goto IL_0507;
																												case 74:
																													goto IL_0511;
																												case 23:
																													goto IL_051c;
																												case 20:
																													goto IL_0531;
																												case 60:
																													goto IL_0546;
																												case 73:
																												case 83:
																													goto IL_0556;
																												case 42:
																													goto IL_0566;
																												case 62:
																												case 82:
																													goto IL_0576;
																												case 8:
																													goto IL_0586;
																												case 9:
																													goto end_IL_04f4;
																												case 66:
																												case 70:
																													goto IL_05a1;
																												}
																												continue;
																												end_IL_018b:
																												break;
																											}
																											break;
																										}
																										goto end_IL_01dc;
																										continue;
																										end_IL_01bc:
																										break;
																										IL_01bc:;
																									}
																									break;
																									IL_01cc:;
																								}
																								goto end_IL_0209;
																								continue;
																								end_IL_01dc:
																								break;
																								IL_01dc:;
																							}
																							break;
																						}
																						goto IL_03ee;
																						IL_0480:
																						num5++;
																						goto IL_048e;
																						IL_03ee:
																						if (7 < b)
																						{
																							goto IL_03f9;
																						}
																						goto IL_0431;
																						IL_03f9:
																						if (8 < b)
																						{
																							goto end_IL_0209;
																						}
																						goto IL_0407;
																						IL_0407:
																						if (8 > b)
																						{
																							goto end_IL_0209;
																						}
																						goto IL_0415;
																						IL_0415:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_0431:
																						if (7 > b)
																						{
																							goto end_IL_0209;
																						}
																						num = 48;
																						goto IL_0445;
																						IL_048e:
																						ptr2 += 8;
																						break;
																						IL_0445:
																						array[num5] = 0;
																						goto IL_0453;
																						IL_0453:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0476;
																						IL_0476:
																						array2[num5] = null;
																						goto IL_0480;
																					}
																					break;
																				}
																				goto IL_0244;
																				IL_0283:
																				ptr2 += 8;
																				goto IL_0345;
																				IL_0244:
																				if (4 <= b)
																				{
																					goto IL_025a;
																				}
																				num = 28;
																				goto IL_0296;
																				IL_0345:
																				num5--;
																				break;
																				IL_0296:
																				if (2 >= b)
																				{
																					goto IL_02a1;
																				}
																				goto IL_02b1;
																				IL_02a1:
																				if (2 <= b)
																				{
																					goto IL_02c4;
																				}
																				goto IL_0358;
																				IL_0358:
																				if (1 < b)
																				{
																					goto end_IL_0209;
																				}
																				goto IL_0366;
																				IL_0366:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_0209;
																				IL_02c4:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0332;
																				IL_0332:
																				num5 -= 2;
																				break;
																				IL_02b1:
																				if (3 < b)
																				{
																					goto end_IL_0209;
																				}
																				goto IL_0379;
																				IL_0379:
																				if (3 > b)
																				{
																					goto end_IL_0209;
																				}
																				goto IL_0387;
																				IL_0387:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03c7;
																				IL_03c7:
																				array[num5 - 2] = 0;
																				goto IL_03db;
																				IL_03db:
																				num5--;
																				break;
																				IL_025a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0283;
																			}
																			goto end_IL_0219;
																			continue;
																			end_IL_0209:
																			break;
																			IL_0209:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 78;
																	goto IL_04ca;
																	IL_04e6:
																	ptr2 += 8;
																	break;
																	IL_04d8:
																	num5++;
																	goto IL_04e6;
																	IL_04ca:
																	array[num5] = 0;
																	goto IL_04d8;
																	continue;
																	end_IL_0219:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a1;
													IL_05a1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f4:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3)
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 102;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GenerateKeyViewAccessControl.UnauthorizedAccessExceptionVARPERINSTANCE);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0234:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0214:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0207:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_01ee:
																							array[num5] = 0;
																							num = 115;
																							while (true)
																							{
																								if (num != 115)
																								{
																									if (num != 1096)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 43:
																									case 62:
																										goto IL_01ee;
																									case 82:
																										goto IL_0207;
																									case 89:
																										goto IL_0214;
																									case 4:
																										goto IL_0224;
																									case 27:
																										goto IL_0234;
																									case 18:
																										goto end_IL_0234;
																									case 97:
																									case 108:
																										goto end_IL_0244;
																									case 78:
																									case 92:
																										goto IL_025f;
																									case 38:
																										goto IL_026d;
																									case 34:
																									case 61:
																										goto IL_0278;
																									case 63:
																										goto IL_02a1;
																									case 25:
																										goto IL_02af;
																									case 1:
																										goto IL_02c2;
																									case 76:
																										goto IL_02d0;
																									case 39:
																									case 50:
																										goto IL_02de;
																									case 65:
																										goto IL_02f7;
																									case 36:
																										goto IL_0305;
																									case 15:
																										goto IL_0313;
																									case 5:
																									case 44:
																										goto IL_0326;
																									case 73:
																										goto IL_0331;
																									case 11:
																									case 93:
																										goto IL_033f;
																									case 52:
																									case 105:
																										goto IL_0357;
																									case 94:
																										goto IL_0365;
																									case 98:
																										goto IL_039b;
																									case 56:
																										goto IL_03a5;
																									case 91:
																										goto IL_03b3;
																									case 103:
																										goto IL_03c6;
																									case 14:
																										goto IL_03d1;
																									case 26:
																									case 75:
																										goto IL_03dc;
																									case 13:
																										goto IL_03ea;
																									case 28:
																										goto IL_03fd;
																									case 6:
																									case 71:
																										goto IL_040b;
																									case 72:
																										goto IL_0430;
																									case 32:
																									case 42:
																										goto IL_043e;
																									case 7:
																										goto IL_0449;
																									case 17:
																									case 57:
																										goto IL_0457;
																									case 60:
																										goto IL_0497;
																									case 23:
																										goto IL_04ab;
																									case 12:
																										goto IL_04be;
																									case 90:
																										goto IL_04cc;
																									case 40:
																									case 54:
																										goto IL_04da;
																									case 83:
																										goto IL_04fd;
																									case 35:
																										goto IL_0514;
																									case 22:
																										goto IL_0522;
																									case 24:
																									case 41:
																										goto IL_0535;
																									case 47:
																										goto IL_0597;
																									case 0:
																									case 3:
																									case 8:
																									case 10:
																									case 29:
																									case 30:
																									case 31:
																									case 33:
																									case 37:
																									case 46:
																									case 49:
																									case 51:
																									case 53:
																									case 55:
																									case 59:
																									case 68:
																									case 74:
																									case 81:
																									case 86:
																									case 95:
																									case 96:
																									case 99:
																									case 107:
																										goto end_IL_01db;
																									case 16:
																									case 19:
																									case 45:
																									case 48:
																									case 66:
																									case 67:
																									case 79:
																									case 80:
																									case 87:
																									case 88:
																									case 101:
																									case 104:
																									case 106:
																										goto end_IL_0254;
																									case 58:
																										goto end_IL_05ba;
																									case 77:
																										goto end_IL_05cd;
																									case 100:
																										goto end_IL_05d7;
																									case 102:
																										goto end_IL_05e2;
																									case 64:
																									case 69:
																										goto end_IL_05f7;
																									case 2:
																										goto end_IL_0607;
																									case 20:
																									case 21:
																										goto end_IL_0620;
																									case 84:
																										goto end_IL_0630;
																									case 85:
																										goto end_IL_0640;
																									case 9:
																									case 70:
																										goto IL_065b;
																									}
																									continue;
																								}
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_039b;
																								IL_039b:
																								array2[num5] = null;
																								goto IL_03a5;
																								IL_03b3:
																								ptr2 += 8;
																								goto end_IL_0254;
																								IL_03a5:
																								num5++;
																								goto IL_03b3;
																								continue;
																								end_IL_01db:
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_025f;
																					IL_0365:
																					if (4 <= b)
																					{
																						goto end_IL_0254;
																					}
																					break;
																					IL_025f:
																					if (2 >= b)
																					{
																						goto IL_026d;
																					}
																					goto IL_0326;
																					IL_026d:
																					if (2 <= b)
																					{
																						goto IL_0278;
																					}
																					goto IL_02c2;
																					IL_0278:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_02a1;
																					IL_02a1:
																					ptr2 += 8;
																					goto IL_02af;
																					IL_02af:
																					num5--;
																					goto end_IL_0254;
																					IL_02c2:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_02d0;
																					IL_02d0:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_02de;
																					IL_02de:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_02f7;
																					IL_02f7:
																					array[num5] = 0;
																					goto IL_0305;
																					IL_0305:
																					num5++;
																					goto IL_0313;
																					IL_0313:
																					ptr2 += 8;
																					goto end_IL_0254;
																					IL_0326:
																					if (3 >= b)
																					{
																						goto IL_0331;
																					}
																					goto IL_0357;
																					IL_0331:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_033f;
																					IL_033f:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0254;
																					IL_0357:
																					if (4 < b)
																					{
																						break;
																					}
																					goto IL_0365;
																				}
																				break;
																			}
																			goto IL_03c6;
																			IL_0535:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0597;
																			IL_03c6:
																			if (8 < b)
																			{
																				goto IL_03d1;
																			}
																			num = 72;
																			goto IL_0430;
																			IL_03d1:
																			if (9 < b)
																			{
																				goto IL_03dc;
																			}
																			goto IL_03fd;
																			IL_03dc:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_03ea;
																			IL_03ea:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_03fd:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_040b;
																			IL_040b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0254;
																			IL_0597:
																			num5 -= 2;
																			goto end_IL_0254;
																			IL_0430:
																			if (8 > b)
																			{
																				goto IL_043e;
																			}
																			goto IL_0535;
																			IL_043e:
																			if (6 >= b)
																			{
																				goto IL_0449;
																			}
																			goto IL_04be;
																			IL_0449:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0457;
																			IL_0457:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0497;
																			IL_0497:
																			array[num5 - 2] = 0;
																			goto IL_04ab;
																			IL_04ab:
																			num5--;
																			goto end_IL_0254;
																			IL_04be:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_04cc;
																			IL_04cc:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04da;
																			IL_04da:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04fd;
																			IL_04fd:
																			array[num5] = 0;
																			num = 35;
																			goto IL_0514;
																			IL_0514:
																			num5++;
																			goto IL_0522;
																			IL_0522:
																			ptr2 += 8;
																			goto end_IL_0254;
																		}
																		break;
																		IL_0224:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0254;
																continue;
																end_IL_0234:
																break;
															}
															continue;
															end_IL_0244:
															break;
														}
														continue;
														end_IL_0254:
														break;
													}
													continue;
												}
												goto IL_065b;
												IL_065b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05ba:
												break;
											}
											continue;
											end_IL_05cd:
											break;
										}
										continue;
										end_IL_05d7:
										break;
									}
									continue;
									end_IL_05e2:
									break;
								}
								continue;
								end_IL_05f7:
								break;
							}
							continue;
							end_IL_0607:
							break;
						}
						continue;
						end_IL_0620:
						break;
					}
					continue;
					end_IL_0630:
					break;
				}
				continue;
				end_IL_0640:
				break;
			}
		}
	}

	static Class149()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 13;
			while (true)
			{
				if (num != 13)
				{
					if (num == 994)
					{
						switch (num)
						{
						default:
							continue;
						case 2:
							break;
						case 0:
							return;
						case 1:
							return;
						case 3:
							return;
						case 4:
							return;
						case 5:
							return;
						case 6:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				return;
			}
		}
	}
}
