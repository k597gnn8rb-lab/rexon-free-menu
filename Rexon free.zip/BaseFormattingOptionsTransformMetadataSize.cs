using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 114)]
internal struct BaseFormattingOptionsTransformMetadataSize
{
	internal static BaseFormattingOptionsTransformMetadataSize GetCurrentgetLocalSignatureMetadataToken/* Not supported: data(01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 02 03 00 00 00 02 02 00 00 00 01 00 00 00 00 00 00 00 00 01 00 00 00 01 01 00 00 00 04 03 00 00 00 03 03 00 00 00 05 00 00 00 02 02 00 00 00 05 00 00 00 03 03 00 00 00 06 03 00 00 00 04 04 00 00 00 05 00 00 00 04 04 00 00 00 07 00 00 00 EA EA 00 00 00 07 00 00 00 0D 0D 00 00 00 08 02 09) */;
}
