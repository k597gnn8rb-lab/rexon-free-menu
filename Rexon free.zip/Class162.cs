using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Connect US", "Room", "Connect to US servers.", true, 2, ModType.const_1, false)]
internal class Class162 : MonoBehaviour
{
	private static bool bool_0;

	private static int int_0;

	private static bool bool_1;

	private static float float_0;

	private static int int_1;

	private static int int_2;

	private static IntPtr[] DaygetFormatterAlgorithm;

	private static IntPtr[] CheckKeyReadPermissionSystemDefaultCharSize;

	private unsafe void OnEnable()
	{
		//The blocks IL_04a5, IL_04b5, IL_04be, IL_04cc, IL_04da, IL_04e8, IL_04f6, IL_0504, IL_050f, IL_054d, IL_0560, IL_056e, IL_057c, IL_058a, IL_0598, IL_05b5, IL_0604, IL_060e, IL_063b, IL_064f, IL_065d, IL_0670, IL_067e, IL_068c, IL_06aa, IL_06b8, IL_06cb, IL_06d4, IL_06fd, IL_0716, IL_0724, IL_0732, IL_074a, IL_0768, IL_078c, IL_07a4, IL_07b7, IL_07c2, IL_07cd, IL_07db, IL_07f3, IL_0801, IL_0814, IL_0822, IL_0830, IL_083e, IL_084c, IL_0857, IL_0865, IL_0873, IL_0888, IL_089b, IL_08a9, IL_08bd, IL_08f5, IL_0908, IL_091c, IL_095a, IL_0976, IL_0981, IL_098f, IL_099d, IL_09b9, IL_09c4, IL_09cd, IL_09db, IL_09e9, IL_0a0a, IL_0a18, IL_0a2f, IL_0a42, IL_0a6b, IL_0a79, IL_0a95, IL_0aa3, IL_0ab1, IL_0abf, IL_0acd, IL_0adb, IL_0ae9, IL_0af7, IL_0b37, IL_0b4b, IL_0b5e, IL_0b67, IL_0b75, IL_0b83, IL_0baf, IL_0bb9, IL_0bc7, IL_0bda, IL_0be5, IL_0c0e, IL_0c25, IL_0c38, IL_0c43, IL_0c56, IL_0c61, IL_0c6f, IL_0caf, IL_0cc3, IL_0cd6, IL_0ce4, IL_0d24, IL_0d38, IL_0d4b, IL_0d59, IL_0d67, IL_0d75, IL_0d83, IL_0da0, IL_0ddf, IL_0df2, IL_0e00, IL_0e62, IL_0e75, IL_0e83, IL_0e8e, IL_0e9c, IL_0eaa, IL_0ebd, IL_0ecb, IL_0f0b, IL_0f1f, IL_0f32, IL_0f7b, IL_0f8f, IL_0fa2, IL_0fb0, IL_0fbe, IL_0fd1 are reachable both inside and outside the pinned region starting at IL_049f. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 178;
		int num3;
		byte[] array2;
		object[] array3;
		int[] array4;
		int[] array5;
		long[] array6;
		object[] array7;
		byte* ptr;
		int num4 = default(int);
		int num5 = default(int);
		object[] array8;
		int num6;
		byte* num7;
		byte* num9;
		int num10;
		int __rxRef74 = default(int);
		ref int reference = ref __rxRef74;
		byte* ptr2;
		byte b = default(byte);
		while (true)
		{
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0481:
					int num2 = 1;
					num = 57;
					while (true)
					{
						IL_0468:
						num3 = num2 * 4;
						num = 75;
						while (true)
						{
							IL_0458:
							array2 = new byte[4];
							while (true)
							{
								IL_0448:
								array3 = new object[4];
								while (true)
								{
									IL_0438:
									array4 = new int[4];
									while (true)
									{
										IL_0428:
										array5 = new int[6];
										while (true)
										{
											IL_0418:
											array6 = new long[4];
											while (true)
											{
												IL_0408:
												array7 = new object[4];
												while (true)
												{
													IL_03f8:
													array7[0] = this;
													while (true)
													{
														IL_03ed:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClientAsyncReplyTerminatorSinkPOLICYVIEWLOCALINFORMATION.getSelfAffectingProcessMgmtIsolatedStorageSecurityOptions);
														while (true)
														{
															IL_03da:
															ptr2 = ptr;
															num = 238;
															while (true)
															{
																if (num == 238)
																{
																	goto IL_04a5;
																}
																if (num != 1219)
																{
																	goto IL_0a42;
																}
																switch (num)
																{
																case 178:
																	break;
																default:
																	continue;
																case 231:
																	goto IL_03da;
																case 190:
																	goto IL_03ed;
																case 76:
																	goto IL_03f8;
																case 169:
																	goto IL_0408;
																case 84:
																	goto IL_0418;
																case 131:
																	goto IL_0428;
																case 41:
																	goto IL_0438;
																case 86:
																	goto IL_0448;
																case 75:
																case 170:
																	goto IL_0458;
																case 57:
																	goto IL_0468;
																case 177:
																	goto IL_0481;
																case 11:
																case 22:
																case 25:
																case 28:
																case 29:
																case 37:
																case 48:
																case 51:
																case 53:
																case 56:
																case 67:
																case 74:
																case 78:
																case 103:
																case 104:
																case 109:
																case 110:
																case 111:
																case 129:
																case 142:
																case 145:
																case 195:
																case 213:
																case 220:
																case 223:
																case 226:
																	goto IL_04a5;
																case 24:
																case 157:
																	goto IL_04b5;
																case 172:
																	goto IL_04be;
																case 79:
																	goto IL_04cc;
																case 55:
																	goto IL_04da;
																case 58:
																	goto IL_04e8;
																case 102:
																case 140:
																	goto IL_04f6;
																case 38:
																	goto IL_0504;
																case 156:
																case 198:
																	goto IL_050f;
																case 161:
																	goto IL_054d;
																case 14:
																	goto IL_0560;
																case 13:
																	goto IL_056e;
																case 128:
																	goto IL_057c;
																case 62:
																	goto IL_058a;
																case 68:
																case 132:
																	goto IL_0598;
																case 80:
																	goto IL_064f;
																case 61:
																	goto IL_065d;
																case 66:
																	goto IL_0670;
																case 221:
																	goto IL_067e;
																case 40:
																case 69:
																	goto IL_068c;
																case 97:
																	goto IL_06aa;
																case 186:
																	goto IL_06b8;
																case 187:
																case 188:
																	goto IL_06d4;
																case 218:
																	goto IL_06fd;
																case 108:
																	goto IL_0716;
																case 191:
																	goto IL_0724;
																case 19:
																case 167:
																	goto IL_0732;
																case 206:
																	goto IL_074a;
																case 222:
																	goto IL_0768;
																case 194:
																	goto IL_078c;
																case 193:
																	goto IL_07a4;
																case 165:
																case 192:
																	goto IL_07b7;
																case 160:
																	goto IL_07c2;
																case 155:
																case 158:
																	goto IL_07cd;
																case 115:
																	goto IL_07db;
																case 93:
																	goto IL_07f3;
																case 137:
																	goto IL_0801;
																case 203:
																	goto IL_0830;
																case 229:
																	goto IL_083e;
																case 2:
																case 30:
																	goto IL_084c;
																case 124:
																	goto IL_0857;
																case 228:
																	goto IL_0865;
																case 44:
																case 50:
																	goto IL_0873;
																case 112:
																	goto IL_0888;
																case 133:
																	goto IL_089b;
																case 204:
																case 216:
																	goto IL_08a9;
																case 136:
																	goto IL_08bd;
																case 173:
																	goto IL_08f5;
																case 21:
																case 83:
																	goto IL_0908;
																case 119:
																	goto IL_091c;
																case 139:
																	goto IL_095a;
																case 18:
																	goto IL_0976;
																case 16:
																case 116:
																	goto IL_0981;
																case 147:
																	goto IL_098f;
																case 17:
																case 36:
																	goto IL_099d;
																case 49:
																	goto IL_09b9;
																case 92:
																case 176:
																	goto IL_09cd;
																case 138:
																	goto IL_09db;
																case 71:
																case 153:
																	goto IL_09e9;
																case 199:
																	goto IL_0a0a;
																case 46:
																	goto IL_0a18;
																case 82:
																	goto IL_0a2f;
																case 0:
																case 166:
																	goto IL_0a42;
																case 45:
																	goto IL_0a6b;
																case 174:
																	goto IL_0a79;
																case 87:
																	goto IL_0a95;
																case 73:
																	goto IL_0aa3;
																case 114:
																	goto IL_0ab1;
																case 95:
																case 107:
																	goto IL_0abf;
																case 33:
																case 123:
																	goto IL_0acd;
																case 214:
																	goto IL_0adb;
																case 32:
																	goto IL_0ae9;
																case 5:
																case 227:
																	goto IL_0af7;
																case 54:
																	goto IL_0b37;
																case 23:
																	goto IL_0b4b;
																case 88:
																	goto IL_0b67;
																case 85:
																case 197:
																	goto IL_0b75;
																case 168:
																	goto IL_0b83;
																case 130:
																	goto IL_0baf;
																case 164:
																	goto IL_0bb9;
																case 141:
																	goto IL_0bc7;
																case 154:
																	goto IL_0bda;
																case 207:
																case 209:
																	goto IL_0be5;
																case 149:
																	goto IL_0c0e;
																case 122:
																	goto IL_0c25;
																case 98:
																case 182:
																	goto IL_0c38;
																case 219:
																	goto IL_0c43;
																case 163:
																	goto IL_0c56;
																case 81:
																	goto IL_0c61;
																case 72:
																case 217:
																	goto IL_0c6f;
																case 196:
																	goto IL_0caf;
																case 212:
																	goto IL_0cc3;
																case 101:
																case 148:
																	goto IL_0ce4;
																case 183:
																	goto IL_0d24;
																case 26:
																	goto IL_0d38;
																case 6:
																	goto IL_0d4b;
																case 180:
																	goto IL_0d59;
																case 106:
																	goto IL_0d67;
																case 4:
																	goto IL_0d75;
																case 121:
																case 152:
																	goto IL_0d83;
																case 60:
																	goto IL_0da0;
																case 10:
																	goto IL_0ddf;
																case 225:
																	goto IL_0df2;
																case 144:
																case 159:
																	goto IL_0e00;
																case 7:
																	goto IL_0e62;
																case 105:
																	goto IL_0e75;
																case 15:
																case 118:
																	goto IL_0e83;
																case 70:
																case 117:
																	goto IL_0e8e;
																case 150:
																	goto IL_0e9c;
																case 100:
																case 146:
																	goto IL_0eaa;
																case 200:
																	goto IL_0ebd;
																case 151:
																case 179:
																	goto IL_0ecb;
																case 134:
																	goto IL_0f0b;
																case 9:
																	goto IL_0f1f;
																case 171:
																case 184:
																	goto IL_0f32;
																case 43:
																	goto IL_0f7b;
																case 135:
																	goto IL_0f8f;
																case 1:
																	goto IL_0fa2;
																case 181:
																	goto IL_0fb0;
																case 64:
																	goto IL_0fbe;
																case 3:
																case 8:
																case 12:
																case 20:
																case 27:
																case 31:
																case 34:
																case 35:
																case 42:
																case 47:
																case 52:
																case 59:
																case 63:
																case 77:
																case 89:
																case 90:
																case 91:
																case 94:
																case 96:
																case 99:
																case 113:
																case 120:
																case 125:
																case 126:
																case 127:
																case 143:
																case 162:
																case 175:
																case 185:
																case 189:
																case 201:
																case 202:
																case 205:
																case 208:
																case 210:
																case 211:
																case 215:
																case 224:
																case 230:
																	goto IL_0fd1;
																case 39:
																case 65:
																	return;
																}
																break;
																IL_0ebd:
																if (7 <= b)
																{
																	goto IL_0ecb;
																}
																goto IL_0fd1;
																IL_0ecb:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
																goto IL_0f0b;
																IL_04a5:
																if (num5 == 1)
																{
																	return;
																}
																goto IL_04b5;
																IL_04b5:
																b = *ptr2;
																goto IL_04be;
																IL_04be:
																ptr2++;
																goto IL_04cc;
																IL_04cc:
																if (b >= 1)
																{
																	goto IL_04da;
																}
																goto IL_0fd1;
																IL_04da:
																if (b <= 24)
																{
																	goto IL_04e8;
																}
																goto IL_0fd1;
																IL_04e8:
																if (12 < b)
																{
																	goto IL_04f6;
																}
																goto IL_0a95;
																IL_04f6:
																if (18 >= b)
																{
																	goto IL_0504;
																}
																goto IL_0830;
																IL_0504:
																if (18 <= b)
																{
																	goto IL_050f;
																}
																goto IL_0560;
																IL_050f:
																((string[])array3[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2])] = (string)array3[num4 - 1];
																goto IL_054d;
																IL_054d:
																num4 -= 3;
																goto IL_04a5;
																IL_0560:
																if (15 >= b)
																{
																	goto IL_056e;
																}
																goto IL_0716;
																IL_056e:
																if (15 > b)
																{
																	goto IL_057c;
																}
																num = 187;
																goto IL_06d4;
																IL_057c:
																if (13 >= b)
																{
																	goto IL_058a;
																}
																goto IL_0670;
																IL_058a:
																if (13 <= b)
																{
																	goto IL_0598;
																}
																goto IL_0fd1;
																IL_0598:
																array8 = array3;
																num6 = num4;
																if (array == null)
																{
																	goto end_IL_0495;
																}
																num7 = ptr2;
																byte b2 = *num7;
																ptr2 = num7 + 4;
																int num8 = *(int*)(ptr2 + num3);
																ptr2 += 8;
																byte* ptr3 = ptr2 + num8;
																byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																while (ptr2 != ptr3)
																{
																	*ptr4 = (byte)(*ptr2 ^ b2);
																	ptr2++;
																	ptr4++;
																}
																array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																goto IL_064f;
																IL_0f1f:
																num4--;
																goto IL_04a5;
																IL_0f32:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
																num = 43;
																goto IL_0f7b;
																IL_0f7b:
																array2[num4 - 2] = 0;
																goto IL_0f8f;
																IL_064f:
																array2[num4] = 5;
																goto IL_065d;
																IL_065d:
																num4++;
																goto IL_04a5;
																IL_0670:
																if (14 >= b)
																{
																	goto IL_067e;
																}
																goto IL_0fd1;
																IL_067e:
																if (14 <= b)
																{
																	goto IL_068c;
																}
																goto IL_0fd1;
																IL_068c:
																array7[*(int*)(ptr2 + num3)] = array3[num4 - 1];
																goto IL_06aa;
																IL_06aa:
																ptr2 += 8;
																goto IL_06b8;
																IL_06b8:
																num4--;
																goto IL_04a5;
																IL_0f0b:
																array2[num4 - 2] = 0;
																goto IL_0f1f;
																IL_06d4:
																array3[num4 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1])];
																goto IL_06fd;
																IL_06fd:
																array2[num4 - 1] = 5;
																goto IL_04a5;
																IL_0716:
																if (16 >= b)
																{
																	goto IL_0724;
																}
																goto IL_07b7;
																IL_0724:
																if (16 <= b)
																{
																	goto IL_0732;
																}
																goto IL_0fd1;
																IL_0732:
																array2[num4] = array2[num4 - 1];
																goto IL_074a;
																IL_074a:
																array4[num4 - 0] = array4[num4 - 1];
																goto IL_0768;
																IL_0768:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
																goto IL_078c;
																IL_078c:
																array3[num4] = array3[num4 - 1];
																goto IL_07a4;
																IL_07a4:
																num4++;
																goto IL_04a5;
																IL_07b7:
																if (17 >= b)
																{
																	goto IL_07c2;
																}
																num = 224;
																goto IL_0fd1;
																IL_07c2:
																if (17 <= b)
																{
																	goto IL_07cd;
																}
																num = 12;
																goto IL_0fd1;
																IL_07cd:
																array2[num4] = 5;
																goto IL_07db;
																IL_07db:
																array3[num4] = array7[*(int*)(ptr2 + num3)];
																goto IL_07f3;
																IL_07f3:
																num4++;
																goto IL_0801;
																IL_0801:
																ptr2 += 8;
																goto IL_04a5;
																IL_0fd1:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4]) = *(int*)(ptr2 + num3);
																goto IL_0fa2;
																IL_0f8f:
																num4--;
																goto IL_04a5;
																IL_0830:
																if (21 >= b)
																{
																	goto IL_083e;
																}
																goto IL_0976;
																IL_083e:
																if (21 > b)
																{
																	goto IL_084c;
																}
																goto IL_0908;
																IL_084c:
																if (19 < b)
																{
																	goto IL_0857;
																}
																goto IL_089b;
																IL_0857:
																if (20 >= b)
																{
																	goto IL_0865;
																}
																goto IL_0fd1;
																IL_0865:
																if (20 <= b)
																{
																	goto IL_0873;
																}
																goto IL_0fd1;
																IL_0873:
																((delegate*<void>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])();
																goto IL_0888;
																IL_0888:
																ptr2 += 8;
																goto IL_04a5;
																IL_089b:
																if (19 <= b)
																{
																	goto IL_08a9;
																}
																goto IL_0fd1;
																IL_08a9:
																array2[num4 - 1] = 5;
																goto IL_08bd;
																IL_08bd:
																array3[num4 - 1] = ((delegate*<string[], string>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])((string[])array3[num4 - 1]);
																goto IL_08f5;
																IL_08f5:
																ptr2 += 8;
																goto IL_04a5;
																IL_0908:
																array2[num4 - 1] = 0;
																goto IL_091c;
																IL_091c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]) = (((delegate*<string, bool>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])((string)array3[num4 - 1]) ? 1 : 0);
																goto IL_095a;
																IL_095a:
																ptr2 += 8;
																num = 111;
																goto IL_04a5;
																IL_0976:
																if (23 < b)
																{
																	goto IL_0981;
																}
																goto IL_09b9;
																IL_0981:
																if (24 >= b)
																{
																	goto IL_098f;
																}
																goto IL_0fd1;
																IL_098f:
																if (24 <= b)
																{
																	goto IL_099d;
																}
																goto IL_0fd1;
																IL_099d:
																num9 = ptr2;
																num10 = -200;
																num5 = 1;
																ptr2 = num9 + num10;
																goto IL_04a5;
																IL_09b9:
																if (23 > b)
																{
																	num = 176;
																	goto IL_09cd;
																}
																goto IL_0a42;
																IL_0fa2:
																array2[num4] = 0;
																goto IL_0fb0;
																IL_09cd:
																if (22 >= b)
																{
																	goto IL_09db;
																}
																goto IL_0fd1;
																IL_09db:
																if (22 <= b)
																{
																	goto IL_09e9;
																}
																goto IL_0fd1;
																IL_09e9:
																array3[num4] = array7[*(int*)(ptr2 + num3)];
																num = 199;
																goto IL_0a0a;
																IL_0a0a:
																array2[num4] = 5;
																goto IL_0a18;
																IL_0a18:
																num4++;
																num = 82;
																goto IL_0a2f;
																IL_0a2f:
																ptr2 += 8;
																goto IL_04a5;
																IL_0a42:
																((delegate*<UnityEngine.Object, void>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])((Class162)array3[num4 - 1]);
																goto IL_0a6b;
																IL_0a6b:
																num4--;
																goto IL_0a79;
																IL_0a79:
																ptr2 += 8;
																num = 67;
																goto IL_04a5;
																IL_0a95:
																if (12 <= b)
																{
																	goto IL_04a5;
																}
																goto IL_0aa3;
																IL_0aa3:
																if (6 >= b)
																{
																	goto IL_0ab1;
																}
																goto IL_0d4b;
																IL_0ab1:
																if (6 > b)
																{
																	goto IL_0abf;
																}
																goto IL_0ce4;
																IL_0abf:
																if (3 < b)
																{
																	goto IL_0acd;
																}
																goto IL_0bda;
																IL_0acd:
																if (4 < b)
																{
																	goto IL_0adb;
																}
																num = 88;
																goto IL_0b67;
																IL_0adb:
																if (5 >= b)
																{
																	goto IL_0ae9;
																}
																goto IL_0fd1;
																IL_0ae9:
																if (5 <= b)
																{
																	goto IL_0af7;
																}
																goto IL_0fd1;
																IL_0af7:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
																goto IL_0b37;
																IL_0b37:
																array2[num4 - 2] = 0;
																goto IL_0b4b;
																IL_0b4b:
																num4--;
																goto IL_04a5;
																IL_0fb0:
																num4++;
																goto IL_0fbe;
																IL_0b67:
																if (4 <= b)
																{
																	goto IL_0b75;
																}
																goto IL_0fd1;
																IL_0b75:
																array2[num4] = 0;
																goto IL_0b83;
																IL_0b83:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4]) = array5[*(int*)(ptr2 + num3)];
																num = 130;
																goto IL_0baf;
																IL_0baf:
																array3[num4] = null;
																goto IL_0bb9;
																IL_0bb9:
																num4++;
																goto IL_0bc7;
																IL_0bc7:
																ptr2 += 8;
																goto IL_04a5;
																IL_0bda:
																if (3 <= b)
																{
																	goto IL_0be5;
																}
																goto IL_0c38;
																IL_0be5:
																reference = ref array5[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
																goto IL_0c0e;
																IL_0c0e:
																ptr2 += 8;
																num = 122;
																goto IL_0c25;
																IL_0c25:
																num4--;
																goto IL_04a5;
																IL_0c38:
																if (1 >= b)
																{
																	goto IL_0c43;
																}
																goto IL_0c56;
																IL_0c43:
																if (1 > b)
																{
																}
																goto IL_0fd1;
																IL_0c56:
																if (2 >= b)
																{
																	goto IL_0c61;
																}
																num = 8;
																goto IL_0fd1;
																IL_0c61:
																if (2 <= b)
																{
																	goto IL_0c6f;
																}
																goto IL_0fd1;
																IL_0c6f:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
																goto IL_0caf;
																IL_0caf:
																array2[num4 - 2] = 0;
																goto IL_0cc3;
																IL_0cc3:
																num4--;
																goto IL_04a5;
																IL_0fbe:
																ptr2 += 8;
																goto IL_04a5;
																IL_0ce4:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
																goto IL_0d24;
																IL_0d24:
																array2[num4 - 2] = 0;
																goto IL_0d38;
																IL_0d38:
																num4--;
																goto IL_04a5;
																IL_0d4b:
																if (9 < b)
																{
																	goto IL_0d59;
																}
																goto IL_0e75;
																IL_0d59:
																if (10 < b)
																{
																	goto IL_0d67;
																}
																goto IL_0df2;
																IL_0d67:
																if (11 >= b)
																{
																	goto IL_0d75;
																}
																goto IL_0fd1;
																IL_0d75:
																if (11 <= b)
																{
																	goto IL_0d83;
																}
																goto IL_0fd1;
																IL_0d83:
																array2[num4 - 1] = 0;
																num = 60;
																goto IL_0da0;
																IL_0da0:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]) = ((delegate*<int, int>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]));
																goto IL_0ddf;
																IL_0ddf:
																ptr2 += 8;
																goto IL_04a5;
																IL_0df2:
																if (10 <= b)
																{
																	goto IL_0e00;
																}
																goto IL_0fd1;
																IL_0e00:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_0e62;
																IL_0e62:
																num4 -= 2;
																goto IL_04a5;
																IL_0e75:
																if (9 > b)
																{
																	goto IL_0e83;
																}
																goto IL_0f32;
																IL_0e83:
																if (7 < b)
																{
																	goto IL_0e8e;
																}
																goto IL_0ebd;
																IL_0e8e:
																if (8 >= b)
																{
																	goto IL_0e9c;
																}
																goto IL_0fd1;
																IL_0e9c:
																if (8 <= b)
																{
																	goto IL_0eaa;
																}
																goto IL_0fd1;
																IL_0eaa:
																num4--;
																goto IL_04a5;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			end_IL_0495:
			break;
		}
		while (true)
		{
			byte[] array = new byte[4];
			do
			{
				num7 = ptr2;
				byte b2 = *num7;
				ptr2 = num7 + 4;
				int num8 = *(int*)(ptr2 + num3);
				ptr2 += 8;
				byte* ptr3 = ptr2 + num8;
				byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
				while (ptr2 != ptr3)
				{
					*ptr4 = (byte)(*ptr2 ^ b2);
					ptr2++;
					ptr4++;
				}
				array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
				array2[num4] = 5;
				num4++;
				while (true)
				{
					if (num5 == 1)
					{
						return;
					}
					b = *ptr2;
					ptr2++;
					if (b >= 1 && b <= 24)
					{
						if (12 < b)
						{
							if (18 >= b)
							{
								if (18 <= b)
								{
									((string[])array3[num4 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2])] = (string)array3[num4 - 1];
									num4 -= 3;
									continue;
								}
								if (15 >= b)
								{
									if (15 <= b)
									{
										num = 187;
										array3[num4 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1])];
										array2[num4 - 1] = 5;
										continue;
									}
									if (13 >= b)
									{
										if (13 <= b)
										{
											break;
										}
									}
									else if (14 >= b && 14 <= b)
									{
										array7[*(int*)(ptr2 + num3)] = array3[num4 - 1];
										ptr2 += 8;
										num4--;
										continue;
									}
								}
								else if (16 >= b)
								{
									if (16 <= b)
									{
										array2[num4] = array2[num4 - 1];
										array4[num4 - 0] = array4[num4 - 1];
										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
										array3[num4] = array3[num4 - 1];
										num4++;
										continue;
									}
								}
								else if (17 >= b)
								{
									if (17 <= b)
									{
										array2[num4] = 5;
										array3[num4] = array7[*(int*)(ptr2 + num3)];
										num4++;
										ptr2 += 8;
										continue;
									}
									num = 12;
								}
								else
								{
									num = 224;
								}
							}
							else if (21 >= b)
							{
								if (21 <= b)
								{
									array2[num4 - 1] = 0;
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]) = (((delegate*<string, bool>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])((string)array3[num4 - 1]) ? 1 : 0);
									ptr2 += 8;
									num = 111;
									continue;
								}
								if (19 < b)
								{
									if (20 >= b && 20 <= b)
									{
										((delegate*<void>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])();
										ptr2 += 8;
										continue;
									}
								}
								else if (19 <= b)
								{
									array2[num4 - 1] = 5;
									array3[num4 - 1] = ((delegate*<string[], string>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])((string[])array3[num4 - 1]);
									ptr2 += 8;
									continue;
								}
							}
							else if (23 < b)
							{
								if (24 >= b && 24 <= b)
								{
									num9 = ptr2;
									num10 = -200;
									num5 = 1;
									ptr2 = num9 + num10;
									continue;
								}
							}
							else
							{
								if (23 <= b)
								{
									((delegate*<UnityEngine.Object, void>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])((Class162)array3[num4 - 1]);
									num4--;
									ptr2 += 8;
									num = 67;
									continue;
								}
								num = 176;
								if (22 >= b && 22 <= b)
								{
									array3[num4] = array7[*(int*)(ptr2 + num3)];
									num = 199;
									array2[num4] = 5;
									num4++;
									num = 82;
									ptr2 += 8;
									continue;
								}
							}
						}
						else
						{
							if (12 <= b)
							{
								continue;
							}
							if (6 >= b)
							{
								if (6 <= b)
								{
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
									array2[num4 - 2] = 0;
									num4--;
									continue;
								}
								if (3 < b)
								{
									if (4 < b)
									{
										if (5 >= b && 5 <= b)
										{
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
											array2[num4 - 2] = 0;
											num4--;
											continue;
										}
									}
									else
									{
										num = 88;
										if (4 <= b)
										{
											array2[num4] = 0;
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4]) = array5[*(int*)(ptr2 + num3)];
											num = 130;
											array3[num4] = null;
											num4++;
											ptr2 += 8;
											continue;
										}
									}
								}
								else
								{
									if (3 <= b)
									{
										reference = ref array5[*(int*)(ptr2 + num3)];
										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
										ptr2 += 8;
										num = 122;
										num4--;
										continue;
									}
									if (1 >= b)
									{
										if (1 > b)
										{
										}
									}
									else if (2 >= b)
									{
										if (2 <= b)
										{
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
											array2[num4 - 2] = 0;
											num4--;
											continue;
										}
									}
									else
									{
										num = 8;
									}
								}
							}
							else if (9 < b)
							{
								if (10 < b)
								{
									if (11 >= b && 11 <= b)
									{
										array2[num4 - 1] = 0;
										num = 60;
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]) = ((delegate*<int, int>)DaygetFormatterAlgorithm[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]));
										ptr2 += 8;
										continue;
									}
								}
								else if (10 <= b)
								{
									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
									num4 -= 2;
									continue;
								}
							}
							else
							{
								if (9 <= b)
								{
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
									num = 43;
									array2[num4 - 2] = 0;
									num4--;
									continue;
								}
								if (7 < b)
								{
									if (8 >= b && 8 <= b)
									{
										num4--;
										continue;
									}
								}
								else if (7 <= b)
								{
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4 - 1]);
									array2[num4 - 2] = 0;
									num4--;
									continue;
								}
							}
						}
					}
					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num4]) = *(int*)(ptr2 + num3);
					array2[num4] = 0;
					num4++;
					ptr2 += 8;
				}
				array8 = array3;
				num6 = num4;
			}
			while (array != null);
		}
	}

	public Class162()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_3)
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 66;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComDefaultInterfaceAttributeGetPrimary.getOutArgsCLAIMSECURITYATTRIBUTEFQBNVALUE);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 80;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																IL_023f:
																ptr2++;
																while (true)
																{
																	IL_022f:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_020f:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_01ff:
																						if (5 <= b)
																						{
																							while (true)
																							{
																								IL_01e6:
																								array[num5] = 0;
																								num = 113;
																								while (true)
																								{
																									if (num != 113)
																									{
																										if (num != 1094)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 24:
																										case 48:
																											goto IL_01e6;
																										case 90:
																											goto IL_01ff;
																										case 38:
																											goto IL_020f;
																										case 89:
																											goto IL_021f;
																										case 5:
																											goto IL_022f;
																										case 74:
																											goto IL_023f;
																										case 80:
																											goto end_IL_01d3;
																										case 28:
																											goto end_IL_024f;
																										case 84:
																											goto IL_0288;
																										case 94:
																											goto IL_0292;
																										case 21:
																											goto IL_02a0;
																										case 1:
																											goto IL_02b3;
																										case 4:
																										case 44:
																											goto IL_02be;
																										case 8:
																											goto IL_02c9;
																										case 53:
																										case 59:
																											goto IL_02d7;
																										case 45:
																											goto IL_02ef;
																										case 15:
																											goto IL_02fd;
																										case 16:
																											goto IL_0310;
																										case 47:
																										case 106:
																											goto IL_031b;
																										case 9:
																											goto IL_0329;
																										case 41:
																										case 67:
																											goto IL_0337;
																										case 73:
																											goto IL_0350;
																										case 93:
																											goto IL_035e;
																										case 0:
																											goto IL_036c;
																										case 27:
																										case 57:
																											goto IL_037f;
																										case 10:
																											goto IL_03a8;
																										case 83:
																											goto IL_03b6;
																										case 95:
																											goto IL_03c9;
																										case 92:
																											goto IL_03d7;
																										case 40:
																											goto IL_03e5;
																										case 50:
																											goto IL_03f0;
																										case 7:
																										case 32:
																											goto IL_03fe;
																										case 76:
																											goto IL_043e;
																										case 101:
																											goto IL_0452;
																										case 72:
																											goto IL_0465;
																										case 26:
																											goto IL_0473;
																										case 33:
																										case 37:
																											goto IL_0481;
																										case 79:
																											goto IL_04a4;
																										case 81:
																											goto IL_04b2;
																										case 82:
																											goto IL_04c0;
																										case 49:
																										case 100:
																											goto IL_04d3;
																										case 105:
																											goto IL_0535;
																										case 6:
																										case 36:
																											goto IL_0545;
																										case 31:
																											goto IL_0550;
																										case 56:
																											goto IL_055b;
																										case 43:
																											goto IL_0568;
																										case 54:
																										case 103:
																											goto IL_0573;
																										case 2:
																										case 3:
																										case 11:
																										case 14:
																										case 17:
																										case 22:
																										case 34:
																										case 35:
																										case 46:
																										case 51:
																										case 52:
																										case 55:
																										case 61:
																										case 62:
																										case 63:
																										case 64:
																										case 65:
																										case 70:
																										case 77:
																										case 88:
																										case 91:
																										case 98:
																										case 99:
																											goto end_IL_021f;
																										case 12:
																										case 18:
																										case 19:
																										case 20:
																										case 29:
																										case 30:
																										case 39:
																										case 58:
																										case 60:
																										case 68:
																										case 71:
																										case 75:
																										case 104:
																											goto end_IL_025a;
																										case 97:
																											goto end_IL_059f;
																										case 69:
																											goto end_IL_05b2;
																										case 78:
																											goto end_IL_05bc;
																										case 102:
																											goto end_IL_05c7;
																										case 42:
																										case 87:
																											goto end_IL_05dc;
																										case 66:
																											goto end_IL_05ec;
																										case 13:
																										case 96:
																											goto end_IL_05fc;
																										case 85:
																											goto end_IL_060c;
																										case 86:
																											goto end_IL_0625;
																										case 23:
																										case 25:
																											goto IL_0640;
																										}
																										continue;
																									}
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0288;
																									IL_0288:
																									array2[num5] = null;
																									goto IL_0292;
																									IL_02a0:
																									ptr2 += 8;
																									goto end_IL_025a;
																									IL_0292:
																									num5++;
																									goto IL_02a0;
																									continue;
																									end_IL_01d3:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_02b3;
																						IL_03b6:
																						num5--;
																						goto end_IL_025a;
																						IL_02b3:
																						if (2 < b)
																						{
																							goto IL_02be;
																						}
																						goto IL_0310;
																						IL_02be:
																						if (3 >= b)
																						{
																							goto IL_02c9;
																						}
																						goto IL_02ef;
																						IL_02c9:
																						if (3 > b)
																						{
																							goto end_IL_021f;
																						}
																						goto IL_02d7;
																						IL_02d7:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_025a;
																						IL_02ef:
																						if (4 < b)
																						{
																							goto end_IL_021f;
																						}
																						goto IL_02fd;
																						IL_02fd:
																						if (4 > b)
																						{
																							goto end_IL_021f;
																						}
																						goto end_IL_025a;
																						IL_0310:
																						if (2 > b)
																						{
																							goto IL_031b;
																						}
																						goto IL_037f;
																						IL_031b:
																						if (1 < b)
																						{
																							goto end_IL_021f;
																						}
																						goto IL_0329;
																						IL_0329:
																						if (1 > b)
																						{
																							goto end_IL_021f;
																						}
																						goto IL_0337;
																						IL_0337:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0350;
																						IL_0350:
																						array[num5] = 0;
																						goto IL_035e;
																						IL_035e:
																						num5++;
																						goto IL_036c;
																						IL_036c:
																						ptr2 += 8;
																						goto end_IL_025a;
																						IL_037f:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03a8;
																						IL_03a8:
																						ptr2 += 8;
																						goto IL_03b6;
																					}
																					break;
																				}
																				goto IL_03c9;
																				IL_0573:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_025a;
																				IL_03c9:
																				if (8 >= b)
																				{
																					goto IL_03d7;
																				}
																				goto IL_0545;
																				IL_03d7:
																				if (8 > b)
																				{
																					goto IL_03e5;
																				}
																				goto IL_04d3;
																				IL_03e5:
																				if (6 >= b)
																				{
																					goto IL_03f0;
																				}
																				goto IL_0465;
																				IL_03f0:
																				if (6 > b)
																				{
																					goto end_IL_021f;
																				}
																				goto IL_03fe;
																				IL_03fe:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_043e;
																				IL_043e:
																				array[num5 - 2] = 0;
																				goto IL_0452;
																				IL_0452:
																				num5--;
																				goto end_IL_025a;
																				IL_0465:
																				if (7 < b)
																				{
																					goto end_IL_021f;
																				}
																				goto IL_0473;
																				IL_0473:
																				if (7 > b)
																				{
																					goto end_IL_021f;
																				}
																				goto IL_0481;
																				IL_0481:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_04a4;
																				IL_04a4:
																				array[num5] = 0;
																				goto IL_04b2;
																				IL_04b2:
																				num5++;
																				goto IL_04c0;
																				IL_04c0:
																				ptr2 += 8;
																				goto end_IL_025a;
																				IL_04d3:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0535;
																				IL_0535:
																				num5 -= 2;
																				goto end_IL_025a;
																				IL_0545:
																				if (9 < b)
																				{
																					goto IL_0550;
																				}
																				goto IL_0568;
																				IL_0550:
																				if (10 < b)
																				{
																					goto end_IL_021f;
																				}
																				goto IL_055b;
																				IL_055b:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_021f;
																				IL_0568:
																				if (9 > b)
																				{
																					goto end_IL_021f;
																				}
																				goto IL_0573;
																			}
																			goto end_IL_022f;
																			continue;
																			end_IL_021f:
																			break;
																			IL_021f:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_025a;
																	continue;
																	end_IL_022f:
																	break;
																}
																break;
															}
															continue;
															end_IL_024f:
															break;
														}
														continue;
														end_IL_025a:
														break;
													}
													continue;
												}
												goto IL_0640;
												IL_0640:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_059f:
												break;
											}
											continue;
											end_IL_05b2:
											break;
										}
										continue;
										end_IL_05bc:
										break;
									}
									continue;
									end_IL_05c7:
									break;
								}
								continue;
								end_IL_05dc:
								break;
							}
							continue;
							end_IL_05ec:
							break;
						}
						continue;
						end_IL_05fc:
						break;
					}
					continue;
					end_IL_060c:
					break;
				}
				continue;
				end_IL_0625:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_3)
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 32;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MapAssemblyExportedTypes.getByteLengthPositiveInfinity);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 101;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_028c:
														num = 22;
														while (true)
														{
															IL_0281:
															byte b = *ptr2;
															while (true)
															{
																IL_0271:
																ptr2++;
																while (true)
																{
																	IL_0261:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0244:
																				if (6 < b)
																				{
																					while (true)
																					{
																						IL_0234:
																						if (9 >= b)
																						{
																							while (true)
																							{
																								IL_0224:
																								if (9 <= b)
																								{
																									num = 125;
																									while (true)
																									{
																										if (num != 125)
																										{
																											if (num != 1106)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 12:
																												goto IL_0224;
																											case 29:
																												goto IL_0234;
																											case 71:
																												goto IL_0244;
																											case 11:
																												goto IL_0251;
																											case 92:
																												goto IL_0261;
																											case 30:
																												goto IL_0271;
																											case 22:
																												goto IL_0281;
																											case 34:
																												goto IL_028c;
																											case 6:
																												goto IL_0297;
																											case 20:
																												goto IL_02a4;
																											case 7:
																											case 21:
																												goto IL_02b4;
																											case 43:
																												goto IL_02f6;
																											case 44:
																												goto IL_0303;
																											case 46:
																												goto IL_0316;
																											case 54:
																												goto IL_032f;
																											case 49:
																											case 57:
																												goto IL_033f;
																											case 26:
																											case 65:
																												goto IL_0352;
																											case 47:
																												goto IL_0360;
																											case 42:
																											case 66:
																												goto IL_0373;
																											case 23:
																												goto IL_037e;
																											case 51:
																												goto IL_038c;
																											case 1:
																											case 13:
																												goto IL_039a;
																											case 37:
																												goto IL_03c3;
																											case 40:
																												goto IL_03d1;
																											case 69:
																												goto IL_03e4;
																											case 75:
																												goto IL_03f7;
																											case 17:
																											case 77:
																												goto IL_0407;
																											case 52:
																												goto IL_0412;
																											case 78:
																												goto IL_0422;
																											case 85:
																											case 90:
																												goto IL_0435;
																											case 94:
																											case 95:
																												goto IL_044d;
																											case 31:
																												goto IL_0466;
																											case 84:
																												goto IL_0474;
																											case 27:
																												goto IL_0482;
																											case 14:
																											case 98:
																												goto IL_049e;
																											case 104:
																												goto IL_04ba;
																											case 8:
																											case 53:
																												goto IL_04c8;
																											case 36:
																												goto IL_052a;
																											case 106:
																												goto IL_0546;
																											case 41:
																												goto IL_0554;
																											case 80:
																											case 87:
																												goto IL_0562;
																											case 19:
																												goto IL_0570;
																											case 73:
																												goto IL_0593;
																											case 102:
																												goto IL_059d;
																											case 99:
																												goto IL_05ab;
																											case 109:
																												goto IL_05be;
																											case 111:
																												goto IL_05d1;
																											case 9:
																												goto IL_05df;
																											case 0:
																											case 88:
																												goto IL_05ed;
																											case 5:
																											case 113:
																												goto IL_0600;
																											case 38:
																												goto IL_0623;
																											case 110:
																												goto IL_0631;
																											case 74:
																												goto IL_063f;
																											case 91:
																												goto IL_064f;
																											case 108:
																												goto IL_065d;
																											case 100:
																												goto IL_0681;
																											case 55:
																												goto IL_068f;
																											case 2:
																											case 10:
																											case 25:
																											case 28:
																											case 35:
																											case 39:
																											case 45:
																											case 48:
																											case 60:
																											case 62:
																											case 63:
																											case 64:
																											case 67:
																											case 68:
																											case 70:
																											case 72:
																											case 83:
																											case 86:
																											case 89:
																											case 114:
																											case 115:
																												goto end_IL_0251;
																											case 3:
																											case 4:
																											case 15:
																											case 24:
																											case 50:
																											case 56:
																											case 59:
																											case 61:
																											case 81:
																											case 82:
																											case 101:
																											case 105:
																											case 107:
																											case 116:
																											case 118:
																												goto end_IL_0211;
																											case 16:
																												goto end_IL_06b2;
																											case 103:
																												goto end_IL_06c5;
																											case 76:
																												goto end_IL_06d8;
																											case 96:
																												goto end_IL_06e3;
																											case 18:
																											case 79:
																												goto end_IL_06f8;
																											case 112:
																												goto end_IL_0708;
																											case 93:
																											case 97:
																												goto end_IL_0718;
																											case 32:
																												goto end_IL_0728;
																											case 33:
																												goto end_IL_0738;
																											case 58:
																											case 117:
																												goto IL_075c;
																											}
																											continue;
																										}
																										goto IL_064f;
																										IL_0681:
																										num5++;
																										goto IL_068f;
																										IL_068f:
																										ptr2 += 8;
																										break;
																										IL_064f:
																										array[num5] = 0;
																										goto IL_065d;
																										IL_065d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)CheckKeyReadPermissionSystemDefaultCharSize[*(int*)(ptr2 + num3)])();
																										goto IL_0681;
																										continue;
																										end_IL_0211:
																										break;
																									}
																									break;
																								}
																								goto IL_02a4;
																								IL_0631:
																								num5++;
																								goto IL_063f;
																								IL_063f:
																								ptr2 += 8;
																								break;
																								IL_02a4:
																								if (7 >= b)
																								{
																									goto IL_0303;
																								}
																								goto IL_033f;
																								IL_033f:
																								if (8 < b)
																								{
																									goto end_IL_0251;
																								}
																								goto IL_04ba;
																								IL_04ba:
																								if (8 > b)
																								{
																									goto end_IL_0251;
																								}
																								goto IL_04c8;
																								IL_04c8:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_052a;
																								IL_052a:
																								num5 -= 2;
																								num = 4;
																								break;
																								IL_0303:
																								if (7 > b)
																								{
																									goto end_IL_0251;
																								}
																								goto IL_0600;
																								IL_0600:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0623;
																								IL_0623:
																								array[num5] = 0;
																								goto IL_0631;
																							}
																							break;
																						}
																						goto IL_0407;
																						IL_05be:
																						if (12 > b)
																						{
																						}
																						goto end_IL_0251;
																						IL_0407:
																						if (11 >= b)
																						{
																							goto IL_0412;
																						}
																						goto IL_0422;
																						IL_0412:
																						if (11 <= b)
																						{
																							goto IL_049e;
																						}
																						goto IL_05d1;
																						IL_049e:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_05d1:
																						if (10 < b)
																						{
																							goto end_IL_0251;
																						}
																						goto IL_05df;
																						IL_05df:
																						if (10 > b)
																						{
																							goto end_IL_0251;
																						}
																						goto IL_05ed;
																						IL_05ed:
																						num5--;
																						break;
																						IL_0422:
																						if (12 < b)
																						{
																							goto end_IL_0251;
																						}
																						goto IL_05be;
																					}
																					break;
																				}
																				goto IL_0297;
																				IL_0435:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_0297:
																				if (6 <= b)
																				{
																					goto IL_02b4;
																				}
																				goto IL_02f6;
																				IL_02b4:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0316;
																				IL_0316:
																				array[num5 - 2] = 0;
																				goto IL_03e4;
																				IL_03e4:
																				num5--;
																				break;
																				IL_02f6:
																				if (3 >= b)
																				{
																					goto IL_032f;
																				}
																				goto IL_0352;
																				IL_0352:
																				if (4 >= b)
																				{
																					goto IL_0360;
																				}
																				goto IL_0546;
																				IL_0360:
																				if (4 > b)
																				{
																					goto end_IL_0251;
																				}
																				break;
																				IL_0546:
																				if (5 < b)
																				{
																					goto end_IL_0251;
																				}
																				goto IL_0554;
																				IL_0554:
																				if (5 > b)
																				{
																					goto end_IL_0251;
																				}
																				goto IL_0562;
																				IL_0562:
																				array[num5] = 0;
																				goto IL_0570;
																				IL_0570:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0593;
																				IL_0593:
																				array2[num5] = null;
																				goto IL_059d;
																				IL_059d:
																				num5++;
																				goto IL_05ab;
																				IL_05ab:
																				ptr2 += 8;
																				break;
																				IL_032f:
																				if (3 > b)
																				{
																					goto IL_0373;
																				}
																				goto IL_0435;
																				IL_0373:
																				if (1 < b)
																				{
																					goto IL_037e;
																				}
																				goto IL_03f7;
																				IL_037e:
																				if (2 < b)
																				{
																					goto end_IL_0251;
																				}
																				goto IL_038c;
																				IL_038c:
																				if (2 > b)
																				{
																					goto end_IL_0251;
																				}
																				goto IL_039a;
																				IL_039a:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03c3;
																				IL_03c3:
																				ptr2 += 8;
																				goto IL_03d1;
																				IL_03d1:
																				num5--;
																				break;
																				IL_03f7:
																				if (1 > b)
																				{
																					goto end_IL_0251;
																				}
																				goto IL_044d;
																				IL_044d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0466;
																				IL_0466:
																				array[num5] = 0;
																				goto IL_0474;
																				IL_0474:
																				num5++;
																				goto IL_0482;
																				IL_0482:
																				ptr2 += 8;
																				num = 15;
																				break;
																			}
																			goto end_IL_0261;
																			continue;
																			end_IL_0251:
																			break;
																			IL_0251:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0261:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_075c;
												IL_075c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06b2:
												break;
											}
											continue;
											end_IL_06c5:
											break;
										}
										continue;
										end_IL_06d8:
										break;
									}
									continue;
									end_IL_06e3:
									break;
								}
								continue;
								end_IL_06f8:
								break;
							}
							continue;
							end_IL_0708:
							break;
						}
						continue;
						end_IL_0718:
						break;
					}
					continue;
					end_IL_0728:
					break;
				}
				continue;
				end_IL_0738:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_3, int int_4)
	{
		int num = 101;
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 87;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InvariantCultureIgnoreCaseParentField.GetHashFromAssemblyFileHashAlgorithmName);
											num = 112;
											while (true)
											{
												if (num != 112)
												{
													if (num != 1093)
													{
														goto IL_06d2;
													}
													switch (num)
													{
													case 83:
														goto end_IL_01cf;
													case 66:
														goto end_IL_01e2;
													case 26:
														goto end_IL_01f6;
													case 105:
														goto end_IL_020b;
													case 23:
													case 84:
														goto end_IL_0220;
													case 73:
														goto end_IL_0230;
													case 14:
													case 87:
														goto end_IL_0240;
													case 100:
														goto end_IL_0250;
													case 101:
														goto end_IL_0260;
													case 19:
													case 24:
													case 31:
													case 42:
													case 63:
													case 64:
													case 70:
													case 79:
													case 80:
													case 91:
													case 98:
														goto IL_028c;
													case 7:
													case 69:
														goto IL_029c;
													case 89:
														goto IL_02a5;
													case 52:
														goto IL_02b3;
													case 4:
														goto IL_02c1;
													case 62:
														goto IL_02cf;
													case 35:
													case 47:
														goto IL_02dd;
													case 40:
													case 58:
														goto IL_02eb;
													case 60:
														goto IL_02ff;
													case 29:
													case 45:
														goto IL_030d;
													case 74:
														goto IL_034d;
													case 18:
														goto IL_0361;
													case 102:
														goto IL_0374;
													case 28:
														goto IL_0382;
													case 32:
													case 33:
														goto IL_0390;
													case 96:
														goto IL_03ac;
													case 51:
													case 55:
														goto IL_03b7;
													case 77:
														goto IL_03d0;
													case 0:
														goto IL_03de;
													case 34:
														goto IL_03ec;
													case 5:
														goto IL_03ff;
													case 1:
														goto IL_040d;
													case 15:
													case 88:
														goto IL_041b;
													case 85:
														goto IL_045b;
													case 50:
														goto IL_046f;
													case 22:
														goto IL_0482;
													case 38:
													case 53:
														goto IL_0490;
													case 17:
													case 67:
														goto IL_049e;
													case 57:
													case 92:
														goto IL_04ac;
													case 41:
														goto IL_04ba;
													case 9:
													case 61:
														goto IL_04c8;
													case 8:
														goto IL_0508;
													case 94:
														goto IL_051c;
													case 75:
														goto IL_052f;
													case 13:
													case 48:
														goto IL_053d;
													case 16:
														goto IL_056f;
													case 86:
														goto IL_057d;
													case 43:
														goto IL_0590;
													case 25:
													case 82:
														goto IL_059b;
													case 71:
														goto IL_05db;
													case 44:
														goto IL_05ef;
													case 3:
													case 68:
														goto IL_0614;
													case 6:
														goto IL_0622;
													case 93:
													case 97:
														goto IL_0635;
													case 56:
														goto IL_064c;
													case 103:
														goto IL_066f;
													case 11:
														goto IL_0679;
													case 39:
														goto IL_0690;
													case 72:
														goto IL_06a3;
													case 12:
														goto IL_06b1;
													case 95:
														goto IL_06bf;
													case 2:
													case 10:
													case 20:
													case 21:
													case 27:
													case 30:
													case 36:
													case 46:
													case 49:
													case 59:
													case 65:
													case 76:
													case 78:
													case 81:
													case 90:
													case 99:
													case 104:
														goto IL_06d2;
													case 37:
													case 54:
														goto IL_06f7;
													}
													continue;
												}
												ptr2 = ptr;
												goto IL_028c;
												IL_0690:
												ptr2 += 8;
												goto IL_028c;
												IL_06a3:
												array[num4] = 0;
												goto IL_06b1;
												IL_06d2:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_06a3;
												IL_028c:
												if (num5 != 1)
												{
													goto IL_029c;
												}
												goto IL_06f7;
												IL_06f7:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_029c:
												b = *ptr2;
												goto IL_02a5;
												IL_02a5:
												ptr2++;
												goto IL_02b3;
												IL_02b3:
												if (b >= 1)
												{
													goto IL_02c1;
												}
												goto IL_06d2;
												IL_02c1:
												if (b <= 9)
												{
													goto IL_02cf;
												}
												goto IL_06d2;
												IL_02cf:
												if (5 < b)
												{
													goto IL_02dd;
												}
												goto IL_0482;
												IL_02dd:
												if (7 < b)
												{
													goto IL_02eb;
												}
												goto IL_03ac;
												IL_02eb:
												if (8 >= b)
												{
													num = 60;
													goto IL_02ff;
												}
												goto IL_0374;
												IL_06b1:
												num4++;
												goto IL_06bf;
												IL_02ff:
												if (8 <= b)
												{
													goto IL_030d;
												}
												goto IL_06d2;
												IL_030d:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_034d;
												IL_034d:
												array[num4 - 2] = 0;
												goto IL_0361;
												IL_0361:
												num4--;
												goto IL_028c;
												IL_0374:
												if (9 >= b)
												{
													goto IL_0382;
												}
												goto IL_06d2;
												IL_0382:
												if (9 <= b)
												{
													goto IL_0390;
												}
												goto IL_06d2;
												IL_0390:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												goto IL_028c;
												IL_03ac:
												if (7 <= b)
												{
													goto IL_03b7;
												}
												goto IL_03ff;
												IL_03b7:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												goto IL_03d0;
												IL_03d0:
												array[num4] = 0;
												goto IL_03de;
												IL_03de:
												num4++;
												goto IL_03ec;
												IL_03ec:
												ptr2 += 8;
												goto IL_028c;
												IL_03ff:
												if (6 >= b)
												{
													goto IL_040d;
												}
												goto IL_06d2;
												IL_040d:
												if (6 <= b)
												{
													goto IL_041b;
												}
												goto IL_06d2;
												IL_041b:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_045b;
												IL_045b:
												array[num4 - 2] = 0;
												goto IL_046f;
												IL_046f:
												num4--;
												goto IL_028c;
												IL_0482:
												if (5 > b)
												{
													goto IL_0490;
												}
												goto IL_0635;
												IL_0490:
												if (2 < b)
												{
													goto IL_049e;
												}
												goto IL_0590;
												IL_049e:
												if (3 < b)
												{
													goto IL_04ac;
												}
												goto IL_052f;
												IL_04ac:
												if (4 >= b)
												{
													goto IL_04ba;
												}
												goto IL_06d2;
												IL_04ba:
												if (4 <= b)
												{
													goto IL_04c8;
												}
												goto IL_06d2;
												IL_04c8:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_0508;
												IL_0508:
												array[num4 - 2] = 0;
												goto IL_051c;
												IL_051c:
												num4--;
												goto IL_028c;
												IL_052f:
												if (3 <= b)
												{
													goto IL_053d;
												}
												goto IL_06d2;
												IL_053d:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												num = 16;
												goto IL_056f;
												IL_056f:
												ptr2 += 8;
												goto IL_057d;
												IL_057d:
												num4--;
												goto IL_028c;
												IL_0590:
												if (2 <= b)
												{
													goto IL_059b;
												}
												num = 3;
												goto IL_0614;
												IL_059b:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_05db;
												IL_05db:
												array[num4 - 2] = 0;
												goto IL_05ef;
												IL_05ef:
												num4--;
												num = 98;
												goto IL_028c;
												IL_06bf:
												ptr2 += 8;
												goto IL_028c;
												IL_0614:
												if (1 >= b)
												{
													goto IL_0622;
												}
												goto IL_06d2;
												IL_0622:
												if (1 <= b)
												{
												}
												goto IL_06d2;
												IL_0635:
												array[num4] = 0;
												num = 56;
												goto IL_064c;
												IL_064c:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												goto IL_066f;
												IL_066f:
												array2[num4] = null;
												goto IL_0679;
												IL_0679:
												num4++;
												num = 39;
												goto IL_0690;
												continue;
												end_IL_01cf:
												break;
											}
											continue;
											end_IL_01e2:
											break;
										}
										continue;
										end_IL_01f6:
										break;
									}
									continue;
									end_IL_020b:
									break;
								}
								continue;
								end_IL_0220:
								break;
							}
							continue;
							end_IL_0230:
							break;
						}
						continue;
						end_IL_0240:
						break;
					}
					continue;
					end_IL_0250:
					break;
				}
				continue;
				end_IL_0260:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_3)
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 103;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CultureTypesFileSystemRights.SerializationMissingKeysInvalidFilterCriteriaException);
										num = 38;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 53;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0260:
																	if (b >= 1)
																	{
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_0240:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0230:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0223:
																								if (3 < b)
																								{
																									while (true)
																									{
																										IL_0213:
																										if (4 < b)
																										{
																											while (5 >= b)
																											{
																												num = 116;
																												while (true)
																												{
																													if (num != 116)
																													{
																														if (num != 1097)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 54:
																														case 64:
																															goto IL_0200;
																														case 78:
																															goto IL_0213;
																														case 37:
																														case 86:
																															goto IL_0223;
																														case 31:
																															goto IL_0230;
																														case 95:
																															goto IL_0240;
																														case 30:
																															goto IL_0250;
																														case 59:
																															goto IL_0260;
																														case 16:
																															goto end_IL_0260;
																														case 53:
																															goto end_IL_0270;
																														case 99:
																															goto end_IL_0280;
																														case 40:
																															goto IL_0296;
																														case 28:
																															goto IL_02a4;
																														case 8:
																															goto IL_02af;
																														case 11:
																														case 39:
																															goto IL_02bd;
																														case 25:
																															goto IL_02d6;
																														case 71:
																															goto IL_02e6;
																														case 60:
																															goto IL_02f4;
																														case 76:
																															goto IL_030d;
																														case 47:
																															goto IL_0324;
																														case 52:
																														case 81:
																															goto IL_0337;
																														case 43:
																															goto IL_0360;
																														case 1:
																														case 87:
																															goto IL_0370;
																														case 97:
																															goto IL_0388;
																														case 36:
																														case 63:
																															goto IL_03a9;
																														case 48:
																															goto IL_03b7;
																														case 89:
																															goto IL_03da;
																														case 27:
																															goto IL_03e4;
																														case 17:
																															goto IL_03f2;
																														case 82:
																															goto IL_0405;
																														case 88:
																														case 91:
																															goto IL_0418;
																														case 77:
																															goto IL_0458;
																														case 3:
																															goto IL_0475;
																														case 5:
																															goto IL_0488;
																														case 62:
																															goto IL_0496;
																														case 4:
																															goto IL_04a4;
																														case 15:
																															goto IL_04af;
																														case 12:
																														case 18:
																															goto IL_04bd;
																														case 72:
																															goto IL_04fd;
																														case 50:
																															goto IL_0511;
																														case 83:
																															goto IL_0524;
																														case 68:
																															goto IL_0532;
																														case 58:
																														case 109:
																															goto IL_0540;
																														case 67:
																															goto IL_0563;
																														case 65:
																															goto IL_0571;
																														case 26:
																															goto IL_057f;
																														case 10:
																														case 100:
																															goto IL_0592;
																														case 108:
																															goto IL_05f4;
																														case 101:
																															goto IL_060d;
																														case 13:
																															goto IL_0618;
																														case 9:
																														case 23:
																															goto IL_0623;
																														case 102:
																															goto IL_063c;
																														case 2:
																															goto IL_0647;
																														case 6:
																														case 7:
																														case 21:
																														case 24:
																														case 29:
																														case 32:
																														case 34:
																														case 35:
																														case 42:
																														case 46:
																														case 74:
																														case 75:
																														case 79:
																														case 85:
																														case 90:
																														case 92:
																														case 94:
																														case 96:
																														case 105:
																														case 107:
																															goto end_IL_01ed;
																														case 0:
																														case 14:
																														case 19:
																														case 22:
																														case 33:
																														case 49:
																														case 51:
																														case 61:
																														case 66:
																														case 69:
																														case 70:
																														case 80:
																														case 93:
																														case 98:
																															goto end_IL_028b;
																														case 38:
																															goto end_IL_0670;
																														case 106:
																															goto end_IL_0683;
																														case 104:
																															goto end_IL_068d;
																														case 44:
																															goto end_IL_06a1;
																														case 20:
																														case 41:
																															goto end_IL_06b6;
																														case 103:
																															goto end_IL_06c6;
																														case 73:
																														case 84:
																															goto end_IL_06d6;
																														case 55:
																															goto end_IL_06e6;
																														case 56:
																															goto end_IL_06ff;
																														case 45:
																														case 57:
																															goto IL_071a;
																														}
																														continue;
																													}
																													if (5 > b)
																													{
																														break;
																													}
																													goto IL_03a9;
																													IL_03da:
																													array2[num5] = null;
																													goto IL_03e4;
																													IL_03f2:
																													ptr2 += 8;
																													goto end_IL_028b;
																													IL_03e4:
																													num5++;
																													goto IL_03f2;
																													IL_03a9:
																													array[num5] = 0;
																													goto IL_03b7;
																													IL_03b7:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_03da;
																													continue;
																													end_IL_01ed:
																													break;
																												}
																												break;
																												IL_0200:;
																											}
																											break;
																										}
																										goto IL_0405;
																										IL_0405:
																										if (4 <= b)
																										{
																											goto end_IL_028b;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_0296;
																								IL_0388:
																								num5--;
																								goto end_IL_028b;
																								IL_0296:
																								if (3 > b)
																								{
																									goto IL_02a4;
																								}
																								goto IL_0370;
																								IL_02a4:
																								if (1 >= b)
																								{
																									goto IL_02af;
																								}
																								goto IL_02e6;
																								IL_02af:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_02bd;
																								IL_02bd:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_02d6;
																								IL_02d6:
																								array[num5] = 0;
																								goto IL_030d;
																								IL_030d:
																								num5++;
																								num = 47;
																								goto IL_0324;
																								IL_0324:
																								ptr2 += 8;
																								goto end_IL_028b;
																								IL_02e6:
																								if (2 < b)
																								{
																									break;
																								}
																								goto IL_02f4;
																								IL_02f4:
																								if (2 > b)
																								{
																									num = 105;
																									break;
																								}
																								goto IL_0337;
																								IL_0370:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_028b;
																								IL_0337:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0360;
																								IL_0360:
																								ptr2 += 8;
																								goto IL_0388;
																							}
																							break;
																						}
																						goto IL_0418;
																						IL_0475:
																						num5--;
																						goto end_IL_028b;
																						IL_0418:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0458;
																						IL_0458:
																						array[num5 - 2] = 0;
																						num = 3;
																						goto IL_0475;
																					}
																					break;
																				}
																				goto IL_0488;
																				IL_0647:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_0488:
																				if (9 >= b)
																				{
																					goto IL_0496;
																				}
																				goto IL_060d;
																				IL_0496:
																				if (9 > b)
																				{
																					goto IL_04a4;
																				}
																				goto IL_0592;
																				IL_04a4:
																				if (7 >= b)
																				{
																					goto IL_04af;
																				}
																				goto IL_0524;
																				IL_04af:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04bd;
																				IL_04bd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04fd;
																				IL_04fd:
																				array[num5 - 2] = 0;
																				goto IL_0511;
																				IL_0511:
																				num5--;
																				goto end_IL_028b;
																				IL_0524:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0532;
																				IL_0532:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0540;
																				IL_0540:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0563;
																				IL_0563:
																				array[num5] = 0;
																				goto IL_0571;
																				IL_0571:
																				num5++;
																				goto IL_057f;
																				IL_057f:
																				ptr2 += 8;
																				goto end_IL_028b;
																				IL_0592:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05f4;
																				IL_05f4:
																				num5 -= 2;
																				num = 66;
																				goto end_IL_028b;
																				IL_060d:
																				if (10 >= b)
																				{
																					goto IL_0618;
																				}
																				goto IL_063c;
																				IL_0618:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0623;
																				IL_0623:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_028b;
																				IL_063c:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0647;
																			}
																			break;
																			IL_0250:;
																		}
																	}
																	else
																	{
																		num = 34;
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_028b;
																	continue;
																	end_IL_0260:
																	break;
																}
																continue;
																end_IL_0270:
																break;
															}
															continue;
															end_IL_0280:
															break;
														}
														continue;
														end_IL_028b:
														break;
													}
													continue;
												}
												goto IL_071a;
												IL_071a:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0670:
												break;
											}
											continue;
											end_IL_0683:
											break;
										}
										continue;
										end_IL_068d:
										break;
									}
									continue;
									end_IL_06a1:
									break;
								}
								continue;
								end_IL_06b6:
								break;
							}
							continue;
							end_IL_06c6:
							break;
						}
						continue;
						end_IL_06d6:
						break;
					}
					continue;
					end_IL_06e6:
					break;
				}
				continue;
				end_IL_06ff:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_3, int int_4)
	{
		int num = 91;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 64;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								num = 22;
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ModifyAccessRuleCompilationRelaxations.SecurityDocumentAddClaim);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0228:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0208:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01f8:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_01e8:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_01db:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 <= b)
																												{
																													num = 98;
																													while (num != 98)
																													{
																														if (num != 1079)
																														{
																															goto IL_0253;
																														}
																														switch (num)
																														{
																														case 36:
																															goto IL_01b8;
																														case 3:
																														case 78:
																															goto IL_01cb;
																														case 75:
																															goto IL_01db;
																														case 12:
																														case 25:
																															goto IL_01e8;
																														case 41:
																															goto IL_01f8;
																														case 42:
																															goto IL_0208;
																														case 59:
																															goto IL_0218;
																														case 61:
																															goto IL_0228;
																														case 58:
																															goto end_IL_0228;
																														case 27:
																														case 69:
																															goto end_IL_0238;
																														case 16:
																														case 17:
																															goto IL_0253;
																														case 4:
																														case 45:
																															goto IL_02c3;
																														case 24:
																															goto IL_02ce;
																														case 47:
																															goto IL_02dc;
																														case 38:
																														case 62:
																															goto IL_02ef;
																														case 31:
																															goto IL_0318;
																														case 15:
																															goto IL_0326;
																														case 67:
																															goto IL_0339;
																														case 74:
																															goto IL_034c;
																														case 5:
																														case 51:
																															goto IL_0363;
																														case 76:
																															goto IL_0371;
																														case 19:
																														case 43:
																															goto IL_037f;
																														case 0:
																														case 81:
																															goto IL_0397;
																														case 26:
																															goto IL_03a5;
																														case 28:
																														case 63:
																															goto IL_03b3;
																														case 60:
																														case 84:
																															goto IL_03cf;
																														case 70:
																															goto IL_03dd;
																														case 49:
																															goto IL_0400;
																														case 13:
																															goto IL_0413;
																														case 21:
																															goto IL_0421;
																														case 6:
																															goto IL_0434;
																														case 30:
																															goto IL_043f;
																														case 33:
																														case 80:
																															goto IL_044a;
																														case 54:
																															goto IL_048a;
																														case 9:
																															goto IL_049e;
																														case 1:
																														case 8:
																														case 11:
																														case 14:
																														case 20:
																														case 23:
																														case 48:
																														case 52:
																														case 55:
																														case 57:
																														case 71:
																														case 72:
																														case 73:
																														case 79:
																														case 82:
																														case 83:
																														case 87:
																															goto end_IL_01a5;
																														case 18:
																															goto IL_04d1;
																														case 50:
																															goto IL_04df;
																														case 53:
																															goto IL_04ed;
																														case 7:
																														case 10:
																														case 29:
																														case 32:
																														case 34:
																														case 65:
																														case 66:
																														case 68:
																														case 77:
																														case 88:
																														case 89:
																															goto end_IL_0248;
																														case 35:
																															goto end_IL_04fb;
																														case 56:
																															goto end_IL_050e;
																														case 37:
																															goto end_IL_0518;
																														case 22:
																															goto end_IL_0523;
																														case 46:
																															goto end_IL_0538;
																														case 64:
																														case 85:
																															goto end_IL_054d;
																														case 44:
																															goto end_IL_0566;
																														case 2:
																														case 86:
																															goto end_IL_0576;
																														case 90:
																															goto end_IL_058f;
																														case 91:
																															goto end_IL_059f;
																														case 39:
																														case 40:
																															goto IL_05ba;
																														}
																														continue;
																														end_IL_01a5:
																														break;
																													}
																													break;
																													IL_01b8:;
																												}
																												break;
																												IL_01cb:;
																											}
																											break;
																										}
																										goto IL_0253;
																										IL_0339:
																										num5 -= 2;
																										goto end_IL_0248;
																										IL_0253:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0339;
																									}
																									break;
																								}
																								goto IL_0434;
																								IL_049e:
																								num5--;
																								goto end_IL_0248;
																								IL_0434:
																								if (3 < b)
																								{
																									break;
																								}
																								goto IL_043f;
																								IL_043f:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_044a;
																								IL_044a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_048a;
																								IL_048a:
																								array[num5 - 2] = 0;
																								goto IL_049e;
																							}
																							break;
																						}
																						goto IL_02ef;
																						IL_0326:
																						num5--;
																						goto end_IL_0248;
																						IL_02ef:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0318;
																						IL_0318:
																						ptr2 += 8;
																						goto IL_0326;
																					}
																					break;
																				}
																				goto IL_02c3;
																				IL_0371:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_037f;
																				IL_02c3:
																				if (6 < b)
																				{
																					goto IL_02ce;
																				}
																				goto IL_034c;
																				IL_02ce:
																				if (7 >= b)
																				{
																					goto IL_02dc;
																				}
																				goto IL_0397;
																				IL_02dc:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_03cf;
																				IL_03cf:
																				array[num5] = 0;
																				goto IL_03dd;
																				IL_03dd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0400;
																				IL_0400:
																				array2[num5] = null;
																				num = 13;
																				goto IL_0413;
																				IL_0413:
																				num5++;
																				goto IL_0421;
																				IL_0421:
																				ptr2 += 8;
																				goto end_IL_0248;
																				IL_0397:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_03a5;
																				IL_03a5:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_03b3;
																				IL_03b3:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0248;
																				IL_034c:
																				if (6 <= b)
																				{
																					goto end_IL_0248;
																				}
																				num = 51;
																				goto IL_0363;
																				IL_037f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0248;
																				IL_0363:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0371;
																			}
																			break;
																			IL_0218:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d1;
																	IL_04ed:
																	ptr2 += 8;
																	goto end_IL_0248;
																	IL_04df:
																	num5++;
																	goto IL_04ed;
																	IL_04d1:
																	array[num5] = 0;
																	goto IL_04df;
																	continue;
																	end_IL_0228:
																	break;
																}
																continue;
																end_IL_0238:
																break;
															}
															continue;
															end_IL_0248:
															break;
														}
														continue;
													}
													goto IL_05ba;
													IL_05ba:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04fb:
													break;
												}
												continue;
												end_IL_050e:
												break;
											}
											continue;
											end_IL_0518:
											break;
										}
										continue;
										end_IL_0523:
										break;
									}
									continue;
									end_IL_0538:
									break;
								}
								continue;
								end_IL_054d:
								break;
							}
							continue;
							end_IL_0566:
							break;
						}
						continue;
						end_IL_0576:
						break;
					}
					continue;
					end_IL_058f:
					break;
				}
				continue;
				end_IL_059f:
				break;
			}
		}
	}

	private static int smethod_5(int int_3, int int_4)
	{
		int num = int_3;
		int num2 = int_4;
		num += num2;
		int num3 = num;
		num = int_3;
		num2 = int_4;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 129;
		num2 = 43;
		return num + 43;
	}

	private unsafe static int smethod_6()
	{
		int num = 84;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 7;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setDisallowCodeDownloadCheckValueReadPermission.IsNestedFamilyDaylightDelta);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_036d:
														byte b = *ptr2;
														while (true)
														{
															IL_035d:
															ptr2++;
															while (true)
															{
																IL_034d:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_032d:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_031d:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_030d:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02fd:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02f0:
																											if (10 <= b)
																											{
																												while (true)
																												{
																													IL_02e0:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_02bb:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														while (true)
																														{
																															IL_02af:
																															array2[num5] = null;
																															while (true)
																															{
																																IL_029f:
																																num5++;
																																while (true)
																																{
																																	IL_0286:
																																	ptr2 += 8;
																																	num = 153;
																																	while (num != 153)
																																	{
																																		if (num != 1134)
																																		{
																																			goto IL_07f6;
																																		}
																																		switch (num)
																																		{
																																		case 24:
																																			goto IL_0286;
																																		case 66:
																																			goto IL_029f;
																																		case 39:
																																			goto IL_02af;
																																		case 94:
																																			goto IL_02bb;
																																		case 12:
																																		case 71:
																																			goto IL_02e0;
																																		case 70:
																																			goto IL_02f0;
																																		case 45:
																																		case 57:
																																			goto IL_02fd;
																																		case 48:
																																			goto IL_030d;
																																		case 82:
																																		case 119:
																																			goto IL_031d;
																																		case 121:
																																			goto IL_032d;
																																		case 67:
																																			goto IL_033d;
																																		case 60:
																																			goto IL_034d;
																																		case 127:
																																			goto IL_035d;
																																		case 136:
																																		case 144:
																																			goto IL_036d;
																																		case 38:
																																			goto IL_0378;
																																		case 1:
																																			goto IL_0383;
																																		case 3:
																																			goto IL_03a4;
																																		case 130:
																																			goto IL_03bb;
																																		case 56:
																																		case 81:
																																			goto IL_03c9;
																																		case 86:
																																			goto IL_040d;
																																		case 10:
																																			goto IL_0421;
																																		case 23:
																																		case 34:
																																			goto IL_0434;
																																		case 19:
																																			goto IL_0474;
																																		case 85:
																																			goto IL_0488;
																																		case 107:
																																		case 118:
																																			goto IL_049b;
																																		case 31:
																																		case 104:
																																			goto IL_04a6;
																																		case 87:
																																			goto IL_04b4;
																																		case 111:
																																			goto IL_04c7;
																																		case 59:
																																		case 89:
																																			goto IL_04d2;
																																		case 110:
																																			goto IL_04ee;
																																		case 65:
																																			goto IL_04fc;
																																		case 8:
																																		case 53:
																																			goto IL_050a;
																																		case 54:
																																			goto IL_0575;
																																		case 62:
																																			goto IL_0588;
																																		case 93:
																																		case 131:
																																			goto IL_0596;
																																		case 61:
																																			goto IL_05a4;
																																		case 124:
																																			goto IL_05b2;
																																		case 15:
																																		case 52:
																																			goto IL_05bd;
																																		case 40:
																																			goto IL_05cb;
																																		case 68:
																																		case 145:
																																			goto IL_05d9;
																																		case 32:
																																			goto IL_0602;
																																		case 58:
																																			goto IL_061b;
																																		case 36:
																																		case 106:
																																			goto IL_0626;
																																		case 49:
																																			goto IL_0666;
																																		case 16:
																																			goto IL_067a;
																																		case 26:
																																			goto IL_068d;
																																		case 25:
																																			goto IL_0698;
																																		case 112:
																																		case 113:
																																			goto IL_06a3;
																																		case 43:
																																			goto IL_06bc;
																																		case 108:
																																			goto IL_06ca;
																																		case 103:
																																			goto IL_06e1;
																																		case 63:
																																		case 115:
																																			goto IL_0710;
																																		case 134:
																																			goto IL_0737;
																																		case 30:
																																			goto IL_0745;
																																		case 109:
																																			goto IL_0758;
																																		case 14:
																																		case 123:
																																			goto IL_0763;
																																		case 99:
																																			goto IL_0771;
																																		case 5:
																																		case 79:
																																			goto IL_077f;
																																		case 88:
																																			goto IL_07a8;
																																		case 140:
																																			goto IL_07b6;
																																		case 22:
																																			goto IL_07c9;
																																		case 33:
																																		case 77:
																																			goto IL_07dd;
																																		case 55:
																																			goto IL_07e8;
																																		case 122:
																																		case 139:
																																			goto IL_07f6;
																																		case 117:
																																			goto IL_0804;
																																		case 135:
																																			goto IL_081c;
																																		case 142:
																																			goto IL_082a;
																																		case 47:
																																		case 100:
																																			goto IL_0848;
																																		case 4:
																																			goto IL_0890;
																																		case 41:
																																		case 102:
																																			goto IL_08a0;
																																		case 0:
																																		case 2:
																																		case 6:
																																		case 9:
																																		case 11:
																																		case 13:
																																		case 18:
																																		case 28:
																																		case 29:
																																		case 37:
																																		case 44:
																																		case 69:
																																		case 72:
																																		case 74:
																																		case 75:
																																		case 76:
																																		case 90:
																																		case 95:
																																		case 120:
																																		case 126:
																																		case 129:
																																		case 132:
																																		case 137:
																																		case 138:
																																		case 143:
																																			goto end_IL_033d;
																																		case 17:
																																		case 20:
																																		case 21:
																																		case 35:
																																		case 42:
																																		case 46:
																																		case 51:
																																		case 64:
																																		case 78:
																																		case 80:
																																		case 91:
																																		case 96:
																																		case 105:
																																		case 114:
																																		case 125:
																																		case 133:
																																		case 141:
																																			goto end_IL_0273;
																																		case 146:
																																			goto end_IL_08c8;
																																		case 27:
																																			goto end_IL_08db;
																																		case 116:
																																			goto end_IL_08e5;
																																		case 7:
																																			goto end_IL_08f0;
																																		case 92:
																																		case 97:
																																			goto end_IL_0900;
																																		case 50:
																																			goto end_IL_0910;
																																		case 73:
																																		case 128:
																																			goto end_IL_0929;
																																		case 83:
																																			goto end_IL_0939;
																																		case 84:
																																			goto end_IL_0949;
																																		case 98:
																																		case 101:
																																			goto IL_0964;
																																		}
																																		continue;
																																		end_IL_0273:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0378;
																											IL_0383:
																											if (9 > b)
																											{
																												goto end_IL_033d;
																											}
																											break;
																											IL_0378:
																											if (9 < b)
																											{
																												num = 9;
																												goto end_IL_033d;
																											}
																											goto IL_0383;
																										}
																										break;
																									}
																									goto IL_03a4;
																									IL_040d:
																									array[num5 - 2] = 0;
																									goto IL_0421;
																									IL_03a4:
																									if (11 < b)
																									{
																										goto end_IL_033d;
																									}
																									num = 130;
																									goto IL_03bb;
																									IL_0421:
																									num5--;
																									break;
																									IL_03bb:
																									if (11 > b)
																									{
																										goto end_IL_033d;
																									}
																									goto IL_03c9;
																									IL_03c9:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_040d;
																								}
																								break;
																							}
																							goto IL_0434;
																							IL_0488:
																							num5--;
																							break;
																							IL_0434:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0474;
																							IL_0474:
																							array[num5 - 2] = 0;
																							goto IL_0488;
																						}
																						break;
																					}
																					goto IL_049b;
																					IL_0575:
																					num5 -= 2;
																					break;
																					IL_049b:
																					if (14 < b)
																					{
																						goto IL_04a6;
																					}
																					goto IL_04c7;
																					IL_04a6:
																					if (15 < b)
																					{
																						goto end_IL_033d;
																					}
																					goto IL_04b4;
																					IL_04b4:
																					if (15 > b)
																					{
																					}
																					goto end_IL_033d;
																					IL_04c7:
																					if (14 <= b)
																					{
																						goto IL_04d2;
																					}
																					goto IL_04ee;
																					IL_04d2:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					break;
																					IL_04ee:
																					if (13 < b)
																					{
																						goto end_IL_033d;
																					}
																					goto IL_04fc;
																					IL_04fc:
																					if (13 > b)
																					{
																						goto end_IL_033d;
																					}
																					goto IL_050a;
																					IL_050a:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 54;
																					goto IL_0575;
																				}
																				break;
																			}
																			goto IL_0588;
																			IL_082a:
																			ptr2 += 8;
																			break;
																			IL_0588:
																			if (8 > b)
																			{
																				goto IL_0596;
																			}
																			goto IL_08a0;
																			IL_0596:
																			if (4 >= b)
																			{
																				goto IL_05a4;
																			}
																			goto IL_0758;
																			IL_05a4:
																			if (4 > b)
																			{
																				goto IL_05b2;
																			}
																			goto IL_0710;
																			IL_05b2:
																			if (2 < b)
																			{
																				goto IL_05bd;
																			}
																			goto IL_061b;
																			IL_05bd:
																			if (3 < b)
																			{
																				goto end_IL_033d;
																			}
																			goto IL_05cb;
																			IL_05cb:
																			if (3 > b)
																			{
																				goto end_IL_033d;
																			}
																			goto IL_05d9;
																			IL_05d9:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0602;
																			IL_0602:
																			array[num5 - 1] = 5;
																			break;
																			IL_061b:
																			if (2 <= b)
																			{
																				goto IL_0626;
																			}
																			goto IL_068d;
																			IL_0626:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0666;
																			IL_0666:
																			array[num5 - 2] = 0;
																			goto IL_067a;
																			IL_067a:
																			num5--;
																			break;
																			IL_068d:
																			if (1 < b)
																			{
																				num = 76;
																				goto end_IL_033d;
																			}
																			goto IL_0698;
																			IL_0698:
																			if (1 > b)
																			{
																				num = 120;
																				goto end_IL_033d;
																			}
																			goto IL_06a3;
																			IL_06a3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_06bc;
																			IL_06bc:
																			array[num5] = 0;
																			goto IL_06ca;
																			IL_06ca:
																			num5++;
																			num = 103;
																			goto IL_06e1;
																			IL_06e1:
																			ptr2 += 8;
																			break;
																			IL_0848:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 4;
																			goto IL_0890;
																			IL_08a0:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			break;
																			IL_0710:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			num = 134;
																			goto IL_0737;
																			IL_0737:
																			ptr2 += 8;
																			goto IL_0745;
																			IL_0745:
																			num5--;
																			break;
																			IL_0758:
																			if (6 < b)
																			{
																				goto IL_0763;
																			}
																			goto IL_07c9;
																			IL_0763:
																			if (7 < b)
																			{
																				goto end_IL_033d;
																			}
																			goto IL_0771;
																			IL_0771:
																			if (7 > b)
																			{
																				goto end_IL_033d;
																			}
																			goto IL_077f;
																			IL_077f:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07a8;
																			IL_07a8:
																			ptr2 += 8;
																			goto IL_07b6;
																			IL_07b6:
																			num5--;
																			break;
																			IL_07c9:
																			if (6 > b)
																			{
																				num = 33;
																				goto IL_07dd;
																			}
																			goto IL_0848;
																			IL_0890:
																			num5 -= 3;
																			break;
																			IL_07dd:
																			if (5 < b)
																			{
																				num = 11;
																				goto end_IL_033d;
																			}
																			goto IL_07e8;
																			IL_07e8:
																			if (5 > b)
																			{
																				goto end_IL_033d;
																			}
																			goto IL_07f6;
																			IL_07f6:
																			array[num5] = 5;
																			goto IL_0804;
																			IL_0804:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_081c;
																			IL_081c:
																			num5++;
																			goto IL_082a;
																		}
																		goto end_IL_034d;
																		continue;
																		end_IL_033d:
																		break;
																		IL_033d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_034d:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0964;
												IL_0964:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c8:
												break;
											}
											continue;
											end_IL_08db:
											break;
										}
										continue;
										end_IL_08e5:
										break;
									}
									continue;
									end_IL_08f0:
									break;
								}
								continue;
								end_IL_0900:
								break;
							}
							continue;
							end_IL_0910:
							break;
						}
						continue;
						end_IL_0929:
						break;
					}
					continue;
					end_IL_0939:
					break;
				}
				continue;
				end_IL_0949:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_3, int int_4)
	{
		int num = 27;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_3;
									while (true)
									{
										array3[1] = int_4;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref opLessThanTransformMetadataSize.getValidOnFormatStubInfo);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 61;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_01d5:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01b8:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01a8:
																						if (4 <= b)
																						{
																							num = 94;
																							while (true)
																							{
																								if (num != 94)
																								{
																									if (num != 1075)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 49:
																										goto IL_01a8;
																									case 84:
																										goto IL_01b8;
																									case 3:
																										goto end_IL_01b8;
																									case 30:
																										goto IL_01d5;
																									case 61:
																										goto end_IL_01d5;
																									case 8:
																									case 44:
																										goto end_IL_01e5;
																									case 34:
																										goto IL_0209;
																									case 40:
																										goto IL_0219;
																									case 16:
																										goto IL_0224;
																									case 50:
																										goto IL_0237;
																									case 11:
																										goto IL_0242;
																									case 56:
																									case 65:
																										goto IL_0263;
																									case 35:
																										goto IL_0271;
																									case 6:
																									case 38:
																										goto IL_027f;
																									case 69:
																										goto IL_02bf;
																									case 25:
																										goto IL_02d3;
																									case 17:
																									case 72:
																										goto IL_02e6;
																									case 48:
																										goto IL_0354;
																									case 73:
																										goto IL_0367;
																									case 19:
																									case 60:
																										goto IL_0375;
																									case 74:
																										goto IL_038d;
																									case 75:
																										goto IL_039b;
																									case 80:
																										goto IL_03ae;
																									case 55:
																										goto IL_03b9;
																									case 45:
																									case 71:
																										goto IL_03c7;
																									case 28:
																										goto IL_03d5;
																									case 1:
																										goto IL_03f8;
																									case 4:
																										goto end_IL_0195;
																									case 78:
																										goto IL_0410;
																									case 62:
																									case 82:
																										goto IL_0423;
																									case 70:
																										goto IL_0431;
																									case 18:
																									case 32:
																										goto IL_0445;
																									case 41:
																										goto IL_0461;
																									case 39:
																										goto IL_048a;
																									case 68:
																										goto IL_0498;
																									case 5:
																									case 7:
																									case 12:
																									case 13:
																									case 21:
																									case 23:
																									case 24:
																									case 37:
																									case 42:
																									case 46:
																									case 53:
																									case 58:
																									case 64:
																									case 66:
																									case 76:
																									case 79:
																									case 87:
																										goto end_IL_01c5;
																									case 9:
																										goto IL_04d4;
																									case 86:
																										goto IL_04e2;
																									case 2:
																										goto IL_04f0;
																									case 10:
																									case 22:
																									case 31:
																									case 36:
																									case 51:
																									case 54:
																									case 57:
																									case 59:
																									case 63:
																									case 77:
																									case 85:
																										goto end_IL_01f5;
																									case 15:
																										goto end_IL_04fe;
																									case 47:
																										goto end_IL_0511;
																									case 20:
																										goto end_IL_051b;
																									case 83:
																										goto end_IL_0526;
																									case 43:
																										goto end_IL_053b;
																									case 33:
																									case 67:
																										goto end_IL_0550;
																									case 52:
																										goto end_IL_0560;
																									case 0:
																									case 29:
																										goto end_IL_0570;
																									case 26:
																										goto end_IL_0580;
																									case 27:
																										goto end_IL_0590;
																									case 14:
																									case 81:
																										goto IL_05ab;
																									}
																									continue;
																								}
																								goto IL_0461;
																								IL_048a:
																								ptr2 += 8;
																								goto IL_0498;
																								IL_0498:
																								num5--;
																								num = 36;
																								goto end_IL_01f5;
																								IL_0461:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_048a;
																								continue;
																								end_IL_0195:
																								break;
																							}
																							break;
																						}
																						goto IL_0219;
																						IL_02bf:
																						array[num5 - 2] = 0;
																						goto IL_02d3;
																						IL_02d3:
																						num5--;
																						goto end_IL_01f5;
																						IL_0219:
																						if (2 >= b)
																						{
																							goto IL_0224;
																						}
																						goto IL_0263;
																						IL_0224:
																						if (2 <= b)
																						{
																							goto IL_02e6;
																						}
																						goto IL_038d;
																						IL_038d:
																						if (1 < b)
																						{
																							goto end_IL_01c5;
																						}
																						goto IL_039b;
																						IL_039b:
																						if (1 > b)
																						{
																						}
																						goto end_IL_01c5;
																						IL_02e6:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0354;
																						IL_0354:
																						num5 -= 2;
																						goto end_IL_01f5;
																						IL_0263:
																						if (3 < b)
																						{
																							goto end_IL_01c5;
																						}
																						goto IL_0271;
																						IL_0271:
																						if (3 > b)
																						{
																							goto end_IL_01c5;
																						}
																						goto IL_027f;
																						IL_027f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_02bf;
																					}
																					goto IL_0402;
																				}
																				goto IL_0209;
																				IL_0431:
																				if (8 > b)
																				{
																					goto end_IL_01c5;
																				}
																				num = 32;
																				goto IL_0445;
																				IL_0209:
																				if (6 >= b)
																				{
																					goto IL_0237;
																				}
																				goto IL_03ae;
																				IL_0237:
																				if (6 <= b)
																				{
																					num = 51;
																					goto end_IL_01f5;
																				}
																				goto IL_0242;
																				IL_0242:
																				if (5 < b)
																				{
																					goto end_IL_01c5;
																				}
																				goto IL_0367;
																				IL_0367:
																				if (5 > b)
																				{
																					goto end_IL_01c5;
																				}
																				goto IL_0375;
																				IL_0375:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_01f5;
																				IL_0445:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_01f5;
																				IL_03ae:
																				if (7 >= b)
																				{
																					goto IL_03b9;
																				}
																				goto IL_0423;
																				IL_03b9:
																				if (7 > b)
																				{
																					goto end_IL_01c5;
																				}
																				goto IL_03c7;
																				IL_03c7:
																				array[num5] = 0;
																				goto IL_03d5;
																				IL_03d5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03f8;
																				IL_03f8:
																				array2[num5] = null;
																				goto IL_0402;
																				IL_0402:
																				num5++;
																				goto IL_0410;
																				IL_0410:
																				ptr2 += 8;
																				goto end_IL_01f5;
																				IL_0423:
																				if (8 < b)
																				{
																					goto end_IL_01c5;
																				}
																				goto IL_0431;
																				continue;
																				end_IL_01b8:
																				break;
																			}
																			continue;
																			end_IL_01c5:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d4;
																	IL_04f0:
																	ptr2 += 8;
																	goto end_IL_01f5;
																	IL_04e2:
																	num5++;
																	goto IL_04f0;
																	IL_04d4:
																	array[num5] = 0;
																	goto IL_04e2;
																	continue;
																	end_IL_01d5:
																	break;
																}
																continue;
																end_IL_01e5:
																break;
															}
															continue;
															end_IL_01f5:
															break;
														}
														continue;
													}
													goto IL_05ab;
													IL_05ab:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04fe:
													break;
												}
												continue;
												end_IL_0511:
												break;
											}
											continue;
											end_IL_051b:
											break;
										}
										continue;
										end_IL_0526:
										break;
									}
									continue;
									end_IL_053b:
									break;
								}
								continue;
								end_IL_0550:
								break;
							}
							continue;
							end_IL_0560:
							break;
						}
						continue;
						end_IL_0570:
						break;
					}
					continue;
					end_IL_0580:
					break;
				}
				continue;
				end_IL_0590:
				break;
			}
		}
	}

	static Class162()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 11;
					while (true)
					{
						if (num != 11)
						{
							if (num != 992)
							{
								break;
							}
							switch (num)
							{
							case 3:
							case 4:
								goto end_IL_0035;
							case 0:
								goto end_IL_0042;
							case 1:
								goto end_IL_0051;
							case 2:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0035:
						break;
					}
					continue;
					end_IL_0042:
					break;
				}
				continue;
				end_IL_0051:
				break;
			}
		}
	}
}
