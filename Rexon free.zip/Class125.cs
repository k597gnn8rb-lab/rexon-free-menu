using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Boost FPS", "Settings", "Reduces quality settings to boost performance.", false, 20, ModType.const_0, false)]
internal class Class125 : MonoBehaviour
{
	private float float_0;

	private ShadowQuality shadowQuality_0;

	private int int_0;

	private int int_1;

	private int int_2;

	private bool bool_0;

	private static bool bool_1;

	private static int int_3;

	private static float float_1;

	private static int int_4;

	private static int int_5;

	private static IntPtr[] getIsNestedAssemblygetCurrencyNativeName;

	private static IntPtr[] getActualValueCommonDesktopDirectory;

	private static IntPtr[] SetSignaturegetIsValueFaulted;

	private static IntPtr[] setPerMilleSymbolCreateDeformatter;

	private static IntPtr[] PoprefpopipopDNDS;

	private void OnEnable()
	{
		try
		{
			int num = 3;
			num = 44;
			num = 41;
			num = 40;
			num = 11;
			num = 13;
			num = 63;
			num = 37;
			num = 2331;
			num = 45;
			num = 2;
			num = 508;
			num = 254;
			object obj = this;
			float shadowDistance = QualitySettings.shadowDistance;
			double num2 = shadowDistance;
			((Class125)obj).float_0 = (float)num2;
			obj = this;
			ShadowQuality shadows = QualitySettings.shadows;
			num = (int)shadows;
			((Class125)obj).shadowQuality_0 = (ShadowQuality)num;
			obj = this;
			int targetFrameRate = Application.targetFrameRate;
			num = targetFrameRate;
			((Class125)obj).int_0 = num;
			obj = this;
			int vSyncCount = QualitySettings.vSyncCount;
			num = vSyncCount;
			((Class125)obj).int_1 = num;
			obj = this;
			int globalTextureMipmapLimit = QualitySettings.globalTextureMipmapLimit;
			num = globalTextureMipmapLimit;
			((Class125)obj).int_2 = num;
			obj = this;
			num = 1;
			((Class125)obj).bool_0 = true;
		}
		catch
		{
		}
	}

	private unsafe void Update()
	{
		int num = 235;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 205;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LeaveObserved.FileStreamAsyncResultfromInclusive);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_0543:
															if (b >= 1)
															{
																while (b <= 33)
																{
																	while (true)
																	{
																		if (17 >= b)
																		{
																			num = 131;
																			while (true)
																			{
																				if (17 > b)
																				{
																					while (true)
																					{
																						IL_0503:
																						if (8 < b)
																						{
																							goto IL_08d9;
																						}
																						while (true)
																						{
																							IL_04f6:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_04e6:
																									if (4 >= b)
																									{
																										while (true)
																										{
																											IL_04d6:
																											if (4 <= b)
																											{
																												while (true)
																												{
																													IL_04c6:
																													array[num6] = 0;
																													while (true)
																													{
																														IL_0498:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																														num = 282;
																														while (true)
																														{
																															if (num != 282)
																															{
																																if (num != 1263)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 114:
																																	goto IL_0498;
																																case 252:
																																case 256:
																																	goto IL_04c6;
																																case 247:
																																	goto IL_04d6;
																																case 126:
																																	goto IL_04e6;
																																case 272:
																																	goto IL_04f6;
																																case 103:
																																	goto IL_0503;
																																case 131:
																																	goto end_IL_0503;
																																case 22:
																																	goto end_IL_0513;
																																case 29:
																																	goto end_IL_0520;
																																case 62:
																																	goto IL_0543;
																																case 147:
																																	goto end_IL_0543;
																																case 19:
																																case 46:
																																	goto end_IL_0553;
																																case 3:
																																case 70:
																																	goto IL_056e;
																																case 118:
																																case 227:
																																	goto IL_0581;
																																case 35:
																																	goto IL_05ab;
																																case 257:
																																	goto IL_05b9;
																																case 245:
																																	goto IL_05df;
																																case 55:
																																	goto IL_05ed;
																																case 145:
																																	goto IL_0600;
																																case 268:
																																	goto IL_060e;
																																case 76:
																																case 87:
																																	goto IL_0619;
																																case 79:
																																	goto IL_0659;
																																case 249:
																																	goto IL_066d;
																																case 109:
																																	goto IL_0680;
																																case 8:
																																	goto IL_068e;
																																case 213:
																																case 225:
																																	goto IL_069c;
																																case 10:
																																	goto IL_06b5;
																																case 226:
																																	goto IL_06c3;
																																case 274:
																																	goto IL_06d1;
																																case 78:
																																	goto IL_06e4;
																																case 41:
																																	goto IL_06f2;
																																case 100:
																																case 215:
																																	goto IL_0700;
																																case 179:
																																	goto IL_0729;
																																case 17:
																																	goto IL_0737;
																																case 156:
																																	goto IL_074a;
																																case 214:
																																	goto IL_0758;
																																case 80:
																																	goto IL_0766;
																																case 90:
																																case 222:
																																	goto IL_0774;
																																case 209:
																																	goto IL_07b4;
																																case 169:
																																	goto IL_07c8;
																																case 178:
																																	goto IL_07e4;
																																case 216:
																																case 219:
																																	goto IL_07ef;
																																case 106:
																																	goto IL_082f;
																																case 122:
																																	goto IL_0843;
																																case 51:
																																	goto IL_0856;
																																case 73:
																																	goto IL_0864;
																																case 120:
																																case 195:
																																	goto IL_0872;
																																case 18:
																																	goto IL_08b2;
																																case 170:
																																	goto IL_08c6;
																																case 250:
																																	goto IL_08d9;
																																case 138:
																																	goto IL_08e7;
																																case 119:
																																	goto IL_08f5;
																																case 36:
																																	goto IL_0903;
																																case 12:
																																case 105:
																																	goto IL_090e;
																																case 113:
																																	goto end_IL_0485;
																																case 265:
																																	goto IL_0983;
																																case 238:
																																	goto IL_0991;
																																case 27:
																																case 128:
																																	goto IL_099f;
																																case 58:
																																	goto IL_09e8;
																																case 271:
																																	goto IL_09fc;
																																case 172:
																																	goto IL_0a0f;
																																case 163:
																																	goto IL_0a1d;
																																case 21:
																																case 223:
																																	goto IL_0a2b;
																																case 241:
																																	goto IL_0a39;
																																case 193:
																																	goto IL_0a5d;
																																case 246:
																																	goto IL_0a6b;
																																case 49:
																																	goto IL_0a8c;
																																case 211:
																																	goto IL_0a9a;
																																case 146:
																																case 207:
																																	goto IL_0aa5;
																																case 64:
																																	goto IL_0abd;
																																case 158:
																																	goto IL_0acb;
																																case 117:
																																case 260:
																																	goto IL_0ad9;
																																case 255:
																																	goto IL_0af2;
																																case 240:
																																	goto IL_0b00;
																																case 66:
																																	goto IL_0b0e;
																																case 243:
																																	goto IL_0b21;
																																case 38:
																																	goto IL_0b2c;
																																case 71:
																																case 208:
																																	goto IL_0b3a;
																																case 220:
																																	goto IL_0b7b;
																																case 99:
																																	goto IL_0b8f;
																																case 230:
																																	goto IL_0ba2;
																																case 116:
																																	goto IL_0bb0;
																																case 121:
																																case 123:
																																	goto IL_0bbe;
																																case 93:
																																	goto IL_0c10;
																																case 43:
																																	goto IL_0c23;
																																case 198:
																																	goto IL_0c31;
																																case 34:
																																case 264:
																																	goto IL_0c3c;
																																case 267:
																																	goto IL_0c7c;
																																case 125:
																																	goto IL_0c90;
																																case 236:
																																	goto IL_0ca3;
																																case 182:
																																	goto IL_0cb1;
																																case 33:
																																case 157:
																																	goto IL_0cbc;
																																case 4:
																																	goto IL_0cd0;
																																case 232:
																																	goto IL_0d18;
																																case 108:
																																	goto IL_0d2b;
																																case 141:
																																	goto IL_0d39;
																																case 202:
																																	goto IL_0d44;
																																case 186:
																																	goto IL_0d5b;
																																case 44:
																																case 187:
																																	goto IL_0d69;
																																case 153:
																																	goto IL_0d82;
																																case 218:
																																	goto IL_0d90;
																																case 154:
																																	goto IL_0d9e;
																																case 148:
																																case 184:
																																	goto IL_0db1;
																																case 160:
																																	goto IL_0dc5;
																																case 63:
																																	goto IL_0e04;
																																case 124:
																																	goto IL_0e17;
																																case 150:
																																	goto IL_0e25;
																																case 56:
																																case 65:
																																	goto IL_0e33;
																																case 69:
																																	goto IL_0e73;
																																case 203:
																																	goto IL_0e87;
																																case 177:
																																	goto IL_0e9a;
																																case 9:
																																	goto IL_0ea8;
																																case 75:
																																case 115:
																																	goto IL_0eb3;
																																case 1:
																																	goto IL_0edd;
																																case 92:
																																	goto IL_0eeb;
																																case 164:
																																	goto IL_0f07;
																																case 48:
																																	goto IL_0f15;
																																case 192:
																																case 194:
																																	goto IL_0f23;
																																case 254:
																																	goto IL_0f3d;
																																case 159:
																																	goto IL_0f4b;
																																case 47:
																																	goto IL_0f59;
																																case 28:
																																	goto IL_0f6c;
																																case 175:
																																	goto IL_0f7a;
																																case 59:
																																case 161:
																																	goto IL_0f88;
																																case 102:
																																	goto IL_0f9c;
																																case 176:
																																	goto IL_0fdb;
																																case 57:
																																	goto IL_0fee;
																																case 37:
																																	goto IL_0ffc;
																																case 95:
																																	goto IL_1013;
																																case 83:
																																case 217:
																																	goto IL_101e;
																																case 190:
																																	goto IL_1049;
																																case 258:
																																	goto IL_1062;
																																case 23:
																																	goto IL_1070;
																																case 85:
																																case 199:
																																	goto IL_107e;
																																case 135:
																																	goto IL_10a8;
																																case 107:
																																	goto IL_10b6;
																																case 110:
																																	goto IL_10c9;
																																case 201:
																																	goto IL_10d4;
																																case 39:
																																case 101:
																																	goto IL_10e2;
																																case 129:
																																	goto IL_10fe;
																																case 5:
																																	goto IL_110c;
																																case 84:
																																	goto IL_111f;
																																case 77:
																																case 112:
																																	goto IL_112a;
																																case 30:
																																	goto IL_115d;
																																case 166:
																																	goto IL_116b;
																																case 88:
																																	goto IL_117e;
																																case 167:
																																	goto IL_1195;
																																case 60:
																																case 152:
																																	goto IL_11a0;
																																case 98:
																																	goto IL_11ca;
																																case 266:
																																	goto IL_11d8;
																																case 52:
																																	goto IL_11eb;
																																case 72:
																																	goto IL_11f9;
																																case 86:
																																case 171:
																																	goto IL_1207;
																																case 127:
																																	goto IL_121b;
																																case 183:
																																	goto IL_125a;
																																case 132:
																																	goto IL_126d;
																																case 143:
																																	goto IL_1281;
																																case 142:
																																case 174:
																																	goto IL_128c;
																																case 228:
																																	goto IL_12a0;
																																case 7:
																																	goto IL_12df;
																																case 11:
																																case 15:
																																case 26:
																																case 31:
																																case 42:
																																case 50:
																																case 67:
																																case 82:
																																case 89:
																																case 96:
																																case 97:
																																case 104:
																																case 111:
																																case 130:
																																case 133:
																																case 144:
																																case 155:
																																case 162:
																																case 180:
																																case 181:
																																case 189:
																																case 191:
																																case 212:
																																case 221:
																																case 224:
																																case 229:
																																case 231:
																																case 233:
																																case 237:
																																case 239:
																																case 244:
																																case 248:
																																case 253:
																																case 259:
																																case 273:
																																case 275:
																																	goto end_IL_0533;
																																case 0:
																																case 6:
																																case 13:
																																case 16:
																																case 24:
																																case 25:
																																case 32:
																																case 40:
																																case 45:
																																case 54:
																																case 61:
																																case 68:
																																case 74:
																																case 81:
																																case 91:
																																case 94:
																																case 136:
																																case 137:
																																case 139:
																																case 140:
																																case 149:
																																case 151:
																																case 165:
																																case 168:
																																case 173:
																																case 185:
																																case 188:
																																case 196:
																																case 197:
																																case 204:
																																case 242:
																																case 251:
																																case 261:
																																case 262:
																																case 263:
																																case 270:
																																	goto end_IL_0563;
																																case 20:
																																	goto end_IL_1302;
																																case 200:
																																	goto end_IL_1315;
																																case 134:
																																	goto end_IL_131f;
																																case 2:
																																case 210:
																																	goto end_IL_132a;
																																case 206:
																																	goto end_IL_133a;
																																case 14:
																																	goto end_IL_134a;
																																case 205:
																																	goto end_IL_135a;
																																case 234:
																																	goto end_IL_136a;
																																case 235:
																																	goto end_IL_137a;
																																case 53:
																																case 269:
																																	return;
																																}
																																continue;
																															}
																															array2[num6] = null;
																															goto IL_05df;
																															IL_05df:
																															num6++;
																															goto IL_05ed;
																															IL_05ed:
																															ptr2 += 8;
																															goto end_IL_0563;
																															continue;
																															end_IL_0485:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0600;
																											IL_0737:
																											num6--;
																											goto end_IL_0563;
																											IL_0600:
																											if (2 >= b)
																											{
																												goto IL_060e;
																											}
																											goto IL_06e4;
																											IL_060e:
																											if (2 <= b)
																											{
																												goto IL_0619;
																											}
																											goto IL_0680;
																											IL_0619:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_0659;
																											IL_0659:
																											array[num6 - 2] = 0;
																											goto IL_066d;
																											IL_066d:
																											num6--;
																											goto end_IL_0563;
																											IL_0680:
																											if (1 < b)
																											{
																												goto end_IL_0533;
																											}
																											goto IL_068e;
																											IL_068e:
																											if (1 > b)
																											{
																												goto end_IL_0533;
																											}
																											goto IL_069c;
																											IL_069c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																											goto IL_06b5;
																											IL_06b5:
																											array[num6] = 0;
																											goto IL_06c3;
																											IL_06c3:
																											num6++;
																											goto IL_06d1;
																											IL_06d1:
																											ptr2 += 8;
																											goto end_IL_0563;
																											IL_06e4:
																											if (3 < b)
																											{
																												goto end_IL_0533;
																											}
																											goto IL_06f2;
																											IL_06f2:
																											if (3 > b)
																											{
																												goto end_IL_0533;
																											}
																											goto IL_0700;
																											IL_0700:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																											goto IL_0729;
																											IL_0729:
																											ptr2 += 8;
																											goto IL_0737;
																										}
																										break;
																									}
																									goto IL_074a;
																									IL_08b2:
																									array[num6 - 2] = 0;
																									goto IL_08c6;
																									IL_074a:
																									if (6 < b)
																									{
																										goto IL_0758;
																									}
																									num = 178;
																									goto IL_07e4;
																									IL_0758:
																									if (7 < b)
																									{
																										goto end_IL_0533;
																									}
																									goto IL_0766;
																									IL_0766:
																									if (7 > b)
																									{
																										goto end_IL_0533;
																									}
																									goto IL_0774;
																									IL_0774:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_07b4;
																									IL_07b4:
																									array[num6 - 2] = 0;
																									goto IL_07c8;
																									IL_07c8:
																									num6--;
																									goto end_IL_0563;
																									IL_08c6:
																									num6--;
																									goto end_IL_0563;
																									IL_07e4:
																									if (6 <= b)
																									{
																										goto IL_07ef;
																									}
																									goto IL_0856;
																									IL_07ef:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_082f;
																									IL_082f:
																									array[num6 - 2] = 0;
																									goto IL_0843;
																									IL_0843:
																									num6--;
																									goto end_IL_0563;
																									IL_0856:
																									if (5 < b)
																									{
																										goto end_IL_0533;
																									}
																									goto IL_0864;
																									IL_0864:
																									if (5 > b)
																									{
																										goto end_IL_0533;
																									}
																									goto IL_0872;
																									IL_0872:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_08b2;
																								}
																								break;
																							}
																							goto IL_056e;
																							IL_056e:
																							num6--;
																							goto end_IL_0563;
																						}
																						goto IL_0970;
																						IL_0bbe:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0c10;
																						IL_08d9:
																						if (12 >= b)
																						{
																							goto IL_08e7;
																						}
																						goto IL_0a8c;
																						IL_08e7:
																						if (12 <= b)
																						{
																							num = 196;
																							goto end_IL_0563;
																						}
																						goto IL_08f5;
																						IL_08f5:
																						if (10 >= b)
																						{
																							goto IL_0903;
																						}
																						goto IL_0a0f;
																						IL_0903:
																						if (10 <= b)
																						{
																							goto IL_090e;
																						}
																						goto IL_0983;
																						IL_090e:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0970;
																						IL_0970:
																						num6 -= 2;
																						goto end_IL_0563;
																						IL_0983:
																						if (9 < b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0991;
																						IL_0991:
																						if (9 > b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_099f;
																						IL_099f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						num = 58;
																						goto IL_09e8;
																						IL_09e8:
																						array[num6 - 2] = 0;
																						goto IL_09fc;
																						IL_09fc:
																						num6--;
																						goto end_IL_0563;
																						IL_0a0f:
																						if (11 < b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0a1d;
																						IL_0a1d:
																						if (11 > b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0a2b;
																						IL_0a2b:
																						array[num6] = 0;
																						goto IL_0a39;
																						IL_0a39:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])();
																						goto IL_0a5d;
																						IL_0a5d:
																						num6++;
																						goto IL_0a6b;
																						IL_0a6b:
																						ptr2 += 8;
																						goto end_IL_0563;
																						IL_0c10:
																						num6--;
																						goto end_IL_0563;
																						IL_0a8c:
																						if (14 >= b)
																						{
																							goto IL_0a9a;
																						}
																						goto IL_0b21;
																						IL_0a9a:
																						if (14 <= b)
																						{
																							goto IL_0aa5;
																						}
																						goto IL_0abd;
																						IL_0aa5:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0563;
																						IL_0abd:
																						if (13 < b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0acb;
																						IL_0acb:
																						if (13 > b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0ad9;
																						IL_0ad9:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0af2;
																						IL_0af2:
																						array[num6] = 1;
																						goto IL_0b00;
																						IL_0b00:
																						num6++;
																						goto IL_0b0e;
																						IL_0b0e:
																						ptr2 += 16;
																						goto end_IL_0563;
																						IL_0b21:
																						if (15 >= b)
																						{
																							goto IL_0b2c;
																						}
																						goto IL_0ba2;
																						IL_0b2c:
																						if (15 > b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0b3a;
																						IL_0b3a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_0b7b;
																						IL_0b7b:
																						array[num6 - 2] = 0;
																						goto IL_0b8f;
																						IL_0b8f:
																						num6--;
																						goto end_IL_0563;
																						IL_0ba2:
																						if (16 < b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0bb0;
																						IL_0bb0:
																						if (16 > b)
																						{
																							goto end_IL_0533;
																						}
																						goto IL_0bbe;
																						continue;
																						end_IL_0503:
																						break;
																					}
																					continue;
																				}
																				goto IL_0581;
																				IL_05b9:
																				ptr2 += 8;
																				num = 91;
																				goto end_IL_0563;
																				IL_0581:
																				((delegate*<int, void>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_05ab;
																				IL_05ab:
																				num6--;
																				goto IL_05b9;
																				continue;
																				end_IL_0513:
																				break;
																			}
																			continue;
																		}
																		goto IL_0c23;
																		IL_126d:
																		if (28 < b)
																		{
																			goto end_IL_0533;
																		}
																		num = 143;
																		goto IL_1281;
																		IL_12df:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_0c23:
																		if (25 >= b)
																		{
																			goto IL_0c31;
																		}
																		goto IL_0fee;
																		IL_0c31:
																		if (25 <= b)
																		{
																			goto IL_0c3c;
																		}
																		goto IL_0ca3;
																		IL_0c3c:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0c7c;
																		IL_0c7c:
																		array[num6 - 2] = 3;
																		goto IL_0c90;
																		IL_0c90:
																		num6--;
																		goto end_IL_0563;
																		IL_0ca3:
																		if (21 >= b)
																		{
																			goto IL_0cb1;
																		}
																		goto IL_0e9a;
																		IL_0cb1:
																		if (21 <= b)
																		{
																			goto IL_0cbc;
																		}
																		goto IL_0d2b;
																		IL_0cbc:
																		array[num6 - 1] = 0;
																		goto IL_0cd0;
																		IL_0cd0:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		num = 232;
																		goto IL_0d18;
																		IL_0d18:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_0d2b:
																		if (19 >= b)
																		{
																			goto IL_0d39;
																		}
																		goto IL_0e17;
																		IL_0d39:
																		if (19 > b)
																		{
																			goto IL_0d44;
																		}
																		goto IL_0db1;
																		IL_0d44:
																		if (18 < b)
																		{
																			goto end_IL_0533;
																		}
																		num = 186;
																		goto IL_0d5b;
																		IL_1281:
																		if (28 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_128c;
																		IL_0d5b:
																		if (18 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_0d69;
																		IL_0d69:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																		goto IL_0d82;
																		IL_0d82:
																		array[num6] = 3;
																		goto IL_0d90;
																		IL_0d90:
																		num6++;
																		goto IL_0d9e;
																		IL_0d9e:
																		ptr2 += 16;
																		goto end_IL_0563;
																		IL_0db1:
																		array[num6 - 1] = 3;
																		goto IL_0dc5;
																		IL_0dc5:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0e04;
																		IL_0e04:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_0e17:
																		if (20 < b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_0e25;
																		IL_0e25:
																		if (20 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_0e33;
																		IL_0e33:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0e73;
																		IL_0e73:
																		array[num6 - 2] = 3;
																		goto IL_0e87;
																		IL_0e87:
																		num6--;
																		goto end_IL_0563;
																		IL_0e9a:
																		if (23 >= b)
																		{
																			goto IL_0ea8;
																		}
																		goto IL_0f6c;
																		IL_0ea8:
																		if (23 <= b)
																		{
																			goto IL_0eb3;
																		}
																		goto IL_0f07;
																		IL_0eb3:
																		((delegate*<float, void>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])));
																		goto IL_0edd;
																		IL_0edd:
																		num6--;
																		goto IL_0eeb;
																		IL_0eeb:
																		ptr2 += 8;
																		num = 168;
																		goto end_IL_0563;
																		IL_0f07:
																		if (22 < b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_0f15;
																		IL_0f15:
																		if (22 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_0f23;
																		IL_0f23:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																		goto IL_0f3d;
																		IL_0f3d:
																		array[num6] = 3;
																		goto IL_0f4b;
																		IL_0f4b:
																		num6++;
																		goto IL_0f59;
																		IL_0f59:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_0f6c:
																		if (24 < b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_0f7a;
																		IL_0f7a:
																		if (24 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_0f88;
																		IL_0f88:
																		array[num6 - 1] = 3;
																		goto IL_0f9c;
																		IL_0f9c:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_0fdb;
																		IL_0fdb:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_0fee:
																		if (29 < b)
																		{
																			goto IL_0ffc;
																		}
																		goto IL_111f;
																		IL_0ffc:
																		if (31 >= b)
																		{
																			num = 95;
																			goto IL_1013;
																		}
																		goto IL_10c9;
																		IL_128c:
																		array[num6 - 1] = 3;
																		goto IL_12a0;
																		IL_1013:
																		if (31 <= b)
																		{
																			goto IL_101e;
																		}
																		goto IL_1062;
																		IL_101e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_1049;
																		IL_1049:
																		array[num6 - 1] = 0;
																		goto end_IL_0563;
																		IL_1062:
																		if (30 < b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_1070;
																		IL_1070:
																		if (30 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_107e;
																		IL_107e:
																		((delegate*<ShadowQuality, void>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(ShadowQuality*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_10a8;
																		IL_10a8:
																		num6--;
																		goto IL_10b6;
																		IL_10b6:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_10c9:
																		if (32 >= b)
																		{
																			goto IL_10d4;
																		}
																		goto IL_10fe;
																		IL_10d4:
																		if (32 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_10e2;
																		IL_10e2:
																		byte* num7 = ptr2;
																		num5 = 1;
																		ptr2 = num7 + -200;
																		goto end_IL_0563;
																		IL_10fe:
																		if (33 < b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_110c;
																		IL_110c:
																		if (33 > b)
																		{
																		}
																		goto end_IL_0533;
																		IL_111f:
																		if (29 <= b)
																		{
																			goto IL_112a;
																		}
																		goto IL_117e;
																		IL_112a:
																		((delegate*<int, void>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		num = 30;
																		goto IL_115d;
																		IL_115d:
																		num6--;
																		goto IL_116b;
																		IL_116b:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_117e:
																		if (27 >= b)
																		{
																			num = 167;
																			goto IL_1195;
																		}
																		goto IL_126d;
																		IL_12a0:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_12df;
																		IL_1195:
																		if (27 <= b)
																		{
																			goto IL_11a0;
																		}
																		goto IL_11eb;
																		IL_11a0:
																		((delegate*<int, void>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_11ca;
																		IL_11ca:
																		num6--;
																		goto IL_11d8;
																		IL_11d8:
																		ptr2 += 8;
																		goto end_IL_0563;
																		IL_11eb:
																		if (26 < b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_11f9;
																		IL_11f9:
																		if (26 > b)
																		{
																			goto end_IL_0533;
																		}
																		goto IL_1207;
																		IL_1207:
																		array[num6 - 1] = 3;
																		goto IL_121b;
																		IL_121b:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getIsNestedAssemblygetCurrencyNativeName[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																		goto IL_125a;
																		IL_125a:
																		ptr2 += 8;
																		goto end_IL_0563;
																		continue;
																		end_IL_0520:
																		break;
																	}
																	continue;
																	end_IL_0533:
																	break;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_0563;
															continue;
															end_IL_0543:
															break;
														}
														continue;
														end_IL_0553:
														break;
													}
													continue;
													end_IL_0563:
													break;
												}
												continue;
												end_IL_1302:
												break;
											}
											continue;
											end_IL_1315:
											break;
										}
										continue;
										end_IL_131f:
										break;
									}
									continue;
									end_IL_132a:
									break;
								}
								continue;
								end_IL_133a:
								break;
							}
							continue;
							end_IL_134a:
							break;
						}
						continue;
						end_IL_135a:
						break;
					}
					continue;
					end_IL_136a:
					break;
				}
				continue;
				end_IL_137a:
				break;
			}
		}
	}

	private void OnDisable()
	{
		CertMaximumConcurrencyLevel(this);
	}

	private unsafe void method_0()
	{
		int num = 51;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					num = 80;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UmAlQuraEraCLRIKeyValuePairImpl.AllFlagsUnadvise);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03d4:
																	if (b >= 1)
																	{
																		while (b <= 24)
																		{
																			while (true)
																			{
																				IL_03b7:
																				if (12 < b)
																				{
																					while (true)
																					{
																						IL_03a7:
																						if (18 < b)
																						{
																							while (true)
																							{
																								IL_0397:
																								if (21 >= b)
																								{
																									while (true)
																									{
																										IL_0384:
																										if (21 <= b)
																										{
																											num = 213;
																											while (true)
																											{
																												if (num != 213)
																												{
																													if (num != 1194)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 131:
																														goto IL_0384;
																													case 42:
																														goto IL_0397;
																													case 194:
																														goto IL_03a7;
																													case 11:
																														goto IL_03b7;
																													case 13:
																														goto end_IL_03b7;
																													case 192:
																														goto IL_03d4;
																													case 56:
																														goto end_IL_03d4;
																													case 0:
																													case 128:
																														goto end_IL_03e4;
																													case 86:
																														goto IL_0408;
																													case 74:
																														goto IL_0416;
																													case 36:
																														goto IL_0424;
																													case 39:
																														goto IL_042f;
																													case 93:
																														goto IL_0445;
																													case 108:
																														goto IL_0458;
																													case 43:
																														goto IL_0466;
																													case 31:
																														goto IL_0474;
																													case 110:
																														goto IL_0487;
																													case 105:
																														goto IL_0495;
																													case 122:
																														goto IL_04a8;
																													case 148:
																														goto IL_04c4;
																													case 30:
																													case 103:
																														goto IL_04d2;
																													case 111:
																														goto IL_0534;
																													case 152:
																														goto IL_0547;
																													case 90:
																													case 137:
																														goto IL_0555;
																													case 106:
																													case 155:
																														goto IL_0571;
																													case 33:
																														goto IL_058e;
																													case 142:
																														goto IL_05e2;
																													case 134:
																														goto IL_05f0;
																													case 159:
																														goto IL_0603;
																													case 124:
																														goto IL_0611;
																													case 174:
																														goto IL_0624;
																													case 34:
																														goto IL_0632;
																													case 180:
																														goto IL_0645;
																													case 60:
																														goto IL_0650;
																													case 179:
																														goto IL_065e;
																													case 8:
																													case 12:
																														goto IL_066c;
																													case 186:
																														goto IL_067f;
																													case 187:
																														goto IL_0692;
																													case 113:
																													case 143:
																														goto IL_06a0;
																													case 97:
																														goto IL_06b9;
																													case 38:
																														goto IL_06c7;
																													case 160:
																														goto IL_06d5;
																													case 35:
																													case 188:
																														goto IL_06e8;
																													case 25:
																														goto IL_0728;
																													case 22:
																														goto IL_073c;
																													case 9:
																													case 189:
																														goto IL_074f;
																													case 75:
																														goto IL_0763;
																													case 151:
																														goto IL_07a2;
																													case 193:
																														goto IL_07b5;
																													case 85:
																														goto IL_07c3;
																													case 154:
																														goto IL_07ce;
																													case 170:
																													case 176:
																														goto IL_07d9;
																													case 139:
																														goto IL_0802;
																													case 17:
																														goto IL_0819;
																													case 171:
																														goto IL_082c;
																													case 10:
																														goto IL_083a;
																													case 37:
																														goto IL_084d;
																													case 40:
																														goto IL_0858;
																													case 136:
																													case 191:
																														goto IL_0866;
																													case 94:
																														goto IL_0874;
																													case 55:
																														goto IL_0897;
																													case 104:
																														goto IL_08a1;
																													case 26:
																														goto IL_08af;
																													case 24:
																														goto IL_08c2;
																													case 101:
																														goto IL_08d9;
																													case 59:
																													case 184:
																														goto IL_08e7;
																													case 20:
																														goto IL_0927;
																													case 98:
																														goto IL_093b;
																													case 23:
																													case 153:
																														goto IL_094e;
																													case 64:
																														goto IL_098e;
																													case 162:
																														goto IL_09a2;
																													case 95:
																													case 195:
																														goto IL_09b5;
																													case 157:
																														goto IL_09fe;
																													case 1:
																														goto end_IL_0371;
																													case 199:
																														goto IL_0a25;
																													case 166:
																														goto IL_0a33;
																													case 89:
																													case 117:
																														goto IL_0a41;
																													case 84:
																														goto IL_0a8a;
																													case 45:
																														goto IL_0a9e;
																													case 78:
																													case 200:
																														goto IL_0ab1;
																													case 53:
																														goto IL_0ac5;
																													case 16:
																														goto IL_0b04;
																													case 7:
																													case 206:
																														goto IL_0b17;
																													case 146:
																														goto IL_0b30;
																													case 83:
																														goto IL_0b3e;
																													case 168:
																														goto IL_0b4c;
																													case 14:
																														goto IL_0b5f;
																													case 140:
																														goto IL_0b9f;
																													case 58:
																														goto IL_0bb3;
																													case 163:
																														goto IL_0bc6;
																													case 48:
																													case 144:
																														goto IL_0bd1;
																													case 121:
																														goto IL_0bfa;
																													case 88:
																														goto IL_0c08;
																													case 118:
																														goto IL_0c1b;
																													case 138:
																														goto IL_0c29;
																													case 129:
																													case 132:
																														goto IL_0c34;
																													case 182:
																														goto IL_0c75;
																													case 47:
																														goto IL_0c89;
																													case 4:
																														goto IL_0c9c;
																													case 147:
																														goto IL_0cb0;
																													case 62:
																													case 156:
																														goto IL_0cbe;
																													case 141:
																														goto IL_0cd7;
																													case 99:
																														goto IL_0cee;
																													case 172:
																														goto IL_0cfc;
																													case 100:
																														goto IL_0d18;
																													case 175:
																														goto IL_0d26;
																													case 3:
																													case 102:
																														goto IL_0d3d;
																													case 70:
																														goto IL_0d55;
																													case 161:
																														goto IL_0d60;
																													case 77:
																													case 123:
																														goto IL_0d6e;
																													case 130:
																														goto IL_0dc0;
																													case 63:
																														goto IL_0dd0;
																													case 145:
																														goto IL_0ddb;
																													case 32:
																													case 67:
																														goto IL_0de6;
																													case 149:
																														goto IL_0dfe;
																													case 204:
																														goto IL_0e0c;
																													case 21:
																														goto IL_0e1a;
																													case 2:
																													case 5:
																													case 6:
																													case 18:
																													case 44:
																													case 49:
																													case 57:
																													case 65:
																													case 72:
																													case 73:
																													case 82:
																													case 109:
																													case 116:
																													case 119:
																													case 125:
																													case 126:
																													case 133:
																													case 158:
																													case 167:
																													case 173:
																													case 177:
																													case 183:
																													case 185:
																													case 197:
																													case 201:
																													case 203:
																													case 205:
																														goto end_IL_03c4;
																													case 15:
																													case 19:
																													case 28:
																													case 29:
																													case 41:
																													case 46:
																													case 52:
																													case 54:
																													case 61:
																													case 69:
																													case 76:
																													case 79:
																													case 81:
																													case 87:
																													case 91:
																													case 96:
																													case 112:
																													case 115:
																													case 120:
																													case 127:
																													case 150:
																													case 164:
																													case 169:
																													case 178:
																													case 181:
																													case 190:
																													case 198:
																														goto end_IL_03f4;
																													case 196:
																														goto end_IL_0e46;
																													case 68:
																														goto end_IL_0e59;
																													case 165:
																														goto end_IL_0e63;
																													case 71:
																														goto end_IL_0e6e;
																													case 202:
																														goto end_IL_0e7e;
																													case 66:
																													case 114:
																														goto end_IL_0e8e;
																													case 27:
																														goto end_IL_0e9e;
																													case 80:
																														goto end_IL_0eae;
																													case 135:
																														goto end_IL_0ebe;
																													case 50:
																														goto end_IL_0ece;
																													case 51:
																														goto end_IL_0ee7;
																													case 92:
																													case 107:
																														return;
																													}
																													continue;
																												}
																												goto IL_0b5f;
																												IL_0b9f:
																												array[num6 - 2] = 3;
																												goto IL_0bb3;
																												IL_0bb3:
																												num6--;
																												goto end_IL_03f4;
																												IL_0b5f:
																												*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_0b9f;
																												continue;
																												end_IL_0371:
																												break;
																											}
																											break;
																										}
																										goto IL_04a8;
																										IL_074f:
																										array[num6 - 1] = 3;
																										goto IL_0763;
																										IL_0763:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getActualValueCommonDesktopDirectory[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_07a2;
																										IL_04a8:
																										if (19 < b)
																										{
																											goto IL_0624;
																										}
																										num = 187;
																										goto IL_0692;
																										IL_07a2:
																										ptr2 += 8;
																										goto end_IL_03f4;
																										IL_0692:
																										if (19 > b)
																										{
																											goto end_IL_03c4;
																										}
																										goto IL_06a0;
																										IL_06a0:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																										goto IL_06b9;
																										IL_06b9:
																										array[num6] = 3;
																										goto IL_06c7;
																										IL_06c7:
																										num6++;
																										goto IL_06d5;
																										IL_06d5:
																										ptr2 += 16;
																										goto end_IL_03f4;
																										IL_0624:
																										if (20 < b)
																										{
																											goto end_IL_03c4;
																										}
																										goto IL_0632;
																										IL_0632:
																										if (20 > b)
																										{
																											goto end_IL_03c4;
																										}
																										goto IL_074f;
																									}
																									break;
																								}
																								goto IL_0458;
																								IL_0b04:
																								ptr2 += 8;
																								goto end_IL_03f4;
																								IL_0458:
																								if (23 < b)
																								{
																									goto IL_0466;
																								}
																								goto IL_0547;
																								IL_0466:
																								if (24 < b)
																								{
																									goto end_IL_03c4;
																								}
																								goto IL_0474;
																								IL_0474:
																								if (24 > b)
																								{
																								}
																								goto end_IL_03c4;
																								IL_0547:
																								if (23 <= b)
																								{
																									goto IL_0555;
																								}
																								goto IL_0603;
																								IL_0555:
																								byte* num7 = ptr2;
																								num5 = 1;
																								ptr2 = num7 + -200;
																								goto end_IL_03f4;
																								IL_0603:
																								if (22 < b)
																								{
																									goto end_IL_03c4;
																								}
																								goto IL_0611;
																								IL_0611:
																								if (22 > b)
																								{
																									goto end_IL_03c4;
																								}
																								goto IL_0ab1;
																								IL_0ab1:
																								array[num6 - 1] = 0;
																								goto IL_0ac5;
																								IL_0ac5:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)getActualValueCommonDesktopDirectory[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_0b04;
																							}
																							break;
																						}
																						goto IL_0bc6;
																						IL_0dfe:
																						array[num6] = 5;
																						goto IL_0e0c;
																						IL_0bc6:
																						if (18 <= b)
																						{
																							goto IL_0bd1;
																						}
																						goto IL_0c1b;
																						IL_0bd1:
																						((delegate*<Class125, void>)getActualValueCommonDesktopDirectory[*(int*)(ptr2 + num3)])((Class125)array2[num6 - 1]);
																						goto IL_0bfa;
																						IL_0bfa:
																						num6--;
																						goto IL_0c08;
																						IL_0c08:
																						ptr2 += 8;
																						goto end_IL_03f4;
																						IL_0c1b:
																						if (15 >= b)
																						{
																							goto IL_0c29;
																						}
																						goto IL_0d55;
																						IL_0c29:
																						if (15 <= b)
																						{
																							goto IL_0c34;
																						}
																						goto IL_0c9c;
																						IL_0c34:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																						goto IL_0c75;
																						IL_0c75:
																						array[num6 - 2] = 0;
																						goto IL_0c89;
																						IL_0c89:
																						num6--;
																						goto end_IL_03f4;
																						IL_0c9c:
																						if (13 >= b)
																						{
																							num = 147;
																							goto IL_0cb0;
																						}
																						goto IL_0d18;
																						IL_0e0c:
																						num6++;
																						goto IL_0e1a;
																						IL_0cb0:
																						if (13 > b)
																						{
																							goto end_IL_03c4;
																						}
																						goto IL_0cbe;
																						IL_0cbe:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																						goto IL_0cd7;
																						IL_0cd7:
																						array[num6] = 1;
																						num = 99;
																						goto IL_0cee;
																						IL_0cee:
																						num6++;
																						goto IL_0cfc;
																						IL_0cfc:
																						ptr2 += 16;
																						num = 127;
																						goto end_IL_03f4;
																						IL_0d18:
																						if (14 < b)
																						{
																							goto end_IL_03c4;
																						}
																						goto IL_0d26;
																						IL_0d26:
																						if (14 > b)
																						{
																							goto end_IL_03c4;
																						}
																						num = 3;
																						goto IL_0d3d;
																						IL_0e1a:
																						ptr2 += 8;
																						goto end_IL_03f4;
																						IL_0d3d:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_03f4;
																						IL_0d55:
																						if (16 >= b)
																						{
																							goto IL_0d60;
																						}
																						goto IL_0dd0;
																						IL_0d60:
																						if (16 > b)
																						{
																							goto end_IL_03c4;
																						}
																						goto IL_0d6e;
																						IL_0d6e:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0dc0;
																						IL_0dc0:
																						num6--;
																						goto end_IL_03f4;
																						IL_0dd0:
																						if (17 < b)
																						{
																							goto end_IL_03c4;
																						}
																						goto IL_0ddb;
																						IL_0ddb:
																						if (17 > b)
																						{
																							goto end_IL_03c4;
																						}
																						goto IL_0de6;
																						IL_0de6:
																						array2[num6] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0dfe;
																					}
																					goto IL_0a12;
																				}
																				num = 86;
																				goto IL_0408;
																				IL_093b:
																				num6--;
																				goto end_IL_03f4;
																				IL_094e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_098e;
																				IL_0408:
																				if (12 <= b)
																				{
																					goto end_IL_03f4;
																				}
																				goto IL_0416;
																				IL_0416:
																				if (6 < b)
																				{
																					goto IL_0424;
																				}
																				goto IL_07b5;
																				IL_0424:
																				if (9 < b)
																				{
																					goto IL_042f;
																				}
																				goto IL_0445;
																				IL_042f:
																				if (10 < b)
																				{
																					goto IL_0487;
																				}
																				num = 148;
																				goto IL_04c4;
																				IL_098e:
																				array[num6 - 2] = 0;
																				goto IL_09a2;
																				IL_04c4:
																				if (10 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_04d2;
																				IL_04d2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0534;
																				IL_0534:
																				num6 -= 2;
																				goto end_IL_03f4;
																				IL_0487:
																				if (11 < b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_0495;
																				IL_0495:
																				if (11 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_0571;
																				IL_0571:
																				array[num6 - 2] = 0;
																				num = 33;
																				goto IL_058e;
																				IL_058e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)getActualValueCommonDesktopDirectory[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_05e2;
																				IL_05e2:
																				num6--;
																				goto IL_05f0;
																				IL_05f0:
																				ptr2 += 8;
																				goto end_IL_03f4;
																				IL_0445:
																				if (9 > b)
																				{
																					goto IL_0645;
																				}
																				goto IL_06e8;
																				IL_06e8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0728;
																				IL_0728:
																				array[num6 - 2] = 0;
																				goto IL_073c;
																				IL_073c:
																				num6--;
																				goto end_IL_03f4;
																				IL_0645:
																				if (7 < b)
																				{
																					goto IL_0650;
																				}
																				goto IL_067f;
																				IL_0650:
																				if (8 < b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_065e;
																				IL_065e:
																				if (8 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_066c;
																				IL_066c:
																				num6--;
																				goto end_IL_03f4;
																				IL_067f:
																				if (7 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_09b5;
																				IL_09b5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 157;
																				goto IL_09fe;
																				IL_09fe:
																				array[num6 - 2] = 0;
																				goto IL_0a12;
																				IL_0a12:
																				num6--;
																				goto end_IL_03f4;
																				IL_07b5:
																				if (6 > b)
																				{
																					goto IL_07c3;
																				}
																				goto IL_094e;
																				IL_07c3:
																				if (3 >= b)
																				{
																					goto IL_07ce;
																				}
																				goto IL_084d;
																				IL_07ce:
																				if (3 <= b)
																				{
																					goto IL_07d9;
																				}
																				goto IL_082c;
																				IL_07d9:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0802;
																				IL_0802:
																				ptr2 += 8;
																				num = 17;
																				goto IL_0819;
																				IL_0819:
																				num6--;
																				goto end_IL_03f4;
																				IL_082c:
																				if (1 >= b)
																				{
																					goto IL_083a;
																				}
																				goto IL_0a25;
																				IL_083a:
																				if (1 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_0b17;
																				IL_0b17:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0b30;
																				IL_0b30:
																				array[num6] = 0;
																				goto IL_0b3e;
																				IL_0b3e:
																				num6++;
																				goto IL_0b4c;
																				IL_0b4c:
																				ptr2 += 8;
																				goto end_IL_03f4;
																				IL_0a25:
																				if (2 < b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_0a33;
																				IL_0a33:
																				if (2 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_0a41;
																				IL_0a41:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 84;
																				goto IL_0a8a;
																				IL_0a8a:
																				array[num6 - 2] = 0;
																				goto IL_0a9e;
																				IL_0a9e:
																				num6--;
																				goto end_IL_03f4;
																				IL_084d:
																				if (4 >= b)
																				{
																					goto IL_0858;
																				}
																				goto IL_08c2;
																				IL_0858:
																				if (4 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_0866;
																				IL_0866:
																				array[num6] = 0;
																				goto IL_0874;
																				IL_0874:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0897;
																				IL_0897:
																				array2[num6] = null;
																				goto IL_08a1;
																				IL_08a1:
																				num6++;
																				goto IL_08af;
																				IL_08af:
																				ptr2 += 8;
																				goto end_IL_03f4;
																				IL_08c2:
																				if (5 < b)
																				{
																					goto end_IL_03c4;
																				}
																				num = 101;
																				goto IL_08d9;
																				IL_09a2:
																				num6--;
																				goto end_IL_03f4;
																				IL_08d9:
																				if (5 > b)
																				{
																					goto end_IL_03c4;
																				}
																				goto IL_08e7;
																				IL_08e7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0927;
																				IL_0927:
																				array[num6 - 2] = 0;
																				goto IL_093b;
																				continue;
																				end_IL_03b7:
																				break;
																			}
																			continue;
																			end_IL_03c4:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 87;
																	goto end_IL_03f4;
																	continue;
																	end_IL_03d4:
																	break;
																}
																continue;
																end_IL_03e4:
																break;
															}
															continue;
															end_IL_03f4:
															break;
														}
														continue;
														end_IL_0e46:
														break;
													}
													continue;
													end_IL_0e59:
													break;
												}
												continue;
												end_IL_0e63:
												break;
											}
											continue;
											end_IL_0e6e:
											break;
										}
										continue;
										end_IL_0e7e:
										break;
									}
									continue;
									end_IL_0e8e:
									break;
								}
								continue;
								end_IL_0e9e:
								break;
							}
							continue;
							end_IL_0eae:
							break;
						}
						continue;
						end_IL_0ebe:
						break;
					}
					continue;
					end_IL_0ece:
					break;
				}
				continue;
				end_IL_0ee7:
				break;
			}
		}
	}

	private void method_1()
	{
		int num = 231;
		num = 33;
		num = 24;
		num = 12;
		num = 33;
		num = 45;
		num = 45;
		num = 45;
		num = 793;
		num = 61;
		num = 96;
		num = 32;
		num = 61;
		num = 93;
		num = 2045;
		num = 2045;
		num = 2090;
		num = 966;
		num = 138;
		object obj = this;
		if (((Class125)obj).bool_0)
		{
			obj = this;
			((Class125)obj).bool_0 = false;
			try
			{
				obj = this;
				double num2 = ((Class125)obj).float_0;
				QualitySettings.shadowDistance = (float)num2;
				obj = this;
				num = (int)((Class125)obj).shadowQuality_0;
				QualitySettings.shadows = (ShadowQuality)num;
				obj = this;
				num = ((Class125)obj).int_0;
				Application.targetFrameRate = num;
				obj = this;
				num = ((Class125)obj).int_1;
				QualitySettings.vSyncCount = num;
				obj = this;
				num = ((Class125)obj).int_2;
				QualitySettings.globalTextureMipmapLimit = num;
			}
			catch
			{
			}
		}
	}

	public Class125()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_0(int int_6, int int_7)
	{
		int num = int_6;
		int num2 = int_7;
		if (num <= num2)
		{
			num = int_7;
			num2 = int_6;
			return num - num2;
		}
		num = int_6;
		num2 = int_7;
		return num - num2;
	}

	private unsafe static int smethod_1(int int_6, int int_7)
	{
		int num = 92;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						IL_07a3:
						object[] array2 = new object[3];
						while (true)
						{
							IL_0798:
							num = 68;
							while (true)
							{
								IL_0788:
								int[] array3 = new int[5];
								while (true)
								{
									IL_0778:
									long[] array4 = new long[3];
									while (true)
									{
										IL_075a:
										array3[0] = int_6;
										num = 16;
										while (true)
										{
											IL_0745:
											array3[1] = int_7;
											while (true)
											{
												IL_073a:
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IncrementStructFieldCountOpenStandardOutput.ResourceManagerAuthoritySeed);
												while (true)
												{
													IL_0730:
													byte* ptr2 = ptr;
													while (true)
													{
														IL_0725:
														num = 42;
														while (true)
														{
															IL_0712:
															if (num4 != 1)
															{
																while (true)
																{
																	IL_0217:
																	byte b = *ptr2;
																	num = 126;
																	while (true)
																	{
																		if (num != 126)
																		{
																			if (num != 1107)
																			{
																				break;
																			}
																			switch (num)
																			{
																			case 70:
																			case 102:
																				goto IL_0217;
																			case 32:
																				goto IL_0239;
																			case 61:
																				goto IL_0247;
																			case 43:
																				goto IL_0255;
																			case 33:
																			case 108:
																				goto IL_0263;
																			case 27:
																				goto IL_0271;
																			case 47:
																				goto IL_027f;
																			case 12:
																			case 93:
																				goto IL_028d;
																			case 21:
																				goto IL_029b;
																			case 22:
																			case 29:
																				goto IL_02a9;
																			case 10:
																				goto IL_02e9;
																			case 76:
																				goto IL_02fd;
																			case 38:
																				goto IL_0310;
																			case 34:
																			case 54:
																				goto IL_031e;
																			case 119:
																				goto IL_0337;
																			case 52:
																				goto IL_0345;
																			case 106:
																				goto IL_0353;
																			case 44:
																			case 103:
																				goto IL_0366;
																			case 101:
																				goto IL_037a;
																			case 83:
																				goto IL_03b9;
																			case 17:
																				goto IL_03cc;
																			case 67:
																				goto IL_03d7;
																			case 1:
																			case 7:
																				goto IL_03e5;
																			case 37:
																				goto IL_03f8;
																			case 94:
																				goto IL_0406;
																			case 5:
																			case 50:
																				goto IL_0414;
																			case 97:
																				goto IL_0430;
																			case 46:
																			case 88:
																				goto IL_043e;
																			case 19:
																			case 36:
																				goto IL_044c;
																			case 86:
																				goto IL_0457;
																			case 64:
																			case 89:
																				goto IL_0465;
																			case 30:
																				goto IL_04a5;
																			case 96:
																				goto IL_04b9;
																			case 24:
																				goto IL_04cc;
																			case 53:
																				goto IL_04da;
																			case 48:
																			case 66:
																				goto IL_04e8;
																			case 87:
																				goto IL_04f6;
																			case 26:
																				goto IL_0522;
																			case 74:
																				goto IL_052c;
																			case 18:
																				goto IL_053a;
																			case 3:
																				goto IL_0556;
																			case 63:
																			case 114:
																				goto IL_0564;
																			case 31:
																				goto IL_056f;
																			case 112:
																				goto IL_0582;
																			case 39:
																				goto IL_0590;
																			case 62:
																			case 77:
																				goto IL_059e;
																			case 40:
																				goto IL_05de;
																			case 20:
																				goto IL_05f2;
																			case 56:
																			case 73:
																				goto IL_060e;
																			case 85:
																				goto IL_0637;
																			case 90:
																				goto IL_0645;
																			case 14:
																			case 118:
																				goto IL_0658;
																			case 104:
																				goto IL_06a1;
																			case 55:
																				goto IL_06b5;
																			case 0:
																			case 6:
																			case 11:
																			case 13:
																			case 15:
																			case 23:
																			case 25:
																			case 51:
																			case 58:
																			case 59:
																			case 65:
																			case 69:
																			case 71:
																			case 72:
																			case 78:
																			case 81:
																			case 105:
																			case 110:
																			case 115:
																			case 117:
																				goto IL_06c5;
																			case 75:
																				goto IL_06e8;
																			case 111:
																				goto IL_06f6;
																			case 107:
																				goto IL_0704;
																			case 8:
																			case 9:
																			case 42:
																			case 45:
																			case 49:
																			case 57:
																			case 60:
																			case 79:
																			case 80:
																			case 84:
																			case 98:
																			case 100:
																				goto IL_0712;
																			case 109:
																				goto IL_0725;
																			case 116:
																				goto IL_0730;
																			case 41:
																				goto IL_073a;
																			case 16:
																				goto IL_0745;
																			case 82:
																				goto IL_075a;
																			case 28:
																				goto IL_0778;
																			case 68:
																				goto IL_0788;
																			case 99:
																				goto IL_0798;
																			case 113:
																				goto IL_07a3;
																			case 2:
																			case 95:
																				goto end_IL_0207;
																			case 91:
																				goto end_IL_07b3;
																			case 92:
																				goto end_IL_07c3;
																			case 4:
																			case 35:
																				goto IL_07de;
																			}
																			continue;
																		}
																		ptr2++;
																		goto IL_0239;
																		IL_06e8:
																		array[num5] = 0;
																		goto IL_06f6;
																		IL_0704:
																		ptr2 += 8;
																		goto IL_0712;
																		IL_06f6:
																		num5++;
																		goto IL_0704;
																		IL_0239:
																		if (b >= 1)
																		{
																			goto IL_0247;
																		}
																		goto IL_06c5;
																		IL_0247:
																		if (b <= 11)
																		{
																			goto IL_0255;
																		}
																		goto IL_06c5;
																		IL_0255:
																		if (6 < b)
																		{
																			goto IL_0263;
																		}
																		goto IL_0430;
																		IL_0263:
																		if (9 >= b)
																		{
																			goto IL_0271;
																		}
																		goto IL_03cc;
																		IL_0271:
																		if (9 > b)
																		{
																			goto IL_027f;
																		}
																		goto IL_0366;
																		IL_027f:
																		if (7 < b)
																		{
																			goto IL_028d;
																		}
																		goto IL_0310;
																		IL_028d:
																		if (8 >= b)
																		{
																			goto IL_029b;
																		}
																		goto IL_06c5;
																		IL_029b:
																		if (8 <= b)
																		{
																			goto IL_02a9;
																		}
																		goto IL_06c5;
																		IL_02a9:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_02e9;
																		IL_02e9:
																		array[num5 - 2] = 0;
																		goto IL_02fd;
																		IL_02fd:
																		num5--;
																		goto IL_0712;
																		IL_0310:
																		if (7 <= b)
																		{
																			goto IL_031e;
																		}
																		goto IL_06c5;
																		IL_031e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																		goto IL_0337;
																		IL_0337:
																		array[num5] = 0;
																		goto IL_0345;
																		IL_0345:
																		num5++;
																		goto IL_0353;
																		IL_0353:
																		ptr2 += 8;
																		goto IL_0712;
																		IL_0366:
																		array[num5 - 1] = 0;
																		goto IL_037a;
																		IL_037a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SetSignaturegetIsValueFaulted[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																		goto IL_03b9;
																		IL_03b9:
																		ptr2 += 8;
																		goto IL_0712;
																		IL_03cc:
																		if (10 >= b)
																		{
																			goto IL_03d7;
																		}
																		goto IL_03f8;
																		IL_03d7:
																		if (10 <= b)
																		{
																			goto IL_03e5;
																		}
																		goto IL_06c5;
																		IL_03e5:
																		num5--;
																		goto IL_0712;
																		IL_03f8:
																		if (11 >= b)
																		{
																			goto IL_0406;
																		}
																		goto IL_06c5;
																		IL_0406:
																		if (11 <= b)
																		{
																			goto IL_0414;
																		}
																		goto IL_06c5;
																		IL_0414:
																		byte* num6 = ptr2;
																		num4 = 1;
																		ptr2 = num6 + -200;
																		goto IL_0712;
																		IL_0430:
																		if (6 > b)
																		{
																			goto IL_043e;
																		}
																		goto IL_0658;
																		IL_043e:
																		if (3 < b)
																		{
																			goto IL_044c;
																		}
																		goto IL_0556;
																		IL_044c:
																		if (4 >= b)
																		{
																			goto IL_0457;
																		}
																		goto IL_04cc;
																		IL_0457:
																		if (4 <= b)
																		{
																			goto IL_0465;
																		}
																		goto IL_06c5;
																		IL_0465:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_04a5;
																		IL_04a5:
																		array[num5 - 2] = 0;
																		goto IL_04b9;
																		IL_04b9:
																		num5--;
																		goto IL_0712;
																		IL_04cc:
																		if (5 >= b)
																		{
																			goto IL_04da;
																		}
																		goto IL_06c5;
																		IL_04da:
																		if (5 <= b)
																		{
																			goto IL_04e8;
																		}
																		goto IL_06c5;
																		IL_04e8:
																		array[num5] = 0;
																		goto IL_04f6;
																		IL_04f6:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 26;
																		goto IL_0522;
																		IL_0522:
																		array2[num5] = null;
																		goto IL_052c;
																		IL_052c:
																		num5++;
																		goto IL_053a;
																		IL_053a:
																		ptr2 += 8;
																		num = 84;
																		goto IL_0712;
																		IL_0556:
																		if (3 > b)
																		{
																			goto IL_0564;
																		}
																		goto IL_060e;
																		IL_0564:
																		if (1 >= b)
																		{
																			goto IL_056f;
																		}
																		goto IL_0582;
																		IL_056f:
																		if (1 > b)
																		{
																		}
																		goto IL_06c5;
																		IL_0582:
																		if (2 >= b)
																		{
																			goto IL_0590;
																		}
																		goto IL_06c5;
																		IL_0590:
																		if (2 <= b)
																		{
																			goto IL_059e;
																		}
																		goto IL_06c5;
																		IL_059e:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_05de;
																		IL_05de:
																		array[num5 - 2] = 0;
																		goto IL_05f2;
																		IL_05f2:
																		num5--;
																		num = 45;
																		goto IL_0712;
																		IL_060e:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0637;
																		IL_0637:
																		ptr2 += 8;
																		goto IL_0645;
																		IL_0645:
																		num5--;
																		goto IL_0712;
																		IL_0658:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		num = 104;
																		goto IL_06a1;
																		IL_06a1:
																		array[num5 - 2] = 0;
																		goto IL_06b5;
																		IL_06b5:
																		num5--;
																		goto IL_0712;
																		IL_06c5:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_06e8;
																		continue;
																		end_IL_0207:
																		break;
																	}
																	break;
																}
																break;
															}
															goto IL_07de;
															IL_07de:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_07b3:
					break;
				}
				continue;
				end_IL_07c3:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 105;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetFileLineNumberSuiteName.AcosUnobservedTaskExceptionEventArgs);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0385:
														byte b = *ptr2;
														while (true)
														{
															IL_0375:
															ptr2++;
															while (true)
															{
																IL_0365:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0348:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0338:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0328:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_031b:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_030b:
																											if (2 >= b)
																											{
																												while (true)
																												{
																													IL_02fb:
																													if (2 <= b)
																													{
																														while (true)
																														{
																															IL_02b9:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															while (true)
																															{
																																IL_02a3:
																																array[num5 - 2] = 0;
																																while (true)
																																{
																																	IL_028a:
																																	num5--;
																																	num = 154;
																																	while (num != 154)
																																	{
																																		if (num != 1135)
																																		{
																																			goto IL_0512;
																																		}
																																		switch (num)
																																		{
																																		case 27:
																																			goto IL_028a;
																																		case 11:
																																			goto IL_02a3;
																																		case 62:
																																		case 120:
																																			goto IL_02b9;
																																		case 33:
																																			goto IL_02fb;
																																		case 66:
																																			goto IL_030b;
																																		case 73:
																																			goto IL_031b;
																																		case 55:
																																		case 93:
																																			goto IL_0328;
																																		case 94:
																																			goto IL_0338;
																																		case 99:
																																			goto IL_0348;
																																		case 70:
																																			goto IL_0355;
																																		case 89:
																																			goto IL_0365;
																																		case 139:
																																			goto IL_0375;
																																		case 38:
																																		case 100:
																																			goto IL_0385;
																																		case 21:
																																		case 97:
																																			goto IL_0390;
																																		case 113:
																																			goto IL_03ae;
																																		case 57:
																																			goto IL_03bc;
																																		case 103:
																																		case 123:
																																			goto IL_03cf;
																																		case 17:
																																		case 32:
																																			goto IL_03da;
																																		case 118:
																																			goto IL_03e5;
																																		case 74:
																																			goto IL_03f8;
																																		case 16:
																																			goto IL_0406;
																																		case 112:
																																			goto IL_0419;
																																		case 106:
																																		case 116:
																																			goto IL_0424;
																																		case 2:
																																			goto IL_046d;
																																		case 30:
																																			goto IL_0481;
																																		case 37:
																																			goto IL_049d;
																																		case 58:
																																			goto IL_04a8;
																																		case 68:
																																		case 90:
																																			goto IL_04b6;
																																		case 8:
																																			goto IL_04c4;
																																		case 87:
																																			goto IL_04e7;
																																		case 0:
																																		case 95:
																																			goto IL_04f6;
																																		case 10:
																																			goto IL_0504;
																																		case 7:
																																		case 43:
																																			goto IL_0512;
																																		case 34:
																																			goto IL_0556;
																																		case 26:
																																			goto IL_0573;
																																		case 53:
																																		case 127:
																																			goto IL_0586;
																																		case 129:
																																			goto IL_05a2;
																																		case 56:
																																			goto IL_05b0;
																																		case 4:
																																		case 138:
																																			goto IL_05c3;
																																		case 132:
																																			goto IL_05da;
																																		case 142:
																																			goto IL_05ed;
																																		case 144:
																																			goto IL_05fb;
																																		case 49:
																																		case 59:
																																			goto IL_0609;
																																		case 42:
																																			goto IL_066b;
																																		case 107:
																																			goto IL_067e;
																																		case 69:
																																			goto IL_068c;
																																		case 29:
																																		case 102:
																																			goto IL_069a;
																																		case 78:
																																			goto IL_06b3;
																																		case 145:
																																			goto IL_06c1;
																																		case 3:
																																			goto IL_06cf;
																																		case 147:
																																			goto IL_06eb;
																																		case 124:
																																			goto IL_06f9;
																																		case 117:
																																		case 134:
																																			goto IL_0707;
																																		case 36:
																																			goto IL_0730;
																																		case 46:
																																			goto IL_0749;
																																		case 64:
																																			goto IL_0757;
																																		case 54:
																																		case 135:
																																			goto IL_0762;
																																		case 9:
																																			goto IL_07a1;
																																		case 121:
																																			goto IL_07b4;
																																		case 86:
																																			goto IL_07c2;
																																		case 48:
																																		case 119:
																																			goto IL_07d0;
																																		case 91:
																																			goto IL_07de;
																																		case 22:
																																			goto IL_07f6;
																																		case 67:
																																			goto IL_0804;
																																		case 45:
																																			goto IL_0817;
																																		case 133:
																																			goto IL_0822;
																																		case 13:
																																		case 71:
																																			goto IL_082d;
																																		case 79:
																																			goto IL_0856;
																																		case 109:
																																			goto IL_0864;
																																		case 72:
																																		case 75:
																																			goto IL_087f;
																																		case 1:
																																		case 12:
																																		case 15:
																																		case 18:
																																		case 24:
																																		case 25:
																																		case 44:
																																		case 47:
																																		case 51:
																																		case 61:
																																		case 80:
																																		case 81:
																																		case 82:
																																		case 83:
																																		case 84:
																																		case 85:
																																		case 98:
																																		case 108:
																																		case 111:
																																		case 114:
																																		case 115:
																																		case 125:
																																		case 126:
																																		case 128:
																																		case 130:
																																		case 131:
																																		case 140:
																																		case 141:
																																		case 146:
																																			goto end_IL_0355;
																																		case 5:
																																		case 6:
																																		case 20:
																																		case 28:
																																		case 39:
																																		case 40:
																																		case 41:
																																		case 52:
																																		case 65:
																																		case 76:
																																		case 77:
																																		case 88:
																																		case 92:
																																		case 96:
																																		case 101:
																																		case 136:
																																		case 137:
																																			goto end_IL_0277;
																																		case 50:
																																			goto end_IL_08a7;
																																		case 110:
																																			goto end_IL_08ba;
																																		case 19:
																																			goto end_IL_08c4;
																																		case 14:
																																			goto end_IL_08cf;
																																		case 60:
																																		case 143:
																																			goto end_IL_08df;
																																		case 122:
																																			goto end_IL_08ef;
																																		case 23:
																																		case 31:
																																			goto end_IL_08ff;
																																		case 104:
																																			goto end_IL_090f;
																																		case 105:
																																			goto end_IL_091f;
																																		case 35:
																																		case 63:
																																			goto IL_0943;
																																		}
																																		continue;
																																		end_IL_0277:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto IL_067e;
																													IL_06cf:
																													ptr2 += 8;
																													num = 136;
																													break;
																													IL_067e:
																													if (1 < b)
																													{
																														goto end_IL_0355;
																													}
																													goto IL_068c;
																													IL_068c:
																													if (1 > b)
																													{
																														goto end_IL_0355;
																													}
																													goto IL_069a;
																													IL_069a:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_06b3;
																													IL_06b3:
																													array[num5] = 0;
																													goto IL_06c1;
																													IL_06c1:
																													num5++;
																													goto IL_06cf;
																												}
																												break;
																											}
																											goto IL_06eb;
																											IL_0730:
																											array[num5 - 1] = 5;
																											break;
																											IL_06eb:
																											if (3 < b)
																											{
																												goto end_IL_0355;
																											}
																											goto IL_06f9;
																											IL_06f9:
																											if (3 > b)
																											{
																												goto end_IL_0355;
																											}
																											goto IL_0707;
																											IL_0707:
																											array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_0730;
																										}
																										break;
																									}
																									goto IL_0390;
																									IL_03bc:
																									num5--;
																									break;
																									IL_0390:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_03ae;
																									IL_03ae:
																									ptr2 += 8;
																									goto IL_03bc;
																								}
																								break;
																							}
																							goto IL_0749;
																							IL_0864:
																							num5--;
																							break;
																							IL_0749:
																							if (6 >= b)
																							{
																								goto IL_0757;
																							}
																							goto IL_0817;
																							IL_0757:
																							if (6 <= b)
																							{
																								goto IL_0762;
																							}
																							goto IL_07b4;
																							IL_0762:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_07a1;
																							IL_07a1:
																							num5 -= 3;
																							break;
																							IL_07b4:
																							if (5 < b)
																							{
																								goto end_IL_0355;
																							}
																							goto IL_07c2;
																							IL_07c2:
																							if (5 > b)
																							{
																								goto end_IL_0355;
																							}
																							goto IL_07d0;
																							IL_07d0:
																							array[num5] = 5;
																							goto IL_07de;
																							IL_07de:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_07f6;
																							IL_07f6:
																							num5++;
																							goto IL_0804;
																							IL_0804:
																							ptr2 += 8;
																							break;
																							IL_0817:
																							if (7 < b)
																							{
																								goto end_IL_0355;
																							}
																							goto IL_0822;
																							IL_0822:
																							if (7 > b)
																							{
																								num = 18;
																								goto end_IL_0355;
																							}
																							goto IL_082d;
																							IL_082d:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0856;
																							IL_0856:
																							ptr2 += 8;
																							goto IL_0864;
																						}
																						break;
																					}
																					goto IL_087f;
																					IL_087f:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																				}
																				break;
																			}
																			goto IL_03cf;
																			IL_0556:
																			array[num5 - 2] = 0;
																			num = 26;
																			goto IL_0573;
																			IL_03cf:
																			if (12 < b)
																			{
																				goto IL_03da;
																			}
																			goto IL_0419;
																			IL_03da:
																			if (14 >= b)
																			{
																				goto IL_03e5;
																			}
																			goto IL_03f8;
																			IL_03e5:
																			if (14 <= b)
																			{
																				goto IL_0586;
																			}
																			goto IL_05ed;
																			IL_0586:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_05ed:
																			if (13 < b)
																			{
																				goto end_IL_0355;
																			}
																			goto IL_05fb;
																			IL_05fb:
																			if (13 > b)
																			{
																				goto end_IL_0355;
																			}
																			goto IL_0609;
																			IL_0609:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_066b;
																			IL_066b:
																			num5 -= 2;
																			break;
																			IL_03f8:
																			if (15 < b)
																			{
																				goto end_IL_0355;
																			}
																			goto IL_0406;
																			IL_0406:
																			if (15 > b)
																			{
																			}
																			goto end_IL_0355;
																			IL_0419:
																			if (12 <= b)
																			{
																				goto IL_0424;
																			}
																			goto IL_049d;
																			IL_0424:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 2;
																			goto IL_046d;
																			IL_046d:
																			array[num5 - 2] = 0;
																			goto IL_0481;
																			IL_0481:
																			num5--;
																			num = 77;
																			break;
																			IL_049d:
																			if (10 >= b)
																			{
																				goto IL_04a8;
																			}
																			goto IL_04f6;
																			IL_04a8:
																			if (10 <= b)
																			{
																				goto IL_04b6;
																			}
																			goto IL_05c3;
																			IL_04b6:
																			array[num5] = 0;
																			goto IL_04c4;
																			IL_04c4:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04e7;
																			IL_04e7:
																			array2[num5] = null;
																			goto IL_05a2;
																			IL_05a2:
																			num5++;
																			goto IL_05b0;
																			IL_05b0:
																			ptr2 += 8;
																			break;
																			IL_05c3:
																			if (9 < b)
																			{
																				goto end_IL_0355;
																			}
																			num = 132;
																			goto IL_05da;
																			IL_0573:
																			num5--;
																			break;
																			IL_05da:
																			if (9 > b)
																			{
																				goto end_IL_0355;
																			}
																			break;
																			IL_04f6:
																			if (11 < b)
																			{
																				goto end_IL_0355;
																			}
																			goto IL_0504;
																			IL_0504:
																			if (11 > b)
																			{
																				goto end_IL_0355;
																			}
																			goto IL_0512;
																			IL_0512:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0556;
																		}
																		goto end_IL_0365;
																		continue;
																		end_IL_0355:
																		break;
																		IL_0355:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0365:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 63;
												goto IL_0943;
												IL_0943:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a7:
												break;
											}
											continue;
											end_IL_08ba:
											break;
										}
										continue;
										end_IL_08c4:
										break;
									}
									continue;
									end_IL_08cf:
									break;
								}
								continue;
								end_IL_08df:
								break;
							}
							continue;
							end_IL_08ef:
							break;
						}
						continue;
						end_IL_08ff:
						break;
					}
					continue;
					end_IL_090f:
					break;
				}
				continue;
				end_IL_091f:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_6, int int_7)
	{
		int num = 54;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 68;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_6;
									while (true)
									{
										array3[1] = int_7;
										num = 119;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDeclaredMethodsURL.ReflectionTypeInfoBaseName);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															num = 49;
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_02db:
																		if (b >= 1)
																		{
																			num = 92;
																			while (b <= 11)
																			{
																				while (true)
																				{
																					if (6 < b)
																					{
																						while (true)
																						{
																							if (9 >= b)
																							{
																								while (true)
																								{
																									if (9 <= b)
																									{
																										while (true)
																										{
																											array[num5 - 2] = 0;
																											while (true)
																											{
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)setPerMilleSymbolCreateDeformatter[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																												num = 127;
																												while (true)
																												{
																													if (num != 127)
																													{
																														if (num == 1108)
																														{
																															switch (num)
																															{
																															case 56:
																																goto end_IL_0219;
																															case 13:
																															case 24:
																																goto end_IL_022c;
																															case 101:
																																goto end_IL_028b;
																															case 48:
																																goto end_IL_02a1;
																															case 51:
																																goto end_IL_02b1;
																															case 92:
																																goto end_IL_02be;
																															case 28:
																																goto IL_02db;
																															case 21:
																																goto end_IL_02db;
																															case 49:
																																goto end_IL_02ee;
																															case 86:
																																goto end_IL_02fe;
																															case 18:
																															case 44:
																																goto IL_0314;
																															case 31:
																																goto IL_031f;
																															case 58:
																																goto IL_0332;
																															case 6:
																															case 46:
																																goto IL_033d;
																															case 72:
																																goto IL_037f;
																															case 74:
																																goto IL_0392;
																															case 11:
																																goto IL_03a6;
																															case 19:
																															case 94:
																																goto IL_03b9;
																															case 55:
																															case 84:
																																goto IL_03c7;
																															case 62:
																																goto IL_03d2;
																															case 45:
																																goto IL_03e5;
																															case 95:
																																goto IL_03f3;
																															case 0:
																															case 96:
																																goto IL_0406;
																															case 16:
																																goto IL_0414;
																															case 65:
																																goto IL_0422;
																															case 39:
																															case 66:
																																goto IL_0430;
																															case 37:
																																goto IL_0470;
																															case 15:
																																goto IL_0484;
																															case 12:
																																goto IL_0497;
																															case 77:
																															case 105:
																																goto IL_04aa;
																															case 100:
																															case 106:
																																goto IL_04bd;
																															case 98:
																																goto IL_04cb;
																															case 75:
																																goto IL_04ee;
																															case 9:
																																goto IL_04f8;
																															case 103:
																																goto IL_0506;
																															case 108:
																																goto IL_0519;
																															case 23:
																															case 67:
																																goto IL_0527;
																															case 41:
																																goto IL_0532;
																															case 2:
																																goto IL_0545;
																															case 63:
																																goto IL_0553;
																															case 14:
																															case 29:
																																goto IL_0561;
																															case 1:
																																goto IL_05a1;
																															case 71:
																																goto IL_05b5;
																															case 3:
																															case 90:
																																goto IL_05c8;
																															case 22:
																																goto IL_05f1;
																															case 35:
																																goto IL_05ff;
																															case 109:
																																goto IL_0612;
																															case 30:
																															case 107:
																																goto IL_0620;
																															case 70:
																															case 115:
																																goto IL_063c;
																															case 85:
																																goto IL_067c;
																															case 38:
																																goto IL_0699;
																															case 82:
																															case 120:
																																goto IL_06b5;
																															case 4:
																																goto IL_06ce;
																															case 43:
																																goto IL_06dc;
																															case 20:
																																goto IL_06ea;
																															case 47:
																																goto IL_0708;
																															case 7:
																															case 34:
																															case 36:
																															case 40:
																															case 50:
																															case 57:
																															case 59:
																															case 60:
																															case 69:
																															case 76:
																															case 78:
																															case 79:
																															case 87:
																															case 88:
																															case 89:
																															case 99:
																															case 104:
																															case 113:
																															case 114:
																															case 118:
																																goto end_IL_02cb;
																															case 111:
																																goto IL_0744;
																															case 8:
																																goto IL_0752;
																															case 25:
																																goto IL_0760;
																															case 5:
																															case 17:
																															case 42:
																															case 52:
																															case 64:
																															case 73:
																															case 80:
																															case 91:
																															case 93:
																															case 97:
																															case 110:
																															case 112:
																															case 116:
																																goto end_IL_0309;
																															case 27:
																																goto end_IL_076e;
																															case 119:
																																goto end_IL_0781;
																															case 81:
																																goto end_IL_078b;
																															case 83:
																																goto end_IL_0796;
																															case 102:
																																goto end_IL_07b4;
																															case 32:
																															case 61:
																																goto end_IL_07c9;
																															case 68:
																																goto end_IL_07d9;
																															case 33:
																															case 117:
																																goto end_IL_07e9;
																															case 53:
																																goto end_IL_07f9;
																															case 54:
																																goto end_IL_0812;
																															case 10:
																															case 26:
																																goto IL_082d;
																															}
																															continue;
																														}
																													}
																													else
																													{
																														num5--;
																													}
																													goto IL_0708;
																													IL_0708:
																													ptr2 += 8;
																													num = 91;
																													goto end_IL_0309;
																													continue;
																													end_IL_0219:
																													break;
																												}
																												continue;
																												end_IL_022c:
																												break;
																											}
																											continue;
																											end_IL_028b:
																											break;
																										}
																										continue;
																									}
																									goto IL_0406;
																									IL_06ea:
																									ptr2 += 8;
																									goto end_IL_0309;
																									IL_0406:
																									if (7 < b)
																									{
																										goto IL_0414;
																									}
																									goto IL_0497;
																									IL_0414:
																									if (8 < b)
																									{
																										goto end_IL_02cb;
																									}
																									goto IL_0422;
																									IL_0422:
																									if (8 > b)
																									{
																										goto end_IL_02cb;
																									}
																									goto IL_0430;
																									IL_0430:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0470;
																									IL_0470:
																									array[num5 - 2] = 0;
																									goto IL_0484;
																									IL_0484:
																									num5--;
																									goto end_IL_0309;
																									IL_0497:
																									if (7 > b)
																									{
																										goto end_IL_02cb;
																									}
																									goto IL_06b5;
																									IL_06b5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_06ce;
																									IL_06ce:
																									array[num5] = 0;
																									goto IL_06dc;
																									IL_06dc:
																									num5++;
																									goto IL_06ea;
																									continue;
																									end_IL_02a1:
																									break;
																								}
																								continue;
																							}
																							goto IL_0314;
																							IL_04aa:
																							num5--;
																							goto end_IL_0309;
																							IL_0314:
																							if (10 < b)
																							{
																								goto IL_031f;
																							}
																							goto IL_037f;
																							IL_031f:
																							if (11 < b)
																							{
																								goto end_IL_02cb;
																							}
																							goto IL_0612;
																							IL_0612:
																							if (11 > b)
																							{
																								goto end_IL_02cb;
																							}
																							goto IL_0620;
																							IL_0620:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							goto end_IL_0309;
																							IL_037f:
																							if (10 > b)
																							{
																								goto end_IL_02cb;
																							}
																							goto IL_04aa;
																							continue;
																							end_IL_02b1:
																							break;
																						}
																						continue;
																					}
																					goto IL_0332;
																					IL_05ff:
																					num5--;
																					goto end_IL_0309;
																					IL_0332:
																					if (6 <= b)
																					{
																						goto IL_033d;
																					}
																					goto IL_03b9;
																					IL_033d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0392;
																					IL_0392:
																					array[num5 - 2] = 0;
																					goto IL_03a6;
																					IL_03a6:
																					num5--;
																					goto end_IL_0309;
																					IL_03b9:
																					if (3 < b)
																					{
																						goto IL_03c7;
																					}
																					goto IL_0519;
																					IL_03c7:
																					if (4 >= b)
																					{
																						goto IL_03d2;
																					}
																					goto IL_03e5;
																					IL_03d2:
																					if (4 > b)
																					{
																						goto end_IL_02cb;
																					}
																					goto IL_063c;
																					IL_063c:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_067c;
																					IL_067c:
																					array[num5 - 2] = 0;
																					num = 38;
																					goto IL_0699;
																					IL_0699:
																					num5--;
																					num = 5;
																					goto end_IL_0309;
																					IL_03e5:
																					if (5 < b)
																					{
																						goto end_IL_02cb;
																					}
																					goto IL_03f3;
																					IL_03f3:
																					if (5 > b)
																					{
																						goto end_IL_02cb;
																					}
																					goto IL_04bd;
																					IL_04bd:
																					array[num5] = 0;
																					goto IL_04cb;
																					IL_04cb:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_04ee;
																					IL_04ee:
																					array2[num5] = null;
																					goto IL_04f8;
																					IL_04f8:
																					num5++;
																					goto IL_0506;
																					IL_0506:
																					ptr2 += 8;
																					goto end_IL_0309;
																					IL_0519:
																					if (3 > b)
																					{
																						goto IL_0527;
																					}
																					goto IL_05c8;
																					IL_0527:
																					if (1 >= b)
																					{
																						goto IL_0532;
																					}
																					goto IL_0545;
																					IL_0532:
																					if (1 <= b)
																					{
																					}
																					goto end_IL_02cb;
																					IL_0545:
																					if (2 < b)
																					{
																						goto end_IL_02cb;
																					}
																					goto IL_0553;
																					IL_0553:
																					if (2 > b)
																					{
																						goto end_IL_02cb;
																					}
																					goto IL_0561;
																					IL_0561:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05a1;
																					IL_05a1:
																					array[num5 - 2] = 0;
																					goto IL_05b5;
																					IL_05b5:
																					num5--;
																					goto end_IL_0309;
																					IL_05c8:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_05f1;
																					IL_05f1:
																					ptr2 += 8;
																					goto IL_05ff;
																					continue;
																					end_IL_02be:
																					break;
																				}
																				continue;
																				end_IL_02cb:
																				break;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0744;
																		IL_0752:
																		num5++;
																		goto IL_0760;
																		IL_0760:
																		ptr2 += 8;
																		goto end_IL_0309;
																		IL_0744:
																		array[num5] = 0;
																		goto IL_0752;
																		continue;
																		end_IL_02db:
																		break;
																	}
																	continue;
																	end_IL_02ee:
																	break;
																}
																continue;
																end_IL_02fe:
																break;
															}
															continue;
															end_IL_0309:
															break;
														}
														continue;
													}
													goto IL_082d;
													IL_082d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_076e:
													break;
												}
												continue;
												end_IL_0781:
												break;
											}
											continue;
											end_IL_078b:
											break;
										}
										continue;
										end_IL_0796:
										break;
									}
									continue;
									end_IL_07b4:
									break;
								}
								continue;
								end_IL_07c9:
								break;
							}
							continue;
							end_IL_07d9:
							break;
						}
						continue;
						end_IL_07e9:
						break;
					}
					continue;
					end_IL_07f9:
					break;
				}
				continue;
				end_IL_0812:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_6)
	{
		int num = 3;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_6;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct79.MultiStringCodeGroupStack);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_026e:
														byte b = *ptr2;
														num = 28;
														while (true)
														{
															IL_025e:
															ptr2++;
															while (true)
															{
																IL_024e:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0231:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0221:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0214:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_0204:
																									if (3 >= b)
																									{
																										while (3 <= b)
																										{
																											while (true)
																											{
																												IL_01d6:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												num = 109;
																												while (num != 109)
																												{
																													if (num != 1090)
																													{
																														goto IL_025e;
																													}
																													switch (num)
																													{
																													case 7:
																													case 85:
																														goto IL_01d6;
																													case 25:
																														goto IL_01f4;
																													case 96:
																														goto IL_0204;
																													case 35:
																														goto IL_0214;
																													case 30:
																														goto IL_0221;
																													case 32:
																														goto IL_0231;
																													case 56:
																														goto IL_023e;
																													case 84:
																														goto IL_024e;
																													case 28:
																														goto IL_025e;
																													case 19:
																													case 81:
																														goto IL_026e;
																													case 24:
																													case 76:
																														goto IL_0282;
																													case 88:
																														goto IL_0292;
																													case 13:
																													case 21:
																														goto IL_02a0;
																													case 75:
																														goto IL_02c9;
																													case 87:
																														goto IL_02d7;
																													case 93:
																														goto IL_02ea;
																													case 49:
																													case 91:
																														goto IL_02f5;
																													case 11:
																														goto IL_0357;
																													case 58:
																													case 64:
																														goto IL_037c;
																													case 53:
																													case 70:
																														goto IL_0387;
																													case 60:
																														goto IL_0395;
																													case 74:
																														goto IL_03a5;
																													case 82:
																													case 90:
																														goto IL_03b3;
																													case 37:
																														goto IL_03f3;
																													case 17:
																														goto IL_0407;
																													case 46:
																													case 94:
																														goto IL_041a;
																													case 5:
																														goto IL_043d;
																													case 86:
																														goto IL_044b;
																													case 29:
																														goto IL_0459;
																													case 99:
																														goto IL_046c;
																													case 98:
																														goto IL_047a;
																													case 33:
																													case 71:
																														goto IL_0488;
																													case 16:
																														goto IL_04a1;
																													case 10:
																														goto IL_04af;
																													case 73:
																														goto IL_04bd;
																													case 97:
																													case 100:
																														goto IL_04d0;
																													case 72:
																														goto IL_04de;
																													case 78:
																														goto IL_0501;
																													case 15:
																														goto IL_050b;
																													case 36:
																														goto IL_0519;
																													case 65:
																													case 102:
																														goto IL_0529;
																													case 9:
																														goto IL_0534;
																													case 48:
																													case 95:
																														goto IL_053f;
																													case 31:
																														goto IL_0558;
																													case 77:
																														goto IL_0563;
																													case 57:
																														goto IL_0570;
																													case 20:
																														goto IL_057b;
																													case 1:
																													case 6:
																													case 14:
																													case 27:
																													case 34:
																													case 39:
																													case 42:
																													case 52:
																													case 54:
																													case 55:
																													case 61:
																													case 67:
																													case 68:
																													case 79:
																													case 80:
																													case 89:
																													case 92:
																													case 101:
																														goto end_IL_01f4;
																													case 0:
																													case 8:
																													case 18:
																													case 26:
																													case 38:
																													case 40:
																													case 41:
																													case 43:
																													case 62:
																													case 66:
																													case 69:
																													case 83:
																														goto end_IL_01c3;
																													case 44:
																														goto end_IL_0599;
																													case 47:
																														goto end_IL_05ac;
																													case 23:
																														goto end_IL_05b6;
																													case 12:
																														goto end_IL_05c1;
																													case 4:
																													case 63:
																														goto end_IL_05d6;
																													case 45:
																														goto end_IL_05e6;
																													case 22:
																													case 59:
																														goto end_IL_05f6;
																													case 2:
																														goto end_IL_0606;
																													case 3:
																														goto end_IL_0616;
																													case 50:
																													case 51:
																														goto IL_0631;
																													}
																													continue;
																													end_IL_01c3:
																													break;
																												}
																												break;
																											}
																											goto end_IL_024e;
																											continue;
																											end_IL_01f4:
																											break;
																											IL_01f4:;
																										}
																										break;
																									}
																									goto IL_0570;
																									IL_057b:
																									if (4 <= b)
																									{
																										goto end_IL_024e;
																									}
																									break;
																									IL_0570:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_057b;
																								}
																								break;
																							}
																							goto IL_0292;
																							IL_04bd:
																							ptr2 += 8;
																							goto end_IL_024e;
																							IL_0292:
																							if (2 <= b)
																							{
																								goto IL_02a0;
																							}
																							goto IL_046c;
																							IL_02a0:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_02c9;
																							IL_02c9:
																							ptr2 += 8;
																							goto IL_02d7;
																							IL_02d7:
																							num5--;
																							goto end_IL_024e;
																							IL_046c:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_047a;
																							IL_047a:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0488;
																							IL_0488:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_04a1;
																							IL_04a1:
																							array[num5] = 0;
																							goto IL_04af;
																							IL_04af:
																							num5++;
																							goto IL_04bd;
																						}
																						break;
																					}
																					goto IL_04d0;
																					IL_0519:
																					ptr2 += 8;
																					goto end_IL_024e;
																					IL_04d0:
																					array[num5] = 0;
																					goto IL_04de;
																					IL_04de:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0501;
																					IL_0501:
																					array2[num5] = null;
																					goto IL_050b;
																					IL_050b:
																					num5++;
																					goto IL_0519;
																				}
																				break;
																			}
																			goto IL_0282;
																			IL_03f3:
																			array[num5 - 2] = 0;
																			goto IL_0407;
																			IL_0282:
																			if (8 >= b)
																			{
																				goto IL_02ea;
																			}
																			goto IL_0529;
																			IL_0529:
																			if (9 >= b)
																			{
																				goto IL_0534;
																			}
																			goto IL_0558;
																			IL_0534:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_053f;
																			IL_053f:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_024e;
																			IL_0558:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0563;
																			IL_0563:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_02ea:
																			if (8 <= b)
																			{
																				goto IL_02f5;
																			}
																			num = 58;
																			goto IL_037c;
																			IL_02f5:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0357;
																			IL_0357:
																			num5 -= 2;
																			num = 41;
																			goto end_IL_024e;
																			IL_0407:
																			num5--;
																			goto end_IL_024e;
																			IL_037c:
																			if (6 < b)
																			{
																				goto IL_0387;
																			}
																			goto IL_03a5;
																			IL_0387:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_0395;
																			IL_0395:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_041a;
																			IL_041a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_043d;
																			IL_043d:
																			array[num5] = 0;
																			goto IL_044b;
																			IL_044b:
																			num5++;
																			goto IL_0459;
																			IL_0459:
																			ptr2 += 8;
																			goto end_IL_024e;
																			IL_03a5:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_03b3;
																			IL_03b3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03f3;
																		}
																		break;
																		IL_023e:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_024e:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0631;
												IL_0631:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0599:
												break;
											}
											continue;
											end_IL_05ac:
											break;
										}
										continue;
										end_IL_05b6:
										break;
									}
									continue;
									end_IL_05c1:
									break;
								}
								continue;
								end_IL_05d6:
								break;
							}
							continue;
							end_IL_05e6:
							break;
						}
						continue;
						end_IL_05f6:
						break;
					}
					continue;
					end_IL_0606:
					break;
				}
				continue;
				end_IL_0616:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_6)
	{
		int num = 131;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 83;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 111;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref InternalArrayTypeEgetIsThreadPoolThread.outCharsInitial);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0361:
															byte b = *ptr2;
															while (true)
															{
																IL_0351:
																ptr2++;
																while (true)
																{
																	IL_0341:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_0321:
																				if (7 < b)
																				{
																					while (true)
																					{
																						IL_0314:
																						if (11 >= b)
																						{
																							while (true)
																							{
																								IL_0307:
																								if (11 > b)
																								{
																									while (true)
																									{
																										IL_02f7:
																										if (9 >= b)
																										{
																											while (true)
																											{
																												IL_02e7:
																												if (9 <= b)
																												{
																													while (true)
																													{
																														IL_0283:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														while (true)
																														{
																															IL_026a:
																															num5 -= 2;
																															num = 146;
																															while (num != 146)
																															{
																																if (num != 1127)
																																{
																																	goto IL_0307;
																																}
																																switch (num)
																																{
																																case 64:
																																	goto IL_026a;
																																case 21:
																																case 110:
																																	goto IL_0283;
																																case 126:
																																	goto IL_02e7;
																																case 78:
																																	goto IL_02f7;
																																case 119:
																																	goto IL_0307;
																																case 9:
																																case 39:
																																	goto IL_0314;
																																case 27:
																																	goto IL_0321;
																																case 81:
																																	goto IL_0331;
																																case 116:
																																	goto IL_0341;
																																case 79:
																																	goto IL_0351;
																																case 33:
																																case 132:
																																	goto IL_0361;
																																case 36:
																																case 41:
																																	goto IL_036c;
																																case 53:
																																	goto IL_0385;
																																case 26:
																																case 70:
																																	goto IL_0392;
																																case 67:
																																	goto IL_03a0;
																																case 75:
																																	goto IL_03b0;
																																case 98:
																																case 100:
																																	goto IL_03be;
																																case 80:
																																case 101:
																																	goto IL_03da;
																																case 40:
																																	goto IL_03e8;
																																case 15:
																																case 103:
																																	goto IL_03fb;
																																case 86:
																																	goto IL_041e;
																																case 107:
																																	goto IL_042c;
																																case 54:
																																	goto IL_043a;
																																case 112:
																																	goto IL_044d;
																																case 82:
																																	goto IL_04a1;
																																case 49:
																																	goto IL_04af;
																																case 11:
																																case 134:
																																	goto IL_04c2;
																																case 45:
																																	goto IL_04d0;
																																case 13:
																																case 43:
																																	goto IL_04de;
																																case 118:
																																	goto IL_04fa;
																																case 61:
																																	goto IL_0508;
																																case 56:
																																case 69:
																																	goto IL_0513;
																																case 71:
																																	goto IL_0553;
																																case 104:
																																	goto IL_0567;
																																case 47:
																																	goto IL_0588;
																																case 32:
																																case 120:
																																	goto IL_0593;
																																case 20:
																																	goto IL_05d3;
																																case 23:
																																	goto IL_05e7;
																																case 42:
																																	goto IL_05fa;
																																case 93:
																																case 109:
																																	goto IL_0608;
																																case 55:
																																	goto IL_0616;
																																case 8:
																																case 87:
																																	goto IL_0621;
																																case 2:
																																	goto IL_062f;
																																case 1:
																																case 122:
																																	goto IL_0642;
																																case 3:
																																	goto IL_0650;
																																case 95:
																																	goto IL_067c;
																																case 4:
																																	goto IL_0686;
																																case 127:
																																	goto IL_0694;
																																case 22:
																																	goto IL_06a7;
																																case 24:
																																	goto IL_06b5;
																																case 94:
																																case 125:
																																	goto IL_06c3;
																																case 30:
																																	goto IL_0703;
																																case 60:
																																	goto IL_0717;
																																case 113:
																																	goto IL_0733;
																																case 48:
																																case 102:
																																	goto IL_073e;
																																case 5:
																																	goto IL_0756;
																																case 14:
																																case 29:
																																	goto IL_0761;
																																case 89:
																																	goto IL_076f;
																																case 51:
																																case 139:
																																	goto IL_077d;
																																case 138:
																																	goto IL_07a6;
																																case 37:
																																	goto IL_07b4;
																																case 58:
																																	goto IL_07c4;
																																case 106:
																																case 128:
																																	goto IL_07cf;
																																case 34:
																																	goto IL_07e8;
																																case 121:
																																	goto IL_07f6;
																																case 124:
																																	goto IL_0804;
																																case 0:
																																case 6:
																																case 7:
																																case 10:
																																case 12:
																																case 16:
																																case 17:
																																case 18:
																																case 19:
																																case 25:
																																case 28:
																																case 38:
																																case 46:
																																case 50:
																																case 52:
																																case 57:
																																case 65:
																																case 68:
																																case 73:
																																case 84:
																																case 88:
																																case 96:
																																case 115:
																																case 133:
																																case 137:
																																	goto end_IL_0331;
																																case 31:
																																case 35:
																																case 44:
																																case 62:
																																case 66:
																																case 72:
																																case 74:
																																case 76:
																																case 85:
																																case 91:
																																case 92:
																																case 97:
																																case 108:
																																case 123:
																																case 129:
																																case 136:
																																	goto end_IL_0257;
																																case 114:
																																	goto end_IL_0827;
																																case 90:
																																	goto end_IL_083a;
																																case 117:
																																	goto end_IL_0844;
																																case 59:
																																	goto end_IL_084f;
																																case 111:
																																	goto end_IL_0864;
																																case 105:
																																	goto end_IL_0874;
																																case 83:
																																	goto end_IL_0884;
																																case 99:
																																case 135:
																																	goto end_IL_088f;
																																case 130:
																																	goto end_IL_089f;
																																case 131:
																																	goto end_IL_08b8;
																																case 63:
																																case 77:
																																	goto IL_08d3;
																																}
																																continue;
																																end_IL_0257:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0392;
																												IL_043a:
																												ptr2 += 8;
																												break;
																												IL_0392:
																												if (8 < b)
																												{
																													goto end_IL_0331;
																												}
																												goto IL_03a0;
																												IL_03a0:
																												if (8 > b)
																												{
																													goto end_IL_0331;
																												}
																												goto IL_03fb;
																												IL_03fb:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_041e;
																												IL_041e:
																												array[num5] = 0;
																												goto IL_042c;
																												IL_042c:
																												num5++;
																												goto IL_043a;
																											}
																											break;
																										}
																										goto IL_04fa;
																										IL_0567:
																										num5--;
																										break;
																										IL_04fa:
																										if (10 < b)
																										{
																											goto end_IL_0331;
																										}
																										goto IL_0508;
																										IL_0508:
																										if (10 > b)
																										{
																											num = 52;
																											goto end_IL_0331;
																										}
																										goto IL_0513;
																										IL_0513:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0553;
																										IL_0553:
																										array[num5 - 2] = 0;
																										goto IL_0567;
																									}
																									break;
																								}
																								goto IL_036c;
																								IL_04af:
																								ptr2 += 8;
																								break;
																								IL_036c:
																								array[num5 - 2] = 0;
																								goto IL_044d;
																								IL_044d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)PoprefpopipopDNDS[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								goto IL_04a1;
																								IL_04a1:
																								num5--;
																								goto IL_04af;
																							}
																							break;
																						}
																						goto IL_0385;
																						IL_04de:
																						num5--;
																						num = 91;
																						break;
																						IL_0385:
																						if (13 >= b)
																						{
																							goto IL_03b0;
																						}
																						goto IL_03da;
																						IL_03da:
																						if (14 < b)
																						{
																							goto end_IL_0331;
																						}
																						goto IL_03e8;
																						IL_03e8:
																						if (14 > b)
																						{
																						}
																						goto end_IL_0331;
																						IL_03b0:
																						if (13 <= b)
																						{
																							goto IL_03be;
																						}
																						goto IL_04c2;
																						IL_03be:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						break;
																						IL_04c2:
																						if (12 < b)
																						{
																							goto end_IL_0331;
																						}
																						goto IL_04d0;
																						IL_04d0:
																						if (12 > b)
																						{
																							goto end_IL_0331;
																						}
																						goto IL_04de;
																					}
																					break;
																				}
																				goto IL_0588;
																				IL_0804:
																				ptr2 += 8;
																				break;
																				IL_0588:
																				if (7 <= b)
																				{
																					goto IL_0593;
																				}
																				goto IL_05fa;
																				IL_0593:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05d3;
																				IL_05d3:
																				array[num5 - 2] = 0;
																				goto IL_05e7;
																				IL_05e7:
																				num5--;
																				break;
																				IL_05fa:
																				if (3 < b)
																				{
																					goto IL_0608;
																				}
																				goto IL_0733;
																				IL_0608:
																				if (5 >= b)
																				{
																					goto IL_0616;
																				}
																				goto IL_06a7;
																				IL_0616:
																				if (5 > b)
																				{
																					goto IL_0621;
																				}
																				goto IL_0642;
																				IL_0621:
																				if (4 < b)
																				{
																					goto end_IL_0331;
																				}
																				goto IL_062f;
																				IL_062f:
																				if (4 > b)
																				{
																					goto end_IL_0331;
																				}
																				break;
																				IL_0642:
																				array[num5] = 0;
																				goto IL_0650;
																				IL_0650:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 95;
																				goto IL_067c;
																				IL_067c:
																				array2[num5] = null;
																				goto IL_0686;
																				IL_0686:
																				num5++;
																				goto IL_0694;
																				IL_0694:
																				ptr2 += 8;
																				break;
																				IL_06a7:
																				if (6 < b)
																				{
																					goto end_IL_0331;
																				}
																				goto IL_06b5;
																				IL_06b5:
																				if (6 > b)
																				{
																					goto end_IL_0331;
																				}
																				goto IL_06c3;
																				IL_06c3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0703;
																				IL_0703:
																				array[num5 - 2] = 0;
																				goto IL_0717;
																				IL_0717:
																				num5--;
																				num = 136;
																				break;
																				IL_0733:
																				if (3 <= b)
																				{
																					goto IL_073e;
																				}
																				goto IL_0756;
																				IL_073e:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_0756:
																				if (1 < b)
																				{
																					goto IL_0761;
																				}
																				goto IL_07c4;
																				IL_0761:
																				if (2 < b)
																				{
																					goto end_IL_0331;
																				}
																				goto IL_076f;
																				IL_076f:
																				if (2 > b)
																				{
																					goto end_IL_0331;
																				}
																				goto IL_077d;
																				IL_077d:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_07a6;
																				IL_07a6:
																				ptr2 += 8;
																				goto IL_07b4;
																				IL_07b4:
																				num5--;
																				break;
																				IL_07c4:
																				if (1 > b)
																				{
																					goto end_IL_0331;
																				}
																				goto IL_07cf;
																				IL_07cf:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_07e8;
																				IL_07e8:
																				array[num5] = 0;
																				goto IL_07f6;
																				IL_07f6:
																				num5++;
																				goto IL_0804;
																			}
																			goto end_IL_0341;
																			continue;
																			end_IL_0331:
																			break;
																			IL_0331:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0341:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_08d3;
													IL_08d3:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0827:
													break;
												}
												continue;
												end_IL_083a:
												break;
											}
											continue;
											end_IL_0844:
											break;
										}
										continue;
										end_IL_084f:
										break;
									}
									continue;
									end_IL_0864:
									break;
								}
								continue;
								end_IL_0874:
								break;
							}
							continue;
							end_IL_0884:
							break;
						}
						continue;
						end_IL_088f:
						break;
					}
					continue;
					end_IL_089f:
					break;
				}
				continue;
				end_IL_08b8:
				break;
			}
		}
	}

	private static int smethod_6(int int_6)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_6;
			if (num >= num4)
			{
				break;
			}
			num = 0;
			int num5 = 0;
			while (true)
			{
				num = num5;
				num4 = int_6;
				if (num >= num4)
				{
					break;
				}
				num = num2;
				num4 = num3;
				int num6 = num5;
				num4 *= num6;
				num += num4;
				num2 = num;
				num = num5;
				num4 = 1;
				num++;
				num5 = num;
			}
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_7(int int_6)
	{
		int num = 94;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_6;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NativeOverlappedCreateFromCertFile.DarkBlueGrantedSet);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_025d:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_023d:
																			if (6 < b)
																			{
																				goto IL_0488;
																			}
																			while (true)
																			{
																				IL_0230:
																				if (6 > b)
																				{
																					while (true)
																					{
																						IL_021d:
																						if (3 < b)
																						{
																							num = 13;
																							while (true)
																							{
																								IL_020a:
																								if (4 >= b)
																								{
																									num = 115;
																									while (true)
																									{
																										if (num != 115)
																										{
																											if (num != 1096)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 13:
																											case 67:
																												goto IL_020a;
																											case 57:
																												goto IL_021d;
																											case 43:
																												goto IL_0230;
																											case 18:
																												goto IL_023d;
																											case 37:
																												goto end_IL_023d;
																											case 77:
																												goto IL_025d;
																											case 63:
																												goto end_IL_025d;
																											case 58:
																											case 98:
																												goto end_IL_026d;
																											case 52:
																											case 64:
																												goto IL_0291;
																											case 22:
																												goto IL_02d1;
																											case 35:
																												goto IL_02e5;
																											case 65:
																												goto IL_030b;
																											case 60:
																												goto IL_0319;
																											case 26:
																											case 107:
																												goto IL_0327;
																											case 38:
																												goto IL_0335;
																											case 9:
																												goto IL_0358;
																											case 12:
																												goto IL_0362;
																											case 105:
																												goto IL_0370;
																											case 80:
																												goto IL_038c;
																											case 49:
																											case 66:
																												goto IL_0397;
																											case 71:
																											case 87:
																												goto IL_03af;
																											case 68:
																												goto IL_03ba;
																											case 40:
																											case 54:
																												goto IL_03c8;
																											case 48:
																												goto IL_03e1;
																											case 90:
																												goto IL_03f8;
																											case 61:
																												goto IL_0406;
																											case 20:
																												goto IL_0419;
																											case 11:
																												goto IL_0427;
																											case 83:
																											case 97:
																												goto IL_0435;
																											case 14:
																												goto IL_045e;
																											case 102:
																												goto IL_046c;
																											case 29:
																												goto IL_0488;
																											case 47:
																												goto IL_0493;
																											case 70:
																												goto IL_049e;
																											case 25:
																											case 50:
																												goto IL_04ac;
																											case 44:
																												goto IL_04d1;
																											case 53:
																												goto IL_04dc;
																											case 59:
																												goto IL_0506;
																											case 86:
																											case 103:
																												goto end_IL_01f7;
																											case 92:
																												goto IL_0573;
																											case 28:
																												goto IL_0586;
																											case 101:
																												goto IL_0591;
																											case 4:
																											case 45:
																												goto IL_059f;
																											case 19:
																												goto IL_05df;
																											case 7:
																												goto IL_05f3;
																											case 96:
																												goto IL_0603;
																											case 108:
																												goto IL_060e;
																											case 5:
																											case 10:
																												goto IL_0619;
																											case 99:
																												goto IL_063c;
																											case 0:
																												goto IL_064a;
																											case 42:
																												goto IL_0658;
																											case 3:
																											case 17:
																											case 21:
																											case 27:
																											case 30:
																											case 31:
																											case 32:
																											case 36:
																											case 51:
																											case 56:
																											case 69:
																											case 72:
																											case 74:
																											case 76:
																											case 79:
																											case 82:
																											case 88:
																											case 95:
																											case 104:
																												goto end_IL_024d;
																											case 6:
																											case 8:
																											case 15:
																											case 23:
																											case 33:
																											case 34:
																											case 41:
																											case 46:
																											case 62:
																											case 75:
																											case 78:
																											case 85:
																											case 91:
																											case 106:
																												goto end_IL_027d;
																											case 2:
																												goto end_IL_067b;
																											case 84:
																												goto end_IL_068e;
																											case 39:
																												goto end_IL_0698;
																											case 55:
																												goto end_IL_06a3;
																											case 1:
																											case 24:
																												goto end_IL_06b8;
																											case 89:
																												goto end_IL_06c8;
																											case 16:
																											case 100:
																												goto end_IL_06d8;
																											case 93:
																												goto end_IL_06e8;
																											case 94:
																												goto end_IL_06f8;
																											case 73:
																											case 81:
																												goto IL_0713;
																											}
																											continue;
																										}
																										if (4 <= b)
																										{
																											goto end_IL_027d;
																										}
																										goto end_IL_024d;
																										continue;
																										end_IL_01f7:
																										break;
																									}
																									break;
																								}
																								goto IL_030b;
																								IL_0362:
																								num5++;
																								goto IL_0370;
																								IL_0370:
																								ptr2 += 8;
																								num = 78;
																								goto end_IL_027d;
																								IL_030b:
																								if (5 < b)
																								{
																									goto end_IL_024d;
																								}
																								goto IL_0319;
																								IL_0319:
																								if (5 > b)
																								{
																									goto end_IL_024d;
																								}
																								goto IL_0327;
																								IL_0327:
																								array[num5] = 0;
																								goto IL_0335;
																								IL_0335:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0358;
																								IL_0358:
																								array2[num5] = null;
																								goto IL_0362;
																							}
																							break;
																						}
																						goto IL_038c;
																						IL_045e:
																						ptr2 += 8;
																						goto IL_046c;
																						IL_046c:
																						num5--;
																						num = 33;
																						goto end_IL_027d;
																						IL_038c:
																						if (3 <= b)
																						{
																							goto IL_0397;
																						}
																						goto IL_03af;
																						IL_0397:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_027d;
																						IL_03af:
																						if (1 >= b)
																						{
																							goto IL_03ba;
																						}
																						goto IL_0419;
																						IL_03ba:
																						if (1 > b)
																						{
																							goto end_IL_024d;
																						}
																						goto IL_03c8;
																						IL_03c8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_03e1;
																						IL_03e1:
																						array[num5] = 0;
																						num = 90;
																						goto IL_03f8;
																						IL_03f8:
																						num5++;
																						goto IL_0406;
																						IL_0406:
																						ptr2 += 8;
																						goto end_IL_027d;
																						IL_0419:
																						if (2 < b)
																						{
																							goto end_IL_024d;
																						}
																						goto IL_0427;
																						IL_0427:
																						if (2 > b)
																						{
																							goto end_IL_024d;
																						}
																						goto IL_0435;
																						IL_0435:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_045e;
																					}
																					break;
																				}
																				num = 52;
																				goto IL_0291;
																				IL_02d1:
																				array[num5 - 2] = 0;
																				goto IL_02e5;
																				IL_02e5:
																				num5--;
																				goto end_IL_027d;
																				IL_0291:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_02d1;
																			}
																			goto IL_0511;
																			IL_063c:
																			array[num5] = 0;
																			goto IL_064a;
																			IL_0488:
																			if (9 < b)
																			{
																				goto IL_0493;
																			}
																			num = 59;
																			goto IL_0506;
																			IL_0493:
																			if (10 >= b)
																			{
																				goto IL_049e;
																			}
																			goto IL_04d1;
																			IL_049e:
																			if (10 > b)
																			{
																				goto end_IL_024d;
																			}
																			goto IL_04ac;
																			IL_04ac:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 75;
																			goto end_IL_027d;
																			IL_04d1:
																			if (11 < b)
																			{
																				num = 32;
																				goto end_IL_024d;
																			}
																			goto IL_04dc;
																			IL_04dc:
																			if (11 > b)
																			{
																			}
																			goto end_IL_024d;
																			IL_0658:
																			ptr2 += 8;
																			goto end_IL_027d;
																			IL_064a:
																			num5++;
																			goto IL_0658;
																			IL_0506:
																			if (9 <= b)
																			{
																				goto IL_0511;
																			}
																			goto IL_0586;
																			IL_0511:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0573;
																			IL_0573:
																			num5 -= 2;
																			goto end_IL_027d;
																			IL_0586:
																			if (7 >= b)
																			{
																				goto IL_0591;
																			}
																			goto IL_0603;
																			IL_0591:
																			if (7 > b)
																			{
																				goto end_IL_024d;
																			}
																			goto IL_059f;
																			IL_059f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05df;
																			IL_05df:
																			array[num5 - 2] = 0;
																			goto IL_05f3;
																			IL_05f3:
																			num5--;
																			goto end_IL_027d;
																			IL_0603:
																			if (8 < b)
																			{
																				goto end_IL_024d;
																			}
																			goto IL_060e;
																			IL_060e:
																			if (8 > b)
																			{
																				goto end_IL_024d;
																			}
																			goto IL_0619;
																			IL_0619:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_063c;
																			continue;
																			end_IL_023d:
																			break;
																		}
																		continue;
																		end_IL_024d:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_027d;
																continue;
																end_IL_025d:
																break;
															}
															continue;
															end_IL_026d:
															break;
														}
														continue;
														end_IL_027d:
														break;
													}
													continue;
												}
												goto IL_0713;
												IL_0713:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_067b:
												break;
											}
											continue;
											end_IL_068e:
											break;
										}
										continue;
										end_IL_0698:
										break;
									}
									continue;
									end_IL_06a3:
									break;
								}
								continue;
								end_IL_06b8:
								break;
							}
							continue;
							end_IL_06c8:
							break;
						}
						continue;
						end_IL_06d8:
						break;
					}
					continue;
					end_IL_06e8:
					break;
				}
				continue;
				end_IL_06f8:
				break;
			}
		}
	}

	static Class125()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 5;
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					IL_0066:
					num = 2;
					while (true)
					{
						IL_005a:
						num = 17;
						while (true)
						{
							if (num != 17)
							{
								if (num != 998)
								{
									break;
								}
								switch (num)
								{
								case 2:
									goto IL_005a;
								case 4:
								case 7:
									goto IL_0066;
								case 5:
									goto end_IL_004d;
								case 6:
									goto end_IL_0075;
								case 0:
								case 1:
								case 3:
								case 8:
									goto IL_0090;
								case 9:
									return;
								case 10:
									return;
								}
								continue;
							}
							goto IL_0090;
							IL_0090:
							num = 10;
							return;
							continue;
							end_IL_004d:
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_0075:
				break;
			}
		}
	}

	private static void CertMaximumConcurrencyLevel(Class125 class125_1)
	{
		class125_1.method_1();
	}
}
