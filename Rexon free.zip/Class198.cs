using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("RGB Monke", "Rig", "Rainbow monke color in stump.", false, 8, ModType.const_0, false)]
internal class Class198 : MonoBehaviour
{
	private float float_0;

	private float float_1;

	private static float float_2;

	private static int int_0;

	private static float float_3;

	private static int int_1;

	private static bool bool_0;

	private static IntPtr[] getCategoryEventInfo;

	private static double getIsLayoutSequentialgetInArgCount(double double_0)
	{
		return Math.Sin(double_0);
	}

	private static void RegisterSoapActionForMethodBaseStripAfterObfuscation()
	{
		PlayerPrefs.Save();
	}

	private static double getFrameworkDescriptionAsUint(double double_0)
	{
		return Math.Round(double_0);
	}

	private static double NullableMarshalersetLocalizationResources(double double_0)
	{
		return Math.Cos(double_0);
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 25;
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetAssemblyManifestRemotingSurrogateSelector.StringToCoTaskMemAutogetDeploymentId);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_026d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_024d:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0240:
																					if (8 >= b)
																					{
																						while (true)
																						{
																							IL_0230:
																							if (8 > b)
																							{
																								while (true)
																								{
																									IL_0220:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_01d2:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													num = 108;
																													while (true)
																													{
																														if (num != 108)
																														{
																															if (num != 1089)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 11:
																															case 90:
																																goto IL_01d2;
																															case 9:
																																goto IL_0200;
																															case 37:
																																goto IL_0210;
																															case 53:
																															case 57:
																																goto IL_0220;
																															case 17:
																																goto IL_0230;
																															case 46:
																															case 56:
																																goto IL_0240;
																															case 76:
																																goto IL_024d;
																															case 34:
																																goto IL_025d;
																															case 8:
																																goto IL_026d;
																															case 32:
																																goto end_IL_026d;
																															case 15:
																															case 18:
																																goto end_IL_027d;
																															case 24:
																															case 87:
																																goto IL_0298;
																															case 66:
																																goto IL_02a3;
																															case 28:
																															case 81:
																																goto IL_02b1;
																															case 39:
																																goto IL_02cd;
																															case 23:
																																goto IL_02db;
																															case 26:
																																goto IL_02fc;
																															case 16:
																																goto IL_030a;
																															case 20:
																																goto IL_0326;
																															case 7:
																															case 91:
																																goto IL_0334;
																															case 75:
																																goto IL_0374;
																															case 72:
																																goto IL_0388;
																															case 4:
																															case 6:
																																goto IL_039b;
																															case 50:
																																goto end_IL_01bf;
																															case 19:
																																goto IL_0410;
																															case 92:
																															case 100:
																																goto IL_041e;
																															case 42:
																															case 85:
																																goto IL_0429;
																															case 36:
																															case 43:
																																goto IL_0434;
																															case 74:
																																goto IL_0442;
																															case 89:
																																goto IL_0455;
																															case 13:
																															case 59:
																																goto IL_0463;
																															case 12:
																																goto IL_047b;
																															case 10:
																															case 70:
																																goto IL_0486;
																															case 0:
																																goto IL_04af;
																															case 21:
																																goto IL_04bd;
																															case 71:
																																goto IL_04d0;
																															case 78:
																																goto IL_04de;
																															case 49:
																															case 64:
																																goto IL_04ec;
																															case 51:
																																goto IL_0505;
																															case 84:
																																goto IL_0513;
																															case 95:
																																goto IL_0521;
																															case 86:
																															case 96:
																																goto IL_0531;
																															case 99:
																																goto IL_053f;
																															case 62:
																																goto IL_056b;
																															case 65:
																																goto IL_0575;
																															case 14:
																																goto IL_0583;
																															case 3:
																															case 22:
																															case 35:
																															case 45:
																															case 60:
																															case 61:
																															case 67:
																															case 68:
																															case 69:
																															case 73:
																															case 79:
																															case 80:
																															case 83:
																															case 93:
																															case 101:
																																goto end_IL_0200;
																															case 2:
																															case 5:
																															case 27:
																															case 38:
																															case 40:
																															case 41:
																															case 44:
																															case 47:
																															case 48:
																															case 54:
																															case 58:
																															case 88:
																															case 94:
																																goto end_IL_028d;
																															case 82:
																																goto end_IL_05a6;
																															case 55:
																																goto end_IL_05b9;
																															case 77:
																																goto end_IL_05c3;
																															case 1:
																																goto end_IL_05ce;
																															case 25:
																															case 52:
																																goto end_IL_05e3;
																															case 33:
																																goto end_IL_05f3;
																															case 31:
																															case 63:
																																goto end_IL_0603;
																															case 29:
																																goto end_IL_061c;
																															case 30:
																																goto end_IL_062c;
																															case 97:
																															case 98:
																																goto IL_0650;
																															}
																															continue;
																														}
																														array[num5] = 0;
																														goto IL_02fc;
																														IL_02fc:
																														num5++;
																														goto IL_030a;
																														IL_030a:
																														ptr2 += 8;
																														num = 88;
																														goto end_IL_028d;
																														continue;
																														end_IL_01bf:
																														break;
																													}
																													break;
																												}
																												goto IL_03fd;
																												continue;
																												end_IL_0200:
																												break;
																												IL_0200:;
																											}
																											break;
																											IL_0210:;
																										}
																										break;
																									}
																									goto IL_0326;
																									IL_0388:
																									num5--;
																									goto end_IL_028d;
																									IL_0326:
																									if (6 > b)
																									{
																										break;
																									}
																									goto IL_0334;
																									IL_0334:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0374;
																									IL_0374:
																									array[num5 - 2] = 0;
																									goto IL_0388;
																								}
																								break;
																							}
																							goto IL_039b;
																							IL_03fd:
																							num5 -= 2;
																							goto end_IL_028d;
																							IL_039b:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_03fd;
																						}
																						break;
																					}
																					goto IL_0298;
																					IL_02db:
																					if (10 > b)
																					{
																					}
																					break;
																					IL_0298:
																					if (9 >= b)
																					{
																						goto IL_02a3;
																					}
																					goto IL_02cd;
																					IL_02a3:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_02b1;
																					IL_02b1:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_028d;
																					IL_02cd:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_02db;
																				}
																				break;
																			}
																			goto IL_0410;
																			IL_0583:
																			ptr2 += 8;
																			goto end_IL_028d;
																			IL_0410:
																			if (5 > b)
																			{
																				goto IL_041e;
																			}
																			goto IL_0531;
																			IL_041e:
																			if (2 < b)
																			{
																				goto IL_0429;
																			}
																			goto IL_047b;
																			IL_0429:
																			if (3 < b)
																			{
																				goto IL_0434;
																			}
																			goto IL_0455;
																			IL_0434:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0442;
																			IL_0442:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_028d;
																			IL_0455:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0463;
																			IL_0463:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_028d;
																			IL_047b:
																			if (2 <= b)
																			{
																				goto IL_0486;
																			}
																			goto IL_04d0;
																			IL_0486:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04af;
																			IL_04af:
																			ptr2 += 8;
																			goto IL_04bd;
																			IL_04bd:
																			num5--;
																			goto end_IL_028d;
																			IL_04d0:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_04de;
																			IL_04de:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04ec;
																			IL_04ec:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0505;
																			IL_0505:
																			array[num5] = 0;
																			goto IL_0513;
																			IL_0513:
																			num5++;
																			goto IL_0521;
																			IL_0521:
																			ptr2 += 8;
																			goto end_IL_028d;
																			IL_0531:
																			array[num5] = 0;
																			goto IL_053f;
																			IL_053f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 62;
																			goto IL_056b;
																			IL_056b:
																			array2[num5] = null;
																			goto IL_0575;
																			IL_0575:
																			num5++;
																			goto IL_0583;
																		}
																		break;
																		IL_025d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_028d;
																continue;
																end_IL_026d:
																break;
															}
															continue;
															end_IL_027d:
															break;
														}
														continue;
														end_IL_028d:
														break;
													}
													continue;
												}
												num = 97;
												goto IL_0650;
												IL_0650:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05a6:
												break;
											}
											continue;
											end_IL_05b9:
											break;
										}
										continue;
										end_IL_05c3:
										break;
									}
									continue;
									end_IL_05ce:
									break;
								}
								continue;
								end_IL_05e3:
								break;
							}
							continue;
							end_IL_05f3:
							break;
						}
						continue;
						end_IL_0603:
						break;
					}
					continue;
					end_IL_061c:
					break;
				}
				continue;
				end_IL_062c:
				break;
			}
		}
	}

	private static void FormatStubInfoIIDENTITYAUTHORITYDEFINITIONIDENTITYTOTEXTFLAGS(Material material_0, string string_0, Color color_0)
	{
		material_0.SetColor(string_0, color_0);
	}

	private static GorillaTagger IProgIdRedirectionEntrygetManifestModule()
	{
		return GorillaTagger.Instance;
	}

	private static float GetGenericParameterConstraintsFReplaceable(Color color_0)
	{
		return color_0.g;
	}

	private static double getCreationTimeDeconstruct(double double_0)
	{
		return Math.Ceiling(double_0);
	}

	private static VRRig FileSecuritySeekOrigin(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.offlineVRRig;
	}

	private unsafe static int smethod_1(int int_2)
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 79;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getPersistPoprefpop.getPersistPoprefpop_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0248:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0228:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0218:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_020b:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_01f8:
																									if (3 < b)
																									{
																										num = 114;
																										while (true)
																										{
																											if (num != 114)
																											{
																												if (num != 1095)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 101:
																													goto IL_01f8;
																												case 72:
																												case 107:
																													goto IL_020b;
																												case 50:
																													goto IL_0218;
																												case 68:
																													goto IL_0228;
																												case 93:
																													goto IL_0238;
																												case 43:
																													goto IL_0248;
																												case 92:
																													goto end_IL_0248;
																												case 33:
																												case 62:
																													goto end_IL_0258;
																												case 42:
																													goto IL_0273;
																												case 1:
																												case 26:
																													goto IL_027e;
																												case 19:
																													goto IL_02a7;
																												case 27:
																												case 44:
																													goto IL_02b7;
																												case 76:
																													goto IL_02ce;
																												case 83:
																													goto IL_02de;
																												case 7:
																												case 97:
																													goto IL_02f1;
																												case 6:
																													goto IL_030a;
																												case 39:
																													goto IL_0318;
																												case 69:
																													goto IL_032f;
																												case 98:
																													goto IL_0342;
																												case 65:
																												case 86:
																													goto IL_0350;
																												case 3:
																													goto IL_0368;
																												case 10:
																													goto IL_0376;
																												case 0:
																												case 90:
																													goto IL_0389;
																												case 31:
																													goto IL_0397;
																												case 73:
																													goto IL_03ba;
																												case 81:
																													goto IL_03c4;
																												case 12:
																													goto IL_03d2;
																												case 4:
																												case 28:
																													goto IL_03e5;
																												case 13:
																												case 47:
																													goto IL_03f0;
																												case 36:
																												case 46:
																													goto IL_03fb;
																												case 20:
																													goto IL_0406;
																												case 24:
																													goto IL_0427;
																												case 61:
																												case 75:
																													goto IL_0435;
																												case 30:
																													goto IL_0451;
																												case 5:
																												case 94:
																													goto IL_045f;
																												case 38:
																													goto IL_046d;
																												case 14:
																												case 74:
																													goto IL_0478;
																												case 15:
																													goto IL_04b8;
																												case 51:
																													goto IL_04cc;
																												case 53:
																													goto IL_04ed;
																												case 29:
																													goto IL_04fb;
																												case 9:
																												case 105:
																													goto IL_0509;
																												case 80:
																													goto IL_0535;
																												case 45:
																													goto IL_054c;
																												case 78:
																													goto IL_0563;
																												case 71:
																												case 104:
																													goto IL_0576;
																												case 35:
																													goto IL_05e1;
																												case 17:
																												case 21:
																												case 23:
																												case 34:
																												case 37:
																												case 40:
																												case 52:
																												case 55:
																												case 56:
																												case 58:
																												case 60:
																												case 67:
																												case 70:
																												case 87:
																												case 91:
																												case 95:
																												case 99:
																												case 102:
																												case 103:
																												case 106:
																													goto end_IL_01e5;
																												case 2:
																												case 8:
																												case 16:
																												case 22:
																												case 41:
																												case 48:
																												case 54:
																												case 59:
																												case 77:
																												case 82:
																												case 84:
																												case 85:
																												case 96:
																													goto end_IL_0268;
																												case 25:
																													goto end_IL_060d;
																												case 49:
																													goto end_IL_0620;
																												case 66:
																													goto end_IL_062a;
																												case 79:
																													goto end_IL_0635;
																												case 11:
																												case 100:
																													goto end_IL_064a;
																												case 89:
																													goto end_IL_065a;
																												case 18:
																												case 32:
																													goto end_IL_0673;
																												case 63:
																													goto end_IL_0683;
																												case 64:
																													goto end_IL_0693;
																												case 57:
																												case 88:
																													goto IL_06b7;
																												}
																												continue;
																											}
																											goto IL_0368;
																											IL_0368:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_0376;
																											IL_0376:
																											if (4 > b)
																											{
																												break;
																											}
																											goto end_IL_0268;
																											continue;
																											end_IL_01e5:
																											break;
																										}
																										break;
																									}
																									goto IL_0342;
																									IL_0342:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0350;
																									IL_0350:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_0268;
																								}
																								break;
																							}
																							goto IL_0273;
																							IL_0318:
																							num5++;
																							num = 69;
																							goto IL_032f;
																							IL_0273:
																							if (2 <= b)
																							{
																								goto IL_027e;
																							}
																							goto IL_02b7;
																							IL_027e:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_02a7;
																							IL_02a7:
																							ptr2 += 8;
																							goto IL_02de;
																							IL_02de:
																							num5--;
																							goto end_IL_0268;
																							IL_02b7:
																							if (1 < b)
																							{
																								break;
																							}
																							num = 76;
																							goto IL_02ce;
																							IL_032f:
																							ptr2 += 8;
																							goto end_IL_0268;
																							IL_02ce:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_02f1;
																							IL_02f1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_030a;
																							IL_030a:
																							array[num5] = 0;
																							goto IL_0318;
																						}
																						break;
																					}
																					goto IL_0389;
																					IL_03d2:
																					ptr2 += 8;
																					goto end_IL_0268;
																					IL_0389:
																					array[num5] = 0;
																					goto IL_0397;
																					IL_0397:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03ba;
																					IL_03ba:
																					array2[num5] = null;
																					goto IL_03c4;
																					IL_03c4:
																					num5++;
																					goto IL_03d2;
																				}
																				break;
																			}
																			goto IL_03e5;
																			IL_0563:
																			ptr2 += 8;
																			goto end_IL_0268;
																			IL_03e5:
																			if (8 < b)
																			{
																				goto IL_03f0;
																			}
																			goto IL_0451;
																			IL_03f0:
																			if (9 < b)
																			{
																				goto IL_03fb;
																			}
																			goto IL_0427;
																			IL_03fb:
																			if (10 < b)
																			{
																				num = 34;
																				break;
																			}
																			goto IL_0406;
																			IL_0406:
																			if (10 > b)
																			{
																			}
																			break;
																			IL_0576:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 35;
																			goto IL_05e1;
																			IL_0427:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0435;
																			IL_0435:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0268;
																			IL_0451:
																			if (8 > b)
																			{
																				goto IL_045f;
																			}
																			goto IL_0576;
																			IL_045f:
																			if (6 >= b)
																			{
																				goto IL_046d;
																			}
																			goto IL_04ed;
																			IL_046d:
																			if (6 > b)
																			{
																				num = 99;
																				break;
																			}
																			goto IL_0478;
																			IL_0478:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04b8;
																			IL_04b8:
																			array[num5 - 2] = 0;
																			goto IL_04cc;
																			IL_04cc:
																			num5--;
																			goto end_IL_0268;
																			IL_05e1:
																			num5 -= 2;
																			goto end_IL_0268;
																			IL_04ed:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_04fb;
																			IL_04fb:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0509;
																			IL_0509:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 80;
																			goto IL_0535;
																			IL_0535:
																			array[num5] = 0;
																			num = 45;
																			goto IL_054c;
																			IL_054c:
																			num5++;
																			num = 78;
																			goto IL_0563;
																		}
																		break;
																		IL_0238:;
																	}
																}
																else
																{
																	num = 17;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0268;
																continue;
																end_IL_0248:
																break;
															}
															continue;
															end_IL_0258:
															break;
														}
														continue;
														end_IL_0268:
														break;
													}
													continue;
												}
												num = 57;
												goto IL_06b7;
												IL_06b7:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_060d:
												break;
											}
											continue;
											end_IL_0620:
											break;
										}
										continue;
										end_IL_062a:
										break;
									}
									continue;
									end_IL_0635:
									break;
								}
								continue;
								end_IL_064a:
								break;
							}
							continue;
							end_IL_065a:
							break;
						}
						continue;
						end_IL_0673:
						break;
					}
					continue;
					end_IL_0683:
					break;
				}
				continue;
				end_IL_0693:
				break;
			}
		}
	}

	private static GorillaFriendCollider ITypeLibConverterGetMethodBody(GorillaComputer gorillaComputer_0)
	{
		return gorillaComputer_0.friendJoinCollider;
	}

	private static Material[] GREGORIANARABICVarpush(VRRig vrrig_0)
	{
		return vrrig_0.materialsToChangeTo;
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 85;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 84;
			while (true)
			{
				int num3 = num2 * 4;
				num = 11;
				while (true)
				{
					num = 46;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StackBuilderSinkIDispatchImplType.CreateComInstanceFromsetHandle);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0254:
															byte b = *ptr2;
															while (true)
															{
																IL_0244:
																ptr2++;
																while (true)
																{
																	IL_0234:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0214:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0207:
																						if (8 < b)
																						{
																							while (true)
																							{
																								IL_01f7:
																								if (9 >= b)
																								{
																									while (true)
																									{
																										IL_01e4:
																										if (9 > b)
																										{
																											num = 109;
																											while (num != 109)
																											{
																												if (num != 1090)
																												{
																													goto end_IL_0234;
																												}
																												switch (num)
																												{
																												case 55:
																													goto IL_01e4;
																												case 7:
																												case 19:
																													goto IL_01f7;
																												case 44:
																												case 52:
																													goto IL_0207;
																												case 92:
																													goto IL_0214;
																												case 40:
																													goto IL_0224;
																												case 12:
																													goto IL_0234;
																												case 28:
																													goto IL_0244;
																												case 2:
																												case 66:
																													goto IL_0254;
																												case 39:
																													goto IL_025f;
																												case 16:
																												case 80:
																													goto IL_026a;
																												case 13:
																													goto IL_02cc;
																												case 83:
																													goto IL_02df;
																												case 9:
																													goto IL_02ed;
																												case 10:
																												case 43:
																													goto IL_02fb;
																												case 32:
																													goto IL_0344;
																												case 30:
																													goto IL_0358;
																												case 88:
																												case 93:
																													goto IL_036b;
																												case 26:
																													goto IL_0379;
																												case 99:
																												case 102:
																													goto IL_038c;
																												case 76:
																													goto IL_039a;
																												case 0:
																												case 95:
																													goto IL_03a8;
																												case 96:
																													goto IL_03cb;
																												case 17:
																													goto IL_03d9;
																												case 27:
																													goto IL_03f0;
																												case 58:
																												case 69:
																													goto IL_0403;
																												case 89:
																													goto IL_041f;
																												case 86:
																													goto IL_042d;
																												case 18:
																													goto IL_043b;
																												case 31:
																												case 34:
																													goto IL_0446;
																												case 15:
																													goto IL_046f;
																												case 91:
																													goto IL_047d;
																												case 36:
																													goto IL_0490;
																												case 60:
																													goto IL_04a7;
																												case 54:
																												case 62:
																													goto IL_04be;
																												case 98:
																													goto IL_04d7;
																												case 68:
																													goto IL_04e5;
																												case 41:
																													goto IL_04f3;
																												case 71:
																													goto IL_0506;
																												case 49:
																													goto IL_0511;
																												case 6:
																												case 51:
																													goto IL_051c;
																												case 59:
																													goto IL_0534;
																												case 74:
																													goto IL_0548;
																												case 22:
																												case 25:
																												case 29:
																												case 38:
																												case 47:
																												case 50:
																												case 53:
																												case 65:
																												case 77:
																												case 79:
																												case 81:
																												case 82:
																												case 87:
																												case 90:
																												case 97:
																												case 100:
																												case 101:
																													goto end_IL_01d1;
																												case 35:
																												case 70:
																													goto IL_057d;
																												case 33:
																													goto IL_058b;
																												case 8:
																													goto IL_05b7;
																												case 63:
																													goto IL_05ca;
																												case 23:
																													goto IL_05d8;
																												case 1:
																												case 3:
																												case 4:
																												case 5:
																												case 14:
																												case 20:
																												case 24:
																												case 45:
																												case 56:
																												case 57:
																												case 64:
																												case 72:
																												case 73:
																													goto end_IL_0234;
																												case 67:
																													goto end_IL_05e6;
																												case 61:
																													goto end_IL_05f9;
																												case 75:
																													goto end_IL_0603;
																												case 94:
																													goto end_IL_060e;
																												case 37:
																												case 42:
																													goto end_IL_0623;
																												case 78:
																													goto end_IL_0633;
																												case 46:
																													goto end_IL_0643;
																												case 11:
																													goto end_IL_0653;
																												case 84:
																													goto end_IL_0663;
																												case 85:
																													goto end_IL_066e;
																												case 21:
																												case 48:
																													goto IL_069b;
																												}
																												continue;
																												end_IL_01d1:
																												break;
																											}
																											break;
																										}
																										goto IL_0403;
																										IL_0403:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										goto end_IL_0234;
																									}
																									break;
																								}
																								goto IL_036b;
																								IL_0379:
																								if (10 > b)
																								{
																								}
																								break;
																								IL_036b:
																								if (10 < b)
																								{
																									break;
																								}
																								goto IL_0379;
																							}
																							break;
																						}
																						goto IL_025f;
																						IL_03f0:
																						ptr2 += 8;
																						goto end_IL_0234;
																						IL_025f:
																						if (8 <= b)
																						{
																							goto IL_026a;
																						}
																						goto IL_02df;
																						IL_026a:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_02cc;
																						IL_02cc:
																						num6 -= 2;
																						goto end_IL_0234;
																						IL_02df:
																						if (6 >= b)
																						{
																							goto IL_02ed;
																						}
																						goto IL_038c;
																						IL_02ed:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_02fb;
																						IL_02fb:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						num = 32;
																						goto IL_0344;
																						IL_0344:
																						array[num6 - 2] = 0;
																						goto IL_0358;
																						IL_0358:
																						num6--;
																						goto end_IL_0234;
																						IL_038c:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_039a;
																						IL_039a:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_03a8;
																						IL_03a8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03cb;
																						IL_03cb:
																						array[num6] = 0;
																						goto IL_03d9;
																						IL_03d9:
																						num6++;
																						num = 27;
																						goto IL_03f0;
																					}
																					break;
																				}
																				goto IL_041f;
																				IL_057d:
																				array[num6] = 0;
																				goto IL_058b;
																				IL_041f:
																				if (5 > b)
																				{
																					goto IL_042d;
																				}
																				num = 70;
																				goto IL_057d;
																				IL_042d:
																				if (2 >= b)
																				{
																					goto IL_043b;
																				}
																				goto IL_0506;
																				IL_043b:
																				if (2 <= b)
																				{
																					goto IL_0446;
																				}
																				goto IL_0490;
																				IL_0446:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_046f;
																				IL_046f:
																				ptr2 += 8;
																				goto IL_047d;
																				IL_047d:
																				num6--;
																				goto end_IL_0234;
																				IL_0490:
																				if (1 < b)
																				{
																					break;
																				}
																				num = 60;
																				goto IL_04a7;
																				IL_05b7:
																				array2[num6] = null;
																				num = 63;
																				goto IL_05ca;
																				IL_04a7:
																				if (1 > b)
																				{
																					break;
																				}
																				num = 54;
																				goto IL_04be;
																				IL_05ca:
																				num6++;
																				goto IL_05d8;
																				IL_04be:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_04d7;
																				IL_04d7:
																				array[num6] = 0;
																				goto IL_04e5;
																				IL_04e5:
																				num6++;
																				goto IL_04f3;
																				IL_04f3:
																				ptr2 += 8;
																				goto end_IL_0234;
																				IL_0506:
																				if (3 >= b)
																				{
																					goto IL_0511;
																				}
																				goto IL_0534;
																				IL_0511:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_051c;
																				IL_051c:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0234;
																				IL_0534:
																				if (4 < b)
																				{
																					break;
																				}
																				num = 74;
																				goto IL_0548;
																				IL_05d8:
																				ptr2 += 8;
																				goto end_IL_0234;
																				IL_0548:
																				if (4 <= b)
																				{
																					goto end_IL_0234;
																				}
																				break;
																				IL_058b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				num = 8;
																				goto IL_05b7;
																			}
																			break;
																			IL_0224:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 20;
																	break;
																	continue;
																	end_IL_0234:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_069b;
													IL_069b:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_05e6:
													break;
												}
												continue;
												end_IL_05f9:
												break;
											}
											continue;
											end_IL_0603:
											break;
										}
										continue;
										end_IL_060e:
										break;
									}
									continue;
									end_IL_0623:
									break;
								}
								continue;
								end_IL_0633:
								break;
							}
							continue;
							end_IL_0643:
							break;
						}
						continue;
						end_IL_0653:
						break;
					}
					continue;
					end_IL_0663:
					break;
				}
				continue;
				end_IL_066e:
				break;
			}
		}
	}

	private static Material getIsStoppedNil(GorillaComputer gorillaComputer_0)
	{
		return gorillaComputer_0.pressedMaterial;
	}

	private static double IUnrestrictedIsMulticast(double double_0)
	{
		return Math.Floor(double_0);
	}

	private static float LibraryAssemblyRequestEntryFieldId(Class198 class198_1)
	{
		return class198_1.float_1;
	}

	private static Player setLicenseFileMutexIndex()
	{
		return PhotonNetwork.LocalPlayer;
	}

	private static double fAnonymousTypeTimerQueueTimer(double double_0)
	{
		return Math.Truncate(double_0);
	}

	private static int InvocationListReadObjectInfo(double double_0)
	{
		return Convert.ToInt32(double_0);
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 38;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 22;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									num = 4;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetPathRootSleep.SubjectDeny);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 96;
												while (true)
												{
													if (num != 96)
													{
														if (num != 1077)
														{
															goto IL_037d;
														}
														switch (num)
														{
														case 73:
															goto end_IL_018f;
														case 68:
															goto end_IL_01a2;
														case 4:
															goto end_IL_01b5;
														case 86:
															goto end_IL_01c0;
														case 15:
															goto end_IL_01d5;
														case 35:
														case 74:
															goto end_IL_01f3;
														case 29:
															goto end_IL_0203;
														case 22:
														case 41:
															goto end_IL_0213;
														case 37:
															goto end_IL_0223;
														case 38:
															goto end_IL_0233;
														case 0:
														case 5:
														case 7:
														case 23:
														case 42:
														case 63:
														case 65:
														case 66:
														case 75:
														case 77:
															goto IL_0260;
														case 8:
														case 21:
															goto IL_0270;
														case 87:
															goto IL_0279;
														case 2:
															goto IL_0287;
														case 25:
															goto IL_0295;
														case 45:
															goto IL_02a3;
														case 10:
															goto IL_02b1;
														case 20:
														case 52:
															goto IL_02bf;
														case 47:
															goto IL_02cd;
														case 55:
														case 82:
															goto IL_02db;
														case 16:
															goto IL_0349;
														case 88:
															goto IL_035c;
														case 13:
															goto IL_036a;
														case 51:
														case 81:
															goto IL_037d;
														case 9:
															goto IL_038b;
														case 64:
														case 79:
															goto IL_03a2;
														case 43:
															goto IL_03e2;
														case 89:
															goto IL_03ff;
														case 12:
														case 60:
															goto IL_0412;
														case 34:
															goto IL_043b;
														case 69:
															goto IL_0449;
														case 61:
															goto IL_045c;
														case 24:
															goto IL_046a;
														case 71:
															goto IL_0475;
														case 19:
														case 49:
															goto IL_0483;
														case 44:
															goto IL_0491;
														case 67:
															goto IL_04b4;
														case 1:
															goto IL_04be;
														case 83:
															goto IL_04cc;
														case 84:
															goto IL_04df;
														case 28:
															goto IL_04ed;
														case 11:
														case 76:
															goto IL_04fb;
														case 3:
															goto IL_0517;
														case 26:
														case 72:
															goto IL_0525;
														case 54:
															goto IL_0530;
														case 17:
														case 78:
															goto IL_053b;
														case 30:
															goto IL_0553;
														case 70:
															goto IL_0561;
														case 31:
															goto IL_056f;
														case 6:
														case 14:
														case 18:
														case 32:
														case 33:
														case 36:
														case 39:
														case 40:
														case 46:
														case 48:
														case 50:
														case 53:
														case 57:
														case 58:
														case 59:
														case 62:
														case 80:
														case 85:
															goto IL_0582;
														case 27:
														case 56:
															goto IL_05a7;
														}
														continue;
													}
													num = 63;
													goto IL_0260;
													IL_0582:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0553;
													IL_0561:
													num4++;
													goto IL_056f;
													IL_0553:
													array[num4] = 0;
													goto IL_0561;
													IL_0260:
													if (num5 != 1)
													{
														goto IL_0270;
													}
													goto IL_05a7;
													IL_05a7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_0270:
													b = *ptr2;
													goto IL_0279;
													IL_0279:
													ptr2++;
													goto IL_0287;
													IL_0287:
													if (b >= 1)
													{
														goto IL_0295;
													}
													goto IL_0582;
													IL_0295:
													if (b <= 8)
													{
														goto IL_02a3;
													}
													goto IL_0582;
													IL_02a3:
													if (4 >= b)
													{
														goto IL_02b1;
													}
													goto IL_045c;
													IL_02b1:
													if (4 > b)
													{
														goto IL_02bf;
													}
													goto IL_0412;
													IL_02bf:
													if (2 >= b)
													{
														goto IL_02cd;
													}
													goto IL_037d;
													IL_02cd:
													if (2 <= b)
													{
														goto IL_02db;
													}
													goto IL_035c;
													IL_02db:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													goto IL_0349;
													IL_0349:
													num4 -= 2;
													goto IL_0260;
													IL_035c:
													if (1 >= b)
													{
														goto IL_036a;
													}
													goto IL_0582;
													IL_036a:
													if (1 <= b)
													{
													}
													goto IL_0582;
													IL_037d:
													if (3 >= b)
													{
														goto IL_038b;
													}
													goto IL_0582;
													IL_038b:
													if (3 <= b)
													{
														num = 79;
														goto IL_03a2;
													}
													goto IL_0582;
													IL_056f:
													ptr2 += 8;
													goto IL_0260;
													IL_03a2:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_03e2;
													IL_03e2:
													array[num4 - 2] = 0;
													num = 89;
													goto IL_03ff;
													IL_03ff:
													num4--;
													goto IL_0260;
													IL_0412:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_043b;
													IL_043b:
													ptr2 += 8;
													goto IL_0449;
													IL_0449:
													num4--;
													goto IL_0260;
													IL_045c:
													if (6 < b)
													{
														goto IL_046a;
													}
													goto IL_0517;
													IL_046a:
													if (7 >= b)
													{
														goto IL_0475;
													}
													goto IL_04df;
													IL_0475:
													if (7 <= b)
													{
														goto IL_0483;
													}
													goto IL_0582;
													IL_0483:
													array[num4] = 0;
													goto IL_0491;
													IL_0491:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_04b4;
													IL_04b4:
													array2[num4] = null;
													goto IL_04be;
													IL_04be:
													num4++;
													goto IL_04cc;
													IL_04cc:
													ptr2 += 8;
													goto IL_0260;
													IL_04df:
													if (8 >= b)
													{
														goto IL_04ed;
													}
													goto IL_0582;
													IL_04ed:
													if (8 <= b)
													{
														goto IL_04fb;
													}
													goto IL_0582;
													IL_04fb:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_0260;
													IL_0517:
													if (6 <= b)
													{
														goto IL_0260;
													}
													goto IL_0525;
													IL_0525:
													if (5 >= b)
													{
														goto IL_0530;
													}
													goto IL_0582;
													IL_0530:
													if (5 <= b)
													{
														goto IL_053b;
													}
													goto IL_0582;
													IL_053b:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0260;
													continue;
													end_IL_018f:
													break;
												}
												continue;
												end_IL_01a2:
												break;
											}
											continue;
											end_IL_01b5:
											break;
										}
										continue;
										end_IL_01c0:
										break;
									}
									continue;
									end_IL_01d5:
									break;
								}
								continue;
								end_IL_01f3:
								break;
							}
							continue;
							end_IL_0203:
							break;
						}
						continue;
						end_IL_0213:
						break;
					}
					continue;
					end_IL_0223:
					break;
				}
				continue;
				end_IL_0233:
				break;
			}
		}
	}

	private static double ContractPublicPropertyNameAttributeDeleteTimer(double double_0)
	{
		return Math.Abs(double_0);
	}

	private static Player GetDynamicILInfosetSafeWaitHandle()
	{
		return PhotonNetwork.LocalPlayer;
	}

	private static GorillaFriendCollider.TouchingPlayerInfo TupleExtensionsCloseNamespace(string string_0)
	{
		return string_0;
	}

	private unsafe static int smethod_5(int int_2)
	{
		int num = 71;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 29;
				while (true)
				{
					num = 103;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeLibExporterFlagsSecurityContextSwitcher.PrivateScopeSTOREASSEMBLY);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0240:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0220:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0210:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_0200:
																								if (8 <= b)
																								{
																									num = 116;
																									while (true)
																									{
																										if (num != 116)
																										{
																											if (num != 1097)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 72:
																												goto IL_0200;
																											case 25:
																											case 46:
																												goto IL_0210;
																											case 73:
																												goto IL_0220;
																											case 2:
																												goto IL_0230;
																											case 0:
																												goto IL_0240;
																											case 64:
																												goto end_IL_0240;
																											case 53:
																											case 75:
																												goto end_IL_0250;
																											case 40:
																												goto IL_026b;
																											case 56:
																												goto IL_0276;
																											case 21:
																											case 93:
																												goto IL_0286;
																											case 68:
																												goto IL_0294;
																											case 23:
																											case 95:
																												goto IL_02a2;
																											case 5:
																												goto IL_02c5;
																											case 31:
																												goto IL_02d3;
																											case 101:
																												goto IL_02e1;
																											case 91:
																											case 109:
																												goto IL_02f4;
																											case 44:
																												goto IL_0334;
																											case 76:
																												goto IL_0348;
																											case 57:
																												goto IL_035b;
																											case 49:
																												goto IL_03bd;
																											case 16:
																											case 90:
																												goto IL_03d0;
																											case 42:
																											case 79:
																												goto IL_03db;
																											case 30:
																												goto IL_03e9;
																											case 63:
																												goto IL_03fc;
																											case 98:
																											case 108:
																												goto IL_040a;
																											case 11:
																												goto IL_0426;
																											case 15:
																											case 52:
																												goto IL_0434;
																											case 14:
																											case 88:
																												goto IL_043f;
																											case 22:
																											case 61:
																												goto IL_044a;
																											case 89:
																												goto IL_0458;
																											case 102:
																												goto IL_046b;
																											case 27:
																											case 41:
																												goto IL_0476;
																											case 7:
																												goto IL_049c;
																											case 10:
																											case 32:
																												goto IL_04a7;
																											case 45:
																												goto IL_04d0;
																											case 28:
																												goto IL_04de;
																											case 51:
																											case 83:
																												goto IL_04f1;
																											case 13:
																												goto IL_04ff;
																											case 55:
																											case 67:
																												goto IL_050d;
																											case 80:
																												goto IL_0526;
																											case 62:
																												goto IL_0534;
																											case 97:
																												goto IL_0542;
																											case 19:
																											case 59:
																												goto IL_0552;
																											case 87:
																												goto IL_0560;
																											case 18:
																												goto IL_0583;
																											case 20:
																												goto IL_058d;
																											case 74:
																												goto IL_059b;
																											case 4:
																											case 6:
																											case 26:
																											case 33:
																											case 35:
																											case 36:
																											case 37:
																											case 50:
																											case 58:
																											case 60:
																											case 65:
																											case 66:
																											case 69:
																											case 77:
																											case 81:
																											case 85:
																											case 86:
																											case 92:
																											case 94:
																											case 99:
																											case 106:
																												goto end_IL_01ed;
																											case 1:
																											case 3:
																											case 8:
																											case 38:
																											case 39:
																											case 43:
																											case 48:
																											case 54:
																											case 78:
																											case 84:
																											case 96:
																											case 100:
																											case 104:
																												goto end_IL_0260;
																											case 12:
																												goto end_IL_05be;
																											case 82:
																												goto end_IL_05d1;
																											case 105:
																												goto end_IL_05db;
																											case 9:
																												goto end_IL_05e6;
																											case 17:
																											case 47:
																												goto end_IL_05fb;
																											case 24:
																												goto end_IL_060b;
																											case 103:
																												goto end_IL_061b;
																											case 29:
																												goto end_IL_062b;
																											case 70:
																												goto end_IL_063b;
																											case 71:
																												goto end_IL_0646;
																											case 34:
																											case 107:
																												goto IL_066a;
																											}
																											continue;
																										}
																										goto IL_035b;
																										IL_035b:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_03bd;
																										IL_03bd:
																										num5 -= 2;
																										goto end_IL_0260;
																										continue;
																										end_IL_01ed:
																										break;
																									}
																									break;
																								}
																								goto IL_026b;
																								IL_02d3:
																								num5++;
																								goto IL_02e1;
																								IL_02e1:
																								ptr2 += 8;
																								goto end_IL_0260;
																								IL_026b:
																								if (6 >= b)
																								{
																									goto IL_0276;
																								}
																								goto IL_0286;
																								IL_0276:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_02f4;
																								IL_02f4:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0334;
																								IL_0334:
																								array[num5 - 2] = 0;
																								goto IL_0348;
																								IL_0348:
																								num5--;
																								goto end_IL_0260;
																								IL_0286:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_0294;
																								IL_0294:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_02a2;
																								IL_02a2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_02c5;
																								IL_02c5:
																								array[num5] = 0;
																								goto IL_02d3;
																							}
																							break;
																						}
																						goto IL_03d0;
																						IL_040a:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0260;
																						IL_03d0:
																						if (9 < b)
																						{
																							goto IL_03db;
																						}
																						goto IL_03fc;
																						IL_03db:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_03e9;
																						IL_03e9:
																						if (10 <= b)
																						{
																						}
																						break;
																						IL_03fc:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_040a;
																					}
																					break;
																				}
																				goto IL_0426;
																				IL_058d:
																				num5++;
																				goto IL_059b;
																				IL_0426:
																				if (5 > b)
																				{
																					goto IL_0434;
																				}
																				goto IL_0552;
																				IL_0434:
																				if (2 < b)
																				{
																					goto IL_043f;
																				}
																				goto IL_049c;
																				IL_043f:
																				if (3 < b)
																				{
																					goto IL_044a;
																				}
																				goto IL_046b;
																				IL_044a:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0458;
																				IL_0458:
																				if (4 > b)
																				{
																					break;
																				}
																				goto end_IL_0260;
																				IL_046b:
																				if (3 > b)
																				{
																					num = 33;
																					break;
																				}
																				goto IL_0476;
																				IL_0476:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0260;
																				IL_059b:
																				ptr2 += 8;
																				goto end_IL_0260;
																				IL_049c:
																				if (2 <= b)
																				{
																					goto IL_04a7;
																				}
																				goto IL_04f1;
																				IL_04a7:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04d0;
																				IL_04d0:
																				ptr2 += 8;
																				goto IL_04de;
																				IL_04de:
																				num5--;
																				goto end_IL_0260;
																				IL_04f1:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_04ff;
																				IL_04ff:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_050d;
																				IL_050d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0526;
																				IL_0526:
																				array[num5] = 0;
																				goto IL_0534;
																				IL_0534:
																				num5++;
																				goto IL_0542;
																				IL_0542:
																				ptr2 += 8;
																				goto end_IL_0260;
																				IL_0552:
																				array[num5] = 0;
																				goto IL_0560;
																				IL_0560:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0583;
																				IL_0583:
																				array2[num5] = null;
																				goto IL_058d;
																			}
																			break;
																			IL_0230:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0260;
																	continue;
																	end_IL_0240:
																	break;
																}
																continue;
																end_IL_0250:
																break;
															}
															continue;
															end_IL_0260:
															break;
														}
														continue;
													}
													goto IL_066a;
													IL_066a:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05be:
													break;
												}
												continue;
												end_IL_05d1:
												break;
											}
											continue;
											end_IL_05db:
											break;
										}
										continue;
										end_IL_05e6:
										break;
									}
									continue;
									end_IL_05fb:
									break;
								}
								continue;
								end_IL_060b:
								break;
							}
							continue;
							end_IL_061b:
							break;
						}
						continue;
						end_IL_062b:
						break;
					}
					continue;
					end_IL_063b:
					break;
				}
				continue;
				end_IL_0646:
				break;
			}
		}
	}

	private static string TokenRestrictedSidsIsSignature(string[] string_0)
	{
		return string.Concat(string_0);
	}

	private unsafe void Update()
	{
		int num = 7;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		string text22 = default(string);
		string text23 = default(string);
		string text24 = default(string);
		string text25 = default(string);
		string text26 = default(string);
		int num11 = default(int);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				IL_004e:
				int num3 = 0;
				num = 14;
				while (true)
				{
					if (num != 14)
					{
						if (num != 995)
						{
							break;
						}
						switch (num)
						{
						case 6:
							goto IL_004e;
						case 7:
							goto end_IL_0041;
						case 4:
							goto IL_0066;
						case 1:
						case 2:
							goto IL_00be;
						case 3:
							goto IL_00c4;
						case 0:
						case 5:
							return;
						}
						continue;
					}
					num3 = 0;
					goto IL_00be;
					IL_00be:
					if (num3 != 64)
					{
						goto IL_0066;
					}
					goto IL_00c4;
					IL_0066:
					((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref int, Class198, void>)getCategoryEventInfo[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref text24, ref text25, ref text26, ref num11, this);
					goto IL_00be;
					IL_00c4:
					num3 = 0;
					return;
					continue;
					end_IL_0041:
					break;
				}
				break;
			}
		}
	}

	private static Room ReadToEndAsyncdContract()
	{
		return PhotonNetwork.CurrentRoom;
	}

	private static NetworkView SetHashAlgorithmContextInline(GorillaTagger gorillaTagger_0)
	{
		return gorillaTagger_0.myVRRig;
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetPEKindOnSerializingAttribute.TaskSchedulerAwaitTaskContinuationAssemblyNameProxy);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0333:
																	if (b >= 1)
																	{
																		goto IL_01de;
																	}
																	goto IL_0302;
																	IL_0302:
																	while (true)
																	{
																		IL_0302_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 111;
																		while (true)
																		{
																			if (num != 111)
																			{
																				if (num != 1092)
																				{
																					break;
																				}
																				switch (num)
																				{
																				case 71:
																					goto IL_01de;
																				case 79:
																					goto IL_01ec;
																				case 72:
																					goto IL_01f7;
																				case 73:
																				case 80:
																					goto IL_020a;
																				case 13:
																					goto IL_0215;
																				case 28:
																					goto IL_0223;
																				case 44:
																					goto IL_0231;
																				case 10:
																					goto IL_0244;
																				case 58:
																				case 70:
																					goto IL_0258;
																				case 33:
																					goto IL_026f;
																				case 63:
																					goto IL_0282;
																				case 7:
																				case 96:
																					goto IL_0292;
																				case 90:
																					goto IL_029d;
																				case 14:
																					goto IL_02ad;
																				case 94:
																					goto IL_02b8;
																				case 89:
																					goto IL_02c8;
																				case 2:
																					goto IL_02d3;
																				case 20:
																				case 104:
																					goto IL_02e3;
																				case 22:
																					goto IL_02ee;
																				case 0:
																				case 3:
																				case 5:
																				case 11:
																				case 12:
																				case 15:
																				case 25:
																				case 35:
																				case 37:
																				case 39:
																				case 41:
																				case 48:
																				case 49:
																				case 50:
																				case 77:
																				case 84:
																				case 86:
																				case 97:
																					goto IL_0302_2;
																				case 102:
																					goto IL_0333;
																				case 32:
																					goto end_IL_0333;
																				case 17:
																				case 82:
																					goto end_IL_0343;
																				case 74:
																				case 76:
																					goto IL_035e;
																				case 23:
																				case 31:
																					goto IL_037a;
																				case 62:
																					goto IL_0393;
																				case 6:
																				case 68:
																					goto IL_03af;
																				case 54:
																					goto IL_03ef;
																				case 45:
																					goto IL_0403;
																				case 18:
																				case 81:
																					goto IL_0416;
																				case 42:
																					goto IL_0456;
																				case 83:
																					goto IL_046c;
																				case 85:
																					goto IL_048f;
																				case 16:
																					goto IL_0499;
																				case 9:
																					goto IL_04a7;
																				case 87:
																					goto IL_04ba;
																				case 91:
																					goto end_IL_01cb;
																				case 1:
																				case 51:
																					goto IL_04e0;
																				case 40:
																					goto IL_0520;
																				case 24:
																					goto IL_0534;
																				case 47:
																				case 52:
																					goto IL_0547;
																				case 61:
																				case 75:
																					goto IL_057e;
																				case 30:
																					goto IL_05be;
																				case 34:
																					goto IL_05d2;
																				case 98:
																				case 99:
																					goto IL_05e2;
																				case 101:
																					goto IL_0604;
																				case 103:
																					goto IL_0614;
																				case 60:
																					goto IL_0622;
																				case 26:
																					goto IL_0640;
																				case 59:
																					goto IL_064e;
																				case 4:
																				case 8:
																				case 19:
																				case 36:
																				case 38:
																				case 43:
																				case 55:
																				case 69:
																				case 78:
																				case 88:
																				case 92:
																					goto end_IL_0353;
																				case 64:
																					goto end_IL_065c;
																				case 57:
																					goto end_IL_066f;
																				case 93:
																					goto end_IL_0679;
																				case 56:
																					goto end_IL_0684;
																				case 46:
																					goto end_IL_0699;
																				case 27:
																				case 67:
																					goto end_IL_06ae;
																				case 29:
																					goto end_IL_06be;
																				case 21:
																				case 100:
																					goto end_IL_06ce;
																				case 65:
																					goto end_IL_06de;
																				case 66:
																					goto end_IL_06ee;
																				case 53:
																				case 95:
																					goto IL_0709;
																				}
																				continue;
																			}
																			array[num5] = 0;
																			goto IL_0640;
																			IL_0640:
																			num5++;
																			goto IL_064e;
																			IL_064e:
																			ptr2 += 8;
																			goto end_IL_0353;
																			continue;
																			end_IL_01cb:
																			break;
																		}
																		break;
																	}
																	goto IL_04cd;
																	IL_01de:
																	if (b <= 9)
																	{
																		goto IL_01ec;
																	}
																	goto IL_0302;
																	IL_01ec:
																	if (5 >= b)
																	{
																		goto IL_01f7;
																	}
																	goto IL_020a;
																	IL_01f7:
																	if (5 > b)
																	{
																		goto IL_0292;
																	}
																	goto IL_035e;
																	IL_0292:
																	if (2 >= b)
																	{
																		goto IL_029d;
																	}
																	goto IL_02ad;
																	IL_029d:
																	if (2 > b)
																	{
																		goto IL_02e3;
																	}
																	goto IL_04e0;
																	IL_04e0:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0520;
																	IL_0520:
																	array[num5 - 2] = 0;
																	goto IL_0534;
																	IL_0534:
																	num5--;
																	goto end_IL_0353;
																	IL_02e3:
																	if (1 >= b)
																	{
																		goto IL_02ee;
																	}
																	goto IL_0302;
																	IL_02ee:
																	if (1 > b)
																	{
																		num = 37;
																	}
																	goto IL_0302;
																	IL_0282:
																	if (8 > b)
																	{
																		goto IL_0302;
																	}
																	num = 6;
																	goto IL_03af;
																	IL_02ad:
																	if (3 >= b)
																	{
																		goto IL_02b8;
																	}
																	goto IL_02c8;
																	IL_02b8:
																	if (3 > b)
																	{
																		goto IL_0302;
																	}
																	goto IL_0547;
																	IL_0547:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0614;
																	IL_0614:
																	ptr2 += 8;
																	goto IL_0622;
																	IL_0622:
																	num5--;
																	goto end_IL_0353;
																	IL_02c8:
																	if (4 >= b)
																	{
																		goto IL_02d3;
																	}
																	goto IL_0302;
																	IL_02d3:
																	if (4 > b)
																	{
																		goto IL_0302;
																	}
																	num = 75;
																	goto IL_057e;
																	IL_0403:
																	num5--;
																	goto end_IL_0353;
																	IL_057e:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_05be;
																	IL_05be:
																	array[num5 - 2] = 0;
																	goto IL_05d2;
																	IL_05d2:
																	num5--;
																	goto end_IL_0353;
																	IL_035e:
																	array[num5] = 0;
																	num = 83;
																	goto IL_046c;
																	IL_046c:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_048f;
																	IL_048f:
																	array2[num5] = null;
																	goto IL_0499;
																	IL_0499:
																	num5++;
																	goto IL_04a7;
																	IL_04a7:
																	ptr2 += 8;
																	goto end_IL_0353;
																	IL_020a:
																	if (7 >= b)
																	{
																		goto IL_0215;
																	}
																	goto IL_0244;
																	IL_0215:
																	if (7 > b)
																	{
																		goto IL_0223;
																	}
																	goto IL_037a;
																	IL_0223:
																	if (6 >= b)
																	{
																		goto IL_0231;
																	}
																	goto IL_0302;
																	IL_0231:
																	if (6 > b)
																	{
																		goto IL_0302;
																	}
																	goto IL_0416;
																	IL_0416:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0456;
																	IL_0456:
																	array[num5 - 2] = 0;
																	goto IL_04cd;
																	IL_04cd:
																	num5--;
																	goto end_IL_0353;
																	IL_037a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0393;
																	IL_0393:
																	array[num5] = 0;
																	goto IL_04ba;
																	IL_04ba:
																	num5++;
																	goto IL_0604;
																	IL_0604:
																	ptr2 += 8;
																	goto end_IL_0353;
																	IL_0244:
																	if (8 < b)
																	{
																		num = 58;
																		goto IL_0258;
																	}
																	goto IL_0282;
																	IL_03af:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_03ef;
																	IL_0258:
																	if (9 >= b)
																	{
																		num = 33;
																		goto IL_026f;
																	}
																	goto IL_0302;
																	IL_03ef:
																	array[num5 - 2] = 0;
																	goto IL_0403;
																	IL_026f:
																	if (9 > b)
																	{
																		goto IL_0302;
																	}
																	goto IL_05e2;
																	IL_05e2:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	num = 88;
																	goto end_IL_0353;
																	continue;
																	end_IL_0333:
																	break;
																}
																continue;
																end_IL_0343:
																break;
															}
															continue;
															end_IL_0353:
															break;
														}
														continue;
													}
													goto IL_0709;
													IL_0709:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_065c:
													break;
												}
												continue;
												end_IL_066f:
												break;
											}
											continue;
											end_IL_0679:
											break;
										}
										continue;
										end_IL_0684:
										break;
									}
									continue;
									end_IL_0699:
									break;
								}
								continue;
								end_IL_06ae:
								break;
							}
							continue;
							end_IL_06be:
							break;
						}
						continue;
						end_IL_06ce:
						break;
					}
					continue;
					end_IL_06de:
					break;
				}
				continue;
				end_IL_06ee:
				break;
			}
		}
	}

	private static double MetadataSectiondefaultPermissionSetIDComputeHash(double double_0)
	{
		return Math.Log(double_0);
	}

	private static double getParamTypesIntTypeInfo(double double_0)
	{
		return Math.Sqrt(double_0);
	}

	private static bool TextToDefinitiongetGroup(PhotonView photonView_0, string string_0, RpcTarget rpcTarget_0, object[] object_0)
	{
		return photonView_0.smethod_3(string_0, rpcTarget_0, object_0);
	}

	private static Color SafeArraySubTypeSetCurrentDirectory()
	{
		return global::_003CModule_003E.color_17;
	}

	private static float getExceptionObjectSECURITYIMPERSONATIONLEVEL(Color color_0)
	{
		return color_0.r;
	}

	private static Color WriteObjectInfogetIsCompliant(float float_4, float float_5, float float_6)
	{
		return Color.HSVToRGB(float_4, float_5, float_6);
	}

	private static List<GorillaFriendCollider.TouchingPlayerInfo> opModulusTraceSynchronousWorkEnd(GorillaFriendCollider gorillaFriendCollider_0)
	{
		return gorillaFriendCollider_0.playerIDsCurrentlyTouching;
	}

	private static float IllogicalCallContextgetRandomlyGenerated()
	{
		return Time.time;
	}

	private static float ProtectedResourcesGetAppId(Class198 class198_1)
	{
		return class198_1.float_0;
	}

	private static void InheritanceFlagsMemoryBarrier()
	{
		Class9.smethod_82();
	}

	public Class198()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static float DBCSDecoderHardwareDevice()
	{
		return Time.deltaTime;
	}

	private static int smethod_8(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		if (num <= num2)
		{
			num = int_3;
			num2 = int_2;
			return num - num2;
		}
		num = int_2;
		num2 = int_3;
		return num - num2;
	}

	private static int getIsLayoutSequentialMinimumLevel(double double_0)
	{
		return Convert.ToInt32(double_0);
	}

	private static float WorldSidAttlistDecl()
	{
		return Time.time;
	}

	private unsafe static int smethod_9(int int_2, int int_3)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getSignatureParamNames.CngAlgorithmIDgetfVersioned);
											num = 22;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 85;
															while (true)
															{
																ptr2++;
																num = 27;
																while (true)
																{
																	IL_01d1:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01b4:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_01a4:
																						if (4 <= b)
																						{
																							num = 93;
																							while (true)
																							{
																								if (num != 93)
																								{
																									if (num != 1074)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 54:
																										goto IL_01a4;
																									case 64:
																										goto IL_01b4;
																									case 34:
																										goto IL_01c1;
																									case 27:
																										goto IL_01d1;
																									case 85:
																										goto end_IL_01d1;
																									case 11:
																									case 69:
																										goto end_IL_01e1;
																									case 43:
																										goto IL_020e;
																									case 51:
																										goto IL_021e;
																									case 6:
																									case 49:
																										goto IL_0229;
																									case 15:
																										goto IL_023c;
																									case 61:
																										goto IL_024f;
																									case 57:
																										goto IL_025d;
																									case 20:
																									case 42:
																										goto IL_026b;
																									case 40:
																										goto IL_0279;
																									case 30:
																										goto IL_029c;
																									case 9:
																										goto IL_02a6;
																									case 35:
																										goto IL_02bd;
																									case 12:
																									case 63:
																										goto IL_02d0;
																									case 68:
																										goto IL_033e;
																									case 25:
																									case 71:
																										goto IL_0351;
																									case 2:
																										goto IL_035f;
																									case 73:
																										goto IL_0372;
																									case 24:
																									case 37:
																										goto IL_0380;
																									case 59:
																										goto IL_03c0;
																									case 23:
																										goto IL_03d4;
																									case 74:
																										goto IL_03e7;
																									case 45:
																									case 75:
																										goto IL_0400;
																									case 81:
																										goto IL_041c;
																									case 8:
																										goto IL_042a;
																									case 19:
																									case 60:
																										goto IL_0438;
																									case 83:
																										goto IL_0450;
																									case 77:
																										goto IL_045b;
																									case 3:
																										goto IL_0471;
																									case 50:
																										goto IL_049a;
																									case 29:
																										goto IL_04a8;
																									case 4:
																									case 5:
																									case 7:
																									case 13:
																									case 16:
																									case 26:
																									case 31:
																									case 41:
																									case 47:
																									case 62:
																									case 67:
																									case 76:
																									case 79:
																									case 80:
																									case 82:
																									case 86:
																										goto end_IL_0191;
																									case 44:
																										goto IL_04db;
																									case 48:
																										goto IL_04e9;
																									case 53:
																										goto IL_0500;
																									case 1:
																									case 18:
																									case 33:
																									case 36:
																									case 46:
																									case 56:
																									case 65:
																									case 66:
																									case 70:
																									case 72:
																									case 84:
																										goto end_IL_01fa;
																									case 22:
																										goto end_IL_050e;
																									case 28:
																										goto end_IL_0521;
																									case 55:
																										goto end_IL_052b;
																									case 52:
																										goto end_IL_053f;
																									case 78:
																										goto end_IL_0554;
																									case 0:
																									case 17:
																										goto end_IL_0569;
																									case 21:
																										goto end_IL_0579;
																									case 10:
																									case 58:
																										goto end_IL_0589;
																									case 38:
																										goto end_IL_0599;
																									case 39:
																										goto end_IL_05a9;
																									case 14:
																									case 32:
																										goto IL_05c4;
																									}
																									continue;
																								}
																								goto IL_0471;
																								IL_049a:
																								ptr2 += 8;
																								goto IL_04a8;
																								IL_04a8:
																								num5--;
																								goto end_IL_01fa;
																								IL_0471:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_049a;
																								continue;
																								end_IL_0191:
																								break;
																							}
																							break;
																						}
																						goto IL_021e;
																						IL_0450:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_045b;
																						IL_045b:
																						if (1 <= b)
																						{
																							num = 16;
																						}
																						break;
																						IL_021e:
																						if (2 < b)
																						{
																							goto IL_0229;
																						}
																						goto IL_023c;
																						IL_0229:
																						if (3 < b)
																						{
																							break;
																						}
																						goto IL_0372;
																						IL_0372:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_0380;
																						IL_0380:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03c0;
																						IL_03c0:
																						array[num5 - 2] = 0;
																						goto IL_03d4;
																						IL_03d4:
																						num5--;
																						goto end_IL_01fa;
																						IL_023c:
																						if (2 <= b)
																						{
																							goto IL_02d0;
																						}
																						goto IL_0450;
																						IL_02d0:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_033e;
																						IL_033e:
																						num5 -= 2;
																						goto end_IL_01fa;
																					}
																					break;
																				}
																				goto IL_020e;
																				IL_035f:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0400;
																				IL_020e:
																				if (6 < b)
																				{
																					goto IL_024f;
																				}
																				goto IL_03e7;
																				IL_03e7:
																				if (6 <= b)
																				{
																					num = 66;
																					goto end_IL_01fa;
																				}
																				goto IL_041c;
																				IL_0400:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_01fa;
																				IL_041c:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_042a;
																				IL_042a:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0438;
																				IL_0438:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_01fa;
																				IL_024f:
																				if (7 >= b)
																				{
																					goto IL_025d;
																				}
																				goto IL_0351;
																				IL_025d:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_026b;
																				IL_026b:
																				array[num5] = 0;
																				goto IL_0279;
																				IL_0279:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_029c;
																				IL_029c:
																				array2[num5] = null;
																				goto IL_02a6;
																				IL_02a6:
																				num5++;
																				num = 35;
																				goto IL_02bd;
																				IL_02bd:
																				ptr2 += 8;
																				goto end_IL_01fa;
																				IL_0351:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_035f;
																			}
																			break;
																			IL_01c1:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04db;
																	IL_0500:
																	ptr2 += 8;
																	goto end_IL_01fa;
																	IL_04e9:
																	num5++;
																	num = 53;
																	goto IL_0500;
																	IL_04db:
																	array[num5] = 0;
																	goto IL_04e9;
																	continue;
																	end_IL_01d1:
																	break;
																}
																continue;
																end_IL_01e1:
																break;
															}
															continue;
															end_IL_01fa:
															break;
														}
														continue;
													}
													goto IL_05c4;
													IL_05c4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_050e:
													break;
												}
												continue;
												end_IL_0521:
												break;
											}
											continue;
											end_IL_052b:
											break;
										}
										continue;
										end_IL_053f:
										break;
									}
									continue;
									end_IL_0554:
									break;
								}
								continue;
								end_IL_0569:
								break;
							}
							continue;
							end_IL_0579:
							break;
						}
						continue;
						end_IL_0589:
						break;
					}
					continue;
					end_IL_0599:
					break;
				}
				continue;
				end_IL_05a9:
				break;
			}
		}
	}

	private static bool IsEnteredgetFrameworkDisplayName(List<GorillaFriendCollider.TouchingPlayerInfo> list_0, GorillaFriendCollider.TouchingPlayerInfo touchingPlayerInfo_0)
	{
		return list_0.Contains(touchingPlayerInfo_0);
	}

	private static bool ChildProgID(UnityEngine.Object object_0, UnityEngine.Object object_1)
	{
		return object_0 != object_1;
	}

	private static float SynchronizeComponentCountLimit(Color color_0)
	{
		return color_0.b;
	}

	private static PhotonView INormalizeForIsolatedStoragePathInternal(NetworkView networkView_0)
	{
		return networkView_0.GetView;
	}

	private static bool INVOCATIONFLAGSUNKNOWNDisableComObjectEagerCleanup()
	{
		return PhotonNetwork.InRoom;
	}

	private static void TanhsetKeepAlive(string string_0, float float_4)
	{
		PlayerPrefs.SetFloat(string_0, float_4);
	}

	private static string DecimalForegroundBlue(Player player_0)
	{
		return player_0.UserId;
	}

	private static GorillaComputer BuiltinAdministratorsSidEncodedType()
	{
		return GorillaComputer.instance;
	}

	static Class198()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				num = 10;
				while (true)
				{
					if (num == 10 || num != 991)
					{
						return;
					}
					switch (num)
					{
					case 2:
						goto end_IL_0031;
					case 3:
						goto end_IL_003e;
					case 0:
						return;
					case 1:
						return;
					}
					continue;
					end_IL_0031:
					break;
				}
				continue;
				end_IL_003e:
				break;
			}
		}
	}
}
