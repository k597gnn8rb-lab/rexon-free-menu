using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Explicit, Pack = 1, Size = 28)]
internal struct addUnhandledExceptiongetSeconds
{
	internal static addUnhandledExceptiongetSeconds NativeMethodsgetToday/* Not supported: data(01 00 00 00 00 00 00 00 00 02 00 00 00 00 00 00 00 00 03 00 00 00 01 01 00 00 00 04) */;
}
