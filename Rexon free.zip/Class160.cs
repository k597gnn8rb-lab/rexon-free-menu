using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Anti Controller Disconnect", "Room", "Prevents controller disconnect detection.", false, 10, ModType.const_0, false)]
internal class Class160 : MonoBehaviour
{
	private FieldInfo fieldInfo_0;

	private FieldInfo fieldInfo_1;

	private static float float_0;

	private static float float_1;

	private static int int_0;

	private static bool bool_0;

	private static bool bool_1;

	private static double double_0;

	private static int int_1;

	private static IntPtr[] IPermissiondwHelpContext;

	private static IntPtr[] setCurrencyDecimalSeparatorContingentProperties;

	private static IntPtr[] TrackResurrectionFieldTypes;

	private static IntPtr[] SafeCspHandleToValueTuple;

	private unsafe void OnEnable()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0439, IL_044c, IL_0475, IL_048f, IL_049f, IL_04af, IL_04bf, IL_04cf, IL_04df, IL_04f2, IL_0502, IL_051b, IL_0526, IL_0531, IL_053c, IL_054a, IL_0575, IL_0583, IL_0591, IL_05af, IL_05bd, IL_05d0, IL_05e9, IL_05f4, IL_0602, IL_0610, IL_0624, IL_065c, IL_066f, IL_067a, IL_0688, IL_0696, IL_06a4, IL_06bc, IL_06ca, IL_06dd, IL_071b, IL_072e, IL_0752, IL_076a, IL_077d, IL_079e, IL_07ac, IL_07ba, IL_07d6, IL_07e4, IL_07ef, IL_07fd, IL_080b, IL_0827, IL_0832, IL_0840, IL_084e, IL_087b, IL_088e, IL_08bb, IL_08d7, IL_08e5, IL_08f3, IL_0901, IL_090f, IL_092c, IL_0964, IL_0980, IL_098e, IL_0997, IL_09aa, IL_09b8, IL_09cb, IL_09df, IL_0a40, IL_0a57, IL_0a6a, IL_0a78, IL_0a95, IL_0ae4, IL_0aee, IL_0b1b, IL_0b2f, IL_0b3d, IL_0b50, IL_0b59, IL_0b67, IL_0b75, IL_0b83, IL_0b91, IL_0b9f, IL_0bad, IL_0c0f, IL_0c22, IL_0c2b, IL_0c3f, IL_0c93, IL_0ca1, IL_0cb4, IL_0cc2, IL_0cd5, IL_0ce3, IL_0cee, IL_0cfc, IL_0d3c, IL_0d50, IL_0d63, IL_0d6c, IL_0d7a, IL_0d88, IL_0d9b, IL_0de4, IL_0df8, IL_0e0b, IL_0e19, IL_0e27, IL_0e35, IL_0e43, IL_0e51, IL_0e91, IL_0ea5, IL_0eb8, IL_0ec6, IL_0ed4, IL_0ef7, IL_0f01, IL_0f0f, IL_0f22, IL_0f2d, IL_0f5f, IL_0f6d, IL_0f80, IL_0f8e, IL_0f9c, IL_0faa, IL_0fea, IL_0ffe, IL_1011, IL_101a, IL_1027, IL_1067, IL_107b, IL_108b, IL_10a4, IL_10b2, IL_10c0, IL_10ce, IL_10e1, IL_10eb, IL_10f6, IL_1106, IL_1116, IL_1126, IL_1136, IL_1146, IL_1156, IL_1166, IL_1176 are reachable both inside and outside the pinned region starting at IL_118b. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 211;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num6;
			int num7;
			object[] array8;
			int num8;
			byte* num9;
			int __rxRef72 = default(int);
			ref int reference = ref __rxRef72;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1176:
					num2 = 1;
					while (true)
					{
						IL_1166:
						num3 = num2 * 4;
						while (true)
						{
							IL_1156:
							array2 = new byte[5];
							while (true)
							{
								IL_1146:
								array3 = new object[5];
								while (true)
								{
									IL_1136:
									array4 = new int[5];
									while (true)
									{
										IL_1126:
										array5 = new int[6];
										while (true)
										{
											IL_1116:
											array6 = new long[5];
											while (true)
											{
												array7 = new object[20];
												while (true)
												{
													IL_10f6:
													array7[0] = this;
													while (true)
													{
														IL_10eb:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EmptyReadOnlyDictionaryInternalApplicationTrustCollection.ReadCharRemoveAccessRuleAll);
														while (true)
														{
															IL_10e1:
															ptr2 = ptr;
															while (true)
															{
																IL_10ce:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_051b:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0502:
																		ptr2++;
																		num = 36;
																		while (true)
																		{
																			IL_04f2:
																			if (b >= 1)
																			{
																				while (b <= 26)
																				{
																					num = 197;
																					while (true)
																					{
																						IL_04cf:
																						if (13 < b)
																						{
																							while (true)
																							{
																								IL_04bf:
																								if (20 >= b)
																								{
																									while (true)
																									{
																										IL_04af:
																										if (20 > b)
																										{
																											while (true)
																											{
																												IL_049f:
																												if (16 >= b)
																												{
																													while (true)
																													{
																														IL_048f:
																														if (16 <= b)
																														{
																															while (true)
																															{
																																IL_0475:
																																array2[num5] = array2[num5 - 1];
																																while (true)
																																{
																																	IL_044c:
																																	array4[num5 - 0] = array4[num5 - 1];
																																	num = 263;
																																	while (true)
																																	{
																																		if (num != 263)
																																		{
																																			if (num != 1244)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 211:
																																				break;
																																			default:
																																				continue;
																																			case 152:
																																				goto IL_044c;
																																			case 19:
																																			case 120:
																																				goto IL_0475;
																																			case 138:
																																				goto IL_048f;
																																			case 58:
																																				goto IL_049f;
																																			case 188:
																																				goto IL_04af;
																																			case 119:
																																				goto IL_04bf;
																																			case 197:
																																				goto IL_04cf;
																																			case 6:
																																				goto IL_04df;
																																			case 36:
																																				goto IL_04f2;
																																			case 9:
																																				goto IL_0502;
																																			case 233:
																																			case 250:
																																				goto IL_051b;
																																			case 136:
																																				goto IL_0526;
																																			case 46:
																																				goto IL_0531;
																																			case 28:
																																				goto IL_053c;
																																			case 87:
																																			case 134:
																																				goto IL_054a;
																																			case 146:
																																				goto IL_0583;
																																			case 158:
																																			case 192:
																																				goto IL_0591;
																																			case 229:
																																				goto IL_05af;
																																			case 99:
																																				goto IL_05bd;
																																			case 239:
																																				goto IL_05d0;
																																			case 148:
																																			case 248:
																																				goto IL_05e9;
																																			case 23:
																																			case 65:
																																				goto IL_05f4;
																																			case 45:
																																				goto IL_0602;
																																			case 3:
																																			case 244:
																																				goto IL_0610;
																																			case 236:
																																				goto IL_0624;
																																			case 127:
																																				goto IL_065c;
																																			case 95:
																																				goto IL_066f;
																																			case 12:
																																			case 237:
																																				goto IL_067a;
																																			case 20:
																																				goto IL_0688;
																																			case 44:
																																			case 216:
																																				goto IL_0696;
																																			case 18:
																																				goto IL_06a4;
																																			case 241:
																																				goto IL_06bc;
																																			case 88:
																																				goto IL_06ca;
																																			case 17:
																																			case 30:
																																				goto IL_06dd;
																																			case 130:
																																				goto IL_071b;
																																			case 71:
																																				goto IL_0752;
																																			case 110:
																																				goto IL_076a;
																																			case 207:
																																			case 252:
																																				goto IL_077d;
																																			case 37:
																																				goto IL_079e;
																																			case 89:
																																				goto IL_07ac;
																																			case 200:
																																				goto IL_07ba;
																																			case 129:
																																				goto IL_07d6;
																																			case 79:
																																			case 182:
																																				goto IL_07e4;
																																			case 70:
																																			case 202:
																																				goto IL_07ef;
																																			case 132:
																																				goto IL_07fd;
																																			case 1:
																																			case 225:
																																				goto IL_080b;
																																			case 221:
																																				goto IL_0827;
																																			case 80:
																																			case 115:
																																				goto IL_0832;
																																			case 150:
																																				goto IL_0840;
																																			case 116:
																																			case 176:
																																				goto IL_084e;
																																			case 157:
																																				goto IL_087b;
																																			case 154:
																																			case 204:
																																				goto IL_088e;
																																			case 56:
																																				goto IL_08bb;
																																			case 96:
																																				goto IL_08d7;
																																			case 184:
																																			case 187:
																																				goto IL_08e5;
																																			case 161:
																																				goto IL_08f3;
																																			case 228:
																																				goto IL_0901;
																																			case 81:
																																			case 243:
																																				goto IL_090f;
																																			case 222:
																																				goto IL_092c;
																																			case 165:
																																				goto IL_0964;
																																			case 118:
																																				goto IL_0980;
																																			case 219:
																																			case 249:
																																				goto IL_0997;
																																			case 169:
																																				goto IL_09aa;
																																			case 125:
																																				goto IL_09b8;
																																			case 64:
																																			case 160:
																																				goto IL_09cb;
																																			case 92:
																																				goto IL_09df;
																																			case 104:
																																				goto IL_0a40;
																																			case 83:
																																				goto IL_0a57;
																																			case 159:
																																				goto IL_0a6a;
																																			case 57:
																																			case 177:
																																				goto IL_0a78;
																																			case 190:
																																				goto IL_0b2f;
																																			case 113:
																																				goto IL_0b3d;
																																			case 133:
																																			case 208:
																																				goto IL_0b59;
																																			case 40:
																																			case 245:
																																				goto IL_0b67;
																																			case 32:
																																			case 156:
																																				goto IL_0b75;
																																			case 74:
																																				goto IL_0b83;
																																			case 145:
																																				goto IL_0b91;
																																			case 25:
																																				goto IL_0b9f;
																																			case 21:
																																			case 227:
																																				goto IL_0bad;
																																			case 8:
																																				goto IL_0c0f;
																																			case 174:
																																			case 175:
																																				goto IL_0c2b;
																																			case 185:
																																				goto IL_0c3f;
																																			case 230:
																																				goto IL_0c93;
																																			case 131:
																																				goto IL_0ca1;
																																			case 106:
																																			case 255:
																																				goto IL_0cb4;
																																			case 85:
																																				goto IL_0cc2;
																																			case 51:
																																				goto IL_0cd5;
																																			case 34:
																																				goto IL_0ce3;
																																			case 166:
																																				goto IL_0cee;
																																			case 201:
																																			case 246:
																																				goto IL_0cfc;
																																			case 13:
																																				goto IL_0d3c;
																																			case 183:
																																				goto IL_0d50;
																																			case 49:
																																			case 111:
																																				goto IL_0d6c;
																																			case 68:
																																				goto IL_0d7a;
																																			case 5:
																																			case 126:
																																				goto IL_0d88;
																																			case 55:
																																			case 247:
																																				goto IL_0d9b;
																																			case 114:
																																				goto IL_0de4;
																																			case 75:
																																				goto IL_0df8;
																																			case 240:
																																				goto IL_0e0b;
																																			case 67:
																																			case 108:
																																				goto IL_0e19;
																																			case 61:
																																			case 91:
																																				goto IL_0e27;
																																			case 167:
																																			case 209:
																																				goto IL_0e35;
																																			case 43:
																																				goto IL_0e43;
																																			case 143:
																																			case 251:
																																				goto IL_0e51;
																																			case 47:
																																				goto IL_0e91;
																																			case 198:
																																				goto IL_0ea5;
																																			case 15:
																																				goto IL_0eb8;
																																			case 38:
																																			case 191:
																																				goto IL_0ec6;
																																			case 220:
																																				goto IL_0ed4;
																																			case 39:
																																				goto IL_0ef7;
																																			case 253:
																																				goto IL_0f01;
																																			case 0:
																																				goto IL_0f0f;
																																			case 29:
																																				goto IL_0f22;
																																			case 27:
																																			case 170:
																																				goto IL_0f2d;
																																			case 109:
																																				goto IL_0f5f;
																																			case 33:
																																				goto IL_0f6d;
																																			case 226:
																																				goto IL_0f80;
																																			case 26:
																																				goto IL_0f8e;
																																			case 206:
																																				goto IL_0f9c;
																																			case 149:
																																			case 196:
																																				goto IL_0faa;
																																			case 195:
																																				goto IL_0fea;
																																			case 31:
																																				goto IL_0ffe;
																																			case 181:
																																				goto IL_101a;
																																			case 60:
																																			case 203:
																																				goto IL_1027;
																																			case 59:
																																				goto IL_1067;
																																			case 97:
																																				goto IL_107b;
																																			case 2:
																																			case 11:
																																			case 24:
																																			case 41:
																																			case 50:
																																			case 62:
																																			case 66:
																																			case 72:
																																			case 73:
																																			case 76:
																																			case 77:
																																			case 78:
																																			case 82:
																																			case 84:
																																			case 86:
																																			case 94:
																																			case 100:
																																			case 101:
																																			case 102:
																																			case 103:
																																			case 105:
																																			case 107:
																																			case 121:
																																			case 124:
																																			case 139:
																																			case 141:
																																			case 144:
																																			case 151:
																																			case 155:
																																			case 162:
																																			case 171:
																																			case 173:
																																			case 178:
																																			case 180:
																																			case 186:
																																			case 193:
																																			case 199:
																																			case 212:
																																			case 213:
																																			case 214:
																																			case 215:
																																			case 218:
																																			case 238:
																																			case 242:
																																				goto end_IL_04df;
																																			case 112:
																																				goto IL_10a4;
																																			case 22:
																																				goto IL_10b2;
																																			case 35:
																																				goto IL_10c0;
																																			case 7:
																																			case 14:
																																			case 16:
																																			case 42:
																																			case 48:
																																			case 52:
																																			case 53:
																																			case 54:
																																			case 63:
																																			case 69:
																																			case 90:
																																			case 98:
																																			case 117:
																																			case 123:
																																			case 135:
																																			case 137:
																																			case 140:
																																			case 163:
																																			case 164:
																																			case 168:
																																			case 179:
																																			case 189:
																																			case 194:
																																			case 205:
																																			case 224:
																																			case 231:
																																			case 234:
																																			case 235:
																																			case 254:
																																				goto IL_10ce;
																																			case 232:
																																				goto IL_10e1;
																																			case 223:
																																				goto IL_10eb;
																																			case 153:
																																				goto IL_10f6;
																																			case 128:
																																				goto end_IL_0439;
																																			case 172:
																																				goto IL_1116;
																																			case 147:
																																				goto IL_1126;
																																			case 4:
																																				goto IL_1136;
																																			case 93:
																																				goto IL_1146;
																																			case 142:
																																			case 217:
																																				goto IL_1156;
																																			case 122:
																																				goto IL_1166;
																																			case 210:
																																				goto IL_1176;
																																			case 10:
																																			case 256:
																																				return;
																																			}
																																			goto end_IL_1106;
																																		}
																																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																		goto IL_0752;
																																		IL_0752:
																																		array3[num5] = array3[num5 - 1];
																																		goto IL_076a;
																																		IL_076a:
																																		num5++;
																																		goto IL_10ce;
																																		continue;
																																		end_IL_0439:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto IL_0526;
																														IL_05af:
																														ptr2 += 8;
																														goto IL_05bd;
																														IL_0526:
																														if (14 < b)
																														{
																															goto IL_0531;
																														}
																														goto IL_0583;
																														IL_0531:
																														if (15 < b)
																														{
																															num = 86;
																															goto end_IL_04df;
																														}
																														goto IL_053c;
																														IL_053c:
																														if (15 > b)
																														{
																															goto end_IL_04df;
																														}
																														goto IL_054a;
																														IL_054a:
																														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																														goto IL_05d0;
																														IL_05d0:
																														array2[num5 - 1] = 5;
																														goto IL_10ce;
																														IL_05bd:
																														num5--;
																														goto IL_10ce;
																														IL_0583:
																														if (14 > b)
																														{
																															goto end_IL_04df;
																														}
																														goto IL_0591;
																														IL_0591:
																														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																														goto IL_05af;
																													}
																													break;
																												}
																												goto IL_05e9;
																												IL_071b:
																												num5 -= 3;
																												goto IL_10ce;
																												IL_05e9:
																												if (18 < b)
																												{
																													goto IL_05f4;
																												}
																												goto IL_066f;
																												IL_05f4:
																												if (19 < b)
																												{
																													goto end_IL_04df;
																												}
																												goto IL_0602;
																												IL_0602:
																												if (19 > b)
																												{
																													goto end_IL_04df;
																												}
																												goto IL_0610;
																												IL_0610:
																												array2[num5 - 1] = 5;
																												goto IL_0624;
																												IL_0624:
																												array3[num5 - 1] = ((delegate*<string[], string>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																												goto IL_065c;
																												IL_065c:
																												ptr2 += 8;
																												goto IL_10ce;
																												IL_066f:
																												if (18 > b)
																												{
																													goto IL_067a;
																												}
																												goto IL_06dd;
																												IL_067a:
																												if (17 < b)
																												{
																													goto end_IL_04df;
																												}
																												goto IL_0688;
																												IL_0688:
																												if (17 > b)
																												{
																													goto end_IL_04df;
																												}
																												goto IL_0696;
																												IL_0696:
																												array2[num5] = 5;
																												goto IL_06a4;
																												IL_06a4:
																												array3[num5] = array7[*(int*)(ptr2 + num3)];
																												goto IL_06bc;
																												IL_06bc:
																												num5++;
																												goto IL_06ca;
																												IL_06ca:
																												ptr2 += 8;
																												goto IL_10ce;
																												IL_06dd:
																												((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																												goto IL_071b;
																											}
																											break;
																										}
																										goto IL_077d;
																										IL_07ba:
																										ptr2 += 8;
																										num = 7;
																										goto IL_10ce;
																										IL_077d:
																										array3[num5] = array7[*(int*)(ptr2 + num3)];
																										num = 37;
																										goto IL_079e;
																										IL_079e:
																										array2[num5] = 5;
																										goto IL_07ac;
																										IL_07ac:
																										num5++;
																										goto IL_07ba;
																									}
																									break;
																								}
																								goto IL_07d6;
																								IL_0a40:
																								num5 -= 2;
																								num = 83;
																								goto IL_0a57;
																								IL_07d6:
																								if (23 < b)
																								{
																									goto IL_07e4;
																								}
																								goto IL_08d7;
																								IL_07e4:
																								if (25 < b)
																								{
																									goto IL_07ef;
																								}
																								goto IL_0827;
																								IL_07ef:
																								if (26 < b)
																								{
																									goto end_IL_04df;
																								}
																								goto IL_07fd;
																								IL_07fd:
																								if (26 > b)
																								{
																									goto end_IL_04df;
																								}
																								goto IL_080b;
																								IL_080b:
																								num6 = ptr2;
																								num7 = -200;
																								num4 = 1;
																								ptr2 = num6 + num7;
																								goto IL_10ce;
																								IL_0827:
																								if (25 > b)
																								{
																									goto IL_0832;
																								}
																								goto IL_088e;
																								IL_0832:
																								if (24 < b)
																								{
																									goto end_IL_04df;
																								}
																								goto IL_0840;
																								IL_0840:
																								if (24 > b)
																								{
																									goto end_IL_04df;
																								}
																								goto IL_084e;
																								IL_084e:
																								((Class160)array3[num5 - 2]).fieldInfo_0 = (FieldInfo)array3[num5 - 1];
																								goto IL_087b;
																								IL_087b:
																								num5 -= 2;
																								goto IL_10ce;
																								IL_088e:
																								((Class160)array3[num5 - 2]).fieldInfo_1 = (FieldInfo)array3[num5 - 1];
																								goto IL_08bb;
																								IL_08bb:
																								num5 -= 2;
																								num = 234;
																								goto IL_10ce;
																								IL_08d7:
																								if (23 > b)
																								{
																									goto IL_08e5;
																								}
																								goto IL_09cb;
																								IL_08e5:
																								if (21 < b)
																								{
																									goto IL_08f3;
																								}
																								goto IL_0980;
																								IL_08f3:
																								if (22 < b)
																								{
																									goto end_IL_04df;
																								}
																								goto IL_0901;
																								IL_0901:
																								if (22 > b)
																								{
																									goto end_IL_04df;
																								}
																								goto IL_090f;
																								IL_090f:
																								array2[num5 - 1] = 5;
																								num = 222;
																								goto IL_092c;
																								IL_092c:
																								array3[num5 - 1] = ((delegate*<RuntimeTypeHandle, Type>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])((RuntimeTypeHandle)array3[num5 - 1]);
																								goto IL_0964;
																								IL_0964:
																								ptr2 += 8;
																								num = 164;
																								goto IL_10ce;
																								IL_0980:
																								if (21 > b)
																								{
																									goto end_IL_04df;
																								}
																								num = 219;
																								goto IL_0997;
																								IL_0a57:
																								ptr2 += 8;
																								goto IL_10ce;
																								IL_0997:
																								array3[num5] = typeof(global::ConnectedControllerHandler).TypeHandle;
																								goto IL_09aa;
																								IL_09aa:
																								array2[num5] = 4;
																								goto IL_09b8;
																								IL_09b8:
																								num5++;
																								goto IL_10ce;
																								IL_09cb:
																								array2[num5 - 3] = 5;
																								goto IL_09df;
																								IL_09df:
																								array3[num5 - 3] = ((delegate*<Type, string, BindingFlags, FieldInfo>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])((Type)array3[num5 - 3], (string)array3[num5 - 2], *(BindingFlags*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																								goto IL_0a40;
																							}
																							break;
																						}
																						goto IL_0a6a;
																						IL_0faa:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0fea;
																						IL_0a6a:
																						if (13 <= b)
																						{
																							goto IL_0a78;
																						}
																						num = 133;
																						goto IL_0b59;
																						IL_0a78:
																						array8 = array3;
																						num8 = num5;
																						if (array == null)
																						{
																							goto IL_0a87;
																						}
																						num9 = ptr2;
																						byte b2 = *num9;
																						ptr2 = num9 + 4;
																						int num10 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num10;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_0b2f;
																						IL_0ffe:
																						num5--;
																						goto IL_10ce;
																						IL_107b:
																						num5--;
																						goto IL_10ce;
																						IL_101a:
																						if (1 <= b)
																						{
																						}
																						goto end_IL_04df;
																						IL_0b2f:
																						array2[num5] = 5;
																						goto IL_0b3d;
																						IL_0b3d:
																						num5++;
																						goto IL_10ce;
																						IL_0fea:
																						array2[num5 - 2] = 0;
																						goto IL_0ffe;
																						IL_0b59:
																						if (6 < b)
																						{
																							goto IL_0b67;
																						}
																						goto IL_0e0b;
																						IL_0b67:
																						if (9 < b)
																						{
																							goto IL_0b75;
																						}
																						goto IL_0cd5;
																						IL_0b75:
																						if (11 >= b)
																						{
																							goto IL_0b83;
																						}
																						goto IL_0cb4;
																						IL_0b83:
																						if (11 > b)
																						{
																							goto IL_0b91;
																						}
																						num = 175;
																						goto IL_0c2b;
																						IL_0b91:
																						if (10 < b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0b9f;
																						IL_0b9f:
																						if (10 > b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0bad;
																						IL_0bad:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0c0f;
																						IL_0c0f:
																						num5 -= 2;
																						goto IL_10ce;
																						IL_1027:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_1067;
																						IL_0c2b:
																						array2[num5 - 2] = 0;
																						goto IL_0c3f;
																						IL_0c3f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																						goto IL_0c93;
																						IL_0c93:
																						num5--;
																						goto IL_0ca1;
																						IL_0ca1:
																						ptr2 += 8;
																						goto IL_10ce;
																						IL_0cb4:
																						if (12 < b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0cc2;
																						IL_0cc2:
																						if (12 > b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_10ce;
																						IL_0cd5:
																						if (9 > b)
																						{
																							goto IL_0ce3;
																						}
																						goto IL_0d9b;
																						IL_0ce3:
																						if (7 >= b)
																						{
																							goto IL_0cee;
																						}
																						num = 49;
																						goto IL_0d6c;
																						IL_0cee:
																						if (7 > b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0cfc;
																						IL_0cfc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0d3c;
																						IL_0d3c:
																						array2[num5 - 2] = 0;
																						goto IL_0d50;
																						IL_0d50:
																						num5--;
																						goto IL_10ce;
																						IL_1067:
																						array2[num5 - 2] = 0;
																						goto IL_107b;
																						IL_0d6c:
																						if (8 < b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0d7a;
																						IL_0d7a:
																						if (8 > b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0d88;
																						IL_0d88:
																						num5--;
																						goto IL_10ce;
																						IL_0d9b:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						num = 114;
																						goto IL_0de4;
																						IL_0de4:
																						array2[num5 - 2] = 0;
																						goto IL_0df8;
																						IL_0df8:
																						num5--;
																						goto IL_10ce;
																						IL_0e0b:
																						if (6 > b)
																						{
																							goto IL_0e19;
																						}
																						goto IL_1027;
																						IL_0e19:
																						if (3 < b)
																						{
																							goto IL_0e27;
																						}
																						goto IL_0f22;
																						IL_0e27:
																						if (4 < b)
																						{
																							goto IL_0e35;
																						}
																						goto IL_0eb8;
																						IL_0e35:
																						if (5 < b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0e43;
																						IL_0e43:
																						if (5 > b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0e51;
																						IL_0e51:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						goto IL_0e91;
																						IL_0e91:
																						array2[num5 - 2] = 0;
																						goto IL_0ea5;
																						IL_0ea5:
																						num5--;
																						goto IL_10ce;
																						IL_0eb8:
																						if (4 > b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0ec6;
																						IL_0ec6:
																						array2[num5] = 0;
																						goto IL_0ed4;
																						IL_0ed4:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0ef7;
																						IL_0ef7:
																						array3[num5] = null;
																						goto IL_0f01;
																						IL_0f01:
																						num5++;
																						goto IL_0f0f;
																						IL_0f0f:
																						ptr2 += 8;
																						goto IL_10ce;
																						IL_0f22:
																						if (3 <= b)
																						{
																							goto IL_0f2d;
																						}
																						goto IL_0f80;
																						IL_0f2d:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																						num = 109;
																						goto IL_0f5f;
																						IL_0f5f:
																						ptr2 += 8;
																						goto IL_0f6d;
																						IL_0f6d:
																						num5--;
																						goto IL_10ce;
																						IL_0f80:
																						if (1 < b)
																						{
																							goto IL_0f8e;
																						}
																						num = 181;
																						goto IL_101a;
																						IL_0f8e:
																						if (2 < b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0f9c;
																						IL_0f9c:
																						if (2 > b)
																						{
																							goto end_IL_04df;
																						}
																						goto IL_0faa;
																					}
																					goto end_IL_04f2;
																					continue;
																					end_IL_04df:
																					break;
																					IL_04df:;
																				}
																			}
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																			goto IL_10a4;
																			IL_10c0:
																			ptr2 += 8;
																			goto IL_10ce;
																			IL_10b2:
																			num5++;
																			goto IL_10c0;
																			IL_10a4:
																			array2[num5] = 0;
																			goto IL_10b2;
																			continue;
																			end_IL_04f2:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_1106:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0a87:
			while (true)
			{
				IL_0a87_2:
				array = new byte[4];
				while (true)
				{
					num9 = ptr2;
					byte b2 = *num9;
					ptr2 = num9 + 4;
					int num10 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num10;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0b2f_2:
						array2[num5] = 5;
						while (true)
						{
							IL_0b3d_2:
							num5++;
							while (true)
							{
								IL_10ce_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										num = 36;
										while (true)
										{
											IL_04f2_2:
											if (b >= 1)
											{
												while (b <= 26)
												{
													num = 197;
													while (true)
													{
														if (13 < b)
														{
															while (true)
															{
																if (20 >= b)
																{
																	while (true)
																	{
																		if (20 > b)
																		{
																			while (true)
																			{
																				if (16 >= b)
																				{
																					while (true)
																					{
																						if (16 <= b)
																						{
																							while (true)
																							{
																								array2[num5] = array2[num5 - 1];
																								while (true)
																								{
																									array4[num5 - 0] = array4[num5 - 1];
																									num = 263;
																									while (true)
																									{
																										if (num != 263)
																										{
																											if (num != 1244)
																											{
																												goto IL_1106_2;
																											}
																											switch (num)
																											{
																											case 152:
																												goto end_IL_0439_2;
																											case 19:
																											case 120:
																												goto end_IL_044c;
																											case 138:
																												goto end_IL_0475;
																											case 58:
																												goto end_IL_048f;
																											case 188:
																												goto end_IL_049f;
																											case 119:
																												goto end_IL_04af;
																											case 197:
																												goto end_IL_04bf;
																											case 6:
																												goto end_IL_04cf;
																											case 36:
																												goto IL_04f2_2;
																											case 9:
																												goto end_IL_04f2_2;
																											case 233:
																											case 250:
																												goto end_IL_0502;
																											case 136:
																												goto IL_0526_2;
																											case 46:
																												goto IL_0531_2;
																											case 28:
																												goto IL_053c_2;
																											case 87:
																											case 134:
																												goto IL_054a_2;
																											case 146:
																												goto IL_0583_2;
																											case 158:
																											case 192:
																												goto IL_0591_2;
																											case 229:
																												goto IL_05af_2;
																											case 99:
																												goto IL_05bd_2;
																											case 239:
																												goto IL_05d0_2;
																											case 148:
																											case 248:
																												goto IL_05e9_2;
																											case 23:
																											case 65:
																												goto IL_05f4_2;
																											case 45:
																												goto IL_0602_2;
																											case 3:
																											case 244:
																												goto IL_0610_2;
																											case 236:
																												goto IL_0624_2;
																											case 127:
																												goto IL_065c_2;
																											case 95:
																												goto IL_066f_2;
																											case 12:
																											case 237:
																												goto IL_067a_2;
																											case 20:
																												goto IL_0688_2;
																											case 44:
																											case 216:
																												goto IL_0696_2;
																											case 18:
																												goto IL_06a4_2;
																											case 241:
																												goto IL_06bc_2;
																											case 88:
																												goto IL_06ca_2;
																											case 17:
																											case 30:
																												goto IL_06dd_2;
																											case 130:
																												goto IL_071b_2;
																											case 71:
																												goto IL_0752_2;
																											case 110:
																												goto IL_076a_2;
																											case 207:
																											case 252:
																												goto IL_077d_2;
																											case 37:
																												goto IL_079e_2;
																											case 89:
																												goto IL_07ac_2;
																											case 200:
																												goto IL_07ba_2;
																											case 129:
																												goto IL_07d6_2;
																											case 79:
																											case 182:
																												goto IL_07e4_2;
																											case 70:
																											case 202:
																												goto IL_07ef_2;
																											case 132:
																												goto IL_07fd_2;
																											case 1:
																											case 225:
																												goto IL_080b_2;
																											case 221:
																												goto IL_0827_2;
																											case 80:
																											case 115:
																												goto IL_0832_2;
																											case 150:
																												goto IL_0840_2;
																											case 116:
																											case 176:
																												goto IL_084e_2;
																											case 157:
																												goto IL_087b_2;
																											case 154:
																											case 204:
																												goto IL_088e_2;
																											case 56:
																												goto IL_08bb_2;
																											case 96:
																												goto IL_08d7_2;
																											case 184:
																											case 187:
																												goto IL_08e5_2;
																											case 161:
																												goto IL_08f3_2;
																											case 228:
																												goto IL_0901_2;
																											case 81:
																											case 243:
																												goto IL_090f_2;
																											case 222:
																												goto IL_092c_2;
																											case 165:
																												goto IL_0964_2;
																											case 118:
																												goto IL_0980_2;
																											case 219:
																											case 249:
																												goto IL_0997_2;
																											case 169:
																												goto IL_09aa_2;
																											case 125:
																												goto IL_09b8_2;
																											case 64:
																											case 160:
																												goto IL_09cb_2;
																											case 92:
																												goto IL_09df_2;
																											case 104:
																												goto IL_0a40_2;
																											case 83:
																												goto IL_0a57_2;
																											case 159:
																												goto IL_0a6a_2;
																											case 57:
																											case 177:
																												goto end_IL_051b;
																											case 190:
																												goto IL_0b2f_2;
																											case 113:
																												goto IL_0b3d_2;
																											case 133:
																											case 208:
																												goto IL_0b59_2;
																											case 40:
																											case 245:
																												goto IL_0b67_2;
																											case 32:
																											case 156:
																												goto IL_0b75_2;
																											case 74:
																												goto IL_0b83_2;
																											case 145:
																												goto IL_0b91_2;
																											case 25:
																												goto IL_0b9f_2;
																											case 21:
																											case 227:
																												goto IL_0bad_2;
																											case 8:
																												goto IL_0c0f_2;
																											case 174:
																											case 175:
																												goto IL_0c2b_2;
																											case 185:
																												goto IL_0c3f_2;
																											case 230:
																												goto IL_0c93_2;
																											case 131:
																												goto IL_0ca1_2;
																											case 106:
																											case 255:
																												goto IL_0cb4_2;
																											case 85:
																												goto IL_0cc2_2;
																											case 51:
																												goto IL_0cd5_2;
																											case 34:
																												goto IL_0ce3_2;
																											case 166:
																												goto IL_0cee_2;
																											case 201:
																											case 246:
																												goto IL_0cfc_2;
																											case 13:
																												goto IL_0d3c_2;
																											case 183:
																												goto IL_0d50_2;
																											case 49:
																											case 111:
																												goto IL_0d6c_2;
																											case 68:
																												goto IL_0d7a_2;
																											case 5:
																											case 126:
																												goto IL_0d88_2;
																											case 55:
																											case 247:
																												goto IL_0d9b_2;
																											case 114:
																												goto IL_0de4_2;
																											case 75:
																												goto IL_0df8_2;
																											case 240:
																												goto IL_0e0b_2;
																											case 67:
																											case 108:
																												goto IL_0e19_2;
																											case 61:
																											case 91:
																												goto IL_0e27_2;
																											case 167:
																											case 209:
																												goto IL_0e35_2;
																											case 43:
																												goto IL_0e43_2;
																											case 143:
																											case 251:
																												goto IL_0e51_2;
																											case 47:
																												goto IL_0e91_2;
																											case 198:
																												goto IL_0ea5_2;
																											case 15:
																												goto IL_0eb8_2;
																											case 38:
																											case 191:
																												goto IL_0ec6_2;
																											case 220:
																												goto IL_0ed4_2;
																											case 39:
																												goto IL_0ef7_2;
																											case 253:
																												goto IL_0f01_2;
																											case 0:
																												goto IL_0f0f_2;
																											case 29:
																												goto IL_0f22_2;
																											case 27:
																											case 170:
																												goto IL_0f2d_2;
																											case 109:
																												goto IL_0f5f_2;
																											case 33:
																												goto IL_0f6d_2;
																											case 226:
																												goto IL_0f80_2;
																											case 26:
																												goto IL_0f8e_2;
																											case 206:
																												goto IL_0f9c_2;
																											case 149:
																											case 196:
																												goto IL_0faa_2;
																											case 195:
																												goto IL_0fea_2;
																											case 31:
																												goto IL_0ffe_2;
																											case 181:
																												goto IL_101a_2;
																											case 60:
																											case 203:
																												goto IL_1027_2;
																											case 59:
																												goto IL_1067_2;
																											case 97:
																												goto IL_107b_2;
																											case 2:
																											case 11:
																											case 24:
																											case 41:
																											case 50:
																											case 62:
																											case 66:
																											case 72:
																											case 73:
																											case 76:
																											case 77:
																											case 78:
																											case 82:
																											case 84:
																											case 86:
																											case 94:
																											case 100:
																											case 101:
																											case 102:
																											case 103:
																											case 105:
																											case 107:
																											case 121:
																											case 124:
																											case 139:
																											case 141:
																											case 144:
																											case 151:
																											case 155:
																											case 162:
																											case 171:
																											case 173:
																											case 178:
																											case 180:
																											case 186:
																											case 193:
																											case 199:
																											case 212:
																											case 213:
																											case 214:
																											case 215:
																											case 218:
																											case 238:
																											case 242:
																												goto end_IL_04df_2;
																											case 112:
																												goto IL_10a4_2;
																											case 22:
																												goto IL_10b2_2;
																											case 35:
																												goto IL_10c0_2;
																											case 7:
																											case 14:
																											case 16:
																											case 42:
																											case 48:
																											case 52:
																											case 53:
																											case 54:
																											case 63:
																											case 69:
																											case 90:
																											case 98:
																											case 117:
																											case 123:
																											case 135:
																											case 137:
																											case 140:
																											case 163:
																											case 164:
																											case 168:
																											case 179:
																											case 189:
																											case 194:
																											case 205:
																											case 224:
																											case 231:
																											case 234:
																											case 235:
																											case 254:
																												goto IL_10ce_2;
																											case 232:
																												goto IL_10e1_2;
																											case 223:
																												goto IL_10eb_2;
																											case 153:
																												goto IL_10f6_2;
																											case 128:
																												goto IL_1106_2;
																											case 172:
																												array6 = new long[5];
																												goto IL_1106_2;
																											case 147:
																												array5 = new int[6];
																												goto case 172;
																											case 4:
																												array4 = new int[5];
																												goto case 147;
																											case 93:
																												array3 = new object[5];
																												goto case 4;
																											case 142:
																											case 217:
																												array2 = new byte[5];
																												goto case 93;
																											case 122:
																												num3 = num2 * 4;
																												goto case 142;
																											case 210:
																												num2 = 1;
																												goto case 122;
																											case 211:
																												goto end_IL_0a95;
																											case 10:
																											case 256:
																												return;
																											}
																											continue;
																										}
																										*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																										goto IL_0752_2;
																										IL_0752_2:
																										array3[num5] = array3[num5 - 1];
																										goto IL_076a_2;
																										IL_076a_2:
																										num5++;
																										goto IL_10ce_2;
																										IL_1106_2:
																										array7 = new object[20];
																										goto IL_10f6_2;
																										IL_10f6_2:
																										array7[0] = this;
																										goto IL_10eb_2;
																										IL_10eb_2:
																										ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EmptyReadOnlyDictionaryInternalApplicationTrustCollection.ReadCharRemoveAccessRuleAll);
																										goto IL_10e1_2;
																										IL_10e1_2:
																										ptr2 = ptr;
																										goto IL_10ce_2;
																										continue;
																										end_IL_0439_2:
																										break;
																									}
																									continue;
																									end_IL_044c:
																									break;
																								}
																								continue;
																								end_IL_0475:
																								break;
																							}
																							continue;
																						}
																						goto IL_0526_2;
																						IL_05af_2:
																						ptr2 += 8;
																						goto IL_05bd_2;
																						IL_0526_2:
																						if (14 < b)
																						{
																							goto IL_0531_2;
																						}
																						goto IL_0583_2;
																						IL_0531_2:
																						if (15 < b)
																						{
																							num = 86;
																							goto end_IL_04df_2;
																						}
																						goto IL_053c_2;
																						IL_053c_2:
																						if (15 > b)
																						{
																							goto end_IL_04df_2;
																						}
																						goto IL_054a_2;
																						IL_054a_2:
																						array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																						goto IL_05d0_2;
																						IL_05d0_2:
																						array2[num5 - 1] = 5;
																						goto IL_10ce_2;
																						IL_05bd_2:
																						num5--;
																						goto IL_10ce_2;
																						IL_0583_2:
																						if (14 > b)
																						{
																							goto end_IL_04df_2;
																						}
																						goto IL_0591_2;
																						IL_0591_2:
																						array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																						goto IL_05af_2;
																						continue;
																						end_IL_048f:
																						break;
																					}
																					continue;
																				}
																				goto IL_05e9_2;
																				IL_071b_2:
																				num5 -= 3;
																				goto IL_10ce_2;
																				IL_05e9_2:
																				if (18 < b)
																				{
																					goto IL_05f4_2;
																				}
																				goto IL_066f_2;
																				IL_05f4_2:
																				if (19 < b)
																				{
																					goto end_IL_04df_2;
																				}
																				goto IL_0602_2;
																				IL_0602_2:
																				if (19 > b)
																				{
																					goto end_IL_04df_2;
																				}
																				goto IL_0610_2;
																				IL_0610_2:
																				array2[num5 - 1] = 5;
																				goto IL_0624_2;
																				IL_0624_2:
																				array3[num5 - 1] = ((delegate*<string[], string>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																				goto IL_065c_2;
																				IL_065c_2:
																				ptr2 += 8;
																				goto IL_10ce_2;
																				IL_066f_2:
																				if (18 > b)
																				{
																					goto IL_067a_2;
																				}
																				goto IL_06dd_2;
																				IL_067a_2:
																				if (17 < b)
																				{
																					goto end_IL_04df_2;
																				}
																				goto IL_0688_2;
																				IL_0688_2:
																				if (17 > b)
																				{
																					goto end_IL_04df_2;
																				}
																				goto IL_0696_2;
																				IL_0696_2:
																				array2[num5] = 5;
																				goto IL_06a4_2;
																				IL_06a4_2:
																				array3[num5] = array7[*(int*)(ptr2 + num3)];
																				goto IL_06bc_2;
																				IL_06bc_2:
																				num5++;
																				goto IL_06ca_2;
																				IL_06ca_2:
																				ptr2 += 8;
																				goto IL_10ce_2;
																				IL_06dd_2:
																				((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																				goto IL_071b_2;
																				continue;
																				end_IL_049f:
																				break;
																			}
																			continue;
																		}
																		goto IL_077d_2;
																		IL_07ba_2:
																		ptr2 += 8;
																		num = 7;
																		goto IL_10ce_2;
																		IL_077d_2:
																		array3[num5] = array7[*(int*)(ptr2 + num3)];
																		num = 37;
																		goto IL_079e_2;
																		IL_079e_2:
																		array2[num5] = 5;
																		goto IL_07ac_2;
																		IL_07ac_2:
																		num5++;
																		goto IL_07ba_2;
																		continue;
																		end_IL_04af:
																		break;
																	}
																	continue;
																}
																goto IL_07d6_2;
																IL_0a40_2:
																num5 -= 2;
																num = 83;
																goto IL_0a57_2;
																IL_07d6_2:
																if (23 < b)
																{
																	goto IL_07e4_2;
																}
																goto IL_08d7_2;
																IL_07e4_2:
																if (25 < b)
																{
																	goto IL_07ef_2;
																}
																goto IL_0827_2;
																IL_07ef_2:
																if (26 < b)
																{
																	goto end_IL_04df_2;
																}
																goto IL_07fd_2;
																IL_07fd_2:
																if (26 > b)
																{
																	goto end_IL_04df_2;
																}
																goto IL_080b_2;
																IL_080b_2:
																num6 = ptr2;
																num7 = -200;
																num4 = 1;
																ptr2 = num6 + num7;
																goto IL_10ce_2;
																IL_0827_2:
																if (25 > b)
																{
																	goto IL_0832_2;
																}
																goto IL_088e_2;
																IL_0832_2:
																if (24 < b)
																{
																	goto end_IL_04df_2;
																}
																goto IL_0840_2;
																IL_0840_2:
																if (24 > b)
																{
																	goto end_IL_04df_2;
																}
																goto IL_084e_2;
																IL_084e_2:
																((Class160)array3[num5 - 2]).fieldInfo_0 = (FieldInfo)array3[num5 - 1];
																goto IL_087b_2;
																IL_087b_2:
																num5 -= 2;
																goto IL_10ce_2;
																IL_088e_2:
																((Class160)array3[num5 - 2]).fieldInfo_1 = (FieldInfo)array3[num5 - 1];
																goto IL_08bb_2;
																IL_08bb_2:
																num5 -= 2;
																num = 234;
																goto IL_10ce_2;
																IL_08d7_2:
																if (23 > b)
																{
																	goto IL_08e5_2;
																}
																goto IL_09cb_2;
																IL_08e5_2:
																if (21 < b)
																{
																	goto IL_08f3_2;
																}
																goto IL_0980_2;
																IL_08f3_2:
																if (22 < b)
																{
																	goto end_IL_04df_2;
																}
																goto IL_0901_2;
																IL_0901_2:
																if (22 > b)
																{
																	goto end_IL_04df_2;
																}
																goto IL_090f_2;
																IL_090f_2:
																array2[num5 - 1] = 5;
																num = 222;
																goto IL_092c_2;
																IL_092c_2:
																array3[num5 - 1] = ((delegate*<RuntimeTypeHandle, Type>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])((RuntimeTypeHandle)array3[num5 - 1]);
																goto IL_0964_2;
																IL_0964_2:
																ptr2 += 8;
																num = 164;
																goto IL_10ce_2;
																IL_0980_2:
																if (21 > b)
																{
																	goto end_IL_04df_2;
																}
																num = 219;
																goto IL_0997_2;
																IL_0a57_2:
																ptr2 += 8;
																goto IL_10ce_2;
																IL_0997_2:
																array3[num5] = typeof(global::ConnectedControllerHandler).TypeHandle;
																goto IL_09aa_2;
																IL_09aa_2:
																array2[num5] = 4;
																goto IL_09b8_2;
																IL_09b8_2:
																num5++;
																goto IL_10ce_2;
																IL_09cb_2:
																array2[num5 - 3] = 5;
																goto IL_09df_2;
																IL_09df_2:
																array3[num5 - 3] = ((delegate*<Type, string, BindingFlags, FieldInfo>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])((Type)array3[num5 - 3], (string)array3[num5 - 2], *(BindingFlags*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
																goto IL_0a40_2;
																continue;
																end_IL_04bf:
																break;
															}
															continue;
														}
														goto IL_0a6a_2;
														IL_107b_2:
														num5--;
														goto IL_10ce_2;
														IL_0a6a_2:
														if (13 <= b)
														{
															goto end_IL_051b;
														}
														num = 133;
														goto IL_0b59_2;
														IL_101a_2:
														if (1 <= b)
														{
														}
														goto end_IL_04df_2;
														IL_0b59_2:
														if (6 < b)
														{
															goto IL_0b67_2;
														}
														goto IL_0e0b_2;
														IL_0b67_2:
														if (9 < b)
														{
															goto IL_0b75_2;
														}
														goto IL_0cd5_2;
														IL_0b75_2:
														if (11 >= b)
														{
															goto IL_0b83_2;
														}
														goto IL_0cb4_2;
														IL_0b83_2:
														if (11 > b)
														{
															goto IL_0b91_2;
														}
														num = 175;
														goto IL_0c2b_2;
														IL_0b91_2:
														if (10 < b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0b9f_2;
														IL_0b9f_2:
														if (10 > b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0bad_2;
														IL_0bad_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0c0f_2;
														IL_0c0f_2:
														num5 -= 2;
														goto IL_10ce_2;
														IL_1027_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_1067_2;
														IL_0c2b_2:
														array2[num5 - 2] = 0;
														goto IL_0c3f_2;
														IL_0c3f_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = ((delegate*<int, int, int>)IPermissiondwHelpContext[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]));
														goto IL_0c93_2;
														IL_0c93_2:
														num5--;
														goto IL_0ca1_2;
														IL_0ca1_2:
														ptr2 += 8;
														goto IL_10ce_2;
														IL_0cb4_2:
														if (12 < b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0cc2_2;
														IL_0cc2_2:
														if (12 > b)
														{
															goto end_IL_04df_2;
														}
														goto IL_10ce_2;
														IL_0cd5_2:
														if (9 > b)
														{
															goto IL_0ce3_2;
														}
														goto IL_0d9b_2;
														IL_0ce3_2:
														if (7 >= b)
														{
															goto IL_0cee_2;
														}
														num = 49;
														goto IL_0d6c_2;
														IL_0cee_2:
														if (7 > b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0cfc_2;
														IL_0cfc_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0d3c_2;
														IL_0d3c_2:
														array2[num5 - 2] = 0;
														goto IL_0d50_2;
														IL_0d50_2:
														num5--;
														goto IL_10ce_2;
														IL_1067_2:
														array2[num5 - 2] = 0;
														goto IL_107b_2;
														IL_0d6c_2:
														if (8 < b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0d7a_2;
														IL_0d7a_2:
														if (8 > b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0d88_2;
														IL_0d88_2:
														num5--;
														goto IL_10ce_2;
														IL_0d9b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 114;
														goto IL_0de4_2;
														IL_0de4_2:
														array2[num5 - 2] = 0;
														goto IL_0df8_2;
														IL_0df8_2:
														num5--;
														goto IL_10ce_2;
														IL_0e0b_2:
														if (6 > b)
														{
															goto IL_0e19_2;
														}
														goto IL_1027_2;
														IL_0e19_2:
														if (3 < b)
														{
															goto IL_0e27_2;
														}
														goto IL_0f22_2;
														IL_0e27_2:
														if (4 < b)
														{
															goto IL_0e35_2;
														}
														goto IL_0eb8_2;
														IL_0e35_2:
														if (5 < b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0e43_2;
														IL_0e43_2:
														if (5 > b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0e51_2;
														IL_0e51_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0e91_2;
														IL_0e91_2:
														array2[num5 - 2] = 0;
														goto IL_0ea5_2;
														IL_0ea5_2:
														num5--;
														goto IL_10ce_2;
														IL_0eb8_2:
														if (4 > b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0ec6_2;
														IL_0ec6_2:
														array2[num5] = 0;
														goto IL_0ed4_2;
														IL_0ed4_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0ef7_2;
														IL_0ef7_2:
														array3[num5] = null;
														goto IL_0f01_2;
														IL_0f01_2:
														num5++;
														goto IL_0f0f_2;
														IL_0f0f_2:
														ptr2 += 8;
														goto IL_10ce_2;
														IL_0f22_2:
														if (3 <= b)
														{
															goto IL_0f2d_2;
														}
														goto IL_0f80_2;
														IL_0f2d_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														num = 109;
														goto IL_0f5f_2;
														IL_0f5f_2:
														ptr2 += 8;
														goto IL_0f6d_2;
														IL_0f6d_2:
														num5--;
														goto IL_10ce_2;
														IL_0f80_2:
														if (1 < b)
														{
															goto IL_0f8e_2;
														}
														num = 181;
														goto IL_101a_2;
														IL_0f8e_2:
														if (2 < b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0f9c_2;
														IL_0f9c_2:
														if (2 > b)
														{
															goto end_IL_04df_2;
														}
														goto IL_0faa_2;
														IL_0faa_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0fea_2;
														IL_0fea_2:
														array2[num5 - 2] = 0;
														goto IL_0ffe_2;
														IL_0ffe_2:
														num5--;
														goto IL_10ce_2;
														continue;
														end_IL_04cf:
														break;
													}
													continue;
													end_IL_04df_2:
													break;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_10a4_2;
											IL_10c0_2:
											ptr2 += 8;
											goto IL_10ce_2;
											IL_10b2_2:
											num5++;
											goto IL_10c0_2;
											IL_10a4_2:
											array2[num5] = 0;
											goto IL_10b2_2;
											continue;
											end_IL_04f2_2:
											break;
										}
										continue;
										end_IL_0502:
										break;
									}
									continue;
									end_IL_051b:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num8 = num5;
					if (array == null)
					{
						goto IL_0a87_2;
					}
					continue;
					end_IL_0a95:
					break;
				}
				break;
			}
		}
	}

	private unsafe void Update()
	{
		int num = 233;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 232;
			while (true)
			{
				int num3 = num2 * 4;
				num = 89;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ISurrogateSelectorCriticalFinalizerObject.KERBSULOGONComEventsHelper);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 199;
														while (true)
														{
															if (num5 == 1)
															{
																return;
															}
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_05eb:
																		if (b >= 1)
																		{
																			while (b <= 38)
																			{
																				while (true)
																				{
																					IL_05cb:
																					if (19 < b)
																					{
																						while (true)
																						{
																							IL_05be:
																							if (29 < b)
																							{
																								while (true)
																								{
																									IL_05ae:
																									if (34 >= b)
																									{
																										while (true)
																										{
																											IL_059e:
																											if (34 <= b)
																											{
																												while (true)
																												{
																													IL_0588:
																													array[num6 - 1] = 3;
																													while (true)
																													{
																														IL_053e:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																														num = 327;
																														while (true)
																														{
																															if (num != 327)
																															{
																																if (num != 1308)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 96:
																																	goto IL_053e;
																																case 17:
																																case 56:
																																	goto IL_0588;
																																case 309:
																																	goto IL_059e;
																																case 302:
																																	goto IL_05ae;
																																case 8:
																																	goto IL_05be;
																																case 11:
																																	goto IL_05cb;
																																case 94:
																																	goto end_IL_05cb;
																																case 49:
																																	goto IL_05eb;
																																case 251:
																																	goto end_IL_05eb;
																																case 246:
																																case 307:
																																	goto end_IL_05fb;
																																case 20:
																																	goto IL_0616;
																																case 12:
																																case 126:
																																	goto IL_0621;
																																case 68:
																																	goto IL_0659;
																																case 91:
																																	goto IL_066d;
																																case 181:
																																	goto IL_0680;
																																case 190:
																																	goto IL_068e;
																																case 97:
																																	goto IL_0699;
																																case 46:
																																	goto IL_06a7;
																																case 133:
																																	goto IL_06b5;
																																case 3:
																																	goto IL_06c8;
																																case 22:
																																	goto IL_06d3;
																																case 95:
																																	goto IL_06ef;
																																case 141:
																																	goto IL_0706;
																																case 142:
																																case 175:
																																	goto IL_071d;
																																case 159:
																																	goto IL_075d;
																																case 220:
																																	goto IL_0776;
																																case 31:
																																case 120:
																																	goto IL_0784;
																																case 150:
																																	goto IL_0798;
																																case 4:
																																	goto IL_07e0;
																																case 234:
																																	goto IL_07f3;
																																case 147:
																																	goto IL_0801;
																																case 69:
																																	goto IL_080f;
																																case 226:
																																	goto IL_081a;
																																case 47:
																																case 243:
																																	goto IL_0838;
																																case 108:
																																	goto IL_0846;
																																case 53:
																																	goto IL_0864;
																																case 36:
																																	goto IL_0872;
																																case 249:
																																	goto IL_0885;
																																case 267:
																																	goto IL_0898;
																																case 52:
																																	goto IL_08a6;
																																case 155:
																																	goto IL_08b4;
																																case 130:
																																	goto IL_08c2;
																																case 162:
																																	goto IL_08d0;
																																case 85:
																																case 90:
																																	goto IL_08de;
																																case 184:
																																	goto IL_0940;
																																case 80:
																																	goto IL_0953;
																																case 202:
																																	goto IL_095e;
																																case 169:
																																	goto IL_0971;
																																case 177:
																																	goto IL_097f;
																																case 25:
																																case 92:
																																	goto IL_098d;
																																case 139:
																																case 166:
																																	goto IL_09ae;
																																case 179:
																																	goto IL_09ef;
																																case 258:
																																	goto IL_0a03;
																																case 268:
																																	goto IL_0a16;
																																case 28:
																																case 134:
																																	goto IL_0a21;
																																case 14:
																																	goto IL_0a61;
																																case 114:
																																	goto IL_0a75;
																																case 178:
																																	goto IL_0a88;
																																case 117:
																																	goto IL_0a96;
																																case 13:
																																	goto IL_0aa4;
																																case 6:
																																	goto IL_0ab2;
																																case 29:
																																	goto IL_0ac0;
																																case 149:
																																	goto IL_0ace;
																																case 10:
																																case 228:
																																	goto IL_0adc;
																																case 144:
																																	goto IL_0af5;
																																case 180:
																																	goto IL_0b03;
																																case 214:
																																	goto IL_0b11;
																																case 275:
																																	goto IL_0b32;
																																case 217:
																																	goto IL_0b40;
																																case 33:
																																case 148:
																																	goto IL_0b4b;
																																case 70:
																																	goto IL_0b8b;
																																case 161:
																																	goto IL_0b9f;
																																case 235:
																																	goto IL_0bb2;
																																case 140:
																																	goto IL_0bc0;
																																case 257:
																																	goto IL_0bd3;
																																case 74:
																																	goto IL_0bde;
																																case 143:
																																	goto IL_0bf1;
																																case 113:
																																	goto IL_0bff;
																																case 105:
																																case 160:
																																	goto IL_0c16;
																																case 262:
																																case 277:
																																	goto IL_0c32;
																																case 55:
																																	goto IL_0c3c;
																																case 183:
																																case 278:
																																	goto IL_0c4f;
																																case 176:
																																	goto IL_0c8f;
																																case 154:
																																	goto IL_0ca3;
																																case 294:
																																	goto IL_0cb6;
																																case 83:
																																	goto IL_0cc1;
																																case 132:
																																	goto IL_0ccf;
																																case 106:
																																case 164:
																																	goto IL_0cdd;
																																case 137:
																																	goto IL_0d15;
																																case 280:
																																	goto IL_0d29;
																																case 206:
																																	goto IL_0d3c;
																																case 128:
																																case 215:
																																	goto IL_0d4a;
																																case 67:
																																	goto IL_0d62;
																																case 227:
																																	goto IL_0d70;
																																case 191:
																																	goto IL_0d7e;
																																case 279:
																																case 298:
																																	goto IL_0d9a;
																																case 239:
																																	goto IL_0dda;
																																case 272:
																																	goto IL_0dee;
																																case 109:
																																case 300:
																																	goto IL_0e01;
																																case 121:
																																	goto IL_0e0f;
																																case 76:
																																	goto IL_0e32;
																																case 0:
																																	goto IL_0e3c;
																																case 253:
																																	goto IL_0e4a;
																																case 291:
																																case 304:
																																	goto IL_0e5d;
																																case 34:
																																case 305:
																																	goto IL_0e7b;
																																case 62:
																																	goto IL_0e8f;
																																case 195:
																																	goto IL_0edc;
																																case 71:
																																	goto IL_0eea;
																																case 308:
																																	goto IL_0f06;
																																case 231:
																																case 254:
																																	goto IL_0f11;
																																case 2:
																																	goto IL_0f36;
																																case 297:
																																	goto IL_0f44;
																																case 21:
																																case 269:
																																	goto IL_0f5b;
																																case 245:
																																	goto end_IL_052b;
																																case 310:
																																	goto IL_0fc0;
																																case 81:
																																	goto IL_0fce;
																																case 72:
																																	goto IL_0fdc;
																																case 182:
																																case 316:
																																	goto IL_0fef;
																																case 255:
																																	goto IL_1003;
																																case 292:
																																	goto IL_1042;
																																case 223:
																																case 317:
																																	goto IL_1055;
																																case 313:
																																	goto IL_1095;
																																case 44:
																																	goto IL_10a9;
																																case 318:
																																	goto IL_10bc;
																																case 170:
																																	goto IL_10ca;
																																case 41:
																																case 118:
																																	goto IL_10d5;
																																case 57:
																																	goto IL_10ee;
																																case 129:
																																	goto IL_10fc;
																																case 193:
																																	goto IL_110a;
																																case 100:
																																	goto IL_111d;
																																case 93:
																																	goto IL_112b;
																																case 146:
																																case 210:
																																	goto IL_1139;
																																case 43:
																																	goto IL_114d;
																																case 271:
																																	goto IL_119a;
																																case 65:
																																	goto IL_11a8;
																																case 60:
																																	goto IL_11bb;
																																case 123:
																																	goto IL_11c6;
																																case 221:
																																case 296:
																																	goto IL_11d4;
																																case 127:
																																	goto IL_11e8;
																																case 131:
																																	goto IL_1230;
																																case 88:
																																	goto IL_1243;
																																case 289:
																																	goto IL_125a;
																																case 54:
																																case 208:
																																	goto IL_1268;
																																case 315:
																																	goto IL_12a8;
																																case 259:
																																	goto IL_12bc;
																																case 319:
																																	goto IL_12cf;
																																case 203:
																																	goto IL_12dd;
																																case 39:
																																case 286:
																																	goto IL_12eb;
																																case 212:
																																	goto IL_1314;
																																case 165:
																																	goto IL_1322;
																																case 320:
																																	goto IL_1335;
																																case 115:
																																	goto IL_135b;
																																case 276:
																																	goto IL_1369;
																																case 207:
																																	goto IL_1374;
																																case 247:
																																	goto IL_1382;
																																case 167:
																																case 287:
																																	goto IL_1390;
																																case 84:
																																	goto IL_139e;
																																case 192:
																																	goto IL_13bc;
																																case 174:
																																	goto IL_13ca;
																																case 173:
																																case 248:
																																	goto IL_13dd;
																																case 270:
																																	goto IL_1406;
																																case 48:
																																	goto IL_141f;
																																case 9:
																																	goto IL_142d;
																																case 135:
																																	goto IL_143b;
																																case 138:
																																case 185:
																																	goto IL_1449;
																																case 229:
																																	goto IL_145d;
																																case 266:
																																	goto IL_149c;
																																case 116:
																																	goto IL_14af;
																																case 66:
																																case 201:
																																	goto IL_14bd;
																																case 136:
																																	goto IL_1509;
																																case 283:
																																	goto IL_1520;
																																case 301:
																																	goto IL_1533;
																																case 273:
																																	goto IL_1541;
																																case 102:
																																case 263:
																																	goto IL_154c;
																																case 77:
																																	goto IL_15aa;
																																case 198:
																																	goto IL_15bd;
																																case 186:
																																	goto IL_15cb;
																																case 64:
																																case 299:
																																	goto IL_15d9;
																																case 145:
																																	goto IL_15e7;
																																case 18:
																																	goto IL_160b;
																																case 110:
																																	goto IL_1619;
																																case 274:
																																	goto IL_162c;
																																case 288:
																																	goto IL_1637;
																																case 194:
																																case 290:
																																	goto IL_1642;
																																case 50:
																																	goto IL_1656;
																																case 285:
																																	goto IL_1695;
																																case 37:
																																	goto IL_16a5;
																																case 103:
																																	goto IL_16b0;
																																case 1:
																																case 7:
																																case 16:
																																case 19:
																																case 23:
																																case 30:
																																case 32:
																																case 40:
																																case 51:
																																case 58:
																																case 61:
																																case 63:
																																case 75:
																																case 79:
																																case 98:
																																case 99:
																																case 104:
																																case 107:
																																case 124:
																																case 151:
																																case 152:
																																case 153:
																																case 158:
																																case 163:
																																case 171:
																																case 187:
																																case 189:
																																case 196:
																																case 200:
																																case 211:
																																case 213:
																																case 216:
																																case 224:
																																case 238:
																																case 240:
																																case 241:
																																case 244:
																																case 250:
																																case 261:
																																case 295:
																																case 312:
																																	goto end_IL_05db;
																																case 5:
																																case 15:
																																case 24:
																																case 26:
																																case 27:
																																case 35:
																																case 38:
																																case 42:
																																case 45:
																																case 59:
																																case 78:
																																case 101:
																																case 111:
																																case 112:
																																case 119:
																																case 122:
																																case 157:
																																case 168:
																																case 172:
																																case 188:
																																case 197:
																																case 199:
																																case 204:
																																case 205:
																																case 218:
																																case 222:
																																case 225:
																																case 230:
																																case 236:
																																case 237:
																																case 242:
																																case 256:
																																case 260:
																																case 264:
																																case 265:
																																case 282:
																																case 284:
																																case 293:
																																case 303:
																																case 306:
																																	goto end_IL_060b;
																																case 314:
																																	goto end_IL_16d7;
																																case 209:
																																	goto end_IL_16ea;
																																case 281:
																																	goto end_IL_16f5;
																																case 219:
																																	goto end_IL_16ff;
																																case 125:
																																	goto end_IL_170a;
																																case 87:
																																	goto end_IL_171a;
																																case 73:
																																case 156:
																																	goto end_IL_172a;
																																case 311:
																																	goto end_IL_173a;
																																case 86:
																																	goto end_IL_174a;
																																case 89:
																																	goto end_IL_175a;
																																case 232:
																																	goto end_IL_176a;
																																case 233:
																																	goto end_IL_177a;
																																case 82:
																																case 252:
																																	return;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															goto end_IL_060b;
																															continue;
																															end_IL_052b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_135b;
																											IL_1520:
																											ptr2 += 8;
																											goto end_IL_060b;
																											IL_135b:
																											if (31 >= b)
																											{
																												goto IL_1369;
																											}
																											goto IL_141f;
																											IL_1369:
																											if (31 > b)
																											{
																												goto IL_1374;
																											}
																											goto IL_13dd;
																											IL_1374:
																											if (30 < b)
																											{
																												goto end_IL_05db;
																											}
																											goto IL_1382;
																											IL_1382:
																											if (30 > b)
																											{
																												goto end_IL_05db;
																											}
																											goto IL_1390;
																											IL_1390:
																											array[num6] = 5;
																											goto IL_139e;
																											IL_139e:
																											array2[num6] = ((delegate*<global::ConnectedControllerHandler>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])();
																											goto IL_13bc;
																											IL_13bc:
																											num6++;
																											goto IL_13ca;
																											IL_13ca:
																											ptr2 += 8;
																											goto end_IL_060b;
																											IL_13dd:
																											array2[num6 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) != 0;
																											goto IL_1406;
																											IL_1406:
																											array[num6 - 1] = 5;
																											goto end_IL_060b;
																											IL_141f:
																											if (32 < b)
																											{
																												goto IL_142d;
																											}
																											goto IL_14af;
																											IL_142d:
																											if (33 < b)
																											{
																												goto end_IL_05db;
																											}
																											goto IL_143b;
																											IL_143b:
																											if (33 > b)
																											{
																												goto end_IL_05db;
																											}
																											goto IL_1449;
																											IL_1449:
																											array[num6 - 1] = 3;
																											goto IL_145d;
																											IL_145d:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																											goto IL_149c;
																											IL_149c:
																											ptr2 += 8;
																											goto end_IL_060b;
																											IL_14af:
																											if (32 > b)
																											{
																												goto end_IL_05db;
																											}
																											goto IL_14bd;
																											IL_14bd:
																											((delegate*<FieldInfo, object, object, void>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])((FieldInfo)array2[num6 - 3], (global::ConnectedControllerHandler)array2[num6 - 2], array2[num6 - 1]);
																											goto IL_1509;
																											IL_1509:
																											num6 -= 3;
																											num = 283;
																											goto IL_1520;
																										}
																										break;
																									}
																									goto IL_1533;
																									IL_16b0:
																									if (38 <= b)
																									{
																									}
																									goto end_IL_05db;
																									IL_1533:
																									if (36 >= b)
																									{
																										goto IL_1541;
																									}
																									goto IL_162c;
																									IL_1541:
																									if (36 <= b)
																									{
																										goto IL_154c;
																									}
																									goto IL_15bd;
																									IL_154c:
																									ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_15aa;
																									IL_15aa:
																									num6--;
																									goto end_IL_060b;
																									IL_15bd:
																									if (35 < b)
																									{
																										goto end_IL_05db;
																									}
																									goto IL_15cb;
																									IL_15cb:
																									if (35 > b)
																									{
																										goto end_IL_05db;
																									}
																									goto IL_15d9;
																									IL_15d9:
																									array[num6] = 0;
																									goto IL_15e7;
																									IL_15e7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])() ? 1 : 0);
																									goto IL_160b;
																									IL_160b:
																									num6++;
																									goto IL_1619;
																									IL_1619:
																									ptr2 += 8;
																									goto end_IL_060b;
																									IL_162c:
																									if (37 >= b)
																									{
																										goto IL_1637;
																									}
																									goto IL_16a5;
																									IL_1637:
																									if (37 > b)
																									{
																										goto end_IL_05db;
																									}
																									goto IL_1642;
																									IL_1642:
																									array[num6 - 1] = 3;
																									goto IL_1656;
																									IL_1656:
																									*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																									goto IL_1695;
																									IL_1695:
																									ptr2 += 8;
																									goto end_IL_060b;
																									IL_16a5:
																									if (38 < b)
																									{
																										goto end_IL_05db;
																									}
																									goto IL_16b0;
																								}
																								break;
																							}
																							goto IL_0616;
																							IL_12bc:
																							num6--;
																							goto end_IL_060b;
																							IL_0616:
																							if (29 <= b)
																							{
																								goto IL_0621;
																							}
																							goto IL_0680;
																							IL_0621:
																							array2[num6 - 1] = ((delegate*<Class160, FieldInfo>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])((Class160)array2[num6 - 1]);
																							goto IL_0659;
																							IL_0659:
																							array[num6 - 1] = 5;
																							goto IL_066d;
																							IL_066d:
																							ptr2 += 8;
																							goto end_IL_060b;
																							IL_0680:
																							if (24 < b)
																							{
																								goto IL_068e;
																							}
																							goto IL_0776;
																							IL_068e:
																							if (26 >= b)
																							{
																								goto IL_0699;
																							}
																							goto IL_06c8;
																							IL_0699:
																							if (26 > b)
																							{
																								goto IL_06a7;
																							}
																							goto IL_0e7b;
																							IL_06a7:
																							if (25 < b)
																							{
																								goto end_IL_05db;
																							}
																							goto IL_06b5;
																							IL_06b5:
																							if (25 > b)
																							{
																								goto end_IL_05db;
																							}
																							goto IL_0838;
																							IL_0838:
																							array[num6] = 5;
																							goto IL_0846;
																							IL_0846:
																							array2[num6] = ((delegate*<global::ConnectedControllerHandler>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])();
																							goto IL_0864;
																							IL_0864:
																							num6++;
																							goto IL_0872;
																							IL_0872:
																							ptr2 += 8;
																							goto end_IL_060b;
																							IL_0e7b:
																							array[num6 - 2] = 0;
																							goto IL_0e8f;
																							IL_0e8f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])((global::ConnectedControllerHandler)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																							goto IL_0edc;
																							IL_0edc:
																							num6--;
																							goto IL_0eea;
																							IL_0eea:
																							ptr2 += 8;
																							num = 157;
																							goto end_IL_060b;
																							IL_06c8:
																							if (27 >= b)
																							{
																								goto IL_06d3;
																							}
																							goto IL_06ef;
																							IL_06d3:
																							if (27 > b)
																							{
																								goto end_IL_05db;
																							}
																							num = 316;
																							goto IL_0fef;
																							IL_125a:
																							if (23 > b)
																							{
																								goto end_IL_05db;
																							}
																							goto IL_1268;
																							IL_0fef:
																							array[num6 - 1] = 3;
																							goto IL_1003;
																							IL_1003:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_1042;
																							IL_1042:
																							ptr2 += 8;
																							goto end_IL_060b;
																							IL_06ef:
																							if (28 < b)
																							{
																								goto end_IL_05db;
																							}
																							num = 141;
																							goto IL_0706;
																							IL_1268:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_12a8;
																							IL_0706:
																							if (28 > b)
																							{
																								goto end_IL_05db;
																							}
																							num = 142;
																							goto IL_071d;
																							IL_12a8:
																							array[num6 - 2] = 3;
																							goto IL_12bc;
																							IL_071d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_075d;
																							IL_075d:
																							array[num6 - 2] = 3;
																							goto IL_0885;
																							IL_0885:
																							num6--;
																							goto end_IL_060b;
																							IL_0776:
																							if (24 <= b)
																							{
																								goto IL_0784;
																							}
																							goto IL_10bc;
																							IL_0784:
																							array[num6 - 1] = 0;
																							goto IL_0798;
																							IL_0798:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							num = 4;
																							goto IL_07e0;
																							IL_07e0:
																							ptr2 += 8;
																							goto end_IL_060b;
																							IL_10bc:
																							if (21 >= b)
																							{
																								goto IL_10ca;
																							}
																							goto IL_11bb;
																							IL_10ca:
																							if (21 <= b)
																							{
																								goto IL_10d5;
																							}
																							goto IL_111d;
																							IL_10d5:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																							goto IL_10ee;
																							IL_10ee:
																							array[num6] = 3;
																							goto IL_10fc;
																							IL_10fc:
																							num6++;
																							goto IL_110a;
																							IL_110a:
																							ptr2 += 16;
																							goto end_IL_060b;
																							IL_111d:
																							if (20 < b)
																							{
																								goto end_IL_05db;
																							}
																							goto IL_112b;
																							IL_112b:
																							if (20 > b)
																							{
																								goto end_IL_05db;
																							}
																							goto IL_1139;
																							IL_1139:
																							array[num6 - 2] = 0;
																							goto IL_114d;
																							IL_114d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<FieldInfo, FieldInfo, bool>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])((FieldInfo)array2[num6 - 2], (FieldInfo)array2[num6 - 1]) ? 1 : 0);
																							goto IL_119a;
																							IL_119a:
																							num6--;
																							goto IL_11a8;
																							IL_11a8:
																							ptr2 += 8;
																							goto end_IL_060b;
																							IL_11bb:
																							if (22 >= b)
																							{
																								goto IL_11c6;
																							}
																							goto IL_1243;
																							IL_11c6:
																							if (22 > b)
																							{
																								goto end_IL_05db;
																							}
																							goto IL_11d4;
																							IL_11d4:
																							array[num6 - 1] = 3;
																							goto IL_11e8;
																							IL_11e8:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							num = 131;
																							goto IL_1230;
																							IL_1230:
																							ptr2 += 8;
																							goto end_IL_060b;
																							IL_1243:
																							if (23 < b)
																							{
																								goto end_IL_05db;
																							}
																							num = 289;
																							goto IL_125a;
																						}
																						goto IL_0fad;
																					}
																					goto IL_07f3;
																					IL_0bff:
																					if (8 > b)
																					{
																						goto end_IL_05db;
																					}
																					num = 105;
																					goto IL_0c16;
																					IL_07f3:
																					if (19 > b)
																					{
																						goto IL_0801;
																					}
																					goto IL_0c32;
																					IL_0801:
																					if (9 < b)
																					{
																						goto IL_080f;
																					}
																					goto IL_0a16;
																					IL_080f:
																					if (14 < b)
																					{
																						goto IL_081a;
																					}
																					num = 267;
																					goto IL_0898;
																					IL_081a:
																					if (16 < b)
																					{
																						goto IL_0cb6;
																					}
																					goto IL_0f06;
																					IL_0cb6:
																					if (17 < b)
																					{
																						goto IL_0cc1;
																					}
																					goto IL_0d3c;
																					IL_0cc1:
																					if (18 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0ccf;
																					IL_0ccf:
																					if (18 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0cdd;
																					IL_0cdd:
																					array2[num6 - 1] = ((delegate*<Class160, FieldInfo>)setCurrencyDecimalSeparatorContingentProperties[*(int*)(ptr2 + num3)])((Class160)array2[num6 - 1]);
																					goto IL_0d15;
																					IL_0d15:
																					array[num6 - 1] = 5;
																					goto IL_0d29;
																					IL_0d29:
																					ptr2 += 8;
																					goto end_IL_060b;
																					IL_0d3c:
																					if (17 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0d4a;
																					IL_0d4a:
																					array2[num6] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0d62;
																					IL_0d62:
																					array[num6] = 5;
																					goto IL_0d70;
																					IL_0d70:
																					num6++;
																					goto IL_0d7e;
																					IL_0d7e:
																					ptr2 += 8;
																					num = 230;
																					goto end_IL_060b;
																					IL_0f06:
																					if (16 <= b)
																					{
																						goto IL_0f11;
																					}
																					goto IL_0f36;
																					IL_0f11:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					num = 205;
																					goto end_IL_060b;
																					IL_0f36:
																					if (15 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0f44;
																					IL_0f44:
																					if (15 > b)
																					{
																						goto end_IL_05db;
																					}
																					num = 21;
																					goto IL_0f5b;
																					IL_0c16:
																					num6--;
																					num = 282;
																					goto end_IL_060b;
																					IL_0f5b:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0fad;
																					IL_0fad:
																					num6--;
																					goto end_IL_060b;
																					IL_1335:
																					num6++;
																					goto end_IL_060b;
																					IL_0898:
																					if (14 > b)
																					{
																						goto IL_08a6;
																					}
																					num = 166;
																					goto IL_09ae;
																					IL_08a6:
																					if (11 >= b)
																					{
																						goto IL_08b4;
																					}
																					goto IL_0953;
																					IL_08b4:
																					if (11 <= b)
																					{
																						goto end_IL_060b;
																					}
																					goto IL_08c2;
																					IL_08c2:
																					if (10 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_08d0;
																					IL_08d0:
																					if (10 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_08de;
																					IL_08de:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0940;
																					IL_0940:
																					num6 -= 2;
																					goto end_IL_060b;
																					IL_0953:
																					if (12 >= b)
																					{
																						goto IL_095e;
																					}
																					goto IL_0971;
																					IL_095e:
																					if (12 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0e5d;
																					IL_0e5d:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																					goto IL_0fc0;
																					IL_0fc0:
																					array[num6] = 1;
																					goto IL_0fce;
																					IL_0fce:
																					num6++;
																					goto IL_0fdc;
																					IL_0fdc:
																					ptr2 += 16;
																					goto end_IL_060b;
																					IL_0971:
																					if (13 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_097f;
																					IL_097f:
																					if (13 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_098d;
																					IL_098d:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_060b;
																					IL_0c32:
																					array2[num6] = null;
																					goto IL_0c3c;
																					IL_09ae:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																					goto IL_09ef;
																					IL_09ef:
																					array[num6 - 2] = 0;
																					goto IL_0a03;
																					IL_0a03:
																					num6--;
																					goto end_IL_060b;
																					IL_0a16:
																					if (9 <= b)
																					{
																						goto IL_0a21;
																					}
																					goto IL_0a88;
																					IL_0a21:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0a61;
																					IL_0a61:
																					array[num6 - 2] = 0;
																					goto IL_0a75;
																					IL_0a75:
																					num6--;
																					goto end_IL_060b;
																					IL_0a88:
																					if (4 >= b)
																					{
																						goto IL_0a96;
																					}
																					goto IL_0b32;
																					IL_0a96:
																					if (4 > b)
																					{
																						goto IL_0aa4;
																					}
																					num = 300;
																					goto IL_0e01;
																					IL_0aa4:
																					if (2 >= b)
																					{
																						goto IL_0ab2;
																					}
																					goto IL_12cf;
																					IL_0ab2:
																					if (2 > b)
																					{
																						goto IL_0ac0;
																					}
																					goto IL_0c4f;
																					IL_0ac0:
																					if (1 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0ace;
																					IL_0ace:
																					if (1 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0adc;
																					IL_0adc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																					goto IL_0af5;
																					IL_0af5:
																					array[num6] = 0;
																					goto IL_0b03;
																					IL_0b03:
																					num6++;
																					goto IL_0b11;
																					IL_0b11:
																					ptr2 += 8;
																					goto end_IL_060b;
																					IL_0c4f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0c8f;
																					IL_0c8f:
																					array[num6 - 2] = 0;
																					goto IL_0ca3;
																					IL_0ca3:
																					num6--;
																					goto end_IL_060b;
																					IL_12cf:
																					if (3 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_12dd;
																					IL_12dd:
																					if (3 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_12eb;
																					IL_12eb:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_1314;
																					IL_1314:
																					ptr2 += 8;
																					goto IL_1322;
																					IL_1322:
																					num6--;
																					goto end_IL_060b;
																					IL_0c3c:
																					array[num6] = 5;
																					goto IL_1335;
																					IL_0e01:
																					array[num6] = 0;
																					goto IL_0e0f;
																					IL_0e0f:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0e32;
																					IL_0e32:
																					array2[num6] = null;
																					goto IL_0e3c;
																					IL_0e3c:
																					num6++;
																					goto IL_0e4a;
																					IL_0e4a:
																					ptr2 += 8;
																					goto end_IL_060b;
																					IL_0b32:
																					if (6 >= b)
																					{
																						goto IL_0b40;
																					}
																					goto IL_0bd3;
																					IL_0b40:
																					if (6 <= b)
																					{
																						goto IL_0b4b;
																					}
																					goto IL_0bb2;
																					IL_0b4b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0b8b;
																					IL_0b8b:
																					array[num6 - 2] = 0;
																					goto IL_0b9f;
																					IL_0b9f:
																					num6--;
																					goto end_IL_060b;
																					IL_0bb2:
																					if (5 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0bc0;
																					IL_0bc0:
																					if (5 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0d9a;
																					IL_0d9a:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0dda;
																					IL_0dda:
																					array[num6 - 2] = 0;
																					goto IL_0dee;
																					IL_0dee:
																					num6--;
																					goto end_IL_060b;
																					IL_0bd3:
																					if (7 >= b)
																					{
																						goto IL_0bde;
																					}
																					goto IL_0bf1;
																					IL_0bde:
																					if (7 > b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_1055;
																					IL_1055:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_1095;
																					IL_1095:
																					array[num6 - 2] = 0;
																					goto IL_10a9;
																					IL_10a9:
																					num6--;
																					goto end_IL_060b;
																					IL_0bf1:
																					if (8 < b)
																					{
																						goto end_IL_05db;
																					}
																					goto IL_0bff;
																					continue;
																					end_IL_05cb:
																					break;
																				}
																				continue;
																				end_IL_05db:
																				break;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		num = 38;
																		goto end_IL_060b;
																		continue;
																		end_IL_05eb:
																		break;
																	}
																	continue;
																	end_IL_05fb:
																	break;
																}
																continue;
																end_IL_060b:
																break;
															}
															continue;
															end_IL_16d7:
															break;
														}
														continue;
														end_IL_16ea:
														break;
													}
													continue;
													end_IL_16f5:
													break;
												}
												continue;
												end_IL_16ff:
												break;
											}
											continue;
											end_IL_170a:
											break;
										}
										continue;
										end_IL_171a:
										break;
									}
									continue;
									end_IL_172a:
									break;
								}
								continue;
								end_IL_173a:
								break;
							}
							continue;
							end_IL_174a:
							break;
						}
						continue;
						end_IL_175a:
						break;
					}
					continue;
					end_IL_176a:
					break;
				}
				continue;
				end_IL_177a:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 168;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 63;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AllClipboardBuiltinGuestsSid.CultureAwareRandomizedComparerVTNULL);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														num = 17;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_047e:
																	if (b >= 1)
																	{
																		while (b <= 25)
																		{
																			while (true)
																			{
																				IL_0461:
																				if (13 < b)
																				{
																					while (true)
																					{
																						IL_0451:
																						if (19 < b)
																						{
																							while (true)
																							{
																								IL_0441:
																								if (22 >= b)
																								{
																									while (true)
																									{
																										IL_0431:
																										if (22 > b)
																										{
																											while (true)
																											{
																												IL_0421:
																												if (20 >= b)
																												{
																													while (20 <= b)
																													{
																														while (true)
																														{
																															IL_03f2:
																															array[num5 - 2] = 0;
																															num = 244;
																															while (true)
																															{
																																if (num != 244)
																																{
																																	if (num != 1225)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 69:
																																	case 113:
																																		goto IL_03f2;
																																	case 129:
																																		goto IL_0411;
																																	case 56:
																																		goto IL_0421;
																																	case 131:
																																		goto IL_0431;
																																	case 134:
																																		goto IL_0441;
																																	case 232:
																																		goto IL_0451;
																																	case 3:
																																		goto IL_0461;
																																	case 218:
																																		goto IL_046e;
																																	case 61:
																																		goto IL_047e;
																																	case 177:
																																		goto end_IL_047e;
																																	case 17:
																																		goto end_IL_048e;
																																	case 104:
																																		goto end_IL_049e;
																																	case 147:
																																		goto IL_04b4;
																																	case 70:
																																	case 110:
																																		goto IL_04c2;
																																	case 81:
																																	case 159:
																																		goto IL_04d5;
																																	case 116:
																																		goto IL_04fe;
																																	case 163:
																																		goto IL_0517;
																																	case 93:
																																	case 142:
																																		goto IL_052e;
																																	case 89:
																																		goto IL_0539;
																																	case 164:
																																		goto IL_0552;
																																	case 87:
																																		goto IL_0560;
																																	case 183:
																																		goto IL_0573;
																																	case 76:
																																	case 80:
																																		goto IL_057e;
																																	case 191:
																																		goto IL_05d5;
																																	case 4:
																																	case 36:
																																		goto IL_05e3;
																																	case 55:
																																		goto IL_05f1;
																																	case 57:
																																	case 88:
																																		goto IL_05ff;
																																	case 133:
																																		goto IL_0613;
																																	case 6:
																																		goto IL_0665;
																																	case 37:
																																	case 75:
																																		goto IL_0673;
																																	case 71:
																																		goto IL_067d;
																																	case 144:
																																		goto IL_068b;
																																	case 194:
																																		goto IL_069e;
																																	case 9:
																																		goto IL_06bc;
																																	case 68:
																																		goto end_IL_03df;
																																	case 62:
																																	case 197:
																																		goto IL_06dd;
																																	case 208:
																																	case 211:
																																		goto IL_071a;
																																	case 204:
																																		goto IL_0728;
																																	case 40:
																																	case 101:
																																		goto IL_0736;
																																	case 145:
																																		goto IL_0744;
																																	case 94:
																																	case 153:
																																		goto IL_0752;
																																	case 58:
																																		goto IL_0760;
																																	case 148:
																																	case 170:
																																		goto IL_076e;
																																	case 65:
																																		goto IL_07d0;
																																	case 27:
																																		goto IL_07e3;
																																	case 45:
																																		goto IL_07f1;
																																	case 12:
																																		goto IL_0804;
																																	case 44:
																																	case 146:
																																		goto IL_080f;
																																	case 24:
																																		goto IL_084f;
																																	case 98:
																																	case 173:
																																		goto IL_087a;
																																	case 25:
																																		goto IL_0885;
																																	case 35:
																																	case 188:
																																		goto IL_0893;
																																	case 43:
																																		goto IL_08d3;
																																	case 39:
																																		goto IL_08e7;
																																	case 66:
																																		goto IL_08fa;
																																	case 34:
																																		goto IL_0908;
																																	case 38:
																																	case 195:
																																		goto IL_0916;
																																	case 213:
																																		goto IL_0929;
																																	case 19:
																																	case 91:
																																		goto IL_0937;
																																	case 215:
																																		goto IL_0953;
																																	case 221:
																																		goto IL_0966;
																																	case 28:
																																	case 114:
																																		goto IL_0974;
																																	case 105:
																																	case 138:
																																		goto IL_0982;
																																	case 13:
																																		goto IL_098d;
																																	case 154:
																																	case 171:
																																		goto IL_099b;
																																	case 155:
																																		goto IL_09a9;
																																	case 196:
																																		goto IL_09cc;
																																	case 23:
																																		goto IL_09d6;
																																	case 120:
																																		goto IL_09e4;
																																	case 175:
																																		goto IL_09f7;
																																	case 92:
																																		goto IL_0a05;
																																	case 72:
																																	case 178:
																																		goto IL_0a13;
																																	case 16:
																																		goto IL_0a53;
																																	case 124:
																																		goto IL_0a67;
																																	case 150:
																																		goto IL_0a7a;
																																	case 156:
																																		goto IL_0a88;
																																	case 86:
																																		goto IL_0a96;
																																	case 111:
																																	case 136:
																																		goto IL_0aad;
																																	case 21:
																																		goto IL_0ac6;
																																	case 190:
																																		goto IL_0ad4;
																																	case 73:
																																		goto IL_0ae2;
																																	case 30:
																																	case 54:
																																		goto IL_0af5;
																																	case 90:
																																		goto IL_0b35;
																																	case 84:
																																		goto IL_0b49;
																																	case 222:
																																		goto IL_0b5c;
																																	case 51:
																																	case 224:
																																		goto IL_0b78;
																																	case 165:
																																		goto IL_0b86;
																																	case 100:
																																	case 172:
																																		goto IL_0b94;
																																	case 109:
																																		goto IL_0bd4;
																																	case 157:
																																		goto IL_0bf1;
																																	case 22:
																																	case 228:
																																		goto IL_0c04;
																																	case 132:
																																		goto IL_0c1c;
																																	case 82:
																																		goto IL_0c2a;
																																	case 139:
																																		goto IL_0c38;
																																	case 137:
																																	case 230:
																																		goto IL_0c4b;
																																	case 20:
																																		goto IL_0c5f;
																																	case 201:
																																		goto IL_0cb3;
																																	case 212:
																																		goto IL_0cc1;
																																	case 234:
																																		goto IL_0cd4;
																																	case 77:
																																		goto IL_0ce2;
																																	case 31:
																																	case 235:
																																		goto IL_0cf5;
																																	case 103:
																																		goto IL_0d1e;
																																	case 229:
																																		goto IL_0d2c;
																																	case 236:
																																		goto IL_0d3f;
																																	case 214:
																																		goto IL_0d53;
																																	case 121:
																																		goto IL_0db3;
																																	case 217:
																																		goto IL_0dc1;
																																	case 141:
																																		goto IL_0dd4;
																																	case 174:
																																		goto IL_0de2;
																																	case 115:
																																	case 225:
																																		goto IL_0ded;
																																	case 179:
																																		goto IL_0dfb;
																																	case 11:
																																		goto IL_0e19;
																																	case 122:
																																		goto IL_0e27;
																																	case 15:
																																		goto IL_0e48;
																																	case 107:
																																		goto IL_0e56;
																																	case 135:
																																	case 203:
																																		goto IL_0e61;
																																	case 42:
																																		goto IL_0e99;
																																	case 83:
																																		goto IL_0ead;
																																	case 1:
																																		goto IL_0ec0;
																																	case 199:
																																		goto IL_0ece;
																																	case 60:
																																	case 126:
																																		goto IL_0edc;
																																	case 119:
																																		goto IL_0f28;
																																	case 26:
																																		goto IL_0f36;
																																	case 18:
																																	case 99:
																																		goto IL_0f4f;
																																	case 151:
																																		goto IL_0f5a;
																																	case 7:
																																	case 8:
																																	case 10:
																																	case 14:
																																	case 29:
																																	case 33:
																																	case 41:
																																	case 46:
																																	case 48:
																																	case 49:
																																	case 53:
																																	case 67:
																																	case 85:
																																	case 96:
																																	case 97:
																																	case 118:
																																	case 125:
																																	case 127:
																																	case 149:
																																	case 160:
																																	case 161:
																																	case 180:
																																	case 181:
																																	case 182:
																																	case 187:
																																	case 189:
																																	case 198:
																																	case 206:
																																	case 207:
																																	case 209:
																																	case 216:
																																	case 219:
																																	case 220:
																																	case 223:
																																	case 226:
																																	case 231:
																																	case 233:
																																	case 237:
																																		goto end_IL_0411;
																																	case 2:
																																	case 5:
																																	case 32:
																																	case 47:
																																	case 50:
																																	case 52:
																																	case 64:
																																	case 74:
																																	case 78:
																																	case 79:
																																	case 95:
																																	case 102:
																																	case 108:
																																	case 130:
																																	case 140:
																																	case 143:
																																	case 152:
																																	case 158:
																																	case 166:
																																	case 169:
																																	case 176:
																																	case 184:
																																	case 186:
																																	case 192:
																																	case 200:
																																	case 202:
																																	case 205:
																																	case 227:
																																		goto end_IL_04a9;
																																	case 210:
																																		goto end_IL_0f78;
																																	case 193:
																																		goto end_IL_0f8b;
																																	case 0:
																																		goto end_IL_0f95;
																																	case 112:
																																		goto end_IL_0fa0;
																																	case 106:
																																		goto end_IL_0fb0;
																																	case 123:
																																	case 185:
																																		goto end_IL_0fc0;
																																	case 59:
																																		goto end_IL_0fd0;
																																	case 63:
																																	case 128:
																																		goto end_IL_0fe0;
																																	case 167:
																																		goto end_IL_0ff0;
																																	case 168:
																																		goto end_IL_1000;
																																	case 117:
																																	case 162:
																																		return;
																																	}
																																	continue;
																																}
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<FieldInfo, FieldInfo, bool>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])((FieldInfo)array2[num5 - 2], (FieldInfo)array2[num5 - 1]) ? 1 : 0);
																																goto IL_0db3;
																																IL_0db3:
																																num5--;
																																goto IL_0dc1;
																																IL_0dc1:
																																ptr2 += 8;
																																goto end_IL_04a9;
																																continue;
																																end_IL_03df:
																																break;
																															}
																															break;
																														}
																														goto IL_06ca;
																														continue;
																														end_IL_0411:
																														break;
																														IL_0411:;
																													}
																													break;
																												}
																												goto IL_0dd4;
																												IL_0e27:
																												ptr2 += 8;
																												goto end_IL_04a9;
																												IL_0dd4:
																												if (21 < b)
																												{
																													break;
																												}
																												goto IL_0de2;
																												IL_0de2:
																												if (21 > b)
																												{
																													num = 49;
																													break;
																												}
																												goto IL_0ded;
																												IL_0ded:
																												array[num5] = 5;
																												goto IL_0dfb;
																												IL_0dfb:
																												array2[num5] = ((delegate*<global::ConnectedControllerHandler>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])();
																												goto IL_0e19;
																												IL_0e19:
																												num5++;
																												goto IL_0e27;
																											}
																											break;
																										}
																										goto IL_04d5;
																										IL_04fe:
																										array[num5 - 1] = 5;
																										goto end_IL_04a9;
																										IL_04d5:
																										array2[num5 - 1] = (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
																										goto IL_04fe;
																									}
																									break;
																								}
																								goto IL_0e48;
																								IL_0f4f:
																								if (25 < b)
																								{
																									break;
																								}
																								goto IL_0f5a;
																								IL_0e48:
																								if (24 >= b)
																								{
																									goto IL_0e56;
																								}
																								num = 99;
																								goto IL_0f4f;
																								IL_0e56:
																								if (24 <= b)
																								{
																									goto IL_0e61;
																								}
																								goto IL_0ec0;
																								IL_0e61:
																								array2[num5 - 1] = ((delegate*<Class160, FieldInfo>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])((Class160)array2[num5 - 1]);
																								goto IL_0e99;
																								IL_0e99:
																								array[num5 - 1] = 5;
																								goto IL_0ead;
																								IL_0ead:
																								ptr2 += 8;
																								goto end_IL_04a9;
																								IL_0ec0:
																								if (23 < b)
																								{
																									break;
																								}
																								goto IL_0ece;
																								IL_0ece:
																								if (23 > b)
																								{
																									break;
																								}
																								goto IL_0edc;
																								IL_0edc:
																								((delegate*<FieldInfo, object, object, void>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])((FieldInfo)array2[num5 - 3], (global::ConnectedControllerHandler)array2[num5 - 2], array2[num5 - 1]);
																								goto IL_0f28;
																								IL_0f28:
																								num5 -= 3;
																								goto IL_0f36;
																								IL_0f36:
																								ptr2 += 8;
																								goto end_IL_04a9;
																								IL_0f5a:
																								if (25 > b)
																								{
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0517;
																						IL_06dd:
																						array2[num5 - 1] = ((delegate*<Class160, FieldInfo>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])((Class160)array2[num5 - 1]);
																						goto IL_0d3f;
																						IL_0517:
																						if (19 > b)
																						{
																							num = 93;
																							goto IL_052e;
																						}
																						goto IL_06dd;
																						IL_0d3f:
																						array[num5 - 1] = 5;
																						goto IL_0d53;
																						IL_052e:
																						if (16 < b)
																						{
																							goto IL_0539;
																						}
																						goto IL_0573;
																						IL_0539:
																						if (17 < b)
																						{
																							goto IL_0552;
																						}
																						num = 213;
																						goto IL_0929;
																						IL_0d53:
																						ptr2 += 8;
																						goto end_IL_04a9;
																						IL_0929:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0937;
																						IL_0937:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_04a9;
																						IL_0552:
																						if (18 < b)
																						{
																							break;
																						}
																						goto IL_0560;
																						IL_0560:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_0c04;
																						IL_0c04:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0c1c;
																						IL_0c1c:
																						array[num5] = 5;
																						goto IL_0c2a;
																						IL_0c2a:
																						num5++;
																						goto IL_0c38;
																						IL_0c38:
																						ptr2 += 8;
																						goto end_IL_04a9;
																						IL_0573:
																						if (16 <= b)
																						{
																							goto IL_057e;
																						}
																						goto IL_05d5;
																						IL_057e:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0953;
																						IL_0953:
																						num5--;
																						goto end_IL_04a9;
																						IL_05d5:
																						if (14 < b)
																						{
																							goto IL_05e3;
																						}
																						goto IL_0665;
																						IL_05e3:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_05f1;
																						IL_05f1:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_05ff;
																						IL_05ff:
																						array[num5 - 2] = 0;
																						goto IL_0613;
																						IL_0613:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])((global::ConnectedControllerHandler)array2[num5 - 2], (UnityEngine.Object)array2[num5 - 1]) ? 1 : 0);
																						goto IL_0cd4;
																						IL_0cd4:
																						num5--;
																						goto IL_0ce2;
																						IL_0ce2:
																						ptr2 += 8;
																						goto end_IL_04a9;
																						IL_0665:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0673;
																						IL_0673:
																						array2[num5] = null;
																						goto IL_067d;
																						IL_067d:
																						array[num5] = 5;
																						goto IL_068b;
																						IL_068b:
																						num5++;
																						goto end_IL_04a9;
																					}
																					break;
																				}
																				goto IL_04b4;
																				IL_0af5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0b35;
																				IL_04b4:
																				if (13 <= b)
																				{
																					goto IL_04c2;
																				}
																				goto IL_071a;
																				IL_04c2:
																				array[num5] = 5;
																				goto IL_069e;
																				IL_069e:
																				array2[num5] = ((delegate*<global::ConnectedControllerHandler>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])();
																				goto IL_06bc;
																				IL_06bc:
																				num5++;
																				goto IL_06ca;
																				IL_06ca:
																				ptr2 += 8;
																				goto end_IL_04a9;
																				IL_071a:
																				if (6 < b)
																				{
																					goto IL_0728;
																				}
																				goto IL_0966;
																				IL_0728:
																				if (9 < b)
																				{
																					goto IL_0736;
																				}
																				goto IL_0804;
																				IL_0736:
																				if (11 >= b)
																				{
																					goto IL_0744;
																				}
																				goto IL_07e3;
																				IL_0744:
																				if (11 > b)
																				{
																					goto IL_0752;
																				}
																				goto IL_0c4b;
																				IL_0752:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0760;
																				IL_0760:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_076e;
																				IL_076e:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_07d0;
																				IL_07d0:
																				num5 -= 2;
																				goto end_IL_04a9;
																				IL_0c4b:
																				array[num5 - 2] = 0;
																				goto IL_0c5f;
																				IL_0c5f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)TrackResurrectionFieldTypes[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_0cb3;
																				IL_0cb3:
																				num5--;
																				goto IL_0cc1;
																				IL_0cc1:
																				ptr2 += 8;
																				goto end_IL_04a9;
																				IL_07e3:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_07f1;
																				IL_07f1:
																				if (12 > b)
																				{
																					break;
																				}
																				goto end_IL_04a9;
																				IL_0804:
																				if (9 <= b)
																				{
																					goto IL_080f;
																				}
																				num = 173;
																				goto IL_087a;
																				IL_080f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_084f;
																				IL_084f:
																				array[num5 - 2] = 0;
																				num = 222;
																				goto IL_0b5c;
																				IL_0b5c:
																				num5--;
																				num = 169;
																				goto end_IL_04a9;
																				IL_0b35:
																				array[num5 - 2] = 0;
																				goto IL_0b49;
																				IL_087a:
																				if (7 >= b)
																				{
																					goto IL_0885;
																				}
																				goto IL_08fa;
																				IL_0885:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0893;
																				IL_0893:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_08d3;
																				IL_08d3:
																				array[num5 - 2] = 0;
																				goto IL_08e7;
																				IL_08e7:
																				num5--;
																				goto end_IL_04a9;
																				IL_08fa:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0908;
																				IL_0908:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0916;
																				IL_0916:
																				num5--;
																				goto end_IL_04a9;
																				IL_0966:
																				if (6 > b)
																				{
																					goto IL_0974;
																				}
																				goto IL_0af5;
																				IL_0974:
																				if (3 < b)
																				{
																					goto IL_0982;
																				}
																				goto IL_0a7a;
																				IL_0982:
																				if (4 >= b)
																				{
																					goto IL_098d;
																				}
																				goto IL_09f7;
																				IL_098d:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_099b;
																				IL_099b:
																				array[num5] = 0;
																				goto IL_09a9;
																				IL_09a9:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_09cc;
																				IL_09cc:
																				array2[num5] = null;
																				goto IL_09d6;
																				IL_09d6:
																				num5++;
																				goto IL_09e4;
																				IL_09e4:
																				ptr2 += 8;
																				goto end_IL_04a9;
																				IL_09f7:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_0a05;
																				IL_0a05:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0a13;
																				IL_0a13:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0a53;
																				IL_0a53:
																				array[num5 - 2] = 0;
																				goto IL_0a67;
																				IL_0a67:
																				num5--;
																				goto end_IL_04a9;
																				IL_0a7a:
																				if (3 > b)
																				{
																					goto IL_0a88;
																				}
																				goto IL_0cf5;
																				IL_0a88:
																				if (1 >= b)
																				{
																					goto IL_0a96;
																				}
																				goto IL_0b78;
																				IL_0a96:
																				if (1 > b)
																				{
																					break;
																				}
																				num = 111;
																				goto IL_0aad;
																				IL_0b49:
																				num5--;
																				goto end_IL_04a9;
																				IL_0aad:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0ac6;
																				IL_0ac6:
																				array[num5] = 0;
																				goto IL_0ad4;
																				IL_0ad4:
																				num5++;
																				goto IL_0ae2;
																				IL_0ae2:
																				ptr2 += 8;
																				goto end_IL_04a9;
																				IL_0b78:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_0b86;
																				IL_0b86:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_0b94;
																				IL_0b94:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0bd4;
																				IL_0bd4:
																				array[num5 - 2] = 0;
																				num = 157;
																				goto IL_0bf1;
																				IL_0bf1:
																				num5--;
																				goto end_IL_04a9;
																				IL_0cf5:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0d1e;
																				IL_0d1e:
																				ptr2 += 8;
																				goto IL_0d2c;
																				IL_0d2c:
																				num5--;
																				goto end_IL_04a9;
																			}
																			break;
																			IL_046e:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_04a9;
																	continue;
																	end_IL_047e:
																	break;
																}
																continue;
																end_IL_048e:
																break;
															}
															continue;
															end_IL_049e:
															break;
														}
														continue;
														end_IL_04a9:
														break;
													}
													continue;
													end_IL_0f78:
													break;
												}
												continue;
												end_IL_0f8b:
												break;
											}
											continue;
											end_IL_0f95:
											break;
										}
										continue;
										end_IL_0fa0:
										break;
									}
									continue;
									end_IL_0fb0:
									break;
								}
								continue;
								end_IL_0fc0:
								break;
							}
							continue;
							end_IL_0fd0:
							break;
						}
						continue;
						end_IL_0fe0:
						break;
					}
					continue;
					end_IL_0ff0:
					break;
				}
				continue;
				end_IL_1000:
				break;
			}
		}
	}

	public Class160()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 56;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 9;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DynamicMethodNullStream.getDriveTypeIConvertible);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														num = 92;
														while (true)
														{
															if (num == 92)
															{
																goto IL_0242;
															}
															if (num != 1073)
															{
																goto IL_0451;
															}
															switch (num)
															{
															case 66:
																goto end_IL_017f;
															case 25:
																goto end_IL_0192;
															case 14:
																goto end_IL_019d;
															case 1:
																goto end_IL_01a7;
															case 79:
																goto end_IL_01b2;
															case 57:
																goto end_IL_01c7;
															case 9:
																goto end_IL_01dc;
															case 70:
																goto end_IL_01ec;
															case 72:
																goto end_IL_01fc;
															case 39:
															case 63:
																goto end_IL_0207;
															case 55:
																goto end_IL_0217;
															case 56:
																goto end_IL_0227;
															case 0:
															case 22:
															case 29:
															case 32:
															case 35:
															case 36:
															case 52:
															case 60:
															case 85:
																goto IL_0242;
															case 16:
															case 82:
																goto IL_0252;
															case 3:
																goto IL_025b;
															case 24:
																goto IL_0269;
															case 53:
																goto IL_0277;
															case 15:
																goto IL_0285;
															case 7:
																goto IL_0293;
															case 28:
															case 48:
																goto IL_029e;
															case 80:
																goto IL_02c7;
															case 19:
																goto IL_02d5;
															case 11:
																goto IL_02e8;
															case 40:
																goto IL_02f6;
															case 12:
																goto IL_0301;
															case 37:
																goto IL_030f;
															case 30:
															case 42:
																goto IL_032b;
															case 67:
																goto IL_0399;
															case 43:
															case 54:
																goto IL_03b5;
															case 75:
																goto IL_03c3;
															case 71:
															case 81:
																goto IL_03d1;
															case 23:
																goto IL_0411;
															case 38:
																goto IL_0425;
															case 18:
																goto IL_0438;
															case 31:
															case 34:
																goto IL_0446;
															case 17:
															case 73:
																goto IL_0451;
															case 64:
																goto IL_0468;
															case 4:
															case 21:
																goto IL_0476;
															case 44:
																goto IL_0492;
															case 26:
															case 33:
																goto IL_04a0;
															case 68:
																goto IL_04ae;
															case 59:
																goto IL_04d1;
															case 77:
																goto IL_04db;
															case 46:
																goto IL_04e9;
															case 5:
																goto IL_04fc;
															case 83:
																goto IL_050a;
															case 65:
																goto IL_0515;
															case 6:
															case 27:
																goto IL_0529;
															case 8:
																goto IL_0541;
															case 61:
																goto IL_054f;
															case 45:
																goto IL_055d;
															case 2:
															case 10:
															case 13:
															case 20:
															case 47:
															case 49:
															case 50:
															case 51:
															case 58:
															case 69:
															case 74:
															case 76:
															case 78:
															case 84:
																goto IL_0570;
															case 41:
															case 62:
																goto IL_0595;
															}
															continue;
															IL_055d:
															ptr2 += 8;
															goto IL_0242;
															IL_0529:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_0242;
															IL_0242:
															if (num4 != 1)
															{
																goto IL_0252;
															}
															goto IL_0595;
															IL_0595:
															return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															IL_0252:
															b = *ptr2;
															goto IL_025b;
															IL_025b:
															ptr2++;
															goto IL_0269;
															IL_0269:
															if (b >= 1)
															{
																goto IL_0277;
															}
															goto IL_0570;
															IL_0277:
															if (b <= 8)
															{
																goto IL_0285;
															}
															goto IL_0570;
															IL_0285:
															if (4 >= b)
															{
																goto IL_0293;
															}
															goto IL_0438;
															IL_0293:
															if (4 <= b)
															{
																goto IL_029e;
															}
															goto IL_02e8;
															IL_029e:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_02c7;
															IL_02c7:
															ptr2 += 8;
															goto IL_02d5;
															IL_02d5:
															num5--;
															goto IL_0242;
															IL_02e8:
															if (2 >= b)
															{
																goto IL_02f6;
															}
															num = 43;
															goto IL_03b5;
															IL_02f6:
															if (2 > b)
															{
																goto IL_0301;
															}
															num = 30;
															goto IL_032b;
															IL_0301:
															if (1 >= b)
															{
																goto IL_030f;
															}
															goto IL_0570;
															IL_030f:
															if (1 > b)
															{
															}
															goto IL_0570;
															IL_0541:
															array[num5] = 0;
															goto IL_054f;
															IL_032b:
															ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0399;
															IL_0399:
															num5 -= 2;
															goto IL_0242;
															IL_0570:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_0541;
															IL_03b5:
															if (3 >= b)
															{
																goto IL_03c3;
															}
															goto IL_0570;
															IL_03c3:
															if (3 <= b)
															{
																goto IL_03d1;
															}
															goto IL_0570;
															IL_03d1:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0411;
															IL_0411:
															array[num5 - 2] = 0;
															goto IL_0425;
															IL_0425:
															num5--;
															goto IL_0242;
															IL_0438:
															if (6 < b)
															{
																goto IL_0446;
															}
															goto IL_04fc;
															IL_0446:
															if (7 < b)
															{
																goto IL_0451;
															}
															goto IL_0492;
															IL_0451:
															if (8 >= b)
															{
																num = 64;
																goto IL_0468;
															}
															goto IL_0570;
															IL_054f:
															num5++;
															goto IL_055d;
															IL_0468:
															if (8 <= b)
															{
																goto IL_0476;
															}
															goto IL_0570;
															IL_0476:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															goto IL_0242;
															IL_0492:
															if (7 <= b)
															{
																goto IL_04a0;
															}
															goto IL_0570;
															IL_04a0:
															array[num5] = 0;
															goto IL_04ae;
															IL_04ae:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_04d1;
															IL_04d1:
															array2[num5] = null;
															goto IL_04db;
															IL_04db:
															num5++;
															goto IL_04e9;
															IL_04e9:
															ptr2 += 8;
															goto IL_0242;
															IL_04fc:
															if (6 <= b)
															{
																goto IL_0242;
															}
															goto IL_050a;
															IL_050a:
															if (5 >= b)
															{
																goto IL_0515;
															}
															goto IL_0570;
															IL_0515:
															if (5 <= b)
															{
																num = 27;
																goto IL_0529;
															}
															goto IL_0570;
															continue;
															end_IL_017f:
															break;
														}
														continue;
														end_IL_0192:
														break;
													}
													continue;
													end_IL_019d:
													break;
												}
												continue;
												end_IL_01a7:
												break;
											}
											continue;
											end_IL_01b2:
											break;
										}
										continue;
										end_IL_01c7:
										break;
									}
									continue;
									end_IL_01dc:
									break;
								}
								continue;
								end_IL_01ec:
								break;
							}
							continue;
							end_IL_01fc:
							break;
						}
						continue;
						end_IL_0207:
						break;
					}
					continue;
					end_IL_0217:
					break;
				}
				continue;
				end_IL_0227:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 40;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 91;
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MakeGenericTypeSpecialPermissionSetFlag.TrimEndStackBasedReturnMessage);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_033e:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		num = 32;
																		while (true)
																		{
																			IL_031b:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_030e:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02fe:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02ee:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02de:
																											if (10 <= b)
																											{
																												while (true)
																												{
																													IL_02ce:
																													array[num5] = 0;
																													while (true)
																													{
																														IL_02a0:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																														num = 156;
																														while (true)
																														{
																															if (num != 156)
																															{
																																if (num != 1137)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 31:
																																	goto IL_02a0;
																																case 27:
																																case 134:
																																	goto IL_02ce;
																																case 3:
																																	goto IL_02de;
																																case 42:
																																case 130:
																																	goto IL_02ee;
																																case 5:
																																	goto IL_02fe;
																																case 26:
																																	goto IL_030e;
																																case 32:
																																	goto IL_031b;
																																case 17:
																																	goto end_IL_028d;
																																case 33:
																																	goto IL_033e;
																																case 2:
																																	goto end_IL_033e;
																																case 68:
																																case 96:
																																	goto end_IL_034e;
																																case 11:
																																case 23:
																																	goto IL_0369;
																																case 115:
																																	goto IL_0377;
																																case 65:
																																case 75:
																																	goto IL_0382;
																																case 92:
																																case 113:
																																	goto IL_0392;
																																case 129:
																																	goto IL_03ae;
																																case 101:
																																case 135:
																																	goto IL_03bc;
																																case 102:
																																	goto IL_041e;
																																case 73:
																																case 146:
																																	goto IL_0431;
																																case 16:
																																	goto IL_043f;
																																case 22:
																																	goto IL_045c;
																																case 140:
																																	goto IL_046a;
																																case 142:
																																	goto IL_047d;
																																case 97:
																																	goto IL_0494;
																																case 99:
																																case 147:
																																	goto IL_04a7;
																																case 114:
																																	goto IL_04b5;
																																case 84:
																																case 100:
																																	goto IL_04c3;
																																case 143:
																																	goto IL_0507;
																																case 127:
																																	goto IL_0524;
																																case 87:
																																case 123:
																																	goto IL_0537;
																																case 93:
																																	goto IL_0577;
																																case 105:
																																	goto IL_058b;
																																case 82:
																																	goto IL_059e;
																																case 57:
																																case 67:
																																	goto IL_05ac;
																																case 52:
																																	goto IL_05ba;
																																case 94:
																																case 119:
																																	goto IL_05c5;
																																case 122:
																																	goto IL_05e3;
																																case 47:
																																	goto IL_05f1;
																																case 107:
																																	goto IL_0604;
																																case 59:
																																case 116:
																																	goto IL_060f;
																																case 131:
																																	goto IL_061d;
																																case 0:
																																case 61:
																																	goto IL_062b;
																																case 41:
																																	goto IL_0654;
																																case 38:
																																	goto IL_0676;
																																case 20:
																																case 25:
																																	goto IL_0681;
																																case 71:
																																	goto IL_0698;
																																case 66:
																																case 104:
																																	goto IL_06a6;
																																case 86:
																																	goto IL_06bf;
																																case 126:
																																	goto IL_06cd;
																																case 45:
																																	goto IL_06db;
																																case 58:
																																case 117:
																																	goto IL_06ee;
																																case 19:
																																	goto IL_072e;
																																case 62:
																																	goto IL_074b;
																																case 139:
																																	goto IL_0767;
																																case 9:
																																case 14:
																																	goto IL_0772;
																																case 111:
																																	goto IL_0780;
																																case 85:
																																case 145:
																																	goto IL_078e;
																																case 6:
																																	goto IL_07b7;
																																case 137:
																																	goto IL_07ce;
																																case 63:
																																	goto IL_07e1;
																																case 83:
																																	goto IL_07ec;
																																case 80:
																																	goto IL_07fa;
																																case 34:
																																case 81:
																																	goto IL_0808;
																																case 120:
																																	goto IL_0816;
																																case 118:
																																	goto IL_0837;
																																case 133:
																																	goto IL_0845;
																																case 29:
																																case 49:
																																	goto IL_0861;
																																case 144:
																																	goto IL_08a9;
																																case 4:
																																case 12:
																																	goto IL_08b9;
																																case 10:
																																case 13:
																																case 24:
																																case 30:
																																case 36:
																																case 43:
																																case 44:
																																case 53:
																																case 54:
																																case 60:
																																case 69:
																																case 70:
																																case 74:
																																case 77:
																																case 79:
																																case 88:
																																case 90:
																																case 98:
																																case 103:
																																case 106:
																																case 108:
																																case 112:
																																case 124:
																																case 125:
																																case 132:
																																case 136:
																																case 138:
																																	goto end_IL_032b;
																																case 7:
																																case 8:
																																case 18:
																																case 21:
																																case 28:
																																case 35:
																																case 48:
																																case 50:
																																case 55:
																																case 56:
																																case 78:
																																case 89:
																																case 95:
																																case 110:
																																case 128:
																																case 141:
																																case 148:
																																case 149:
																																	goto end_IL_035e;
																																case 76:
																																	goto end_IL_08e1;
																																case 46:
																																	goto end_IL_08f4;
																																case 109:
																																	goto end_IL_08fe;
																																case 37:
																																	goto end_IL_0909;
																																case 64:
																																case 91:
																																	goto end_IL_0919;
																																case 1:
																																	goto end_IL_0929;
																																case 15:
																																case 51:
																																	goto end_IL_0939;
																																case 39:
																																	goto end_IL_0952;
																																case 40:
																																	goto end_IL_0962;
																																case 72:
																																case 121:
																																	goto IL_097d;
																																}
																																continue;
																															}
																															array2[num5] = null;
																															goto IL_045c;
																															IL_045c:
																															num5++;
																															goto IL_046a;
																															IL_046a:
																															ptr2 += 8;
																															goto end_IL_035e;
																															continue;
																															end_IL_028d:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_047d;
																											IL_0494:
																											if (9 <= b)
																											{
																												goto end_IL_035e;
																											}
																											goto end_IL_032b;
																											IL_047d:
																											if (9 < b)
																											{
																												goto end_IL_032b;
																											}
																											num = 97;
																											goto IL_0494;
																										}
																										break;
																									}
																									goto IL_04a7;
																									IL_0524:
																									num5--;
																									goto end_IL_035e;
																									IL_04a7:
																									if (11 < b)
																									{
																										goto end_IL_032b;
																									}
																									goto IL_04b5;
																									IL_04b5:
																									if (11 > b)
																									{
																										goto end_IL_032b;
																									}
																									goto IL_04c3;
																									IL_04c3:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_0507;
																									IL_0507:
																									array[num5 - 2] = 0;
																									num = 127;
																									goto IL_0524;
																								}
																								break;
																							}
																							goto IL_0537;
																							IL_058b:
																							num5--;
																							goto end_IL_035e;
																							IL_0537:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0577;
																							IL_0577:
																							array[num5 - 2] = 0;
																							goto IL_058b;
																						}
																						break;
																					}
																					goto IL_0369;
																					IL_043f:
																					if (15 <= b)
																					{
																					}
																					goto end_IL_032b;
																					IL_0369:
																					if (14 >= b)
																					{
																						goto IL_0377;
																					}
																					goto IL_0431;
																					IL_0377:
																					if (14 > b)
																					{
																						goto IL_0382;
																					}
																					goto IL_0392;
																					IL_0382:
																					if (13 < b)
																					{
																						goto end_IL_032b;
																					}
																					goto IL_03ae;
																					IL_03ae:
																					if (13 > b)
																					{
																						goto end_IL_032b;
																					}
																					goto IL_03bc;
																					IL_03bc:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_041e;
																					IL_041e:
																					num5 -= 2;
																					goto end_IL_035e;
																					IL_0392:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_035e;
																					IL_0431:
																					if (15 < b)
																					{
																						goto end_IL_032b;
																					}
																					goto IL_043f;
																				}
																				break;
																			}
																			goto IL_059e;
																			IL_08a9:
																			num5 -= 3;
																			goto end_IL_035e;
																			IL_059e:
																			if (8 > b)
																			{
																				goto IL_05ac;
																			}
																			goto IL_08b9;
																			IL_05ac:
																			if (4 >= b)
																			{
																				goto IL_05ba;
																			}
																			goto IL_0767;
																			IL_05ba:
																			if (4 <= b)
																			{
																				goto IL_05c5;
																			}
																			goto IL_0604;
																			IL_05c5:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_05e3;
																			IL_05e3:
																			ptr2 += 8;
																			goto IL_05f1;
																			IL_05f1:
																			num5--;
																			goto end_IL_035e;
																			IL_0604:
																			if (2 < b)
																			{
																				goto IL_060f;
																			}
																			goto IL_0676;
																			IL_060f:
																			if (3 < b)
																			{
																				goto end_IL_032b;
																			}
																			goto IL_061d;
																			IL_061d:
																			if (3 > b)
																			{
																				goto end_IL_032b;
																			}
																			goto IL_062b;
																			IL_062b:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0654;
																			IL_0654:
																			array[num5 - 1] = 5;
																			num = 8;
																			goto end_IL_035e;
																			IL_0676:
																			if (2 > b)
																			{
																				goto IL_0681;
																			}
																			goto IL_06ee;
																			IL_0681:
																			if (1 < b)
																			{
																				goto end_IL_032b;
																			}
																			num = 71;
																			goto IL_0698;
																			IL_08b9:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_035e;
																			IL_0698:
																			if (1 > b)
																			{
																				goto end_IL_032b;
																			}
																			goto IL_06a6;
																			IL_06a6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_06bf;
																			IL_06bf:
																			array[num5] = 0;
																			goto IL_06cd;
																			IL_06cd:
																			num5++;
																			goto IL_06db;
																			IL_06db:
																			ptr2 += 8;
																			goto end_IL_035e;
																			IL_06ee:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_072e;
																			IL_072e:
																			array[num5 - 2] = 0;
																			num = 62;
																			goto IL_074b;
																			IL_074b:
																			num5--;
																			num = 55;
																			goto end_IL_035e;
																			IL_0767:
																			if (6 < b)
																			{
																				goto IL_0772;
																			}
																			goto IL_07e1;
																			IL_0772:
																			if (7 < b)
																			{
																				goto end_IL_032b;
																			}
																			goto IL_0780;
																			IL_0780:
																			if (7 > b)
																			{
																				goto end_IL_032b;
																			}
																			goto IL_078e;
																			IL_078e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07b7;
																			IL_07b7:
																			ptr2 += 8;
																			num = 137;
																			goto IL_07ce;
																			IL_07ce:
																			num5--;
																			goto end_IL_035e;
																			IL_07e1:
																			if (6 > b)
																			{
																				goto IL_07ec;
																			}
																			goto IL_0861;
																			IL_07ec:
																			if (5 < b)
																			{
																				goto end_IL_032b;
																			}
																			goto IL_07fa;
																			IL_07fa:
																			if (5 > b)
																			{
																				goto end_IL_032b;
																			}
																			goto IL_0808;
																			IL_0808:
																			array[num5] = 5;
																			goto IL_0816;
																			IL_0816:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			num = 118;
																			goto IL_0837;
																			IL_0837:
																			num5++;
																			goto IL_0845;
																			IL_0845:
																			ptr2 += 8;
																			num = 95;
																			goto end_IL_035e;
																			IL_0861:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 144;
																			goto IL_08a9;
																		}
																		continue;
																		end_IL_032b:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_035e;
																continue;
																end_IL_033e:
																break;
															}
															continue;
															end_IL_034e:
															break;
														}
														continue;
														end_IL_035e:
														break;
													}
													continue;
												}
												goto IL_097d;
												IL_097d:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08e1:
												break;
											}
											continue;
											end_IL_08f4:
											break;
										}
										continue;
										end_IL_08fe:
										break;
									}
									continue;
									end_IL_0909:
									break;
								}
								continue;
								end_IL_0919:
								break;
							}
							continue;
							end_IL_0929:
							break;
						}
						continue;
						end_IL_0939:
						break;
					}
					continue;
					end_IL_0952:
					break;
				}
				continue;
				end_IL_0962:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_2)
	{
		int num = 23;
		byte* ptr2 = default(byte*);
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 20;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TypeInitializerPrivateBinPathValue.METHODSTOSKIPITypeLibConverter);
											num = 116;
											while (true)
											{
												if (num != 116)
												{
													if (num != 1097)
													{
														goto IL_048a;
													}
													switch (num)
													{
													case 87:
														goto end_IL_01df;
													case 77:
														goto end_IL_01f2;
													case 74:
														goto end_IL_0206;
													case 20:
														goto end_IL_021b;
													case 78:
														goto end_IL_022b;
													case 65:
														goto end_IL_023b;
													case 34:
													case 58:
														goto end_IL_0246;
													case 22:
														goto end_IL_0256;
													case 23:
														goto end_IL_0266;
													case 3:
													case 4:
													case 9:
													case 11:
													case 16:
													case 25:
													case 27:
													case 39:
													case 53:
													case 82:
													case 95:
													case 102:
													case 105:
														goto IL_0289;
													case 59:
													case 107:
														goto IL_0299;
													case 18:
														goto IL_02a2;
													case 101:
														goto IL_02b0;
													case 32:
														goto IL_02be;
													case 92:
														goto IL_02cc;
													case 15:
														goto IL_02da;
													case 43:
													case 90:
														goto IL_02e8;
													case 52:
														goto IL_02f6;
													case 24:
													case 97:
														goto IL_0301;
													case 57:
														goto IL_030f;
													case 93:
													case 98:
														goto IL_031d;
													case 81:
														goto IL_0336;
													case 36:
														goto IL_0344;
													case 8:
														goto IL_0352;
													case 41:
													case 100:
														goto IL_0365;
													case 37:
														goto IL_038e;
													case 13:
														goto IL_039c;
													case 28:
														goto IL_03af;
													case 0:
													case 62:
														goto IL_03ba;
													case 1:
														goto IL_03c8;
													case 44:
														goto IL_03db;
													case 45:
													case 79:
														goto IL_03e9;
													case 6:
													case 63:
														goto IL_0401;
													case 73:
														goto IL_040f;
													case 7:
														goto IL_043b;
													case 35:
														goto IL_0445;
													case 72:
														goto IL_0453;
													case 51:
														goto IL_0466;
													case 42:
													case 99:
														goto IL_0471;
													case 80:
													case 109:
														goto IL_047c;
													case 17:
														goto IL_048a;
													case 21:
														goto IL_049d;
													case 86:
													case 91:
														goto IL_04ab;
													case 19:
														goto IL_04c7;
													case 61:
													case 108:
														goto IL_04d5;
													case 55:
													case 94:
														goto IL_04e0;
													case 48:
														goto IL_04ee;
													case 46:
													case 69:
														goto IL_04fc;
													case 40:
														goto IL_0528;
													case 67:
														goto IL_0536;
													case 96:
														goto IL_0544;
													case 26:
														goto IL_0557;
													case 33:
													case 38:
														goto IL_0565;
													case 64:
														goto IL_05a5;
													case 60:
														goto IL_05c2;
													case 68:
													case 88:
														goto IL_05d5;
													case 56:
														goto IL_0637;
													case 2:
													case 5:
													case 10:
													case 12:
													case 14:
													case 29:
													case 30:
													case 31:
													case 47:
													case 49:
													case 50:
													case 66:
													case 70:
													case 71:
													case 75:
													case 83:
													case 84:
													case 85:
													case 89:
													case 103:
													case 104:
													case 106:
														goto IL_0653;
													case 54:
													case 76:
														goto IL_0674;
													}
													continue;
												}
												ptr2 = ptr;
												goto IL_0289;
												IL_05c2:
												num4--;
												goto IL_0289;
												IL_0637:
												num4 -= 2;
												num = 16;
												goto IL_0289;
												IL_05d5:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0637;
												IL_0289:
												if (num5 != 1)
												{
													goto IL_0299;
												}
												num = 54;
												goto IL_0674;
												IL_0653:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0289;
												IL_0674:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												IL_0299:
												b = *ptr2;
												goto IL_02a2;
												IL_02a2:
												ptr2++;
												goto IL_02b0;
												IL_02b0:
												if (b >= 1)
												{
													goto IL_02be;
												}
												goto IL_0653;
												IL_02be:
												if (b <= 10)
												{
													goto IL_02cc;
												}
												goto IL_0653;
												IL_02cc:
												if (5 >= b)
												{
													goto IL_02da;
												}
												goto IL_0466;
												IL_02da:
												if (5 > b)
												{
													goto IL_02e8;
												}
												goto IL_0401;
												IL_02e8:
												if (2 >= b)
												{
													goto IL_02f6;
												}
												goto IL_03af;
												IL_02f6:
												if (2 > b)
												{
													goto IL_0301;
												}
												goto IL_0365;
												IL_0301:
												if (1 >= b)
												{
													goto IL_030f;
												}
												goto IL_0653;
												IL_030f:
												if (1 <= b)
												{
													goto IL_031d;
												}
												goto IL_0653;
												IL_031d:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = *(int*)(ptr2 + num3);
												goto IL_0336;
												IL_0336:
												array[num4] = 0;
												goto IL_0344;
												IL_0344:
												num4++;
												goto IL_0352;
												IL_0352:
												ptr2 += 8;
												goto IL_0289;
												IL_0365:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_038e;
												IL_038e:
												ptr2 += 8;
												goto IL_039c;
												IL_039c:
												num4--;
												goto IL_0289;
												IL_03af:
												if (3 < b)
												{
													goto IL_03ba;
												}
												goto IL_03db;
												IL_03ba:
												if (4 >= b)
												{
													goto IL_03c8;
												}
												goto IL_0653;
												IL_03c8:
												if (4 <= b)
												{
													goto IL_0289;
												}
												goto IL_0653;
												IL_03db:
												if (3 <= b)
												{
													goto IL_03e9;
												}
												goto IL_0653;
												IL_03e9:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_0289;
												IL_0401:
												array[num4] = 0;
												goto IL_040f;
												IL_040f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												num = 7;
												goto IL_043b;
												IL_043b:
												array2[num4] = null;
												goto IL_0445;
												IL_0445:
												num4++;
												goto IL_0453;
												IL_0453:
												ptr2 += 8;
												goto IL_0289;
												IL_0466:
												if (8 < b)
												{
													goto IL_0471;
												}
												goto IL_04c7;
												IL_0471:
												if (9 < b)
												{
													goto IL_047c;
												}
												goto IL_049d;
												IL_047c:
												if (10 >= b)
												{
													goto IL_048a;
												}
												goto IL_0653;
												IL_048a:
												if (10 <= b)
												{
												}
												goto IL_0653;
												IL_049d:
												if (9 <= b)
												{
													goto IL_04ab;
												}
												goto IL_0653;
												IL_04ab:
												byte* num6 = ptr2;
												num5 = 1;
												ptr2 = num6 + -200;
												goto IL_0289;
												IL_04c7:
												if (8 > b)
												{
													goto IL_04d5;
												}
												goto IL_05d5;
												IL_04d5:
												if (6 < b)
												{
													goto IL_04e0;
												}
												goto IL_0557;
												IL_04e0:
												if (7 >= b)
												{
													goto IL_04ee;
												}
												goto IL_0653;
												IL_04ee:
												if (7 <= b)
												{
													goto IL_04fc;
												}
												goto IL_0653;
												IL_04fc:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
												num = 40;
												goto IL_0528;
												IL_0528:
												array[num4] = 0;
												goto IL_0536;
												IL_0536:
												num4++;
												goto IL_0544;
												IL_0544:
												ptr2 += 8;
												goto IL_0289;
												IL_0557:
												if (6 <= b)
												{
													goto IL_0565;
												}
												goto IL_0653;
												IL_0565:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
												goto IL_05a5;
												IL_05a5:
												array[num4 - 2] = 0;
												num = 60;
												goto IL_05c2;
												continue;
												end_IL_01df:
												break;
											}
											continue;
											end_IL_01f2:
											break;
										}
										continue;
										end_IL_0206:
										break;
									}
									continue;
									end_IL_021b:
									break;
								}
								continue;
								end_IL_022b:
								break;
							}
							continue;
							end_IL_023b:
							break;
						}
						continue;
						end_IL_0246:
						break;
					}
					continue;
					end_IL_0256:
					break;
				}
				continue;
				end_IL_0266:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 36;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetInteropFieldTypeAndNameFromXmlAttributeBITONLY.getIsBrowserSaveModifyAccessRule);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02fc:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			if (8 >= b)
																			{
																				while (true)
																				{
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02bf:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02ac:
																									if (6 < b)
																									{
																										num = 159;
																										while (true)
																										{
																											if (num != 159)
																											{
																												if (num != 1140)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 32:
																													goto IL_02ac;
																												case 3:
																												case 50:
																													goto IL_02bf;
																												case 146:
																													goto end_IL_02bf;
																												case 14:
																													goto end_IL_02cf;
																												case 120:
																													goto end_IL_02df;
																												case 41:
																													goto IL_02fc;
																												case 80:
																													goto end_IL_02fc;
																												case 13:
																												case 17:
																													goto end_IL_030c;
																												case 23:
																												case 100:
																													goto IL_0327;
																												case 78:
																													goto IL_0335;
																												case 103:
																													goto IL_0345;
																												case 65:
																												case 83:
																													goto IL_0353;
																												case 59:
																													goto IL_039b;
																												case 101:
																												case 125:
																													goto IL_03ae;
																												case 27:
																													goto IL_03b9;
																												case 33:
																												case 112:
																													goto IL_03c7;
																												case 30:
																													goto IL_03d5;
																												case 88:
																													goto IL_03f8;
																												case 29:
																													goto IL_0402;
																												case 70:
																													goto IL_0410;
																												case 133:
																													goto IL_0423;
																												case 109:
																													goto IL_0431;
																												case 60:
																												case 118:
																													goto IL_043f;
																												case 136:
																													goto IL_0488;
																												case 31:
																												case 90:
																													goto IL_0496;
																												case 124:
																													goto IL_04a4;
																												case 104:
																												case 107:
																													goto IL_04af;
																												case 48:
																													goto IL_04bd;
																												case 51:
																												case 132:
																													goto IL_04cb;
																												case 74:
																													goto IL_04e4;
																												case 82:
																												case 127:
																													goto IL_04f7;
																												case 108:
																													goto IL_0537;
																												case 130:
																													goto IL_054b;
																												case 9:
																												case 22:
																													goto end_IL_0299;
																												case 15:
																													goto IL_057c;
																												case 96:
																													goto IL_058a;
																												case 7:
																												case 140:
																													goto IL_059d;
																												case 87:
																													goto IL_05dd;
																												case 12:
																													goto IL_05fa;
																												case 141:
																													goto IL_060d;
																												case 91:
																												case 92:
																													goto IL_0618;
																												case 81:
																													goto IL_0626;
																												case 5:
																													goto IL_0639;
																												case 105:
																												case 114:
																													goto IL_0644;
																												case 26:
																													goto IL_0660;
																												case 131:
																													goto IL_066e;
																												case 1:
																												case 76:
																													goto IL_067c;
																												case 67:
																													goto IL_06de;
																												case 143:
																													goto IL_06f1;
																												case 134:
																													goto IL_0705;
																												case 144:
																													goto IL_0718;
																												case 84:
																													goto IL_0726;
																												case 145:
																													goto IL_0742;
																												case 89:
																													goto IL_074d;
																												case 64:
																												case 111:
																													goto IL_075b;
																												case 56:
																													goto IL_0784;
																												case 95:
																												case 150:
																													goto IL_07ab;
																												case 94:
																													goto IL_07b9;
																												case 151:
																													goto IL_07cc;
																												case 0:
																													goto IL_07da;
																												case 69:
																												case 75:
																													goto IL_07e8;
																												case 128:
																													goto IL_07ff;
																												case 71:
																													goto IL_0817;
																												case 152:
																													goto IL_0825;
																												case 148:
																													goto IL_0838;
																												case 97:
																													goto IL_0843;
																												case 72:
																												case 93:
																													goto IL_084e;
																												case 149:
																													goto IL_0877;
																												case 139:
																													goto IL_0885;
																												case 39:
																												case 135:
																													goto IL_0895;
																												case 2:
																												case 4:
																												case 6:
																												case 10:
																												case 11:
																												case 21:
																												case 24:
																												case 34:
																												case 37:
																												case 38:
																												case 42:
																												case 49:
																												case 52:
																												case 53:
																												case 54:
																												case 57:
																												case 58:
																												case 61:
																												case 63:
																												case 73:
																												case 77:
																												case 85:
																												case 86:
																												case 99:
																												case 102:
																												case 116:
																												case 122:
																												case 126:
																												case 129:
																												case 137:
																												case 138:
																													goto end_IL_02ec;
																												case 8:
																												case 19:
																												case 20:
																												case 40:
																												case 43:
																												case 44:
																												case 46:
																												case 47:
																												case 62:
																												case 79:
																												case 98:
																												case 106:
																												case 110:
																												case 113:
																												case 115:
																												case 117:
																												case 123:
																												case 147:
																													goto end_IL_031c;
																												case 16:
																													goto end_IL_08c6;
																												case 119:
																													goto end_IL_08d9;
																												case 45:
																													goto end_IL_08e3;
																												case 55:
																													goto end_IL_08ee;
																												case 68:
																												case 142:
																													goto end_IL_08fe;
																												case 66:
																													goto end_IL_090e;
																												case 18:
																												case 25:
																													goto end_IL_091e;
																												case 35:
																													goto end_IL_092e;
																												case 36:
																													goto end_IL_093e;
																												case 28:
																												case 121:
																													goto IL_0959;
																												}
																												continue;
																											}
																											goto IL_0838;
																											IL_0877:
																											ptr2 += 8;
																											goto IL_0885;
																											IL_0885:
																											num5--;
																											goto end_IL_031c;
																											IL_0838:
																											if (7 < b)
																											{
																												goto end_IL_02ec;
																											}
																											goto IL_0843;
																											IL_0843:
																											if (7 > b)
																											{
																												goto end_IL_02ec;
																											}
																											goto IL_084e;
																											IL_084e:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0877;
																											continue;
																											end_IL_0299:
																											break;
																										}
																										break;
																									}
																									goto IL_0345;
																									IL_0817:
																									num5++;
																									goto IL_0825;
																									IL_0825:
																									ptr2 += 8;
																									goto end_IL_031c;
																									IL_0345:
																									if (6 <= b)
																									{
																										goto IL_0353;
																									}
																									goto IL_07cc;
																									IL_0353:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 59;
																									goto IL_039b;
																									IL_039b:
																									num5 -= 3;
																									goto end_IL_031c;
																									IL_07cc:
																									if (5 < b)
																									{
																										goto end_IL_02ec;
																									}
																									goto IL_07da;
																									IL_07da:
																									if (5 > b)
																									{
																										goto end_IL_02ec;
																									}
																									goto IL_07e8;
																									IL_07e8:
																									array[num5] = 5;
																									num = 128;
																									goto IL_07ff;
																									IL_07ff:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_0817;
																								}
																								goto IL_055e;
																							}
																							goto IL_0488;
																							IL_057c:
																							ptr2 += 8;
																							goto IL_058a;
																							IL_0488:
																							if (4 > b)
																							{
																								goto IL_0496;
																							}
																							goto IL_055e;
																							IL_0496:
																							if (2 >= b)
																							{
																								goto IL_04a4;
																							}
																							goto IL_0742;
																							IL_04a4:
																							if (2 > b)
																							{
																								goto IL_04af;
																							}
																							goto IL_04f7;
																							IL_04af:
																							if (1 < b)
																							{
																								goto end_IL_02ec;
																							}
																							goto IL_04bd;
																							IL_04bd:
																							if (1 > b)
																							{
																								goto end_IL_02ec;
																							}
																							goto IL_04cb;
																							IL_04cb:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_04e4;
																							IL_04e4:
																							array[num5] = 0;
																							goto IL_0718;
																							IL_0718:
																							num5++;
																							goto IL_0726;
																							IL_0726:
																							ptr2 += 8;
																							num = 19;
																							goto end_IL_031c;
																							IL_04f7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0537;
																							IL_0537:
																							array[num5 - 2] = 0;
																							goto IL_054b;
																							IL_054b:
																							num5--;
																							goto end_IL_031c;
																							IL_0742:
																							if (3 < b)
																							{
																								num = 37;
																								goto end_IL_02ec;
																							}
																							goto IL_074d;
																							IL_074d:
																							if (3 > b)
																							{
																								goto end_IL_02ec;
																							}
																							goto IL_075b;
																							IL_075b:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_0784;
																							IL_0784:
																							array[num5 - 1] = 5;
																							goto end_IL_031c;
																							IL_058a:
																							num5--;
																							goto end_IL_031c;
																							IL_055e:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_057c;
																							continue;
																							end_IL_02bf:
																							break;
																						}
																						continue;
																					}
																					goto IL_0895;
																					IL_0895:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_031c;
																					continue;
																					end_IL_02cf:
																					break;
																				}
																				continue;
																			}
																			goto IL_0327;
																			IL_06de:
																			num5 -= 2;
																			goto end_IL_031c;
																			IL_0327:
																			if (12 >= b)
																			{
																				goto IL_0335;
																			}
																			goto IL_060d;
																			IL_0335:
																			if (12 > b)
																			{
																				goto IL_03ae;
																			}
																			goto IL_059d;
																			IL_03ae:
																			if (10 >= b)
																			{
																				goto IL_03b9;
																			}
																			goto IL_0423;
																			IL_03b9:
																			if (10 <= b)
																			{
																				goto IL_03c7;
																			}
																			goto IL_07ab;
																			IL_03c7:
																			array[num5] = 0;
																			goto IL_03d5;
																			IL_03d5:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03f8;
																			IL_03f8:
																			array2[num5] = null;
																			goto IL_0402;
																			IL_0402:
																			num5++;
																			goto IL_0410;
																			IL_0410:
																			ptr2 += 8;
																			goto end_IL_031c;
																			IL_07ab:
																			if (9 < b)
																			{
																				goto end_IL_02ec;
																			}
																			goto IL_07b9;
																			IL_07b9:
																			if (9 > b)
																			{
																				goto end_IL_02ec;
																			}
																			goto end_IL_031c;
																			IL_0423:
																			if (11 < b)
																			{
																				goto end_IL_02ec;
																			}
																			goto IL_0431;
																			IL_0431:
																			if (11 > b)
																			{
																				goto end_IL_02ec;
																			}
																			goto IL_043f;
																			IL_043f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06f1;
																			IL_06f1:
																			array[num5 - 2] = 0;
																			goto IL_0705;
																			IL_0705:
																			num5--;
																			goto end_IL_031c;
																			IL_059d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05dd;
																			IL_05dd:
																			array[num5 - 2] = 0;
																			num = 12;
																			goto IL_05fa;
																			IL_05fa:
																			num5--;
																			goto end_IL_031c;
																			IL_060d:
																			if (14 < b)
																			{
																				goto IL_0618;
																			}
																			goto IL_0639;
																			IL_0618:
																			if (15 < b)
																			{
																				goto end_IL_02ec;
																			}
																			goto IL_0626;
																			IL_0626:
																			if (15 > b)
																			{
																			}
																			goto end_IL_02ec;
																			IL_0639:
																			if (14 <= b)
																			{
																				goto IL_0644;
																			}
																			goto IL_0660;
																			IL_0644:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_031c;
																			IL_0660:
																			if (13 < b)
																			{
																				goto end_IL_02ec;
																			}
																			goto IL_066e;
																			IL_066e:
																			if (13 > b)
																			{
																				goto end_IL_02ec;
																			}
																			goto IL_067c;
																			IL_067c:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06de;
																			continue;
																			end_IL_02df:
																			break;
																		}
																		continue;
																		end_IL_02ec:
																		break;
																	}
																}
																else
																{
																	num = 10;
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_031c;
																continue;
																end_IL_02fc:
																break;
															}
															continue;
															end_IL_030c:
															break;
														}
														continue;
														end_IL_031c:
														break;
													}
													continue;
												}
												goto IL_0959;
												IL_0959:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c6:
												break;
											}
											continue;
											end_IL_08d9:
											break;
										}
										continue;
										end_IL_08e3:
										break;
									}
									continue;
									end_IL_08ee:
									break;
								}
								continue;
								end_IL_08fe:
								break;
							}
							continue;
							end_IL_090e:
							break;
						}
						continue;
						end_IL_091e:
						break;
					}
					continue;
					end_IL_092e:
					break;
				}
				continue;
				end_IL_093e:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 45;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getMaximumConcurrencyLevelgetBaseStream.InformationalVersiongetCurrentSize);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0266:
															byte b = *ptr2;
															while (true)
															{
																IL_0256:
																ptr2++;
																while (true)
																{
																	IL_0246:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0226:
																				if (4 >= b)
																				{
																					num = 27;
																					while (true)
																					{
																						IL_0213:
																						if (4 <= b)
																						{
																							num = 26;
																							while (true)
																							{
																								IL_01e8:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								while (true)
																								{
																									IL_01cf:
																									ptr2 += 8;
																									num = 79;
																									while (true)
																									{
																										IL_01b6:
																										num5--;
																										num = 94;
																										while (num != 94)
																										{
																											if (num != 1075)
																											{
																												goto IL_05de;
																											}
																											switch (num)
																											{
																											case 79:
																												goto IL_01b6;
																											case 63:
																												goto IL_01cf;
																											case 4:
																											case 26:
																												goto IL_01e8;
																											case 27:
																												goto IL_0213;
																											case 44:
																												goto IL_0226;
																											case 87:
																												goto IL_0236;
																											case 0:
																												goto IL_0246;
																											case 60:
																												goto IL_0256;
																											case 12:
																											case 13:
																												goto IL_0266;
																											case 53:
																												goto IL_0271;
																											case 14:
																												goto IL_027c;
																											case 41:
																												goto IL_0287;
																											case 8:
																											case 37:
																												goto IL_0295;
																											case 51:
																												goto IL_02a5;
																											case 62:
																												goto IL_02b5;
																											case 67:
																												goto IL_02c5;
																											case 1:
																											case 76:
																												goto IL_02d8;
																											case 19:
																												goto IL_02e6;
																											case 30:
																											case 73:
																												goto IL_02f4;
																											case 77:
																												goto IL_030c;
																											case 56:
																												goto IL_0338;
																											case 21:
																												goto IL_0342;
																											case 71:
																												goto IL_0350;
																											case 33:
																											case 82:
																												goto IL_0363;
																											case 40:
																												goto IL_037f;
																											case 2:
																												goto IL_038d;
																											case 80:
																												goto IL_039b;
																											case 61:
																											case 65:
																												goto IL_03a9;
																											case 57:
																												goto IL_03e9;
																											case 47:
																												goto IL_0406;
																											case 29:
																												goto IL_042b;
																											case 17:
																											case 42:
																												goto IL_0436;
																											case 81:
																												goto IL_0444;
																											case 66:
																											case 69:
																												goto IL_0454;
																											case 36:
																												goto IL_04c2;
																											case 5:
																											case 6:
																											case 10:
																											case 11:
																											case 15:
																											case 16:
																											case 18:
																											case 20:
																											case 31:
																											case 46:
																											case 48:
																											case 54:
																											case 58:
																											case 64:
																											case 75:
																											case 83:
																											case 85:
																												goto end_IL_0236;
																											case 68:
																												goto IL_04f5;
																											case 52:
																												goto IL_0503;
																											case 9:
																												goto IL_051a;
																											case 3:
																											case 7:
																											case 23:
																											case 24:
																											case 28:
																											case 35:
																											case 43:
																											case 49:
																											case 70:
																											case 74:
																												goto end_IL_01a3;
																											case 55:
																												goto end_IL_0528;
																											case 84:
																												goto end_IL_053b;
																											case 50:
																												goto end_IL_0545;
																											case 32:
																												goto end_IL_0550;
																											case 45:
																												goto end_IL_0565;
																											case 25:
																											case 59:
																												goto end_IL_057a;
																											case 86:
																												goto end_IL_058a;
																											case 72:
																											case 78:
																												goto end_IL_05a3;
																											case 38:
																												goto end_IL_05b3;
																											case 39:
																												goto end_IL_05c3;
																											case 22:
																											case 34:
																												goto IL_05de;
																											}
																											continue;
																											end_IL_01a3:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_037f;
																						IL_0444:
																						if (1 > b)
																						{
																						}
																						goto end_IL_0236;
																						IL_0454:
																						ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_04c2;
																						IL_037f:
																						if (2 < b)
																						{
																							goto IL_038d;
																						}
																						num = 29;
																						goto IL_042b;
																						IL_038d:
																						if (3 < b)
																						{
																							goto end_IL_0236;
																						}
																						goto IL_039b;
																						IL_039b:
																						if (3 > b)
																						{
																							goto end_IL_0236;
																						}
																						goto IL_03a9;
																						IL_03a9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_03e9;
																						IL_03e9:
																						array[num5 - 2] = 0;
																						num = 47;
																						goto IL_0406;
																						IL_0406:
																						num5--;
																						num = 43;
																						break;
																						IL_04c2:
																						num5 -= 2;
																						break;
																						IL_042b:
																						if (2 > b)
																						{
																							goto IL_0436;
																						}
																						goto IL_0454;
																						IL_0436:
																						if (1 < b)
																						{
																							goto end_IL_0236;
																						}
																						goto IL_0444;
																					}
																					break;
																				}
																				goto IL_0271;
																				IL_02e6:
																				if (5 > b)
																				{
																					goto end_IL_0236;
																				}
																				goto IL_02f4;
																				IL_02f4:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				break;
																				IL_0271:
																				if (6 < b)
																				{
																					goto IL_027c;
																				}
																				goto IL_02b5;
																				IL_027c:
																				if (7 >= b)
																				{
																					goto IL_0287;
																				}
																				goto IL_02a5;
																				IL_0287:
																				if (7 > b)
																				{
																					goto end_IL_0236;
																				}
																				goto IL_0295;
																				IL_0295:
																				array[num5] = 0;
																				goto IL_030c;
																				IL_030c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 56;
																				goto IL_0338;
																				IL_0338:
																				array2[num5] = null;
																				goto IL_0342;
																				IL_0342:
																				num5++;
																				goto IL_0350;
																				IL_0350:
																				ptr2 += 8;
																				break;
																				IL_02a5:
																				if (8 < b)
																				{
																					goto end_IL_0236;
																				}
																				goto IL_02c5;
																				IL_02c5:
																				if (8 > b)
																				{
																					goto end_IL_0236;
																				}
																				goto IL_0363;
																				IL_0363:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_02b5:
																				if (6 <= b)
																				{
																					break;
																				}
																				goto IL_02d8;
																				IL_02d8:
																				if (5 < b)
																				{
																					goto end_IL_0236;
																				}
																				goto IL_02e6;
																			}
																			goto end_IL_0246;
																			continue;
																			end_IL_0236:
																			break;
																			IL_0236:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04f5;
																	IL_051a:
																	ptr2 += 8;
																	break;
																	IL_0503:
																	num5++;
																	num = 9;
																	goto IL_051a;
																	IL_04f5:
																	array[num5] = 0;
																	goto IL_0503;
																	continue;
																	end_IL_0246:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05de;
													IL_05de:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0528:
													break;
												}
												continue;
												end_IL_053b:
												break;
											}
											continue;
											end_IL_0545:
											break;
										}
										continue;
										end_IL_0550:
										break;
									}
									continue;
									end_IL_0565:
									break;
								}
								continue;
								end_IL_057a:
								break;
							}
							continue;
							end_IL_058a:
							break;
						}
						continue;
						end_IL_05a3:
						break;
					}
					continue;
					end_IL_05b3:
					break;
				}
				continue;
				end_IL_05c3:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 39;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 51;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[5];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref APPXFLAGSINITIALIZEDCMSSECTIONIDFILESECTION.WriteExtendedAttributesgetConsistencyGuarantee);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0258:
																		if (b >= 1)
																		{
																			while (b <= 9)
																			{
																				while (true)
																				{
																					IL_023b:
																					if (5 >= b)
																					{
																						while (true)
																						{
																							IL_022b:
																							if (5 > b)
																							{
																								while (true)
																								{
																									IL_021b:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_020b:
																											if (2 > b)
																											{
																												while (1 >= b)
																												{
																													num = 114;
																													while (true)
																													{
																														if (num != 114)
																														{
																															if (num != 1095)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 65:
																															case 86:
																																goto IL_01f8;
																															case 49:
																																goto IL_020b;
																															case 48:
																															case 76:
																																goto IL_021b;
																															case 70:
																																goto IL_022b;
																															case 68:
																																goto IL_023b;
																															case 67:
																																goto IL_0248;
																															case 92:
																																goto IL_0258;
																															case 9:
																																goto end_IL_0258;
																															case 28:
																															case 83:
																																goto end_IL_0268;
																															case 21:
																															case 46:
																																goto IL_0283;
																															case 3:
																																goto IL_028e;
																															case 59:
																																goto IL_029e;
																															case 52:
																																goto IL_02a9;
																															case 54:
																															case 71:
																																goto IL_02bc;
																															case 25:
																																goto IL_02d5;
																															case 14:
																																goto IL_02e3;
																															case 15:
																																goto IL_02f1;
																															case 72:
																																goto IL_0304;
																															case 57:
																															case 61:
																																goto IL_0312;
																															case 11:
																																goto IL_0352;
																															case 82:
																																goto IL_036b;
																															case 29:
																																goto IL_0379;
																															case 5:
																															case 44:
																																goto IL_0387;
																															case 75:
																																goto IL_03c7;
																															case 79:
																																goto IL_03db;
																															case 16:
																															case 84:
																																goto IL_03ee;
																															case 13:
																																goto IL_042e;
																															case 74:
																																goto IL_0442;
																															case 89:
																																goto IL_0455;
																															case 12:
																															case 62:
																																goto IL_0463;
																															case 97:
																																goto IL_047f;
																															case 43:
																																goto IL_04a5;
																															case 31:
																																goto IL_04b0;
																															case 7:
																															case 58:
																																goto IL_04be;
																															case 23:
																																goto IL_04e7;
																															case 60:
																																goto IL_04f5;
																															case 37:
																															case 63:
																																goto IL_0511;
																															case 53:
																																goto IL_051f;
																															case 22:
																															case 85:
																																goto IL_052d;
																															case 90:
																																goto IL_056d;
																															case 41:
																																goto IL_0581;
																															case 96:
																															case 105:
																																goto IL_0594;
																															case 91:
																																goto IL_05a2;
																															case 101:
																																goto IL_05c5;
																															case 73:
																																goto IL_05cf;
																															case 26:
																																goto IL_05dd;
																															case 0:
																															case 1:
																															case 2:
																															case 4:
																															case 6:
																															case 10:
																															case 20:
																															case 33:
																															case 36:
																															case 40:
																															case 42:
																															case 45:
																															case 55:
																															case 56:
																															case 69:
																															case 93:
																															case 94:
																															case 95:
																															case 98:
																															case 103:
																															case 106:
																																goto end_IL_01e5;
																															case 77:
																																goto IL_0619;
																															case 47:
																																goto IL_0627;
																															case 104:
																																goto IL_0635;
																															case 18:
																															case 19:
																															case 30:
																															case 32:
																															case 34:
																															case 50:
																															case 66:
																															case 80:
																															case 81:
																															case 87:
																															case 102:
																																goto end_IL_0278;
																															case 64:
																																goto end_IL_0643;
																															case 100:
																																goto end_IL_0656;
																															case 88:
																																goto end_IL_0660;
																															case 99:
																																goto end_IL_066b;
																															case 17:
																																goto end_IL_0680;
																															case 8:
																															case 24:
																																goto end_IL_0695;
																															case 27:
																																goto end_IL_06a5;
																															case 51:
																																goto end_IL_06b5;
																															case 35:
																																goto end_IL_06c5;
																															case 38:
																																goto end_IL_06d5;
																															case 39:
																																goto end_IL_06e0;
																															case 78:
																															case 107:
																																goto IL_06fb;
																															}
																															continue;
																														}
																														if (1 <= b)
																														{
																														}
																														break;
																														continue;
																														end_IL_01e5:
																														break;
																													}
																													break;
																													IL_01f8:;
																												}
																												break;
																											}
																											goto IL_03ee;
																											IL_0442:
																											num5--;
																											goto end_IL_0278;
																											IL_03ee:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_042e;
																											IL_042e:
																											array[num5 - 2] = 0;
																											goto IL_0442;
																										}
																										break;
																									}
																									goto IL_04a5;
																									IL_056d:
																									array[num5 - 2] = 0;
																									goto IL_0581;
																									IL_04a5:
																									if (3 >= b)
																									{
																										goto IL_04b0;
																									}
																									num = 37;
																									goto IL_0511;
																									IL_04b0:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_04be;
																									IL_04be:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_04e7;
																									IL_04e7:
																									ptr2 += 8;
																									goto IL_04f5;
																									IL_04f5:
																									num5--;
																									goto end_IL_0278;
																									IL_0581:
																									num5--;
																									goto end_IL_0278;
																									IL_0511:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_051f;
																									IL_051f:
																									if (4 > b)
																									{
																										break;
																									}
																									goto IL_052d;
																									IL_052d:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_056d;
																								}
																								break;
																							}
																							goto IL_0594;
																							IL_05dd:
																							ptr2 += 8;
																							goto end_IL_0278;
																							IL_0594:
																							array[num5] = 0;
																							goto IL_05a2;
																							IL_05a2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_05c5;
																							IL_05c5:
																							array2[num5] = null;
																							goto IL_05cf;
																							IL_05cf:
																							num5++;
																							goto IL_05dd;
																						}
																						break;
																					}
																					goto IL_0283;
																					IL_047f:
																					num5--;
																					goto end_IL_0278;
																					IL_0283:
																					if (7 >= b)
																					{
																						goto IL_028e;
																					}
																					goto IL_029e;
																					IL_028e:
																					if (7 <= b)
																					{
																						goto IL_02bc;
																					}
																					goto IL_036b;
																					IL_02bc:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_02d5;
																					IL_02d5:
																					array[num5] = 0;
																					goto IL_02e3;
																					IL_02e3:
																					num5++;
																					goto IL_02f1;
																					IL_02f1:
																					ptr2 += 8;
																					goto end_IL_0278;
																					IL_036b:
																					if (6 < b)
																					{
																						break;
																					}
																					goto IL_0379;
																					IL_0379:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0387;
																					IL_0387:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_03c7;
																					IL_03c7:
																					array[num5 - 2] = 0;
																					goto IL_03db;
																					IL_03db:
																					num5--;
																					goto end_IL_0278;
																					IL_029e:
																					if (8 < b)
																					{
																						goto IL_02a9;
																					}
																					goto IL_0304;
																					IL_02a9:
																					if (9 < b)
																					{
																						break;
																					}
																					goto IL_0455;
																					IL_0455:
																					if (9 > b)
																					{
																						break;
																					}
																					goto IL_0463;
																					IL_0463:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0278;
																					IL_0304:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0312;
																					IL_0312:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0352;
																					IL_0352:
																					array[num5 - 2] = 0;
																					goto IL_047f;
																				}
																				break;
																				IL_0248:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 77;
																		goto IL_0619;
																		IL_0635:
																		ptr2 += 8;
																		goto end_IL_0278;
																		IL_0627:
																		num5++;
																		goto IL_0635;
																		IL_0619:
																		array[num5] = 0;
																		goto IL_0627;
																		continue;
																		end_IL_0258:
																		break;
																	}
																	continue;
																	end_IL_0268:
																	break;
																}
																continue;
																end_IL_0278:
																break;
															}
															continue;
														}
														goto IL_06fb;
														IL_06fb:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0643:
														break;
													}
													continue;
													end_IL_0656:
													break;
												}
												continue;
												end_IL_0660:
												break;
											}
											continue;
											end_IL_066b:
											break;
										}
										continue;
										end_IL_0680:
										break;
									}
									continue;
									end_IL_0695:
									break;
								}
								continue;
								end_IL_06a5:
								break;
							}
							continue;
							end_IL_06b5:
							break;
						}
						continue;
						end_IL_06c5:
						break;
					}
					continue;
					end_IL_06d5:
					break;
				}
				continue;
				end_IL_06e0:
				break;
			}
		}
	}

	private static int smethod_6(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		num += num2;
		int num3 = num;
		num = int_2;
		num2 = int_3;
		num *= num2;
		int num4 = num;
		num = num3;
		num2 = num4;
		num ^= num2;
		int num5 = num;
		num = num5;
		num2 = 264;
		num2 = 24;
		num += 24;
		num2 = 81;
		num2 = 27;
		int num6 = smethod_7(27);
		num2 = num6;
		return num;
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 28;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									num = 84;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref VararggetBackgroundColor.AssemblyIsolationByRoamingUsergetControlFlags);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02d1:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02b4:
																			if (7 >= b)
																			{
																				while (true)
																				{
																					IL_02a4:
																					if (7 > b)
																					{
																						while (true)
																						{
																							IL_0294:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_0287:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_0277:
																											if (1 < b)
																											{
																												while (2 >= b)
																												{
																													while (2 <= b)
																													{
																														num = 137;
																														while (true)
																														{
																															if (num != 137)
																															{
																																if (num != 1118)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 73:
																																	goto IL_0254;
																																case 101:
																																	goto IL_0267;
																																case 12:
																																case 124:
																																	goto IL_0277;
																																case 48:
																																	goto IL_0287;
																																case 44:
																																case 108:
																																	goto IL_0294;
																																case 21:
																																	goto IL_02a4;
																																case 69:
																																	goto IL_02b4;
																																case 54:
																																	goto IL_02c1;
																																case 16:
																																	goto IL_02d1;
																																case 11:
																																	goto end_IL_02d1;
																																case 38:
																																case 85:
																																	goto end_IL_02e1;
																																case 8:
																																case 22:
																																	goto IL_02fc;
																																case 74:
																																	goto IL_0314;
																																case 35:
																																case 77:
																																	goto IL_0327;
																																case 59:
																																	goto IL_0335;
																																case 32:
																																case 46:
																																	goto IL_0343;
																																case 64:
																																	goto IL_0357;
																																case 40:
																																	goto IL_03ab;
																																case 72:
																																	goto IL_03b9;
																																case 36:
																																case 90:
																																	goto IL_03cc;
																																case 81:
																																	goto IL_03da;
																																case 79:
																																case 97:
																																	goto IL_03e8;
																																case 34:
																																	goto IL_03f6;
																																case 51:
																																case 61:
																																	goto IL_0404;
																																case 53:
																																case 98:
																																	goto IL_0420;
																																case 13:
																																	goto end_IL_0241;
																																case 92:
																																	goto IL_0450;
																																case 0:
																																	goto IL_045e;
																																case 2:
																																case 102:
																																	goto IL_0471;
																																case 116:
																																	goto IL_048d;
																																case 103:
																																	goto IL_049b;
																																case 104:
																																case 115:
																																	goto IL_04a9;
																																case 70:
																																	goto IL_050b;
																																case 50:
																																case 99:
																																	goto IL_051e;
																																case 118:
																																	goto IL_0535;
																																case 33:
																																case 75:
																																	goto IL_0543;
																																case 39:
																																	goto IL_0583;
																																case 9:
																																	goto IL_0597;
																																case 23:
																																case 119:
																																	goto IL_05aa;
																																case 31:
																																	goto IL_05b8;
																																case 20:
																																	goto IL_05cb;
																																case 100:
																																	goto IL_05f4;
																																case 24:
																																	goto IL_060b;
																																case 93:
																																	goto IL_0627;
																																case 76:
																																	goto IL_0635;
																																case 7:
																																case 110:
																																	goto IL_0640;
																																case 86:
																																	goto IL_064e;
																																case 42:
																																	goto IL_0671;
																																case 109:
																																	goto IL_067b;
																																case 129:
																																	goto IL_0689;
																																case 49:
																																case 60:
																																	goto IL_06a5;
																																case 111:
																																	goto IL_06b3;
																																case 65:
																																	goto IL_06c6;
																																case 26:
																																	goto IL_06d4;
																																case 41:
																																case 52:
																																	goto IL_06e2;
																																case 66:
																																	goto IL_0722;
																																case 5:
																																	goto IL_073f;
																																case 58:
																																case 122:
																																	goto IL_0758;
																																case 57:
																																	goto IL_077b;
																																case 126:
																																	goto IL_0789;
																																case 120:
																																	goto IL_0797;
																																case 1:
																																case 4:
																																case 6:
																																case 14:
																																case 19:
																																case 25:
																																case 30:
																																case 45:
																																case 55:
																																case 56:
																																case 62:
																																case 63:
																																case 71:
																																case 80:
																																case 87:
																																case 89:
																																case 94:
																																case 107:
																																case 112:
																																case 113:
																																case 117:
																																case 128:
																																	goto end_IL_0254;
																																case 3:
																																case 10:
																																case 15:
																																case 17:
																																case 18:
																																case 37:
																																case 47:
																																case 78:
																																case 83:
																																case 88:
																																case 91:
																																case 95:
																																case 105:
																																case 123:
																																case 125:
																																case 127:
																																	goto end_IL_02f1;
																																case 82:
																																	goto end_IL_07ba;
																																case 84:
																																	goto end_IL_07cd;
																																case 43:
																																	goto end_IL_07d7;
																																case 114:
																																	goto end_IL_07e2;
																																case 67:
																																case 106:
																																	goto end_IL_0800;
																																case 130:
																																	goto end_IL_0810;
																																case 29:
																																case 96:
																																	goto end_IL_0820;
																																case 27:
																																	goto end_IL_0830;
																																case 28:
																																	goto end_IL_0840;
																																case 68:
																																case 121:
																																	goto IL_085b;
																																}
																																continue;
																															}
																															goto IL_05cb;
																															IL_05f4:
																															ptr2 += 8;
																															num = 24;
																															goto IL_060b;
																															IL_060b:
																															num5--;
																															num = 18;
																															goto end_IL_02f1;
																															IL_05cb:
																															ref int reference = ref array3[*(int*)(ptr2 + num3)];
																															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																															goto IL_05f4;
																															continue;
																															end_IL_0241:
																															break;
																														}
																														goto IL_0439;
																														continue;
																														end_IL_0254:
																														break;
																														IL_0254:;
																													}
																													break;
																													IL_0267:;
																												}
																												break;
																											}
																											goto IL_0314;
																											IL_045e:
																											ptr2 += 8;
																											goto end_IL_02f1;
																											IL_0314:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0420;
																											IL_0420:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_0439;
																											IL_0439:
																											array[num5] = 0;
																											num = 92;
																											goto IL_0450;
																											IL_0450:
																											num5++;
																											goto IL_045e;
																										}
																										break;
																									}
																									goto IL_02fc;
																									IL_02fc:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02f1;
																								}
																								break;
																							}
																							goto IL_0627;
																							IL_073f:
																							num5--;
																							num = 91;
																							goto end_IL_02f1;
																							IL_0627:
																							if (5 >= b)
																							{
																								goto IL_0635;
																							}
																							goto IL_06c6;
																							IL_0635:
																							if (5 <= b)
																							{
																								goto IL_0640;
																							}
																							goto IL_06a5;
																							IL_0640:
																							array[num5] = 0;
																							goto IL_064e;
																							IL_064e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0671;
																							IL_0671:
																							array2[num5] = null;
																							goto IL_067b;
																							IL_067b:
																							num5++;
																							goto IL_0689;
																							IL_0689:
																							ptr2 += 8;
																							num = 10;
																							goto end_IL_02f1;
																							IL_06a5:
																							if (4 < b)
																							{
																								break;
																							}
																							goto IL_06b3;
																							IL_06b3:
																							if (4 <= b)
																							{
																								goto end_IL_02f1;
																							}
																							break;
																							IL_06c6:
																							if (6 < b)
																							{
																								break;
																							}
																							goto IL_06d4;
																							IL_06d4:
																							if (6 > b)
																							{
																								break;
																							}
																							goto IL_06e2;
																							IL_06e2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0722;
																							IL_0722:
																							array[num5 - 2] = 0;
																							num = 5;
																							goto IL_073f;
																						}
																						break;
																					}
																					goto IL_0758;
																					IL_0797:
																					ptr2 += 8;
																					goto end_IL_02f1;
																					IL_0758:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_077b;
																					IL_077b:
																					array[num5] = 0;
																					goto IL_0789;
																					IL_0789:
																					num5++;
																					goto IL_0797;
																				}
																				break;
																			}
																			goto IL_0327;
																			IL_05aa:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_05b8;
																			IL_0327:
																			if (10 >= b)
																			{
																				goto IL_0335;
																			}
																			goto IL_03cc;
																			IL_0335:
																			if (10 <= b)
																			{
																				goto IL_0343;
																			}
																			goto IL_048d;
																			IL_0343:
																			array[num5 - 2] = 0;
																			goto IL_0357;
																			IL_0357:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)SafeCspHandleToValueTuple[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_03ab;
																			IL_03ab:
																			num5--;
																			goto IL_03b9;
																			IL_03b9:
																			ptr2 += 8;
																			goto end_IL_02f1;
																			IL_048d:
																			if (8 >= b)
																			{
																				goto IL_049b;
																			}
																			goto IL_051e;
																			IL_049b:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_04a9;
																			IL_04a9:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_050b;
																			IL_050b:
																			num5 -= 2;
																			goto end_IL_02f1;
																			IL_051e:
																			if (9 < b)
																			{
																				break;
																			}
																			num = 118;
																			goto IL_0535;
																			IL_05b8:
																			if (13 <= b)
																			{
																			}
																			break;
																			IL_0535:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0543;
																			IL_0543:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0583;
																			IL_0583:
																			array[num5 - 2] = 0;
																			goto IL_0597;
																			IL_0597:
																			num5--;
																			goto end_IL_02f1;
																			IL_03cc:
																			if (12 >= b)
																			{
																				goto IL_03da;
																			}
																			goto IL_05aa;
																			IL_03da:
																			if (12 > b)
																			{
																				goto IL_03e8;
																			}
																			goto IL_0471;
																			IL_03e8:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_03f6;
																			IL_03f6:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0404;
																			IL_0404:
																			num5--;
																			num = 83;
																			goto end_IL_02f1;
																			IL_0471:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02f1;
																		}
																		break;
																		IL_02c1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02f1;
																continue;
																end_IL_02d1:
																break;
															}
															continue;
															end_IL_02e1:
															break;
														}
														continue;
														end_IL_02f1:
														break;
													}
													continue;
												}
												goto IL_085b;
												IL_085b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_07ba:
												break;
											}
											continue;
											end_IL_07cd:
											break;
										}
										continue;
										end_IL_07d7:
										break;
									}
									continue;
									end_IL_07e2:
									break;
								}
								continue;
								end_IL_0800:
								break;
							}
							continue;
							end_IL_0810:
							break;
						}
						continue;
						end_IL_0820:
						break;
					}
					continue;
					end_IL_0830:
					break;
				}
				continue;
				end_IL_0840:
				break;
			}
		}
	}

	static Class160()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 14;
					while (true)
					{
						if (num != 14)
						{
							if (num != 995)
							{
								break;
							}
							switch (num)
							{
							case 6:
							case 7:
								goto end_IL_0041;
							case 2:
								goto end_IL_004e;
							case 3:
								goto end_IL_005d;
							case 0:
								return;
							case 1:
								return;
							case 4:
								return;
							case 5:
								return;
							}
							continue;
						}
						return;
						continue;
						end_IL_0041:
						break;
					}
					continue;
					end_IL_004e:
					break;
				}
				continue;
				end_IL_005d:
				break;
			}
		}
	}
}
