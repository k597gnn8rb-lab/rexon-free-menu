using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Random Gadgets Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns random gadgets.", false, 21, ModType.const_0, false)]
internal class Class122 : MonoBehaviour
{
	private static string string_0;

	private int int_0;

	private static bool bool_0;

	private static bool bool_1;

	private static float float_0;

	private static int int_1;

	private static IntPtr[] IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode;

	private static IntPtr[] CompletingsetCapacity;

	private static IntPtr[] dwLowDateTimegetCapsLock;

	private static IntPtr[] OleAutBindergetTreatControlCAsInput;

	private static IntPtr[] getExportedTypesgetPreviousValue;

	private static IntPtr[] NonSerializedAttributeGetServerTypeForUri;

	private static IntPtr[] ServerObjectTerminatorSinkEphemerisCorrectionAlgorithmMap;

	private unsafe void Update()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0999, IL_09ac, IL_09cb, IL_0a0d, IL_0a1d, IL_0a2d, IL_0a3a, IL_0a4a, IL_0a5a, IL_0a6a, IL_0a7d, IL_0a8d, IL_0a9d, IL_0aa8, IL_0ae6, IL_0af9, IL_0b0c, IL_0b1a, IL_0b25, IL_0b33, IL_0b56, IL_0b69, IL_0b77, IL_0b93, IL_0ba1, IL_0bac, IL_0bec, IL_0c00, IL_0c13, IL_0c21, IL_0c2f, IL_0c48, IL_0c56, IL_0c64, IL_0c77, IL_0c85, IL_0c93, IL_0c9c, IL_0cc5, IL_0cd3, IL_0ce6, IL_0cf4, IL_0cff, IL_0d3f, IL_0d53, IL_0d66, IL_0d74, IL_0d82, IL_0d8b, IL_0dd4, IL_0de8, IL_0dfb, IL_0e06, IL_0e14, IL_0e54, IL_0e68, IL_0e7b, IL_0e89, IL_0e97, IL_0eaa, IL_0eb8, IL_0ec6, IL_0ee3, IL_0f32, IL_0f3c, IL_0f69, IL_0f7d, IL_0f94, IL_0fb0, IL_0fbe, IL_0fc9, IL_0fdd, IL_101c, IL_102f, IL_103d, IL_104b, IL_10ad, IL_10c0, IL_10ce, IL_10e1, IL_10ef, IL_10fa, IL_1103, IL_112c, IL_1145, IL_1153, IL_1161, IL_117f, IL_118d, IL_11a0, IL_11ae, IL_11bc, IL_11d4, IL_11f2, IL_1216, IL_122e, IL_124a, IL_1258, IL_1266, IL_1274, IL_128c, IL_129a, IL_12ad, IL_12bb, IL_12c6, IL_1306, IL_131a, IL_132d, IL_133b, IL_1349, IL_1357, IL_1362, IL_1370, IL_137e, IL_1392, IL_13ca, IL_13dd, IL_13f6, IL_1404, IL_1412, IL_1425, IL_1433, IL_1441, IL_1459, IL_149a, IL_14ae, IL_14c1, IL_14cf, IL_14da, IL_14ef, IL_1502, IL_1510, IL_151e, IL_1570, IL_1583, IL_1591, IL_159f, IL_15ad, IL_15c1, IL_1600, IL_1613, IL_161c, IL_162a, IL_1643, IL_1651, IL_165f, IL_1672, IL_1680, IL_168b, IL_16a4, IL_16b7, IL_16c5, IL_16d0, IL_16ea, IL_16f8, IL_1706, IL_1719, IL_1727, IL_1735, IL_1752, IL_1791, IL_17a4, IL_17b2, IL_17bb, IL_17c9, IL_17dd, IL_186e, IL_1885, IL_1898, IL_18a6, IL_18b1, IL_18bf, IL_18e3, IL_18f1, IL_1904, IL_1912, IL_1920, IL_1934, IL_1973, IL_1986, IL_1991, IL_199f, IL_19fd, IL_1a10, IL_1a1e, IL_1a2c, IL_1a6c, IL_1a80, IL_1a93, IL_1aab, IL_1ab9, IL_1ac7, IL_1ada, IL_1ae8, IL_1af6, IL_1b0a, IL_1b79, IL_1b8c, IL_1b9a, IL_1ba5, IL_1bb9, IL_1c01, IL_1c14, IL_1c22, IL_1c2d, IL_1c58, IL_1c71, IL_1c7f, IL_1c8a, IL_1cb1, IL_1cbf, IL_1ccd, IL_1ce0, IL_1cee, IL_1cf7, IL_1d05, IL_1d43, IL_1d57, IL_1d6a, IL_1d78, IL_1d86, IL_1db0, IL_1dc9, IL_1dd7, IL_1de2, IL_1e10, IL_1e23, IL_1e31, IL_1e3f, IL_1e7f, IL_1e93, IL_1ea6, IL_1eb4, IL_1ec2, IL_1ed0, IL_1f17, IL_1f2b, IL_1f3e, IL_1f47, IL_1f55, IL_1f78, IL_1f86, IL_1f94, IL_1fa7, IL_1fb5, IL_1fc0, IL_1fde, IL_1fec, IL_1ffa, IL_200d, IL_201b, IL_2029, IL_2037, IL_204b, IL_208a, IL_209d, IL_20a8, IL_20b6, IL_20bf, IL_20cd, IL_20e9, IL_20f7, IL_211b, IL_2129, IL_213c, IL_214a, IL_2155, IL_2163, IL_2171, IL_2184, IL_2192, IL_21a5, IL_21b3, IL_21c1, IL_2210, IL_2224, IL_223d, IL_2250, IL_2259, IL_2267, IL_227b, IL_22d6, IL_22e4, IL_22f7, IL_2305, IL_2313, IL_2331, IL_233f, IL_234d, IL_2360, IL_236e, IL_2379, IL_238d, IL_23cc, IL_23df, IL_23ed, IL_23f8, IL_2421, IL_242f, IL_2442, IL_2450, IL_245b, IL_24ad, IL_24bb, IL_24ce, IL_24dc, IL_24ea, IL_24f8, IL_251b, IL_2529, IL_253c, IL_254a, IL_2558, IL_256c, IL_25ab, IL_25be, IL_25cc, IL_25da, IL_25e8, IL_25f6, IL_25ff, IL_2613, IL_2665, IL_2673, IL_2686, IL_2694, IL_26c1, IL_26d8, IL_26eb, IL_26f6, IL_2704, IL_2718, IL_2757, IL_276a, IL_2778, IL_2786, IL_27c4, IL_27d8, IL_27eb, IL_27f9, IL_2804, IL_281b, IL_283e, IL_284c, IL_285f, IL_286d, IL_2878, IL_2891, IL_28a4, IL_28b2, IL_28c0, IL_28f9, IL_290d, IL_2920, IL_292b, IL_2939, IL_2962, IL_2970, IL_2983, IL_2991, IL_299f, IL_29b3, IL_2a22, IL_2a35, IL_2a43, IL_2a4e, IL_2a8c, IL_2aa0, IL_2ab3, IL_2ac1, IL_2acf, IL_2ae3, IL_2b35, IL_2b43, IL_2b56, IL_2b61, IL_2b6c, IL_2b80, IL_2bbf, IL_2bcf, IL_2bda, IL_2be5, IL_2bf8, IL_2c0b, IL_2c15, IL_2c20, IL_2c30, IL_2c40, IL_2c50, IL_2c69, IL_2c79, IL_2c89, IL_2c99, IL_2ca9, IL_2cc2 are reachable both inside and outside the pinned region starting at IL_2cd7. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 556;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef33 = default(int);
			ref int reference = ref __rxRef33;
			object[] array8;
			int num7;
			byte* num8;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_2cc2:
					num2 = 1;
					while (true)
					{
						IL_2ca9:
						num3 = num2 * 4;
						num = 415;
						while (true)
						{
							IL_2c99:
							num4 = num2 * 8;
							while (true)
							{
								IL_2c89:
								array2 = new byte[5];
								while (true)
								{
									IL_2c79:
									array3 = new object[5];
									while (true)
									{
										IL_2c69:
										array4 = new int[5];
										while (true)
										{
											IL_2c50:
											array5 = new int[7];
											num = 191;
											while (true)
											{
												IL_2c40:
												array6 = new long[5];
												while (true)
												{
													IL_2c30:
													array7 = new object[14];
													while (true)
													{
														IL_2c20:
														array7[0] = this;
														while (true)
														{
															IL_2c15:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LeaveParent.ActivityTrackerCreateSubdirectory);
															while (true)
															{
																IL_2c0b:
																ptr2 = ptr;
																while (true)
																{
																	IL_2bf8:
																	if (num5 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0a9d:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0a8d:
																			ptr2++;
																			while (true)
																			{
																				IL_0a7d:
																				if (b >= 1)
																				{
																					while (b <= 72)
																					{
																						num = 220;
																						while (true)
																						{
																							IL_0a5a:
																							if (36 >= b)
																							{
																								while (true)
																								{
																									IL_0a4a:
																									if (36 > b)
																									{
																										while (true)
																										{
																											IL_0a3a:
																											if (18 < b)
																											{
																												goto IL_12ad;
																											}
																											while (true)
																											{
																												IL_0a2d:
																												if (18 > b)
																												{
																													while (true)
																													{
																														IL_0a1d:
																														if (9 >= b)
																														{
																															while (true)
																															{
																																IL_0a0d:
																																if (9 <= b)
																																{
																																	while (true)
																																	{
																																		IL_09cb:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		while (true)
																																		{
																																			IL_09ac:
																																			array2[num6 - 2] = 0;
																																			num = 607;
																																			while (true)
																																			{
																																				if (num != 607)
																																				{
																																					if (num != 1588)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 556:
																																						break;
																																					default:
																																						continue;
																																					case 38:
																																						goto IL_09ac;
																																					case 10:
																																					case 232:
																																						goto IL_09cb;
																																					case 518:
																																						goto IL_0a0d;
																																					case 598:
																																						goto IL_0a1d;
																																					case 423:
																																						goto IL_0a2d;
																																					case 341:
																																						goto IL_0a3a;
																																					case 378:
																																						goto IL_0a4a;
																																					case 220:
																																						goto IL_0a5a;
																																					case 403:
																																						goto IL_0a6a;
																																					case 119:
																																						goto IL_0a7d;
																																					case 450:
																																						goto IL_0a8d;
																																					case 162:
																																					case 582:
																																						goto IL_0a9d;
																																					case 116:
																																					case 397:
																																						goto IL_0aa8;
																																					case 190:
																																						goto IL_0ae6;
																																					case 413:
																																						goto IL_0b0c;
																																					case 393:
																																						goto IL_0b1a;
																																					case 25:
																																					case 259:
																																						goto IL_0b25;
																																					case 147:
																																						goto IL_0b33;
																																					case 503:
																																						goto IL_0b56;
																																					case 471:
																																						goto IL_0b69;
																																					case 465:
																																						goto IL_0b77;
																																					case 126:
																																						goto IL_0b93;
																																					case 496:
																																						goto IL_0ba1;
																																					case 472:
																																					case 531:
																																						goto IL_0bac;
																																					case 339:
																																						goto IL_0bec;
																																					case 40:
																																						goto IL_0c00;
																																					case 485:
																																						goto IL_0c13;
																																					case 106:
																																						goto IL_0c21;
																																					case 260:
																																					case 517:
																																						goto IL_0c2f;
																																					case 463:
																																						goto IL_0c48;
																																					case 97:
																																						goto IL_0c56;
																																					case 50:
																																						goto IL_0c64;
																																					case 343:
																																						goto IL_0c77;
																																					case 512:
																																						goto IL_0c85;
																																					case 84:
																																					case 398:
																																						goto IL_0c9c;
																																					case 258:
																																						goto IL_0cc5;
																																					case 593:
																																						goto IL_0cd3;
																																					case 180:
																																						goto IL_0ce6;
																																					case 278:
																																						goto IL_0cf4;
																																					case 440:
																																					case 502:
																																						goto IL_0cff;
																																					case 464:
																																						goto IL_0d3f;
																																					case 168:
																																						goto IL_0d53;
																																					case 49:
																																						goto IL_0d66;
																																					case 13:
																																						goto IL_0d74;
																																					case 45:
																																					case 309:
																																						goto IL_0d8b;
																																					case 297:
																																						goto IL_0dd4;
																																					case 547:
																																						goto IL_0de8;
																																					case 466:
																																						goto IL_0dfb;
																																					case 452:
																																						goto IL_0e06;
																																					case 213:
																																					case 559:
																																						goto IL_0e14;
																																					case 539:
																																						goto IL_0e54;
																																					case 282:
																																						goto IL_0e68;
																																					case 356:
																																						goto IL_0e7b;
																																					case 338:
																																						goto IL_0e89;
																																					case 385:
																																					case 545:
																																						goto IL_0e97;
																																					case 109:
																																						goto IL_0eaa;
																																					case 102:
																																						goto IL_0eb8;
																																					case 263:
																																					case 312:
																																						goto IL_0ec6;
																																					case 179:
																																						goto IL_0f7d;
																																					case 189:
																																						goto IL_0f94;
																																					case 234:
																																						goto IL_0fb0;
																																					case 214:
																																						goto IL_0fbe;
																																					case 364:
																																					case 536:
																																						goto IL_0fc9;
																																					case 461:
																																						goto IL_0fdd;
																																					case 181:
																																						goto IL_101c;
																																					case 490:
																																						goto IL_102f;
																																					case 422:
																																						goto IL_103d;
																																					case 154:
																																					case 192:
																																						goto IL_104b;
																																					case 149:
																																						goto IL_10ad;
																																					case 425:
																																						goto IL_10c0;
																																					case 513:
																																						goto IL_10ce;
																																					case 204:
																																						goto IL_10e1;
																																					case 359:
																																						goto IL_10ef;
																																					case 200:
																																					case 586:
																																						goto IL_1103;
																																					case 80:
																																						goto IL_112c;
																																					case 522:
																																						goto IL_1145;
																																					case 510:
																																						goto IL_1153;
																																					case 110:
																																					case 194:
																																						goto IL_1161;
																																					case 371:
																																						goto IL_117f;
																																					case 421:
																																						goto IL_118d;
																																					case 534:
																																						goto IL_11a0;
																																					case 288:
																																						goto IL_11ae;
																																					case 322:
																																					case 460:
																																						goto IL_11bc;
																																					case 246:
																																						goto IL_11d4;
																																					case 51:
																																						goto IL_11f2;
																																					case 487:
																																						goto IL_1216;
																																					case 388:
																																						goto IL_122e;
																																					case 405:
																																						goto IL_124a;
																																					case 8:
																																						goto IL_1258;
																																					case 134:
																																					case 495:
																																						goto IL_1266;
																																					case 61:
																																						goto IL_1274;
																																					case 318:
																																						goto IL_128c;
																																					case 575:
																																						goto IL_129a;
																																					case 448:
																																						goto IL_12ad;
																																					case 226:
																																						goto IL_12bb;
																																					case 475:
																																					case 481:
																																						goto IL_12c6;
																																					case 459:
																																						goto IL_1306;
																																					case 402:
																																						goto IL_131a;
																																					case 314:
																																						goto IL_132d;
																																					case 188:
																																						goto IL_133b;
																																					case 196:
																																						goto IL_1349;
																																					case 177:
																																						goto IL_1357;
																																					case 167:
																																						goto IL_1362;
																																					case 433:
																																						goto IL_1370;
																																					case 39:
																																					case 331:
																																						goto IL_137e;
																																					case 231:
																																						goto IL_1392;
																																					case 367:
																																						goto IL_13ca;
																																					case 121:
																																					case 506:
																																						goto IL_13dd;
																																					case 311:
																																						goto IL_13f6;
																																					case 15:
																																						goto IL_1404;
																																					case 419:
																																						goto IL_1412;
																																					case 27:
																																						goto IL_1425;
																																					case 65:
																																						goto IL_1433;
																																					case 128:
																																					case 368:
																																						goto IL_1441;
																																					case 334:
																																					case 596:
																																						goto IL_1459;
																																					case 600:
																																						goto IL_149a;
																																					case 570:
																																						goto IL_14ae;
																																					case 212:
																																						goto IL_14c1;
																																					case 41:
																																						goto IL_14cf;
																																					case 185:
																																					case 317:
																																						goto IL_14da;
																																					case 300:
																																						goto IL_14ef;
																																					case 344:
																																						goto IL_1502;
																																					case 183:
																																						goto IL_1510;
																																					case 22:
																																					case 219:
																																						goto IL_151e;
																																					case 554:
																																						goto IL_1570;
																																					case 329:
																																						goto end_IL_0999;
																																					case 187:
																																						goto IL_1591;
																																					case 308:
																																						goto IL_159f;
																																					case 261:
																																					case 544:
																																						goto IL_15ad;
																																					case 345:
																																						goto IL_15c1;
																																					case 526:
																																						goto IL_1600;
																																					case 349:
																																						goto IL_161c;
																																					case 160:
																																					case 163:
																																						goto IL_162a;
																																					case 585:
																																						goto IL_1643;
																																					case 374:
																																						goto IL_1651;
																																					case 566:
																																						goto IL_165f;
																																					case 360:
																																						goto IL_1672;
																																					case 67:
																																						goto IL_1680;
																																					case 78:
																																					case 113:
																																						goto IL_168b;
																																					case 216:
																																						goto IL_16a4;
																																					case 417:
																																						goto IL_16b7;
																																					case 326:
																																						goto IL_16c5;
																																					case 91:
																																					case 389:
																																						goto IL_16d0;
																																					case 529:
																																						goto IL_16ea;
																																					case 458:
																																						goto IL_16f8;
																																					case 83:
																																						goto IL_1706;
																																					case 428:
																																						goto IL_1719;
																																					case 156:
																																						goto IL_1727;
																																					case 132:
																																					case 208:
																																						goto IL_1735;
																																					case 467:
																																						goto IL_1752;
																																					case 474:
																																						goto IL_1791;
																																					case 521:
																																						goto IL_17a4;
																																					case 9:
																																						goto IL_17bb;
																																					case 182:
																																					case 552:
																																						goto IL_17c9;
																																					case 432:
																																						goto IL_17dd;
																																					case 454:
																																						goto IL_186e;
																																					case 221:
																																						goto IL_1885;
																																					case 141:
																																						goto IL_1898;
																																					case 291:
																																						goto IL_18a6;
																																					case 146:
																																					case 319:
																																						goto IL_18b1;
																																					case 447:
																																						goto IL_18bf;
																																					case 542:
																																						goto IL_18e3;
																																					case 111:
																																						goto IL_18f1;
																																					case 178:
																																						goto IL_1904;
																																					case 442:
																																						goto IL_1912;
																																					case 75:
																																					case 514:
																																						goto IL_1920;
																																					case 511:
																																						goto IL_1934;
																																					case 444:
																																						goto IL_1973;
																																					case 557:
																																						goto IL_1986;
																																					case 12:
																																						goto IL_1991;
																																					case 175:
																																					case 427:
																																						goto IL_199f;
																																					case 74:
																																						goto IL_19fd;
																																					case 2:
																																						goto IL_1a10;
																																					case 363:
																																						goto IL_1a1e;
																																					case 130:
																																					case 249:
																																						goto IL_1a2c;
																																					case 553:
																																						goto IL_1a6c;
																																					case 92:
																																						goto IL_1a80;
																																					case 303:
																																					case 577:
																																						goto IL_1a93;
																																					case 492:
																																						goto IL_1aab;
																																					case 390:
																																						goto IL_1ab9;
																																					case 118:
																																						goto IL_1ac7;
																																					case 240:
																																						goto IL_1ada;
																																					case 151:
																																						goto IL_1ae8;
																																					case 30:
																																					case 52:
																																						goto IL_1af6;
																																					case 424:
																																						goto IL_1b0a;
																																					case 340:
																																						goto IL_1b79;
																																					case 325:
																																						goto IL_1b8c;
																																					case 145:
																																						goto IL_1b9a;
																																					case 327:
																																					case 486:
																																						goto IL_1ba5;
																																					case 95:
																																						goto IL_1bb9;
																																					case 292:
																																						goto IL_1c01;
																																					case 456:
																																						goto IL_1c14;
																																					case 295:
																																						goto IL_1c22;
																																					case 88:
																																					case 571:
																																						goto IL_1c2d;
																																					case 36:
																																						goto IL_1c58;
																																					case 164:
																																						goto IL_1c71;
																																					case 159:
																																						goto IL_1c7f;
																																					case 228:
																																					case 562:
																																						goto IL_1c8a;
																																					case 107:
																																						goto IL_1cb1;
																																					case 355:
																																						goto IL_1cbf;
																																					case 436:
																																						goto IL_1ccd;
																																					case 491:
																																						goto IL_1ce0;
																																					case 333:
																																						goto IL_1cf7;
																																					case 174:
																																					case 386:
																																						goto IL_1d05;
																																					case 87:
																																						goto IL_1d43;
																																					case 392:
																																						goto IL_1d57;
																																					case 148:
																																						goto IL_1d6a;
																																					case 462:
																																						goto IL_1d78;
																																					case 276:
																																					case 438:
																																						goto IL_1d86;
																																					case 396:
																																						goto IL_1db0;
																																					case 237:
																																						goto IL_1dc9;
																																					case 66:
																																						goto IL_1dd7;
																																					case 301:
																																					case 395:
																																						goto IL_1de2;
																																					case 207:
																																						goto IL_1e10;
																																					case 289:
																																						goto IL_1e23;
																																					case 267:
																																						goto IL_1e31;
																																					case 46:
																																					case 59:
																																						goto IL_1e3f;
																																					case 64:
																																						goto IL_1e7f;
																																					case 375:
																																						goto IL_1e93;
																																					case 414:
																																						goto IL_1ea6;
																																					case 247:
																																						goto IL_1eb4;
																																					case 34:
																																						goto IL_1ec2;
																																					case 233:
																																					case 302:
																																						goto IL_1ed0;
																																					case 523:
																																						goto IL_1f17;
																																					case 140:
																																						goto IL_1f2b;
																																					case 489:
																																						goto IL_1f47;
																																					case 98:
																																					case 591:
																																						goto IL_1f55;
																																					case 135:
																																						goto IL_1f78;
																																					case 266:
																																						goto IL_1f86;
																																					case 384:
																																						goto IL_1f94;
																																					case 264:
																																						goto IL_1fa7;
																																					case 293:
																																						goto IL_1fb5;
																																					case 369:
																																					case 541:
																																						goto IL_1fc0;
																																					case 283:
																																						goto IL_1fde;
																																					case 305:
																																						goto IL_1fec;
																																					case 193:
																																						goto IL_1ffa;
																																					case 251:
																																						goto IL_200d;
																																					case 269:
																																						goto IL_201b;
																																					case 387:
																																						goto IL_2029;
																																					case 455:
																																					case 538:
																																						goto IL_2037;
																																					case 275:
																																						goto IL_204b;
																																					case 519:
																																						goto IL_208a;
																																					case 597:
																																						goto IL_209d;
																																					case 262:
																																						goto IL_20a8;
																																					case 383:
																																						goto IL_20bf;
																																					case 114:
																																					case 443:
																																						goto IL_20cd;
																																					case 426:
																																					case 563:
																																						goto IL_20e9;
																																					case 441:
																																						goto IL_20f7;
																																					case 108:
																																						goto IL_211b;
																																					case 239:
																																						goto IL_2129;
																																					case 11:
																																						goto IL_213c;
																																					case 478:
																																						goto IL_214a;
																																					case 143:
																																						goto IL_2155;
																																					case 96:
																																					case 500:
																																						goto IL_2163;
																																					case 381:
																																						goto IL_2171;
																																					case 504:
																																						goto IL_2184;
																																					case 29:
																																						goto IL_2192;
																																					case 122:
																																						goto IL_21a5;
																																					case 286:
																																						goto IL_21b3;
																																					case 142:
																																					case 161:
																																						goto IL_21c1;
																																					case 509:
																																						goto IL_2210;
																																					case 287:
																																						goto IL_2224;
																																					case 361:
																																						goto IL_223d;
																																					case 429:
																																						goto IL_2259;
																																					case 53:
																																					case 124:
																																						goto IL_2267;
																																					case 205:
																																						goto IL_227b;
																																					case 120:
																																						goto IL_22d6;
																																					case 537:
																																						goto IL_22e4;
																																					case 380:
																																						goto IL_22f7;
																																					case 323:
																																						goto IL_2305;
																																					case 453:
																																					case 477:
																																						goto IL_2313;
																																					case 324:
																																						goto IL_2331;
																																					case 310:
																																						goto IL_233f;
																																					case 298:
																																						goto IL_234d;
																																					case 574:
																																						goto IL_2360;
																																					case 407:
																																						goto IL_236e;
																																					case 4:
																																					case 280:
																																						goto IL_2379;
																																					case 103:
																																						goto IL_238d;
																																					case 273:
																																						goto IL_23cc;
																																					case 198:
																																						goto IL_23df;
																																					case 391:
																																						goto IL_23ed;
																																					case 28:
																																					case 532:
																																						goto IL_23f8;
																																					case 125:
																																						goto IL_2421;
																																					case 268:
																																						goto IL_242f;
																																					case 236:
																																						goto IL_2442;
																																					case 69:
																																						goto IL_2450;
																																					case 244:
																																					case 350:
																																						goto IL_245b;
																																					case 409:
																																						goto IL_24ad;
																																					case 470:
																																						goto IL_24bb;
																																					case 479:
																																						goto IL_24ce;
																																					case 171:
																																						goto IL_24dc;
																																					case 117:
																																					case 565:
																																						goto IL_24ea;
																																					case 406:
																																						goto IL_24f8;
																																					case 551:
																																						goto IL_251b;
																																					case 245:
																																						goto IL_2529;
																																					case 316:
																																						goto IL_253c;
																																					case 540:
																																						goto IL_254a;
																																					case 250:
																																					case 564:
																																						goto IL_2558;
																																					case 157:
																																						goto IL_256c;
																																					case 56:
																																						goto IL_25ab;
																																					case 57:
																																						goto IL_25be;
																																					case 412:
																																						goto IL_25cc;
																																					case 211:
																																						goto IL_25da;
																																					case 498:
																																						goto IL_25e8;
																																					case 482:
																																					case 584:
																																						goto IL_25ff;
																																					case 399:
																																						goto IL_2613;
																																					case 255:
																																						goto IL_2665;
																																					case 527:
																																						goto IL_2673;
																																					case 139:
																																					case 270:
																																						goto IL_2686;
																																					case 576:
																																						goto IL_2694;
																																					case 155:
																																						goto IL_26c1;
																																					case 150:
																																						goto IL_26d8;
																																					case 241:
																																						goto IL_26eb;
																																					case 144:
																																						goto IL_26f6;
																																					case 202:
																																					case 218:
																																						goto IL_2704;
																																					case 17:
																																						goto IL_2718;
																																					case 136:
																																						goto IL_2757;
																																					case 476:
																																						goto IL_276a;
																																					case 222:
																																						goto IL_2778;
																																					case 55:
																																					case 328:
																																						goto IL_2786;
																																					case 235:
																																						goto IL_27c4;
																																					case 348:
																																						goto IL_27d8;
																																					case 404:
																																						goto IL_27eb;
																																					case 131:
																																						goto IL_27f9;
																																					case 23:
																																					case 508:
																																						goto IL_2804;
																																					case 439:
																																						goto IL_281b;
																																					case 357:
																																						goto IL_283e;
																																					case 451:
																																						goto IL_284c;
																																					case 112:
																																						goto IL_285f;
																																					case 24:
																																						goto IL_286d;
																																					case 284:
																																					case 336:
																																						goto IL_2878;
																																					case 505:
																																						goto IL_2891;
																																					case 457:
																																						goto IL_28a4;
																																					case 72:
																																						goto IL_28b2;
																																					case 337:
																																					case 437:
																																						goto IL_28c0;
																																					case 206:
																																						goto IL_28f9;
																																					case 353:
																																						goto IL_290d;
																																					case 152:
																																						goto IL_2920;
																																					case 44:
																																						goto IL_292b;
																																					case 100:
																																					case 296:
																																						goto IL_2939;
																																					case 127:
																																						goto IL_2962;
																																					case 568:
																																						goto IL_2970;
																																					case 101:
																																						goto IL_2983;
																																					case 420:
																																						goto IL_2991;
																																					case 73:
																																					case 599:
																																						goto IL_299f;
																																					case 494:
																																						goto IL_29b3;
																																					case 93:
																																						goto IL_2a22;
																																					case 5:
																																						goto IL_2a35;
																																					case 6:
																																						goto IL_2a43;
																																					case 285:
																																					case 473:
																																						goto IL_2a4e;
																																					case 569:
																																						goto IL_2a8c;
																																					case 81:
																																						goto IL_2aa0;
																																					case 21:
																																						goto IL_2ab3;
																																					case 516:
																																						goto IL_2ac1;
																																					case 362:
																																					case 524:
																																						goto IL_2acf;
																																					case 435:
																																						goto IL_2ae3;
																																					case 90:
																																						goto IL_2b35;
																																					case 416:
																																						goto IL_2b43;
																																					case 229:
																																						goto IL_2b56;
																																					case 1:
																																						goto IL_2b61;
																																					case 0:
																																					case 54:
																																						goto IL_2b6c;
																																					case 272:
																																						goto IL_2b80;
																																					case 94:
																																						goto IL_2bbf;
																																					case 400:
																																						goto IL_2bcf;
																																					case 16:
																																						goto IL_2bda;
																																					case 3:
																																					case 14:
																																					case 18:
																																					case 20:
																																					case 26:
																																					case 33:
																																					case 37:
																																					case 42:
																																					case 43:
																																					case 47:
																																					case 48:
																																					case 63:
																																					case 76:
																																					case 77:
																																					case 85:
																																					case 86:
																																					case 89:
																																					case 104:
																																					case 105:
																																					case 115:
																																					case 123:
																																					case 133:
																																					case 153:
																																					case 166:
																																					case 169:
																																					case 170:
																																					case 173:
																																					case 186:
																																					case 209:
																																					case 217:
																																					case 225:
																																					case 227:
																																					case 243:
																																					case 248:
																																					case 254:
																																					case 256:
																																					case 257:
																																					case 265:
																																					case 271:
																																					case 277:
																																					case 279:
																																					case 290:
																																					case 313:
																																					case 321:
																																					case 335:
																																					case 346:
																																					case 354:
																																					case 370:
																																					case 373:
																																					case 376:
																																					case 377:
																																					case 379:
																																					case 382:
																																					case 401:
																																					case 418:
																																					case 434:
																																					case 469:
																																					case 480:
																																					case 499:
																																					case 501:
																																					case 507:
																																					case 525:
																																					case 533:
																																					case 535:
																																					case 543:
																																					case 548:
																																					case 550:
																																					case 558:
																																					case 561:
																																					case 572:
																																					case 581:
																																					case 589:
																																					case 590:
																																					case 592:
																																					case 594:
																																						goto end_IL_0a6a;
																																					case 7:
																																					case 32:
																																					case 35:
																																					case 58:
																																					case 60:
																																					case 68:
																																					case 70:
																																					case 71:
																																					case 79:
																																					case 82:
																																					case 99:
																																					case 129:
																																					case 137:
																																					case 138:
																																					case 165:
																																					case 172:
																																					case 176:
																																					case 195:
																																					case 197:
																																					case 199:
																																					case 201:
																																					case 203:
																																					case 210:
																																					case 215:
																																					case 223:
																																					case 224:
																																					case 230:
																																					case 238:
																																					case 242:
																																					case 252:
																																					case 253:
																																					case 274:
																																					case 281:
																																					case 294:
																																					case 299:
																																					case 304:
																																					case 306:
																																					case 307:
																																					case 315:
																																					case 320:
																																					case 330:
																																					case 332:
																																					case 342:
																																					case 347:
																																					case 351:
																																					case 352:
																																					case 358:
																																					case 365:
																																					case 366:
																																					case 372:
																																					case 394:
																																					case 410:
																																					case 411:
																																					case 431:
																																					case 445:
																																					case 449:
																																					case 468:
																																					case 483:
																																					case 484:
																																					case 488:
																																					case 493:
																																					case 497:
																																					case 520:
																																					case 528:
																																					case 530:
																																					case 546:
																																					case 560:
																																					case 573:
																																					case 578:
																																					case 579:
																																					case 580:
																																					case 583:
																																					case 587:
																																					case 588:
																																					case 595:
																																						goto IL_2bf8;
																																					case 549:
																																						goto IL_2c0b;
																																					case 62:
																																						goto IL_2c15;
																																					case 446:
																																						goto IL_2c20;
																																					case 430:
																																						goto IL_2c30;
																																					case 191:
																																						goto IL_2c40;
																																					case 408:
																																						goto IL_2c50;
																																					case 19:
																																						goto IL_2c69;
																																					case 31:
																																						goto IL_2c79;
																																					case 184:
																																						goto IL_2c89;
																																					case 415:
																																						goto IL_2c99;
																																					case 158:
																																						goto IL_2ca9;
																																					case 555:
																																						goto IL_2cc2;
																																					case 515:
																																					case 567:
																																						return;
																																					}
																																					goto end_IL_0a3a;
																																				}
																																				num6--;
																																				goto IL_2bf8;
																																				continue;
																																				end_IL_0999:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_0b0c;
																																IL_0e7b:
																																if (8 < b)
																																{
																																	goto end_IL_0a6a;
																																}
																																goto IL_0e89;
																																IL_0b0c:
																																if (4 >= b)
																																{
																																	goto IL_0b1a;
																																}
																																goto IL_0ce6;
																																IL_0b1a:
																																if (4 <= b)
																																{
																																	goto IL_0b25;
																																}
																																goto IL_0b93;
																																IL_0b25:
																																array2[num6] = 0;
																																goto IL_0b33;
																																IL_0b33:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																goto IL_0b56;
																																IL_0b56:
																																array3[num6] = null;
																																num = 471;
																																goto IL_0b69;
																																IL_0b69:
																																num6++;
																																goto IL_0b77;
																																IL_0b77:
																																ptr2 += 8;
																																num = 483;
																																goto IL_2bf8;
																																IL_0b93:
																																if (2 >= b)
																																{
																																	goto IL_0ba1;
																																}
																																goto IL_0c77;
																																IL_0ba1:
																																if (2 <= b)
																																{
																																	goto IL_0bac;
																																}
																																goto IL_0c13;
																																IL_0bac:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0bec;
																																IL_0bec:
																																array2[num6 - 2] = 0;
																																goto IL_0c00;
																																IL_0c00:
																																num6--;
																																goto IL_2bf8;
																																IL_0c13:
																																if (1 < b)
																																{
																																	goto end_IL_0a6a;
																																}
																																goto IL_0c21;
																																IL_0c21:
																																if (1 > b)
																																{
																																	goto end_IL_0a6a;
																																}
																																goto IL_0c2f;
																																IL_0c2f:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																																goto IL_0c48;
																																IL_0c48:
																																array2[num6] = 0;
																																goto IL_0c56;
																																IL_0c56:
																																num6++;
																																goto IL_0c64;
																																IL_0c64:
																																ptr2 += 8;
																																goto IL_2bf8;
																																IL_0c77:
																																if (3 < b)
																																{
																																	goto end_IL_0a6a;
																																}
																																goto IL_0c85;
																																IL_0c85:
																																if (3 > b)
																																{
																																	goto end_IL_0a6a;
																																}
																																num = 398;
																																goto IL_0c9c;
																																IL_0e89:
																																if (8 > b)
																																{
																																	goto end_IL_0a6a;
																																}
																																goto IL_0e97;
																																IL_0c9c:
																																reference = ref array5[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0cc5;
																																IL_0cc5:
																																ptr2 += 8;
																																goto IL_0cd3;
																																IL_0cd3:
																																num6--;
																																goto IL_2bf8;
																																IL_0ce6:
																																if (6 >= b)
																																{
																																	goto IL_0cf4;
																																}
																																goto IL_0dfb;
																																IL_0cf4:
																																if (6 <= b)
																																{
																																	goto IL_0cff;
																																}
																																goto IL_0d66;
																																IL_0cff:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0d3f;
																																IL_0d3f:
																																array2[num6 - 2] = 0;
																																goto IL_0d53;
																																IL_0d53:
																																num6--;
																																goto IL_2bf8;
																																IL_0d66:
																																if (5 < b)
																																{
																																	goto end_IL_0a6a;
																																}
																																goto IL_0d74;
																																IL_0d74:
																																if (5 > b)
																																{
																																	goto end_IL_0a6a;
																																}
																																num = 309;
																																goto IL_0d8b;
																																IL_0e97:
																																num6--;
																																goto IL_2bf8;
																																IL_0d8b:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																num = 297;
																																goto IL_0dd4;
																																IL_0dd4:
																																array2[num6 - 2] = 0;
																																goto IL_0de8;
																																IL_0de8:
																																num6--;
																																goto IL_2bf8;
																																IL_0dfb:
																																if (7 >= b)
																																{
																																	goto IL_0e06;
																																}
																																goto IL_0e7b;
																																IL_0e06:
																																if (7 > b)
																																{
																																	goto end_IL_0a6a;
																																}
																																goto IL_0e14;
																																IL_0e14:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0e54;
																																IL_0e54:
																																array2[num6 - 2] = 0;
																																goto IL_0e68;
																																IL_0e68:
																																num6--;
																																goto IL_2bf8;
																															}
																															break;
																														}
																														goto IL_0eaa;
																														IL_1258:
																														if (17 > b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_1266;
																														IL_0eaa:
																														if (13 >= b)
																														{
																															goto IL_0eb8;
																														}
																														goto IL_10e1;
																														IL_0eb8:
																														if (13 <= b)
																														{
																															goto IL_0ec6;
																														}
																														goto IL_0fb0;
																														IL_0ec6:
																														array8 = array3;
																														num7 = num6;
																														if (array == null)
																														{
																															goto IL_0ed5;
																														}
																														num8 = ptr2;
																														byte b2 = *num8;
																														ptr2 = num8 + 4;
																														int num9 = *(int*)(ptr2 + num3);
																														ptr2 += 8;
																														byte* ptr3 = ptr2 + num9;
																														byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																														while (ptr2 != ptr3)
																														{
																															*ptr4 = (byte)(*ptr2 ^ b2);
																															ptr2++;
																															ptr4++;
																														}
																														array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																														goto IL_0f7d;
																														IL_1266:
																														array2[num6] = 5;
																														goto IL_1274;
																														IL_1274:
																														array3[num6] = array7[*(int*)(ptr2 + num3)];
																														goto IL_128c;
																														IL_128c:
																														num6++;
																														goto IL_129a;
																														IL_0f7d:
																														array2[num6] = 5;
																														num = 189;
																														goto IL_0f94;
																														IL_0f94:
																														num6++;
																														num = 294;
																														goto IL_2bf8;
																														IL_0fb0:
																														if (11 >= b)
																														{
																															goto IL_0fbe;
																														}
																														goto IL_10c0;
																														IL_0fbe:
																														if (11 <= b)
																														{
																															goto IL_0fc9;
																														}
																														goto IL_102f;
																														IL_0fc9:
																														array2[num6 - 1] = 0;
																														goto IL_0fdd;
																														IL_0fdd:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																														goto IL_101c;
																														IL_101c:
																														ptr2 += 8;
																														goto IL_2bf8;
																														IL_102f:
																														if (10 < b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_103d;
																														IL_103d:
																														if (10 > b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_104b;
																														IL_104b:
																														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																														goto IL_10ad;
																														IL_10ad:
																														num6 -= 2;
																														goto IL_2bf8;
																														IL_10c0:
																														if (12 < b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_10ce;
																														IL_10ce:
																														if (12 > b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_2bf8;
																														IL_10e1:
																														if (15 >= b)
																														{
																															goto IL_10ef;
																														}
																														goto IL_11a0;
																														IL_10ef:
																														if (15 <= b)
																														{
																															num = 200;
																															goto IL_1103;
																														}
																														goto IL_1145;
																														IL_129a:
																														ptr2 += 8;
																														goto IL_2bf8;
																														IL_1103:
																														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																														goto IL_112c;
																														IL_112c:
																														array2[num6 - 1] = 5;
																														goto IL_2bf8;
																														IL_1145:
																														if (14 < b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_1153;
																														IL_1153:
																														if (14 > b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_1161;
																														IL_1161:
																														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																														goto IL_117f;
																														IL_117f:
																														ptr2 += 8;
																														goto IL_118d;
																														IL_118d:
																														num6--;
																														goto IL_2bf8;
																														IL_11a0:
																														if (16 >= b)
																														{
																															goto IL_11ae;
																														}
																														goto IL_124a;
																														IL_11ae:
																														if (16 > b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_11bc;
																														IL_11bc:
																														array2[num6] = array2[num6 - 1];
																														goto IL_11d4;
																														IL_11d4:
																														array4[num6 - 0] = array4[num6 - 1];
																														goto IL_11f2;
																														IL_11f2:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_1216;
																														IL_1216:
																														array3[num6] = array3[num6 - 1];
																														goto IL_122e;
																														IL_122e:
																														num6++;
																														num = 520;
																														goto IL_2bf8;
																														IL_124a:
																														if (17 < b)
																														{
																															goto end_IL_0a6a;
																														}
																														goto IL_1258;
																													}
																													break;
																												}
																												goto IL_0aa8;
																												IL_0ae6:
																												num6 -= 3;
																												goto IL_2bf8;
																												IL_0aa8:
																												((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																												goto IL_0ae6;
																											}
																											goto IL_1583;
																											IL_1a2c:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_1a6c;
																											IL_12ad:
																											if (27 >= b)
																											{
																												goto IL_12bb;
																											}
																											goto IL_1672;
																											IL_12bb:
																											if (27 <= b)
																											{
																												goto IL_12c6;
																											}
																											goto IL_132d;
																											IL_12c6:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_1306;
																											IL_1306:
																											array2[num6 - 2] = 3;
																											goto IL_131a;
																											IL_131a:
																											num6--;
																											goto IL_2bf8;
																											IL_132d:
																											if (22 >= b)
																											{
																												goto IL_133b;
																											}
																											goto IL_14c1;
																											IL_133b:
																											if (22 > b)
																											{
																												goto IL_1349;
																											}
																											goto IL_1459;
																											IL_1349:
																											if (20 >= b)
																											{
																												goto IL_1357;
																											}
																											goto IL_1425;
																											IL_1357:
																											if (20 > b)
																											{
																												goto IL_1362;
																											}
																											goto IL_13dd;
																											IL_1362:
																											if (19 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1370;
																											IL_1370:
																											if (19 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_137e;
																											IL_137e:
																											array2[num6 - 1] = 5;
																											goto IL_1392;
																											IL_1392:
																											array3[num6 - 1] = ((delegate*<string[], string>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																											goto IL_13ca;
																											IL_13ca:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_13dd:
																											*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																											goto IL_13f6;
																											IL_13f6:
																											array2[num6] = 1;
																											goto IL_1404;
																											IL_1404:
																											num6++;
																											goto IL_1412;
																											IL_1412:
																											ptr2 += 16;
																											goto IL_2bf8;
																											IL_1425:
																											if (21 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1433;
																											IL_1433:
																											if (21 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1441;
																											IL_1441:
																											ptr2 = ptr + *(int*)(ptr2 + num3);
																											goto IL_2bf8;
																											IL_1459:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																											goto IL_149a;
																											IL_149a:
																											array2[num6 - 2] = 0;
																											goto IL_14ae;
																											IL_14ae:
																											num6--;
																											goto IL_2bf8;
																											IL_14c1:
																											if (24 >= b)
																											{
																												goto IL_14cf;
																											}
																											goto IL_1583;
																											IL_14cf:
																											if (24 <= b)
																											{
																												goto IL_14da;
																											}
																											goto IL_1502;
																											IL_14da:
																											((delegate*<void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																											goto IL_14ef;
																											IL_14ef:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_1502:
																											if (23 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1510;
																											IL_1510:
																											if (23 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_151e;
																											IL_151e:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_1570;
																											IL_1570:
																											num6--;
																											goto IL_2bf8;
																											IL_1583:
																											if (25 < b)
																											{
																												goto IL_1591;
																											}
																											num = 349;
																											goto IL_161c;
																											IL_1591:
																											if (26 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_159f;
																											IL_159f:
																											if (26 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_15ad;
																											IL_15ad:
																											array2[num6 - 1] = 3;
																											goto IL_15c1;
																											IL_15c1:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_1600;
																											IL_1600:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_1a6c:
																											array2[num6 - 2] = 3;
																											goto IL_1a80;
																											IL_161c:
																											if (25 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_162a;
																											IL_162a:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																											goto IL_1643;
																											IL_1643:
																											array2[num6] = 3;
																											goto IL_1651;
																											IL_1651:
																											num6++;
																											goto IL_165f;
																											IL_165f:
																											ptr2 += 16;
																											goto IL_2bf8;
																											IL_1672:
																											if (31 >= b)
																											{
																												goto IL_1680;
																											}
																											goto IL_1898;
																											IL_1680:
																											if (31 <= b)
																											{
																												goto IL_168b;
																											}
																											goto IL_16b7;
																											IL_168b:
																											global::_003CModule_003E.Lpy_003E_007DtKxME = (Class8.GunResult)array3[num6 - 1];
																											goto IL_16a4;
																											IL_16a4:
																											num6--;
																											goto IL_2bf8;
																											IL_16b7:
																											if (29 >= b)
																											{
																												goto IL_16c5;
																											}
																											goto IL_17a4;
																											IL_16c5:
																											if (29 <= b)
																											{
																												goto IL_16d0;
																											}
																											goto IL_1719;
																											IL_16d0:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																											goto IL_16ea;
																											IL_16ea:
																											array2[num6] = 3;
																											goto IL_16f8;
																											IL_16f8:
																											num6++;
																											goto IL_1706;
																											IL_1706:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_1719:
																											if (28 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1727;
																											IL_1727:
																											if (28 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1735;
																											IL_1735:
																											array2[num6 - 1] = 0;
																											num = 467;
																											goto IL_1752;
																											IL_1752:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_1791;
																											IL_1791:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_17a4:
																											if (30 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											num = 9;
																											goto IL_17bb;
																											IL_1a80:
																											num6--;
																											goto IL_2bf8;
																											IL_17bb:
																											if (30 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_17c9;
																											IL_17c9:
																											array2[num6 - 5] = 4;
																											goto IL_17dd;
																											IL_17dd:
																											array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																											goto IL_186e;
																											IL_186e:
																											num6 -= 4;
																											num = 221;
																											goto IL_1885;
																											IL_1885:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_1898:
																											if (33 >= b)
																											{
																												goto IL_18a6;
																											}
																											goto IL_1986;
																											IL_18a6:
																											if (33 <= b)
																											{
																												goto IL_18b1;
																											}
																											goto IL_1904;
																											IL_18b1:
																											array2[num6] = 0;
																											goto IL_18bf;
																											IL_18bf:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])() ? 1 : 0);
																											goto IL_18e3;
																											IL_18e3:
																											num6++;
																											goto IL_18f1;
																											IL_18f1:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_1904:
																											if (32 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1912;
																											IL_1912:
																											if (32 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1920;
																											IL_1920:
																											array2[num6 - 1] = 3;
																											goto IL_1934;
																											IL_1934:
																											*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_1973;
																											IL_1973:
																											ptr2 += 8;
																											goto IL_2bf8;
																											IL_1986:
																											if (34 >= b)
																											{
																												goto IL_1991;
																											}
																											goto IL_1a10;
																											IL_1991:
																											if (34 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_199f;
																											IL_199f:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_19fd;
																											IL_19fd:
																											num6--;
																											goto IL_2bf8;
																											IL_1a10:
																											if (35 < b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1a1e;
																											IL_1a1e:
																											if (35 > b)
																											{
																												goto end_IL_0a6a;
																											}
																											goto IL_1a2c;
																											continue;
																											end_IL_0a3a:
																											break;
																										}
																										break;
																									}
																									goto IL_1a93;
																									IL_1ac7:
																									ptr2 += 8;
																									goto IL_2bf8;
																									IL_1a93:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									goto IL_1aab;
																									IL_1aab:
																									array2[num6] = 5;
																									goto IL_1ab9;
																									IL_1ab9:
																									num6++;
																									goto IL_1ac7;
																								}
																								break;
																							}
																							goto IL_1ada;
																							IL_2b61:
																							if (71 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2b6c;
																							IL_1ada:
																							if (54 >= b)
																							{
																								goto IL_1ae8;
																							}
																							goto IL_2360;
																							IL_1ae8:
																							if (54 <= b)
																							{
																								goto IL_1af6;
																							}
																							goto IL_1b8c;
																							IL_1af6:
																							array2[num6 - 1] = 4;
																							goto IL_1b0a;
																							IL_1b0a:
																							array3[num6 - 1] = ((delegate*<ref RaycastHit, Vector3>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref RaycastHit>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																							goto IL_1b79;
																							IL_1b79:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_1b8c:
																							if (45 >= b)
																							{
																								goto IL_1b9a;
																							}
																							goto IL_1fa7;
																							IL_1b9a:
																							if (45 <= b)
																							{
																								goto IL_1ba5;
																							}
																							goto IL_1c14;
																							IL_1ba5:
																							array2[num6 - 1] = 3;
																							goto IL_1bb9;
																							IL_1bb9:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							num = 292;
																							goto IL_1c01;
																							IL_1c01:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_1c14:
																							if (40 >= b)
																							{
																								goto IL_1c22;
																							}
																							goto IL_1dc9;
																							IL_1c22:
																							if (40 <= b)
																							{
																								goto IL_1c2d;
																							}
																							goto IL_1c71;
																							IL_1c2d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_1c58;
																							IL_1c58:
																							array2[num6 - 1] = 0;
																							goto IL_2bf8;
																							IL_1c71:
																							if (38 >= b)
																							{
																								goto IL_1c7f;
																							}
																							goto IL_1d6a;
																							IL_1c7f:
																							if (38 <= b)
																							{
																								goto IL_1c8a;
																							}
																							goto IL_1ce0;
																							IL_1c8a:
																							array3[num6] = ((delegate*<string[]>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																							num = 107;
																							goto IL_1cb1;
																							IL_1cb1:
																							array2[num6] = 5;
																							goto IL_1cbf;
																							IL_1cbf:
																							num6++;
																							goto IL_1ccd;
																							IL_1ccd:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_1ce0:
																							if (37 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							num = 333;
																							goto IL_1cf7;
																							IL_2b6c:
																							array2[num6 - 1] = 3;
																							goto IL_2b80;
																							IL_1cf7:
																							if (37 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1d05;
																							IL_1d05:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class122, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class122)array3[num6 - 1]);
																							goto IL_1d43;
																							IL_1d43:
																							array2[num6 - 1] = 0;
																							goto IL_1d57;
																							IL_1d57:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_1d6a:
																							if (39 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1d78;
																							IL_1d78:
																							if (39 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1d86;
																							IL_1d86:
																							*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((string[])array3[num6 - 1]).LongLength;
																							goto IL_1db0;
																							IL_1db0:
																							array2[num6 - 1] = 2;
																							goto IL_2bf8;
																							IL_1dc9:
																							if (42 >= b)
																							{
																								goto IL_1dd7;
																							}
																							goto IL_1ea6;
																							IL_1dd7:
																							if (42 <= b)
																							{
																								goto IL_1de2;
																							}
																							goto IL_1e23;
																							IL_1de2:
																							((Class122)array3[num6 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1e10;
																							IL_1e10:
																							num6 -= 2;
																							goto IL_2bf8;
																							IL_1e23:
																							if (41 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1e31;
																							IL_1e31:
																							if (41 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1e3f;
																							IL_1e3f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_1e7f;
																							IL_1e7f:
																							array2[num6 - 2] = 0;
																							goto IL_1e93;
																							IL_1e93:
																							num6--;
																							goto IL_2bf8;
																							IL_1ea6:
																							if (43 < b)
																							{
																								goto IL_1eb4;
																							}
																							num = 489;
																							goto IL_1f47;
																							IL_1eb4:
																							if (44 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1ec2;
																							IL_1ec2:
																							if (44 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1ed0;
																							IL_1ed0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																							num = 523;
																							goto IL_1f17;
																							IL_1f17:
																							array2[num6 - 1] = 0;
																							goto IL_1f2b;
																							IL_1f2b:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2b80:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_2bbf;
																							IL_1f47:
																							if (43 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_1f55;
																							IL_1f55:
																							array3[num6] = ((delegate*<Class8.GunResult>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																							goto IL_1f78;
																							IL_1f78:
																							array2[num6] = 4;
																							goto IL_1f86;
																							IL_1f86:
																							num6++;
																							goto IL_1f94;
																							IL_1f94:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_1fa7:
																							if (49 >= b)
																							{
																								goto IL_1fb5;
																							}
																							goto IL_213c;
																							IL_1fb5:
																							if (49 <= b)
																							{
																								goto IL_1fc0;
																							}
																							goto IL_200d;
																							IL_1fc0:
																							array3[num6] = ((delegate*<Dictionary<string, int>>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																							goto IL_1fde;
																							IL_1fde:
																							array2[num6] = 5;
																							goto IL_1fec;
																							IL_1fec:
																							num6++;
																							goto IL_1ffa;
																							IL_1ffa:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_200d:
																							if (47 < b)
																							{
																								goto IL_201b;
																							}
																							goto IL_209d;
																							IL_201b:
																							if (48 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2029;
																							IL_2029:
																							if (48 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2037;
																							IL_2037:
																							array2[num6 - 1] = 3;
																							goto IL_204b;
																							IL_204b:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_208a;
																							IL_208a:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_209d:
																							if (47 > b)
																							{
																								goto IL_20a8;
																							}
																							goto IL_20e9;
																							IL_20a8:
																							if (46 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							num = 383;
																							goto IL_20bf;
																							IL_2bbf:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_20bf:
																							if (46 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_20cd;
																							IL_20cd:
																							num10 = ptr2;
																							num11 = -200;
																							num5 = 1;
																							ptr2 = num10 + num11;
																							goto IL_2bf8;
																							IL_20e9:
																							array2[num6] = 0;
																							goto IL_20f7;
																							IL_20f7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							goto IL_211b;
																							IL_211b:
																							num6++;
																							goto IL_2129;
																							IL_2129:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_213c:
																							if (51 < b)
																							{
																								goto IL_214a;
																							}
																							num = 429;
																							goto IL_2259;
																							IL_214a:
																							if (52 >= b)
																							{
																								goto IL_2155;
																							}
																							goto IL_21a5;
																							IL_2155:
																							if (52 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2163;
																							IL_2163:
																							array2[num6] = 15;
																							goto IL_2171;
																							IL_2171:
																							array4[num6] = *(int*)(ptr2 + num3);
																							goto IL_2184;
																							IL_2184:
																							ptr2 += 8;
																							goto IL_2192;
																							IL_2192:
																							num6++;
																							goto IL_2bf8;
																							IL_21a5:
																							if (53 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_21b3;
																							IL_21b3:
																							if (53 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_21c1;
																							IL_21c1:
																							array3[num6 - 1] = new NestedFamANDAssemgetCalendarWeekRule(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array4[num6 - 1], array5);
																							goto IL_2210;
																							IL_2210:
																							array2[num6 - 1] = 15;
																							goto IL_2224;
																							IL_2224:
																							array4[num6 - 1] = *(int*)(ptr2 + num3);
																							goto IL_223d;
																							IL_223d:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2bcf:
																							if (72 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2bda;
																							IL_2259:
																							if (51 <= b)
																							{
																								goto IL_2267;
																							}
																							goto IL_22f7;
																							IL_2267:
																							array2[num6 - 2] = 0;
																							goto IL_227b;
																							IL_227b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]);
																							num = 120;
																							goto IL_22d6;
																							IL_22d6:
																							num6--;
																							goto IL_22e4;
																							IL_22e4:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_22f7:
																							if (50 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2305;
																							IL_2305:
																							if (50 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2313;
																							IL_2313:
																							array3[num6] = ((delegate*<string>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																							goto IL_2331;
																							IL_2331:
																							array2[num6] = 5;
																							goto IL_233f;
																							IL_233f:
																							num6++;
																							goto IL_234d;
																							IL_234d:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2360:
																							if (63 >= b)
																							{
																								goto IL_236e;
																							}
																							goto IL_27eb;
																							IL_236e:
																							if (63 <= b)
																							{
																								goto IL_2379;
																							}
																							goto IL_23df;
																							IL_2379:
																							array2[num6 - 1] = 3;
																							goto IL_238d;
																							IL_238d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_23cc;
																							IL_23cc:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_23df:
																							if (58 >= b)
																							{
																								goto IL_23ed;
																							}
																							goto IL_25be;
																							IL_23ed:
																							if (58 <= b)
																							{
																								goto IL_23f8;
																							}
																							goto IL_2442;
																							IL_23f8:
																							((delegate*<string, void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																							goto IL_2421;
																							IL_2421:
																							num6--;
																							goto IL_242f;
																							IL_242f:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2442:
																							if (56 >= b)
																							{
																								goto IL_2450;
																							}
																							goto IL_253c;
																							IL_2450:
																							if (56 <= b)
																							{
																								goto IL_245b;
																							}
																							goto IL_24ce;
																							IL_245b:
																							((delegate*<int, Vector3, Quaternion, void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]), (Vector3)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
																							goto IL_24ad;
																							IL_24ad:
																							num6 -= 3;
																							goto IL_24bb;
																							IL_24bb:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_24ce:
																							if (55 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_24dc;
																							IL_24dc:
																							if (55 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_24ea;
																							IL_24ea:
																							array2[num6] = 4;
																							goto IL_24f8;
																							IL_24f8:
																							array3[num6] = ((delegate*<Quaternion>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																							goto IL_251b;
																							IL_251b:
																							num6++;
																							goto IL_2529;
																							IL_2529:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_253c:
																							if (57 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_254a;
																							IL_254a:
																							if (57 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2558;
																							IL_2558:
																							array2[num6 - 1] = 3;
																							goto IL_256c;
																							IL_256c:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_25ab;
																							IL_25ab:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_25be:
																							if (60 >= b)
																							{
																								goto IL_25cc;
																							}
																							goto IL_26eb;
																							IL_25cc:
																							if (60 > b)
																							{
																								goto IL_25da;
																							}
																							goto IL_2686;
																							IL_25da:
																							if (59 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_25e8;
																							IL_25e8:
																							if (59 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							num = 482;
																							goto IL_25ff;
																							IL_2bda:
																							if (72 <= b)
																							{
																							}
																							goto end_IL_0a6a;
																							IL_25ff:
																							array2[num6 - 2] = 0;
																							goto IL_2613;
																							IL_2613:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																							goto IL_2665;
																							IL_2665:
																							num6--;
																							goto IL_2673;
																							IL_2673:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2686:
																							array2[num6] = 0;
																							goto IL_2694;
																							IL_2694:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])() ? 1 : 0);
																							num = 155;
																							goto IL_26c1;
																							IL_26c1:
																							num6++;
																							num = 150;
																							goto IL_26d8;
																							IL_26d8:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_26eb:
																							if (61 >= b)
																							{
																								goto IL_26f6;
																							}
																							goto IL_276a;
																							IL_26f6:
																							if (61 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2704;
																							IL_2704:
																							array2[num6 - 1] = 3;
																							goto IL_2718;
																							IL_2718:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_2757;
																							IL_2757:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_276a:
																							if (62 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2778;
																							IL_2778:
																							if (62 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2786;
																							IL_2786:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																							goto IL_27c4;
																							IL_27c4:
																							array2[num6 - 1] = 0;
																							goto IL_27d8;
																							IL_27d8:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_27eb:
																							if (68 >= b)
																							{
																								goto IL_27f9;
																							}
																							goto IL_2a35;
																							IL_27f9:
																							if (68 <= b)
																							{
																								goto IL_2804;
																							}
																							goto IL_285f;
																							IL_2804:
																							array2[num6] = 4;
																							num = 439;
																							goto IL_281b;
																							IL_281b:
																							array3[num6] = ((delegate*<Vector3>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																							goto IL_283e;
																							IL_283e:
																							num6++;
																							goto IL_284c;
																							IL_284c:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_285f:
																							if (65 >= b)
																							{
																								goto IL_286d;
																							}
																							goto IL_2920;
																							IL_286d:
																							if (65 <= b)
																							{
																								goto IL_2878;
																							}
																							goto IL_28a4;
																							IL_2878:
																							global::_003CModule_003E.string_43 = (string)array3[num6 - 1];
																							goto IL_2891;
																							IL_2891:
																							num6--;
																							goto IL_2bf8;
																							IL_28a4:
																							if (64 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_28b2;
																							IL_28b2:
																							if (64 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_28c0;
																							IL_28c0:
																							array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																							goto IL_28f9;
																							IL_28f9:
																							array2[num6 - 2] = 5;
																							goto IL_290d;
																							IL_290d:
																							num6--;
																							goto IL_2bf8;
																							IL_2920:
																							if (66 >= b)
																							{
																								goto IL_292b;
																							}
																							goto IL_2983;
																							IL_292b:
																							if (66 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2939;
																							IL_2939:
																							((delegate*<string, void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																							goto IL_2962;
																							IL_2962:
																							num6--;
																							goto IL_2970;
																							IL_2970:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2983:
																							if (67 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2991;
																							IL_2991:
																							if (67 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_299f;
																							IL_299f:
																							array2[num6 - 1] = 4;
																							goto IL_29b3;
																							IL_29b3:
																							array3[num6 - 1] = ((delegate*<ref RaycastHit, Vector3>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref RaycastHit>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																							goto IL_2a22;
																							IL_2a22:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2a35:
																							if (70 >= b)
																							{
																								goto IL_2a43;
																							}
																							goto IL_2b56;
																							IL_2a43:
																							if (70 <= b)
																							{
																								goto IL_2a4e;
																							}
																							goto IL_2ab3;
																							IL_2a4e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
																							goto IL_2a8c;
																							IL_2a8c:
																							array2[num6 - 1] = 0;
																							goto IL_2aa0;
																							IL_2aa0:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2ab3:
																							if (69 < b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2ac1;
																							IL_2ac1:
																							if (69 > b)
																							{
																								goto end_IL_0a6a;
																							}
																							goto IL_2acf;
																							IL_2acf:
																							array2[num6 - 2] = 0;
																							goto IL_2ae3;
																							IL_2ae3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<Vector3, Vector3, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]) ? 1 : 0);
																							goto IL_2b35;
																							IL_2b35:
																							num6--;
																							goto IL_2b43;
																							IL_2b43:
																							ptr2 += 8;
																							goto IL_2bf8;
																							IL_2b56:
																							if (71 >= b)
																							{
																								goto IL_2b61;
																							}
																							goto IL_2bcf;
																						}
																						goto end_IL_0a7d;
																						continue;
																						end_IL_0a6a:
																						break;
																						IL_0a6a:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_2bf8;
																				continue;
																				end_IL_0a7d:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0ed5:
			while (true)
			{
				IL_0ed5_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0f7d_2:
						array2[num6] = 5;
						num = 189;
						while (true)
						{
							IL_0f94_2:
							num6++;
							num = 294;
							while (true)
							{
								IL_2bf8_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0a7d_2:
											if (b >= 1)
											{
												while (b <= 72)
												{
													num = 220;
													while (true)
													{
														if (36 >= b)
														{
															while (true)
															{
																if (36 > b)
																{
																	while (true)
																	{
																		IL_0a3a_2:
																		if (18 < b)
																		{
																			goto IL_12ad_2;
																		}
																		while (true)
																		{
																			IL_0a2d_2:
																			if (18 > b)
																			{
																				while (true)
																				{
																					IL_0a1d_2:
																					if (9 >= b)
																					{
																						while (true)
																						{
																							IL_0a0d_2:
																							if (9 <= b)
																							{
																								while (true)
																								{
																									IL_09cb_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									while (true)
																									{
																										IL_09ac_2:
																										array2[num6 - 2] = 0;
																										num = 607;
																										while (true)
																										{
																											if (num != 607)
																											{
																												if (num != 1588)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 38:
																													goto IL_09ac_2;
																												case 10:
																												case 232:
																													goto IL_09cb_2;
																												case 518:
																													goto IL_0a0d_2;
																												case 598:
																													goto IL_0a1d_2;
																												case 423:
																													goto IL_0a2d_2;
																												case 341:
																													goto IL_0a3a_2;
																												case 378:
																													goto end_IL_0a3a_2;
																												case 220:
																													goto end_IL_0a4a;
																												case 403:
																													goto end_IL_0a5a;
																												case 119:
																													goto IL_0a7d_2;
																												case 450:
																													goto end_IL_0a7d_2;
																												case 162:
																												case 582:
																													goto end_IL_0a8d;
																												case 116:
																												case 397:
																													goto IL_0aa8_2;
																												case 190:
																													goto IL_0ae6_2;
																												case 413:
																													goto IL_0b0c_2;
																												case 393:
																													goto IL_0b1a_2;
																												case 25:
																												case 259:
																													goto IL_0b25_2;
																												case 147:
																													goto IL_0b33_2;
																												case 503:
																													goto IL_0b56_2;
																												case 471:
																													goto IL_0b69_2;
																												case 465:
																													goto IL_0b77_2;
																												case 126:
																													goto IL_0b93_2;
																												case 496:
																													goto IL_0ba1_2;
																												case 472:
																												case 531:
																													goto IL_0bac_2;
																												case 339:
																													goto IL_0bec_2;
																												case 40:
																													goto IL_0c00_2;
																												case 485:
																													goto IL_0c13_2;
																												case 106:
																													goto IL_0c21_2;
																												case 260:
																												case 517:
																													goto IL_0c2f_2;
																												case 463:
																													goto IL_0c48_2;
																												case 97:
																													goto IL_0c56_2;
																												case 50:
																													goto IL_0c64_2;
																												case 343:
																													goto IL_0c77_2;
																												case 512:
																													goto IL_0c85_2;
																												case 84:
																												case 398:
																													goto IL_0c9c_2;
																												case 258:
																													goto IL_0cc5_2;
																												case 593:
																													goto IL_0cd3_2;
																												case 180:
																													goto IL_0ce6_2;
																												case 278:
																													goto IL_0cf4_2;
																												case 440:
																												case 502:
																													goto IL_0cff_2;
																												case 464:
																													goto IL_0d3f_2;
																												case 168:
																													goto IL_0d53_2;
																												case 49:
																													goto IL_0d66_2;
																												case 13:
																													goto IL_0d74_2;
																												case 45:
																												case 309:
																													goto IL_0d8b_2;
																												case 297:
																													goto IL_0dd4_2;
																												case 547:
																													goto IL_0de8_2;
																												case 466:
																													goto IL_0dfb_2;
																												case 452:
																													goto IL_0e06_2;
																												case 213:
																												case 559:
																													goto IL_0e14_2;
																												case 539:
																													goto IL_0e54_2;
																												case 282:
																													goto IL_0e68_2;
																												case 356:
																													goto IL_0e7b_2;
																												case 338:
																													goto IL_0e89_2;
																												case 385:
																												case 545:
																													goto IL_0e97_2;
																												case 109:
																													goto IL_0eaa_2;
																												case 102:
																													goto IL_0eb8_2;
																												case 263:
																												case 312:
																													goto end_IL_0a9d;
																												case 179:
																													goto IL_0f7d_2;
																												case 189:
																													goto IL_0f94_2;
																												case 234:
																													goto IL_0fb0_2;
																												case 214:
																													goto IL_0fbe_2;
																												case 364:
																												case 536:
																													goto IL_0fc9_2;
																												case 461:
																													goto IL_0fdd_2;
																												case 181:
																													goto IL_101c_2;
																												case 490:
																													goto IL_102f_2;
																												case 422:
																													goto IL_103d_2;
																												case 154:
																												case 192:
																													goto IL_104b_2;
																												case 149:
																													goto IL_10ad_2;
																												case 425:
																													goto IL_10c0_2;
																												case 513:
																													goto IL_10ce_2;
																												case 204:
																													goto IL_10e1_2;
																												case 359:
																													goto IL_10ef_2;
																												case 200:
																												case 586:
																													goto IL_1103_2;
																												case 80:
																													goto IL_112c_2;
																												case 522:
																													goto IL_1145_2;
																												case 510:
																													goto IL_1153_2;
																												case 110:
																												case 194:
																													goto IL_1161_2;
																												case 371:
																													goto IL_117f_2;
																												case 421:
																													goto IL_118d_2;
																												case 534:
																													goto IL_11a0_2;
																												case 288:
																													goto IL_11ae_2;
																												case 322:
																												case 460:
																													goto IL_11bc_2;
																												case 246:
																													goto IL_11d4_2;
																												case 51:
																													goto IL_11f2_2;
																												case 487:
																													goto IL_1216_2;
																												case 388:
																													goto IL_122e_2;
																												case 405:
																													goto IL_124a_2;
																												case 8:
																													goto IL_1258_2;
																												case 134:
																												case 495:
																													goto IL_1266_2;
																												case 61:
																													goto IL_1274_2;
																												case 318:
																													goto IL_128c_2;
																												case 575:
																													goto IL_129a_2;
																												case 448:
																													goto IL_12ad_2;
																												case 226:
																													goto IL_12bb_2;
																												case 475:
																												case 481:
																													goto IL_12c6_2;
																												case 459:
																													goto IL_1306_2;
																												case 402:
																													goto IL_131a_2;
																												case 314:
																													goto IL_132d_2;
																												case 188:
																													goto IL_133b_2;
																												case 196:
																													goto IL_1349_2;
																												case 177:
																													goto IL_1357_2;
																												case 167:
																													goto IL_1362_2;
																												case 433:
																													goto IL_1370_2;
																												case 39:
																												case 331:
																													goto IL_137e_2;
																												case 231:
																													goto IL_1392_2;
																												case 367:
																													goto IL_13ca_2;
																												case 121:
																												case 506:
																													goto IL_13dd_2;
																												case 311:
																													goto IL_13f6_2;
																												case 15:
																													goto IL_1404_2;
																												case 419:
																													goto IL_1412_2;
																												case 27:
																													goto IL_1425_2;
																												case 65:
																													goto IL_1433_2;
																												case 128:
																												case 368:
																													goto IL_1441_2;
																												case 334:
																												case 596:
																													goto IL_1459_2;
																												case 600:
																													goto IL_149a_2;
																												case 570:
																													goto IL_14ae_2;
																												case 212:
																													goto IL_14c1_2;
																												case 41:
																													goto IL_14cf_2;
																												case 185:
																												case 317:
																													goto IL_14da_2;
																												case 300:
																													goto IL_14ef_2;
																												case 344:
																													goto IL_1502_2;
																												case 183:
																													goto IL_1510_2;
																												case 22:
																												case 219:
																													goto IL_151e_2;
																												case 554:
																													goto IL_1570_2;
																												case 329:
																													goto end_IL_0999_2;
																												case 187:
																													goto IL_1591_2;
																												case 308:
																													goto IL_159f_2;
																												case 261:
																												case 544:
																													goto IL_15ad_2;
																												case 345:
																													goto IL_15c1_2;
																												case 526:
																													goto IL_1600_2;
																												case 349:
																													goto IL_161c_2;
																												case 160:
																												case 163:
																													goto IL_162a_2;
																												case 585:
																													goto IL_1643_2;
																												case 374:
																													goto IL_1651_2;
																												case 566:
																													goto IL_165f_2;
																												case 360:
																													goto IL_1672_2;
																												case 67:
																													goto IL_1680_2;
																												case 78:
																												case 113:
																													goto IL_168b_2;
																												case 216:
																													goto IL_16a4_2;
																												case 417:
																													goto IL_16b7_2;
																												case 326:
																													goto IL_16c5_2;
																												case 91:
																												case 389:
																													goto IL_16d0_2;
																												case 529:
																													goto IL_16ea_2;
																												case 458:
																													goto IL_16f8_2;
																												case 83:
																													goto IL_1706_2;
																												case 428:
																													goto IL_1719_2;
																												case 156:
																													goto IL_1727_2;
																												case 132:
																												case 208:
																													goto IL_1735_2;
																												case 467:
																													goto IL_1752_2;
																												case 474:
																													goto IL_1791_2;
																												case 521:
																													goto IL_17a4_2;
																												case 9:
																													goto IL_17bb_2;
																												case 182:
																												case 552:
																													goto IL_17c9_2;
																												case 432:
																													goto IL_17dd_2;
																												case 454:
																													goto IL_186e_2;
																												case 221:
																													goto IL_1885_2;
																												case 141:
																													goto IL_1898_2;
																												case 291:
																													goto IL_18a6_2;
																												case 146:
																												case 319:
																													goto IL_18b1_2;
																												case 447:
																													goto IL_18bf_2;
																												case 542:
																													goto IL_18e3_2;
																												case 111:
																													goto IL_18f1_2;
																												case 178:
																													goto IL_1904_2;
																												case 442:
																													goto IL_1912_2;
																												case 75:
																												case 514:
																													goto IL_1920_2;
																												case 511:
																													goto IL_1934_2;
																												case 444:
																													goto IL_1973_2;
																												case 557:
																													goto IL_1986_2;
																												case 12:
																													goto IL_1991_2;
																												case 175:
																												case 427:
																													goto IL_199f_2;
																												case 74:
																													goto IL_19fd_2;
																												case 2:
																													goto IL_1a10_2;
																												case 363:
																													goto IL_1a1e_2;
																												case 130:
																												case 249:
																													goto IL_1a2c_2;
																												case 553:
																													goto IL_1a6c_2;
																												case 92:
																													goto IL_1a80_2;
																												case 303:
																												case 577:
																													goto IL_1a93_2;
																												case 492:
																													goto IL_1aab_2;
																												case 390:
																													goto IL_1ab9_2;
																												case 118:
																													goto IL_1ac7_2;
																												case 240:
																													goto IL_1ada_2;
																												case 151:
																													goto IL_1ae8_2;
																												case 30:
																												case 52:
																													goto IL_1af6_2;
																												case 424:
																													goto IL_1b0a_2;
																												case 340:
																													goto IL_1b79_2;
																												case 325:
																													goto IL_1b8c_2;
																												case 145:
																													goto IL_1b9a_2;
																												case 327:
																												case 486:
																													goto IL_1ba5_2;
																												case 95:
																													goto IL_1bb9_2;
																												case 292:
																													goto IL_1c01_2;
																												case 456:
																													goto IL_1c14_2;
																												case 295:
																													goto IL_1c22_2;
																												case 88:
																												case 571:
																													goto IL_1c2d_2;
																												case 36:
																													goto IL_1c58_2;
																												case 164:
																													goto IL_1c71_2;
																												case 159:
																													goto IL_1c7f_2;
																												case 228:
																												case 562:
																													goto IL_1c8a_2;
																												case 107:
																													goto IL_1cb1_2;
																												case 355:
																													goto IL_1cbf_2;
																												case 436:
																													goto IL_1ccd_2;
																												case 491:
																													goto IL_1ce0_2;
																												case 333:
																													goto IL_1cf7_2;
																												case 174:
																												case 386:
																													goto IL_1d05_2;
																												case 87:
																													goto IL_1d43_2;
																												case 392:
																													goto IL_1d57_2;
																												case 148:
																													goto IL_1d6a_2;
																												case 462:
																													goto IL_1d78_2;
																												case 276:
																												case 438:
																													goto IL_1d86_2;
																												case 396:
																													goto IL_1db0_2;
																												case 237:
																													goto IL_1dc9_2;
																												case 66:
																													goto IL_1dd7_2;
																												case 301:
																												case 395:
																													goto IL_1de2_2;
																												case 207:
																													goto IL_1e10_2;
																												case 289:
																													goto IL_1e23_2;
																												case 267:
																													goto IL_1e31_2;
																												case 46:
																												case 59:
																													goto IL_1e3f_2;
																												case 64:
																													goto IL_1e7f_2;
																												case 375:
																													goto IL_1e93_2;
																												case 414:
																													goto IL_1ea6_2;
																												case 247:
																													goto IL_1eb4_2;
																												case 34:
																													goto IL_1ec2_2;
																												case 233:
																												case 302:
																													goto IL_1ed0_2;
																												case 523:
																													goto IL_1f17_2;
																												case 140:
																													goto IL_1f2b_2;
																												case 489:
																													goto IL_1f47_2;
																												case 98:
																												case 591:
																													goto IL_1f55_2;
																												case 135:
																													goto IL_1f78_2;
																												case 266:
																													goto IL_1f86_2;
																												case 384:
																													goto IL_1f94_2;
																												case 264:
																													goto IL_1fa7_2;
																												case 293:
																													goto IL_1fb5_2;
																												case 369:
																												case 541:
																													goto IL_1fc0_2;
																												case 283:
																													goto IL_1fde_2;
																												case 305:
																													goto IL_1fec_2;
																												case 193:
																													goto IL_1ffa_2;
																												case 251:
																													goto IL_200d_2;
																												case 269:
																													goto IL_201b_2;
																												case 387:
																													goto IL_2029_2;
																												case 455:
																												case 538:
																													goto IL_2037_2;
																												case 275:
																													goto IL_204b_2;
																												case 519:
																													goto IL_208a_2;
																												case 597:
																													goto IL_209d_2;
																												case 262:
																													goto IL_20a8_2;
																												case 383:
																													goto IL_20bf_2;
																												case 114:
																												case 443:
																													goto IL_20cd_2;
																												case 426:
																												case 563:
																													goto IL_20e9_2;
																												case 441:
																													goto IL_20f7_2;
																												case 108:
																													goto IL_211b_2;
																												case 239:
																													goto IL_2129_2;
																												case 11:
																													goto IL_213c_2;
																												case 478:
																													goto IL_214a_2;
																												case 143:
																													goto IL_2155_2;
																												case 96:
																												case 500:
																													goto IL_2163_2;
																												case 381:
																													goto IL_2171_2;
																												case 504:
																													goto IL_2184_2;
																												case 29:
																													goto IL_2192_2;
																												case 122:
																													goto IL_21a5_2;
																												case 286:
																													goto IL_21b3_2;
																												case 142:
																												case 161:
																													goto IL_21c1_2;
																												case 509:
																													goto IL_2210_2;
																												case 287:
																													goto IL_2224_2;
																												case 361:
																													goto IL_223d_2;
																												case 429:
																													goto IL_2259_2;
																												case 53:
																												case 124:
																													goto IL_2267_2;
																												case 205:
																													goto IL_227b_2;
																												case 120:
																													goto IL_22d6_2;
																												case 537:
																													goto IL_22e4_2;
																												case 380:
																													goto IL_22f7_2;
																												case 323:
																													goto IL_2305_2;
																												case 453:
																												case 477:
																													goto IL_2313_2;
																												case 324:
																													goto IL_2331_2;
																												case 310:
																													goto IL_233f_2;
																												case 298:
																													goto IL_234d_2;
																												case 574:
																													goto IL_2360_2;
																												case 407:
																													goto IL_236e_2;
																												case 4:
																												case 280:
																													goto IL_2379_2;
																												case 103:
																													goto IL_238d_2;
																												case 273:
																													goto IL_23cc_2;
																												case 198:
																													goto IL_23df_2;
																												case 391:
																													goto IL_23ed_2;
																												case 28:
																												case 532:
																													goto IL_23f8_2;
																												case 125:
																													goto IL_2421_2;
																												case 268:
																													goto IL_242f_2;
																												case 236:
																													goto IL_2442_2;
																												case 69:
																													goto IL_2450_2;
																												case 244:
																												case 350:
																													goto IL_245b_2;
																												case 409:
																													goto IL_24ad_2;
																												case 470:
																													goto IL_24bb_2;
																												case 479:
																													goto IL_24ce_2;
																												case 171:
																													goto IL_24dc_2;
																												case 117:
																												case 565:
																													goto IL_24ea_2;
																												case 406:
																													goto IL_24f8_2;
																												case 551:
																													goto IL_251b_2;
																												case 245:
																													goto IL_2529_2;
																												case 316:
																													goto IL_253c_2;
																												case 540:
																													goto IL_254a_2;
																												case 250:
																												case 564:
																													goto IL_2558_2;
																												case 157:
																													goto IL_256c_2;
																												case 56:
																													goto IL_25ab_2;
																												case 57:
																													goto IL_25be_2;
																												case 412:
																													goto IL_25cc_2;
																												case 211:
																													goto IL_25da_2;
																												case 498:
																													goto IL_25e8_2;
																												case 482:
																												case 584:
																													goto IL_25ff_2;
																												case 399:
																													goto IL_2613_2;
																												case 255:
																													goto IL_2665_2;
																												case 527:
																													goto IL_2673_2;
																												case 139:
																												case 270:
																													goto IL_2686_2;
																												case 576:
																													goto IL_2694_2;
																												case 155:
																													goto IL_26c1_2;
																												case 150:
																													goto IL_26d8_2;
																												case 241:
																													goto IL_26eb_2;
																												case 144:
																													goto IL_26f6_2;
																												case 202:
																												case 218:
																													goto IL_2704_2;
																												case 17:
																													goto IL_2718_2;
																												case 136:
																													goto IL_2757_2;
																												case 476:
																													goto IL_276a_2;
																												case 222:
																													goto IL_2778_2;
																												case 55:
																												case 328:
																													goto IL_2786_2;
																												case 235:
																													goto IL_27c4_2;
																												case 348:
																													goto IL_27d8_2;
																												case 404:
																													goto IL_27eb_2;
																												case 131:
																													goto IL_27f9_2;
																												case 23:
																												case 508:
																													goto IL_2804_2;
																												case 439:
																													goto IL_281b_2;
																												case 357:
																													goto IL_283e_2;
																												case 451:
																													goto IL_284c_2;
																												case 112:
																													goto IL_285f_2;
																												case 24:
																													goto IL_286d_2;
																												case 284:
																												case 336:
																													goto IL_2878_2;
																												case 505:
																													goto IL_2891_2;
																												case 457:
																													goto IL_28a4_2;
																												case 72:
																													goto IL_28b2_2;
																												case 337:
																												case 437:
																													goto IL_28c0_2;
																												case 206:
																													goto IL_28f9_2;
																												case 353:
																													goto IL_290d_2;
																												case 152:
																													goto IL_2920_2;
																												case 44:
																													goto IL_292b_2;
																												case 100:
																												case 296:
																													goto IL_2939_2;
																												case 127:
																													goto IL_2962_2;
																												case 568:
																													goto IL_2970_2;
																												case 101:
																													goto IL_2983_2;
																												case 420:
																													goto IL_2991_2;
																												case 73:
																												case 599:
																													goto IL_299f_2;
																												case 494:
																													goto IL_29b3_2;
																												case 93:
																													goto IL_2a22_2;
																												case 5:
																													goto IL_2a35_2;
																												case 6:
																													goto IL_2a43_2;
																												case 285:
																												case 473:
																													goto IL_2a4e_2;
																												case 569:
																													goto IL_2a8c_2;
																												case 81:
																													goto IL_2aa0_2;
																												case 21:
																													goto IL_2ab3_2;
																												case 516:
																													goto IL_2ac1_2;
																												case 362:
																												case 524:
																													goto IL_2acf_2;
																												case 435:
																													goto IL_2ae3_2;
																												case 90:
																													goto IL_2b35_2;
																												case 416:
																													goto IL_2b43_2;
																												case 229:
																													goto IL_2b56_2;
																												case 1:
																													goto IL_2b61_2;
																												case 0:
																												case 54:
																													goto IL_2b6c_2;
																												case 272:
																													goto IL_2b80_2;
																												case 94:
																													goto IL_2bbf_2;
																												case 400:
																													goto IL_2bcf_2;
																												case 16:
																													goto IL_2bda_2;
																												case 3:
																												case 14:
																												case 18:
																												case 20:
																												case 26:
																												case 33:
																												case 37:
																												case 42:
																												case 43:
																												case 47:
																												case 48:
																												case 63:
																												case 76:
																												case 77:
																												case 85:
																												case 86:
																												case 89:
																												case 104:
																												case 105:
																												case 115:
																												case 123:
																												case 133:
																												case 153:
																												case 166:
																												case 169:
																												case 170:
																												case 173:
																												case 186:
																												case 209:
																												case 217:
																												case 225:
																												case 227:
																												case 243:
																												case 248:
																												case 254:
																												case 256:
																												case 257:
																												case 265:
																												case 271:
																												case 277:
																												case 279:
																												case 290:
																												case 313:
																												case 321:
																												case 335:
																												case 346:
																												case 354:
																												case 370:
																												case 373:
																												case 376:
																												case 377:
																												case 379:
																												case 382:
																												case 401:
																												case 418:
																												case 434:
																												case 469:
																												case 480:
																												case 499:
																												case 501:
																												case 507:
																												case 525:
																												case 533:
																												case 535:
																												case 543:
																												case 548:
																												case 550:
																												case 558:
																												case 561:
																												case 572:
																												case 581:
																												case 589:
																												case 590:
																												case 592:
																												case 594:
																													goto end_IL_0a6a_2;
																												case 7:
																												case 32:
																												case 35:
																												case 58:
																												case 60:
																												case 68:
																												case 70:
																												case 71:
																												case 79:
																												case 82:
																												case 99:
																												case 129:
																												case 137:
																												case 138:
																												case 165:
																												case 172:
																												case 176:
																												case 195:
																												case 197:
																												case 199:
																												case 201:
																												case 203:
																												case 210:
																												case 215:
																												case 223:
																												case 224:
																												case 230:
																												case 238:
																												case 242:
																												case 252:
																												case 253:
																												case 274:
																												case 281:
																												case 294:
																												case 299:
																												case 304:
																												case 306:
																												case 307:
																												case 315:
																												case 320:
																												case 330:
																												case 332:
																												case 342:
																												case 347:
																												case 351:
																												case 352:
																												case 358:
																												case 365:
																												case 366:
																												case 372:
																												case 394:
																												case 410:
																												case 411:
																												case 431:
																												case 445:
																												case 449:
																												case 468:
																												case 483:
																												case 484:
																												case 488:
																												case 493:
																												case 497:
																												case 520:
																												case 528:
																												case 530:
																												case 546:
																												case 560:
																												case 573:
																												case 578:
																												case 579:
																												case 580:
																												case 583:
																												case 587:
																												case 588:
																												case 595:
																													goto IL_2bf8_2;
																												case 549:
																													ptr2 = ptr;
																													goto IL_2bf8_2;
																												case 62:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LeaveParent.ActivityTrackerCreateSubdirectory);
																													goto case 549;
																												case 446:
																													array7[0] = this;
																													goto case 62;
																												case 430:
																													array7 = new object[14];
																													goto case 446;
																												case 191:
																													array6 = new long[5];
																													goto case 430;
																												case 408:
																													array5 = new int[7];
																													num = 191;
																													goto case 191;
																												case 19:
																													array4 = new int[5];
																													goto case 408;
																												case 31:
																													array3 = new object[5];
																													goto case 19;
																												case 184:
																													array2 = new byte[5];
																													goto case 31;
																												case 415:
																													num4 = num2 * 8;
																													goto case 184;
																												case 158:
																													num3 = num2 * 4;
																													num = 415;
																													goto case 415;
																												case 555:
																													num2 = 1;
																													goto case 158;
																												case 556:
																													goto end_IL_0ee3;
																												case 515:
																												case 567:
																													return;
																												}
																												continue;
																											}
																											num6--;
																											goto IL_2bf8_2;
																											continue;
																											end_IL_0999_2:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_0b0c_2;
																							IL_0e7b_2:
																							if (8 < b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							goto IL_0e89_2;
																							IL_0b0c_2:
																							if (4 >= b)
																							{
																								goto IL_0b1a_2;
																							}
																							goto IL_0ce6_2;
																							IL_0b1a_2:
																							if (4 <= b)
																							{
																								goto IL_0b25_2;
																							}
																							goto IL_0b93_2;
																							IL_0b25_2:
																							array2[num6] = 0;
																							goto IL_0b33_2;
																							IL_0b33_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																							goto IL_0b56_2;
																							IL_0b56_2:
																							array3[num6] = null;
																							num = 471;
																							goto IL_0b69_2;
																							IL_0b69_2:
																							num6++;
																							goto IL_0b77_2;
																							IL_0b77_2:
																							ptr2 += 8;
																							num = 483;
																							goto IL_2bf8_2;
																							IL_0b93_2:
																							if (2 >= b)
																							{
																								goto IL_0ba1_2;
																							}
																							goto IL_0c77_2;
																							IL_0ba1_2:
																							if (2 <= b)
																							{
																								goto IL_0bac_2;
																							}
																							goto IL_0c13_2;
																							IL_0bac_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0bec_2;
																							IL_0bec_2:
																							array2[num6 - 2] = 0;
																							goto IL_0c00_2;
																							IL_0c00_2:
																							num6--;
																							goto IL_2bf8_2;
																							IL_0c13_2:
																							if (1 < b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							goto IL_0c21_2;
																							IL_0c21_2:
																							if (1 > b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							goto IL_0c2f_2;
																							IL_0c2f_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																							goto IL_0c48_2;
																							IL_0c48_2:
																							array2[num6] = 0;
																							goto IL_0c56_2;
																							IL_0c56_2:
																							num6++;
																							goto IL_0c64_2;
																							IL_0c64_2:
																							ptr2 += 8;
																							goto IL_2bf8_2;
																							IL_0c77_2:
																							if (3 < b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							goto IL_0c85_2;
																							IL_0c85_2:
																							if (3 > b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							num = 398;
																							goto IL_0c9c_2;
																							IL_0e89_2:
																							if (8 > b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							goto IL_0e97_2;
																							IL_0c9c_2:
																							reference = ref array5[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0cc5_2;
																							IL_0cc5_2:
																							ptr2 += 8;
																							goto IL_0cd3_2;
																							IL_0cd3_2:
																							num6--;
																							goto IL_2bf8_2;
																							IL_0ce6_2:
																							if (6 >= b)
																							{
																								goto IL_0cf4_2;
																							}
																							goto IL_0dfb_2;
																							IL_0cf4_2:
																							if (6 <= b)
																							{
																								goto IL_0cff_2;
																							}
																							goto IL_0d66_2;
																							IL_0cff_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0d3f_2;
																							IL_0d3f_2:
																							array2[num6 - 2] = 0;
																							goto IL_0d53_2;
																							IL_0d53_2:
																							num6--;
																							goto IL_2bf8_2;
																							IL_0d66_2:
																							if (5 < b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							goto IL_0d74_2;
																							IL_0d74_2:
																							if (5 > b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							num = 309;
																							goto IL_0d8b_2;
																							IL_0e97_2:
																							num6--;
																							goto IL_2bf8_2;
																							IL_0d8b_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							num = 297;
																							goto IL_0dd4_2;
																							IL_0dd4_2:
																							array2[num6 - 2] = 0;
																							goto IL_0de8_2;
																							IL_0de8_2:
																							num6--;
																							goto IL_2bf8_2;
																							IL_0dfb_2:
																							if (7 >= b)
																							{
																								goto IL_0e06_2;
																							}
																							goto IL_0e7b_2;
																							IL_0e06_2:
																							if (7 > b)
																							{
																								goto end_IL_0a6a_2;
																							}
																							goto IL_0e14_2;
																							IL_0e14_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0e54_2;
																							IL_0e54_2:
																							array2[num6 - 2] = 0;
																							goto IL_0e68_2;
																							IL_0e68_2:
																							num6--;
																							goto IL_2bf8_2;
																						}
																						break;
																					}
																					goto IL_0eaa_2;
																					IL_128c_2:
																					num6++;
																					goto IL_129a_2;
																					IL_0eaa_2:
																					if (13 >= b)
																					{
																						goto IL_0eb8_2;
																					}
																					goto IL_10e1_2;
																					IL_0eb8_2:
																					if (13 <= b)
																					{
																						goto end_IL_0a9d;
																					}
																					goto IL_0fb0_2;
																					IL_0fb0_2:
																					if (11 >= b)
																					{
																						goto IL_0fbe_2;
																					}
																					goto IL_10c0_2;
																					IL_0fbe_2:
																					if (11 <= b)
																					{
																						goto IL_0fc9_2;
																					}
																					goto IL_102f_2;
																					IL_0fc9_2:
																					array2[num6 - 1] = 0;
																					goto IL_0fdd_2;
																					IL_0fdd_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																					goto IL_101c_2;
																					IL_101c_2:
																					ptr2 += 8;
																					goto IL_2bf8_2;
																					IL_102f_2:
																					if (10 < b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_103d_2;
																					IL_103d_2:
																					if (10 > b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_104b_2;
																					IL_104b_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_10ad_2;
																					IL_10ad_2:
																					num6 -= 2;
																					goto IL_2bf8_2;
																					IL_10c0_2:
																					if (12 < b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_10ce_2;
																					IL_10ce_2:
																					if (12 > b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_2bf8_2;
																					IL_10e1_2:
																					if (15 >= b)
																					{
																						goto IL_10ef_2;
																					}
																					goto IL_11a0_2;
																					IL_10ef_2:
																					if (15 <= b)
																					{
																						num = 200;
																						goto IL_1103_2;
																					}
																					goto IL_1145_2;
																					IL_129a_2:
																					ptr2 += 8;
																					goto IL_2bf8_2;
																					IL_1103_2:
																					array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																					goto IL_112c_2;
																					IL_112c_2:
																					array2[num6 - 1] = 5;
																					goto IL_2bf8_2;
																					IL_1145_2:
																					if (14 < b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_1153_2;
																					IL_1153_2:
																					if (14 > b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_1161_2;
																					IL_1161_2:
																					array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																					goto IL_117f_2;
																					IL_117f_2:
																					ptr2 += 8;
																					goto IL_118d_2;
																					IL_118d_2:
																					num6--;
																					goto IL_2bf8_2;
																					IL_11a0_2:
																					if (16 >= b)
																					{
																						goto IL_11ae_2;
																					}
																					goto IL_124a_2;
																					IL_11ae_2:
																					if (16 > b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_11bc_2;
																					IL_11bc_2:
																					array2[num6] = array2[num6 - 1];
																					goto IL_11d4_2;
																					IL_11d4_2:
																					array4[num6 - 0] = array4[num6 - 1];
																					goto IL_11f2_2;
																					IL_11f2_2:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_1216_2;
																					IL_1216_2:
																					array3[num6] = array3[num6 - 1];
																					goto IL_122e_2;
																					IL_122e_2:
																					num6++;
																					num = 520;
																					goto IL_2bf8_2;
																					IL_124a_2:
																					if (17 < b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_1258_2;
																					IL_1258_2:
																					if (17 > b)
																					{
																						goto end_IL_0a6a_2;
																					}
																					goto IL_1266_2;
																					IL_1266_2:
																					array2[num6] = 5;
																					goto IL_1274_2;
																					IL_1274_2:
																					array3[num6] = array7[*(int*)(ptr2 + num3)];
																					goto IL_128c_2;
																				}
																				break;
																			}
																			goto IL_0aa8_2;
																			IL_0ae6_2:
																			num6 -= 3;
																			goto IL_2bf8_2;
																			IL_0aa8_2:
																			((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																			goto IL_0ae6_2;
																		}
																		goto IL_1583_2;
																		IL_1a2c_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_1a6c_2;
																		IL_12ad_2:
																		if (27 >= b)
																		{
																			goto IL_12bb_2;
																		}
																		goto IL_1672_2;
																		IL_12bb_2:
																		if (27 <= b)
																		{
																			goto IL_12c6_2;
																		}
																		goto IL_132d_2;
																		IL_12c6_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_1306_2;
																		IL_1306_2:
																		array2[num6 - 2] = 3;
																		goto IL_131a_2;
																		IL_131a_2:
																		num6--;
																		goto IL_2bf8_2;
																		IL_132d_2:
																		if (22 >= b)
																		{
																			goto IL_133b_2;
																		}
																		goto IL_14c1_2;
																		IL_133b_2:
																		if (22 > b)
																		{
																			goto IL_1349_2;
																		}
																		goto IL_1459_2;
																		IL_1349_2:
																		if (20 >= b)
																		{
																			goto IL_1357_2;
																		}
																		goto IL_1425_2;
																		IL_1357_2:
																		if (20 > b)
																		{
																			goto IL_1362_2;
																		}
																		goto IL_13dd_2;
																		IL_1362_2:
																		if (19 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1370_2;
																		IL_1370_2:
																		if (19 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_137e_2;
																		IL_137e_2:
																		array2[num6 - 1] = 5;
																		goto IL_1392_2;
																		IL_1392_2:
																		array3[num6 - 1] = ((delegate*<string[], string>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																		goto IL_13ca_2;
																		IL_13ca_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_13dd_2:
																		*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																		goto IL_13f6_2;
																		IL_13f6_2:
																		array2[num6] = 1;
																		goto IL_1404_2;
																		IL_1404_2:
																		num6++;
																		goto IL_1412_2;
																		IL_1412_2:
																		ptr2 += 16;
																		goto IL_2bf8_2;
																		IL_1425_2:
																		if (21 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1433_2;
																		IL_1433_2:
																		if (21 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1441_2;
																		IL_1441_2:
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto IL_2bf8_2;
																		IL_1459_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																		goto IL_149a_2;
																		IL_149a_2:
																		array2[num6 - 2] = 0;
																		goto IL_14ae_2;
																		IL_14ae_2:
																		num6--;
																		goto IL_2bf8_2;
																		IL_14c1_2:
																		if (24 >= b)
																		{
																			goto IL_14cf_2;
																		}
																		goto IL_1583_2;
																		IL_14cf_2:
																		if (24 <= b)
																		{
																			goto IL_14da_2;
																		}
																		goto IL_1502_2;
																		IL_14da_2:
																		((delegate*<void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
																		goto IL_14ef_2;
																		IL_14ef_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_1502_2:
																		if (23 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1510_2;
																		IL_1510_2:
																		if (23 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_151e_2;
																		IL_151e_2:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_1570_2;
																		IL_1570_2:
																		num6--;
																		goto IL_2bf8_2;
																		IL_1583_2:
																		if (25 < b)
																		{
																			goto IL_1591_2;
																		}
																		num = 349;
																		goto IL_161c_2;
																		IL_1591_2:
																		if (26 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_159f_2;
																		IL_159f_2:
																		if (26 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_15ad_2;
																		IL_15ad_2:
																		array2[num6 - 1] = 3;
																		goto IL_15c1_2;
																		IL_15c1_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_1600_2;
																		IL_1600_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_1a6c_2:
																		array2[num6 - 2] = 3;
																		goto IL_1a80_2;
																		IL_161c_2:
																		if (25 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_162a_2;
																		IL_162a_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																		goto IL_1643_2;
																		IL_1643_2:
																		array2[num6] = 3;
																		goto IL_1651_2;
																		IL_1651_2:
																		num6++;
																		goto IL_165f_2;
																		IL_165f_2:
																		ptr2 += 16;
																		goto IL_2bf8_2;
																		IL_1672_2:
																		if (31 >= b)
																		{
																			goto IL_1680_2;
																		}
																		goto IL_1898_2;
																		IL_1680_2:
																		if (31 <= b)
																		{
																			goto IL_168b_2;
																		}
																		goto IL_16b7_2;
																		IL_168b_2:
																		global::_003CModule_003E.Lpy_003E_007DtKxME = (Class8.GunResult)array3[num6 - 1];
																		goto IL_16a4_2;
																		IL_16a4_2:
																		num6--;
																		goto IL_2bf8_2;
																		IL_16b7_2:
																		if (29 >= b)
																		{
																			goto IL_16c5_2;
																		}
																		goto IL_17a4_2;
																		IL_16c5_2:
																		if (29 <= b)
																		{
																			goto IL_16d0_2;
																		}
																		goto IL_1719_2;
																		IL_16d0_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(float*)(ptr2 + num3);
																		goto IL_16ea_2;
																		IL_16ea_2:
																		array2[num6] = 3;
																		goto IL_16f8_2;
																		IL_16f8_2:
																		num6++;
																		goto IL_1706_2;
																		IL_1706_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_1719_2:
																		if (28 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1727_2;
																		IL_1727_2:
																		if (28 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1735_2;
																		IL_1735_2:
																		array2[num6 - 1] = 0;
																		num = 467;
																		goto IL_1752_2;
																		IL_1752_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_1791_2;
																		IL_1791_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_17a4_2:
																		if (30 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		num = 9;
																		goto IL_17bb_2;
																		IL_1a80_2:
																		num6--;
																		goto IL_2bf8_2;
																		IL_17bb_2:
																		if (30 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_17c9_2;
																		IL_17c9_2:
																		array2[num6 - 5] = 4;
																		goto IL_17dd_2;
																		IL_17dd_2:
																		array3[num6 - 5] = ((delegate*<string, bool, float, bool, bool, Class8.GunResult>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string)array3[num6 - 5], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 4])) != 0, (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3])), (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])) != 0, (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																		goto IL_186e_2;
																		IL_186e_2:
																		num6 -= 4;
																		num = 221;
																		goto IL_1885_2;
																		IL_1885_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_1898_2:
																		if (33 >= b)
																		{
																			goto IL_18a6_2;
																		}
																		goto IL_1986_2;
																		IL_18a6_2:
																		if (33 <= b)
																		{
																			goto IL_18b1_2;
																		}
																		goto IL_1904_2;
																		IL_18b1_2:
																		array2[num6] = 0;
																		goto IL_18bf_2;
																		IL_18bf_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])() ? 1 : 0);
																		goto IL_18e3_2;
																		IL_18e3_2:
																		num6++;
																		goto IL_18f1_2;
																		IL_18f1_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_1904_2:
																		if (32 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1912_2;
																		IL_1912_2:
																		if (32 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1920_2;
																		IL_1920_2:
																		array2[num6 - 1] = 3;
																		goto IL_1934_2;
																		IL_1934_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_1973_2;
																		IL_1973_2:
																		ptr2 += 8;
																		goto IL_2bf8_2;
																		IL_1986_2:
																		if (34 >= b)
																		{
																			goto IL_1991_2;
																		}
																		goto IL_1a10_2;
																		IL_1991_2:
																		if (34 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_199f_2;
																		IL_199f_2:
																		ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_19fd_2;
																		IL_19fd_2:
																		num6--;
																		goto IL_2bf8_2;
																		IL_1a10_2:
																		if (35 < b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1a1e_2;
																		IL_1a1e_2:
																		if (35 > b)
																		{
																			goto end_IL_0a6a_2;
																		}
																		goto IL_1a2c_2;
																		continue;
																		end_IL_0a3a_2:
																		break;
																	}
																	continue;
																}
																goto IL_1a93_2;
																IL_1ac7_2:
																ptr2 += 8;
																goto IL_2bf8_2;
																IL_1a93_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_1aab_2;
																IL_1aab_2:
																array2[num6] = 5;
																goto IL_1ab9_2;
																IL_1ab9_2:
																num6++;
																goto IL_1ac7_2;
																continue;
																end_IL_0a4a:
																break;
															}
															continue;
														}
														goto IL_1ada_2;
														IL_2b61_2:
														if (71 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2b6c_2;
														IL_1ada_2:
														if (54 >= b)
														{
															goto IL_1ae8_2;
														}
														goto IL_2360_2;
														IL_1ae8_2:
														if (54 <= b)
														{
															goto IL_1af6_2;
														}
														goto IL_1b8c_2;
														IL_1af6_2:
														array2[num6 - 1] = 4;
														goto IL_1b0a_2;
														IL_1b0a_2:
														array3[num6 - 1] = ((delegate*<ref RaycastHit, Vector3>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref RaycastHit>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
														goto IL_1b79_2;
														IL_1b79_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_1b8c_2:
														if (45 >= b)
														{
															goto IL_1b9a_2;
														}
														goto IL_1fa7_2;
														IL_1b9a_2:
														if (45 <= b)
														{
															goto IL_1ba5_2;
														}
														goto IL_1c14_2;
														IL_1ba5_2:
														array2[num6 - 1] = 3;
														goto IL_1bb9_2;
														IL_1bb9_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														num = 292;
														goto IL_1c01_2;
														IL_1c01_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_1c14_2:
														if (40 >= b)
														{
															goto IL_1c22_2;
														}
														goto IL_1dc9_2;
														IL_1c22_2:
														if (40 <= b)
														{
															goto IL_1c2d_2;
														}
														goto IL_1c71_2;
														IL_1c2d_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1c58_2;
														IL_1c58_2:
														array2[num6 - 1] = 0;
														goto IL_2bf8_2;
														IL_1c71_2:
														if (38 >= b)
														{
															goto IL_1c7f_2;
														}
														goto IL_1d6a_2;
														IL_1c7f_2:
														if (38 <= b)
														{
															goto IL_1c8a_2;
														}
														goto IL_1ce0_2;
														IL_1c8a_2:
														array3[num6] = ((delegate*<string[]>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
														num = 107;
														goto IL_1cb1_2;
														IL_1cb1_2:
														array2[num6] = 5;
														goto IL_1cbf_2;
														IL_1cbf_2:
														num6++;
														goto IL_1ccd_2;
														IL_1ccd_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_1ce0_2:
														if (37 < b)
														{
															goto end_IL_0a6a_2;
														}
														num = 333;
														goto IL_1cf7_2;
														IL_2b6c_2:
														array2[num6 - 1] = 3;
														goto IL_2b80_2;
														IL_1cf7_2:
														if (37 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1d05_2;
														IL_1d05_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<Class122, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class122)array3[num6 - 1]);
														goto IL_1d43_2;
														IL_1d43_2:
														array2[num6 - 1] = 0;
														goto IL_1d57_2;
														IL_1d57_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_1d6a_2:
														if (39 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1d78_2;
														IL_1d78_2:
														if (39 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1d86_2;
														IL_1d86_2:
														*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (nint)((string[])array3[num6 - 1]).LongLength;
														goto IL_1db0_2;
														IL_1db0_2:
														array2[num6 - 1] = 2;
														goto IL_2bf8_2;
														IL_1dc9_2:
														if (42 >= b)
														{
															goto IL_1dd7_2;
														}
														goto IL_1ea6_2;
														IL_1dd7_2:
														if (42 <= b)
														{
															goto IL_1de2_2;
														}
														goto IL_1e23_2;
														IL_1de2_2:
														((Class122)array3[num6 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1e10_2;
														IL_1e10_2:
														num6 -= 2;
														goto IL_2bf8_2;
														IL_1e23_2:
														if (41 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1e31_2;
														IL_1e31_2:
														if (41 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1e3f_2;
														IL_1e3f_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1e7f_2;
														IL_1e7f_2:
														array2[num6 - 2] = 0;
														goto IL_1e93_2;
														IL_1e93_2:
														num6--;
														goto IL_2bf8_2;
														IL_1ea6_2:
														if (43 < b)
														{
															goto IL_1eb4_2;
														}
														num = 489;
														goto IL_1f47_2;
														IL_1eb4_2:
														if (44 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1ec2_2;
														IL_1ec2_2:
														if (44 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1ed0_2;
														IL_1ed0_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
														num = 523;
														goto IL_1f17_2;
														IL_1f17_2:
														array2[num6 - 1] = 0;
														goto IL_1f2b_2;
														IL_1f2b_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2b80_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_2bbf_2;
														IL_1f47_2:
														if (43 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_1f55_2;
														IL_1f55_2:
														array3[num6] = ((delegate*<Class8.GunResult>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
														goto IL_1f78_2;
														IL_1f78_2:
														array2[num6] = 4;
														goto IL_1f86_2;
														IL_1f86_2:
														num6++;
														goto IL_1f94_2;
														IL_1f94_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_1fa7_2:
														if (49 >= b)
														{
															goto IL_1fb5_2;
														}
														goto IL_213c_2;
														IL_1fb5_2:
														if (49 <= b)
														{
															goto IL_1fc0_2;
														}
														goto IL_200d_2;
														IL_1fc0_2:
														array3[num6] = ((delegate*<Dictionary<string, int>>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
														goto IL_1fde_2;
														IL_1fde_2:
														array2[num6] = 5;
														goto IL_1fec_2;
														IL_1fec_2:
														num6++;
														goto IL_1ffa_2;
														IL_1ffa_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_200d_2:
														if (47 < b)
														{
															goto IL_201b_2;
														}
														goto IL_209d_2;
														IL_201b_2:
														if (48 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2029_2;
														IL_2029_2:
														if (48 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2037_2;
														IL_2037_2:
														array2[num6 - 1] = 3;
														goto IL_204b_2;
														IL_204b_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_208a_2;
														IL_208a_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_209d_2:
														if (47 > b)
														{
															goto IL_20a8_2;
														}
														goto IL_20e9_2;
														IL_20a8_2:
														if (46 < b)
														{
															goto end_IL_0a6a_2;
														}
														num = 383;
														goto IL_20bf_2;
														IL_2bbf_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_20bf_2:
														if (46 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_20cd_2;
														IL_20cd_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto IL_2bf8_2;
														IL_20e9_2:
														array2[num6] = 0;
														goto IL_20f7_2;
														IL_20f7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])() ? 1 : 0);
														goto IL_211b_2;
														IL_211b_2:
														num6++;
														goto IL_2129_2;
														IL_2129_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_213c_2:
														if (51 < b)
														{
															goto IL_214a_2;
														}
														num = 429;
														goto IL_2259_2;
														IL_214a_2:
														if (52 >= b)
														{
															goto IL_2155_2;
														}
														goto IL_21a5_2;
														IL_2155_2:
														if (52 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2163_2;
														IL_2163_2:
														array2[num6] = 15;
														goto IL_2171_2;
														IL_2171_2:
														array4[num6] = *(int*)(ptr2 + num3);
														goto IL_2184_2;
														IL_2184_2:
														ptr2 += 8;
														goto IL_2192_2;
														IL_2192_2:
														num6++;
														goto IL_2bf8_2;
														IL_21a5_2:
														if (53 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_21b3_2;
														IL_21b3_2:
														if (53 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_21c1_2;
														IL_21c1_2:
														array3[num6 - 1] = new NestedFamANDAssemgetCalendarWeekRule(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array4[num6 - 1], array5);
														goto IL_2210_2;
														IL_2210_2:
														array2[num6 - 1] = 15;
														goto IL_2224_2;
														IL_2224_2:
														array4[num6 - 1] = *(int*)(ptr2 + num3);
														goto IL_223d_2;
														IL_223d_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2bcf_2:
														if (72 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2bda_2;
														IL_2259_2:
														if (51 <= b)
														{
															goto IL_2267_2;
														}
														goto IL_22f7_2;
														IL_2267_2:
														array2[num6 - 2] = 0;
														goto IL_227b_2;
														IL_227b_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<Dictionary<string, int>, string, int>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]);
														num = 120;
														goto IL_22d6_2;
														IL_22d6_2:
														num6--;
														goto IL_22e4_2;
														IL_22e4_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_22f7_2:
														if (50 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2305_2;
														IL_2305_2:
														if (50 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2313_2;
														IL_2313_2:
														array3[num6] = ((delegate*<string>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
														goto IL_2331_2;
														IL_2331_2:
														array2[num6] = 5;
														goto IL_233f_2;
														IL_233f_2:
														num6++;
														goto IL_234d_2;
														IL_234d_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2360_2:
														if (63 >= b)
														{
															goto IL_236e_2;
														}
														goto IL_27eb_2;
														IL_236e_2:
														if (63 <= b)
														{
															goto IL_2379_2;
														}
														goto IL_23df_2;
														IL_2379_2:
														array2[num6 - 1] = 3;
														goto IL_238d_2;
														IL_238d_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_23cc_2;
														IL_23cc_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_23df_2:
														if (58 >= b)
														{
															goto IL_23ed_2;
														}
														goto IL_25be_2;
														IL_23ed_2:
														if (58 <= b)
														{
															goto IL_23f8_2;
														}
														goto IL_2442_2;
														IL_23f8_2:
														((delegate*<string, void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_2421_2;
														IL_2421_2:
														num6--;
														goto IL_242f_2;
														IL_242f_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2442_2:
														if (56 >= b)
														{
															goto IL_2450_2;
														}
														goto IL_253c_2;
														IL_2450_2:
														if (56 <= b)
														{
															goto IL_245b_2;
														}
														goto IL_24ce_2;
														IL_245b_2:
														((delegate*<int, Vector3, Quaternion, void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 3]), (Vector3)array3[num6 - 2], (Quaternion)array3[num6 - 1]);
														goto IL_24ad_2;
														IL_24ad_2:
														num6 -= 3;
														goto IL_24bb_2;
														IL_24bb_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_24ce_2:
														if (55 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_24dc_2;
														IL_24dc_2:
														if (55 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_24ea_2;
														IL_24ea_2:
														array2[num6] = 4;
														goto IL_24f8_2;
														IL_24f8_2:
														array3[num6] = ((delegate*<Quaternion>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
														goto IL_251b_2;
														IL_251b_2:
														num6++;
														goto IL_2529_2;
														IL_2529_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_253c_2:
														if (57 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_254a_2;
														IL_254a_2:
														if (57 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2558_2;
														IL_2558_2:
														array2[num6 - 1] = 3;
														goto IL_256c_2;
														IL_256c_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_25ab_2;
														IL_25ab_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_25be_2:
														if (60 >= b)
														{
															goto IL_25cc_2;
														}
														goto IL_26eb_2;
														IL_25cc_2:
														if (60 > b)
														{
															goto IL_25da_2;
														}
														goto IL_2686_2;
														IL_25da_2:
														if (59 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_25e8_2;
														IL_25e8_2:
														if (59 > b)
														{
															goto end_IL_0a6a_2;
														}
														num = 482;
														goto IL_25ff_2;
														IL_2bda_2:
														if (72 <= b)
														{
														}
														goto end_IL_0a6a_2;
														IL_25ff_2:
														array2[num6 - 2] = 0;
														goto IL_2613_2;
														IL_2613_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<Dictionary<string, int>, string, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Dictionary<string, int>)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
														goto IL_2665_2;
														IL_2665_2:
														num6--;
														goto IL_2673_2;
														IL_2673_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2686_2:
														array2[num6] = 0;
														goto IL_2694_2;
														IL_2694_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = (((delegate*<bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])() ? 1 : 0);
														num = 155;
														goto IL_26c1_2;
														IL_26c1_2:
														num6++;
														num = 150;
														goto IL_26d8_2;
														IL_26d8_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_26eb_2:
														if (61 >= b)
														{
															goto IL_26f6_2;
														}
														goto IL_276a_2;
														IL_26f6_2:
														if (61 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2704_2;
														IL_2704_2:
														array2[num6 - 1] = 3;
														goto IL_2718_2;
														IL_2718_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_2757_2;
														IL_2757_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_276a_2:
														if (62 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2778_2;
														IL_2778_2:
														if (62 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2786_2;
														IL_2786_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
														goto IL_27c4_2;
														IL_27c4_2:
														array2[num6 - 1] = 0;
														goto IL_27d8_2;
														IL_27d8_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_27eb_2:
														if (68 >= b)
														{
															goto IL_27f9_2;
														}
														goto IL_2a35_2;
														IL_27f9_2:
														if (68 <= b)
														{
															goto IL_2804_2;
														}
														goto IL_285f_2;
														IL_2804_2:
														array2[num6] = 4;
														num = 439;
														goto IL_281b_2;
														IL_281b_2:
														array3[num6] = ((delegate*<Vector3>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])();
														goto IL_283e_2;
														IL_283e_2:
														num6++;
														goto IL_284c_2;
														IL_284c_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_285f_2:
														if (65 >= b)
														{
															goto IL_286d_2;
														}
														goto IL_2920_2;
														IL_286d_2:
														if (65 <= b)
														{
															goto IL_2878_2;
														}
														goto IL_28a4_2;
														IL_2878_2:
														global::_003CModule_003E.string_43 = (string)array3[num6 - 1];
														goto IL_2891_2;
														IL_2891_2:
														num6--;
														goto IL_2bf8_2;
														IL_28a4_2:
														if (64 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_28b2_2;
														IL_28b2_2:
														if (64 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_28c0_2;
														IL_28c0_2:
														array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_28f9_2;
														IL_28f9_2:
														array2[num6 - 2] = 5;
														goto IL_290d_2;
														IL_290d_2:
														num6--;
														goto IL_2bf8_2;
														IL_2920_2:
														if (66 >= b)
														{
															goto IL_292b_2;
														}
														goto IL_2983_2;
														IL_292b_2:
														if (66 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2939_2;
														IL_2939_2:
														((delegate*<string, void>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_2962_2;
														IL_2962_2:
														num6--;
														goto IL_2970_2;
														IL_2970_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2983_2:
														if (67 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2991_2;
														IL_2991_2:
														if (67 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_299f_2;
														IL_299f_2:
														array2[num6 - 1] = 4;
														goto IL_29b3_2;
														IL_29b3_2:
														array3[num6 - 1] = ((delegate*<ref RaycastHit, Vector3>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref RaycastHit>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
														goto IL_2a22_2;
														IL_2a22_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2a35_2:
														if (70 >= b)
														{
															goto IL_2a43_2;
														}
														goto IL_2b56_2;
														IL_2a43_2:
														if (70 <= b)
														{
															goto IL_2a4e_2;
														}
														goto IL_2ab3_2;
														IL_2a4e_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = (((delegate*<Class8.GunResult, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Class8.GunResult)array3[num6 - 1]) ? 1 : 0);
														goto IL_2a8c_2;
														IL_2a8c_2:
														array2[num6 - 1] = 0;
														goto IL_2aa0_2;
														IL_2aa0_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2ab3_2:
														if (69 < b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2ac1_2;
														IL_2ac1_2:
														if (69 > b)
														{
															goto end_IL_0a6a_2;
														}
														goto IL_2acf_2;
														IL_2acf_2:
														array2[num6 - 2] = 0;
														goto IL_2ae3_2;
														IL_2ae3_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<Vector3, Vector3, bool>)IIDIEnumSTORECATEGORYsetLargeObjectHeapCompactionMode[*(int*)(ptr2 + num3)])((Vector3)array3[num6 - 2], (Vector3)array3[num6 - 1]) ? 1 : 0);
														goto IL_2b35_2;
														IL_2b35_2:
														num6--;
														goto IL_2b43_2;
														IL_2b43_2:
														ptr2 += 8;
														goto IL_2bf8_2;
														IL_2b56_2:
														if (71 >= b)
														{
															goto IL_2b61_2;
														}
														goto IL_2bcf_2;
														continue;
														end_IL_0a5a:
														break;
													}
													continue;
													end_IL_0a6a_2:
													break;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_2bf8_2;
											continue;
											end_IL_0a7d_2:
											break;
										}
										continue;
										end_IL_0a8d:
										break;
									}
									continue;
									end_IL_0a9d:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_0ed5_2;
					}
					continue;
					end_IL_0ee3:
					break;
				}
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		//The blocks IL_000e, IL_001e, IL_036f, IL_0382, IL_03a1, IL_03e3, IL_03f3, IL_0403, IL_0413, IL_0423, IL_0433, IL_0443, IL_0450, IL_0460, IL_0470, IL_0480, IL_048b, IL_0496, IL_04a6, IL_04b6, IL_04c9, IL_04dc, IL_04ea, IL_04fd, IL_050b, IL_0519, IL_0527, IL_0537, IL_054f, IL_0572, IL_0582, IL_0595, IL_05da, IL_05ed, IL_05f8, IL_060b, IL_0619, IL_0627, IL_0689, IL_069c, IL_06a7, IL_06b5, IL_06d3, IL_06e1, IL_06f4, IL_0702, IL_0710, IL_0739, IL_075b, IL_076e, IL_0792, IL_07af, IL_07c3, IL_07fb, IL_080e, IL_084e, IL_0862, IL_0875, IL_0880, IL_088e, IL_08b7, IL_08c5, IL_08d8, IL_08e6, IL_08f4, IL_0910, IL_0923, IL_0931, IL_093a, IL_0978, IL_098b, IL_09a8, IL_09f7, IL_0a01, IL_0a2e, IL_0a42, IL_0a55, IL_0a68, IL_0a7c, IL_0a8f, IL_0aa7, IL_0ab5, IL_0ac8, IL_0ad3, IL_0ae1, IL_0b21, IL_0b35, IL_0b48, IL_0b53, IL_0b61, IL_0b8a, IL_0ba1, IL_0bb4, IL_0bc2, IL_0bd0, IL_0bd9, IL_0be7, IL_0c0f, IL_0c58, IL_0c6c, IL_0c7f, IL_0c92, IL_0c9c, IL_0caa, IL_0cbd, IL_0cc8, IL_0cd5, IL_0ce8, IL_0cff, IL_0d23, IL_0d31, IL_0d41, IL_0d5a, IL_0d68, IL_0d7f, IL_0d8d, IL_0da0, IL_0daa, IL_0db5, IL_0dc5, IL_0dd5, IL_0de5, IL_0df5, IL_0e05, IL_0e15, IL_0e25 are reachable both inside and outside the pinned region starting at IL_0e3a. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 74;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2;
			int num3;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			int __rxRef34 = default(int);
			ref int reference = ref __rxRef34;
			object[] array8;
			int num6;
			byte* num7;
			byte* num9;
			int num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_0e25:
					num2 = 1;
					while (true)
					{
						IL_0e15:
						num3 = num2 * 4;
						while (true)
						{
							IL_0e05:
							array2 = new byte[4];
							while (true)
							{
								IL_0df5:
								array3 = new object[4];
								while (true)
								{
									IL_0de5:
									array4 = new int[4];
									while (true)
									{
										IL_0dd5:
										array5 = new int[6];
										while (true)
										{
											IL_0dc5:
											array6 = new long[4];
											while (true)
											{
												IL_0db5:
												array7 = new object[13];
												while (true)
												{
													IL_0daa:
													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRectArrayVariantBool.ContractExceptionRegisterTypeForComClients);
													while (true)
													{
														IL_0da0:
														ptr2 = ptr;
														while (true)
														{
															IL_0d8d:
															if (num4 == 1)
															{
																return;
															}
															while (true)
															{
																IL_0480:
																byte b = *ptr2;
																while (true)
																{
																	IL_0470:
																	ptr2++;
																	while (true)
																	{
																		IL_0460:
																		if (b >= 1)
																		{
																			while (b <= 21)
																			{
																				while (true)
																				{
																					IL_0443:
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_0433:
																							if (11 > b)
																							{
																								while (true)
																								{
																									IL_0423:
																									if (5 < b)
																									{
																										while (true)
																										{
																											IL_0413:
																											if (8 >= b)
																											{
																												while (true)
																												{
																													IL_0403:
																													if (8 > b)
																													{
																														while (true)
																														{
																															IL_03f3:
																															if (6 >= b)
																															{
																																while (6 <= b)
																																{
																																	while (true)
																																	{
																																		IL_03a1:
																																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																																		while (true)
																																		{
																																			IL_0382:
																																			array2[num5 - 2] = 0;
																																			num = 216;
																																			while (true)
																																			{
																																				if (num != 216)
																																				{
																																					if (num != 1197)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 74:
																																						break;
																																					default:
																																						continue;
																																					case 100:
																																						goto IL_0382;
																																					case 28:
																																					case 53:
																																						goto IL_03a1;
																																					case 114:
																																						goto IL_03e3;
																																					case 44:
																																					case 66:
																																						goto IL_03f3;
																																					case 90:
																																						goto IL_0403;
																																					case 192:
																																						goto IL_0413;
																																					case 69:
																																					case 128:
																																						goto IL_0423;
																																					case 46:
																																						goto IL_0433;
																																					case 26:
																																						goto IL_0443;
																																					case 177:
																																						goto IL_0450;
																																					case 64:
																																						goto IL_0460;
																																					case 172:
																																						goto IL_0470;
																																					case 2:
																																					case 155:
																																						goto IL_0480;
																																					case 21:
																																					case 30:
																																						goto IL_048b;
																																					case 56:
																																						goto IL_0496;
																																					case 58:
																																					case 67:
																																						goto IL_04a6;
																																					case 42:
																																					case 68:
																																						goto IL_04b6;
																																					case 134:
																																						goto IL_04c9;
																																					case 138:
																																						goto IL_04dc;
																																					case 124:
																																						goto IL_04ea;
																																					case 135:
																																					case 144:
																																						goto IL_04fd;
																																					case 109:
																																						goto IL_050b;
																																					case 117:
																																					case 148:
																																						goto IL_0519;
																																					case 83:
																																						goto IL_0527;
																																					case 141:
																																					case 154:
																																						goto IL_0537;
																																					case 153:
																																						goto IL_054f;
																																					case 158:
																																						goto IL_0572;
																																					case 129:
																																					case 159:
																																						goto IL_0582;
																																					case 89:
																																					case 162:
																																						goto IL_0595;
																																					case 166:
																																						goto end_IL_036f;
																																					case 152:
																																					case 170:
																																						goto IL_05ed;
																																					case 15:
																																						goto IL_05f8;
																																					case 169:
																																						goto IL_060b;
																																					case 163:
																																						goto IL_0619;
																																					case 107:
																																					case 147:
																																						goto IL_0627;
																																					case 24:
																																						goto IL_0689;
																																					case 50:
																																					case 173:
																																						goto IL_069c;
																																					case 20:
																																						goto IL_06a7;
																																					case 4:
																																					case 137:
																																						goto IL_06b5;
																																					case 115:
																																						goto IL_06d3;
																																					case 29:
																																						goto IL_06e1;
																																					case 13:
																																						goto IL_06f4;
																																					case 146:
																																						goto IL_0702;
																																					case 51:
																																					case 88:
																																						goto IL_0710;
																																					case 17:
																																						goto IL_0739;
																																					case 174:
																																						goto IL_075b;
																																					case 179:
																																						goto IL_076e;
																																					case 60:
																																						goto IL_0792;
																																					case 85:
																																					case 185:
																																						goto IL_07af;
																																					case 22:
																																						goto IL_07c3;
																																					case 91:
																																						goto IL_07fb;
																																					case 112:
																																					case 191:
																																						goto IL_080e;
																																					case 108:
																																						goto IL_084e;
																																					case 93:
																																						goto IL_0862;
																																					case 193:
																																						goto IL_0875;
																																					case 40:
																																						goto IL_0880;
																																					case 156:
																																					case 186:
																																						goto IL_088e;
																																					case 126:
																																						goto IL_08b7;
																																					case 119:
																																						goto IL_08c5;
																																					case 8:
																																						goto IL_08d8;
																																					case 48:
																																						goto IL_08e6;
																																					case 23:
																																					case 82:
																																						goto IL_08f4;
																																					case 195:
																																						goto IL_0910;
																																					case 196:
																																						goto IL_0923;
																																					case 75:
																																					case 87:
																																						goto IL_093a;
																																					case 165:
																																						goto IL_0978;
																																					case 149:
																																					case 197:
																																						goto IL_098b;
																																					case 145:
																																						goto IL_0a42;
																																					case 198:
																																						goto IL_0a55;
																																					case 199:
																																						goto IL_0a68;
																																					case 76:
																																						goto IL_0a7c;
																																					case 200:
																																						goto IL_0a8f;
																																					case 95:
																																						goto IL_0aa7;
																																					case 113:
																																						goto IL_0ab5;
																																					case 203:
																																						goto IL_0ac8;
																																					case 171:
																																						goto IL_0ad3;
																																					case 3:
																																					case 194:
																																						goto IL_0ae1;
																																					case 188:
																																						goto IL_0b21;
																																					case 180:
																																						goto IL_0b35;
																																					case 6:
																																						goto IL_0b48;
																																					case 130:
																																						goto IL_0b53;
																																					case 33:
																																					case 38:
																																						goto IL_0b61;
																																					case 167:
																																						goto IL_0b8a;
																																					case 37:
																																						goto IL_0ba1;
																																					case 0:
																																						goto IL_0bb4;
																																					case 97:
																																						goto IL_0bc2;
																																					case 54:
																																					case 187:
																																						goto IL_0bd9;
																																					case 176:
																																						goto IL_0be7;
																																					case 201:
																																					case 205:
																																						goto IL_0c0f;
																																					case 86:
																																						goto IL_0c58;
																																					case 92:
																																						goto IL_0c6c;
																																					case 206:
																																						goto IL_0c7f;
																																					case 207:
																																						goto IL_0c92;
																																					case 18:
																																						goto IL_0c9c;
																																					case 103:
																																						goto IL_0caa;
																																					case 84:
																																					case 209:
																																						goto IL_0cbd;
																																					case 9:
																																						goto IL_0cc8;
																																					case 57:
																																					case 78:
																																						goto IL_0ce8;
																																					case 118:
																																						goto IL_0cff;
																																					case 62:
																																						goto IL_0d23;
																																					case 55:
																																						goto IL_0d31;
																																					case 1:
																																					case 5:
																																					case 7:
																																					case 10:
																																					case 12:
																																					case 19:
																																					case 32:
																																					case 35:
																																					case 36:
																																					case 43:
																																					case 49:
																																					case 59:
																																					case 61:
																																					case 65:
																																					case 70:
																																					case 77:
																																					case 80:
																																					case 94:
																																					case 98:
																																					case 99:
																																					case 102:
																																					case 104:
																																					case 110:
																																					case 125:
																																					case 131:
																																					case 132:
																																					case 133:
																																					case 136:
																																					case 142:
																																					case 143:
																																					case 157:
																																					case 160:
																																					case 168:
																																					case 175:
																																					case 178:
																																					case 181:
																																					case 182:
																																					case 190:
																																					case 208:
																																						goto end_IL_03e3;
																																					case 63:
																																						goto IL_0d5a;
																																					case 202:
																																						goto IL_0d68;
																																					case 122:
																																						goto IL_0d7f;
																																					case 11:
																																					case 14:
																																					case 16:
																																					case 25:
																																					case 27:
																																					case 39:
																																					case 47:
																																					case 52:
																																					case 71:
																																					case 72:
																																					case 81:
																																					case 96:
																																					case 101:
																																					case 105:
																																					case 106:
																																					case 111:
																																					case 116:
																																					case 121:
																																					case 123:
																																					case 127:
																																					case 150:
																																					case 161:
																																					case 184:
																																					case 189:
																																						goto IL_0d8d;
																																					case 151:
																																						goto IL_0da0;
																																					case 140:
																																						goto IL_0daa;
																																					case 79:
																																						goto IL_0db5;
																																					case 45:
																																						goto IL_0dc5;
																																					case 120:
																																						goto IL_0dd5;
																																					case 164:
																																						goto IL_0de5;
																																					case 31:
																																						goto IL_0df5;
																																					case 183:
																																					case 204:
																																						goto IL_0e05;
																																					case 139:
																																						goto IL_0e15;
																																					case 73:
																																						goto IL_0e25;
																																					case 34:
																																					case 41:
																																						return;
																																					}
																																					goto end_IL_0460;
																																				}
																																				num5--;
																																				goto IL_0d8d;
																																				continue;
																																				end_IL_036f:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	goto IL_05da;
																																	continue;
																																	end_IL_03e3:
																																	break;
																																	IL_03e3:;
																																}
																																break;
																															}
																															goto IL_04a6;
																															IL_0c6c:
																															num5--;
																															goto IL_0d8d;
																															IL_04a6:
																															if (7 < b)
																															{
																																break;
																															}
																															goto IL_04c9;
																															IL_04c9:
																															if (7 > b)
																															{
																																break;
																															}
																															goto IL_0c0f;
																															IL_0c0f:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																															num = 86;
																															goto IL_0c58;
																															IL_0c58:
																															array2[num5 - 2] = 0;
																															goto IL_0c6c;
																														}
																														break;
																													}
																													goto IL_04b6;
																													IL_04b6:
																													num5--;
																													goto IL_0d8d;
																												}
																												break;
																											}
																											goto IL_05ed;
																											IL_0689:
																											num5 -= 2;
																											goto IL_0d8d;
																											IL_05ed:
																											if (9 >= b)
																											{
																												goto IL_05f8;
																											}
																											goto IL_060b;
																											IL_05f8:
																											if (9 > b)
																											{
																												break;
																											}
																											goto IL_080e;
																											IL_080e:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											goto IL_084e;
																											IL_084e:
																											array2[num5 - 2] = 0;
																											goto IL_0862;
																											IL_0862:
																											num5--;
																											goto IL_0d8d;
																											IL_060b:
																											if (10 < b)
																											{
																												break;
																											}
																											goto IL_0619;
																											IL_0619:
																											if (10 > b)
																											{
																												break;
																											}
																											goto IL_0627;
																											IL_0627:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0689;
																										}
																										break;
																									}
																									goto IL_0572;
																									IL_0a68:
																									array2[num5 - 2] = 0;
																									goto IL_0a7c;
																									IL_0572:
																									if (5 <= b)
																									{
																										goto IL_0595;
																									}
																									goto IL_0ac8;
																									IL_0ac8:
																									if (2 >= b)
																									{
																										goto IL_0ad3;
																									}
																									goto IL_0b48;
																									IL_0ad3:
																									if (2 <= b)
																									{
																										goto IL_0ae1;
																									}
																									goto IL_0cbd;
																									IL_0ae1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_0b21;
																									IL_0b21:
																									array2[num5 - 2] = 0;
																									goto IL_0b35;
																									IL_0b35:
																									num5--;
																									goto IL_0d8d;
																									IL_0cbd:
																									if (1 < b)
																									{
																										break;
																									}
																									goto IL_0cc8;
																									IL_0cc8:
																									if (1 <= b)
																									{
																									}
																									break;
																									IL_0b48:
																									if (3 >= b)
																									{
																										goto IL_0b53;
																									}
																									goto IL_0bb4;
																									IL_0b53:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0b61;
																									IL_0b61:
																									reference = ref array5[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_0b8a;
																									IL_0b8a:
																									ptr2 += 8;
																									num = 37;
																									goto IL_0ba1;
																									IL_0ba1:
																									num5--;
																									goto IL_0d8d;
																									IL_0bb4:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_0bc2;
																									IL_0bc2:
																									if (4 > b)
																									{
																										break;
																									}
																									num = 187;
																									goto IL_0bd9;
																									IL_0a7c:
																									num5--;
																									goto IL_0d8d;
																									IL_0bd9:
																									array2[num5] = 0;
																									goto IL_0be7;
																									IL_0be7:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																									goto IL_0c92;
																									IL_0c92:
																									array3[num5] = null;
																									goto IL_0c9c;
																									IL_0c9c:
																									num5++;
																									goto IL_0caa;
																									IL_0caa:
																									ptr2 += 8;
																									goto IL_0d8d;
																									IL_0595:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																									goto IL_0a68;
																								}
																								break;
																							}
																							goto IL_0ce8;
																							IL_0d31:
																							ptr2 += 8;
																							goto IL_0d8d;
																							IL_0ce8:
																							array2[num5] = 0;
																							num = 118;
																							goto IL_0cff;
																							IL_0cff:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)CompletingsetCapacity[*(int*)(ptr2 + num3)])();
																							goto IL_0d23;
																							IL_0d23:
																							num5++;
																							goto IL_0d31;
																						}
																						break;
																					}
																					goto IL_048b;
																					IL_08b7:
																					num5--;
																					goto IL_08c5;
																					IL_048b:
																					if (16 >= b)
																					{
																						goto IL_0496;
																					}
																					goto IL_04fd;
																					IL_0496:
																					if (16 > b)
																					{
																						goto IL_04dc;
																					}
																					goto IL_0537;
																					IL_0537:
																					array2[num5] = array2[num5 - 1];
																					goto IL_054f;
																					IL_054f:
																					array4[num5 - 0] = array4[num5 - 1];
																					goto IL_076e;
																					IL_076e:
																					*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																					goto IL_0792;
																					IL_0792:
																					array3[num5] = array3[num5 - 1];
																					goto IL_0a55;
																					IL_0a55:
																					num5++;
																					goto IL_0d8d;
																					IL_04dc:
																					if (13 >= b)
																					{
																						goto IL_04ea;
																					}
																					goto IL_069c;
																					IL_04ea:
																					if (13 > b)
																					{
																						goto IL_05da;
																					}
																					goto IL_098b;
																					IL_05da:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_0910;
																					IL_0910:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_0d8d;
																					IL_098b:
																					array8 = array3;
																					num6 = num5;
																					if (array == null)
																					{
																						goto IL_099a;
																					}
																					num7 = ptr2;
																					byte b2 = *num7;
																					ptr2 = num7 + 4;
																					int num8 = *(int*)(ptr2 + num3);
																					ptr2 += 8;
																					byte* ptr3 = ptr2 + num8;
																					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																					while (ptr2 != ptr3)
																					{
																						*ptr4 = (byte)(*ptr2 ^ b2);
																						ptr2++;
																						ptr4++;
																					}
																					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																					goto IL_0a42;
																					IL_08c5:
																					ptr2 += 8;
																					goto IL_0d8d;
																					IL_08d8:
																					if (21 < b)
																					{
																						break;
																					}
																					goto IL_08e6;
																					IL_08e6:
																					if (21 > b)
																					{
																						break;
																					}
																					goto IL_08f4;
																					IL_0a42:
																					array2[num5] = 5;
																					goto IL_0c7f;
																					IL_0c7f:
																					num5++;
																					goto IL_0d8d;
																					IL_069c:
																					if (14 >= b)
																					{
																						goto IL_06a7;
																					}
																					goto IL_06f4;
																					IL_06a7:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_06b5;
																					IL_06b5:
																					array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
																					goto IL_06d3;
																					IL_06d3:
																					ptr2 += 8;
																					goto IL_06e1;
																					IL_06e1:
																					num5--;
																					goto IL_0d8d;
																					IL_06f4:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_0702;
																					IL_0702:
																					if (15 > b)
																					{
																						break;
																					}
																					goto IL_0710;
																					IL_0710:
																					array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
																					goto IL_0739;
																					IL_0739:
																					array2[num5 - 1] = 5;
																					num = 52;
																					goto IL_0d8d;
																					IL_04fd:
																					if (19 >= b)
																					{
																						goto IL_050b;
																					}
																					goto IL_0875;
																					IL_050b:
																					if (19 > b)
																					{
																						goto IL_0519;
																					}
																					goto IL_07af;
																					IL_0519:
																					if (17 >= b)
																					{
																						goto IL_0527;
																					}
																					goto IL_075b;
																					IL_0527:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_0582;
																					IL_0582:
																					array2[num5] = 5;
																					goto IL_0a8f;
																					IL_0a8f:
																					array3[num5] = array7[*(int*)(ptr2 + num3)];
																					goto IL_0aa7;
																					IL_0aa7:
																					num5++;
																					goto IL_0ab5;
																					IL_0ab5:
																					ptr2 += 8;
																					goto IL_0d8d;
																					IL_075b:
																					if (18 < b)
																					{
																						break;
																					}
																					goto IL_0923;
																					IL_0923:
																					if (18 > b)
																					{
																						break;
																					}
																					num = 87;
																					goto IL_093a;
																					IL_08f4:
																					num9 = ptr2;
																					num10 = -200;
																					num4 = 1;
																					ptr2 = num9 + num10;
																					goto IL_0d8d;
																					IL_093a:
																					((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
																					goto IL_0978;
																					IL_0978:
																					num5 -= 3;
																					goto IL_0d8d;
																					IL_07af:
																					array2[num5 - 1] = 5;
																					goto IL_07c3;
																					IL_07c3:
																					array3[num5 - 1] = ((delegate*<string[], string>)CompletingsetCapacity[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
																					goto IL_07fb;
																					IL_07fb:
																					ptr2 += 8;
																					goto IL_0d8d;
																					IL_0875:
																					if (20 >= b)
																					{
																						goto IL_0880;
																					}
																					goto IL_08d8;
																					IL_0880:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_088e;
																					IL_088e:
																					((delegate*<string, void>)CompletingsetCapacity[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
																					goto IL_08b7;
																				}
																				break;
																				IL_0450:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
																		goto IL_0d5a;
																		IL_0d7f:
																		ptr2 += 8;
																		goto IL_0d8d;
																		IL_0d68:
																		num5++;
																		num = 122;
																		goto IL_0d7f;
																		IL_0d5a:
																		array2[num5] = 0;
																		goto IL_0d68;
																		continue;
																		end_IL_0460:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_099a:
			while (true)
			{
				IL_099a_2:
				array = new byte[4];
				while (true)
				{
					num7 = ptr2;
					byte b2 = *num7;
					ptr2 = num7 + 4;
					int num8 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num8;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num6] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0a42_2:
						array2[num5] = 5;
						while (true)
						{
							IL_0c7f_2:
							num5++;
							while (true)
							{
								IL_0d8d_2:
								if (num4 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_0460_2:
											if (b >= 1)
											{
												while (b <= 21)
												{
													while (true)
													{
														IL_0443_2:
														if (11 >= b)
														{
															while (true)
															{
																IL_0433_2:
																if (11 > b)
																{
																	while (true)
																	{
																		IL_0423_2:
																		if (5 < b)
																		{
																			while (true)
																			{
																				IL_0413_2:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_0403_2:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_03f3_2:
																								if (6 >= b)
																								{
																									while (6 <= b)
																									{
																										while (true)
																										{
																											IL_03a1_2:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																											while (true)
																											{
																												IL_0382_2:
																												array2[num5 - 2] = 0;
																												num = 216;
																												while (true)
																												{
																													if (num != 216)
																													{
																														if (num != 1197)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 100:
																															goto IL_0382_2;
																														case 28:
																														case 53:
																															goto IL_03a1_2;
																														case 114:
																															goto IL_03e3_2;
																														case 44:
																														case 66:
																															goto IL_03f3_2;
																														case 90:
																															goto IL_0403_2;
																														case 192:
																															goto IL_0413_2;
																														case 69:
																														case 128:
																															goto IL_0423_2;
																														case 46:
																															goto IL_0433_2;
																														case 26:
																															goto IL_0443_2;
																														case 177:
																															goto IL_0450_2;
																														case 64:
																															goto IL_0460_2;
																														case 172:
																															goto end_IL_0460_2;
																														case 2:
																														case 155:
																															goto end_IL_0470;
																														case 21:
																														case 30:
																															goto IL_048b_2;
																														case 56:
																															goto IL_0496_2;
																														case 58:
																														case 67:
																															goto IL_04a6_2;
																														case 42:
																														case 68:
																															goto IL_04b6_2;
																														case 134:
																															goto IL_04c9_2;
																														case 138:
																															goto IL_04dc_2;
																														case 124:
																															goto IL_04ea_2;
																														case 135:
																														case 144:
																															goto IL_04fd_2;
																														case 109:
																															goto IL_050b_2;
																														case 117:
																														case 148:
																															goto IL_0519_2;
																														case 83:
																															goto IL_0527_2;
																														case 141:
																														case 154:
																															goto IL_0537_2;
																														case 153:
																															goto IL_054f_2;
																														case 158:
																															goto IL_0572_2;
																														case 129:
																														case 159:
																															goto IL_0582_2;
																														case 89:
																														case 162:
																															goto IL_0595_2;
																														case 166:
																															goto end_IL_036f_2;
																														case 152:
																														case 170:
																															goto IL_05ed_2;
																														case 15:
																															goto IL_05f8_2;
																														case 169:
																															goto IL_060b_2;
																														case 163:
																															goto IL_0619_2;
																														case 107:
																														case 147:
																															goto IL_0627_2;
																														case 24:
																															goto IL_0689_2;
																														case 50:
																														case 173:
																															goto IL_069c_2;
																														case 20:
																															goto IL_06a7_2;
																														case 4:
																														case 137:
																															goto IL_06b5_2;
																														case 115:
																															goto IL_06d3_2;
																														case 29:
																															goto IL_06e1_2;
																														case 13:
																															goto IL_06f4_2;
																														case 146:
																															goto IL_0702_2;
																														case 51:
																														case 88:
																															goto IL_0710_2;
																														case 17:
																															goto IL_0739_2;
																														case 174:
																															goto IL_075b_2;
																														case 179:
																															goto IL_076e_2;
																														case 60:
																															goto IL_0792_2;
																														case 85:
																														case 185:
																															goto IL_07af_2;
																														case 22:
																															goto IL_07c3_2;
																														case 91:
																															goto IL_07fb_2;
																														case 112:
																														case 191:
																															goto IL_080e_2;
																														case 108:
																															goto IL_084e_2;
																														case 93:
																															goto IL_0862_2;
																														case 193:
																															goto IL_0875_2;
																														case 40:
																															goto IL_0880_2;
																														case 156:
																														case 186:
																															goto IL_088e_2;
																														case 126:
																															goto IL_08b7_2;
																														case 119:
																															goto IL_08c5_2;
																														case 8:
																															goto IL_08d8_2;
																														case 48:
																															goto IL_08e6_2;
																														case 23:
																														case 82:
																															goto IL_08f4_2;
																														case 195:
																															goto IL_0910_2;
																														case 196:
																															goto IL_0923_2;
																														case 75:
																														case 87:
																															goto IL_093a_2;
																														case 165:
																															goto IL_0978_2;
																														case 149:
																														case 197:
																															goto end_IL_0480;
																														case 145:
																															goto IL_0a42_2;
																														case 198:
																															goto IL_0a55_2;
																														case 199:
																															goto IL_0a68_2;
																														case 76:
																															goto IL_0a7c_2;
																														case 200:
																															goto IL_0a8f_2;
																														case 95:
																															goto IL_0aa7_2;
																														case 113:
																															goto IL_0ab5_2;
																														case 203:
																															goto IL_0ac8_2;
																														case 171:
																															goto IL_0ad3_2;
																														case 3:
																														case 194:
																															goto IL_0ae1_2;
																														case 188:
																															goto IL_0b21_2;
																														case 180:
																															goto IL_0b35_2;
																														case 6:
																															goto IL_0b48_2;
																														case 130:
																															goto IL_0b53_2;
																														case 33:
																														case 38:
																															goto IL_0b61_2;
																														case 167:
																															goto IL_0b8a_2;
																														case 37:
																															goto IL_0ba1_2;
																														case 0:
																															goto IL_0bb4_2;
																														case 97:
																															goto IL_0bc2_2;
																														case 54:
																														case 187:
																															goto IL_0bd9_2;
																														case 176:
																															goto IL_0be7_2;
																														case 201:
																														case 205:
																															goto IL_0c0f_2;
																														case 86:
																															goto IL_0c58_2;
																														case 92:
																															goto IL_0c6c_2;
																														case 206:
																															goto IL_0c7f_2;
																														case 207:
																															goto IL_0c92_2;
																														case 18:
																															goto IL_0c9c_2;
																														case 103:
																															goto IL_0caa_2;
																														case 84:
																														case 209:
																															goto IL_0cbd_2;
																														case 9:
																															goto IL_0cc8_2;
																														case 57:
																														case 78:
																															goto IL_0ce8_2;
																														case 118:
																															goto IL_0cff_2;
																														case 62:
																															goto IL_0d23_2;
																														case 55:
																															goto IL_0d31_2;
																														case 1:
																														case 5:
																														case 7:
																														case 10:
																														case 12:
																														case 19:
																														case 32:
																														case 35:
																														case 36:
																														case 43:
																														case 49:
																														case 59:
																														case 61:
																														case 65:
																														case 70:
																														case 77:
																														case 80:
																														case 94:
																														case 98:
																														case 99:
																														case 102:
																														case 104:
																														case 110:
																														case 125:
																														case 131:
																														case 132:
																														case 133:
																														case 136:
																														case 142:
																														case 143:
																														case 157:
																														case 160:
																														case 168:
																														case 175:
																														case 178:
																														case 181:
																														case 182:
																														case 190:
																														case 208:
																															goto end_IL_03e3_2;
																														case 63:
																															goto IL_0d5a_2;
																														case 202:
																															goto IL_0d68_2;
																														case 122:
																															goto IL_0d7f_2;
																														case 11:
																														case 14:
																														case 16:
																														case 25:
																														case 27:
																														case 39:
																														case 47:
																														case 52:
																														case 71:
																														case 72:
																														case 81:
																														case 96:
																														case 101:
																														case 105:
																														case 106:
																														case 111:
																														case 116:
																														case 121:
																														case 123:
																														case 127:
																														case 150:
																														case 161:
																														case 184:
																														case 189:
																															goto IL_0d8d_2;
																														case 151:
																															ptr2 = ptr;
																															goto IL_0d8d_2;
																														case 140:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRectArrayVariantBool.ContractExceptionRegisterTypeForComClients);
																															goto case 151;
																														case 79:
																															array7 = new object[13];
																															goto case 140;
																														case 45:
																															array6 = new long[4];
																															goto case 79;
																														case 120:
																															array5 = new int[6];
																															goto case 45;
																														case 164:
																															array4 = new int[4];
																															goto case 120;
																														case 31:
																															array3 = new object[4];
																															goto case 164;
																														case 183:
																														case 204:
																															array2 = new byte[4];
																															goto case 31;
																														case 139:
																															num3 = num2 * 4;
																															goto case 183;
																														case 73:
																															num2 = 1;
																															goto case 139;
																														case 74:
																															goto end_IL_09a8;
																														case 34:
																														case 41:
																															return;
																														}
																														continue;
																													}
																													num5--;
																													goto IL_0d8d_2;
																													continue;
																													end_IL_036f_2:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_05da_2;
																										continue;
																										end_IL_03e3_2:
																										break;
																										IL_03e3_2:;
																									}
																									break;
																								}
																								goto IL_04a6_2;
																								IL_0c6c_2:
																								num5--;
																								goto IL_0d8d_2;
																								IL_04a6_2:
																								if (7 < b)
																								{
																									break;
																								}
																								goto IL_04c9_2;
																								IL_04c9_2:
																								if (7 > b)
																								{
																									break;
																								}
																								goto IL_0c0f_2;
																								IL_0c0f_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																								num = 86;
																								goto IL_0c58_2;
																								IL_0c58_2:
																								array2[num5 - 2] = 0;
																								goto IL_0c6c_2;
																							}
																							break;
																						}
																						goto IL_04b6_2;
																						IL_04b6_2:
																						num5--;
																						goto IL_0d8d_2;
																					}
																					break;
																				}
																				goto IL_05ed_2;
																				IL_0689_2:
																				num5 -= 2;
																				goto IL_0d8d_2;
																				IL_05ed_2:
																				if (9 >= b)
																				{
																					goto IL_05f8_2;
																				}
																				goto IL_060b_2;
																				IL_05f8_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_080e_2;
																				IL_080e_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																				goto IL_084e_2;
																				IL_084e_2:
																				array2[num5 - 2] = 0;
																				goto IL_0862_2;
																				IL_0862_2:
																				num5--;
																				goto IL_0d8d_2;
																				IL_060b_2:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0619_2;
																				IL_0619_2:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0627_2;
																				IL_0627_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0689_2;
																			}
																			break;
																		}
																		goto IL_0572_2;
																		IL_0a68_2:
																		array2[num5 - 2] = 0;
																		goto IL_0a7c_2;
																		IL_0572_2:
																		if (5 <= b)
																		{
																			goto IL_0595_2;
																		}
																		goto IL_0ac8_2;
																		IL_0ac8_2:
																		if (2 >= b)
																		{
																			goto IL_0ad3_2;
																		}
																		goto IL_0b48_2;
																		IL_0ad3_2:
																		if (2 <= b)
																		{
																			goto IL_0ae1_2;
																		}
																		goto IL_0cbd_2;
																		IL_0ae1_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0b21_2;
																		IL_0b21_2:
																		array2[num5 - 2] = 0;
																		goto IL_0b35_2;
																		IL_0b35_2:
																		num5--;
																		goto IL_0d8d_2;
																		IL_0cbd_2:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_0cc8_2;
																		IL_0cc8_2:
																		if (1 <= b)
																		{
																		}
																		break;
																		IL_0b48_2:
																		if (3 >= b)
																		{
																			goto IL_0b53_2;
																		}
																		goto IL_0bb4_2;
																		IL_0b53_2:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_0b61_2;
																		IL_0b61_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0b8a_2;
																		IL_0b8a_2:
																		ptr2 += 8;
																		num = 37;
																		goto IL_0ba1_2;
																		IL_0ba1_2:
																		num5--;
																		goto IL_0d8d_2;
																		IL_0bb4_2:
																		if (4 < b)
																		{
																			break;
																		}
																		goto IL_0bc2_2;
																		IL_0bc2_2:
																		if (4 > b)
																		{
																			break;
																		}
																		num = 187;
																		goto IL_0bd9_2;
																		IL_0a7c_2:
																		num5--;
																		goto IL_0d8d_2;
																		IL_0bd9_2:
																		array2[num5] = 0;
																		goto IL_0be7_2;
																		IL_0be7_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_0c92_2;
																		IL_0c92_2:
																		array3[num5] = null;
																		goto IL_0c9c_2;
																		IL_0c9c_2:
																		num5++;
																		goto IL_0caa_2;
																		IL_0caa_2:
																		ptr2 += 8;
																		goto IL_0d8d_2;
																		IL_0595_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
																		goto IL_0a68_2;
																	}
																	break;
																}
																goto IL_0ce8_2;
																IL_0d31_2:
																ptr2 += 8;
																goto IL_0d8d_2;
																IL_0ce8_2:
																array2[num5] = 0;
																num = 118;
																goto IL_0cff_2;
																IL_0cff_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = ((delegate*<int>)CompletingsetCapacity[*(int*)(ptr2 + num3)])();
																goto IL_0d23_2;
																IL_0d23_2:
																num5++;
																goto IL_0d31_2;
															}
															break;
														}
														goto IL_048b_2;
														IL_08e6_2:
														if (21 > b)
														{
															break;
														}
														goto IL_08f4_2;
														IL_048b_2:
														if (16 >= b)
														{
															goto IL_0496_2;
														}
														goto IL_04fd_2;
														IL_0496_2:
														if (16 > b)
														{
															goto IL_04dc_2;
														}
														goto IL_0537_2;
														IL_0537_2:
														array2[num5] = array2[num5 - 1];
														goto IL_054f_2;
														IL_054f_2:
														array4[num5 - 0] = array4[num5 - 1];
														goto IL_076e_2;
														IL_076e_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1]);
														goto IL_0792_2;
														IL_0792_2:
														array3[num5] = array3[num5 - 1];
														goto IL_0a55_2;
														IL_0a55_2:
														num5++;
														goto IL_0d8d_2;
														IL_04dc_2:
														if (13 >= b)
														{
															goto IL_04ea_2;
														}
														goto IL_069c_2;
														IL_04ea_2:
														if (13 <= b)
														{
															goto end_IL_0480;
														}
														goto IL_05da_2;
														IL_05da_2:
														if (12 < b)
														{
															break;
														}
														goto IL_0910_2;
														IL_0910_2:
														if (12 > b)
														{
															break;
														}
														goto IL_0d8d_2;
														IL_069c_2:
														if (14 >= b)
														{
															goto IL_06a7_2;
														}
														goto IL_06f4_2;
														IL_06a7_2:
														if (14 > b)
														{
															break;
														}
														goto IL_06b5_2;
														IL_06b5_2:
														array7[*(int*)(ptr2 + num3)] = array3[num5 - 1];
														goto IL_06d3_2;
														IL_06d3_2:
														ptr2 += 8;
														goto IL_06e1_2;
														IL_06e1_2:
														num5--;
														goto IL_0d8d_2;
														IL_06f4_2:
														if (15 < b)
														{
															break;
														}
														goto IL_0702_2;
														IL_0702_2:
														if (15 > b)
														{
															break;
														}
														goto IL_0710_2;
														IL_0710_2:
														array3[num5 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 1])];
														goto IL_0739_2;
														IL_0739_2:
														array2[num5 - 1] = 5;
														num = 52;
														goto IL_0d8d_2;
														IL_04fd_2:
														if (19 >= b)
														{
															goto IL_050b_2;
														}
														goto IL_0875_2;
														IL_050b_2:
														if (19 > b)
														{
															goto IL_0519_2;
														}
														goto IL_07af_2;
														IL_0519_2:
														if (17 >= b)
														{
															goto IL_0527_2;
														}
														goto IL_075b_2;
														IL_0527_2:
														if (17 > b)
														{
															break;
														}
														goto IL_0582_2;
														IL_0582_2:
														array2[num5] = 5;
														goto IL_0a8f_2;
														IL_0a8f_2:
														array3[num5] = array7[*(int*)(ptr2 + num3)];
														goto IL_0aa7_2;
														IL_0aa7_2:
														num5++;
														goto IL_0ab5_2;
														IL_0ab5_2:
														ptr2 += 8;
														goto IL_0d8d_2;
														IL_075b_2:
														if (18 < b)
														{
															break;
														}
														goto IL_0923_2;
														IL_0923_2:
														if (18 > b)
														{
															break;
														}
														num = 87;
														goto IL_093a_2;
														IL_08f4_2:
														num9 = ptr2;
														num10 = -200;
														num4 = 1;
														ptr2 = num9 + num10;
														goto IL_0d8d_2;
														IL_093a_2:
														((string[])array3[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5 - 2])] = (string)array3[num5 - 1];
														goto IL_0978_2;
														IL_0978_2:
														num5 -= 3;
														goto IL_0d8d_2;
														IL_07af_2:
														array2[num5 - 1] = 5;
														goto IL_07c3_2;
														IL_07c3_2:
														array3[num5 - 1] = ((delegate*<string[], string>)CompletingsetCapacity[*(int*)(ptr2 + num3)])((string[])array3[num5 - 1]);
														goto IL_07fb_2;
														IL_07fb_2:
														ptr2 += 8;
														goto IL_0d8d_2;
														IL_0875_2:
														if (20 >= b)
														{
															goto IL_0880_2;
														}
														goto IL_08d8_2;
														IL_0880_2:
														if (20 > b)
														{
															break;
														}
														goto IL_088e_2;
														IL_088e_2:
														((delegate*<string, void>)CompletingsetCapacity[*(int*)(ptr2 + num3)])((string)array3[num5 - 1]);
														goto IL_08b7_2;
														IL_08b7_2:
														num5--;
														goto IL_08c5_2;
														IL_08c5_2:
														ptr2 += 8;
														goto IL_0d8d_2;
														IL_08d8_2:
														if (21 < b)
														{
															break;
														}
														goto IL_08e6_2;
													}
													break;
													IL_0450_2:;
												}
											}
											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num5]) = *(int*)(ptr2 + num3);
											goto IL_0d5a_2;
											IL_0d7f_2:
											ptr2 += 8;
											goto IL_0d8d_2;
											IL_0d68_2:
											num5++;
											num = 122;
											goto IL_0d7f_2;
											IL_0d5a_2:
											array2[num5] = 0;
											goto IL_0d68_2;
											continue;
											end_IL_0460_2:
											break;
										}
										continue;
										end_IL_0470:
										break;
									}
									continue;
									end_IL_0480:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num6 = num5;
					if (array == null)
					{
						goto IL_099a_2;
					}
					continue;
					end_IL_09a8:
					break;
				}
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_042d, IL_0440, IL_0453, IL_0463, IL_0473, IL_0483, IL_0490, IL_04a0, IL_04b0, IL_04c0, IL_04d0, IL_04e0, IL_04eb, IL_04fb, IL_0509, IL_0517, IL_0522, IL_0530, IL_053e, IL_0551, IL_055c, IL_0585, IL_0593, IL_05a6, IL_05b1, IL_05c4, IL_05d2, IL_05db, IL_05e9, IL_0629, IL_063d, IL_0659, IL_0699, IL_06ad, IL_06c0, IL_06ce, IL_06d9, IL_0719, IL_0732, IL_0740, IL_074e, IL_075c, IL_077f, IL_0789, IL_07a0, IL_07b3, IL_07c1, IL_07cf, IL_07d8, IL_0821, IL_0835, IL_0848, IL_0861, IL_086f, IL_087d, IL_0890, IL_08a3, IL_08e3, IL_08f7, IL_090a, IL_0918, IL_097a, IL_098d, IL_09a1, IL_09e0, IL_09f3, IL_0a01, IL_0a0f, IL_0a2c, IL_0a7b, IL_0a85, IL_0ab2, IL_0ac6, IL_0ad4, IL_0ae7, IL_0af5, IL_0b08, IL_0b16, IL_0b24, IL_0b42, IL_0b50, IL_0b6c, IL_0b95, IL_0bae, IL_0bbc, IL_0bc7, IL_0c19, IL_0c2c, IL_0c3a, IL_0c45, IL_0c59, IL_0c91, IL_0ca4, IL_0cb2, IL_0cbd, IL_0ccb, IL_0cec, IL_0cfa, IL_0d0d, IL_0d1b, IL_0d29, IL_0d4a, IL_0d68, IL_0d8c, IL_0da4, IL_0db7, IL_0dc5, IL_0dd3, IL_0e11, IL_0e2d, IL_0e3b, IL_0e46, IL_0e5e, IL_0e6c, IL_0e7a, IL_0e93, IL_0ea1, IL_0eaf, IL_0ecb, IL_0ed9, IL_0ee2, IL_0ef0, IL_0f31, IL_0f45, IL_0f58, IL_0f66, IL_0f74, IL_0f82, IL_0f8d, IL_0fa6, IL_0fb4, IL_0fc2, IL_0fd5, IL_0fe3, IL_0ff1, IL_101a, IL_1028, IL_103b, IL_1049, IL_1057, IL_1060, IL_1074, IL_10b3, IL_10c6, IL_10cf, IL_110f, IL_112c, IL_113f, IL_114d, IL_115b, IL_1169, IL_1177, IL_1180, IL_1194, IL_11d3, IL_11e3, IL_11fc, IL_1207, IL_1212, IL_1225, IL_1238, IL_1242, IL_124d, IL_125d, IL_126d, IL_1286, IL_1296, IL_12a6, IL_12b6, IL_12cf, IL_12df, IL_12fa are reachable both inside and outside the pinned region starting at IL_12f4. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 211;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef35 = default(int);
			ref int reference = ref __rxRef35;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_12df:
					num2 = 1;
					while (true)
					{
						IL_12cf:
						num3 = num2 * 4;
						while (true)
						{
							IL_12b6:
							num4 = num2 * 8;
							num = 167;
							while (true)
							{
								IL_12a6:
								array2 = new byte[4];
								while (true)
								{
									IL_1296:
									array3 = new object[4];
									while (true)
									{
										IL_1286:
										array4 = new int[4];
										while (true)
										{
											IL_126d:
											array5 = new int[7];
											num = 131;
											while (true)
											{
												IL_125d:
												array6 = new long[4];
												while (true)
												{
													IL_124d:
													array7 = new object[13];
													while (true)
													{
														IL_1242:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HostProtectionPermissiongetActivationType.MscorlibDictionaryKeyCollectionDebugViewAsyncMessageHelper);
														while (true)
														{
															IL_1238:
															ptr2 = ptr;
															while (true)
															{
																IL_1225:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_04e0:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_04d0:
																			ptr2++;
																			while (true)
																			{
																				IL_04c0:
																				if (b >= 1)
																				{
																					while (b <= 30)
																					{
																						while (true)
																						{
																							IL_04a0:
																							if (15 >= b)
																							{
																								while (true)
																								{
																									IL_0490:
																									if (15 > b)
																									{
																										while (true)
																										{
																											IL_0483:
																											if (7 < b)
																											{
																												while (true)
																												{
																													IL_0473:
																													if (11 >= b)
																													{
																														while (true)
																														{
																															IL_0463:
																															if (11 > b)
																															{
																																while (true)
																																{
																																	IL_0453:
																																	if (9 < b)
																																	{
																																		while (10 >= b)
																																		{
																																			num = 260;
																																			while (true)
																																			{
																																				if (num != 260)
																																				{
																																					if (num != 1241)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 211:
																																						break;
																																					default:
																																						continue;
																																					case 183:
																																						goto IL_0440;
																																					case 56:
																																						goto IL_0453;
																																					case 29:
																																						goto IL_0463;
																																					case 123:
																																						goto IL_0473;
																																					case 7:
																																						goto IL_0483;
																																					case 108:
																																						goto IL_0490;
																																					case 202:
																																						goto IL_04a0;
																																					case 14:
																																						goto IL_04b0;
																																					case 170:
																																						goto IL_04c0;
																																					case 69:
																																						goto IL_04d0;
																																					case 47:
																																					case 245:
																																						goto IL_04e0;
																																					case 67:
																																						goto IL_04eb;
																																					case 171:
																																						goto IL_04fb;
																																					case 28:
																																						goto IL_0509;
																																					case 191:
																																						goto IL_0522;
																																					case 120:
																																						goto IL_0530;
																																					case 133:
																																					case 169:
																																						goto IL_053e;
																																					case 217:
																																						goto IL_0551;
																																					case 16:
																																					case 145:
																																						goto IL_055c;
																																					case 137:
																																						goto IL_0585;
																																					case 3:
																																						goto IL_0593;
																																					case 136:
																																						goto IL_05a6;
																																					case 44:
																																						goto IL_05b1;
																																					case 52:
																																						goto IL_05c4;
																																					case 54:
																																						goto IL_05db;
																																					case 113:
																																					case 187:
																																						goto IL_05e9;
																																					case 149:
																																						goto IL_0629;
																																					case 190:
																																						goto IL_063d;
																																					case 151:
																																					case 230:
																																						goto IL_0659;
																																					case 96:
																																						goto IL_0699;
																																					case 82:
																																						goto IL_06ad;
																																					case 231:
																																						goto IL_06c0;
																																					case 93:
																																						goto IL_06ce;
																																					case 89:
																																					case 229:
																																						goto IL_06d9;
																																					case 161:
																																						goto IL_0719;
																																					case 166:
																																						goto IL_0732;
																																					case 130:
																																						goto IL_0740;
																																					case 72:
																																					case 114:
																																						goto end_IL_042d;
																																					case 98:
																																						goto IL_075c;
																																					case 17:
																																						goto IL_077f;
																																					case 144:
																																						goto IL_0789;
																																					case 163:
																																						goto IL_07a0;
																																					case 19:
																																						goto IL_07b3;
																																					case 122:
																																						goto IL_07c1;
																																					case 80:
																																					case 215:
																																						goto IL_07d8;
																																					case 237:
																																						goto IL_0821;
																																					case 125:
																																						goto IL_0835;
																																					case 205:
																																					case 240:
																																						goto IL_0848;
																																					case 141:
																																						goto IL_0861;
																																					case 53:
																																						goto IL_086f;
																																					case 92:
																																						goto IL_087d;
																																					case 241:
																																						goto IL_0890;
																																					case 51:
																																					case 253:
																																						goto IL_08a3;
																																					case 213:
																																						goto IL_08e3;
																																					case 20:
																																						goto IL_08f7;
																																					case 119:
																																					case 134:
																																						goto IL_0918;
																																					case 46:
																																						goto IL_097a;
																																					case 172:
																																					case 207:
																																						goto IL_098d;
																																					case 185:
																																						goto IL_09a1;
																																					case 68:
																																						goto IL_09e0;
																																					case 150:
																																						goto IL_09f3;
																																					case 232:
																																						goto IL_0a01;
																																					case 73:
																																					case 216:
																																						goto IL_0a0f;
																																					case 4:
																																						goto IL_0ac6;
																																					case 109:
																																						goto IL_0ad4;
																																					case 155:
																																						goto IL_0ae7;
																																					case 147:
																																						goto IL_0af5;
																																					case 48:
																																						goto IL_0b08;
																																					case 127:
																																						goto IL_0b16;
																																					case 57:
																																					case 247:
																																						goto IL_0b24;
																																					case 74:
																																						goto IL_0b42;
																																					case 37:
																																						goto IL_0b50;
																																					case 31:
																																					case 227:
																																						goto IL_0b6c;
																																					case 1:
																																						goto IL_0b95;
																																					case 42:
																																						goto IL_0bae;
																																					case 43:
																																						goto IL_0bbc;
																																					case 135:
																																					case 146:
																																						goto IL_0bc7;
																																					case 36:
																																						goto IL_0c19;
																																					case 35:
																																						goto IL_0c2c;
																																					case 85:
																																						goto IL_0c3a;
																																					case 175:
																																					case 234:
																																						goto IL_0c45;
																																					case 12:
																																						goto IL_0c59;
																																					case 221:
																																						goto IL_0c91;
																																					case 78:
																																						goto IL_0ca4;
																																					case 204:
																																						goto IL_0cb2;
																																					case 236:
																																					case 246:
																																						goto IL_0cbd;
																																					case 223:
																																						goto IL_0ccb;
																																					case 99:
																																						goto IL_0cec;
																																					case 203:
																																						goto IL_0cfa;
																																					case 118:
																																						goto IL_0d0d;
																																					case 15:
																																						goto IL_0d1b;
																																					case 201:
																																					case 243:
																																						goto IL_0d29;
																																					case 101:
																																						goto IL_0d4a;
																																					case 178:
																																						goto IL_0d68;
																																					case 124:
																																						goto IL_0d8c;
																																					case 181:
																																						goto IL_0da4;
																																					case 239:
																																						goto IL_0db7;
																																					case 194:
																																						goto IL_0dc5;
																																					case 94:
																																					case 222:
																																						goto IL_0dd3;
																																					case 112:
																																						goto IL_0e11;
																																					case 212:
																																						goto IL_0e2d;
																																					case 63:
																																						goto IL_0e3b;
																																					case 88:
																																					case 152:
																																						goto IL_0e46;
																																					case 142:
																																						goto IL_0e5e;
																																					case 24:
																																						goto IL_0e6c;
																																					case 21:
																																					case 60:
																																						goto IL_0e7a;
																																					case 40:
																																						goto IL_0e93;
																																					case 182:
																																						goto IL_0ea1;
																																					case 164:
																																						goto IL_0eaf;
																																					case 126:
																																						goto IL_0ecb;
																																					case 27:
																																						goto IL_0ee2;
																																					case 75:
																																					case 192:
																																						goto IL_0ef0;
																																					case 62:
																																						goto IL_0f31;
																																					case 70:
																																						goto IL_0f45;
																																					case 32:
																																						goto IL_0f58;
																																					case 168:
																																						goto IL_0f66;
																																					case 79:
																																						goto IL_0f74;
																																					case 242:
																																						goto IL_0f82;
																																					case 107:
																																					case 184:
																																						goto IL_0f8d;
																																					case 49:
																																						goto IL_0fa6;
																																					case 64:
																																						goto IL_0fb4;
																																					case 218:
																																						goto IL_0fc2;
																																					case 41:
																																						goto IL_0fd5;
																																					case 77:
																																						goto IL_0fe3;
																																					case 153:
																																					case 251:
																																						goto IL_0ff1;
																																					case 196:
																																						goto IL_101a;
																																					case 189:
																																						goto IL_1028;
																																					case 250:
																																						goto IL_103b;
																																					case 195:
																																						goto IL_1049;
																																					case 5:
																																					case 25:
																																						goto IL_1060;
																																					case 248:
																																						goto IL_1074;
																																					case 199:
																																						goto IL_10b3;
																																					case 90:
																																					case 252:
																																						goto IL_10cf;
																																					case 26:
																																						goto IL_110f;
																																					case 200:
																																						goto IL_112c;
																																					case 162:
																																						goto IL_113f;
																																					case 104:
																																						goto IL_114d;
																																					case 198:
																																						goto IL_115b;
																																					case 86:
																																						goto IL_1169;
																																					case 23:
																																					case 61:
																																						goto IL_1180;
																																					case 0:
																																						goto IL_1194;
																																					case 50:
																																						goto IL_11d3;
																																					case 176:
																																					case 235:
																																						goto IL_11e3;
																																					case 66:
																																						goto IL_11fc;
																																					case 154:
																																						goto IL_1207;
																																					case 6:
																																					case 10:
																																					case 11:
																																					case 13:
																																					case 18:
																																					case 22:
																																					case 34:
																																					case 38:
																																					case 39:
																																					case 45:
																																					case 81:
																																					case 83:
																																					case 91:
																																					case 97:
																																					case 103:
																																					case 105:
																																					case 106:
																																					case 110:
																																					case 111:
																																					case 116:
																																					case 138:
																																					case 140:
																																					case 157:
																																					case 158:
																																					case 165:
																																					case 173:
																																					case 174:
																																					case 177:
																																					case 193:
																																					case 209:
																																					case 219:
																																					case 220:
																																					case 233:
																																						goto end_IL_0440;
																																					case 8:
																																					case 9:
																																					case 30:
																																					case 33:
																																					case 55:
																																					case 58:
																																					case 59:
																																					case 65:
																																					case 71:
																																					case 76:
																																					case 87:
																																					case 100:
																																					case 102:
																																					case 117:
																																					case 121:
																																					case 128:
																																					case 129:
																																					case 139:
																																					case 156:
																																					case 160:
																																					case 180:
																																					case 186:
																																					case 188:
																																					case 197:
																																					case 208:
																																					case 214:
																																					case 224:
																																					case 225:
																																					case 226:
																																					case 228:
																																					case 238:
																																					case 244:
																																					case 249:
																																						goto IL_1225;
																																					case 2:
																																						goto IL_1238;
																																					case 206:
																																						goto IL_1242;
																																					case 84:
																																						goto IL_124d;
																																					case 131:
																																						goto IL_125d;
																																					case 143:
																																						goto IL_126d;
																																					case 95:
																																						goto IL_1286;
																																					case 148:
																																						goto IL_1296;
																																					case 167:
																																						goto IL_12a6;
																																					case 132:
																																						goto IL_12b6;
																																					case 179:
																																						goto IL_12cf;
																																					case 210:
																																						goto IL_12df;
																																					case 115:
																																					case 159:
																																						return;
																																					}
																																					goto end_IL_04c0;
																																				}
																																				if (10 > b)
																																				{
																																					goto end_IL_0440;
																																				}
																																				goto IL_0918;
																																				IL_0918:
																																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																																				goto IL_097a;
																																				IL_097a:
																																				num6 -= 2;
																																				goto IL_1225;
																																				continue;
																																				end_IL_042d:
																																				break;
																																			}
																																			goto IL_074e;
																																			continue;
																																			end_IL_0440:
																																			break;
																																			IL_0440:;
																																		}
																																		break;
																																	}
																																	goto IL_04eb;
																																	IL_08f7:
																																	num6--;
																																	goto IL_1225;
																																	IL_04eb:
																																	if (9 > b)
																																	{
																																		goto IL_0522;
																																	}
																																	goto IL_08a3;
																																	IL_0522:
																																	if (8 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0530;
																																	IL_0530:
																																	if (8 > b)
																																	{
																																		break;
																																	}
																																	goto IL_053e;
																																	IL_053e:
																																	num6--;
																																	goto IL_1225;
																																	IL_08a3:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	goto IL_08e3;
																																	IL_08e3:
																																	array2[num6 - 2] = 0;
																																	goto IL_08f7;
																																}
																																break;
																															}
																															goto IL_098d;
																															IL_09e0:
																															ptr2 += 8;
																															goto IL_1225;
																															IL_098d:
																															array2[num6 - 1] = 0;
																															goto IL_09a1;
																															IL_09a1:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																															goto IL_09e0;
																														}
																														break;
																													}
																													goto IL_09f3;
																													IL_0b16:
																													if (14 > b)
																													{
																														break;
																													}
																													goto IL_0b24;
																													IL_09f3:
																													if (13 >= b)
																													{
																														goto IL_0a01;
																													}
																													goto IL_0b08;
																													IL_0a01:
																													if (13 <= b)
																													{
																														goto IL_0a0f;
																													}
																													goto IL_0ae7;
																													IL_0a0f:
																													array8 = array3;
																													num7 = num6;
																													if (array == null)
																													{
																														goto IL_0a1e;
																													}
																													num8 = ptr2;
																													byte b2 = *num8;
																													ptr2 = num8 + 4;
																													int num9 = *(int*)(ptr2 + num3);
																													ptr2 += 8;
																													byte* ptr3 = ptr2 + num9;
																													byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																													while (ptr2 != ptr3)
																													{
																														*ptr4 = (byte)(*ptr2 ^ b2);
																														ptr2++;
																														ptr4++;
																													}
																													array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																													goto IL_0ac6;
																													IL_0b24:
																													array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																													goto IL_0b42;
																													IL_0b42:
																													ptr2 += 8;
																													goto IL_0b50;
																													IL_0b50:
																													num6--;
																													num = 30;
																													goto IL_1225;
																													IL_0ac6:
																													array2[num6] = 5;
																													goto IL_0ad4;
																													IL_0ad4:
																													num6++;
																													goto IL_1225;
																													IL_0ae7:
																													if (12 < b)
																													{
																														break;
																													}
																													goto IL_0af5;
																													IL_0af5:
																													if (12 > b)
																													{
																														break;
																													}
																													goto IL_1225;
																													IL_0b08:
																													if (14 < b)
																													{
																														break;
																													}
																													goto IL_0b16;
																												}
																												break;
																											}
																											goto IL_04fb;
																											IL_0835:
																											num6--;
																											goto IL_1225;
																											IL_04fb:
																											if (7 > b)
																											{
																												goto IL_0509;
																											}
																											goto IL_0659;
																											IL_0509:
																											if (3 >= b)
																											{
																												num = 217;
																												goto IL_0551;
																											}
																											goto IL_06c0;
																											IL_0659:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0699;
																											IL_0551:
																											if (3 <= b)
																											{
																												goto IL_055c;
																											}
																											goto IL_05a6;
																											IL_055c:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0585;
																											IL_0585:
																											ptr2 += 8;
																											goto IL_0593;
																											IL_0593:
																											num6--;
																											goto IL_1225;
																											IL_05a6:
																											if (1 >= b)
																											{
																												goto IL_05b1;
																											}
																											goto IL_05c4;
																											IL_05b1:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_0848;
																											IL_0848:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																											goto IL_0861;
																											IL_0861:
																											array2[num6] = 0;
																											goto IL_086f;
																											IL_086f:
																											num6++;
																											goto IL_087d;
																											IL_087d:
																											ptr2 += 8;
																											goto IL_1225;
																											IL_05c4:
																											if (2 < b)
																											{
																												break;
																											}
																											num = 54;
																											goto IL_05db;
																											IL_0699:
																											array2[num6 - 2] = 0;
																											goto IL_06ad;
																											IL_05db:
																											if (2 > b)
																											{
																												break;
																											}
																											goto IL_05e9;
																											IL_05e9:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0629;
																											IL_0629:
																											array2[num6 - 2] = 0;
																											goto IL_063d;
																											IL_063d:
																											num6--;
																											num = 59;
																											goto IL_1225;
																											IL_06c0:
																											if (5 >= b)
																											{
																												goto IL_06ce;
																											}
																											goto IL_07b3;
																											IL_06ce:
																											if (5 <= b)
																											{
																												goto IL_06d9;
																											}
																											goto IL_0732;
																											IL_06d9:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_0719;
																											IL_0719:
																											array2[num6 - 2] = 0;
																											goto IL_0890;
																											IL_0890:
																											num6--;
																											goto IL_1225;
																											IL_0732:
																											if (4 < b)
																											{
																												break;
																											}
																											goto IL_0740;
																											IL_0740:
																											if (4 > b)
																											{
																												break;
																											}
																											goto IL_074e;
																											IL_074e:
																											array2[num6] = 0;
																											goto IL_075c;
																											IL_075c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_077f;
																											IL_077f:
																											array3[num6] = null;
																											goto IL_0789;
																											IL_0789:
																											num6++;
																											num = 163;
																											goto IL_07a0;
																											IL_07a0:
																											ptr2 += 8;
																											goto IL_1225;
																											IL_07b3:
																											if (6 < b)
																											{
																												break;
																											}
																											goto IL_07c1;
																											IL_07c1:
																											if (6 > b)
																											{
																												break;
																											}
																											num = 215;
																											goto IL_07d8;
																											IL_06ad:
																											num6--;
																											goto IL_1225;
																											IL_07d8:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											num = 237;
																											goto IL_0821;
																											IL_0821:
																											array2[num6 - 2] = 0;
																											goto IL_0835;
																										}
																										break;
																									}
																									goto IL_0b6c;
																									IL_0b95:
																									array2[num6 - 1] = 5;
																									goto IL_1225;
																									IL_0b6c:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_0b95;
																								}
																								break;
																							}
																							goto IL_0bae;
																							IL_1194:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_11d3;
																							IL_0bae:
																							if (23 >= b)
																							{
																								goto IL_0bbc;
																							}
																							goto IL_0f58;
																							IL_0bbc:
																							if (23 <= b)
																							{
																								goto IL_0bc7;
																							}
																							goto IL_0c2c;
																							IL_0bc7:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0c19;
																							IL_0c19:
																							num6--;
																							goto IL_1225;
																							IL_0c2c:
																							if (19 >= b)
																							{
																								goto IL_0c3a;
																							}
																							goto IL_0e2d;
																							IL_0c3a:
																							if (19 <= b)
																							{
																								goto IL_0c45;
																							}
																							goto IL_0ca4;
																							IL_0c45:
																							array2[num6 - 1] = 5;
																							goto IL_0c59;
																							IL_0c59:
																							array3[num6 - 1] = ((delegate*<string[], string>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_0c91;
																							IL_0c91:
																							ptr2 += 8;
																							goto IL_1225;
																							IL_0ca4:
																							if (17 >= b)
																							{
																								goto IL_0cb2;
																							}
																							goto IL_0db7;
																							IL_0cb2:
																							if (17 <= b)
																							{
																								goto IL_0cbd;
																							}
																							goto IL_0d0d;
																							IL_0cbd:
																							array2[num6] = 5;
																							goto IL_0ccb;
																							IL_0ccb:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							num = 99;
																							goto IL_0cec;
																							IL_0cec:
																							num6++;
																							goto IL_0cfa;
																							IL_0cfa:
																							ptr2 += 8;
																							goto IL_1225;
																							IL_0d0d:
																							if (16 < b)
																							{
																								break;
																							}
																							goto IL_0d1b;
																							IL_0d1b:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_0d29;
																							IL_0d29:
																							array2[num6] = array2[num6 - 1];
																							num = 101;
																							goto IL_0d4a;
																							IL_0d4a:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_0d68;
																							IL_0d68:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0d8c;
																							IL_0d8c:
																							array3[num6] = array3[num6 - 1];
																							goto IL_0da4;
																							IL_0da4:
																							num6++;
																							goto IL_1225;
																							IL_0db7:
																							if (18 < b)
																							{
																								break;
																							}
																							goto IL_0dc5;
																							IL_0dc5:
																							if (18 > b)
																							{
																								break;
																							}
																							goto IL_0dd3;
																							IL_0dd3:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_0e11;
																							IL_0e11:
																							num6 -= 3;
																							num = 225;
																							goto IL_1225;
																							IL_0e2d:
																							if (21 >= b)
																							{
																								goto IL_0e3b;
																							}
																							goto IL_0ecb;
																							IL_0e3b:
																							if (21 <= b)
																							{
																								goto IL_0e46;
																							}
																							goto IL_0e5e;
																							IL_0e46:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_1225;
																							IL_0e5e:
																							if (20 < b)
																							{
																								break;
																							}
																							goto IL_0e6c;
																							IL_0e6c:
																							if (20 > b)
																							{
																								break;
																							}
																							goto IL_0e7a;
																							IL_0e7a:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0e93;
																							IL_0e93:
																							array2[num6] = 1;
																							goto IL_0ea1;
																							IL_0ea1:
																							num6++;
																							goto IL_0eaf;
																							IL_0eaf:
																							ptr2 += 16;
																							num = 208;
																							goto IL_1225;
																							IL_0ecb:
																							if (22 < b)
																							{
																								break;
																							}
																							num = 27;
																							goto IL_0ee2;
																							IL_11d3:
																							ptr2 += 8;
																							goto IL_1225;
																							IL_0ee2:
																							if (22 > b)
																							{
																								break;
																							}
																							goto IL_0ef0;
																							IL_0ef0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_0f31;
																							IL_0f31:
																							array2[num6 - 2] = 0;
																							goto IL_0f45;
																							IL_0f45:
																							num6--;
																							goto IL_1225;
																							IL_0f58:
																							if (27 >= b)
																							{
																								goto IL_0f66;
																							}
																							goto IL_113f;
																							IL_0f66:
																							if (27 > b)
																							{
																								goto IL_0f74;
																							}
																							num = 252;
																							goto IL_10cf;
																							IL_0f74:
																							if (25 >= b)
																							{
																								goto IL_0f82;
																							}
																							goto IL_103b;
																							IL_0f82:
																							if (25 <= b)
																							{
																								goto IL_0f8d;
																							}
																							goto IL_0fd5;
																							IL_0f8d:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																							goto IL_0fa6;
																							IL_0fa6:
																							array2[num6] = 3;
																							goto IL_0fb4;
																							IL_0fb4:
																							num6++;
																							goto IL_0fc2;
																							IL_0fc2:
																							ptr2 += 16;
																							goto IL_1225;
																							IL_0fd5:
																							if (24 < b)
																							{
																								break;
																							}
																							goto IL_0fe3;
																							IL_0fe3:
																							if (24 > b)
																							{
																								break;
																							}
																							goto IL_0ff1;
																							IL_0ff1:
																							((delegate*<string, void>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																							goto IL_101a;
																							IL_101a:
																							num6--;
																							goto IL_1028;
																							IL_1028:
																							ptr2 += 8;
																							goto IL_1225;
																							IL_103b:
																							if (26 < b)
																							{
																								break;
																							}
																							goto IL_1049;
																							IL_1049:
																							if (26 > b)
																							{
																								break;
																							}
																							num = 5;
																							goto IL_1060;
																							IL_11fc:
																							if (30 < b)
																							{
																								break;
																							}
																							goto IL_1207;
																							IL_1060:
																							array2[num6 - 1] = 3;
																							goto IL_1074;
																							IL_1074:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_10b3;
																							IL_10b3:
																							ptr2 += 8;
																							goto IL_1225;
																							IL_11e3:
																							num10 = ptr2;
																							num11 = -200;
																							num5 = 1;
																							ptr2 = num10 + num11;
																							goto IL_1225;
																							IL_10cf:
																							*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_110f;
																							IL_110f:
																							array2[num6 - 2] = 3;
																							num = 200;
																							goto IL_112c;
																							IL_112c:
																							num6--;
																							goto IL_1225;
																							IL_113f:
																							if (29 >= b)
																							{
																								goto IL_114d;
																							}
																							goto IL_11fc;
																							IL_114d:
																							if (29 > b)
																							{
																								goto IL_115b;
																							}
																							goto IL_11e3;
																							IL_115b:
																							if (28 < b)
																							{
																								break;
																							}
																							goto IL_1169;
																							IL_1169:
																							if (28 > b)
																							{
																								break;
																							}
																							num = 23;
																							goto IL_1180;
																							IL_1207:
																							if (30 <= b)
																							{
																							}
																							break;
																							IL_1180:
																							array2[num6 - 1] = 0;
																							goto IL_1194;
																						}
																						break;
																						IL_04b0:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_1225;
																				continue;
																				end_IL_04c0:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																num = 115;
																return;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0a1e:
			while (true)
			{
				IL_0a1e_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0ac6_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0ad4_2:
							num6++;
							while (true)
							{
								IL_1225_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_04c0_2:
												if (b >= 1)
												{
													while (b <= 30)
													{
														while (true)
														{
															IL_04a0_2:
															if (15 >= b)
															{
																while (true)
																{
																	IL_0490_2:
																	if (15 > b)
																	{
																		while (true)
																		{
																			IL_0483_2:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_0473_2:
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_0463_2:
																							if (11 > b)
																							{
																								while (true)
																								{
																									IL_0453_2:
																									if (9 < b)
																									{
																										while (10 >= b)
																										{
																											num = 260;
																											while (true)
																											{
																												if (num != 260)
																												{
																													if (num != 1241)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 183:
																														goto IL_0440_2;
																													case 56:
																														goto IL_0453_2;
																													case 29:
																														goto IL_0463_2;
																													case 123:
																														goto IL_0473_2;
																													case 7:
																														goto IL_0483_2;
																													case 108:
																														goto IL_0490_2;
																													case 202:
																														goto IL_04a0_2;
																													case 14:
																														goto IL_04b0_2;
																													case 170:
																														goto IL_04c0_2;
																													case 69:
																														goto end_IL_04c0_2;
																													case 47:
																													case 245:
																														goto end_IL_04d0;
																													case 67:
																														goto IL_04eb_2;
																													case 171:
																														goto IL_04fb_2;
																													case 28:
																														goto IL_0509_2;
																													case 191:
																														goto IL_0522_2;
																													case 120:
																														goto IL_0530_2;
																													case 133:
																													case 169:
																														goto IL_053e_2;
																													case 217:
																														goto IL_0551_2;
																													case 16:
																													case 145:
																														goto IL_055c_2;
																													case 137:
																														goto IL_0585_2;
																													case 3:
																														goto IL_0593_2;
																													case 136:
																														goto IL_05a6_2;
																													case 44:
																														goto IL_05b1_2;
																													case 52:
																														goto IL_05c4_2;
																													case 54:
																														goto IL_05db_2;
																													case 113:
																													case 187:
																														goto IL_05e9_2;
																													case 149:
																														goto IL_0629_2;
																													case 190:
																														goto IL_063d_2;
																													case 151:
																													case 230:
																														goto IL_0659_2;
																													case 96:
																														goto IL_0699_2;
																													case 82:
																														goto IL_06ad_2;
																													case 231:
																														goto IL_06c0_2;
																													case 93:
																														goto IL_06ce_2;
																													case 89:
																													case 229:
																														goto IL_06d9_2;
																													case 161:
																														goto IL_0719_2;
																													case 166:
																														goto IL_0732_2;
																													case 130:
																														goto IL_0740_2;
																													case 72:
																													case 114:
																														goto end_IL_042d_2;
																													case 98:
																														goto IL_075c_2;
																													case 17:
																														goto IL_077f_2;
																													case 144:
																														goto IL_0789_2;
																													case 163:
																														goto IL_07a0_2;
																													case 19:
																														goto IL_07b3_2;
																													case 122:
																														goto IL_07c1_2;
																													case 80:
																													case 215:
																														goto IL_07d8_2;
																													case 237:
																														goto IL_0821_2;
																													case 125:
																														goto IL_0835_2;
																													case 205:
																													case 240:
																														goto IL_0848_2;
																													case 141:
																														goto IL_0861_2;
																													case 53:
																														goto IL_086f_2;
																													case 92:
																														goto IL_087d_2;
																													case 241:
																														goto IL_0890_2;
																													case 51:
																													case 253:
																														goto IL_08a3_2;
																													case 213:
																														goto IL_08e3_2;
																													case 20:
																														goto IL_08f7_2;
																													case 119:
																													case 134:
																														goto IL_0918_2;
																													case 46:
																														goto IL_097a_2;
																													case 172:
																													case 207:
																														goto IL_098d_2;
																													case 185:
																														goto IL_09a1_2;
																													case 68:
																														goto IL_09e0_2;
																													case 150:
																														goto IL_09f3_2;
																													case 232:
																														goto IL_0a01_2;
																													case 73:
																													case 216:
																														goto end_IL_04e0;
																													case 4:
																														goto IL_0ac6_2;
																													case 109:
																														goto IL_0ad4_2;
																													case 155:
																														goto IL_0ae7_2;
																													case 147:
																														goto IL_0af5_2;
																													case 48:
																														goto IL_0b08_2;
																													case 127:
																														goto IL_0b16_2;
																													case 57:
																													case 247:
																														goto IL_0b24_2;
																													case 74:
																														goto IL_0b42_2;
																													case 37:
																														goto IL_0b50_2;
																													case 31:
																													case 227:
																														goto IL_0b6c_2;
																													case 1:
																														goto IL_0b95_2;
																													case 42:
																														goto IL_0bae_2;
																													case 43:
																														goto IL_0bbc_2;
																													case 135:
																													case 146:
																														goto IL_0bc7_2;
																													case 36:
																														goto IL_0c19_2;
																													case 35:
																														goto IL_0c2c_2;
																													case 85:
																														goto IL_0c3a_2;
																													case 175:
																													case 234:
																														goto IL_0c45_2;
																													case 12:
																														goto IL_0c59_2;
																													case 221:
																														goto IL_0c91_2;
																													case 78:
																														goto IL_0ca4_2;
																													case 204:
																														goto IL_0cb2_2;
																													case 236:
																													case 246:
																														goto IL_0cbd_2;
																													case 223:
																														goto IL_0ccb_2;
																													case 99:
																														goto IL_0cec_2;
																													case 203:
																														goto IL_0cfa_2;
																													case 118:
																														goto IL_0d0d_2;
																													case 15:
																														goto IL_0d1b_2;
																													case 201:
																													case 243:
																														goto IL_0d29_2;
																													case 101:
																														goto IL_0d4a_2;
																													case 178:
																														goto IL_0d68_2;
																													case 124:
																														goto IL_0d8c_2;
																													case 181:
																														goto IL_0da4_2;
																													case 239:
																														goto IL_0db7_2;
																													case 194:
																														goto IL_0dc5_2;
																													case 94:
																													case 222:
																														goto IL_0dd3_2;
																													case 112:
																														goto IL_0e11_2;
																													case 212:
																														goto IL_0e2d_2;
																													case 63:
																														goto IL_0e3b_2;
																													case 88:
																													case 152:
																														goto IL_0e46_2;
																													case 142:
																														goto IL_0e5e_2;
																													case 24:
																														goto IL_0e6c_2;
																													case 21:
																													case 60:
																														goto IL_0e7a_2;
																													case 40:
																														goto IL_0e93_2;
																													case 182:
																														goto IL_0ea1_2;
																													case 164:
																														goto IL_0eaf_2;
																													case 126:
																														goto IL_0ecb_2;
																													case 27:
																														goto IL_0ee2_2;
																													case 75:
																													case 192:
																														goto IL_0ef0_2;
																													case 62:
																														goto IL_0f31_2;
																													case 70:
																														goto IL_0f45_2;
																													case 32:
																														goto IL_0f58_2;
																													case 168:
																														goto IL_0f66_2;
																													case 79:
																														goto IL_0f74_2;
																													case 242:
																														goto IL_0f82_2;
																													case 107:
																													case 184:
																														goto IL_0f8d_2;
																													case 49:
																														goto IL_0fa6_2;
																													case 64:
																														goto IL_0fb4_2;
																													case 218:
																														goto IL_0fc2_2;
																													case 41:
																														goto IL_0fd5_2;
																													case 77:
																														goto IL_0fe3_2;
																													case 153:
																													case 251:
																														goto IL_0ff1_2;
																													case 196:
																														goto IL_101a_2;
																													case 189:
																														goto IL_1028_2;
																													case 250:
																														goto IL_103b_2;
																													case 195:
																														goto IL_1049_2;
																													case 5:
																													case 25:
																														goto IL_1060_2;
																													case 248:
																														goto IL_1074_2;
																													case 199:
																														goto IL_10b3_2;
																													case 90:
																													case 252:
																														goto IL_10cf_2;
																													case 26:
																														goto IL_110f_2;
																													case 200:
																														goto IL_112c_2;
																													case 162:
																														goto IL_113f_2;
																													case 104:
																														goto IL_114d_2;
																													case 198:
																														goto IL_115b_2;
																													case 86:
																														goto IL_1169_2;
																													case 23:
																													case 61:
																														goto IL_1180_2;
																													case 0:
																														goto IL_1194_2;
																													case 50:
																														goto IL_11d3_2;
																													case 176:
																													case 235:
																														goto IL_11e3_2;
																													case 66:
																														goto IL_11fc_2;
																													case 154:
																														goto IL_1207_2;
																													case 6:
																													case 10:
																													case 11:
																													case 13:
																													case 18:
																													case 22:
																													case 34:
																													case 38:
																													case 39:
																													case 45:
																													case 81:
																													case 83:
																													case 91:
																													case 97:
																													case 103:
																													case 105:
																													case 106:
																													case 110:
																													case 111:
																													case 116:
																													case 138:
																													case 140:
																													case 157:
																													case 158:
																													case 165:
																													case 173:
																													case 174:
																													case 177:
																													case 193:
																													case 209:
																													case 219:
																													case 220:
																													case 233:
																														goto end_IL_0440_2;
																													case 8:
																													case 9:
																													case 30:
																													case 33:
																													case 55:
																													case 58:
																													case 59:
																													case 65:
																													case 71:
																													case 76:
																													case 87:
																													case 100:
																													case 102:
																													case 117:
																													case 121:
																													case 128:
																													case 129:
																													case 139:
																													case 156:
																													case 160:
																													case 180:
																													case 186:
																													case 188:
																													case 197:
																													case 208:
																													case 214:
																													case 224:
																													case 225:
																													case 226:
																													case 228:
																													case 238:
																													case 244:
																													case 249:
																														goto IL_1225_2;
																													case 2:
																														ptr2 = ptr;
																														goto IL_1225_2;
																													case 206:
																														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HostProtectionPermissiongetActivationType.MscorlibDictionaryKeyCollectionDebugViewAsyncMessageHelper);
																														goto case 2;
																													case 84:
																														array7 = new object[13];
																														goto case 206;
																													case 131:
																														array6 = new long[4];
																														goto case 84;
																													case 143:
																														array5 = new int[7];
																														num = 131;
																														goto case 131;
																													case 95:
																														array4 = new int[4];
																														goto case 143;
																													case 148:
																														array3 = new object[4];
																														goto case 95;
																													case 167:
																														array2 = new byte[4];
																														goto case 148;
																													case 132:
																														num4 = num2 * 8;
																														num = 167;
																														goto case 167;
																													case 179:
																														num3 = num2 * 4;
																														goto case 132;
																													case 210:
																														num2 = 1;
																														goto case 179;
																													case 211:
																														goto end_IL_0a2c;
																													case 115:
																													case 159:
																														return;
																													}
																													continue;
																												}
																												if (10 > b)
																												{
																													goto end_IL_0440_2;
																												}
																												goto IL_0918_2;
																												IL_0918_2:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_097a_2;
																												IL_097a_2:
																												num6 -= 2;
																												goto IL_1225_2;
																												continue;
																												end_IL_042d_2:
																												break;
																											}
																											goto IL_074e_2;
																											continue;
																											end_IL_0440_2:
																											break;
																											IL_0440_2:;
																										}
																										break;
																									}
																									goto IL_04eb_2;
																									IL_08f7_2:
																									num6--;
																									goto IL_1225_2;
																									IL_04eb_2:
																									if (9 > b)
																									{
																										goto IL_0522_2;
																									}
																									goto IL_08a3_2;
																									IL_0522_2:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_0530_2;
																									IL_0530_2:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_053e_2;
																									IL_053e_2:
																									num6--;
																									goto IL_1225_2;
																									IL_08a3_2:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_08e3_2;
																									IL_08e3_2:
																									array2[num6 - 2] = 0;
																									goto IL_08f7_2;
																								}
																								break;
																							}
																							goto IL_098d_2;
																							IL_09e0_2:
																							ptr2 += 8;
																							goto IL_1225_2;
																							IL_098d_2:
																							array2[num6 - 1] = 0;
																							goto IL_09a1_2;
																							IL_09a1_2:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																							goto IL_09e0_2;
																						}
																						break;
																					}
																					goto IL_09f3_2;
																					IL_0b50_2:
																					num6--;
																					num = 30;
																					goto IL_1225_2;
																					IL_09f3_2:
																					if (13 >= b)
																					{
																						goto IL_0a01_2;
																					}
																					goto IL_0b08_2;
																					IL_0a01_2:
																					if (13 <= b)
																					{
																						goto end_IL_04e0;
																					}
																					goto IL_0ae7_2;
																					IL_0ae7_2:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_0af5_2;
																					IL_0af5_2:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_1225_2;
																					IL_0b08_2:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_0b16_2;
																					IL_0b16_2:
																					if (14 > b)
																					{
																						break;
																					}
																					goto IL_0b24_2;
																					IL_0b24_2:
																					array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																					goto IL_0b42_2;
																					IL_0b42_2:
																					ptr2 += 8;
																					goto IL_0b50_2;
																				}
																				break;
																			}
																			goto IL_04fb_2;
																			IL_0835_2:
																			num6--;
																			goto IL_1225_2;
																			IL_04fb_2:
																			if (7 > b)
																			{
																				goto IL_0509_2;
																			}
																			goto IL_0659_2;
																			IL_0509_2:
																			if (3 >= b)
																			{
																				num = 217;
																				goto IL_0551_2;
																			}
																			goto IL_06c0_2;
																			IL_0659_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0699_2;
																			IL_0551_2:
																			if (3 <= b)
																			{
																				goto IL_055c_2;
																			}
																			goto IL_05a6_2;
																			IL_055c_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0585_2;
																			IL_0585_2:
																			ptr2 += 8;
																			goto IL_0593_2;
																			IL_0593_2:
																			num6--;
																			goto IL_1225_2;
																			IL_05a6_2:
																			if (1 >= b)
																			{
																				goto IL_05b1_2;
																			}
																			goto IL_05c4_2;
																			IL_05b1_2:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0848_2;
																			IL_0848_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0861_2;
																			IL_0861_2:
																			array2[num6] = 0;
																			goto IL_086f_2;
																			IL_086f_2:
																			num6++;
																			goto IL_087d_2;
																			IL_087d_2:
																			ptr2 += 8;
																			goto IL_1225_2;
																			IL_05c4_2:
																			if (2 < b)
																			{
																				break;
																			}
																			num = 54;
																			goto IL_05db_2;
																			IL_0699_2:
																			array2[num6 - 2] = 0;
																			goto IL_06ad_2;
																			IL_05db_2:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_05e9_2;
																			IL_05e9_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0629_2;
																			IL_0629_2:
																			array2[num6 - 2] = 0;
																			goto IL_063d_2;
																			IL_063d_2:
																			num6--;
																			num = 59;
																			goto IL_1225_2;
																			IL_06c0_2:
																			if (5 >= b)
																			{
																				goto IL_06ce_2;
																			}
																			goto IL_07b3_2;
																			IL_06ce_2:
																			if (5 <= b)
																			{
																				goto IL_06d9_2;
																			}
																			goto IL_0732_2;
																			IL_06d9_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_0719_2;
																			IL_0719_2:
																			array2[num6 - 2] = 0;
																			goto IL_0890_2;
																			IL_0890_2:
																			num6--;
																			goto IL_1225_2;
																			IL_0732_2:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0740_2;
																			IL_0740_2:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_074e_2;
																			IL_074e_2:
																			array2[num6] = 0;
																			goto IL_075c_2;
																			IL_075c_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_077f_2;
																			IL_077f_2:
																			array3[num6] = null;
																			goto IL_0789_2;
																			IL_0789_2:
																			num6++;
																			num = 163;
																			goto IL_07a0_2;
																			IL_07a0_2:
																			ptr2 += 8;
																			goto IL_1225_2;
																			IL_07b3_2:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_07c1_2;
																			IL_07c1_2:
																			if (6 > b)
																			{
																				break;
																			}
																			num = 215;
																			goto IL_07d8_2;
																			IL_06ad_2:
																			num6--;
																			goto IL_1225_2;
																			IL_07d8_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			num = 237;
																			goto IL_0821_2;
																			IL_0821_2:
																			array2[num6 - 2] = 0;
																			goto IL_0835_2;
																		}
																		break;
																	}
																	goto IL_0b6c_2;
																	IL_0b95_2:
																	array2[num6 - 1] = 5;
																	goto IL_1225_2;
																	IL_0b6c_2:
																	array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																	goto IL_0b95_2;
																}
																break;
															}
															goto IL_0bae_2;
															IL_1194_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_11d3_2;
															IL_0bae_2:
															if (23 >= b)
															{
																goto IL_0bbc_2;
															}
															goto IL_0f58_2;
															IL_0bbc_2:
															if (23 <= b)
															{
																goto IL_0bc7_2;
															}
															goto IL_0c2c_2;
															IL_0bc7_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0c19_2;
															IL_0c19_2:
															num6--;
															goto IL_1225_2;
															IL_0c2c_2:
															if (19 >= b)
															{
																goto IL_0c3a_2;
															}
															goto IL_0e2d_2;
															IL_0c3a_2:
															if (19 <= b)
															{
																goto IL_0c45_2;
															}
															goto IL_0ca4_2;
															IL_0c45_2:
															array2[num6 - 1] = 5;
															goto IL_0c59_2;
															IL_0c59_2:
															array3[num6 - 1] = ((delegate*<string[], string>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
															goto IL_0c91_2;
															IL_0c91_2:
															ptr2 += 8;
															goto IL_1225_2;
															IL_0ca4_2:
															if (17 >= b)
															{
																goto IL_0cb2_2;
															}
															goto IL_0db7_2;
															IL_0cb2_2:
															if (17 <= b)
															{
																goto IL_0cbd_2;
															}
															goto IL_0d0d_2;
															IL_0cbd_2:
															array2[num6] = 5;
															goto IL_0ccb_2;
															IL_0ccb_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															num = 99;
															goto IL_0cec_2;
															IL_0cec_2:
															num6++;
															goto IL_0cfa_2;
															IL_0cfa_2:
															ptr2 += 8;
															goto IL_1225_2;
															IL_0d0d_2:
															if (16 < b)
															{
																break;
															}
															goto IL_0d1b_2;
															IL_0d1b_2:
															if (16 > b)
															{
																break;
															}
															goto IL_0d29_2;
															IL_0d29_2:
															array2[num6] = array2[num6 - 1];
															num = 101;
															goto IL_0d4a_2;
															IL_0d4a_2:
															array4[num6 - 0] = array4[num6 - 1];
															goto IL_0d68_2;
															IL_0d68_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0d8c_2;
															IL_0d8c_2:
															array3[num6] = array3[num6 - 1];
															goto IL_0da4_2;
															IL_0da4_2:
															num6++;
															goto IL_1225_2;
															IL_0db7_2:
															if (18 < b)
															{
																break;
															}
															goto IL_0dc5_2;
															IL_0dc5_2:
															if (18 > b)
															{
																break;
															}
															goto IL_0dd3_2;
															IL_0dd3_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															goto IL_0e11_2;
															IL_0e11_2:
															num6 -= 3;
															num = 225;
															goto IL_1225_2;
															IL_0e2d_2:
															if (21 >= b)
															{
																goto IL_0e3b_2;
															}
															goto IL_0ecb_2;
															IL_0e3b_2:
															if (21 <= b)
															{
																goto IL_0e46_2;
															}
															goto IL_0e5e_2;
															IL_0e46_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_1225_2;
															IL_0e5e_2:
															if (20 < b)
															{
																break;
															}
															goto IL_0e6c_2;
															IL_0e6c_2:
															if (20 > b)
															{
																break;
															}
															goto IL_0e7a_2;
															IL_0e7a_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
															goto IL_0e93_2;
															IL_0e93_2:
															array2[num6] = 1;
															goto IL_0ea1_2;
															IL_0ea1_2:
															num6++;
															goto IL_0eaf_2;
															IL_0eaf_2:
															ptr2 += 16;
															num = 208;
															goto IL_1225_2;
															IL_0ecb_2:
															if (22 < b)
															{
																break;
															}
															num = 27;
															goto IL_0ee2_2;
															IL_11d3_2:
															ptr2 += 8;
															goto IL_1225_2;
															IL_0ee2_2:
															if (22 > b)
															{
																break;
															}
															goto IL_0ef0_2;
															IL_0ef0_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
															goto IL_0f31_2;
															IL_0f31_2:
															array2[num6 - 2] = 0;
															goto IL_0f45_2;
															IL_0f45_2:
															num6--;
															goto IL_1225_2;
															IL_0f58_2:
															if (27 >= b)
															{
																goto IL_0f66_2;
															}
															goto IL_113f_2;
															IL_0f66_2:
															if (27 > b)
															{
																goto IL_0f74_2;
															}
															num = 252;
															goto IL_10cf_2;
															IL_0f74_2:
															if (25 >= b)
															{
																goto IL_0f82_2;
															}
															goto IL_103b_2;
															IL_0f82_2:
															if (25 <= b)
															{
																goto IL_0f8d_2;
															}
															goto IL_0fd5_2;
															IL_0f8d_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
															goto IL_0fa6_2;
															IL_0fa6_2:
															array2[num6] = 3;
															goto IL_0fb4_2;
															IL_0fb4_2:
															num6++;
															goto IL_0fc2_2;
															IL_0fc2_2:
															ptr2 += 16;
															goto IL_1225_2;
															IL_0fd5_2:
															if (24 < b)
															{
																break;
															}
															goto IL_0fe3_2;
															IL_0fe3_2:
															if (24 > b)
															{
																break;
															}
															goto IL_0ff1_2;
															IL_0ff1_2:
															((delegate*<string, void>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
															goto IL_101a_2;
															IL_101a_2:
															num6--;
															goto IL_1028_2;
															IL_1028_2:
															ptr2 += 8;
															goto IL_1225_2;
															IL_103b_2:
															if (26 < b)
															{
																break;
															}
															goto IL_1049_2;
															IL_1049_2:
															if (26 > b)
															{
																break;
															}
															num = 5;
															goto IL_1060_2;
															IL_11fc_2:
															if (30 < b)
															{
																break;
															}
															goto IL_1207_2;
															IL_1060_2:
															array2[num6 - 1] = 3;
															goto IL_1074_2;
															IL_1074_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)dwLowDateTimegetCapsLock[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
															goto IL_10b3_2;
															IL_10b3_2:
															ptr2 += 8;
															goto IL_1225_2;
															IL_11e3_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															goto IL_1225_2;
															IL_10cf_2:
															*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_110f_2;
															IL_110f_2:
															array2[num6 - 2] = 3;
															num = 200;
															goto IL_112c_2;
															IL_112c_2:
															num6--;
															goto IL_1225_2;
															IL_113f_2:
															if (29 >= b)
															{
																goto IL_114d_2;
															}
															goto IL_11fc_2;
															IL_114d_2:
															if (29 > b)
															{
																goto IL_115b_2;
															}
															goto IL_11e3_2;
															IL_115b_2:
															if (28 < b)
															{
																break;
															}
															goto IL_1169_2;
															IL_1169_2:
															if (28 > b)
															{
																break;
															}
															num = 23;
															goto IL_1180_2;
															IL_1207_2:
															if (30 <= b)
															{
															}
															break;
															IL_1180_2:
															array2[num6 - 1] = 0;
															goto IL_1194_2;
														}
														break;
														IL_04b0_2:;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_1225_2;
												continue;
												end_IL_04c0_2:
												break;
											}
											continue;
											end_IL_04d0:
											break;
										}
										continue;
										end_IL_04e0:
										break;
									}
									break;
								}
								num = 115;
								return;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_0a1e_2;
					}
					continue;
					end_IL_0a2c:
					break;
				}
				break;
			}
		}
	}

	public Class122()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 63;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 112;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref wMinorVerNumDeclaredFields.SBCSCodePageEncodingUnregisterTypeForComClients);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0338:
															byte b = *ptr2;
															while (true)
															{
																IL_0328:
																ptr2++;
																while (true)
																{
																	IL_0318:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_02f8:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_02eb:
																						if (7 <= b)
																						{
																							while (true)
																							{
																								IL_02a9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								while (true)
																								{
																									IL_0293:
																									array[num5 - 2] = 0;
																									while (true)
																									{
																										IL_027a:
																										num5--;
																										num = 150;
																										while (num != 150 && num == 1131)
																										{
																											switch (num)
																											{
																											case 138:
																												goto IL_027a;
																											case 107:
																												goto IL_0293;
																											case 1:
																											case 123:
																												goto IL_02a9;
																											case 126:
																												goto IL_02eb;
																											case 139:
																												goto IL_02f8;
																											case 50:
																												goto IL_0308;
																											case 40:
																												goto IL_0318;
																											case 136:
																												goto IL_0328;
																											case 5:
																											case 60:
																												goto IL_0338;
																											case 34:
																												goto IL_0343;
																											case 52:
																												goto IL_034e;
																											case 22:
																											case 32:
																												goto IL_035c;
																											case 109:
																												goto IL_0374;
																											case 17:
																											case 54:
																												goto IL_037f;
																											case 87:
																												goto IL_038f;
																											case 6:
																											case 44:
																												goto IL_039d;
																											case 27:
																												goto IL_03ab;
																											case 132:
																												goto IL_03be;
																											case 108:
																											case 127:
																												goto IL_03cc;
																											case 0:
																												goto IL_040c;
																											case 43:
																												goto IL_0420;
																											case 11:
																											case 133:
																												goto IL_0433;
																											case 89:
																												goto IL_0441;
																											case 82:
																											case 134:
																												goto IL_0469;
																											case 75:
																												goto IL_0474;
																											case 105:
																											case 118:
																												goto IL_0482;
																											case 41:
																												goto IL_049b;
																											case 95:
																												goto IL_04a9;
																											case 111:
																												goto IL_04b7;
																											case 48:
																												goto IL_04ca;
																											case 81:
																												goto IL_04d8;
																											case 83:
																											case 115:
																												goto IL_04e6;
																											case 86:
																												goto IL_050f;
																											case 35:
																												goto IL_051d;
																											case 140:
																												goto IL_0530;
																											case 37:
																												goto IL_053a;
																											case 4:
																												goto IL_0548;
																											case 100:
																											case 114:
																												goto IL_056d;
																											case 96:
																												goto IL_057b;
																											case 3:
																											case 29:
																												goto IL_0589;
																											case 92:
																												goto IL_059d;
																											case 113:
																												goto IL_05f1;
																											case 142:
																												goto IL_05ff;
																											case 19:
																											case 58:
																												goto IL_061b;
																											case 106:
																											case 116:
																												goto IL_0629;
																											case 91:
																												goto IL_0637;
																											case 66:
																											case 93:
																												goto IL_0645;
																											case 16:
																												goto IL_0685;
																											case 102:
																												goto IL_0699;
																											case 88:
																												goto IL_06ac;
																											case 9:
																											case 51:
																												goto IL_06b7;
																											case 143:
																												goto IL_06c5;
																											case 23:
																											case 39:
																												goto IL_06d3;
																											case 38:
																												goto IL_06f6;
																											case 120:
																												goto IL_0704;
																											case 128:
																												goto IL_071b;
																											case 26:
																											case 69:
																												goto IL_072e;
																											case 85:
																												goto IL_0790;
																											case 67:
																											case 103:
																												goto IL_07ac;
																											case 101:
																												goto IL_07b7;
																											case 7:
																											case 68:
																												goto IL_07cb;
																											case 73:
																												goto IL_07d6;
																											case 33:
																											case 76:
																												goto IL_07e1;
																											case 25:
																											case 110:
																												goto IL_07f1;
																											case 74:
																												goto IL_080a;
																											case 2:
																												goto IL_0815;
																											case 10:
																											case 12:
																											case 13:
																											case 14:
																											case 18:
																											case 20:
																											case 21:
																											case 28:
																											case 30:
																											case 42:
																											case 45:
																											case 55:
																											case 57:
																											case 59:
																											case 72:
																											case 79:
																											case 80:
																											case 84:
																											case 94:
																											case 98:
																											case 119:
																											case 122:
																											case 125:
																											case 129:
																											case 130:
																											case 131:
																											case 135:
																												goto end_IL_0308;
																											case 8:
																											case 15:
																											case 46:
																											case 56:
																											case 61:
																											case 64:
																											case 65:
																											case 77:
																											case 78:
																											case 90:
																											case 97:
																											case 99:
																											case 104:
																											case 121:
																											case 124:
																											case 141:
																												goto end_IL_0267;
																											case 117:
																												goto end_IL_0833;
																											case 71:
																												goto end_IL_0846;
																											case 47:
																												goto end_IL_0850;
																											case 49:
																												goto end_IL_085b;
																											case 112:
																												goto end_IL_0870;
																											case 53:
																												goto end_IL_0880;
																											case 137:
																												goto end_IL_0890;
																											case 36:
																											case 70:
																												goto end_IL_089b;
																											case 62:
																												goto end_IL_08ab;
																											case 63:
																												goto end_IL_08bb;
																											case 24:
																											case 31:
																												goto IL_08d6;
																											}
																											continue;
																											end_IL_0267:
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0343;
																						IL_0548:
																						ptr2 += 8;
																						num = 104;
																						break;
																						IL_0343:
																						if (3 >= b)
																						{
																							goto IL_034e;
																						}
																						goto IL_0374;
																						IL_034e:
																						if (3 <= b)
																						{
																							goto IL_035c;
																						}
																						goto IL_0469;
																						IL_035c:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_0469:
																						if (1 >= b)
																						{
																							goto IL_0474;
																						}
																						goto IL_04ca;
																						IL_0474:
																						if (1 > b)
																						{
																							goto end_IL_0308;
																						}
																						goto IL_0482;
																						IL_0482:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_049b;
																						IL_049b:
																						array[num5] = 0;
																						goto IL_04a9;
																						IL_04a9:
																						num5++;
																						goto IL_04b7;
																						IL_04b7:
																						ptr2 += 8;
																						break;
																						IL_04ca:
																						if (2 < b)
																						{
																							goto end_IL_0308;
																						}
																						goto IL_04d8;
																						IL_04d8:
																						if (2 > b)
																						{
																							goto end_IL_0308;
																						}
																						goto IL_04e6;
																						IL_04e6:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_050f;
																						IL_050f:
																						ptr2 += 8;
																						goto IL_051d;
																						IL_051d:
																						num5--;
																						break;
																						IL_0374:
																						if (5 < b)
																						{
																							goto IL_037f;
																						}
																						goto IL_038f;
																						IL_037f:
																						if (6 < b)
																						{
																							goto end_IL_0308;
																						}
																						goto IL_03be;
																						IL_03be:
																						if (6 > b)
																						{
																							goto end_IL_0308;
																						}
																						goto IL_03cc;
																						IL_03cc:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_040c;
																						IL_040c:
																						array[num5 - 2] = 0;
																						goto IL_0420;
																						IL_0420:
																						num5--;
																						break;
																						IL_038f:
																						if (5 > b)
																						{
																							goto IL_039d;
																						}
																						goto IL_0433;
																						IL_039d:
																						if (4 < b)
																						{
																							goto end_IL_0308;
																						}
																						goto IL_03ab;
																						IL_03ab:
																						if (4 > b)
																						{
																							goto end_IL_0308;
																						}
																						break;
																						IL_0433:
																						array[num5] = 0;
																						goto IL_0441;
																						IL_0441:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0530;
																						IL_0530:
																						array2[num5] = null;
																						goto IL_053a;
																						IL_053a:
																						num5++;
																						goto IL_0548;
																					}
																					break;
																				}
																				num = 114;
																				goto IL_056d;
																				IL_07d6:
																				if (12 > b)
																				{
																					goto end_IL_0308;
																				}
																				goto IL_07e1;
																				IL_07e1:
																				num5--;
																				break;
																				IL_056d:
																				if (11 >= b)
																				{
																					goto IL_057b;
																				}
																				num = 103;
																				goto IL_07ac;
																				IL_057b:
																				if (11 <= b)
																				{
																					goto IL_0589;
																				}
																				num = 19;
																				goto IL_061b;
																				IL_0589:
																				array[num5 - 2] = 0;
																				goto IL_059d;
																				IL_059d:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)OleAutBindergetTreatControlCAsInput[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_05f1;
																				IL_05f1:
																				num5--;
																				goto IL_05ff;
																				IL_05ff:
																				ptr2 += 8;
																				break;
																				IL_080a:
																				if (14 < b)
																				{
																					goto end_IL_0308;
																				}
																				goto IL_0815;
																				IL_061b:
																				if (9 < b)
																				{
																					goto IL_0629;
																				}
																				goto IL_06ac;
																				IL_0629:
																				if (10 < b)
																				{
																					goto end_IL_0308;
																				}
																				goto IL_0637;
																				IL_0637:
																				if (10 > b)
																				{
																					goto end_IL_0308;
																				}
																				goto IL_0645;
																				IL_0645:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0685;
																				IL_0685:
																				array[num5 - 2] = 0;
																				goto IL_0699;
																				IL_0699:
																				num5--;
																				break;
																				IL_06ac:
																				if (9 > b)
																				{
																					goto IL_06b7;
																				}
																				goto IL_072e;
																				IL_06b7:
																				if (8 < b)
																				{
																					goto end_IL_0308;
																				}
																				goto IL_06c5;
																				IL_06c5:
																				if (8 > b)
																				{
																					goto end_IL_0308;
																				}
																				goto IL_06d3;
																				IL_06d3:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_06f6;
																				IL_06f6:
																				array[num5] = 0;
																				goto IL_0704;
																				IL_0704:
																				num5++;
																				num = 128;
																				goto IL_071b;
																				IL_071b:
																				ptr2 += 8;
																				break;
																				IL_072e:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0790;
																				IL_0790:
																				num5 -= 2;
																				break;
																				IL_07f1:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_07ac:
																				if (13 >= b)
																				{
																					goto IL_07b7;
																				}
																				goto IL_080a;
																				IL_07b7:
																				if (13 > b)
																				{
																					num = 68;
																					goto IL_07cb;
																				}
																				goto IL_07f1;
																				IL_0815:
																				if (14 > b)
																				{
																				}
																				goto end_IL_0308;
																				IL_07cb:
																				if (12 < b)
																				{
																					goto end_IL_0308;
																				}
																				goto IL_07d6;
																			}
																			goto end_IL_0318;
																			continue;
																			end_IL_0308:
																			break;
																			IL_0308:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0318:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_08d6;
													IL_08d6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0833:
													break;
												}
												continue;
												end_IL_0846:
												break;
											}
											continue;
											end_IL_0850:
											break;
										}
										continue;
										end_IL_085b:
										break;
									}
									continue;
									end_IL_0870:
									break;
								}
								continue;
								end_IL_0880:
								break;
							}
							continue;
							end_IL_0890:
							break;
						}
						continue;
						end_IL_089b:
						break;
					}
					continue;
					end_IL_08ab:
					break;
				}
				continue;
				end_IL_08bb:
				break;
			}
		}
	}

	private static int smethod_1(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		int num3;
		if (num <= num2)
		{
			num = int_3;
			num2 = int_2;
			num -= num2;
			num3 = num;
		}
		else
		{
			num = int_2;
			num2 = int_3;
			num -= num2;
			num3 = num;
		}
		num = num3;
		num2 = 253;
		num2 = 23;
		int num4 = smethod_0(23);
		num2 = num4;
		return num;
	}

	private unsafe static int smethod_2()
	{
		int num = 86;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getFullTypeNameToByte.CtorDelegateuseApmPattern);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_08d1:
												if (num4 != 1)
												{
													while (true)
													{
														IL_0373:
														byte b = *ptr2;
														while (true)
														{
															IL_0363:
															ptr2++;
															while (true)
															{
																IL_0353:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0333:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0323:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0316:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_0306:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_02f6:
																											if (6 > b)
																											{
																												while (5 >= b)
																												{
																													while (5 <= b)
																													{
																														num = 60;
																														while (true)
																														{
																															IL_02c3:
																															array[num5] = 5;
																															while (true)
																															{
																																IL_02a0:
																																array2[num5] = array5[*(int*)(ptr2 + num3)];
																																num = 156;
																																while (true)
																																{
																																	if (num != 156)
																																	{
																																		if (num != 1137)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 35:
																																			goto IL_02a0;
																																		case 60:
																																		case 135:
																																			goto IL_02c3;
																																		case 1:
																																			goto IL_02d3;
																																		case 6:
																																			goto IL_02e6;
																																		case 79:
																																			goto IL_02f6;
																																		case 30:
																																			goto IL_0306;
																																		case 28:
																																		case 109:
																																			goto IL_0316;
																																		case 26:
																																			goto IL_0323;
																																		case 122:
																																			goto IL_0333;
																																		case 53:
																																			goto IL_0343;
																																		case 71:
																																			goto IL_0353;
																																		case 131:
																																			goto IL_0363;
																																		case 4:
																																		case 134:
																																			goto IL_0373;
																																		case 74:
																																			goto IL_037e;
																																		case 57:
																																		case 114:
																																			goto IL_038c;
																																		case 19:
																																			goto IL_0397;
																																		case 91:
																																		case 106:
																																			goto IL_03a5;
																																		case 36:
																																			goto IL_03b3;
																																		case 11:
																																		case 76:
																																			goto IL_03be;
																																		case 107:
																																			goto IL_03d7;
																																		case 45:
																																			goto IL_03e5;
																																		case 44:
																																			goto IL_03f3;
																																		case 119:
																																			goto IL_0414;
																																		case 42:
																																			goto IL_0422;
																																		case 2:
																																		case 121:
																																			goto IL_043b;
																																		case 92:
																																			goto IL_0464;
																																		case 14:
																																		case 126:
																																			goto IL_047d;
																																		case 129:
																																			goto IL_049b;
																																		case 7:
																																			goto IL_04a9;
																																		case 82:
																																		case 133:
																																			goto IL_04bc;
																																		case 140:
																																			goto IL_04fc;
																																		case 69:
																																		case 143:
																																			goto IL_051b;
																																		case 141:
																																			goto IL_055a;
																																		case 146:
																																			goto IL_056d;
																																		case 24:
																																		case 147:
																																			goto IL_0580;
																																		case 95:
																																			goto IL_058e;
																																		case 39:
																																		case 81:
																																			goto IL_05a5;
																																		case 142:
																																			goto IL_05ce;
																																		case 46:
																																			goto IL_05dc;
																																		case 128:
																																			goto IL_0606;
																																		case 63:
																																		case 75:
																																			goto IL_0619;
																																		case 116:
																																			goto IL_0631;
																																		case 32:
																																		case 37:
																																			goto IL_063f;
																																		case 23:
																																		case 113:
																																			goto IL_064a;
																																		case 56:
																																			goto IL_0658;
																																		case 3:
																																			goto IL_066b;
																																		case 5:
																																		case 40:
																																			goto IL_0679;
																																		case 105:
																																			goto IL_0687;
																																		case 77:
																																		case 100:
																																			goto IL_0695;
																																		case 73:
																																			goto IL_06f7;
																																		case 97:
																																		case 117:
																																			goto IL_070a;
																																		case 25:
																																			goto IL_0726;
																																		case 99:
																																		case 110:
																																			goto IL_0731;
																																		case 96:
																																			goto IL_0771;
																																		case 130:
																																			goto IL_0785;
																																		case 112:
																																			goto IL_0798;
																																		case 87:
																																		case 136:
																																			goto IL_07a6;
																																		case 58:
																																			goto IL_07b4;
																																		case 64:
																																		case 80:
																																			goto IL_07c2;
																																		case 144:
																																			goto IL_0806;
																																		case 101:
																																			goto IL_081a;
																																		case 123:
																																			goto IL_082d;
																																		case 84:
																																		case 120:
																																			goto IL_0838;
																																		case 103:
																																			goto IL_0843;
																																		case 33:
																																		case 94:
																																			goto IL_085c;
																																		case 65:
																																			goto IL_086a;
																																		case 149:
																																			goto IL_088d;
																																		case 104:
																																			goto IL_08a0;
																																		case 61:
																																			goto IL_08ae;
																																		case 0:
																																		case 16:
																																		case 18:
																																		case 21:
																																		case 22:
																																		case 27:
																																		case 31:
																																		case 34:
																																		case 38:
																																		case 41:
																																		case 48:
																																		case 49:
																																		case 51:
																																		case 54:
																																		case 59:
																																		case 67:
																																		case 72:
																																		case 83:
																																		case 90:
																																		case 93:
																																		case 108:
																																		case 115:
																																		case 118:
																																		case 127:
																																		case 137:
																																		case 139:
																																		case 145:
																																			goto end_IL_02d3;
																																		case 8:
																																		case 15:
																																		case 17:
																																		case 20:
																																		case 43:
																																		case 47:
																																		case 52:
																																		case 55:
																																		case 66:
																																		case 70:
																																		case 78:
																																		case 89:
																																		case 98:
																																		case 102:
																																		case 124:
																																		case 132:
																																		case 138:
																																		case 148:
																																			goto IL_08d1;
																																		case 68:
																																			goto end_IL_08d1;
																																		case 111:
																																			goto end_IL_08e4;
																																		case 13:
																																			goto end_IL_08ee;
																																		case 50:
																																			goto end_IL_08f9;
																																		case 10:
																																		case 125:
																																			goto end_IL_0909;
																																		case 9:
																																			goto end_IL_0919;
																																		case 62:
																																		case 88:
																																			goto end_IL_0929;
																																		case 85:
																																			goto end_IL_0939;
																																		case 86:
																																			goto end_IL_0949;
																																		case 12:
																																		case 29:
																																			goto end_IL_028d;
																																		}
																																		continue;
																																	}
																																	num5++;
																																	goto IL_0606;
																																	IL_0606:
																																	ptr2 += 8;
																																	goto IL_08d1;
																																	continue;
																																	end_IL_028d:
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_0353;
																														continue;
																														end_IL_02d3:
																														break;
																														IL_02d3:;
																													}
																													break;
																													IL_02e6:;
																												}
																												break;
																											}
																											goto IL_051b;
																											IL_055a:
																											num5 -= 3;
																											goto IL_08d1;
																											IL_051b:
																											((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_055a;
																										}
																										break;
																									}
																									goto IL_0580;
																									IL_05ce:
																									ptr2 += 8;
																									goto IL_05dc;
																									IL_0580:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_058e;
																									IL_058e:
																									if (7 > b)
																									{
																										break;
																									}
																									num = 81;
																									goto IL_05a5;
																									IL_05dc:
																									num5--;
																									num = 20;
																									goto IL_08d1;
																									IL_05a5:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05ce;
																								}
																								break;
																							}
																							goto IL_037e;
																							IL_047d:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_049b;
																							IL_037e:
																							if (4 > b)
																							{
																								goto IL_038c;
																							}
																							goto IL_047d;
																							IL_038c:
																							if (2 >= b)
																							{
																								goto IL_0397;
																							}
																							goto IL_0414;
																							IL_0397:
																							if (2 > b)
																							{
																								goto IL_03a5;
																							}
																							goto IL_04bc;
																							IL_03a5:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_03b3;
																							IL_03b3:
																							if (1 > b)
																							{
																								num = 31;
																								break;
																							}
																							goto IL_03be;
																							IL_03be:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_03d7;
																							IL_03d7:
																							array[num5] = 0;
																							goto IL_03e5;
																							IL_03e5:
																							num5++;
																							goto IL_03f3;
																							IL_03f3:
																							ptr2 += 8;
																							goto IL_08d1;
																							IL_049b:
																							ptr2 += 8;
																							goto IL_04a9;
																							IL_04bc:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04fc;
																							IL_04fc:
																							array[num5 - 2] = 0;
																							num = 146;
																							goto IL_056d;
																							IL_056d:
																							num5--;
																							goto IL_08d1;
																							IL_0414:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0422;
																							IL_0422:
																							if (3 > b)
																							{
																								num = 139;
																								break;
																							}
																							goto IL_043b;
																							IL_04a9:
																							num5--;
																							goto IL_08d1;
																							IL_043b:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_0464;
																							IL_0464:
																							array[num5 - 1] = 5;
																							goto IL_08d1;
																						}
																						break;
																					}
																					goto IL_0619;
																					IL_0619:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto IL_08d1;
																				}
																				break;
																			}
																			goto IL_0631;
																			IL_08a0:
																			num5++;
																			goto IL_08ae;
																			IL_0631:
																			if (12 < b)
																			{
																				goto IL_063f;
																			}
																			goto IL_0726;
																			IL_063f:
																			if (14 < b)
																			{
																				goto IL_064a;
																			}
																			goto IL_066b;
																			IL_064a:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0658;
																			IL_0658:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_066b:
																			if (14 > b)
																			{
																				goto IL_0679;
																			}
																			goto IL_070a;
																			IL_0679:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0687;
																			IL_0687:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0695;
																			IL_0695:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06f7;
																			IL_06f7:
																			num5 -= 2;
																			goto IL_08d1;
																			IL_070a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto IL_08d1;
																			IL_0726:
																			if (12 <= b)
																			{
																				goto IL_0731;
																			}
																			goto IL_0798;
																			IL_0731:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0771;
																			IL_0771:
																			array[num5 - 2] = 0;
																			goto IL_0785;
																			IL_0785:
																			num5--;
																			goto IL_08d1;
																			IL_0798:
																			if (10 < b)
																			{
																				goto IL_07a6;
																			}
																			goto IL_082d;
																			IL_07a6:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_07b4;
																			IL_07b4:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_07c2;
																			IL_07c2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0806;
																			IL_0806:
																			array[num5 - 2] = 0;
																			goto IL_081a;
																			IL_081a:
																			num5--;
																			goto IL_08d1;
																			IL_082d:
																			if (10 > b)
																			{
																				goto IL_0838;
																			}
																			goto IL_085c;
																			IL_0838:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_0843;
																			IL_0843:
																			if (9 > b)
																			{
																				num = 118;
																				break;
																			}
																			goto IL_08d1;
																			IL_08ae:
																			ptr2 += 8;
																			goto IL_08d1;
																			IL_085c:
																			array[num5] = 0;
																			goto IL_086a;
																			IL_086a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_088d;
																			IL_088d:
																			array2[num5] = null;
																			num = 104;
																			goto IL_08a0;
																		}
																		break;
																		IL_0343:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_08d1;
																continue;
																end_IL_0353:
																break;
															}
															break;
														}
														break;
													}
												}
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08d1:
												break;
											}
											continue;
											end_IL_08e4:
											break;
										}
										continue;
										end_IL_08ee:
										break;
									}
									continue;
									end_IL_08f9:
									break;
								}
								continue;
								end_IL_0909:
								break;
							}
							continue;
							end_IL_0919:
							break;
						}
						continue;
						end_IL_0929:
						break;
					}
					continue;
					end_IL_0939:
					break;
				}
				continue;
				end_IL_0949:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 87;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_08ba:
					byte[] array = new byte[4];
					while (true)
					{
						IL_08aa:
						object[] array2 = new object[4];
						while (true)
						{
							IL_089a:
							int[] array3 = new int[4];
							while (true)
							{
								IL_088a:
								long[] array4 = new long[4];
								while (true)
								{
									IL_0875:
									array3[0] = int_2;
									while (true)
									{
										IL_086a:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CMSASSEMBLYREFERENCEFLAGFOLLOWIRestrictedErrorInfo.NameNotFoundOwner);
										while (true)
										{
											IL_0860:
											byte* ptr2 = ptr;
											while (true)
											{
												IL_084d:
												if (num4 != 1)
												{
													while (true)
													{
														IL_02e5:
														byte b = *ptr2;
														while (true)
														{
															IL_02d5:
															ptr2++;
															while (true)
															{
																IL_02c5:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_02a8:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_0298:
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_0288:
																							if (11 > b)
																							{
																								while (true)
																								{
																									IL_0278:
																									if (9 < b)
																									{
																										num = 146;
																										while (true)
																										{
																											if (num != 146)
																											{
																												if (num != 1127)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 57:
																												case 106:
																													goto IL_0278;
																												case 0:
																													goto IL_0288;
																												case 5:
																													goto IL_0298;
																												case 49:
																													goto IL_02a8;
																												case 119:
																													goto IL_02b5;
																												case 58:
																													goto IL_02c5;
																												case 77:
																													goto IL_02d5;
																												case 19:
																												case 29:
																													goto IL_02e5;
																												case 3:
																													goto IL_02f0;
																												case 44:
																													goto IL_0300;
																												case 51:
																													goto IL_0316;
																												case 40:
																													goto IL_032d;
																												case 52:
																													goto IL_0340;
																												case 23:
																													goto IL_034b;
																												case 32:
																												case 62:
																													goto IL_0369;
																												case 60:
																												case 98:
																													goto IL_03d0;
																												case 28:
																												case 108:
																													goto IL_03f1;
																												case 20:
																													goto IL_0414;
																												case 31:
																													goto IL_0422;
																												case 13:
																													goto IL_0430;
																												case 81:
																												case 115:
																													goto IL_0443;
																												case 126:
																													goto IL_044e;
																												case 67:
																													goto IL_045c;
																												case 46:
																												case 96:
																													goto IL_046a;
																												case 54:
																													goto IL_0493;
																												case 55:
																													goto IL_04a1;
																												case 129:
																													goto IL_04b4;
																												case 4:
																												case 47:
																													goto IL_04c2;
																												case 65:
																													goto IL_04db;
																												case 124:
																													goto IL_04e9;
																												case 122:
																													goto IL_0500;
																												case 74:
																												case 134:
																													goto IL_0513;
																												case 25:
																												case 69:
																													goto IL_0521;
																												case 132:
																													goto IL_052f;
																												case 110:
																												case 127:
																													goto IL_053d;
																												case 128:
																													goto IL_0586;
																												case 15:
																													goto IL_059a;
																												case 101:
																													goto IL_05ad;
																												case 7:
																												case 43:
																													goto IL_05b8;
																												case 18:
																													goto IL_05c6;
																												case 27:
																												case 82:
																													goto IL_05e2;
																												case 118:
																													goto IL_05f0;
																												case 125:
																													goto IL_0613;
																												case 104:
																													goto IL_061d;
																												case 66:
																													goto IL_062b;
																												case 99:
																												case 135:
																													goto IL_0647;
																												case 63:
																													goto IL_0687;
																												case 91:
																													goto IL_069b;
																												case 136:
																													goto IL_06ae;
																												case 6:
																													goto IL_06c1;
																												case 112:
																													goto IL_06cf;
																												case 2:
																												case 35:
																													goto IL_06dd;
																												case 100:
																													goto IL_071d;
																												case 45:
																													goto IL_0731;
																												case 36:
																												case 56:
																													goto IL_0744;
																												case 109:
																													goto IL_0758;
																												case 73:
																													goto IL_07ac;
																												case 94:
																													goto IL_07ba;
																												case 92:
																													goto IL_07cd;
																												case 64:
																												case 113:
																													goto IL_07d8;
																												case 103:
																													goto IL_07e3;
																												case 84:
																													goto IL_07f0;
																												case 14:
																												case 78:
																													goto IL_07fb;
																												case 130:
																													goto IL_0814;
																												case 50:
																													goto IL_081f;
																												case 22:
																												case 59:
																													goto IL_082a;
																												case 1:
																												case 9:
																												case 16:
																												case 17:
																												case 30:
																												case 37:
																												case 42:
																												case 53:
																												case 71:
																												case 72:
																												case 76:
																												case 79:
																												case 85:
																												case 88:
																												case 90:
																												case 93:
																												case 97:
																												case 102:
																												case 105:
																												case 107:
																												case 111:
																												case 114:
																												case 120:
																												case 121:
																												case 123:
																													goto end_IL_02b5;
																												case 11:
																												case 12:
																												case 21:
																												case 26:
																												case 33:
																												case 34:
																												case 48:
																												case 61:
																												case 68:
																												case 70:
																												case 80:
																												case 83:
																												case 89:
																												case 95:
																												case 116:
																												case 117:
																												case 139:
																													goto IL_084d;
																												case 8:
																													goto IL_0860;
																												case 133:
																													goto IL_086a;
																												case 138:
																													goto IL_0875;
																												case 39:
																													goto IL_088a;
																												case 10:
																												case 75:
																													goto IL_089a;
																												case 38:
																													goto IL_08aa;
																												case 41:
																												case 131:
																													goto IL_08ba;
																												case 86:
																													goto end_IL_0265;
																												case 87:
																													goto end_IL_08ca;
																												case 24:
																												case 137:
																													goto IL_08e5;
																												}
																												continue;
																											}
																											goto IL_06c1;
																											IL_071d:
																											array[num5 - 2] = 0;
																											goto IL_0731;
																											IL_0731:
																											num5--;
																											goto IL_084d;
																											IL_06c1:
																											if (10 < b)
																											{
																												goto end_IL_02b5;
																											}
																											goto IL_06cf;
																											IL_06cf:
																											if (10 > b)
																											{
																												goto end_IL_02b5;
																											}
																											goto IL_06dd;
																											IL_06dd:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_071d;
																											continue;
																											end_IL_0265:
																											break;
																										}
																										break;
																									}
																									goto IL_0300;
																									IL_03f1:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_0414;
																									IL_0414:
																									array[num5] = 0;
																									goto IL_0422;
																									IL_0300:
																									if (9 > b)
																									{
																										goto IL_0316;
																									}
																									num = 32;
																									goto IL_0369;
																									IL_0422:
																									num5++;
																									goto IL_0430;
																									IL_0369:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_06ae;
																									IL_06ae:
																									num5 -= 2;
																									goto IL_084d;
																									IL_0316:
																									if (8 < b)
																									{
																										goto end_IL_02b5;
																									}
																									num = 40;
																									goto IL_032d;
																									IL_0430:
																									ptr2 += 8;
																									goto IL_084d;
																									IL_032d:
																									if (8 > b)
																									{
																										goto end_IL_02b5;
																									}
																									goto IL_03f1;
																								}
																								break;
																							}
																							goto IL_0744;
																							IL_07ba:
																							ptr2 += 8;
																							goto IL_084d;
																							IL_0744:
																							array[num5 - 2] = 0;
																							goto IL_0758;
																							IL_0758:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getExportedTypesgetPreviousValue[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_07ac;
																							IL_07ac:
																							num5--;
																							goto IL_07ba;
																						}
																						break;
																					}
																					goto IL_07cd;
																					IL_082a:
																					num5--;
																					goto IL_084d;
																					IL_07cd:
																					if (13 < b)
																					{
																						goto IL_07d8;
																					}
																					goto IL_07f0;
																					IL_07d8:
																					if (14 < b)
																					{
																						goto end_IL_02b5;
																					}
																					goto IL_07e3;
																					IL_07e3:
																					if (14 > b)
																					{
																					}
																					goto end_IL_02b5;
																					IL_07f0:
																					if (13 <= b)
																					{
																						goto IL_07fb;
																					}
																					goto IL_0814;
																					IL_07fb:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto IL_084d;
																					IL_0814:
																					if (12 < b)
																					{
																						goto end_IL_02b5;
																					}
																					goto IL_081f;
																					IL_081f:
																					if (12 > b)
																					{
																						goto end_IL_02b5;
																					}
																					goto IL_082a;
																				}
																				break;
																			}
																			goto IL_02f0;
																			IL_0647:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0687;
																			IL_02f0:
																			if (7 > b)
																			{
																				goto IL_0340;
																			}
																			goto IL_0647;
																			IL_0340:
																			if (3 >= b)
																			{
																				goto IL_034b;
																			}
																			num = 74;
																			goto IL_0513;
																			IL_034b:
																			if (3 <= b)
																			{
																				goto IL_03d0;
																			}
																			goto IL_0443;
																			IL_0443:
																			if (1 < b)
																			{
																				goto IL_044e;
																			}
																			goto IL_04b4;
																			IL_044e:
																			if (2 < b)
																			{
																				goto end_IL_02b5;
																			}
																			goto IL_045c;
																			IL_045c:
																			if (2 > b)
																			{
																				goto end_IL_02b5;
																			}
																			goto IL_046a;
																			IL_046a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0493;
																			IL_0493:
																			ptr2 += 8;
																			goto IL_04a1;
																			IL_04a1:
																			num5--;
																			goto IL_084d;
																			IL_04b4:
																			if (1 > b)
																			{
																				goto end_IL_02b5;
																			}
																			goto IL_04c2;
																			IL_04c2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_04db;
																			IL_04db:
																			array[num5] = 0;
																			goto IL_04e9;
																			IL_04e9:
																			num5++;
																			num = 122;
																			goto IL_0500;
																			IL_0500:
																			ptr2 += 8;
																			goto IL_084d;
																			IL_03d0:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			num = 89;
																			goto IL_084d;
																			IL_0687:
																			array[num5 - 2] = 0;
																			goto IL_069b;
																			IL_0513:
																			if (5 < b)
																			{
																				goto IL_0521;
																			}
																			goto IL_05ad;
																			IL_0521:
																			if (6 < b)
																			{
																				goto end_IL_02b5;
																			}
																			goto IL_052f;
																			IL_052f:
																			if (6 > b)
																			{
																				goto end_IL_02b5;
																			}
																			goto IL_053d;
																			IL_053d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 128;
																			goto IL_0586;
																			IL_0586:
																			array[num5 - 2] = 0;
																			goto IL_059a;
																			IL_059a:
																			num5--;
																			goto IL_084d;
																			IL_05ad:
																			if (5 > b)
																			{
																				goto IL_05b8;
																			}
																			goto IL_05e2;
																			IL_05b8:
																			if (4 < b)
																			{
																				goto end_IL_02b5;
																			}
																			goto IL_05c6;
																			IL_05c6:
																			if (4 > b)
																			{
																				num = 9;
																				goto end_IL_02b5;
																			}
																			goto IL_084d;
																			IL_069b:
																			num5--;
																			goto IL_084d;
																			IL_05e2:
																			array[num5] = 0;
																			goto IL_05f0;
																			IL_05f0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0613;
																			IL_0613:
																			array2[num5] = null;
																			goto IL_061d;
																			IL_061d:
																			num5++;
																			goto IL_062b;
																			IL_062b:
																			ptr2 += 8;
																			num = 117;
																			goto IL_084d;
																		}
																		goto end_IL_02c5;
																		continue;
																		end_IL_02b5:
																		break;
																		IL_02b5:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto IL_084d;
																continue;
																end_IL_02c5:
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												goto IL_08e5;
												IL_08e5:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_08ca:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 1;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 91;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddAccessgetIsSecurityCritical.FreeHStringLockAssemblyPath);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 115;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_02a8:
															byte b = *ptr2;
															while (true)
															{
																IL_0298:
																ptr2++;
																while (true)
																{
																	IL_0288:
																	if (b >= 1)
																	{
																		while (b <= 12)
																		{
																			while (true)
																			{
																				IL_0268:
																				if (6 >= b)
																				{
																					while (6 > b)
																					{
																						while (true)
																						{
																							IL_0248:
																							if (3 < b)
																							{
																								goto IL_03d3;
																							}
																							while (true)
																							{
																								IL_0238:
																								if (3 > b)
																								{
																									while (true)
																									{
																										IL_0228:
																										if (1 >= b)
																										{
																											num = 126;
																											while (true)
																											{
																												if (num != 126)
																												{
																													if (num != 1107)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 80:
																														goto IL_0228;
																													case 109:
																														goto IL_0238;
																													case 18:
																														goto IL_0248;
																													case 85:
																														goto end_IL_0248;
																													case 29:
																														goto IL_0268;
																													case 100:
																														goto IL_0278;
																													case 114:
																														goto IL_0288;
																													case 45:
																														goto IL_0298;
																													case 3:
																													case 39:
																														goto IL_02a8;
																													case 77:
																														goto IL_02b3;
																													case 13:
																														goto IL_02c1;
																													case 24:
																													case 48:
																														goto IL_02cf;
																													case 81:
																														goto IL_033d;
																													case 5:
																													case 89:
																														goto IL_0363;
																													case 23:
																														goto IL_03ac;
																													case 106:
																														goto IL_03c0;
																													case 21:
																														goto IL_03d3;
																													case 34:
																														goto IL_03de;
																													case 112:
																														goto end_IL_0215;
																													case 57:
																													case 65:
																														goto IL_03fa;
																													case 111:
																														goto IL_0412;
																													case 49:
																													case 117:
																														goto IL_0420;
																													case 43:
																														goto IL_0449;
																													case 36:
																														goto IL_0457;
																													case 38:
																														goto IL_046a;
																													case 52:
																														goto IL_0478;
																													case 98:
																													case 119:
																														goto IL_0486;
																													case 4:
																													case 59:
																														goto IL_0491;
																													case 64:
																														goto IL_049f;
																													case 6:
																													case 74:
																														goto IL_04ad;
																													case 83:
																														goto IL_04c6;
																													case 108:
																														goto IL_04d4;
																													case 30:
																														goto IL_04e2;
																													case 90:
																														goto IL_04f5;
																													case 79:
																													case 96:
																														goto IL_0503;
																													case 60:
																														goto IL_0511;
																													case 116:
																														goto IL_0534;
																													case 7:
																														goto IL_053e;
																													case 42:
																														goto IL_0555;
																													case 33:
																													case 63:
																														goto IL_0568;
																													case 40:
																														goto IL_05a8;
																													case 67:
																														goto IL_05bc;
																													case 78:
																														goto IL_05cf;
																													case 32:
																														goto IL_05da;
																													case 69:
																														goto IL_05e8;
																													case 28:
																													case 31:
																														goto IL_05f3;
																													case 54:
																														goto IL_0626;
																													case 51:
																														goto IL_0631;
																													case 71:
																														goto IL_063c;
																													case 26:
																													case 72:
																														goto IL_0647;
																													case 82:
																														goto IL_065b;
																													case 107:
																														goto IL_069a;
																													case 66:
																													case 110:
																														goto IL_06aa;
																													case 2:
																													case 8:
																													case 11:
																													case 14:
																													case 15:
																													case 35:
																													case 50:
																													case 53:
																													case 56:
																													case 58:
																													case 61:
																													case 68:
																													case 84:
																													case 92:
																													case 94:
																													case 95:
																													case 99:
																													case 101:
																													case 102:
																													case 104:
																													case 105:
																													case 118:
																														goto end_IL_0278;
																													case 20:
																														goto IL_06dd;
																													case 113:
																														goto IL_06eb;
																													case 103:
																														goto IL_06f9;
																													case 10:
																													case 19:
																													case 22:
																													case 27:
																													case 41:
																													case 46:
																													case 47:
																													case 55:
																													case 62:
																													case 70:
																													case 75:
																													case 86:
																													case 93:
																													case 97:
																													case 115:
																														goto end_IL_0258;
																													case 25:
																														goto end_IL_0707;
																													case 37:
																														goto end_IL_071a;
																													case 76:
																														goto end_IL_072d;
																													case 44:
																														goto end_IL_0738;
																													case 12:
																														goto end_IL_074d;
																													case 9:
																													case 88:
																														goto end_IL_0762;
																													case 17:
																														goto end_IL_0772;
																													case 87:
																													case 91:
																														goto end_IL_0782;
																													case 0:
																														goto end_IL_0792;
																													case 1:
																														goto end_IL_07a2;
																													case 16:
																													case 73:
																														goto IL_07c6;
																													}
																													continue;
																												}
																												if (1 <= b)
																												{
																												}
																												goto end_IL_0278;
																												continue;
																												end_IL_0215:
																												break;
																											}
																											break;
																										}
																										goto IL_02b3;
																										IL_02cf:
																										ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_033d;
																										IL_033d:
																										num5 -= 2;
																										goto end_IL_0258;
																										IL_02b3:
																										if (2 < b)
																										{
																											goto end_IL_0278;
																										}
																										goto IL_02c1;
																										IL_02c1:
																										if (2 > b)
																										{
																											goto end_IL_0278;
																										}
																										goto IL_02cf;
																									}
																									break;
																								}
																								goto IL_0363;
																								IL_03c0:
																								num5--;
																								goto end_IL_0258;
																								IL_0363:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 23;
																								goto IL_03ac;
																								IL_03ac:
																								array[num5 - 2] = 0;
																								goto IL_03c0;
																							}
																							goto IL_03ec;
																							IL_0457:
																							num5--;
																							goto end_IL_0258;
																							IL_03d3:
																							if (4 < b)
																							{
																								goto IL_03de;
																							}
																							goto IL_0412;
																							IL_03de:
																							if (5 < b)
																							{
																								goto end_IL_0278;
																							}
																							goto IL_03ec;
																							IL_03ec:
																							if (5 > b)
																							{
																								goto end_IL_0278;
																							}
																							goto IL_03fa;
																							IL_03fa:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_0258;
																							IL_0412:
																							if (4 > b)
																							{
																								goto end_IL_0278;
																							}
																							goto IL_0420;
																							IL_0420:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0449;
																							IL_0449:
																							ptr2 += 8;
																							goto IL_0457;
																							continue;
																							end_IL_0248:
																							break;
																						}
																						continue;
																						end_IL_0258:
																						break;
																					}
																					break;
																				}
																				goto IL_046a;
																				IL_065b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)NonSerializedAttributeGetServerTypeForUri[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				goto IL_069a;
																				IL_046a:
																				if (9 >= b)
																				{
																					goto IL_0478;
																				}
																				goto IL_05cf;
																				IL_0478:
																				if (9 > b)
																				{
																					goto IL_0486;
																				}
																				goto IL_0568;
																				IL_0486:
																				if (7 < b)
																				{
																					goto IL_0491;
																				}
																				goto IL_04f5;
																				IL_0491:
																				if (8 < b)
																				{
																					goto end_IL_0278;
																				}
																				goto IL_049f;
																				IL_049f:
																				if (8 > b)
																				{
																					goto end_IL_0278;
																				}
																				goto IL_04ad;
																				IL_04ad:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_04c6;
																				IL_04c6:
																				array[num5] = 0;
																				goto IL_04d4;
																				IL_04d4:
																				num5++;
																				goto IL_04e2;
																				IL_04e2:
																				ptr2 += 8;
																				break;
																				IL_04f5:
																				if (7 > b)
																				{
																					goto end_IL_0278;
																				}
																				goto IL_0503;
																				IL_0503:
																				array[num5] = 0;
																				goto IL_0511;
																				IL_0511:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0534;
																				IL_0534:
																				array2[num5] = null;
																				goto IL_053e;
																				IL_053e:
																				num5++;
																				num = 42;
																				goto IL_0555;
																				IL_0555:
																				ptr2 += 8;
																				break;
																				IL_0568:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05a8;
																				IL_05a8:
																				array[num5 - 2] = 0;
																				goto IL_05bc;
																				IL_05bc:
																				num5--;
																				break;
																				IL_05cf:
																				if (11 < b)
																				{
																					goto IL_05da;
																				}
																				num = 54;
																				goto IL_0626;
																				IL_05da:
																				if (12 < b)
																				{
																					goto end_IL_0278;
																				}
																				goto IL_05e8;
																				IL_05e8:
																				if (12 > b)
																				{
																					num = 50;
																					goto end_IL_0278;
																				}
																				goto IL_05f3;
																				IL_05f3:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_06aa:
																				num5--;
																				break;
																				IL_069a:
																				ptr2 += 8;
																				break;
																				IL_0626:
																				if (11 > b)
																				{
																					goto IL_0631;
																				}
																				goto IL_06aa;
																				IL_0631:
																				if (10 < b)
																				{
																					goto end_IL_0278;
																				}
																				goto IL_063c;
																				IL_063c:
																				if (10 > b)
																				{
																					goto end_IL_0278;
																				}
																				goto IL_0647;
																				IL_0647:
																				array[num5 - 1] = 0;
																				goto IL_065b;
																			}
																			goto end_IL_0288;
																			continue;
																			end_IL_0278:
																			break;
																			IL_0278:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_06dd;
																	IL_06f9:
																	ptr2 += 8;
																	break;
																	IL_06eb:
																	num5++;
																	goto IL_06f9;
																	IL_06dd:
																	array[num5] = 0;
																	goto IL_06eb;
																	continue;
																	end_IL_0288:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_07c6;
													IL_07c6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0707:
													break;
												}
												continue;
												end_IL_071a:
												break;
											}
											continue;
											end_IL_072d:
											break;
										}
										continue;
										end_IL_0738:
										break;
									}
									continue;
									end_IL_074d:
									break;
								}
								continue;
								end_IL_0762:
								break;
							}
							continue;
							end_IL_0772:
							break;
						}
						continue;
						end_IL_0782:
						break;
					}
					continue;
					end_IL_0792:
					break;
				}
				continue;
				end_IL_07a2:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 122;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SEPLocalTimeMarkCryptoKeySecurity.EvidenceTypeGeneratedDeny);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 72;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 147;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 7;
																while (true)
																{
																	IL_0353:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_0336:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_0326:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_0316:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_0309:
																										if (10 < b)
																										{
																											while (11 >= b)
																											{
																												while (11 <= b)
																												{
																													while (true)
																													{
																														IL_029a:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																														num = 158;
																														while (true)
																														{
																															if (num != 158)
																															{
																																if (num != 1139)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 109:
																																case 137:
																																	goto IL_029a;
																																case 99:
																																	goto IL_02e9;
																																case 91:
																																case 112:
																																	goto IL_02f9;
																																case 55:
																																case 79:
																																	goto IL_0309;
																																case 35:
																																	goto IL_0316;
																																case 74:
																																	goto IL_0326;
																																case 59:
																																	goto IL_0336;
																																case 54:
																																	goto IL_0343;
																																case 7:
																																	goto IL_0353;
																																case 66:
																																	goto end_IL_0353;
																																case 147:
																																	goto end_IL_0363;
																																case 133:
																																	goto end_IL_037c;
																																case 76:
																																	goto IL_0392;
																																case 46:
																																case 90:
																																	goto IL_039d;
																																case 27:
																																	goto IL_03ab;
																																case 140:
																																	goto IL_03be;
																																case 19:
																																case 89:
																																	goto IL_03cc;
																																case 13:
																																case 145:
																																	goto IL_03ed;
																																case 105:
																																	goto IL_03fb;
																																case 78:
																																	goto IL_041e;
																																case 42:
																																	goto IL_0428;
																																case 67:
																																	goto IL_043f;
																																case 149:
																																	goto IL_0452;
																																case 58:
																																case 120:
																																	goto IL_0460;
																																case 36:
																																case 53:
																																	goto IL_046b;
																																case 87:
																																	goto IL_0479;
																																case 41:
																																case 119:
																																	goto IL_0487;
																																case 138:
																																	goto IL_04b0;
																																case 110:
																																	goto IL_04c7;
																																case 73:
																																	goto IL_04da;
																																case 45:
																																case 65:
																																	goto IL_04e5;
																																case 125:
																																	goto IL_04f3;
																																case 6:
																																case 80:
																																	goto IL_0501;
																																case 98:
																																	goto IL_050f;
																																case 20:
																																	goto IL_0527;
																																case 113:
																																	goto IL_0535;
																																case 71:
																																case 129:
																																	goto IL_0548;
																																case 95:
																																	goto IL_0590;
																																case 144:
																																	goto IL_05a3;
																																case 52:
																																case 97:
																																	goto IL_05b1;
																																case 64:
																																case 93:
																																	goto IL_05bc;
																																case 100:
																																	goto IL_05ca;
																																case 106:
																																case 146:
																																	goto IL_05d8;
																																case 103:
																																	goto IL_0601;
																																case 10:
																																	goto IL_061a;
																																case 0:
																																case 14:
																																	goto IL_0625;
																																case 32:
																																	goto IL_0633;
																																case 81:
																																case 107:
																																	goto IL_0641;
																																case 5:
																																	goto IL_0663;
																																case 128:
																																	goto IL_0671;
																																case 116:
																																	goto IL_0688;
																																case 38:
																																case 126:
																																	goto IL_069b;
																																case 68:
																																	goto IL_06db;
																																case 50:
																																	goto IL_06ef;
																																case 34:
																																case 61:
																																	goto IL_0702;
																																case 56:
																																	goto IL_0720;
																																case 43:
																																	goto IL_072e;
																																case 8:
																																	goto IL_0755;
																																case 3:
																																case 21:
																																	goto IL_0768;
																																case 94:
																																	goto IL_07a8;
																																case 142:
																																	goto IL_07bc;
																																case 69:
																																	goto IL_07cf;
																																case 108:
																																	goto IL_07dd;
																																case 131:
																																case 141:
																																	goto IL_07eb;
																																case 18:
																																	goto IL_07f9;
																																case 25:
																																case 151:
																																	goto IL_0807;
																																case 86:
																																	goto IL_0869;
																																case 24:
																																case 30:
																																	goto IL_0879;
																																case 12:
																																	goto IL_0892;
																																case 39:
																																	goto IL_089d;
																																case 1:
																																case 2:
																																case 4:
																																case 16:
																																case 22:
																																case 23:
																																case 26:
																																case 28:
																																case 29:
																																case 37:
																																case 47:
																																case 60:
																																case 63:
																																case 70:
																																case 75:
																																case 77:
																																case 82:
																																case 88:
																																case 92:
																																case 101:
																																case 102:
																																case 114:
																																case 124:
																																case 130:
																																case 134:
																																case 135:
																																case 139:
																																case 148:
																																	goto end_IL_0287;
																																case 9:
																																case 11:
																																case 15:
																																case 17:
																																case 33:
																																case 40:
																																case 48:
																																case 49:
																																case 57:
																																case 72:
																																case 83:
																																case 96:
																																case 115:
																																case 118:
																																case 123:
																																case 127:
																																case 143:
																																case 150:
																																	goto end_IL_0387;
																																case 85:
																																	goto end_IL_08c4;
																																case 84:
																																	goto end_IL_08d7;
																																case 132:
																																	goto end_IL_08ea;
																																case 51:
																																	goto end_IL_08f5;
																																case 31:
																																case 111:
																																	goto end_IL_0905;
																																case 117:
																																	goto end_IL_0915;
																																case 44:
																																case 104:
																																	goto end_IL_0925;
																																case 121:
																																	goto end_IL_0935;
																																case 122:
																																	goto end_IL_0945;
																																case 62:
																																case 136:
																																	goto IL_0960;
																																}
																																continue;
																															}
																															array[num5 - 2] = 0;
																															goto IL_0755;
																															IL_0755:
																															num5--;
																															goto end_IL_0387;
																															continue;
																															end_IL_0287:
																															break;
																														}
																														break;
																													}
																													break;
																													IL_02e9:;
																												}
																												break;
																												IL_02f9:;
																											}
																											break;
																										}
																										goto IL_0392;
																										IL_043f:
																										ptr2 += 8;
																										goto end_IL_0387;
																										IL_0392:
																										if (10 > b)
																										{
																											goto IL_039d;
																										}
																										goto IL_03ed;
																										IL_039d:
																										if (9 < b)
																										{
																											break;
																										}
																										goto IL_03ab;
																										IL_03ab:
																										if (9 > b)
																										{
																											break;
																										}
																										goto end_IL_0387;
																										IL_03ed:
																										array[num5] = 0;
																										goto IL_03fb;
																										IL_03fb:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_041e;
																										IL_041e:
																										array2[num5] = null;
																										goto IL_0428;
																										IL_0428:
																										num5++;
																										num = 67;
																										goto IL_043f;
																									}
																									break;
																								}
																								goto IL_0768;
																								IL_07bc:
																								num5--;
																								goto end_IL_0387;
																								IL_0768:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_07a8;
																								IL_07a8:
																								array[num5 - 2] = 0;
																								goto IL_07bc;
																							}
																							break;
																						}
																						goto IL_07cf;
																						IL_089d:
																						if (15 <= b)
																						{
																						}
																						break;
																						IL_07cf:
																						if (14 >= b)
																						{
																							goto IL_07dd;
																						}
																						goto IL_0892;
																						IL_07dd:
																						if (14 > b)
																						{
																							goto IL_07eb;
																						}
																						goto IL_0879;
																						IL_07eb:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_07f9;
																						IL_07f9:
																						if (13 > b)
																						{
																							break;
																						}
																						goto IL_0807;
																						IL_0807:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0869;
																						IL_0869:
																						num5 -= 2;
																						goto end_IL_0387;
																						IL_0879:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0387;
																						IL_0892:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_089d;
																					}
																					break;
																				}
																				goto IL_03be;
																				IL_072e:
																				num5--;
																				goto end_IL_0387;
																				IL_03be:
																				if (8 <= b)
																				{
																					goto IL_03cc;
																				}
																				goto IL_0452;
																				IL_03cc:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 83;
																				goto end_IL_0387;
																				IL_0452:
																				if (4 < b)
																				{
																					goto IL_0460;
																				}
																				goto IL_05a3;
																				IL_0460:
																				if (6 < b)
																				{
																					goto IL_046b;
																				}
																				goto IL_04da;
																				IL_046b:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0479;
																				IL_0479:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0487;
																				IL_0487:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04b0;
																				IL_04b0:
																				ptr2 += 8;
																				num = 110;
																				goto IL_04c7;
																				IL_04c7:
																				num5--;
																				goto end_IL_0387;
																				IL_04da:
																				if (6 > b)
																				{
																					goto IL_04e5;
																				}
																				goto IL_0548;
																				IL_04e5:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_04f3;
																				IL_04f3:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0501;
																				IL_0501:
																				array[num5] = 5;
																				goto IL_050f;
																				IL_050f:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_0527;
																				IL_0527:
																				num5++;
																				goto IL_0535;
																				IL_0535:
																				ptr2 += 8;
																				goto end_IL_0387;
																				IL_0548:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				num = 95;
																				goto IL_0590;
																				IL_0590:
																				num5 -= 3;
																				goto end_IL_0387;
																				IL_05a3:
																				if (4 > b)
																				{
																					goto IL_05b1;
																				}
																				goto IL_0702;
																				IL_05b1:
																				if (2 < b)
																				{
																					goto IL_05bc;
																				}
																				goto IL_061a;
																				IL_05bc:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_05ca;
																				IL_05ca:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_05d8;
																				IL_05d8:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0601;
																				IL_0601:
																				array[num5 - 1] = 5;
																				goto end_IL_0387;
																				IL_061a:
																				if (2 > b)
																				{
																					goto IL_0625;
																				}
																				goto IL_069b;
																				IL_0625:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0633;
																				IL_0633:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0641;
																				IL_0641:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				num = 5;
																				goto IL_0663;
																				IL_0663:
																				array[num5] = 0;
																				goto IL_0671;
																				IL_0671:
																				num5++;
																				num = 116;
																				goto IL_0688;
																				IL_0688:
																				ptr2 += 8;
																				goto end_IL_0387;
																				IL_069b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06db;
																				IL_06db:
																				array[num5 - 2] = 0;
																				goto IL_06ef;
																				IL_06ef:
																				num5--;
																				goto end_IL_0387;
																				IL_0702:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_0720;
																				IL_0720:
																				ptr2 += 8;
																				goto IL_072e;
																			}
																			break;
																			IL_0343:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 143;
																	goto end_IL_0387;
																	continue;
																	end_IL_0353:
																	break;
																}
																continue;
																end_IL_0363:
																break;
															}
															continue;
															end_IL_037c:
															break;
														}
														continue;
														end_IL_0387:
														break;
													}
													continue;
												}
												goto IL_0960;
												IL_0960:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c4:
												break;
											}
											continue;
											end_IL_08d7:
											break;
										}
										continue;
										end_IL_08ea:
										break;
									}
									continue;
									end_IL_08f5:
									break;
								}
								continue;
								end_IL_0905:
								break;
							}
							continue;
							end_IL_0915:
							break;
						}
						continue;
						end_IL_0925:
						break;
					}
					continue;
					end_IL_0935:
					break;
				}
				continue;
				end_IL_0945:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 102;
		int num4 = default(int);
		byte b = default(byte);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 61;
						while (true)
						{
							int[] array3 = new int[4];
							num = 6;
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref stackStoreOperationSetCanonicalizationContext.CancellationTokenRegistrationReserveProcessor);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_01f7:
														num = 118;
														while (true)
														{
															if (num != 118)
															{
																if (num != 1099)
																{
																	break;
																}
																switch (num)
																{
																case 72:
																	goto IL_01f7;
																case 13:
																	goto IL_020b;
																case 32:
																	goto IL_0222;
																case 97:
																	goto IL_0230;
																case 64:
																	goto IL_023e;
																case 31:
																case 42:
																	goto IL_024c;
																case 33:
																case 85:
																	goto IL_0257;
																case 41:
																	goto IL_0262;
																case 1:
																case 83:
																	goto IL_0270;
																case 35:
																case 58:
																	goto IL_028c;
																case 78:
																	goto IL_029a;
																case 107:
																	goto IL_02ad;
																case 34:
																case 44:
																	goto IL_02bb;
																case 29:
																	goto IL_02c6;
																case 81:
																	goto IL_02d4;
																case 63:
																case 106:
																	goto IL_02e2;
																case 47:
																	goto IL_0305;
																case 60:
																	goto IL_0313;
																case 54:
																	goto IL_0321;
																case 74:
																	goto IL_033d;
																case 49:
																case 86:
																	goto IL_034b;
																case 68:
																	goto IL_038b;
																case 0:
																	goto IL_039f;
																case 39:
																case 46:
																	goto IL_03b2;
																case 56:
																	goto IL_0414;
																case 110:
																	goto IL_0427;
																case 9:
																case 77:
																	goto IL_0432;
																case 18:
																	goto IL_0472;
																case 53:
																	goto IL_0486;
																case 70:
																	goto IL_0499;
																case 38:
																case 98:
																	goto IL_04a7;
																case 37:
																	goto IL_04b2;
																case 23:
																	goto IL_04c5;
																case 108:
																	goto IL_04d3;
																case 7:
																case 95:
																	goto IL_04e1;
																case 82:
																	goto IL_04ef;
																case 67:
																	goto IL_0512;
																case 80:
																	goto IL_051c;
																case 28:
																	goto IL_052a;
																case 17:
																	goto IL_053d;
																case 59:
																case 88:
																	goto IL_0548;
																case 40:
																	goto IL_0560;
																case 48:
																	goto IL_056b;
																case 12:
																case 57:
																	goto IL_0579;
																case 91:
																	goto IL_0592;
																case 27:
																	goto IL_05a0;
																case 10:
																	goto IL_05ae;
																case 30:
																	goto IL_05be;
																case 92:
																	goto IL_05c9;
																case 8:
																case 96:
																	goto IL_05d4;
																case 65:
																	goto IL_05fd;
																case 52:
																	goto IL_060b;
																case 5:
																case 15:
																case 19:
																case 20:
																case 26:
																case 36:
																case 43:
																case 45:
																case 50:
																case 51:
																case 55:
																case 66:
																case 75:
																case 76:
																case 84:
																case 93:
																case 94:
																case 105:
																case 111:
																	goto IL_061b;
																case 4:
																case 11:
																case 14:
																case 21:
																case 62:
																case 69:
																case 71:
																case 73:
																case 79:
																case 89:
																case 99:
																case 100:
																case 104:
																case 109:
																	goto end_IL_01e7;
																case 25:
																	goto end_IL_062e;
																case 90:
																	goto end_IL_0641;
																case 16:
																	goto end_IL_064b;
																case 6:
																	goto end_IL_0656;
																case 24:
																case 61:
																	goto end_IL_066b;
																case 87:
																	goto end_IL_067b;
																case 3:
																case 22:
																	goto end_IL_0694;
																case 101:
																	goto end_IL_06ad;
																case 102:
																	goto end_IL_06bd;
																case 2:
																case 103:
																	goto IL_06d8;
																}
																continue;
															}
															b = *ptr2;
															goto IL_020b;
															IL_05fd:
															ptr2 += 8;
															goto IL_060b;
															IL_061b:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															IL_060b:
															num5--;
															break;
															IL_020b:
															ptr2++;
															num = 32;
															goto IL_0222;
															IL_0222:
															if (b >= 1)
															{
																goto IL_0230;
															}
															goto IL_061b;
															IL_0230:
															if (b <= 11)
															{
																goto IL_023e;
															}
															goto IL_061b;
															IL_023e:
															if (6 < b)
															{
																goto IL_024c;
															}
															goto IL_0427;
															IL_024c:
															if (9 < b)
															{
																goto IL_0257;
															}
															goto IL_02ad;
															IL_0257:
															if (10 >= b)
															{
																goto IL_0262;
															}
															goto IL_028c;
															IL_0262:
															if (10 <= b)
															{
																goto IL_0270;
															}
															goto IL_061b;
															IL_0270:
															byte* num6 = ptr2;
															num4 = 1;
															ptr2 = num6 + -200;
															break;
															IL_028c:
															if (11 >= b)
															{
																goto IL_029a;
															}
															goto IL_061b;
															IL_029a:
															if (11 <= b)
															{
															}
															goto IL_061b;
															IL_02ad:
															if (9 > b)
															{
																goto IL_02bb;
															}
															goto IL_03b2;
															IL_02bb:
															if (7 < b)
															{
																goto IL_02c6;
															}
															goto IL_033d;
															IL_02c6:
															if (8 >= b)
															{
																goto IL_02d4;
															}
															goto IL_061b;
															IL_02d4:
															if (8 <= b)
															{
																goto IL_02e2;
															}
															goto IL_061b;
															IL_02e2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_0305;
															IL_0305:
															array[num5] = 0;
															goto IL_0313;
															IL_0313:
															num5++;
															goto IL_0321;
															IL_0321:
															ptr2 += 8;
															num = 104;
															break;
															IL_033d:
															if (7 <= b)
															{
																goto IL_034b;
															}
															goto IL_061b;
															IL_034b:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_038b;
															IL_038b:
															array[num5 - 2] = 0;
															goto IL_039f;
															IL_039f:
															num5--;
															break;
															IL_03b2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0414;
															IL_0414:
															num5 -= 2;
															break;
															IL_0427:
															if (6 <= b)
															{
																goto IL_0432;
															}
															goto IL_0499;
															IL_0432:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_0472;
															IL_0472:
															array[num5 - 2] = 0;
															goto IL_0486;
															IL_0486:
															num5--;
															break;
															IL_0499:
															if (3 < b)
															{
																goto IL_04a7;
															}
															goto IL_053d;
															IL_04a7:
															if (4 >= b)
															{
																goto IL_04b2;
															}
															goto IL_04c5;
															IL_04b2:
															if (4 <= b)
															{
																break;
															}
															goto IL_061b;
															IL_04c5:
															if (5 >= b)
															{
																goto IL_04d3;
															}
															goto IL_061b;
															IL_04d3:
															if (5 <= b)
															{
																goto IL_04e1;
															}
															goto IL_061b;
															IL_04e1:
															array[num5] = 0;
															goto IL_04ef;
															IL_04ef:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
															goto IL_0512;
															IL_0512:
															array2[num5] = null;
															goto IL_051c;
															IL_051c:
															num5++;
															goto IL_052a;
															IL_052a:
															ptr2 += 8;
															break;
															IL_053d:
															if (3 <= b)
															{
																goto IL_0548;
															}
															goto IL_0560;
															IL_0548:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															break;
															IL_0560:
															if (1 >= b)
															{
																goto IL_056b;
															}
															goto IL_05be;
															IL_056b:
															if (1 <= b)
															{
																goto IL_0579;
															}
															goto IL_061b;
															IL_0579:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															goto IL_0592;
															IL_0592:
															array[num5] = 0;
															goto IL_05a0;
															IL_05a0:
															num5++;
															goto IL_05ae;
															IL_05ae:
															ptr2 += 8;
															break;
															IL_05be:
															if (2 >= b)
															{
																goto IL_05c9;
															}
															goto IL_061b;
															IL_05c9:
															if (2 <= b)
															{
																goto IL_05d4;
															}
															goto IL_061b;
															IL_05d4:
															ref int reference = ref array3[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
															goto IL_05fd;
															continue;
															end_IL_01e7:
															break;
														}
														break;
													}
													continue;
												}
												goto IL_06d8;
												IL_06d8:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_062e:
												break;
											}
											continue;
											end_IL_0641:
											break;
										}
										continue;
										end_IL_064b:
										break;
									}
									continue;
									end_IL_0656:
									break;
								}
								continue;
								end_IL_066b:
								break;
							}
							continue;
							end_IL_067b:
							break;
						}
						continue;
						end_IL_0694:
						break;
					}
					continue;
					end_IL_06ad:
					break;
				}
				continue;
				end_IL_06bd:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 19;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 18;
			while (true)
			{
				int num3 = num2 * 4;
				num = 107;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EGetPathRoot.getForegroundColorGenericAce);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0355:
																if (b >= 1)
																{
																	while (b <= 14)
																	{
																		while (true)
																		{
																			IL_0335:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_0325:
																					if (11 >= b)
																					{
																						while (true)
																						{
																							IL_0315:
																							if (11 > b)
																							{
																								while (true)
																								{
																									IL_0308:
																									if (9 < b)
																									{
																										while (10 >= b)
																										{
																											while (10 <= b)
																											{
																												while (true)
																												{
																													IL_029d:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 14;
																													while (true)
																													{
																														IL_027e:
																														array[num5 - 2] = 0;
																														num = 151;
																														while (true)
																														{
																															if (num != 151)
																															{
																																if (num != 1132)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 14:
																																	goto IL_027e;
																																case 62:
																																case 108:
																																	goto IL_029d;
																																case 4:
																																	goto IL_02e8;
																																case 33:
																																case 127:
																																	goto IL_02f8;
																																case 82:
																																	goto IL_0308;
																																case 81:
																																	goto IL_0315;
																																case 78:
																																case 116:
																																	goto IL_0325;
																																case 70:
																																	goto IL_0335;
																																case 96:
																																	goto IL_0345;
																																case 100:
																																	goto IL_0355;
																																case 123:
																																	goto end_IL_0355;
																																case 26:
																																case 91:
																																	goto end_IL_0365;
																																case 30:
																																	goto IL_0380;
																																case 10:
																																case 56:
																																	goto IL_038b;
																																case 61:
																																	goto IL_0399;
																																case 50:
																																case 99:
																																	goto IL_03ac;
																																case 65:
																																	goto IL_040e;
																																case 105:
																																case 124:
																																	goto IL_042a;
																																case 111:
																																	goto IL_044d;
																																case 35:
																																	goto IL_045b;
																																case 3:
																																	goto IL_0469;
																																case 64:
																																case 86:
																																	goto IL_04a1;
																																case 16:
																																	goto IL_04b5;
																																case 94:
																																	goto IL_0509;
																																case 9:
																																	goto IL_0517;
																																case 103:
																																case 131:
																																	goto IL_0533;
																																case 45:
																																case 137:
																																	goto IL_053e;
																																case 87:
																																	goto IL_054c;
																																case 143:
																																	goto IL_055f;
																																case 134:
																																case 140:
																																	goto IL_056a;
																																case 69:
																																	goto IL_0586;
																																case 110:
																																	goto IL_0594;
																																case 58:
																																case 90:
																																	goto IL_05a2;
																																case 83:
																																	goto IL_05be;
																																case 36:
																																case 101:
																																	goto IL_05c9;
																																case 122:
																																	goto IL_0609;
																																case 40:
																																	goto IL_061d;
																																case 77:
																																case 112:
																																	goto IL_0639;
																																case 43:
																																	goto IL_0647;
																																case 22:
																																case 118:
																																	goto IL_0655;
																																case 24:
																																case 52:
																																	goto IL_0660;
																																case 13:
																																	goto IL_066e;
																																case 41:
																																case 80:
																																	goto IL_067c;
																																case 132:
																																	goto IL_06ae;
																																case 98:
																																	goto IL_06bc;
																																case 49:
																																	goto IL_06cf;
																																case 74:
																																case 75:
																																	goto end_IL_026b;
																																case 6:
																																	goto IL_06f6;
																																case 48:
																																	goto IL_0704;
																																case 115:
																																	goto IL_0712;
																																case 53:
																																case 133:
																																	goto IL_0725;
																																case 95:
																																case 136:
																																	goto IL_073d;
																																case 129:
																																	goto IL_074b;
																																case 27:
																																case 55:
																																	goto IL_0756;
																																case 102:
																																	goto IL_0764;
																																case 42:
																																case 138:
																																	goto IL_0777;
																																case 125:
																																	goto IL_0785;
																																case 104:
																																	goto IL_07b1;
																																case 54:
																																	goto IL_07bb;
																																case 37:
																																	goto IL_07c9;
																																case 44:
																																	goto IL_07dc;
																																case 32:
																																	goto IL_07e7;
																																case 126:
																																case 144:
																																	goto IL_07f2;
																																case 119:
																																	goto IL_083b;
																																case 12:
																																	goto IL_084f;
																																case 0:
																																case 1:
																																case 2:
																																case 8:
																																case 11:
																																case 15:
																																case 20:
																																case 31:
																																case 38:
																																case 47:
																																case 51:
																																case 57:
																																case 59:
																																case 60:
																																case 68:
																																case 71:
																																case 76:
																																case 85:
																																case 88:
																																case 89:
																																case 93:
																																case 106:
																																case 120:
																																case 128:
																																case 130:
																																case 135:
																																case 142:
																																	goto end_IL_02e8;
																																case 7:
																																case 17:
																																case 21:
																																case 25:
																																case 28:
																																case 34:
																																case 39:
																																case 46:
																																case 63:
																																case 66:
																																case 67:
																																case 97:
																																case 114:
																																case 117:
																																case 121:
																																case 139:
																																case 141:
																																	goto end_IL_0375;
																																case 73:
																																	goto end_IL_0872;
																																case 92:
																																	goto end_IL_0885;
																																case 79:
																																	goto end_IL_088f;
																																case 84:
																																	goto end_IL_089a;
																																case 29:
																																case 109:
																																	goto end_IL_08af;
																																case 5:
																																	goto end_IL_08bf;
																																case 23:
																																case 107:
																																	goto end_IL_08cf;
																																case 18:
																																	goto end_IL_08df;
																																case 19:
																																	goto end_IL_08ef;
																																case 72:
																																case 113:
																																	goto IL_091c;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_0375;
																															continue;
																															end_IL_026b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_06dd;
																												continue;
																												end_IL_02e8:
																												break;
																												IL_02e8:;
																											}
																											break;
																											IL_02f8:;
																										}
																										break;
																									}
																									goto IL_0380;
																									IL_040e:
																									num5 -= 2;
																									num = 117;
																									goto end_IL_0375;
																									IL_0380:
																									if (9 > b)
																									{
																										goto IL_038b;
																									}
																									goto IL_03ac;
																									IL_038b:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_0399;
																									IL_0399:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_042a;
																									IL_042a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_044d;
																									IL_044d:
																									array[num5] = 0;
																									goto IL_045b;
																									IL_045b:
																									num5++;
																									goto IL_0469;
																									IL_0469:
																									ptr2 += 8;
																									num = 39;
																									goto end_IL_0375;
																									IL_03ac:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_040e;
																								}
																								break;
																							}
																							num = 64;
																							goto IL_04a1;
																							IL_0509:
																							num5--;
																							goto IL_0517;
																							IL_0517:
																							ptr2 += 8;
																							goto end_IL_0375;
																							IL_04a1:
																							array[num5 - 2] = 0;
																							goto IL_04b5;
																							IL_04b5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)ServerObjectTerminatorSinkEphemerisCorrectionAlgorithmMap[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_0509;
																						}
																						break;
																					}
																					num = 103;
																					goto IL_0533;
																					IL_0594:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_05a2;
																					IL_05a2:
																					num5--;
																					num = 63;
																					goto end_IL_0375;
																					IL_0533:
																					if (13 < b)
																					{
																						goto IL_053e;
																					}
																					goto IL_055f;
																					IL_053e:
																					if (14 < b)
																					{
																						break;
																					}
																					goto IL_054c;
																					IL_054c:
																					if (14 <= b)
																					{
																					}
																					break;
																					IL_055f:
																					if (13 <= b)
																					{
																						goto IL_056a;
																					}
																					goto IL_0586;
																					IL_056a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0375;
																					IL_0586:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_0594;
																				}
																				break;
																			}
																			goto IL_05be;
																			IL_083b:
																			array[num5 - 2] = 0;
																			goto IL_084f;
																			IL_05be:
																			if (7 <= b)
																			{
																				goto IL_05c9;
																			}
																			num = 112;
																			goto IL_0639;
																			IL_05c9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0609;
																			IL_0609:
																			array[num5 - 2] = 0;
																			goto IL_061d;
																			IL_061d:
																			num5--;
																			goto end_IL_0375;
																			IL_084f:
																			num5--;
																			goto end_IL_0375;
																			IL_0639:
																			if (3 >= b)
																			{
																				goto IL_0647;
																			}
																			goto IL_073d;
																			IL_0647:
																			if (3 > b)
																			{
																				goto IL_0655;
																			}
																			goto IL_0725;
																			IL_0655:
																			if (1 < b)
																			{
																				goto IL_0660;
																			}
																			goto IL_06cf;
																			IL_0660:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_066e;
																			IL_066e:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_067c;
																			IL_067c:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 132;
																			goto IL_06ae;
																			IL_06ae:
																			ptr2 += 8;
																			goto IL_06bc;
																			IL_06bc:
																			num5--;
																			goto end_IL_0375;
																			IL_06cf:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_06dd;
																			IL_06dd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_06f6;
																			IL_06f6:
																			array[num5] = 0;
																			goto IL_0704;
																			IL_0704:
																			num5++;
																			goto IL_0712;
																			IL_0712:
																			ptr2 += 8;
																			goto end_IL_0375;
																			IL_0725:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0375;
																			IL_073d:
																			if (5 >= b)
																			{
																				goto IL_074b;
																			}
																			goto IL_07dc;
																			IL_074b:
																			if (5 > b)
																			{
																				goto IL_0756;
																			}
																			goto IL_0777;
																			IL_0756:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0764;
																			IL_0764:
																			if (4 <= b)
																			{
																				goto end_IL_0375;
																			}
																			break;
																			IL_0777:
																			array[num5] = 0;
																			goto IL_0785;
																			IL_0785:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			num = 104;
																			goto IL_07b1;
																			IL_07b1:
																			array2[num5] = null;
																			goto IL_07bb;
																			IL_07bb:
																			num5++;
																			goto IL_07c9;
																			IL_07c9:
																			ptr2 += 8;
																			goto end_IL_0375;
																			IL_07dc:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_07e7;
																			IL_07e7:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_07f2;
																			IL_07f2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 119;
																			goto IL_083b;
																		}
																		break;
																		IL_0345:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0375;
																continue;
																end_IL_0355:
																break;
															}
															continue;
															end_IL_0365:
															break;
														}
														continue;
														end_IL_0375:
														break;
													}
													continue;
												}
												goto IL_091c;
												IL_091c:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0872:
												break;
											}
											continue;
											end_IL_0885:
											break;
										}
										continue;
										end_IL_088f:
										break;
									}
									continue;
									end_IL_089a:
									break;
								}
								continue;
								end_IL_08af:
								break;
							}
							continue;
							end_IL_08bf:
							break;
						}
						continue;
						end_IL_08cf:
						break;
					}
					continue;
					end_IL_08df:
					break;
				}
				continue;
				end_IL_08ef:
				break;
			}
		}
	}

	static Class122()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 18;
					while (true)
					{
						if (num != 18)
						{
							if (num != 999)
							{
								break;
							}
							switch (num)
							{
							case 2:
							case 9:
							case 10:
							case 11:
								goto end_IL_0051;
							case 5:
								goto end_IL_005e;
							case 6:
								goto end_IL_0073;
							case 0:
							case 1:
							case 4:
							case 7:
							case 8:
								goto IL_0086;
							case 3:
								return;
							}
							continue;
						}
						goto IL_0086;
						IL_0086:
						string_0 = "RandomGadgetsGun";
						return;
						continue;
						end_IL_0051:
						break;
					}
					continue;
					end_IL_005e:
					break;
				}
				continue;
				end_IL_0073:
				break;
			}
		}
	}
}
