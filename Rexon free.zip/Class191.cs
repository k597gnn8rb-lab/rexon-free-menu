using System;
using System.Runtime.CompilerServices;
using HarmonyLib;

[HarmonyPatch(typeof(ControllerInputPoller), "LateUpdate")]
internal class Class191
{
	private static int int_0;

	private static bool bool_0;

	private static int int_1;

	private static bool bool_1;

	private static float float_0;

	private static float float_1;

	private static IntPtr[] getManifestFlagsValidKeySize;

	private static IntPtr[] setUserQuotaPublicKey;

	private unsafe static void Postfix(ControllerInputPoller __instance)
	{
		int num = 58;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = __instance;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ComposedOfAllPrivateMethodsContains.RequestingAssemblyCONSOLECURSORINFO);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_03f3:
																if (b >= 1)
																{
																	while (b <= 24)
																	{
																		while (true)
																		{
																			IL_03d3:
																			if (12 < b)
																			{
																				while (true)
																				{
																					IL_03c3:
																					if (18 >= b)
																					{
																						while (true)
																						{
																							IL_03b6:
																							if (18 <= b)
																							{
																								while (true)
																								{
																									IL_0393:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									num = 81;
																									while (true)
																									{
																										IL_0383:
																										array[num5] = 5;
																										while (true)
																										{
																											IL_036a:
																											num5++;
																											num = 210;
																											while (true)
																											{
																												if (num != 210)
																												{
																													if (num != 1191)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 12:
																														goto IL_036a;
																													case 81:
																														goto IL_0383;
																													case 78:
																													case 146:
																														goto IL_0393;
																													case 9:
																														goto IL_03b6;
																													case 103:
																														goto IL_03c3;
																													case 32:
																														goto IL_03d3;
																													case 16:
																														goto IL_03e3;
																													case 83:
																														goto IL_03f3;
																													case 28:
																														goto end_IL_03f3;
																													case 112:
																													case 199:
																														goto end_IL_0403;
																													case 41:
																														goto IL_041e;
																													case 99:
																														goto IL_0429;
																													case 116:
																														goto IL_0437;
																													case 74:
																														goto IL_0445;
																													case 132:
																														goto IL_0458;
																													case 44:
																														goto IL_0463;
																													case 167:
																														goto IL_0473;
																													case 152:
																													case 177:
																														goto IL_0486;
																													case 34:
																														goto IL_04e4;
																													case 180:
																														goto IL_04f7;
																													case 174:
																														goto IL_0505;
																													case 68:
																														goto IL_0513;
																													case 63:
																													case 65:
																														goto IL_051e;
																													case 178:
																														goto IL_0563;
																													case 148:
																														goto IL_0571;
																													case 143:
																														goto IL_057f;
																													case 47:
																														goto IL_058a;
																													case 87:
																													case 128:
																														goto IL_05a1;
																													case 172:
																														goto IL_05ba;
																													case 26:
																														goto IL_05c8;
																													case 129:
																														goto IL_05d6;
																													case 104:
																														goto IL_05e9;
																													case 35:
																														goto IL_05f7;
																													case 55:
																													case 115:
																														goto IL_0605;
																													case 73:
																														goto IL_064a;
																													case 22:
																														goto IL_0655;
																													case 134:
																														goto IL_0668;
																													case 179:
																														goto IL_067f;
																													case 20:
																													case 160:
																														goto IL_0696;
																													case 70:
																														goto IL_06d6;
																													case 40:
																														goto IL_06ea;
																													case 140:
																														goto IL_06fd;
																													case 107:
																														goto IL_070b;
																													case 98:
																														goto IL_0719;
																													case 156:
																														goto IL_0724;
																													case 133:
																													case 165:
																														goto IL_0732;
																													case 123:
																														goto IL_0772;
																													case 82:
																														goto IL_0786;
																													case 69:
																														goto IL_0799;
																													case 150:
																														goto IL_07a7;
																													case 24:
																													case 161:
																														goto IL_07b5;
																													case 119:
																														goto IL_07c8;
																													case 19:
																														goto IL_07d3;
																													case 170:
																														goto IL_07e6;
																													case 59:
																													case 182:
																														goto IL_0802;
																													case 118:
																														goto IL_0842;
																													case 84:
																														goto IL_0856;
																													case 184:
																														goto IL_0869;
																													case 62:
																													case 77:
																														goto IL_0877;
																													case 105:
																													case 185:
																														goto IL_089c;
																													case 114:
																														goto IL_08af;
																													case 89:
																														goto IL_08bd;
																													case 166:
																													case 188:
																														goto IL_08d0;
																													case 190:
																														goto IL_08e4;
																													case 151:
																														goto IL_0922;
																													case 38:
																													case 191:
																														goto IL_0935;
																													case 5:
																														goto IL_095e;
																													case 79:
																														goto IL_096c;
																													case 27:
																													case 192:
																														goto IL_097f;
																													case 157:
																														goto IL_09e1;
																													case 193:
																														goto IL_09f4;
																													case 86:
																														goto IL_0a08;
																													case 194:
																														goto IL_0a1b;
																													case 197:
																														goto IL_0a2f;
																													case 198:
																														goto IL_0a42;
																													case 120:
																													case 127:
																														goto IL_0a50;
																													case 45:
																														goto IL_0a64;
																													case 130:
																														goto IL_0ab8;
																													case 13:
																														goto IL_0ac6;
																													case 49:
																													case 200:
																														goto IL_0ad9;
																													case 1:
																														goto IL_0ae7;
																													case 100:
																														goto IL_0b0a;
																													case 14:
																														goto IL_0b14;
																													case 95:
																														goto IL_0b22;
																													case 202:
																														goto IL_0b3e;
																													case 80:
																														goto IL_0b4c;
																													case 147:
																													case 154:
																														goto IL_0b5a;
																													case 176:
																														goto IL_0b6e;
																													case 162:
																														goto IL_0ba6;
																													case 36:
																														goto IL_0bcc;
																													case 10:
																														goto IL_0bda;
																													case 18:
																														goto IL_0be8;
																													case 15:
																														goto IL_0bf3;
																													case 102:
																													case 171:
																														goto IL_0c01;
																													case 42:
																														goto IL_0c24;
																													case 97:
																														goto IL_0c32;
																													case 175:
																														goto IL_0c40;
																													case 155:
																														goto IL_0c53;
																													case 66:
																														goto IL_0c61;
																													case 67:
																													case 187:
																														goto IL_0c6f;
																													case 94:
																														goto IL_0c9d;
																													case 168:
																													case 169:
																														goto IL_0cb0;
																													case 31:
																														goto IL_0cde;
																													case 39:
																														goto IL_0cf1;
																													case 11:
																														goto IL_0cfc;
																													case 96:
																														goto IL_0d0a;
																													case 135:
																														goto IL_0d26;
																													case 159:
																													case 173:
																														goto IL_0d31;
																													case 71:
																														goto IL_0d68;
																													case 149:
																														goto IL_0d81;
																													case 106:
																														goto IL_0d8c;
																													case 29:
																													case 51:
																														goto IL_0d97;
																													case 142:
																														goto IL_0dc5;
																													case 3:
																													case 8:
																													case 17:
																													case 30:
																													case 37:
																													case 43:
																													case 48:
																													case 52:
																													case 61:
																													case 76:
																													case 88:
																													case 90:
																													case 91:
																													case 93:
																													case 108:
																													case 110:
																													case 113:
																													case 117:
																													case 121:
																													case 124:
																													case 138:
																													case 141:
																													case 158:
																													case 163:
																													case 196:
																													case 201:
																													case 203:
																														goto end_IL_0357;
																													case 0:
																													case 2:
																													case 6:
																													case 7:
																													case 21:
																													case 46:
																													case 50:
																													case 54:
																													case 56:
																													case 60:
																													case 72:
																													case 75:
																													case 92:
																													case 101:
																													case 109:
																													case 111:
																													case 125:
																													case 131:
																													case 137:
																													case 139:
																													case 145:
																													case 153:
																													case 181:
																													case 183:
																													case 186:
																													case 189:
																													case 195:
																														goto end_IL_0413;
																													case 33:
																														goto end_IL_0df1;
																													case 126:
																														goto end_IL_0e04;
																													case 53:
																														goto end_IL_0e0e;
																													case 25:
																														goto end_IL_0e19;
																													case 4:
																														goto end_IL_0e29;
																													case 136:
																													case 164:
																														goto end_IL_0e39;
																													case 144:
																														goto end_IL_0e49;
																													case 23:
																													case 122:
																														goto end_IL_0e59;
																													case 57:
																														goto end_IL_0e69;
																													case 58:
																														goto end_IL_0e79;
																													case 64:
																													case 85:
																														return;
																													}
																													continue;
																												}
																												ptr2 += 8;
																												goto end_IL_0413;
																												continue;
																												end_IL_0357:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_041e;
																							IL_0877:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							num = 145;
																							goto end_IL_0413;
																							IL_041e:
																							if (15 >= b)
																							{
																								goto IL_0429;
																							}
																							goto IL_0458;
																							IL_0429:
																							if (15 > b)
																							{
																								goto IL_0437;
																							}
																							goto IL_08d0;
																							IL_0437:
																							if (13 >= b)
																							{
																								goto IL_0445;
																							}
																							goto IL_0b3e;
																							IL_0445:
																							if (13 > b)
																							{
																								break;
																							}
																							goto IL_089c;
																							IL_089c:
																							array2[num5] = typeof(Class190).TypeHandle;
																							goto IL_08af;
																							IL_08af:
																							array[num5] = 4;
																							goto IL_08bd;
																							IL_08bd:
																							num5++;
																							goto end_IL_0413;
																							IL_0b3e:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_0b4c;
																							IL_0b4c:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_0b5a;
																							IL_0b5a:
																							array[num5 - 1] = 5;
																							goto IL_0b6e;
																							IL_0b6e:
																							array2[num5 - 1] = ((delegate*<RuntimeTypeHandle, Type>)getManifestFlagsValidKeySize[*(int*)(ptr2 + num3)])((RuntimeTypeHandle)array2[num5 - 1]);
																							goto IL_0ba6;
																							IL_0ba6:
																							ptr2 += 8;
																							goto end_IL_0413;
																							IL_08d0:
																							array[num5 - 1] = 0;
																							goto IL_08e4;
																							IL_08e4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (((delegate*<Type, bool>)getManifestFlagsValidKeySize[*(int*)(ptr2 + num3)])((Type)array2[num5 - 1]) ? 1 : 0);
																							goto IL_0922;
																							IL_0922:
																							ptr2 += 8;
																							goto end_IL_0413;
																							IL_0458:
																							if (16 >= b)
																							{
																								goto IL_0463;
																							}
																							goto IL_0473;
																							IL_0463:
																							if (16 > b)
																							{
																								break;
																							}
																							goto IL_0486;
																							IL_0486:
																							ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_04e4;
																							IL_04e4:
																							num5--;
																							goto end_IL_0413;
																							IL_0473:
																							if (17 < b)
																							{
																								break;
																							}
																							goto IL_0869;
																							IL_0869:
																							if (17 > b)
																							{
																								break;
																							}
																							goto IL_0877;
																						}
																						break;
																					}
																					goto IL_0bcc;
																					IL_0d97:
																					((ControllerInputPoller)array2[num5 - 2]).rightControllerGripFloat = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0dc5;
																					IL_0bcc:
																					if (21 >= b)
																					{
																						goto IL_0bda;
																					}
																					goto IL_0cf1;
																					IL_0bda:
																					if (21 > b)
																					{
																						goto IL_0be8;
																					}
																					goto IL_0cb0;
																					IL_0be8:
																					if (19 >= b)
																					{
																						goto IL_0bf3;
																					}
																					goto IL_0c53;
																					IL_0bf3:
																					if (19 > b)
																					{
																						break;
																					}
																					goto IL_0c01;
																					IL_0c01:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																					num = 42;
																					goto IL_0c24;
																					IL_0c24:
																					array[num5] = 3;
																					goto IL_0c32;
																					IL_0c32:
																					num5++;
																					goto IL_0c40;
																					IL_0c40:
																					ptr2 += 8;
																					goto end_IL_0413;
																					IL_0c53:
																					if (20 < b)
																					{
																						break;
																					}
																					goto IL_0c61;
																					IL_0c61:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0c6f;
																					IL_0c6f:
																					((ControllerInputPoller)array2[num5 - 2]).rightControllerIndexFloat = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0c9d;
																					IL_0c9d:
																					num5 -= 2;
																					goto end_IL_0413;
																					IL_0cb0:
																					((ControllerInputPoller)array2[num5 - 2]).leftControllerIndexFloat = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					goto IL_0cde;
																					IL_0cde:
																					num5 -= 2;
																					goto end_IL_0413;
																					IL_0cf1:
																					if (23 < b)
																					{
																						goto IL_0cfc;
																					}
																					num = 135;
																					goto IL_0d26;
																					IL_0cfc:
																					if (24 < b)
																					{
																						break;
																					}
																					goto IL_0d0a;
																					IL_0d0a:
																					if (24 > b)
																					{
																					}
																					break;
																					IL_0dc5:
																					num5 -= 2;
																					num = 2;
																					goto end_IL_0413;
																					IL_0d26:
																					if (23 <= b)
																					{
																						goto IL_0d31;
																					}
																					goto IL_0d81;
																					IL_0d31:
																					((ControllerInputPoller)array2[num5 - 2]).leftControllerGripFloat = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																					num = 71;
																					goto IL_0d68;
																					IL_0d68:
																					num5 -= 2;
																					num = 101;
																					goto end_IL_0413;
																					IL_0d81:
																					if (22 < b)
																					{
																						break;
																					}
																					goto IL_0d8c;
																					IL_0d8c:
																					if (22 > b)
																					{
																						break;
																					}
																					goto IL_0d97;
																				}
																				break;
																			}
																			goto IL_04f7;
																			IL_0a42:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0a50;
																			IL_04f7:
																			if (12 <= b)
																			{
																				goto end_IL_0413;
																			}
																			goto IL_0505;
																			IL_0505:
																			if (6 >= b)
																			{
																				goto IL_0513;
																			}
																			goto IL_06fd;
																			IL_0513:
																			if (6 <= b)
																			{
																				goto IL_051e;
																			}
																			goto IL_0563;
																			IL_051e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_09f4;
																			IL_09f4:
																			array[num5 - 2] = 0;
																			goto IL_0a08;
																			IL_0a08:
																			num5--;
																			goto end_IL_0413;
																			IL_0563:
																			if (3 >= b)
																			{
																				goto IL_0571;
																			}
																			goto IL_064a;
																			IL_0571:
																			if (3 > b)
																			{
																				goto IL_057f;
																			}
																			goto IL_0935;
																			IL_057f:
																			if (1 >= b)
																			{
																				goto IL_058a;
																			}
																			goto IL_05e9;
																			IL_058a:
																			if (1 > b)
																			{
																				break;
																			}
																			num = 87;
																			goto IL_05a1;
																			IL_0a50:
																			array[num5 - 2] = 0;
																			goto IL_0a64;
																			IL_05a1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_05ba;
																			IL_05ba:
																			array[num5] = 0;
																			goto IL_05c8;
																			IL_05c8:
																			num5++;
																			goto IL_05d6;
																			IL_05d6:
																			ptr2 += 8;
																			goto end_IL_0413;
																			IL_05e9:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_05f7;
																			IL_05f7:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0605;
																			IL_0605:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0a1b;
																			IL_0a1b:
																			array[num5 - 2] = 0;
																			goto IL_0a2f;
																			IL_0a2f:
																			num5--;
																			goto end_IL_0413;
																			IL_0935:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_095e;
																			IL_095e:
																			ptr2 += 8;
																			goto IL_096c;
																			IL_096c:
																			num5--;
																			goto end_IL_0413;
																			IL_064a:
																			if (4 >= b)
																			{
																				goto IL_0655;
																			}
																			goto IL_0668;
																			IL_0655:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_0ad9;
																			IL_0ad9:
																			array[num5] = 0;
																			goto IL_0ae7;
																			IL_0ae7:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0b0a;
																			IL_0b0a:
																			array2[num5] = null;
																			goto IL_0b14;
																			IL_0b14:
																			num5++;
																			goto IL_0b22;
																			IL_0b22:
																			ptr2 += 8;
																			num = 6;
																			goto end_IL_0413;
																			IL_0668:
																			if (5 < b)
																			{
																				break;
																			}
																			num = 179;
																			goto IL_067f;
																			IL_0a64:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)getManifestFlagsValidKeySize[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0ab8;
																			IL_067f:
																			if (5 > b)
																			{
																				break;
																			}
																			num = 160;
																			goto IL_0696;
																			IL_0ab8:
																			num5--;
																			goto IL_0ac6;
																			IL_0696:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06d6;
																			IL_06d6:
																			array[num5 - 2] = 0;
																			goto IL_06ea;
																			IL_06ea:
																			num5--;
																			goto end_IL_0413;
																			IL_06fd:
																			if (9 >= b)
																			{
																				goto IL_070b;
																			}
																			goto IL_07c8;
																			IL_070b:
																			if (9 > b)
																			{
																				goto IL_0719;
																			}
																			goto IL_0802;
																			IL_0719:
																			if (7 >= b)
																			{
																				goto IL_0724;
																			}
																			goto IL_0799;
																			IL_0724:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_0732;
																			IL_0732:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0772;
																			IL_0772:
																			array[num5 - 2] = 0;
																			goto IL_0786;
																			IL_0786:
																			num5--;
																			goto end_IL_0413;
																			IL_0799:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_07a7;
																			IL_07a7:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_07b5;
																			IL_07b5:
																			num5--;
																			goto end_IL_0413;
																			IL_0802:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0842;
																			IL_0842:
																			array[num5 - 2] = 0;
																			goto IL_0856;
																			IL_0856:
																			num5--;
																			goto end_IL_0413;
																			IL_07c8:
																			if (10 >= b)
																			{
																				goto IL_07d3;
																			}
																			goto IL_07e6;
																			IL_07d3:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_097f;
																			IL_097f:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_09e1;
																			IL_09e1:
																			num5 -= 2;
																			goto end_IL_0413;
																			IL_07e6:
																			if (11 < b)
																			{
																				break;
																			}
																			num = 198;
																			goto IL_0a42;
																			IL_0ac6:
																			ptr2 += 8;
																			goto end_IL_0413;
																		}
																		break;
																		IL_03e3:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0413;
																continue;
																end_IL_03f3:
																break;
															}
															continue;
															end_IL_0403:
															break;
														}
														continue;
														end_IL_0413:
														break;
													}
													continue;
													end_IL_0df1:
													break;
												}
												continue;
												end_IL_0e04:
												break;
											}
											continue;
											end_IL_0e0e:
											break;
										}
										continue;
										end_IL_0e19:
										break;
									}
									continue;
									end_IL_0e29:
									break;
								}
								continue;
								end_IL_0e39:
								break;
							}
							continue;
							end_IL_0e49:
							break;
						}
						continue;
						end_IL_0e59:
						break;
					}
					continue;
					end_IL_0e69:
					break;
				}
				continue;
				end_IL_0e79:
				break;
			}
		}
	}

	public Class191()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_2)
	{
		int num = 50;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 11;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TaskPOLICYVIEWAUDITINFORMATION.getWasUsedcArgs);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_021c:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_01fc:
																			if (5 < b)
																			{
																				num = 115;
																				while (true)
																				{
																					if (num != 115)
																					{
																						if (num != 1096)
																						{
																							break;
																						}
																						switch (num)
																						{
																						case 17:
																							goto IL_01fc;
																						case 94:
																							goto end_IL_01fc;
																						case 38:
																							goto IL_021c;
																						case 68:
																							goto end_IL_021c;
																						case 35:
																						case 45:
																							goto end_IL_022c;
																						case 89:
																							goto IL_0247;
																						case 15:
																						case 72:
																							goto IL_0255;
																						case 57:
																							goto IL_0263;
																						case 29:
																						case 76:
																							goto IL_026e;
																						case 30:
																							goto IL_0297;
																						case 79:
																							goto IL_02ae;
																						case 16:
																							goto IL_02c1;
																						case 85:
																							goto IL_02cf;
																						case 24:
																						case 82:
																							goto IL_02dd;
																						case 10:
																						case 52:
																							goto IL_02fb;
																						case 63:
																							goto IL_0309;
																						case 36:
																							goto IL_032c;
																						case 27:
																							goto IL_0336;
																						case 101:
																							goto end_IL_01e9;
																						case 59:
																						case 106:
																							goto IL_0357;
																						case 66:
																							goto IL_0362;
																						case 0:
																						case 60:
																							goto IL_0370;
																						case 54:
																						case 86:
																							goto IL_0388;
																						case 1:
																							goto IL_0396;
																						case 107:
																							goto IL_03a9;
																						case 9:
																							goto IL_03b7;
																						case 41:
																							goto IL_03c5;
																						case 5:
																							goto IL_03d8;
																						case 95:
																							goto IL_03e6;
																						case 48:
																						case 90:
																							goto IL_03f4;
																						case 31:
																						case 87:
																							goto IL_03ff;
																						case 6:
																							goto IL_040d;
																						case 19:
																						case 78:
																							goto IL_041b;
																						case 44:
																							goto IL_043e;
																						case 46:
																							goto IL_044c;
																						case 20:
																							goto IL_045a;
																						case 13:
																							goto IL_046d;
																						case 33:
																						case 40:
																							goto IL_047b;
																						case 103:
																							goto IL_04bb;
																						case 88:
																							goto IL_04cf;
																						case 7:
																						case 102:
																							goto IL_04e2;
																						case 28:
																							goto IL_0544;
																						case 47:
																							goto IL_0554;
																						case 53:
																						case 67:
																							goto IL_055f;
																						case 108:
																							goto IL_056a;
																						case 105:
																							goto IL_0577;
																						case 21:
																						case 39:
																							goto IL_0582;
																						case 2:
																						case 3:
																						case 25:
																						case 26:
																						case 32:
																						case 37:
																						case 42:
																						case 43:
																						case 51:
																						case 56:
																						case 61:
																						case 62:
																						case 65:
																						case 71:
																						case 73:
																						case 74:
																						case 80:
																						case 84:
																						case 92:
																						case 99:
																						case 100:
																							goto end_IL_020c;
																						case 4:
																						case 8:
																						case 18:
																						case 22:
																						case 23:
																						case 55:
																						case 70:
																						case 75:
																						case 81:
																						case 93:
																						case 96:
																						case 97:
																						case 104:
																							goto end_IL_023c;
																						case 77:
																							goto end_IL_05ae;
																						case 14:
																							goto end_IL_05c1;
																						case 69:
																							goto end_IL_05cb;
																						case 83:
																							goto end_IL_05d6;
																						case 34:
																						case 91:
																							goto end_IL_05eb;
																						case 58:
																							goto end_IL_05fb;
																						case 11:
																						case 64:
																							goto end_IL_060b;
																						case 49:
																							goto end_IL_061b;
																						case 50:
																							goto end_IL_062b;
																						case 12:
																						case 98:
																							goto IL_064f;
																						}
																						continue;
																					}
																					goto IL_03d8;
																					IL_0577:
																					if (9 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_0582;
																					IL_0582:
																					byte* num5 = ptr2;
																					num4 = 1;
																					ptr2 = num5 + -200;
																					goto end_IL_023c;
																					IL_03d8:
																					if (8 >= b)
																					{
																						goto IL_03e6;
																					}
																					goto IL_0554;
																					IL_03e6:
																					if (8 > b)
																					{
																						goto IL_03f4;
																					}
																					goto IL_04e2;
																					IL_03f4:
																					if (6 < b)
																					{
																						goto IL_03ff;
																					}
																					goto IL_046d;
																					IL_03ff:
																					if (7 < b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_040d;
																					IL_040d:
																					if (7 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_041b;
																					IL_041b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_043e;
																					IL_043e:
																					array[num6] = 0;
																					goto IL_044c;
																					IL_044c:
																					num6++;
																					goto IL_045a;
																					IL_045a:
																					ptr2 += 8;
																					goto end_IL_023c;
																					IL_046d:
																					if (6 > b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_047b;
																					IL_047b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_04bb;
																					IL_04bb:
																					array[num6 - 2] = 0;
																					goto IL_04cf;
																					IL_04cf:
																					num6--;
																					goto end_IL_023c;
																					IL_04e2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0544;
																					IL_0544:
																					num6 -= 2;
																					goto end_IL_023c;
																					IL_0554:
																					if (9 < b)
																					{
																						goto IL_055f;
																					}
																					goto IL_0577;
																					IL_055f:
																					if (10 < b)
																					{
																						goto end_IL_020c;
																					}
																					goto IL_056a;
																					IL_056a:
																					if (10 <= b)
																					{
																					}
																					goto end_IL_020c;
																					continue;
																					end_IL_01e9:
																					break;
																				}
																				goto IL_0344;
																			}
																			goto IL_0247;
																			IL_0336:
																			num6++;
																			goto IL_0344;
																			IL_0344:
																			ptr2 += 8;
																			goto end_IL_023c;
																			IL_0247:
																			if (5 > b)
																			{
																				goto IL_0255;
																			}
																			goto IL_02fb;
																			IL_0255:
																			if (2 >= b)
																			{
																				goto IL_0263;
																			}
																			goto IL_0357;
																			IL_0263:
																			if (2 <= b)
																			{
																				goto IL_026e;
																			}
																			goto IL_02c1;
																			IL_026e:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0297;
																			IL_0297:
																			ptr2 += 8;
																			num = 79;
																			goto IL_02ae;
																			IL_02ae:
																			num6--;
																			goto end_IL_023c;
																			IL_02c1:
																			if (1 < b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_02cf;
																			IL_02cf:
																			if (1 > b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_02dd;
																			IL_02dd:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_03a9;
																			IL_03a9:
																			array[num6] = 0;
																			goto IL_03b7;
																			IL_03b7:
																			num6++;
																			goto IL_03c5;
																			IL_03c5:
																			ptr2 += 8;
																			goto end_IL_023c;
																			IL_0357:
																			if (3 >= b)
																			{
																				goto IL_0362;
																			}
																			goto IL_0388;
																			IL_0362:
																			if (3 > b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_0370;
																			IL_0370:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_023c;
																			IL_0388:
																			if (4 < b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_0396;
																			IL_0396:
																			if (4 <= b)
																			{
																				goto end_IL_023c;
																			}
																			goto end_IL_020c;
																			IL_02fb:
																			array[num6] = 0;
																			goto IL_0309;
																			IL_0309:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_032c;
																			IL_032c:
																			array2[num6] = null;
																			goto IL_0336;
																			continue;
																			end_IL_01fc:
																			break;
																		}
																		continue;
																		end_IL_020c:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_023c;
																continue;
																end_IL_021c:
																break;
															}
															continue;
															end_IL_022c:
															break;
														}
														continue;
														end_IL_023c:
														break;
													}
													continue;
												}
												goto IL_064f;
												IL_064f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05ae:
												break;
											}
											continue;
											end_IL_05c1:
											break;
										}
										continue;
										end_IL_05cb:
										break;
									}
									continue;
									end_IL_05d6:
									break;
								}
								continue;
								end_IL_05eb:
								break;
							}
							continue;
							end_IL_05fb:
							break;
						}
						continue;
						end_IL_060b:
						break;
					}
					continue;
					end_IL_061b:
					break;
				}
				continue;
				end_IL_062b:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_2, int int_3)
	{
		int num = 23;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EnumBuildergetCompatibleFrameworksData.EndOffsetremoveModuleResolve);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																num = 35;
																while (true)
																{
																	IL_0244:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0227:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0217:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0207:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01f7:
																										if (3 >= b)
																										{
																											while (3 <= b)
																											{
																												num = 109;
																												while (true)
																												{
																													if (num != 109)
																													{
																														if (num != 1090)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 45:
																															goto IL_01e4;
																														case 4:
																														case 88:
																															goto IL_01f7;
																														case 60:
																														case 66:
																															goto IL_0207;
																														case 69:
																															goto IL_0217;
																														case 93:
																															goto IL_0227;
																														case 36:
																															goto IL_0234;
																														case 35:
																															goto IL_0244;
																														case 44:
																															goto end_IL_0244;
																														case 37:
																														case 74:
																															goto end_IL_0254;
																														case 76:
																														case 92:
																															goto IL_0278;
																														case 0:
																															goto IL_0286;
																														case 11:
																														case 39:
																															goto IL_0291;
																														case 47:
																															goto IL_02aa;
																														case 83:
																															goto IL_02c1;
																														case 40:
																															goto IL_02cf;
																														case 25:
																															goto IL_02e2;
																														case 29:
																															goto IL_02f0;
																														case 8:
																														case 24:
																															goto IL_02fe;
																														case 28:
																															goto IL_033e;
																														case 73:
																															goto IL_0352;
																														case 96:
																															goto IL_0365;
																														case 52:
																														case 57:
																															goto IL_0370;
																														case 1:
																															goto IL_037e;
																														case 16:
																														case 91:
																															goto IL_038c;
																														case 68:
																															goto IL_03a8;
																														case 31:
																														case 81:
																															goto IL_03b6;
																														case 10:
																															goto IL_03f6;
																														case 82:
																															goto IL_040a;
																														case 61:
																															goto IL_041d;
																														case 53:
																															goto IL_0446;
																														case 21:
																															goto IL_045d;
																														case 58:
																															goto IL_0470;
																														case 99:
																															goto IL_047e;
																														case 9:
																														case 62:
																															goto IL_048c;
																														case 54:
																															goto IL_04cc;
																														case 5:
																															goto IL_04e0;
																														case 78:
																															goto IL_04f3;
																														case 27:
																															goto IL_04fe;
																														case 19:
																															goto IL_050c;
																														case 15:
																														case 34:
																															goto end_IL_01d1;
																														case 6:
																															goto IL_055f;
																														case 80:
																															goto IL_0573;
																														case 12:
																														case 87:
																															goto IL_0586;
																														case 89:
																															goto IL_0594;
																														case 26:
																															goto IL_05b7;
																														case 98:
																															goto IL_05c1;
																														case 56:
																															goto IL_05cf;
																														case 2:
																														case 13:
																														case 14:
																														case 17:
																														case 38:
																														case 41:
																														case 46:
																														case 59:
																														case 67:
																														case 70:
																														case 71:
																														case 72:
																														case 85:
																														case 90:
																														case 97:
																														case 101:
																															goto end_IL_01e4;
																														case 100:
																															goto IL_0602;
																														case 63:
																															goto IL_0610;
																														case 32:
																															goto IL_061e;
																														case 7:
																														case 18:
																														case 20:
																														case 30:
																														case 33:
																														case 48:
																														case 49:
																														case 64:
																														case 79:
																														case 94:
																														case 102:
																															goto end_IL_026d;
																														case 84:
																															goto end_IL_062c;
																														case 42:
																															goto end_IL_063f;
																														case 50:
																															goto end_IL_0649;
																														case 95:
																															goto end_IL_0654;
																														case 55:
																															goto end_IL_0669;
																														case 43:
																														case 77:
																															goto end_IL_067e;
																														case 65:
																															goto end_IL_068e;
																														case 75:
																														case 86:
																															goto end_IL_069e;
																														case 22:
																															goto end_IL_06ae;
																														case 23:
																															goto end_IL_06be;
																														case 3:
																														case 51:
																															goto IL_06d9;
																														}
																														continue;
																													}
																													goto IL_041d;
																													IL_0446:
																													ptr2 += 8;
																													num = 21;
																													goto IL_045d;
																													IL_045d:
																													num5--;
																													goto end_IL_026d;
																													IL_041d:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0446;
																													continue;
																													end_IL_01d1:
																													break;
																												}
																												goto IL_051f;
																												continue;
																												end_IL_01e4:
																												break;
																												IL_01e4:;
																											}
																											break;
																										}
																										goto IL_0470;
																										IL_04e0:
																										num5--;
																										goto end_IL_026d;
																										IL_0470:
																										if (4 < b)
																										{
																											break;
																										}
																										goto IL_047e;
																										IL_047e:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_048c;
																										IL_048c:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_04cc;
																										IL_04cc:
																										array[num5 - 2] = 0;
																										goto IL_04e0;
																									}
																									break;
																								}
																								goto IL_04f3;
																								IL_0573:
																								num5--;
																								goto end_IL_026d;
																								IL_04f3:
																								if (2 > b)
																								{
																									goto IL_04fe;
																								}
																								goto IL_051f;
																								IL_04fe:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_050c;
																								IL_050c:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_051f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_055f;
																								IL_055f:
																								array[num5 - 2] = 0;
																								goto IL_0573;
																							}
																							break;
																						}
																						goto IL_0586;
																						IL_05cf:
																						ptr2 += 8;
																						goto end_IL_026d;
																						IL_0586:
																						array[num5] = 0;
																						goto IL_0594;
																						IL_0594:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05b7;
																						IL_05b7:
																						array2[num5] = null;
																						goto IL_05c1;
																						IL_05c1:
																						num5++;
																						goto IL_05cf;
																					}
																					break;
																				}
																				goto IL_0278;
																				IL_040a:
																				num5--;
																				goto end_IL_026d;
																				IL_0278:
																				if (7 >= b)
																				{
																					goto IL_0286;
																				}
																				goto IL_0365;
																				IL_0286:
																				if (7 <= b)
																				{
																					goto IL_0291;
																				}
																				goto IL_02e2;
																				IL_0291:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_02aa;
																				IL_02aa:
																				array[num5] = 0;
																				num = 83;
																				goto IL_02c1;
																				IL_02c1:
																				num5++;
																				goto IL_02cf;
																				IL_02cf:
																				ptr2 += 8;
																				goto end_IL_026d;
																				IL_02e2:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_02f0;
																				IL_02f0:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_02fe;
																				IL_02fe:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_033e;
																				IL_033e:
																				array[num5 - 2] = 0;
																				goto IL_0352;
																				IL_0352:
																				num5--;
																				goto end_IL_026d;
																				IL_0365:
																				if (8 < b)
																				{
																					goto IL_0370;
																				}
																				goto IL_03a8;
																				IL_0370:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_037e;
																				IL_037e:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_038c;
																				IL_038c:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_026d;
																				IL_03a8:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_03b6;
																				IL_03b6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03f6;
																				IL_03f6:
																				array[num5 - 2] = 0;
																				goto IL_040a;
																			}
																			break;
																			IL_0234:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0602;
																	IL_061e:
																	ptr2 += 8;
																	goto end_IL_026d;
																	IL_0610:
																	num5++;
																	goto IL_061e;
																	IL_0602:
																	array[num5] = 0;
																	goto IL_0610;
																	continue;
																	end_IL_0244:
																	break;
																}
																continue;
																end_IL_0254:
																break;
															}
															continue;
															end_IL_026d:
															break;
														}
														continue;
													}
													goto IL_06d9;
													IL_06d9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062c:
													break;
												}
												continue;
												end_IL_063f:
												break;
											}
											continue;
											end_IL_0649:
											break;
										}
										continue;
										end_IL_0654:
										break;
									}
									continue;
									end_IL_0669:
									break;
								}
								continue;
								end_IL_067e:
								break;
							}
							continue;
							end_IL_068e:
							break;
						}
						continue;
						end_IL_069e:
						break;
					}
					continue;
					end_IL_06ae:
					break;
				}
				continue;
				end_IL_06be:
				break;
			}
		}
	}

	private unsafe static int smethod_2()
	{
		int num = 46;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 120;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref NVTraceIgetInnerException.CreateFromCertFilewMinorVerNum);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														num = 95;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_02e0:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02c0:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02b3:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02a3:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_0290:
																										if (10 < b)
																										{
																											num = 152;
																											while (true)
																											{
																												if (num != 152)
																												{
																													if (num != 1133)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 48:
																														goto IL_0290;
																													case 138:
																														goto IL_02a3;
																													case 57:
																														goto IL_02b3;
																													case 96:
																														goto IL_02c0;
																													case 65:
																														goto end_IL_027d;
																													case 37:
																														goto IL_02e0;
																													case 102:
																														goto end_IL_02e0;
																													case 95:
																														goto end_IL_02f0;
																													case 36:
																														goto end_IL_0300;
																													case 4:
																													case 14:
																														goto IL_0316;
																													case 63:
																														goto IL_0324;
																													case 5:
																													case 18:
																														goto IL_032f;
																													case 69:
																													case 81:
																														goto IL_0354;
																													case 40:
																														goto IL_0362;
																													case 13:
																													case 17:
																														goto IL_0370;
																													case 67:
																														goto IL_03db;
																													case 77:
																													case 83:
																														goto IL_03ee;
																													case 131:
																														goto IL_03fe;
																													case 111:
																													case 122:
																														goto IL_0409;
																													case 109:
																														goto IL_0417;
																													case 100:
																														goto IL_043a;
																													case 20:
																													case 129:
																														goto IL_0446;
																													case 47:
																														goto IL_0454;
																													case 132:
																														goto IL_0467;
																													case 133:
																														goto IL_0483;
																													case 32:
																														goto IL_0491;
																													case 112:
																														goto IL_04a4;
																													case 10:
																														goto IL_04b2;
																													case 0:
																													case 92:
																														goto IL_04c9;
																													case 60:
																														goto IL_050d;
																													case 145:
																														goto IL_0521;
																													case 68:
																													case 141:
																														goto IL_0534;
																													case 2:
																														goto IL_0574;
																													case 93:
																														goto IL_0588;
																													case 58:
																														goto IL_059b;
																													case 35:
																													case 79:
																														goto IL_05a9;
																													case 87:
																														goto IL_05b7;
																													case 80:
																													case 91:
																														goto IL_05cb;
																													case 78:
																														goto IL_05e9;
																													case 103:
																														goto IL_05f7;
																													case 125:
																														goto IL_060a;
																													case 8:
																														goto IL_0618;
																													case 23:
																													case 90:
																														goto IL_0623;
																													case 26:
																														goto IL_0631;
																													case 49:
																													case 101:
																														goto IL_063f;
																													case 98:
																														goto IL_0658;
																													case 76:
																														goto IL_0666;
																													case 34:
																														goto IL_0674;
																													case 11:
																													case 31:
																														goto IL_0687;
																													case 108:
																														goto IL_06c7;
																													case 88:
																														goto IL_06db;
																													case 74:
																														goto IL_06ee;
																													case 42:
																														goto IL_06fc;
																													case 82:
																													case 126:
																														goto IL_070a;
																													case 29:
																														goto IL_0733;
																													case 27:
																														goto IL_074c;
																													case 52:
																														goto IL_075a;
																													case 86:
																													case 130:
																														goto IL_0765;
																													case 16:
																														goto IL_07a4;
																													case 25:
																														goto IL_07b7;
																													case 113:
																														goto IL_07c5;
																													case 41:
																													case 115:
																														goto IL_07d3;
																													case 117:
																														goto IL_07e1;
																													case 30:
																														goto IL_07f9;
																													case 72:
																														goto IL_0807;
																													case 33:
																														goto IL_081a;
																													case 44:
																														goto IL_0825;
																													case 51:
																													case 127:
																														goto IL_0830;
																													case 124:
																														goto IL_0859;
																													case 128:
																														goto IL_0867;
																													case 84:
																													case 85:
																														goto IL_0877;
																													case 1:
																													case 12:
																													case 22:
																													case 24:
																													case 28:
																													case 39:
																													case 43:
																													case 62:
																													case 64:
																													case 66:
																													case 73:
																													case 75:
																													case 97:
																													case 104:
																													case 105:
																													case 106:
																													case 110:
																													case 114:
																													case 119:
																													case 123:
																													case 134:
																													case 135:
																													case 136:
																													case 143:
																													case 144:
																														goto end_IL_02d0;
																													case 3:
																													case 7:
																													case 9:
																													case 15:
																													case 21:
																													case 50:
																													case 53:
																													case 54:
																													case 55:
																													case 56:
																													case 61:
																													case 89:
																													case 107:
																													case 116:
																													case 137:
																													case 139:
																													case 140:
																													case 142:
																														goto end_IL_030b;
																													case 118:
																														goto end_IL_089f;
																													case 94:
																														goto end_IL_08b2;
																													case 99:
																														goto end_IL_08bc;
																													case 6:
																														goto end_IL_08c7;
																													case 19:
																													case 38:
																														goto end_IL_08d7;
																													case 120:
																														goto end_IL_08e7;
																													case 59:
																													case 121:
																														goto end_IL_08f7;
																													case 45:
																														goto end_IL_0907;
																													case 46:
																														goto end_IL_0920;
																													case 70:
																													case 71:
																														goto IL_093b;
																													}
																													continue;
																												}
																												goto IL_04a4;
																												IL_04c9:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																												goto IL_050d;
																												IL_050d:
																												array[num5 - 2] = 0;
																												goto IL_0521;
																												IL_04a4:
																												if (11 < b)
																												{
																													goto end_IL_02d0;
																												}
																												goto IL_04b2;
																												IL_04b2:
																												if (11 > b)
																												{
																													goto end_IL_02d0;
																												}
																												num = 92;
																												goto IL_04c9;
																												IL_0521:
																												num5--;
																												goto end_IL_030b;
																												continue;
																												end_IL_027d:
																												break;
																											}
																											break;
																										}
																										goto IL_03fe;
																										IL_0446:
																										if (9 < b)
																										{
																											goto end_IL_02d0;
																										}
																										goto IL_0454;
																										IL_0454:
																										if (9 > b)
																										{
																											goto end_IL_02d0;
																										}
																										goto end_IL_030b;
																										IL_03fe:
																										if (10 <= b)
																										{
																											goto IL_0409;
																										}
																										goto IL_0446;
																										IL_0409:
																										array[num5] = 0;
																										goto IL_0417;
																										IL_0417:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_043a;
																										IL_043a:
																										array2[num5] = null;
																										goto IL_0483;
																										IL_0483:
																										num5++;
																										goto IL_0491;
																										IL_0491:
																										ptr2 += 8;
																										goto end_IL_030b;
																									}
																									break;
																								}
																								goto IL_0534;
																								IL_0588:
																								num5--;
																								goto end_IL_030b;
																								IL_0534:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0574;
																								IL_0574:
																								array[num5 - 2] = 0;
																								goto IL_0588;
																							}
																							break;
																						}
																						goto IL_0316;
																						IL_0467:
																						if (15 > b)
																						{
																							num = 144;
																						}
																						goto end_IL_02d0;
																						IL_0316:
																						if (14 >= b)
																						{
																							goto IL_0324;
																						}
																						goto IL_03ee;
																						IL_0324:
																						if (14 <= b)
																						{
																							goto IL_032f;
																						}
																						goto IL_0354;
																						IL_032f:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						num = 140;
																						goto end_IL_030b;
																						IL_0354:
																						if (13 < b)
																						{
																							goto end_IL_02d0;
																						}
																						goto IL_0362;
																						IL_0362:
																						if (13 > b)
																						{
																							goto end_IL_02d0;
																						}
																						goto IL_0370;
																						IL_0370:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						num = 67;
																						goto IL_03db;
																						IL_03db:
																						num5 -= 2;
																						goto end_IL_030b;
																						IL_03ee:
																						if (15 < b)
																						{
																							goto end_IL_02d0;
																						}
																						goto IL_0467;
																					}
																					break;
																				}
																				goto IL_059b;
																				IL_0867:
																				num5--;
																				goto end_IL_030b;
																				IL_059b:
																				if (8 > b)
																				{
																					goto IL_05a9;
																				}
																				goto IL_0877;
																				IL_05a9:
																				if (4 >= b)
																				{
																					goto IL_05b7;
																				}
																				goto IL_074c;
																				IL_05b7:
																				if (4 <= b)
																				{
																					num = 91;
																					goto IL_05cb;
																				}
																				goto IL_060a;
																				IL_0877:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_030b;
																				IL_05cb:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_05e9;
																				IL_05e9:
																				ptr2 += 8;
																				goto IL_05f7;
																				IL_05f7:
																				num5--;
																				goto end_IL_030b;
																				IL_060a:
																				if (2 >= b)
																				{
																					goto IL_0618;
																				}
																				goto IL_06ee;
																				IL_0618:
																				if (2 > b)
																				{
																					goto IL_0623;
																				}
																				goto IL_0687;
																				IL_0623:
																				if (1 < b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_0631;
																				IL_0631:
																				if (1 > b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_063f;
																				IL_063f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0658;
																				IL_0658:
																				array[num5] = 0;
																				goto IL_0666;
																				IL_0666:
																				num5++;
																				goto IL_0674;
																				IL_0674:
																				ptr2 += 8;
																				goto end_IL_030b;
																				IL_0687:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06c7;
																				IL_06c7:
																				array[num5 - 2] = 0;
																				goto IL_06db;
																				IL_06db:
																				num5--;
																				goto end_IL_030b;
																				IL_06ee:
																				if (3 < b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_06fc;
																				IL_06fc:
																				if (3 > b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_070a;
																				IL_070a:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_0733;
																				IL_0733:
																				array[num5 - 1] = 5;
																				goto end_IL_030b;
																				IL_074c:
																				if (6 >= b)
																				{
																					goto IL_075a;
																				}
																				goto IL_081a;
																				IL_075a:
																				if (6 <= b)
																				{
																					goto IL_0765;
																				}
																				goto IL_07b7;
																				IL_0765:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_07a4;
																				IL_07a4:
																				num5 -= 3;
																				goto end_IL_030b;
																				IL_07b7:
																				if (5 < b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_07c5;
																				IL_07c5:
																				if (5 > b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_07d3;
																				IL_07d3:
																				array[num5] = 5;
																				goto IL_07e1;
																				IL_07e1:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_07f9;
																				IL_07f9:
																				num5++;
																				goto IL_0807;
																				IL_0807:
																				ptr2 += 8;
																				goto end_IL_030b;
																				IL_081a:
																				if (7 < b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_0825;
																				IL_0825:
																				if (7 > b)
																				{
																					goto end_IL_02d0;
																				}
																				goto IL_0830;
																				IL_0830:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0859;
																				IL_0859:
																				ptr2 += 8;
																				goto IL_0867;
																			}
																			continue;
																			end_IL_02d0:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_030b;
																	continue;
																	end_IL_02e0:
																	break;
																}
																continue;
																end_IL_02f0:
																break;
															}
															continue;
															end_IL_0300:
															break;
														}
														continue;
														end_IL_030b:
														break;
													}
													continue;
												}
												goto IL_093b;
												IL_093b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_089f:
												break;
											}
											continue;
											end_IL_08b2:
											break;
										}
										continue;
										end_IL_08bc:
										break;
									}
									continue;
									end_IL_08c7:
									break;
								}
								continue;
								end_IL_08d7:
								break;
							}
							continue;
							end_IL_08e7:
							break;
						}
						continue;
						end_IL_08f7:
						break;
					}
					continue;
					end_IL_0907:
					break;
				}
				continue;
				end_IL_0920:
				break;
			}
		}
	}

	private static int smethod_3()
	{
		int num = 6;
		int num2 = 2;
		num = 3;
		object obj = new int[3];
		object obj2 = obj;
		obj = obj2;
		num2 = 0;
		int num3 = 120;
		num3 = 40;
		((int[])obj)[0] = 40;
		obj = obj2;
		num2 = 1;
		num3 = 1;
		((int[])obj)[1] = 1;
		obj = obj2;
		num2 = 10;
		num3 = 5;
		num2 = 2;
		num3 = 102;
		num3 = 34;
		((int[])obj)[2] = 34;
		num = 0;
		int num4 = 0;
		num = 0;
		int num5 = 0;
		while (true)
		{
			num = num5;
			num2 = 33;
			num3 = 11;
			num2 = 3;
			if (num >= 3)
			{
				break;
			}
			num = num4;
			object obj3 = obj2;
			num3 = num5;
			num2 = ((int[])obj3)[num3];
			num += num2;
			num4 = num;
			num = num5;
			num2 = 1;
			num++;
			num5 = num;
		}
		return num4;
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 3;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									num = 73;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DynamicTypeInfogetModules.PerefFUNCFLAGFREQUESTEDIT);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 97;
															while (true)
															{
																if (num != 97)
																{
																	if (num != 1078)
																	{
																		goto IL_0405;
																	}
																	switch (num)
																	{
																	case 45:
																	case 46:
																		goto end_IL_0193;
																	case 88:
																		goto IL_01c5;
																	case 27:
																		goto IL_01d3;
																	case 85:
																		goto IL_01e1;
																	case 86:
																		goto IL_01ef;
																	case 8:
																	case 15:
																		goto IL_01fd;
																	case 64:
																	case 66:
																		goto IL_020b;
																	case 50:
																		goto IL_0219;
																	case 13:
																	case 53:
																		goto IL_0227;
																	case 31:
																		goto IL_0267;
																	case 41:
																		goto IL_027b;
																	case 89:
																		goto IL_028e;
																	case 30:
																	case 36:
																		goto IL_029c;
																	case 79:
																		goto IL_030a;
																	case 20:
																	case 78:
																		goto IL_0326;
																	case 65:
																		goto IL_0334;
																	case 57:
																	case 68:
																		goto IL_0347;
																	case 56:
																		goto IL_0370;
																	case 90:
																		goto IL_037e;
																	case 61:
																		goto IL_0391;
																	case 0:
																		goto IL_039c;
																	case 33:
																	case 55:
																		goto IL_03aa;
																	case 25:
																		goto IL_03b8;
																	case 23:
																	case 75:
																		goto IL_03c6;
																	case 40:
																		goto IL_03de;
																	case 34:
																		goto IL_03e9;
																	case 62:
																	case 70:
																		goto IL_03f7;
																	case 7:
																		goto IL_0405;
																	case 60:
																		goto IL_0428;
																	case 71:
																		goto IL_0432;
																	case 51:
																		goto IL_0440;
																	case 82:
																	case 84:
																		goto IL_0453;
																	case 35:
																		goto IL_045e;
																	case 10:
																	case 19:
																		goto IL_0469;
																	case 1:
																	case 4:
																	case 6:
																	case 9:
																	case 16:
																	case 17:
																	case 24:
																	case 28:
																	case 48:
																	case 58:
																	case 59:
																	case 67:
																	case 69:
																	case 72:
																	case 76:
																	case 81:
																	case 83:
																		goto IL_048b;
																	case 63:
																		goto IL_04ae;
																	case 52:
																		goto IL_04bc;
																	case 42:
																		goto IL_04ca;
																	case 12:
																	case 14:
																	case 18:
																	case 21:
																	case 22:
																	case 39:
																	case 43:
																	case 44:
																	case 54:
																	case 77:
																	case 87:
																		goto end_IL_01a3;
																	case 38:
																		goto end_IL_04d8;
																	case 32:
																		goto end_IL_04eb;
																	case 73:
																		goto end_IL_04f5;
																	case 11:
																		goto end_IL_0500;
																	case 5:
																		goto end_IL_0515;
																	case 29:
																	case 74:
																		goto end_IL_0533;
																	case 49:
																		goto end_IL_0543;
																	case 37:
																	case 47:
																		goto end_IL_0553;
																	case 2:
																		goto end_IL_0563;
																	case 3:
																		goto end_IL_0573;
																	case 26:
																	case 80:
																		goto IL_0597;
																	}
																	continue;
																}
																ptr2++;
																goto IL_01c5;
																IL_04ca:
																ptr2 += 8;
																goto end_IL_01a3;
																IL_04ae:
																array[num5] = 0;
																goto IL_04bc;
																IL_048b:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_04ae;
																IL_01c5:
																if (b >= 1)
																{
																	goto IL_01d3;
																}
																goto IL_048b;
																IL_01d3:
																if (b <= 8)
																{
																	goto IL_01e1;
																}
																goto IL_048b;
																IL_01e1:
																if (4 >= b)
																{
																	goto IL_01ef;
																}
																goto IL_0391;
																IL_01ef:
																if (4 > b)
																{
																	goto IL_01fd;
																}
																goto IL_0347;
																IL_01fd:
																if (2 < b)
																{
																	goto IL_020b;
																}
																goto IL_028e;
																IL_020b:
																if (3 >= b)
																{
																	goto IL_0219;
																}
																goto IL_048b;
																IL_0219:
																if (3 <= b)
																{
																	goto IL_0227;
																}
																goto IL_048b;
																IL_0227:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0267;
																IL_0267:
																array[num5 - 2] = 0;
																goto IL_027b;
																IL_027b:
																num5--;
																goto end_IL_01a3;
																IL_028e:
																if (2 <= b)
																{
																	goto IL_029c;
																}
																num = 78;
																goto IL_0326;
																IL_029c:
																ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_030a;
																IL_030a:
																num5 -= 2;
																goto end_IL_01a3;
																IL_04bc:
																num5++;
																goto IL_04ca;
																IL_0326:
																if (1 >= b)
																{
																	goto IL_0334;
																}
																goto IL_048b;
																IL_0334:
																if (1 > b)
																{
																}
																goto IL_048b;
																IL_0347:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0370;
																IL_0370:
																ptr2 += 8;
																goto IL_037e;
																IL_037e:
																num5--;
																goto end_IL_01a3;
																IL_0391:
																if (6 >= b)
																{
																	goto IL_039c;
																}
																goto IL_03de;
																IL_039c:
																if (6 <= b)
																{
																	goto end_IL_01a3;
																}
																goto IL_03aa;
																IL_03aa:
																if (5 >= b)
																{
																	goto IL_03b8;
																}
																goto IL_048b;
																IL_03b8:
																if (5 <= b)
																{
																	goto IL_03c6;
																}
																goto IL_048b;
																IL_03c6:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_01a3;
																IL_03de:
																if (7 >= b)
																{
																	goto IL_03e9;
																}
																goto IL_0453;
																IL_03e9:
																if (7 <= b)
																{
																	goto IL_03f7;
																}
																goto IL_048b;
																IL_03f7:
																array[num5] = 0;
																goto IL_0405;
																IL_0405:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_0428;
																IL_0428:
																array2[num5] = null;
																goto IL_0432;
																IL_0432:
																num5++;
																goto IL_0440;
																IL_0440:
																ptr2 += 8;
																goto end_IL_01a3;
																IL_0453:
																if (8 >= b)
																{
																	goto IL_045e;
																}
																num = 9;
																goto IL_048b;
																IL_045e:
																if (8 <= b)
																{
																	goto IL_0469;
																}
																goto IL_048b;
																IL_0469:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_01a3;
																continue;
																end_IL_0193:
																break;
															}
															continue;
															end_IL_01a3:
															break;
														}
														continue;
													}
													num = 26;
													goto IL_0597;
													IL_0597:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04d8:
													break;
												}
												continue;
												end_IL_04eb:
												break;
											}
											continue;
											end_IL_04f5:
											break;
										}
										continue;
										end_IL_0500:
										break;
									}
									continue;
									end_IL_0515:
									break;
								}
								continue;
								end_IL_0533:
								break;
							}
							continue;
							end_IL_0543:
							break;
						}
						continue;
						end_IL_0553:
						break;
					}
					continue;
					end_IL_0563:
					break;
				}
				continue;
				end_IL_0573:
				break;
			}
		}
	}

	private unsafe static int smethod_5()
	{
		int num = 64;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setValueXMLLang.DiscretionaryAclAutoInheritRequiredsetCursorVisible);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_034f:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_032f:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_031f:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_030f:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_0302:
																									if (6 < b)
																									{
																										while (7 >= b)
																										{
																											while (7 <= b)
																											{
																												while (true)
																												{
																													IL_02b7:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													while (true)
																													{
																														IL_029e:
																														ptr2 += 8;
																														num = 159;
																														while (true)
																														{
																															if (num != 159)
																															{
																																if (num != 1140)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 45:
																																	goto IL_029e;
																																case 16:
																																case 114:
																																	goto IL_02b7;
																																case 111:
																																	goto IL_02e2;
																																case 84:
																																	goto IL_02f2;
																																case 20:
																																case 135:
																																	goto IL_0302;
																																case 27:
																																case 77:
																																	goto IL_030f;
																																case 28:
																																	goto IL_031f;
																																case 133:
																																	goto IL_032f;
																																case 88:
																																	goto IL_033f;
																																case 71:
																																	goto IL_034f;
																																case 0:
																																	goto end_IL_034f;
																																case 96:
																																case 106:
																																	goto end_IL_035f;
																																case 98:
																																	goto IL_037a;
																																case 50:
																																case 79:
																																	goto IL_0385;
																																case 40:
																																	goto end_IL_028b;
																																case 23:
																																case 69:
																																	goto IL_03a3;
																																case 127:
																																	goto IL_03e2;
																																case 118:
																																case 136:
																																	goto IL_03f5;
																																case 82:
																																case 145:
																																	goto IL_040d;
																																case 149:
																																	goto IL_041b;
																																case 19:
																																	goto IL_0433;
																																case 97:
																																	goto IL_0441;
																																case 141:
																																	goto IL_0467;
																																case 129:
																																case 130:
																																	goto IL_0472;
																																case 126:
																																	goto IL_0490;
																																case 112:
																																	goto IL_049e;
																																case 53:
																																	goto IL_04b1;
																																case 54:
																																case 90:
																																	goto IL_04c5;
																																case 51:
																																	goto IL_04d3;
																																case 36:
																																case 92:
																																	goto IL_04e1;
																																case 61:
																																	goto IL_0513;
																																case 87:
																																	goto IL_052c;
																																case 25:
																																case 44:
																																	goto IL_0537;
																																case 80:
																																	goto IL_0545;
																																case 6:
																																case 110:
																																	goto IL_0553;
																																case 37:
																																	goto IL_056c;
																																case 75:
																																	goto IL_057a;
																																case 116:
																																	goto IL_0588;
																																case 35:
																																case 95:
																																	goto IL_059b;
																																case 94:
																																	goto IL_05db;
																																case 59:
																																	goto IL_05f8;
																																case 108:
																																	goto IL_060b;
																																case 76:
																																	goto IL_0619;
																																case 138:
																																	goto IL_0627;
																																case 1:
																																case 13:
																																	goto IL_0635;
																																case 101:
																																	goto IL_0643;
																																case 49:
																																case 146:
																																	goto IL_065c;
																																case 139:
																																	goto IL_06a0;
																																case 31:
																																	goto IL_06b4;
																																case 46:
																																	goto IL_06c7;
																																case 11:
																																case 18:
																																	goto IL_06d2;
																																case 131:
																																	goto IL_06eb;
																																case 72:
																																case 113:
																																	goto IL_06fe;
																																case 147:
																																	goto IL_070c;
																																case 151:
																																	goto IL_072f;
																																case 24:
																																	goto IL_0739;
																																case 128:
																																	goto IL_0747;
																																case 29:
																																case 41:
																																	goto IL_0763;
																																case 32:
																																	goto IL_07ac;
																																case 30:
																																	goto IL_07c0;
																																case 42:
																																case 73:
																																	goto IL_07dc;
																																case 86:
																																	goto IL_07ea;
																																case 81:
																																case 83:
																																	goto IL_07f5;
																																case 9:
																																case 57:
																																	goto IL_0811;
																																case 107:
																																	goto IL_081f;
																																case 102:
																																case 150:
																																	goto IL_082d;
																																case 15:
																																	goto IL_088f;
																																case 48:
																																case 65:
																																	goto IL_089f;
																																case 43:
																																	goto IL_08aa;
																																case 3:
																																case 4:
																																case 7:
																																case 12:
																																case 17:
																																case 26:
																																case 34:
																																case 56:
																																case 60:
																																case 62:
																																case 68:
																																case 70:
																																case 74:
																																case 85:
																																case 89:
																																case 99:
																																case 104:
																																case 105:
																																case 109:
																																case 115:
																																case 121:
																																case 122:
																																case 125:
																																case 132:
																																case 134:
																																case 140:
																																case 143:
																																case 148:
																																case 152:
																																	goto end_IL_02e2;
																																case 5:
																																case 10:
																																case 14:
																																case 33:
																																case 38:
																																case 39:
																																case 47:
																																case 52:
																																case 55:
																																case 58:
																																case 66:
																																case 67:
																																case 91:
																																case 100:
																																case 103:
																																case 117:
																																case 120:
																																case 137:
																																	goto end_IL_036f;
																																case 78:
																																	goto end_IL_08c8;
																																case 21:
																																	goto end_IL_08db;
																																case 123:
																																	goto end_IL_08e5;
																																case 8:
																																	goto end_IL_08f0;
																																case 119:
																																case 142:
																																	goto end_IL_0900;
																																case 22:
																																	goto end_IL_0910;
																																case 93:
																																case 124:
																																	goto end_IL_0920;
																																case 63:
																																	goto end_IL_0930;
																																case 64:
																																	goto end_IL_0940;
																																case 2:
																																case 144:
																																	goto IL_095b;
																																}
																																continue;
																															}
																															num5--;
																															goto end_IL_036f;
																															continue;
																															end_IL_028b:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0393;
																												continue;
																												end_IL_02e2:
																												break;
																												IL_02e2:;
																											}
																											break;
																											IL_02f2:;
																										}
																										break;
																									}
																									goto IL_037a;
																									IL_03e2:
																									num5 -= 3;
																									goto end_IL_036f;
																									IL_037a:
																									if (6 > b)
																									{
																										goto IL_0385;
																									}
																									goto IL_03a3;
																									IL_0385:
																									if (5 < b)
																									{
																										break;
																									}
																									goto IL_0393;
																									IL_0393:
																									if (5 > b)
																									{
																										break;
																									}
																									goto IL_040d;
																									IL_040d:
																									array[num5] = 5;
																									goto IL_041b;
																									IL_041b:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_0433;
																									IL_0433:
																									num5++;
																									goto IL_0441;
																									IL_0441:
																									ptr2 += 8;
																									goto end_IL_036f;
																									IL_03a3:
																									((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_03e2;
																								}
																								break;
																							}
																							goto IL_0467;
																							IL_05db:
																							array[num5 - 2] = 0;
																							num = 59;
																							goto IL_05f8;
																							IL_0467:
																							if (4 <= b)
																							{
																								goto IL_0472;
																							}
																							goto IL_04b1;
																							IL_0472:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_0490;
																							IL_0490:
																							ptr2 += 8;
																							goto IL_049e;
																							IL_049e:
																							num5--;
																							goto end_IL_036f;
																							IL_04b1:
																							if (2 < b)
																							{
																								num = 54;
																								goto IL_04c5;
																							}
																							goto IL_052c;
																							IL_05f8:
																							num5--;
																							goto end_IL_036f;
																							IL_04c5:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_04d3;
																							IL_04d3:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_04e1;
																							IL_04e1:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							num = 61;
																							goto IL_0513;
																							IL_0513:
																							array[num5 - 1] = 5;
																							goto end_IL_036f;
																							IL_052c:
																							if (2 > b)
																							{
																								goto IL_0537;
																							}
																							goto IL_059b;
																							IL_0537:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0545;
																							IL_0545:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0553;
																							IL_0553:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_056c;
																							IL_056c:
																							array[num5] = 0;
																							goto IL_057a;
																							IL_057a:
																							num5++;
																							goto IL_0588;
																							IL_0588:
																							ptr2 += 8;
																							goto end_IL_036f;
																							IL_059b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05db;
																						}
																						break;
																					}
																					goto IL_03f5;
																					IL_03f5:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_036f;
																				}
																				break;
																			}
																			goto IL_060b;
																			IL_082d:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_088f;
																			IL_060b:
																			if (12 >= b)
																			{
																				goto IL_0619;
																			}
																			num = 42;
																			goto IL_07dc;
																			IL_0619:
																			if (12 > b)
																			{
																				goto IL_0627;
																			}
																			goto IL_0763;
																			IL_0627:
																			if (10 < b)
																			{
																				goto IL_0635;
																			}
																			goto IL_06c7;
																			IL_0635:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0643;
																			IL_0643:
																			if (11 > b)
																			{
																				num = 85;
																				break;
																			}
																			goto IL_065c;
																			IL_089f:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_08aa;
																			IL_065c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06a0;
																			IL_06a0:
																			array[num5 - 2] = 0;
																			goto IL_06b4;
																			IL_06b4:
																			num5--;
																			goto end_IL_036f;
																			IL_06c7:
																			if (10 > b)
																			{
																				goto IL_06d2;
																			}
																			goto IL_06fe;
																			IL_06d2:
																			if (9 < b)
																			{
																				num = 89;
																				break;
																			}
																			goto IL_06eb;
																			IL_08aa:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_06eb:
																			if (9 <= b)
																			{
																				goto end_IL_036f;
																			}
																			break;
																			IL_06fe:
																			array[num5] = 0;
																			goto IL_070c;
																			IL_070c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_072f;
																			IL_072f:
																			array2[num5] = null;
																			goto IL_0739;
																			IL_0739:
																			num5++;
																			goto IL_0747;
																			IL_0747:
																			ptr2 += 8;
																			num = 137;
																			goto end_IL_036f;
																			IL_0763:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 32;
																			goto IL_07ac;
																			IL_07ac:
																			array[num5 - 2] = 0;
																			goto IL_07c0;
																			IL_07c0:
																			num5--;
																			goto end_IL_036f;
																			IL_088f:
																			num5 -= 2;
																			goto end_IL_036f;
																			IL_07dc:
																			if (14 >= b)
																			{
																				goto IL_07ea;
																			}
																			goto IL_089f;
																			IL_07ea:
																			if (14 <= b)
																			{
																				goto IL_07f5;
																			}
																			goto IL_0811;
																			IL_07f5:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_036f;
																			IL_0811:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_081f;
																			IL_081f:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_082d;
																		}
																		break;
																		IL_033f:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_036f;
																continue;
																end_IL_034f:
																break;
															}
															continue;
															end_IL_035f:
															break;
														}
														continue;
														end_IL_036f:
														break;
													}
													continue;
												}
												goto IL_095b;
												IL_095b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08c8:
												break;
											}
											continue;
											end_IL_08db:
											break;
										}
										continue;
										end_IL_08e5:
										break;
									}
									continue;
									end_IL_08f0:
									break;
								}
								continue;
								end_IL_0900:
								break;
							}
							continue;
							end_IL_0910:
							break;
						}
						continue;
						end_IL_0920:
						break;
					}
					continue;
					end_IL_0930:
					break;
				}
				continue;
				end_IL_0940:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2)
	{
		int num = 81;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 20;
				while (true)
				{
					num = 86;
					while (true)
					{
						byte[] array = new byte[2];
						while (true)
						{
							object[] array2 = new object[2];
							num = 27;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ModeNOOPCreateOriginSchemeAccess.EndGetResponseSuppressFlowWindowsIdentity);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_022d:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0210:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0200:
																						if (8 >= b)
																						{
																							while (true)
																							{
																								IL_01f0:
																								if (8 > b)
																								{
																									while (true)
																									{
																										IL_01e0:
																										if (6 >= b)
																										{
																											num = 108;
																											while (true)
																											{
																												if (num != 108)
																												{
																													if (num != 1089)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 0:
																														goto IL_01e0;
																													case 42:
																														goto IL_01f0;
																													case 70:
																														goto IL_0200;
																													case 50:
																														goto IL_0210;
																													case 21:
																														goto end_IL_0210;
																													case 82:
																														goto IL_022d;
																													case 94:
																														goto end_IL_022d;
																													case 57:
																													case 96:
																														goto end_IL_023d;
																													case 15:
																														goto IL_0258;
																													case 46:
																														goto IL_0266;
																													case 67:
																														goto IL_0279;
																													case 26:
																														goto end_IL_01cd;
																													case 51:
																														goto IL_028f;
																													case 29:
																													case 65:
																														goto IL_02a2;
																													case 7:
																														goto IL_02ad;
																													case 11:
																													case 48:
																														goto IL_02c0;
																													case 66:
																														goto IL_02ce;
																													case 43:
																														goto IL_02f1;
																													case 58:
																														goto IL_02fb;
																													case 56:
																														goto IL_0309;
																													case 75:
																														goto IL_031c;
																													case 74:
																														goto IL_032a;
																													case 77:
																														goto IL_033d;
																													case 83:
																														goto IL_034b;
																													case 36:
																													case 85:
																														goto IL_035e;
																													case 5:
																														goto IL_0387;
																													case 32:
																														goto IL_0395;
																													case 25:
																													case 88:
																														goto IL_03a8;
																													case 14:
																													case 90:
																														goto IL_03c0;
																													case 71:
																														goto IL_03e3;
																													case 84:
																														goto IL_03f1;
																													case 13:
																														goto IL_03ff;
																													case 76:
																													case 91:
																														goto IL_041b;
																													case 64:
																														goto IL_0434;
																													case 49:
																														goto IL_0442;
																													case 53:
																														goto IL_0450;
																													case 9:
																													case 99:
																														goto IL_0463;
																													case 100:
																														goto IL_04c5;
																													case 4:
																													case 68:
																														goto IL_04e6;
																													case 61:
																														goto IL_0526;
																													case 79:
																														goto IL_053a;
																													case 30:
																														goto IL_0553;
																													case 39:
																														goto IL_055e;
																													case 44:
																													case 78:
																														goto IL_0569;
																													case 37:
																														goto IL_0582;
																													case 62:
																														goto IL_058d;
																													case 2:
																													case 10:
																													case 12:
																													case 18:
																													case 19:
																													case 22:
																													case 23:
																													case 24:
																													case 31:
																													case 34:
																													case 38:
																													case 41:
																													case 47:
																													case 54:
																													case 55:
																													case 63:
																													case 69:
																													case 72:
																													case 98:
																													case 101:
																														goto end_IL_021d;
																													case 1:
																													case 8:
																													case 17:
																													case 28:
																													case 33:
																													case 35:
																													case 40:
																													case 45:
																													case 87:
																													case 92:
																													case 93:
																													case 95:
																													case 97:
																														goto end_IL_024d;
																													case 73:
																														goto end_IL_05ab;
																													case 60:
																														goto end_IL_05be;
																													case 3:
																														goto end_IL_05c8;
																													case 89:
																														goto end_IL_05d3;
																													case 16:
																													case 27:
																														goto end_IL_05e8;
																													case 59:
																														goto end_IL_05f8;
																													case 86:
																														goto end_IL_0608;
																													case 20:
																														goto end_IL_0621;
																													case 80:
																														goto end_IL_0631;
																													case 81:
																														goto end_IL_063c;
																													case 6:
																													case 52:
																														goto IL_0660;
																													}
																													continue;
																												}
																												if (6 > b)
																												{
																													goto end_IL_021d;
																												}
																												goto IL_04e6;
																												IL_04e6:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_0526;
																												IL_053a:
																												num5--;
																												num = 95;
																												goto end_IL_024d;
																												IL_0526:
																												array[num5 - 2] = 0;
																												goto IL_053a;
																												continue;
																												end_IL_01cd:
																												break;
																											}
																											break;
																										}
																										goto IL_0258;
																										IL_03f1:
																										num5++;
																										goto IL_03ff;
																										IL_03ff:
																										ptr2 += 8;
																										num = 93;
																										goto end_IL_024d;
																										IL_0258:
																										if (7 < b)
																										{
																											goto end_IL_021d;
																										}
																										goto IL_0266;
																										IL_0266:
																										if (7 > b)
																										{
																											goto end_IL_021d;
																										}
																										goto IL_03c0;
																										IL_03c0:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																										goto IL_03e3;
																										IL_03e3:
																										array[num5] = 0;
																										goto IL_03f1;
																									}
																									break;
																								}
																								goto IL_0463;
																								IL_04c5:
																								num5 -= 2;
																								goto end_IL_024d;
																								IL_0463:
																								ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_04c5;
																							}
																							break;
																						}
																						goto IL_0553;
																						IL_058d:
																						if (10 > b)
																						{
																						}
																						goto end_IL_021d;
																						IL_0553:
																						if (9 >= b)
																						{
																							goto IL_055e;
																						}
																						goto IL_0582;
																						IL_055e:
																						if (9 > b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_0569;
																						IL_0569:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_024d;
																						IL_0582:
																						if (10 < b)
																						{
																							goto end_IL_021d;
																						}
																						goto IL_058d;
																					}
																					goto IL_0284;
																				}
																				goto IL_0279;
																				IL_0309:
																				ptr2 += 8;
																				goto end_IL_024d;
																				IL_0279:
																				if (5 > b)
																				{
																					goto IL_0284;
																				}
																				goto IL_02c0;
																				IL_0284:
																				if (2 >= b)
																				{
																					goto IL_028f;
																				}
																				goto IL_02a2;
																				IL_028f:
																				if (2 > b)
																				{
																					goto IL_033d;
																				}
																				goto IL_035e;
																				IL_033d:
																				if (1 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_034b;
																				IL_034b:
																				if (1 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_041b;
																				IL_041b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0434;
																				IL_0434:
																				array[num5] = 0;
																				goto IL_0442;
																				IL_0442:
																				num5++;
																				goto IL_0450;
																				IL_0450:
																				ptr2 += 8;
																				goto end_IL_024d;
																				IL_035e:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0387;
																				IL_0387:
																				ptr2 += 8;
																				goto IL_0395;
																				IL_0395:
																				num5--;
																				goto end_IL_024d;
																				IL_02a2:
																				if (3 >= b)
																				{
																					goto IL_02ad;
																				}
																				goto IL_031c;
																				IL_02ad:
																				if (3 > b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_03a8;
																				IL_03a8:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_024d;
																				IL_031c:
																				if (4 < b)
																				{
																					goto end_IL_021d;
																				}
																				goto IL_032a;
																				IL_032a:
																				if (4 <= b)
																				{
																					goto end_IL_024d;
																				}
																				goto end_IL_021d;
																				IL_02c0:
																				array[num5] = 0;
																				goto IL_02ce;
																				IL_02ce:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_02f1;
																				IL_02f1:
																				array2[num5] = null;
																				goto IL_02fb;
																				IL_02fb:
																				num5++;
																				goto IL_0309;
																				continue;
																				end_IL_0210:
																				break;
																			}
																			continue;
																			end_IL_021d:
																			break;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_024d;
																	continue;
																	end_IL_022d:
																	break;
																}
																continue;
																end_IL_023d:
																break;
															}
															continue;
															end_IL_024d:
															break;
														}
														continue;
													}
													goto IL_0660;
													IL_0660:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05ab:
													break;
												}
												continue;
												end_IL_05be:
												break;
											}
											continue;
											end_IL_05c8:
											break;
										}
										continue;
										end_IL_05d3:
										break;
									}
									continue;
									end_IL_05e8:
									break;
								}
								continue;
								end_IL_05f8:
								break;
							}
							continue;
							end_IL_0608:
							break;
						}
						continue;
						end_IL_0621:
						break;
					}
					continue;
					end_IL_0631:
					break;
				}
				continue;
				end_IL_063c:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_2)
	{
		int num = 61;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					num = 73;
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									num = 3;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetTypeAttrgetRegisteredHandlers.PrevStacksetArgs);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 84;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02d1:
																if (b >= 1)
																{
																	while (b <= 13)
																	{
																		while (true)
																		{
																			IL_02b1:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_02a1:
																					if (10 >= b)
																					{
																						while (true)
																						{
																							IL_0291:
																							if (10 > b)
																							{
																								while (true)
																								{
																									IL_0284:
																									if (8 < b)
																									{
																										while (9 >= b)
																										{
																											num = 4;
																											while (9 <= b)
																											{
																												num = 136;
																												while (true)
																												{
																													if (num != 136)
																													{
																														if (num != 1117)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 4:
																															goto IL_025e;
																														case 105:
																															goto IL_0271;
																														case 16:
																														case 27:
																															goto IL_0284;
																														case 80:
																															goto end_IL_024b;
																														case 42:
																														case 103:
																															goto IL_02a1;
																														case 108:
																															goto IL_02b1;
																														case 43:
																															goto IL_02c1;
																														case 88:
																															goto IL_02d1;
																														case 57:
																															goto end_IL_02d1;
																														case 25:
																														case 34:
																															goto end_IL_02e1;
																														case 19:
																															goto IL_02fc;
																														case 50:
																														case 90:
																															goto IL_030a;
																														case 102:
																															goto IL_032d;
																														case 109:
																															goto IL_033b;
																														case 66:
																															goto IL_0349;
																														case 28:
																															goto IL_035c;
																														case 129:
																															goto IL_03be;
																														case 9:
																														case 49:
																															goto IL_03d1;
																														case 115:
																															goto IL_03df;
																														case 74:
																															goto IL_0403;
																														case 26:
																															goto IL_0411;
																														case 97:
																															goto IL_0424;
																														case 13:
																														case 89:
																															goto IL_042f;
																														case 99:
																															goto IL_043d;
																														case 10:
																															goto IL_0450;
																														case 79:
																														case 124:
																															goto IL_045b;
																														case 106:
																															goto IL_0469;
																														case 29:
																														case 121:
																															goto IL_0477;
																														case 12:
																														case 104:
																															goto IL_048a;
																														case 58:
																															goto IL_04a6;
																														case 53:
																														case 123:
																															goto IL_04b4;
																														case 69:
																															goto IL_04c2;
																														case 14:
																														case 78:
																															goto IL_04d0;
																														case 15:
																															goto IL_04db;
																														case 23:
																														case 117:
																															goto IL_04e9;
																														case 45:
																															goto IL_0502;
																														case 100:
																															goto IL_0519;
																														case 120:
																															goto IL_0527;
																														case 35:
																															goto IL_053a;
																														case 86:
																															goto IL_0548;
																														case 1:
																														case 118:
																															goto IL_0556;
																														case 116:
																															goto IL_057f;
																														case 67:
																															goto IL_058d;
																														case 46:
																														case 112:
																															goto IL_05a0;
																														case 81:
																															goto IL_05b8;
																														case 55:
																															goto IL_05c6;
																														case 44:
																														case 68:
																															goto IL_05d1;
																														case 127:
																															goto IL_05df;
																														case 30:
																														case 77:
																															goto IL_05f2;
																														case 39:
																															goto IL_0609;
																														case 126:
																															goto IL_062c;
																														case 5:
																															goto IL_0636;
																														case 75:
																															goto IL_0644;
																														case 72:
																															goto IL_0657;
																														case 52:
																															goto IL_0665;
																														case 54:
																														case 62:
																															goto IL_0673;
																														case 59:
																															goto IL_06bc;
																														case 76:
																															goto IL_06d0;
																														case 87:
																														case 113:
																															goto IL_06e3;
																														case 11:
																															goto IL_0723;
																														case 65:
																															goto IL_0737;
																														case 18:
																														case 24:
																														case 33:
																														case 36:
																														case 41:
																														case 47:
																														case 51:
																														case 71:
																														case 82:
																														case 91:
																														case 92:
																														case 93:
																														case 94:
																														case 95:
																														case 96:
																														case 98:
																														case 101:
																														case 107:
																														case 111:
																														case 122:
																														case 125:
																														case 128:
																															goto end_IL_025e;
																														case 0:
																														case 2:
																														case 7:
																														case 17:
																														case 21:
																														case 31:
																														case 32:
																														case 38:
																														case 40:
																														case 48:
																														case 63:
																														case 83:
																														case 84:
																														case 110:
																														case 114:
																														case 119:
																															goto end_IL_02f1;
																														case 64:
																															goto end_IL_0763;
																														case 3:
																															goto end_IL_0776;
																														case 85:
																															goto end_IL_0789;
																														case 6:
																															goto end_IL_0794;
																														case 8:
																														case 37:
																															goto end_IL_07b2;
																														case 73:
																															goto end_IL_07c2;
																														case 22:
																														case 56:
																															goto end_IL_07d2;
																														case 60:
																															goto end_IL_07e2;
																														case 61:
																															goto end_IL_07fb;
																														case 20:
																														case 70:
																															goto IL_0816;
																														}
																														continue;
																													}
																													goto IL_035c;
																													IL_035c:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_03be;
																													IL_03be:
																													num5 -= 2;
																													goto end_IL_02f1;
																													continue;
																													end_IL_024b:
																													break;
																												}
																												goto IL_0291;
																												continue;
																												end_IL_025e:
																												break;
																												IL_025e:;
																											}
																											break;
																											IL_0271:;
																										}
																										break;
																									}
																									goto IL_02fc;
																									IL_0349:
																									ptr2 += 8;
																									goto end_IL_02f1;
																									IL_02fc:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_030a;
																									IL_030a:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_032d;
																									IL_032d:
																									array[num5] = 0;
																									goto IL_033b;
																									IL_033b:
																									num5++;
																									goto IL_0349;
																								}
																								break;
																							}
																							goto IL_03d1;
																							IL_0411:
																							ptr2 += 8;
																							goto end_IL_02f1;
																							IL_03d1:
																							array[num5] = 0;
																							goto IL_03df;
																							IL_03df:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)setUserQuotaPublicKey[*(int*)(ptr2 + num3)])();
																							goto IL_0403;
																							IL_0403:
																							num5++;
																							goto IL_0411;
																						}
																						break;
																					}
																					goto IL_0424;
																					IL_048a:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_02f1;
																					IL_0424:
																					if (12 < b)
																					{
																						goto IL_042f;
																					}
																					goto IL_0450;
																					IL_042f:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_043d;
																					IL_043d:
																					if (13 <= b)
																					{
																					}
																					break;
																					IL_0450:
																					if (12 > b)
																					{
																						goto IL_045b;
																					}
																					goto IL_048a;
																					IL_045b:
																					if (11 < b)
																					{
																						break;
																					}
																					goto IL_0469;
																					IL_0469:
																					if (11 > b)
																					{
																						break;
																					}
																					goto IL_0477;
																					IL_0477:
																					num5--;
																					goto end_IL_02f1;
																				}
																				break;
																			}
																			goto IL_04a6;
																			IL_0737:
																			num5--;
																			num = 119;
																			goto end_IL_02f1;
																			IL_04a6:
																			if (7 > b)
																			{
																				goto IL_04b4;
																			}
																			goto IL_06e3;
																			IL_04b4:
																			if (3 >= b)
																			{
																				goto IL_04c2;
																			}
																			goto IL_05b8;
																			IL_04c2:
																			if (3 > b)
																			{
																				goto IL_04d0;
																			}
																			goto IL_05a0;
																			IL_04d0:
																			if (1 >= b)
																			{
																				goto IL_04db;
																			}
																			goto IL_053a;
																			IL_04db:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_04e9;
																			IL_04e9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0502;
																			IL_0502:
																			array[num5] = 0;
																			num = 100;
																			goto IL_0519;
																			IL_0519:
																			num5++;
																			goto IL_0527;
																			IL_0527:
																			ptr2 += 8;
																			goto end_IL_02f1;
																			IL_053a:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_0548;
																			IL_0548:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_0556;
																			IL_0556:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_057f;
																			IL_057f:
																			ptr2 += 8;
																			goto IL_058d;
																			IL_058d:
																			num5--;
																			goto end_IL_02f1;
																			IL_05a0:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_02f1;
																			IL_05b8:
																			if (5 >= b)
																			{
																				goto IL_05c6;
																			}
																			goto IL_0657;
																			IL_05c6:
																			if (5 > b)
																			{
																				goto IL_05d1;
																			}
																			goto IL_05f2;
																			IL_05d1:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_05df;
																			IL_05df:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_02f1;
																			IL_05f2:
																			array[num5] = 0;
																			num = 39;
																			goto IL_0609;
																			IL_0609:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_062c;
																			IL_062c:
																			array2[num5] = null;
																			goto IL_0636;
																			IL_0636:
																			num5++;
																			goto IL_0644;
																			IL_0644:
																			ptr2 += 8;
																			goto end_IL_02f1;
																			IL_0657:
																			if (6 < b)
																			{
																				break;
																			}
																			goto IL_0665;
																			IL_0665:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0673;
																			IL_0673:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 59;
																			goto IL_06bc;
																			IL_06bc:
																			array[num5 - 2] = 0;
																			goto IL_06d0;
																			IL_06d0:
																			num5--;
																			goto end_IL_02f1;
																			IL_06e3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0723;
																			IL_0723:
																			array[num5 - 2] = 0;
																			goto IL_0737;
																		}
																		break;
																		IL_02c1:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02f1;
																continue;
																end_IL_02d1:
																break;
															}
															continue;
															end_IL_02e1:
															break;
														}
														continue;
														end_IL_02f1:
														break;
													}
													continue;
												}
												goto IL_0816;
												IL_0816:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0763:
												break;
											}
											continue;
											end_IL_0776:
											break;
										}
										continue;
										end_IL_0789:
										break;
									}
									continue;
									end_IL_0794:
									break;
								}
								continue;
								end_IL_07b2:
								break;
							}
							continue;
							end_IL_07c2:
							break;
						}
						continue;
						end_IL_07d2:
						break;
					}
					continue;
					end_IL_07e2:
					break;
				}
				continue;
				end_IL_07fb:
				break;
			}
		}
	}

	static Class191()
	{
		int num = 2;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_0054:
				Class300.smethod_0();
				while (true)
				{
					IL_0042:
					num = 11;
					while (true)
					{
						if (num != 11)
						{
							if (num != 992)
							{
								break;
							}
							switch (num)
							{
							case 0:
							case 3:
							case 4:
								goto IL_0042;
							case 1:
								goto IL_0054;
							case 2:
								goto end_IL_0035;
							}
							continue;
						}
						return;
						continue;
						end_IL_0035:
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
