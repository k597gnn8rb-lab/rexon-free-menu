using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("30 FPS Lock", "World", "Locks frame rate to ~30fps.", false, 40, ModType.const_0, false)]
internal class Class19 : MonoBehaviour
{
	private static double double_0;

	private static double double_1;

	private static float float_0;

	private static float float_1;

	private static bool bool_0;

	private static IntPtr[] STATSTGAssembly;

	private unsafe void Update()
	{
		int num = 71;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TryRemoveClaimCMSCOMSERVERFLAGISCLRCLASS.MutexRightssetReadTimeout);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 == 1)
												{
													return;
												}
												while (true)
												{
													byte b = *ptr2;
													while (true)
													{
														ptr2++;
														while (true)
														{
															IL_037d:
															if (b >= 1)
															{
																while (b <= 22)
																{
																	while (true)
																	{
																		IL_035d:
																		if (11 < b)
																		{
																			while (true)
																			{
																				IL_0350:
																				if (17 < b)
																				{
																					while (true)
																					{
																						IL_0340:
																						if (20 >= b)
																						{
																							while (true)
																							{
																								IL_0330:
																								if (20 <= b)
																								{
																									num = 192;
																									while (true)
																									{
																										if (num != 192)
																										{
																											if (num != 1173)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 93:
																												goto IL_0330;
																											case 63:
																												goto IL_0340;
																											case 60:
																												goto IL_0350;
																											case 167:
																												goto IL_035d;
																											case 15:
																												goto end_IL_035d;
																											case 3:
																												goto IL_037d;
																											case 114:
																												goto end_IL_037d;
																											case 43:
																											case 52:
																												goto end_IL_038d;
																											case 30:
																												goto IL_03a8;
																											case 38:
																												goto IL_03b8;
																											case 82:
																												goto IL_03c5;
																											case 74:
																											case 90:
																												goto IL_03d8;
																											case 77:
																												goto IL_0418;
																											case 103:
																												goto IL_0431;
																											case 35:
																												goto IL_043c;
																											case 106:
																												goto IL_0447;
																											case 110:
																												goto IL_0455;
																											case 113:
																												goto IL_0468;
																											case 122:
																												goto IL_0484;
																											case 123:
																												goto IL_0497;
																											case 79:
																												goto IL_04a2;
																											case 108:
																												goto IL_04b0;
																											case 61:
																											case 81:
																												goto IL_04be;
																											case 45:
																											case 89:
																												goto IL_04dc;
																											case 91:
																												goto IL_051d;
																											case 130:
																												goto IL_0536;
																											case 31:
																											case 137:
																												goto IL_0549;
																											case 124:
																												goto IL_0562;
																											case 67:
																												goto IL_0570;
																											case 7:
																												goto IL_057e;
																											case 142:
																												goto IL_0591;
																											case 135:
																												goto IL_059f;
																											case 37:
																											case 85:
																												goto IL_05ad;
																											case 147:
																												goto IL_05c5;
																											case 11:
																												goto IL_05d3;
																											case 13:
																												goto IL_05e1;
																											case 151:
																												goto IL_05f4;
																											case 10:
																											case 156:
																												goto IL_0607;
																											case 97:
																												goto IL_0659;
																											case 169:
																											case 175:
																												goto IL_066c;
																											case 101:
																												goto IL_0680;
																											case 143:
																												goto IL_06bf;
																											case 180:
																												goto IL_06d2;
																											case 100:
																											case 150:
																												goto IL_06e0;
																											case 162:
																												goto IL_070a;
																											case 170:
																												goto IL_0718;
																											case 129:
																												goto IL_072b;
																											case 125:
																												goto IL_0756;
																											case 131:
																												goto IL_076f;
																											case 20:
																												goto IL_077a;
																											case 24:
																											case 166:
																												goto IL_0788;
																											case 57:
																												goto IL_07a4;
																											case 27:
																												goto IL_07b2;
																											case 144:
																												goto IL_07ce;
																											case 2:
																												goto end_IL_031d;
																											case 25:
																												goto IL_07ea;
																											case 51:
																												goto IL_07f8;
																											case 133:
																												goto IL_0806;
																											case 50:
																												goto IL_0811;
																											case 32:
																											case 53:
																												goto IL_081f;
																											case 141:
																												goto IL_085f;
																											case 28:
																												goto IL_0873;
																											case 96:
																												goto IL_0886;
																											case 102:
																												goto IL_0894;
																											case 33:
																											case 152:
																												goto IL_08a2;
																											case 138:
																												goto IL_08e2;
																											case 92:
																												goto IL_08f6;
																											case 139:
																											case 171:
																												goto IL_0909;
																											case 42:
																												goto IL_091c;
																											case 161:
																												goto IL_0927;
																											case 4:
																											case 94:
																												goto IL_0935;
																											case 105:
																												goto IL_0975;
																											case 117:
																												goto IL_0989;
																											case 159:
																												goto IL_09a5;
																											case 136:
																												goto IL_09b3;
																											case 40:
																											case 174:
																												goto IL_09c1;
																											case 119:
																												goto IL_0a23;
																											case 86:
																												goto IL_0a36;
																											case 116:
																											case 179:
																												goto IL_0a41;
																											case 84:
																												goto IL_0a81;
																											case 14:
																												goto IL_0a95;
																											case 55:
																												goto IL_0aa8;
																											case 112:
																												goto IL_0ab6;
																											case 36:
																											case 149:
																												goto IL_0ac1;
																											case 6:
																												goto IL_0b01;
																											case 22:
																												goto IL_0b15;
																											case 75:
																												goto IL_0b28;
																											case 158:
																												goto IL_0b36;
																											case 104:
																											case 126:
																												goto IL_0b44;
																											case 1:
																												goto IL_0b5d;
																											case 95:
																												goto IL_0b6b;
																											case 173:
																												goto IL_0b79;
																											case 146:
																												goto IL_0b8c;
																											case 44:
																												goto IL_0b97;
																											case 26:
																											case 168:
																												goto IL_0ba5;
																											case 69:
																												goto IL_0bce;
																											case 46:
																												goto IL_0bdc;
																											case 59:
																												goto IL_0bef;
																											case 56:
																												goto IL_0bfa;
																											case 39:
																											case 160:
																												goto IL_0c05;
																											case 62:
																												goto IL_0c13;
																											case 172:
																												goto IL_0c36;
																											case 165:
																												goto IL_0c40;
																											case 164:
																												goto IL_0c4e;
																											case 5:
																											case 9:
																											case 12:
																											case 17:
																											case 23:
																											case 34:
																											case 41:
																											case 54:
																											case 58:
																											case 64:
																											case 73:
																											case 80:
																											case 83:
																											case 88:
																											case 98:
																											case 99:
																											case 111:
																											case 121:
																											case 132:
																											case 140:
																											case 145:
																											case 163:
																											case 177:
																											case 183:
																											case 185:
																												goto end_IL_036d;
																											case 0:
																											case 8:
																											case 18:
																											case 19:
																											case 21:
																											case 29:
																											case 47:
																											case 48:
																											case 49:
																											case 68:
																											case 72:
																											case 76:
																											case 78:
																											case 107:
																											case 118:
																											case 120:
																											case 127:
																											case 128:
																											case 153:
																											case 155:
																											case 157:
																											case 176:
																											case 178:
																											case 181:
																											case 182:
																												goto end_IL_039d;
																											case 154:
																												goto end_IL_0c71;
																											case 134:
																												goto end_IL_0c84;
																											case 109:
																												goto end_IL_0c8e;
																											case 87:
																											case 115:
																												goto end_IL_0c99;
																											case 66:
																												goto end_IL_0ca9;
																											case 184:
																												goto end_IL_0cb9;
																											case 148:
																												goto end_IL_0cc9;
																											case 70:
																												goto end_IL_0cd9;
																											case 71:
																												goto end_IL_0ce9;
																											case 16:
																											case 65:
																												return;
																											}
																											continue;
																										}
																										goto IL_072b;
																										IL_072b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0756;
																										IL_0756:
																										array[num6 - 1] = 0;
																										goto end_IL_039d;
																										continue;
																										end_IL_031d:
																										break;
																									}
																									break;
																								}
																								goto IL_03a8;
																								IL_070a:
																								num6--;
																								goto IL_0718;
																								IL_0718:
																								ptr2 += 8;
																								goto end_IL_039d;
																								IL_03a8:
																								if (18 >= b)
																								{
																									goto IL_03c5;
																								}
																								goto IL_0484;
																								IL_03c5:
																								if (18 > b)
																								{
																									goto end_IL_036d;
																								}
																								goto IL_066c;
																								IL_066c:
																								array[num6 - 1] = 0;
																								goto IL_0680;
																								IL_0680:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)STATSTGAssembly[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_06bf;
																								IL_06bf:
																								ptr2 += 8;
																								goto end_IL_039d;
																								IL_0484:
																								if (19 < b)
																								{
																									goto end_IL_036d;
																								}
																								goto IL_06d2;
																								IL_06d2:
																								if (19 > b)
																								{
																									goto end_IL_036d;
																								}
																								goto IL_06e0;
																								IL_06e0:
																								((delegate*<int, void>)STATSTGAssembly[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																								goto IL_070a;
																							}
																							break;
																						}
																						goto IL_076f;
																						IL_07b2:
																						if (22 > b)
																						{
																						}
																						goto end_IL_036d;
																						IL_076f:
																						if (21 >= b)
																						{
																							goto IL_077a;
																						}
																						goto IL_07a4;
																						IL_077a:
																						if (21 > b)
																						{
																							goto end_IL_036d;
																						}
																						goto IL_0788;
																						IL_0788:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_039d;
																						IL_07a4:
																						if (22 < b)
																						{
																							goto end_IL_036d;
																						}
																						goto IL_07b2;
																					}
																					break;
																				}
																				goto IL_03b8;
																				IL_0418:
																				array[num6 - 2] = 3;
																				goto IL_0536;
																				IL_03b8:
																				if (17 <= b)
																				{
																					goto IL_03d8;
																				}
																				goto IL_0431;
																				IL_0431:
																				if (14 < b)
																				{
																					goto IL_043c;
																				}
																				goto IL_0497;
																				IL_043c:
																				if (15 < b)
																				{
																					goto IL_0447;
																				}
																				goto IL_0468;
																				IL_0447:
																				if (16 < b)
																				{
																					goto end_IL_036d;
																				}
																				goto IL_0455;
																				IL_0455:
																				if (16 > b)
																				{
																					goto end_IL_036d;
																				}
																				goto IL_0549;
																				IL_0549:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_0562;
																				IL_0562:
																				array[num6] = 3;
																				goto IL_0570;
																				IL_0570:
																				num6++;
																				goto IL_057e;
																				IL_057e:
																				ptr2 += 16;
																				goto end_IL_039d;
																				IL_0468:
																				if (15 > b)
																				{
																					goto end_IL_036d;
																				}
																				num = 10;
																				goto IL_0607;
																				IL_0536:
																				num6--;
																				goto end_IL_039d;
																				IL_0607:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0659;
																				IL_0659:
																				num6--;
																				goto end_IL_039d;
																				IL_0497:
																				if (14 > b)
																				{
																					goto IL_04a2;
																				}
																				goto IL_04dc;
																				IL_04a2:
																				if (12 >= b)
																				{
																					goto IL_04b0;
																				}
																				goto IL_0591;
																				IL_04b0:
																				if (12 > b)
																				{
																					goto end_IL_036d;
																				}
																				goto IL_04be;
																				IL_04be:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_05c5;
																				IL_05c5:
																				array[num6] = 1;
																				goto IL_05d3;
																				IL_05d3:
																				num6++;
																				goto IL_05e1;
																				IL_05e1:
																				ptr2 += 16;
																				goto end_IL_039d;
																				IL_0591:
																				if (13 < b)
																				{
																					goto end_IL_036d;
																				}
																				goto IL_059f;
																				IL_059f:
																				if (13 > b)
																				{
																					goto end_IL_036d;
																				}
																				goto IL_05ad;
																				IL_05ad:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_039d;
																				IL_04dc:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_051d;
																				IL_051d:
																				array[num6 - 2] = 0;
																				goto IL_05f4;
																				IL_05f4:
																				num6--;
																				goto end_IL_039d;
																				IL_03d8:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0418;
																			}
																			goto IL_07dc;
																		}
																		num = 144;
																		goto IL_07ce;
																		IL_0c40:
																		num6++;
																		goto IL_0c4e;
																		IL_0c4e:
																		ptr2 += 8;
																		goto end_IL_039d;
																		IL_07ce:
																		if (11 <= b)
																		{
																			goto end_IL_039d;
																		}
																		goto IL_07dc;
																		IL_07dc:
																		if (5 < b)
																		{
																			goto IL_07ea;
																		}
																		goto IL_0a36;
																		IL_07ea:
																		if (8 >= b)
																		{
																			goto IL_07f8;
																		}
																		goto IL_091c;
																		IL_07f8:
																		if (8 > b)
																		{
																			goto IL_0806;
																		}
																		goto IL_0909;
																		IL_0806:
																		if (6 >= b)
																		{
																			goto IL_0811;
																		}
																		goto IL_0886;
																		IL_0811:
																		if (6 > b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_081f;
																		IL_081f:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_085f;
																		IL_085f:
																		array[num6 - 2] = 0;
																		goto IL_0873;
																		IL_0873:
																		num6--;
																		goto end_IL_039d;
																		IL_0886:
																		if (7 < b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_0894;
																		IL_0894:
																		if (7 > b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_08a2;
																		IL_08a2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_08e2;
																		IL_08e2:
																		array[num6 - 2] = 0;
																		goto IL_08f6;
																		IL_08f6:
																		num6--;
																		goto end_IL_039d;
																		IL_0909:
																		num6--;
																		goto end_IL_039d;
																		IL_091c:
																		if (9 >= b)
																		{
																			goto IL_0927;
																		}
																		goto IL_09a5;
																		IL_0927:
																		if (9 > b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_0935;
																		IL_0935:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0975;
																		IL_0975:
																		array[num6 - 2] = 0;
																		goto IL_0989;
																		IL_0989:
																		num6--;
																		num = 49;
																		goto end_IL_039d;
																		IL_09a5:
																		if (10 < b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_09b3;
																		IL_09b3:
																		if (10 > b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_09c1;
																		IL_09c1:
																		ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																		goto IL_0a23;
																		IL_0a23:
																		num6 -= 2;
																		goto end_IL_039d;
																		IL_0a36:
																		if (5 <= b)
																		{
																			goto IL_0a41;
																		}
																		goto IL_0aa8;
																		IL_0a41:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0a81;
																		IL_0a81:
																		array[num6 - 2] = 0;
																		goto IL_0a95;
																		IL_0a95:
																		num6--;
																		goto end_IL_039d;
																		IL_0aa8:
																		if (2 >= b)
																		{
																			goto IL_0ab6;
																		}
																		goto IL_0b8c;
																		IL_0ab6:
																		if (2 <= b)
																		{
																			goto IL_0ac1;
																		}
																		goto IL_0b28;
																		IL_0ac1:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0b01;
																		IL_0b01:
																		array[num6 - 2] = 0;
																		goto IL_0b15;
																		IL_0b15:
																		num6--;
																		goto end_IL_039d;
																		IL_0b28:
																		if (1 < b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_0b36;
																		IL_0b36:
																		if (1 > b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_0b44;
																		IL_0b44:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0b5d;
																		IL_0b5d:
																		array[num6] = 0;
																		goto IL_0b6b;
																		IL_0b6b:
																		num6++;
																		goto IL_0b79;
																		IL_0b79:
																		ptr2 += 8;
																		goto end_IL_039d;
																		IL_0b8c:
																		if (3 >= b)
																		{
																			goto IL_0b97;
																		}
																		goto IL_0bef;
																		IL_0b97:
																		if (3 > b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_0ba5;
																		IL_0ba5:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																		goto IL_0bce;
																		IL_0bce:
																		ptr2 += 8;
																		goto IL_0bdc;
																		IL_0bdc:
																		num6--;
																		goto end_IL_039d;
																		IL_0bef:
																		if (4 < b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_0bfa;
																		IL_0bfa:
																		if (4 > b)
																		{
																			goto end_IL_036d;
																		}
																		goto IL_0c05;
																		IL_0c05:
																		array[num6] = 0;
																		goto IL_0c13;
																		IL_0c13:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_0c36;
																		IL_0c36:
																		array2[num6] = null;
																		goto IL_0c40;
																		continue;
																		end_IL_035d:
																		break;
																	}
																	continue;
																	end_IL_036d:
																	break;
																}
															}
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto end_IL_039d;
															continue;
															end_IL_037d:
															break;
														}
														continue;
														end_IL_038d:
														break;
													}
													continue;
													end_IL_039d:
													break;
												}
												continue;
												end_IL_0c71:
												break;
											}
											continue;
											end_IL_0c84:
											break;
										}
										continue;
										end_IL_0c8e:
										break;
									}
									continue;
									end_IL_0c99:
									break;
								}
								continue;
								end_IL_0ca9:
								break;
							}
							continue;
							end_IL_0cb9:
							break;
						}
						continue;
						end_IL_0cc9:
						break;
					}
					continue;
					end_IL_0cd9:
					break;
				}
				continue;
				end_IL_0ce9:
				break;
			}
		}
	}

	public Class19()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0()
	{
		int num = 114;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref JustificationParallelInvokeBegin.ErasCobol);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0298:
																if (b < 1)
																{
																	num = 154;
																	while (num != 154)
																	{
																		if (num != 1135)
																		{
																			goto IL_0480;
																		}
																		switch (num)
																		{
																		case 17:
																			goto IL_0298;
																		case 73:
																			goto end_IL_0298;
																		case 40:
																		case 136:
																			goto end_IL_02a8;
																		case 68:
																			goto IL_02c3;
																		case 130:
																			goto IL_02d1;
																		case 87:
																			goto IL_02df;
																		case 57:
																			goto IL_02ed;
																		case 82:
																			goto IL_02fb;
																		case 26:
																		case 115:
																			goto IL_0309;
																		case 51:
																			goto IL_0317;
																		case 63:
																		case 89:
																			goto IL_0322;
																		case 120:
																			goto IL_0330;
																		case 16:
																		case 38:
																			goto IL_033e;
																		case 85:
																			goto IL_0357;
																		case 83:
																			goto IL_0365;
																		case 107:
																			goto IL_0373;
																		case 1:
																		case 79:
																			goto IL_0386;
																		case 117:
																			goto IL_03c6;
																		case 55:
																			goto IL_03da;
																		case 111:
																			goto IL_03ed;
																		case 116:
																			goto IL_03fb;
																		case 47:
																		case 76:
																			goto IL_0409;
																		case 33:
																			goto IL_0448;
																		case 30:
																			goto IL_0464;
																		case 71:
																		case 94:
																			goto IL_0472;
																		case 81:
																			goto IL_0480;
																		case 54:
																		case 64:
																			goto IL_048e;
																		case 106:
																			goto IL_049c;
																		case 6:
																		case 43:
																			goto IL_04aa;
																		case 2:
																			goto IL_050c;
																		case 36:
																		case 48:
																			goto IL_051f;
																		case 42:
																		case 80:
																			goto IL_053b;
																		case 72:
																			goto IL_0549;
																		case 67:
																			goto IL_055c;
																		case 78:
																		case 105:
																			goto IL_056a;
																		case 112:
																			goto IL_0578;
																		case 13:
																			goto IL_0583;
																		case 39:
																			goto IL_0591;
																		case 9:
																		case 121:
																			goto IL_05ad;
																		case 41:
																			goto IL_05bb;
																		case 95:
																			goto IL_05de;
																		case 93:
																			goto IL_05e8;
																		case 108:
																			goto IL_05f6;
																		case 45:
																		case 124:
																			goto IL_0609;
																		case 125:
																			goto IL_0617;
																		case 60:
																		case 96:
																			goto IL_062a;
																		case 11:
																		case 134:
																			goto IL_066c;
																		case 56:
																			goto IL_067a;
																		case 10:
																		case 27:
																			goto IL_0688;
																		case 133:
																			goto IL_0696;
																		case 59:
																			goto IL_06ae;
																		case 28:
																			goto IL_06bc;
																		case 135:
																			goto IL_06cf;
																		case 50:
																			goto IL_06e3;
																		case 138:
																			goto IL_06f6;
																		case 119:
																			goto IL_0704;
																		case 23:
																		case 102:
																			goto IL_0712;
																		case 90:
																			goto IL_073b;
																		case 12:
																		case 139:
																			goto IL_0754;
																		case 0:
																			goto IL_0798;
																		case 101:
																			goto IL_07ac;
																		case 140:
																			goto IL_07c8;
																		case 4:
																			goto IL_07df;
																		case 49:
																		case 52:
																			goto IL_07ed;
																		case 32:
																			goto IL_0816;
																		case 104:
																			goto IL_0824;
																		case 61:
																		case 142:
																			goto IL_0834;
																		case 92:
																		case 143:
																			goto IL_0849;
																		case 8:
																			goto IL_0867;
																		case 118:
																			goto IL_0875;
																		case 7:
																		case 18:
																		case 20:
																		case 21:
																		case 22:
																		case 25:
																		case 44:
																		case 53:
																		case 58:
																		case 69:
																		case 74:
																		case 77:
																		case 84:
																		case 86:
																		case 100:
																		case 103:
																		case 110:
																		case 122:
																		case 127:
																		case 128:
																		case 129:
																		case 144:
																		case 145:
																		case 146:
																		case 147:
																			goto end_IL_0285;
																		case 5:
																		case 14:
																		case 29:
																		case 31:
																		case 34:
																		case 35:
																		case 46:
																		case 62:
																		case 66:
																		case 70:
																		case 75:
																		case 88:
																		case 91:
																		case 97:
																		case 98:
																		case 109:
																		case 137:
																		case 141:
																			goto end_IL_02b8;
																		case 19:
																			goto end_IL_0898;
																		case 131:
																			goto end_IL_08ab;
																		case 65:
																			goto end_IL_08b5;
																		case 99:
																			goto end_IL_08c0;
																		case 3:
																		case 15:
																			goto end_IL_08d0;
																		case 123:
																			goto end_IL_08e0;
																		case 24:
																		case 37:
																			goto end_IL_08f0;
																		case 113:
																			goto end_IL_0900;
																		case 114:
																			goto end_IL_0910;
																		case 126:
																		case 132:
																			goto IL_092b;
																		}
																		continue;
																		end_IL_0285:
																		break;
																	}
																	goto IL_0885;
																}
																goto IL_02c3;
																IL_062a:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_06cf;
																IL_06cf:
																array[num5 - 2] = 0;
																goto IL_06e3;
																IL_02c3:
																if (b <= 15)
																{
																	goto IL_02d1;
																}
																goto IL_0885;
																IL_02d1:
																if (8 >= b)
																{
																	goto IL_02df;
																}
																goto IL_0464;
																IL_02df:
																if (8 > b)
																{
																	goto IL_02ed;
																}
																goto IL_0834;
																IL_02ed:
																if (4 >= b)
																{
																	goto IL_02fb;
																}
																goto IL_03ed;
																IL_02fb:
																if (4 > b)
																{
																	goto IL_0309;
																}
																goto IL_0849;
																IL_0309:
																if (2 >= b)
																{
																	goto IL_0317;
																}
																goto IL_06f6;
																IL_0317:
																if (2 > b)
																{
																	goto IL_0322;
																}
																goto IL_0386;
																IL_0322:
																if (1 >= b)
																{
																	goto IL_0330;
																}
																goto IL_0885;
																IL_0330:
																if (1 <= b)
																{
																	goto IL_033e;
																}
																goto IL_0885;
																IL_033e:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																goto IL_0357;
																IL_0357:
																array[num5] = 0;
																goto IL_0365;
																IL_0365:
																num5++;
																goto IL_0373;
																IL_0373:
																ptr2 += 8;
																goto end_IL_02b8;
																IL_0386:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_03c6;
																IL_03c6:
																array[num5 - 2] = 0;
																goto IL_03da;
																IL_03da:
																num5--;
																goto end_IL_02b8;
																IL_06f6:
																if (3 >= b)
																{
																	goto IL_0704;
																}
																goto IL_0885;
																IL_0704:
																if (3 <= b)
																{
																	goto IL_0712;
																}
																goto IL_0885;
																IL_0712:
																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_073b;
																IL_073b:
																array[num5 - 1] = 5;
																goto end_IL_02b8;
																IL_0849:
																array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																goto IL_0867;
																IL_0867:
																ptr2 += 8;
																goto IL_0875;
																IL_0875:
																num5--;
																goto end_IL_02b8;
																IL_03ed:
																if (6 >= b)
																{
																	goto IL_03fb;
																}
																goto IL_07c8;
																IL_03fb:
																if (6 <= b)
																{
																	goto IL_0409;
																}
																goto IL_066c;
																IL_0409:
																((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0448;
																IL_0448:
																num5 -= 3;
																num = 31;
																goto end_IL_02b8;
																IL_066c:
																if (5 >= b)
																{
																	goto IL_067a;
																}
																goto IL_0885;
																IL_067a:
																if (5 <= b)
																{
																	goto IL_0688;
																}
																goto IL_0885;
																IL_0688:
																array[num5] = 5;
																goto IL_0696;
																IL_0696:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																goto IL_06ae;
																IL_06ae:
																num5++;
																goto IL_06bc;
																IL_06bc:
																ptr2 += 8;
																goto end_IL_02b8;
																IL_07c8:
																if (7 >= b)
																{
																	num = 4;
																	goto IL_07df;
																}
																goto IL_0885;
																IL_06e3:
																num5--;
																goto end_IL_02b8;
																IL_07df:
																if (7 <= b)
																{
																	goto IL_07ed;
																}
																goto IL_0885;
																IL_07ed:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0816;
																IL_0816:
																ptr2 += 8;
																goto IL_0824;
																IL_0824:
																num5--;
																goto end_IL_02b8;
																IL_0834:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02b8;
																IL_0464:
																if (12 < b)
																{
																	goto IL_0472;
																}
																goto IL_055c;
																IL_0472:
																if (14 >= b)
																{
																	goto IL_0480;
																}
																goto IL_053b;
																IL_0480:
																if (14 > b)
																{
																	goto IL_048e;
																}
																goto IL_051f;
																IL_048e:
																if (13 >= b)
																{
																	goto IL_049c;
																}
																goto IL_0885;
																IL_049c:
																if (13 <= b)
																{
																	goto IL_04aa;
																}
																goto IL_0885;
																IL_04aa:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_050c;
																IL_050c:
																num5 -= 2;
																goto end_IL_02b8;
																IL_051f:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																goto end_IL_02b8;
																IL_053b:
																if (15 >= b)
																{
																	goto IL_0549;
																}
																goto IL_0885;
																IL_0549:
																if (15 > b)
																{
																}
																goto IL_0885;
																IL_055c:
																if (12 > b)
																{
																	goto IL_056a;
																}
																goto IL_062a;
																IL_056a:
																if (10 >= b)
																{
																	goto IL_0578;
																}
																goto IL_0609;
																IL_0578:
																if (10 > b)
																{
																	goto IL_0583;
																}
																num = 121;
																goto IL_05ad;
																IL_0583:
																if (9 >= b)
																{
																	goto IL_0591;
																}
																goto IL_0885;
																IL_0591:
																if (9 <= b)
																{
																	goto end_IL_02b8;
																}
																goto IL_0885;
																IL_0885:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02b8;
																IL_05ad:
																array[num5] = 0;
																goto IL_05bb;
																IL_05bb:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_05de;
																IL_05de:
																array2[num5] = null;
																goto IL_05e8;
																IL_05e8:
																num5++;
																goto IL_05f6;
																IL_05f6:
																ptr2 += 8;
																goto end_IL_02b8;
																IL_0609:
																if (11 >= b)
																{
																	goto IL_0617;
																}
																goto IL_0885;
																IL_0617:
																if (11 <= b)
																{
																	goto IL_0754;
																}
																goto IL_0885;
																IL_0754:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_0798;
																IL_0798:
																array[num5 - 2] = 0;
																goto IL_07ac;
																IL_07ac:
																num5--;
																num = 46;
																goto end_IL_02b8;
																continue;
																end_IL_0298:
																break;
															}
															continue;
															end_IL_02a8:
															break;
														}
														continue;
														end_IL_02b8:
														break;
													}
													continue;
												}
												goto IL_092b;
												IL_092b:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0898:
												break;
											}
											continue;
											end_IL_08ab:
											break;
										}
										continue;
										end_IL_08b5:
										break;
									}
									continue;
									end_IL_08c0:
									break;
								}
								continue;
								end_IL_08d0:
								break;
							}
							continue;
							end_IL_08e0:
							break;
						}
						continue;
						end_IL_08f0:
						break;
					}
					continue;
					end_IL_0900:
					break;
				}
				continue;
				end_IL_0910:
				break;
			}
		}
	}

	private unsafe static int smethod_1(int int_0)
	{
		int num = 70;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 53;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[4];
								num = 62;
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getApplicationTrustManagerToEventKeywords.IsValidAttributeValuesetDateTimeFormat);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0288:
																	if (b >= 1)
																	{
																		num = 90;
																		while (b <= 11)
																		{
																			while (true)
																			{
																				IL_026b:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_025b:
																						if (6 <= b)
																						{
																							while (true)
																							{
																								IL_0210:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								num = 120;
																								while (true)
																								{
																									if (num != 120)
																									{
																										if (num != 1101)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 16:
																										case 56:
																											goto IL_0210;
																										case 108:
																											goto IL_025b;
																										case 80:
																											goto IL_026b;
																										case 90:
																											goto IL_0278;
																										case 10:
																											goto IL_0288;
																										case 52:
																											goto end_IL_0288;
																										case 5:
																										case 9:
																											goto end_IL_029b;
																										case 83:
																										case 102:
																											goto IL_02b6;
																										case 78:
																											goto IL_02c4;
																										case 12:
																										case 25:
																											goto IL_02d2;
																										case 61:
																											goto IL_02dd;
																										case 29:
																										case 96:
																											goto IL_02eb;
																										case 77:
																											goto IL_032b;
																										case 97:
																											goto IL_033f;
																										case 95:
																											goto IL_0352;
																										case 6:
																											goto IL_0369;
																										case 31:
																										case 63:
																											goto IL_0377;
																										case 26:
																											goto IL_039a;
																										case 2:
																											goto IL_03a8;
																										case 79:
																											goto IL_03b6;
																										case 73:
																										case 101:
																											goto IL_03c9;
																										case 50:
																											goto IL_0436;
																										case 47:
																											goto IL_0441;
																										case 81:
																										case 87:
																											goto IL_044f;
																										case 103:
																											goto IL_046b;
																										case 7:
																										case 106:
																											goto IL_047e;
																										case 109:
																											goto IL_048c;
																										case 68:
																											goto IL_04bc;
																										case 55:
																											goto IL_04cf;
																										case 104:
																											goto IL_04dd;
																										case 23:
																										case 110:
																											goto IL_04eb;
																										case 57:
																											goto IL_04f6;
																										case 41:
																										case 42:
																											goto IL_0504;
																										case 51:
																											goto IL_0512;
																										case 17:
																											goto IL_0535;
																										case 67:
																											goto IL_053f;
																										case 91:
																											goto IL_054d;
																										case 24:
																											goto IL_056e;
																										case 94:
																											goto IL_058a;
																										case 76:
																										case 112:
																											goto IL_059e;
																										case 65:
																											goto IL_05b6;
																										case 21:
																										case 92:
																											goto IL_05c1;
																										case 34:
																											goto IL_05cf;
																										case 0:
																										case 22:
																											goto IL_05dd;
																										case 71:
																											goto IL_0606;
																										case 33:
																											goto IL_0614;
																										case 4:
																											goto IL_0624;
																										case 88:
																										case 111:
																											goto IL_062f;
																										case 14:
																											goto IL_0648;
																										case 28:
																											goto IL_0656;
																										case 86:
																											goto IL_0664;
																										case 13:
																										case 15:
																										case 19:
																										case 30:
																										case 32:
																										case 35:
																										case 36:
																										case 37:
																										case 39:
																										case 40:
																										case 43:
																										case 44:
																										case 46:
																										case 59:
																										case 66:
																										case 74:
																										case 89:
																										case 93:
																										case 99:
																										case 105:
																										case 113:
																											goto end_IL_01fd;
																										case 1:
																										case 11:
																										case 18:
																										case 20:
																										case 48:
																										case 54:
																										case 64:
																										case 72:
																										case 75:
																										case 82:
																										case 84:
																										case 85:
																										case 98:
																										case 100:
																											goto end_IL_02ab;
																										case 27:
																											goto end_IL_0687;
																										case 45:
																											goto end_IL_069a;
																										case 58:
																											goto end_IL_06a4;
																										case 62:
																											goto end_IL_06af;
																										case 38:
																										case 60:
																											goto end_IL_06c4;
																										case 107:
																											goto end_IL_06d4;
																										case 53:
																											goto end_IL_06ed;
																										case 3:
																											goto end_IL_06fd;
																										case 69:
																											goto end_IL_070d;
																										case 70:
																											goto end_IL_0718;
																										case 8:
																										case 49:
																											goto IL_073c;
																										}
																										continue;
																									}
																									array[num5 - 2] = 0;
																									num = 68;
																									goto IL_04bc;
																									IL_04bc:
																									num5--;
																									goto end_IL_02ab;
																									continue;
																									end_IL_01fd:
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_04cf;
																						IL_062f:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0648;
																						IL_04cf:
																						if (3 < b)
																						{
																							goto IL_04dd;
																						}
																						num = 94;
																						goto IL_058a;
																						IL_04dd:
																						if (4 < b)
																						{
																							goto IL_04eb;
																						}
																						goto IL_056e;
																						IL_04eb:
																						if (5 < b)
																						{
																							num = 39;
																							break;
																						}
																						goto IL_04f6;
																						IL_04f6:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_0504;
																						IL_0504:
																						array[num5] = 0;
																						goto IL_0512;
																						IL_0512:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0535;
																						IL_0535:
																						array2[num5] = null;
																						goto IL_053f;
																						IL_053f:
																						num5++;
																						goto IL_054d;
																						IL_054d:
																						ptr2 += 8;
																						goto end_IL_02ab;
																						IL_0656:
																						num5++;
																						goto IL_0664;
																						IL_056e:
																						if (4 > b)
																						{
																							break;
																						}
																						goto end_IL_02ab;
																						IL_0648:
																						array[num5] = 0;
																						goto IL_0656;
																						IL_058a:
																						if (3 <= b)
																						{
																							num = 76;
																							goto IL_059e;
																						}
																						goto IL_05b6;
																						IL_0664:
																						ptr2 += 8;
																						goto end_IL_02ab;
																						IL_059e:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_02ab;
																						IL_05b6:
																						if (1 < b)
																						{
																							goto IL_05c1;
																						}
																						goto IL_0624;
																						IL_05c1:
																						if (2 < b)
																						{
																							break;
																						}
																						goto IL_05cf;
																						IL_05cf:
																						if (2 > b)
																						{
																							break;
																						}
																						goto IL_05dd;
																						IL_05dd:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0606;
																						IL_0606:
																						ptr2 += 8;
																						goto IL_0614;
																						IL_0614:
																						num5--;
																						goto end_IL_02ab;
																						IL_0624:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_062f;
																					}
																					break;
																				}
																				goto IL_02b6;
																				IL_047e:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_048c;
																				IL_02b6:
																				if (9 >= b)
																				{
																					goto IL_02c4;
																				}
																				goto IL_0436;
																				IL_02c4:
																				if (9 > b)
																				{
																					goto IL_02d2;
																				}
																				goto IL_03c9;
																				IL_02d2:
																				if (7 >= b)
																				{
																					goto IL_02dd;
																				}
																				goto IL_0352;
																				IL_02dd:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_02eb;
																				IL_02eb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_032b;
																				IL_032b:
																				array[num5 - 2] = 0;
																				goto IL_033f;
																				IL_033f:
																				num5--;
																				goto end_IL_02ab;
																				IL_0352:
																				if (8 < b)
																				{
																					break;
																				}
																				num = 6;
																				goto IL_0369;
																				IL_048c:
																				if (11 <= b)
																				{
																				}
																				break;
																				IL_0369:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0377;
																				IL_0377:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_039a;
																				IL_039a:
																				array[num5] = 0;
																				goto IL_03a8;
																				IL_03a8:
																				num5++;
																				goto IL_03b6;
																				IL_03b6:
																				ptr2 += 8;
																				goto end_IL_02ab;
																				IL_03c9:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				num = 103;
																				goto IL_046b;
																				IL_046b:
																				num5 -= 2;
																				goto end_IL_02ab;
																				IL_0436:
																				if (10 >= b)
																				{
																					goto IL_0441;
																				}
																				goto IL_047e;
																				IL_0441:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_044f;
																				IL_044f:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_02ab;
																			}
																			break;
																			IL_0278:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_02ab;
																	continue;
																	end_IL_0288:
																	break;
																}
																continue;
																end_IL_029b:
																break;
															}
															continue;
															end_IL_02ab:
															break;
														}
														continue;
													}
													num = 49;
													goto IL_073c;
													IL_073c:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0687:
													break;
												}
												continue;
												end_IL_069a:
												break;
											}
											continue;
											end_IL_06a4:
											break;
										}
										continue;
										end_IL_06af:
										break;
									}
									continue;
									end_IL_06c4:
									break;
								}
								continue;
								end_IL_06d4:
								break;
							}
							continue;
							end_IL_06ed:
							break;
						}
						continue;
						end_IL_06fd:
						break;
					}
					continue;
					end_IL_070d:
					break;
				}
				continue;
				end_IL_0718:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_0, int int_1)
	{
		int num = 13;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EphemerisCorrectionAlgorithmMapLocalDataStoreHolder.setKeyPasswordSystemAuditCallback);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0246:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0229:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_021c:
																						if (6 < b)
																						{
																							while (true)
																							{
																								IL_020c:
																								if (7 >= b)
																								{
																									while (7 <= b)
																									{
																										while (true)
																										{
																											array[num5] = 0;
																											while (true)
																											{
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												while (true)
																												{
																													array2[num5] = null;
																													while (true)
																													{
																														IL_01a2:
																														num5++;
																														num = 96;
																														while (true)
																														{
																															if (num != 96)
																															{
																																if (num != 1077)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 47:
																																	goto IL_01a2;
																																case 86:
																																	goto end_IL_018f;
																																case 60:
																																	goto end_IL_01bb;
																																case 25:
																																case 59:
																																	goto end_IL_01c7;
																																case 8:
																																	goto end_IL_01ec;
																																case 35:
																																	goto IL_020c;
																																case 85:
																																	goto IL_021c;
																																case 18:
																																	goto IL_0229;
																																case 45:
																																	goto IL_0236;
																																case 26:
																																	goto IL_0246;
																																case 38:
																																	goto end_IL_0246;
																																case 11:
																																case 23:
																																	goto end_IL_0256;
																																case 41:
																																	goto IL_027c;
																																case 61:
																																	goto IL_028c;
																																case 55:
																																case 67:
																																	goto IL_029c;
																																case 75:
																																	goto IL_02aa;
																																case 22:
																																case 39:
																																	goto IL_02b8;
																																case 17:
																																case 77:
																																	goto IL_02d0;
																																case 74:
																																	goto IL_02db;
																																case 27:
																																case 81:
																																	goto IL_02fc;
																																case 30:
																																case 36:
																																	goto IL_030a;
																																case 40:
																																	goto IL_0318;
																																case 37:
																																case 53:
																																	goto IL_0326;
																																case 6:
																																	goto IL_0366;
																																case 58:
																																	goto IL_037a;
																																case 28:
																																	goto IL_038d;
																																case 72:
																																case 73:
																																	goto IL_039b;
																																case 66:
																																	goto IL_0409;
																																case 43:
																																	goto IL_041c;
																																case 44:
																																	goto IL_042a;
																																case 51:
																																case 87:
																																	goto IL_0437;
																																case 32:
																																case 89:
																																	goto IL_0453;
																																case 71:
																																	goto IL_047c;
																																case 24:
																																	goto IL_048a;
																																case 3:
																																case 4:
																																case 5:
																																case 7:
																																case 9:
																																case 10:
																																case 29:
																																case 46:
																																case 52:
																																case 57:
																																case 63:
																																case 64:
																																case 68:
																																case 69:
																																case 79:
																																case 83:
																																case 88:
																																	goto end_IL_01fc;
																																case 82:
																																	goto IL_04cd;
																																case 2:
																																	goto IL_04db;
																																case 42:
																																	goto IL_04e9;
																																case 0:
																																case 1:
																																case 19:
																																case 20:
																																case 21:
																																case 34:
																																case 48:
																																case 50:
																																case 56:
																																case 70:
																																case 78:
																																	goto end_IL_0266;
																																case 80:
																																	goto end_IL_04f7;
																																case 14:
																																	goto end_IL_050a;
																																case 84:
																																	goto end_IL_0514;
																																case 33:
																																	goto end_IL_051f;
																																case 65:
																																	goto end_IL_0534;
																																case 16:
																																case 31:
																																	goto end_IL_0549;
																																case 54:
																																	goto end_IL_0559;
																																case 15:
																																case 62:
																																	goto end_IL_0569;
																																case 12:
																																	goto end_IL_0579;
																																case 13:
																																	goto end_IL_0589;
																																case 49:
																																case 76:
																																	goto IL_05a4;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															goto end_IL_0266;
																															continue;
																															end_IL_018f:
																															break;
																														}
																														break;
																													}
																													continue;
																													end_IL_01bb:
																													break;
																												}
																												continue;
																												end_IL_01c7:
																												break;
																											}
																											continue;
																											end_IL_01ec:
																											break;
																										}
																										continue;
																										end_IL_01fc:
																										break;
																									}
																									break;
																								}
																								goto IL_02d0;
																								IL_0437:
																								byte* num6 = ptr2;
																								num4 = 1;
																								ptr2 = num6 + -200;
																								goto end_IL_0266;
																								IL_02d0:
																								if (8 < b)
																								{
																									num = 64;
																									break;
																								}
																								goto IL_02db;
																								IL_02db:
																								if (8 > b)
																								{
																									break;
																								}
																								goto IL_0437;
																							}
																							break;
																						}
																						goto IL_027c;
																						IL_02b8:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_0266;
																						IL_027c:
																						if (6 <= b)
																						{
																							goto end_IL_0266;
																						}
																						goto IL_029c;
																						IL_029c:
																						if (5 < b)
																						{
																							break;
																						}
																						goto IL_02aa;
																						IL_02aa:
																						if (5 > b)
																						{
																							break;
																						}
																						goto IL_02b8;
																					}
																					break;
																				}
																				num = 61;
																				goto IL_028c;
																				IL_047c:
																				ptr2 += 8;
																				goto IL_048a;
																				IL_048a:
																				num5--;
																				goto end_IL_0266;
																				IL_028c:
																				if (4 > b)
																				{
																					goto IL_02fc;
																				}
																				goto IL_0453;
																				IL_02fc:
																				if (2 < b)
																				{
																					goto IL_030a;
																				}
																				goto IL_038d;
																				IL_030a:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_0318;
																				IL_0318:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0326;
																				IL_0326:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0366;
																				IL_0366:
																				array[num5 - 2] = 0;
																				goto IL_037a;
																				IL_037a:
																				num5--;
																				goto end_IL_0266;
																				IL_038d:
																				if (2 <= b)
																				{
																					goto IL_039b;
																				}
																				goto IL_041c;
																				IL_039b:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0409;
																				IL_0409:
																				num5 -= 2;
																				goto end_IL_0266;
																				IL_041c:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_042a;
																				IL_042a:
																				if (1 > b)
																				{
																				}
																				break;
																				IL_0453:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_047c;
																			}
																			break;
																			IL_0236:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04cd;
																	IL_04e9:
																	ptr2 += 8;
																	goto end_IL_0266;
																	IL_04db:
																	num5++;
																	goto IL_04e9;
																	IL_04cd:
																	array[num5] = 0;
																	goto IL_04db;
																	continue;
																	end_IL_0246:
																	break;
																}
																continue;
																end_IL_0256:
																break;
															}
															continue;
															end_IL_0266:
															break;
														}
														continue;
													}
													goto IL_05a4;
													IL_05a4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f7:
													break;
												}
												continue;
												end_IL_050a:
												break;
											}
											continue;
											end_IL_0514:
											break;
										}
										continue;
										end_IL_051f:
										break;
									}
									continue;
									end_IL_0534:
									break;
								}
								continue;
								end_IL_0549:
								break;
							}
							continue;
							end_IL_0559:
							break;
						}
						continue;
						end_IL_0569:
						break;
					}
					continue;
					end_IL_0579:
					break;
				}
				continue;
				end_IL_0589:
				break;
			}
		}
	}

	private static int smethod_3(int int_0)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_0;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_4(int int_0, int int_1)
	{
		int num = 60;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_0;
									while (true)
									{
										array3[1] = int_1;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCompletedSynchronouslyForkJoinOperationType.AssemblyRequestEntrygetAllLocalFiles);
											num = 24;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0239:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0219:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_0209:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_01fc:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_01ec:
																										if (3 >= b)
																										{
																											num = 111;
																											while (true)
																											{
																												if (num != 111)
																												{
																													if (num != 1092)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 14:
																														goto IL_01ec;
																													case 68:
																													case 70:
																														goto IL_01fc;
																													case 81:
																														goto IL_0209;
																													case 8:
																														goto IL_0219;
																													case 27:
																														goto IL_0229;
																													case 31:
																														goto IL_0239;
																													case 19:
																														goto end_IL_0239;
																													case 9:
																													case 100:
																														goto end_IL_0249;
																													case 48:
																														goto IL_0264;
																													case 62:
																														goto IL_0277;
																													case 4:
																													case 10:
																														goto IL_0282;
																													case 16:
																														goto IL_02c2;
																													case 6:
																														goto IL_02d6;
																													case 64:
																														goto IL_02e9;
																													case 61:
																														goto IL_02f7;
																													case 67:
																														goto IL_0313;
																													case 36:
																													case 71:
																														goto IL_0321;
																													case 12:
																														goto IL_0361;
																													case 55:
																														goto IL_0375;
																													case 35:
																													case 92:
																														goto IL_0396;
																													case 15:
																														goto IL_03bf;
																													case 79:
																														goto IL_03cd;
																													case 74:
																													case 95:
																														goto IL_03e0;
																													case 20:
																														goto IL_03ee;
																													case 63:
																														goto IL_0411;
																													case 97:
																														goto IL_041b;
																													case 104:
																														goto IL_0429;
																													case 101:
																														goto IL_043c;
																													case 41:
																													case 90:
																														goto IL_044a;
																													case 22:
																													case 96:
																														goto IL_0455;
																													case 44:
																														goto IL_0463;
																													case 94:
																													case 102:
																														goto IL_0471;
																													case 43:
																														goto IL_048d;
																													case 23:
																													case 42:
																														goto IL_049b;
																													case 91:
																														goto IL_04db;
																													case 85:
																														goto IL_04ef;
																													case 98:
																														goto IL_0502;
																													case 47:
																													case 66:
																														goto IL_0510;
																													case 58:
																														goto IL_051e;
																													case 37:
																													case 77:
																														goto IL_052c;
																													case 17:
																														goto IL_056c;
																													case 21:
																														goto IL_0580;
																													case 30:
																													case 87:
																														goto IL_0593;
																													case 73:
																														goto IL_05ac;
																													case 76:
																														goto IL_05ba;
																													case 75:
																														goto IL_05c8;
																													case 2:
																													case 3:
																													case 7:
																													case 11:
																													case 13:
																													case 18:
																													case 25:
																													case 33:
																													case 34:
																													case 45:
																													case 50:
																													case 51:
																													case 53:
																													case 65:
																													case 80:
																													case 86:
																													case 88:
																													case 99:
																														goto end_IL_01d9;
																													case 57:
																														goto IL_0604;
																													case 40:
																														goto IL_0612;
																													case 32:
																														goto IL_0620;
																													case 1:
																													case 28:
																													case 29:
																													case 38:
																													case 46:
																													case 54:
																													case 56:
																													case 69:
																													case 84:
																													case 93:
																													case 103:
																														goto end_IL_0259;
																													case 24:
																														goto end_IL_062e;
																													case 83:
																														goto end_IL_0641;
																													case 89:
																														goto end_IL_064b;
																													case 0:
																														goto end_IL_065f;
																													case 39:
																														goto end_IL_0674;
																													case 49:
																													case 52:
																														goto end_IL_0689;
																													case 5:
																														goto end_IL_0699;
																													case 26:
																													case 78:
																														goto end_IL_06a9;
																													case 59:
																														goto end_IL_06b9;
																													case 60:
																														goto end_IL_06c9;
																													case 72:
																													case 82:
																														goto IL_06e4;
																													}
																													continue;
																												}
																												if (3 > b)
																												{
																													break;
																												}
																												goto IL_0396;
																												IL_0396:
																												ref int reference = ref array3[*(int*)(ptr2 + num3)];
																												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												goto IL_03bf;
																												IL_03cd:
																												num5--;
																												goto end_IL_0259;
																												IL_03bf:
																												ptr2 += 8;
																												goto IL_03cd;
																												continue;
																												end_IL_01d9:
																												break;
																											}
																											break;
																										}
																										goto IL_0264;
																										IL_0361:
																										array[num5 - 2] = 0;
																										goto IL_0375;
																										IL_0375:
																										num5--;
																										goto end_IL_0259;
																										IL_0264:
																										if (4 < b)
																										{
																											break;
																										}
																										goto IL_0313;
																										IL_0313:
																										if (4 > b)
																										{
																											break;
																										}
																										goto IL_0321;
																										IL_0321:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0361;
																									}
																									break;
																								}
																								goto IL_0277;
																								IL_02f7:
																								if (1 <= b)
																								{
																									num = 34;
																								}
																								break;
																								IL_0277:
																								if (2 <= b)
																								{
																									goto IL_0282;
																								}
																								goto IL_02e9;
																								IL_0282:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02c2;
																								IL_02c2:
																								array[num5 - 2] = 0;
																								goto IL_02d6;
																								IL_02d6:
																								num5--;
																								goto end_IL_0259;
																								IL_02e9:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_02f7;
																							}
																							break;
																						}
																						goto IL_03e0;
																						IL_0429:
																						ptr2 += 8;
																						goto end_IL_0259;
																						IL_03e0:
																						array[num5] = 0;
																						goto IL_03ee;
																						IL_03ee:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0411;
																						IL_0411:
																						array2[num5] = null;
																						goto IL_041b;
																						IL_041b:
																						num5++;
																						goto IL_0429;
																					}
																					break;
																				}
																				goto IL_043c;
																				IL_05c8:
																				ptr2 += 8;
																				goto end_IL_0259;
																				IL_043c:
																				if (7 < b)
																				{
																					goto IL_044a;
																				}
																				goto IL_0502;
																				IL_044a:
																				if (8 < b)
																				{
																					goto IL_0455;
																				}
																				goto IL_048d;
																				IL_0455:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0463;
																				IL_0463:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0471;
																				IL_0471:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0259;
																				IL_048d:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_049b;
																				IL_049b:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04db;
																				IL_04db:
																				array[num5 - 2] = 0;
																				goto IL_04ef;
																				IL_04ef:
																				num5--;
																				goto end_IL_0259;
																				IL_0502:
																				if (7 > b)
																				{
																					goto IL_0510;
																				}
																				goto IL_0593;
																				IL_0510:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_051e;
																				IL_051e:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_052c;
																				IL_052c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_056c;
																				IL_056c:
																				array[num5 - 2] = 0;
																				goto IL_0580;
																				IL_0580:
																				num5--;
																				goto end_IL_0259;
																				IL_0593:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_05ac;
																				IL_05ac:
																				array[num5] = 0;
																				goto IL_05ba;
																				IL_05ba:
																				num5++;
																				goto IL_05c8;
																			}
																			break;
																			IL_0229:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	num = 57;
																	goto IL_0604;
																	IL_0620:
																	ptr2 += 8;
																	goto end_IL_0259;
																	IL_0612:
																	num5++;
																	goto IL_0620;
																	IL_0604:
																	array[num5] = 0;
																	goto IL_0612;
																	continue;
																	end_IL_0239:
																	break;
																}
																continue;
																end_IL_0249:
																break;
															}
															continue;
															end_IL_0259:
															break;
														}
														continue;
													}
													goto IL_06e4;
													IL_06e4:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062e:
													break;
												}
												continue;
												end_IL_0641:
												break;
											}
											continue;
											end_IL_064b:
											break;
										}
										continue;
										end_IL_065f:
										break;
									}
									continue;
									end_IL_0674:
									break;
								}
								continue;
								end_IL_0689:
								break;
							}
							continue;
							end_IL_0699:
							break;
						}
						continue;
						end_IL_06a9:
						break;
					}
					continue;
					end_IL_06b9:
					break;
				}
				continue;
				end_IL_06c9:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_0, int int_1)
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 36;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									while (true)
									{
										array3[0] = int_0;
										while (true)
										{
											array3[1] = int_1;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ParallelInvokeTotalMinutes.getAppIdAuthorityJulianEra);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_0229:
																		if (b >= 1)
																		{
																			while (b <= 8)
																			{
																				while (true)
																				{
																					IL_020c:
																					if (4 >= b)
																					{
																						while (true)
																						{
																							IL_01ff:
																							if (4 > b)
																							{
																								while (true)
																								{
																									IL_01ef:
																									if (2 >= b)
																									{
																										while (true)
																										{
																											IL_01df:
																											if (2 > b)
																											{
																												while (1 >= b)
																												{
																													while (1 <= b)
																													{
																														num = 99;
																														while (num != 99)
																														{
																															if (num != 1080)
																															{
																																goto IL_0393;
																															}
																															switch (num)
																															{
																															case 37:
																																goto IL_01bc;
																															case 20:
																															case 29:
																																goto IL_01cf;
																															case 16:
																																goto IL_01df;
																															case 26:
																																goto IL_01ef;
																															case 80:
																																goto IL_01ff;
																															case 79:
																																goto IL_020c;
																															case 67:
																																goto IL_0219;
																															case 28:
																																goto IL_0229;
																															case 45:
																																goto end_IL_0229;
																															case 3:
																															case 81:
																																goto end_IL_0239;
																															case 11:
																															case 40:
																																goto IL_0254;
																															case 13:
																																goto IL_0262;
																															case 61:
																															case 72:
																																goto IL_0272;
																															case 6:
																																goto IL_029b;
																															case 24:
																																goto IL_02a9;
																															case 57:
																															case 77:
																																goto IL_02bc;
																															case 52:
																																goto IL_02ca;
																															case 35:
																															case 58:
																																goto IL_02d8;
																															case 86:
																															case 87:
																																goto IL_02f0;
																															case 0:
																															case 31:
																																goto IL_02fb;
																															case 71:
																																goto IL_0309;
																															case 2:
																															case 14:
																																goto IL_0317;
																															case 65:
																																goto IL_0333;
																															case 76:
																															case 88:
																																goto IL_0341;
																															case 73:
																																goto IL_0358;
																															case 1:
																																goto IL_037b;
																															case 49:
																																goto IL_0385;
																															case 27:
																																goto IL_0393;
																															case 42:
																															case 44:
																																goto IL_03a6;
																															case 34:
																																goto IL_0414;
																															case 56:
																															case 92:
																																goto IL_0430;
																															case 30:
																																goto IL_043b;
																															case 22:
																															case 23:
																																goto IL_0446;
																															case 60:
																																goto IL_0486;
																															case 47:
																																goto IL_049a;
																															case 7:
																															case 10:
																															case 18:
																															case 32:
																															case 33:
																															case 39:
																															case 41:
																															case 46:
																															case 50:
																															case 54:
																															case 59:
																															case 62:
																															case 64:
																															case 68:
																															case 74:
																															case 78:
																															case 89:
																																goto end_IL_01a9;
																															case 38:
																																goto IL_04cd;
																															case 21:
																																goto IL_04db;
																															case 55:
																																goto IL_04e9;
																															case 5:
																															case 9:
																															case 12:
																															case 15:
																															case 17:
																															case 43:
																															case 48:
																															case 53:
																															case 66:
																															case 83:
																															case 91:
																																goto end_IL_0249;
																															case 63:
																																goto end_IL_04f7;
																															case 51:
																																goto end_IL_050a;
																															case 25:
																																goto end_IL_0514;
																															case 19:
																																goto end_IL_051f;
																															case 8:
																																goto end_IL_0534;
																															case 36:
																																goto end_IL_0549;
																															case 69:
																																goto end_IL_0559;
																															case 4:
																																goto end_IL_0569;
																															case 75:
																															case 90:
																																goto end_IL_0574;
																															case 84:
																																goto end_IL_0584;
																															case 85:
																																goto end_IL_0594;
																															case 70:
																															case 82:
																																goto IL_05af;
																															}
																															continue;
																															end_IL_01a9:
																															break;
																														}
																														break;
																														IL_01bc:;
																													}
																													break;
																													IL_01cf:;
																												}
																												break;
																											}
																											goto IL_03a6;
																											IL_0414:
																											num5 -= 2;
																											num = 17;
																											goto end_IL_0249;
																											IL_03a6:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0414;
																										}
																										break;
																									}
																									goto IL_0430;
																									IL_049a:
																									num5--;
																									goto end_IL_0249;
																									IL_0430:
																									if (3 < b)
																									{
																										break;
																									}
																									goto IL_043b;
																									IL_043b:
																									if (3 > b)
																									{
																										break;
																									}
																									goto IL_0446;
																									IL_0446:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_0486;
																									IL_0486:
																									array[num5 - 2] = 0;
																									goto IL_049a;
																								}
																								break;
																							}
																							goto IL_0272;
																							IL_02a9:
																							num5--;
																							goto end_IL_0249;
																							IL_0272:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_029b;
																							IL_029b:
																							ptr2 += 8;
																							goto IL_02a9;
																						}
																						break;
																					}
																					goto IL_0254;
																					IL_0393:
																					ptr2 += 8;
																					goto end_IL_0249;
																					IL_0254:
																					if (6 >= b)
																					{
																						goto IL_0262;
																					}
																					goto IL_02f0;
																					IL_0262:
																					if (6 <= b)
																					{
																						goto end_IL_0249;
																					}
																					goto IL_02bc;
																					IL_02bc:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_02ca;
																					IL_02ca:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_02d8;
																					IL_02d8:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0249;
																					IL_02f0:
																					if (7 < b)
																					{
																						goto IL_02fb;
																					}
																					goto IL_0333;
																					IL_02fb:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_0309;
																					IL_0309:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0317;
																					IL_0317:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0249;
																					IL_0333:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0341;
																					IL_0341:
																					array[num5] = 0;
																					num = 73;
																					goto IL_0358;
																					IL_0358:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_037b;
																					IL_037b:
																					array2[num5] = null;
																					goto IL_0385;
																					IL_0385:
																					num5++;
																					goto IL_0393;
																				}
																				break;
																				IL_0219:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_04cd;
																		IL_04e9:
																		ptr2 += 8;
																		goto end_IL_0249;
																		IL_04db:
																		num5++;
																		goto IL_04e9;
																		IL_04cd:
																		array[num5] = 0;
																		goto IL_04db;
																		continue;
																		end_IL_0229:
																		break;
																	}
																	continue;
																	end_IL_0239:
																	break;
																}
																continue;
																end_IL_0249:
																break;
															}
															continue;
														}
														goto IL_05af;
														IL_05af:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_04f7:
														break;
													}
													continue;
													end_IL_050a:
													break;
												}
												continue;
												end_IL_0514:
												break;
											}
											continue;
											end_IL_051f:
											break;
										}
										continue;
										end_IL_0534:
										break;
									}
									continue;
									end_IL_0549:
									break;
								}
								continue;
								end_IL_0559:
								break;
							}
							continue;
							end_IL_0569:
							break;
						}
						continue;
						end_IL_0574:
						break;
					}
					continue;
					end_IL_0584:
					break;
				}
				continue;
				end_IL_0594:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_0)
	{
		int num = 47;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_0;
									num = 45;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DemandedOnStop.setListSeparatorCallingConventions);
										num = 93;
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0295:
														byte b = *ptr2;
														while (true)
														{
															IL_0285:
															ptr2++;
															while (true)
															{
																IL_0275:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0255:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0248:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_0238:
																							array[num5] = 0;
																							while (true)
																							{
																								IL_0213:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								while (true)
																								{
																									IL_0207:
																									array2[num5] = null;
																									while (true)
																									{
																										IL_01f7:
																										num5++;
																										while (true)
																										{
																											IL_01de:
																											ptr2 += 8;
																											num = 111;
																											while (num != 111 && num == 1092)
																											{
																												switch (num)
																												{
																												case 36:
																													goto IL_01de;
																												case 41:
																													goto IL_01f7;
																												case 78:
																													goto IL_0207;
																												case 95:
																													goto IL_0213;
																												case 37:
																												case 57:
																													goto IL_0238;
																												case 24:
																													goto IL_0248;
																												case 80:
																													goto IL_0255;
																												case 23:
																													goto IL_0265;
																												case 90:
																													goto IL_0275;
																												case 77:
																													goto IL_0285;
																												case 5:
																												case 102:
																													goto IL_0295;
																												case 49:
																												case 82:
																													goto IL_02a0;
																												case 39:
																													goto IL_02ab;
																												case 0:
																												case 43:
																													goto IL_02b9;
																												case 28:
																													goto IL_02e2;
																												case 26:
																													goto IL_02f0;
																												case 67:
																												case 75:
																													goto IL_030c;
																												case 38:
																													goto IL_031a;
																												case 56:
																													goto IL_0328;
																												case 20:
																												case 94:
																													goto IL_033b;
																												case 9:
																													goto IL_0349;
																												case 12:
																												case 44:
																													goto IL_0357;
																												case 72:
																													goto IL_0370;
																												case 62:
																													goto IL_037e;
																												case 31:
																													goto IL_038c;
																												case 104:
																													goto IL_039f;
																												case 30:
																												case 55:
																													goto IL_03ad;
																												case 6:
																													goto IL_03ce;
																												case 4:
																												case 87:
																													goto IL_03d9;
																												case 65:
																													goto IL_03e4;
																												case 10:
																												case 99:
																													goto IL_03f2;
																												case 50:
																													goto IL_040e;
																												case 70:
																													goto IL_041c;
																												case 68:
																													goto IL_042f;
																												case 19:
																												case 71:
																													goto IL_043a;
																												case 33:
																													goto IL_049c;
																												case 73:
																													goto IL_04af;
																												case 40:
																												case 60:
																													goto IL_04ba;
																												case 59:
																													goto IL_04c8;
																												case 11:
																												case 51:
																													goto IL_04d6;
																												case 89:
																													goto IL_04f9;
																												case 53:
																													goto IL_0507;
																												case 86:
																													goto IL_0515;
																												case 27:
																													goto IL_0528;
																												case 48:
																												case 88:
																													goto IL_0533;
																												case 84:
																													goto IL_0573;
																												case 69:
																													goto IL_0587;
																												case 1:
																												case 3:
																												case 7:
																												case 13:
																												case 15:
																												case 17:
																												case 25:
																												case 34:
																												case 61:
																												case 63:
																												case 64:
																												case 66:
																												case 76:
																												case 79:
																												case 85:
																												case 97:
																												case 98:
																												case 101:
																												case 103:
																													goto end_IL_0265;
																												case 16:
																												case 18:
																												case 22:
																												case 29:
																												case 35:
																												case 52:
																												case 54:
																												case 81:
																												case 83:
																												case 91:
																												case 96:
																												case 100:
																													goto end_IL_01cb;
																												case 93:
																													goto end_IL_05aa;
																												case 45:
																													goto end_IL_05bd;
																												case 74:
																													goto end_IL_05c7;
																												case 2:
																													goto end_IL_05db;
																												case 32:
																												case 42:
																													goto end_IL_05f9;
																												case 8:
																													goto end_IL_0609;
																												case 14:
																												case 58:
																													goto end_IL_0619;
																												case 46:
																													goto end_IL_0629;
																												case 47:
																													goto end_IL_0639;
																												case 21:
																												case 92:
																													goto IL_0654;
																												}
																												continue;
																												end_IL_01cb:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					goto IL_02a0;
																					IL_039f:
																					if (3 > b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_03ad;
																					IL_02a0:
																					if (2 >= b)
																					{
																						goto IL_02ab;
																					}
																					num = 75;
																					goto IL_030c;
																					IL_02ab:
																					if (2 <= b)
																					{
																						goto IL_02b9;
																					}
																					goto IL_033b;
																					IL_02b9:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_02e2;
																					IL_02e2:
																					ptr2 += 8;
																					goto IL_02f0;
																					IL_02f0:
																					num5--;
																					break;
																					IL_033b:
																					if (1 < b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_0349;
																					IL_0349:
																					if (1 > b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_0357;
																					IL_0357:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0370;
																					IL_0370:
																					array[num5] = 0;
																					goto IL_037e;
																					IL_037e:
																					num5++;
																					goto IL_038c;
																					IL_038c:
																					ptr2 += 8;
																					break;
																					IL_03ad:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					num = 16;
																					break;
																					IL_030c:
																					if (3 < b)
																					{
																						goto IL_031a;
																					}
																					goto IL_039f;
																					IL_031a:
																					if (4 < b)
																					{
																						goto end_IL_0265;
																					}
																					goto IL_0328;
																					IL_0328:
																					if (4 > b)
																					{
																						goto end_IL_0265;
																					}
																					break;
																				}
																				break;
																			}
																			goto IL_03ce;
																			IL_0587:
																			num5--;
																			break;
																			IL_03ce:
																			if (8 < b)
																			{
																				goto IL_03d9;
																			}
																			goto IL_042f;
																			IL_03d9:
																			if (9 >= b)
																			{
																				goto IL_03e4;
																			}
																			goto IL_040e;
																			IL_03e4:
																			if (9 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_03f2;
																			IL_03f2:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_040e:
																			if (10 < b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_041c;
																			IL_041c:
																			if (10 > b)
																			{
																			}
																			goto end_IL_0265;
																			IL_042f:
																			if (8 <= b)
																			{
																				goto IL_043a;
																			}
																			goto IL_04af;
																			IL_043a:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_049c;
																			IL_049c:
																			num5 -= 2;
																			break;
																			IL_04af:
																			if (6 < b)
																			{
																				goto IL_04ba;
																			}
																			goto IL_0528;
																			IL_04ba:
																			if (7 < b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_04c8;
																			IL_04c8:
																			if (7 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_04d6;
																			IL_04d6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04f9;
																			IL_04f9:
																			array[num5] = 0;
																			goto IL_0507;
																			IL_0507:
																			num5++;
																			goto IL_0515;
																			IL_0515:
																			ptr2 += 8;
																			break;
																			IL_0528:
																			if (6 > b)
																			{
																				goto end_IL_0265;
																			}
																			goto IL_0533;
																			IL_0533:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0573;
																			IL_0573:
																			array[num5 - 2] = 0;
																			goto IL_0587;
																		}
																		goto end_IL_0275;
																		continue;
																		end_IL_0265:
																		break;
																		IL_0265:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0275:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0654;
												IL_0654:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05aa:
												break;
											}
											continue;
											end_IL_05bd:
											break;
										}
										continue;
										end_IL_05c7:
										break;
									}
									continue;
									end_IL_05db:
									break;
								}
								continue;
								end_IL_05f9:
								break;
							}
							continue;
							end_IL_0609:
							break;
						}
						continue;
						end_IL_0619:
						break;
					}
					continue;
					end_IL_0629:
					break;
				}
				continue;
				end_IL_0639:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 79;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							IL_08ed:
							int[] array3 = new int[2];
							while (true)
							{
								IL_08d4:
								long[] array4 = new long[4];
								num = 49;
								while (true)
								{
									IL_08c4:
									object[] array5 = new object[1];
									while (true)
									{
										IL_08b9:
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SafeHandleMinusOneIsInvalidKeywords.getIsImpersonatingThreadPoolWorkQueue);
										while (true)
										{
											IL_08af:
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0338:
														byte b = *ptr2;
														while (true)
														{
															IL_0328:
															ptr2++;
															while (true)
															{
																IL_0318:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_02f8:
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02e8:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02d8:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02c8:
																									if (10 >= b)
																									{
																										while (true)
																										{
																											IL_02bb:
																											if (10 > b)
																											{
																												while (9 >= b)
																												{
																													while (9 <= b)
																													{
																														num = 154;
																														while (num != 154)
																														{
																															if (num != 1135)
																															{
																																goto end_IL_089c;
																															}
																															switch (num)
																															{
																															case 42:
																																goto IL_0298;
																															case 102:
																																goto IL_02ab;
																															case 62:
																																goto IL_02bb;
																															case 0:
																																goto IL_02c8;
																															case 31:
																																goto IL_02d8;
																															case 2:
																																goto IL_02e8;
																															case 69:
																																goto IL_02f8;
																															case 33:
																																goto IL_0308;
																															case 50:
																																goto IL_0318;
																															case 11:
																																goto IL_0328;
																															case 61:
																															case 132:
																																goto IL_0338;
																															case 95:
																															case 139:
																																goto IL_0343;
																															case 134:
																																goto IL_0351;
																															case 141:
																																goto IL_0374;
																															case 27:
																																goto IL_037e;
																															case 146:
																																goto IL_038c;
																															case 41:
																															case 77:
																																goto IL_039f;
																															case 115:
																																goto IL_03ad;
																															case 96:
																															case 111:
																																goto IL_03bb;
																															case 37:
																																goto IL_03ff;
																															case 120:
																																goto IL_0413;
																															case 101:
																															case 124:
																																goto IL_0426;
																															case 16:
																																goto IL_0466;
																															case 74:
																																goto IL_047a;
																															case 52:
																																goto IL_0496;
																															case 19:
																																goto IL_04a4;
																															case 83:
																															case 140:
																																goto IL_04af;
																															case 3:
																															case 68:
																																goto IL_04cb;
																															case 93:
																																goto IL_04d9;
																															case 84:
																															case 129:
																																goto IL_04e7;
																															case 97:
																																goto IL_0549;
																															case 4:
																															case 65:
																																goto IL_0565;
																															case 75:
																																goto IL_0573;
																															case 144:
																																goto IL_0586;
																															case 25:
																															case 110:
																																goto IL_0594;
																															case 35:
																																goto IL_05a2;
																															case 32:
																																goto IL_05b0;
																															case 63:
																																goto IL_05be;
																															case 71:
																															case 82:
																																goto IL_05c9;
																															case 105:
																																goto IL_0609;
																															case 64:
																																goto IL_061d;
																															case 67:
																																goto IL_0630;
																															case 36:
																																goto IL_063e;
																															case 99:
																															case 127:
																																goto IL_064c;
																															case 106:
																																goto IL_0665;
																															case 81:
																																goto IL_0673;
																															case 8:
																																goto IL_0681;
																															case 57:
																																goto IL_0694;
																															case 90:
																																goto IL_06a2;
																															case 15:
																															case 89:
																																goto IL_06b0;
																															case 107:
																																goto IL_06d9;
																															case 80:
																															case 137:
																																goto IL_0704;
																															case 119:
																																goto IL_0722;
																															case 114:
																																goto IL_0730;
																															case 100:
																																goto IL_0743;
																															case 39:
																																goto IL_074e;
																															case 46:
																																goto IL_075c;
																															case 5:
																															case 118:
																																goto IL_076a;
																															case 18:
																																goto IL_0793;
																															case 135:
																																goto IL_07a1;
																															case 116:
																																goto IL_07bd;
																															case 56:
																															case 72:
																																goto IL_07c8;
																															case 40:
																																goto IL_0807;
																															case 45:
																																goto IL_081a;
																															case 20:
																																goto IL_0825;
																															case 6:
																															case 14:
																																goto IL_0830;
																															case 60:
																																goto IL_083e;
																															case 76:
																																goto IL_0856;
																															case 104:
																																goto IL_0864;
																															case 55:
																															case 138:
																																goto IL_0874;
																															case 1:
																															case 7:
																															case 9:
																															case 12:
																															case 22:
																															case 23:
																															case 24:
																															case 28:
																															case 29:
																															case 43:
																															case 51:
																															case 53:
																															case 58:
																															case 59:
																															case 66:
																															case 70:
																															case 87:
																															case 91:
																															case 92:
																															case 98:
																															case 108:
																															case 112:
																															case 123:
																															case 126:
																															case 128:
																															case 130:
																															case 131:
																															case 136:
																															case 142:
																															case 143:
																																goto end_IL_0298;
																															case 13:
																															case 17:
																															case 21:
																															case 47:
																															case 54:
																															case 73:
																															case 85:
																															case 86:
																															case 88:
																															case 94:
																															case 103:
																															case 113:
																															case 121:
																															case 125:
																															case 133:
																															case 145:
																															case 147:
																																goto end_IL_0285;
																															case 122:
																																goto IL_08af;
																															case 109:
																																goto IL_08b9;
																															case 49:
																																goto IL_08c4;
																															case 48:
																																goto IL_08d4;
																															case 26:
																															case 30:
																																goto IL_08ed;
																															case 38:
																																goto end_IL_089c;
																															case 10:
																															case 34:
																																goto end_IL_08fd;
																															case 78:
																																goto end_IL_090d;
																															case 79:
																																goto end_IL_091d;
																															case 44:
																															case 117:
																																goto IL_0938;
																															}
																															continue;
																															end_IL_0285:
																															break;
																														}
																														goto end_IL_0318;
																														continue;
																														end_IL_0298:
																														break;
																														IL_0298:;
																													}
																													break;
																													IL_02ab:;
																												}
																												break;
																											}
																											goto IL_0343;
																											IL_038c:
																											ptr2 += 8;
																											goto end_IL_0318;
																											IL_0343:
																											array[num5] = 0;
																											goto IL_0351;
																											IL_0351:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_0374;
																											IL_0374:
																											array2[num5] = null;
																											goto IL_037e;
																											IL_037e:
																											num5++;
																											goto IL_038c;
																										}
																										break;
																									}
																									goto IL_039f;
																									IL_0413:
																									num5--;
																									goto end_IL_0318;
																									IL_039f:
																									if (11 < b)
																									{
																										break;
																									}
																									goto IL_03ad;
																									IL_03ad:
																									if (11 > b)
																									{
																										break;
																									}
																									goto IL_03bb;
																									IL_03bb:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_03ff;
																									IL_03ff:
																									array[num5 - 2] = 0;
																									goto IL_0413;
																								}
																								break;
																							}
																							goto IL_0426;
																							IL_047a:
																							num5--;
																							num = 73;
																							goto end_IL_0318;
																							IL_0426:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0466;
																							IL_0466:
																							array[num5 - 2] = 0;
																							goto IL_047a;
																						}
																						break;
																					}
																					goto IL_0496;
																					IL_0573:
																					if (15 <= b)
																					{
																					}
																					break;
																					IL_0496:
																					if (14 >= b)
																					{
																						goto IL_04a4;
																					}
																					goto IL_0565;
																					IL_04a4:
																					if (14 <= b)
																					{
																						goto IL_04af;
																					}
																					goto IL_04cb;
																					IL_04af:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0318;
																					IL_04cb:
																					if (13 < b)
																					{
																						break;
																					}
																					goto IL_04d9;
																					IL_04d9:
																					if (13 > b)
																					{
																						break;
																					}
																					goto IL_04e7;
																					IL_04e7:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0549;
																					IL_0549:
																					num5 -= 2;
																					num = 103;
																					goto end_IL_0318;
																					IL_0565:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_0573;
																				}
																				break;
																			}
																			goto IL_0586;
																			IL_0856:
																			num5++;
																			goto IL_0864;
																			IL_0586:
																			if (8 > b)
																			{
																				goto IL_0594;
																			}
																			goto IL_0874;
																			IL_0594:
																			if (4 >= b)
																			{
																				goto IL_05a2;
																			}
																			goto IL_0743;
																			IL_05a2:
																			if (4 > b)
																			{
																				goto IL_05b0;
																			}
																			num = 80;
																			goto IL_0704;
																			IL_05b0:
																			if (2 >= b)
																			{
																				goto IL_05be;
																			}
																			goto IL_0694;
																			IL_05be:
																			if (2 <= b)
																			{
																				goto IL_05c9;
																			}
																			goto IL_0630;
																			IL_05c9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0609;
																			IL_0609:
																			array[num5 - 2] = 0;
																			goto IL_061d;
																			IL_061d:
																			num5--;
																			goto end_IL_0318;
																			IL_0630:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_063e;
																			IL_063e:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_064c;
																			IL_064c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_0665;
																			IL_0665:
																			array[num5] = 0;
																			goto IL_0673;
																			IL_0673:
																			num5++;
																			goto IL_0681;
																			IL_0681:
																			ptr2 += 8;
																			goto end_IL_0318;
																			IL_0694:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_06a2;
																			IL_06a2:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_06b0;
																			IL_06b0:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06d9;
																			IL_06d9:
																			array[num5 - 1] = 5;
																			num = 133;
																			goto end_IL_0318;
																			IL_0864:
																			ptr2 += 8;
																			goto end_IL_0318;
																			IL_0704:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0722;
																			IL_0722:
																			ptr2 += 8;
																			goto IL_0730;
																			IL_0730:
																			num5--;
																			goto end_IL_0318;
																			IL_0743:
																			if (6 < b)
																			{
																				goto IL_074e;
																			}
																			num = 116;
																			goto IL_07bd;
																			IL_074e:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_075c;
																			IL_075c:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_076a;
																			IL_076a:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0793;
																			IL_0793:
																			ptr2 += 8;
																			goto IL_07a1;
																			IL_07a1:
																			num5--;
																			goto end_IL_0318;
																			IL_0874:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0318;
																			IL_07bd:
																			if (6 <= b)
																			{
																				goto IL_07c8;
																			}
																			goto IL_081a;
																			IL_07c8:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0807;
																			IL_0807:
																			num5 -= 3;
																			goto end_IL_0318;
																			IL_081a:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_0825;
																			IL_0825:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_0830;
																			IL_0830:
																			array[num5] = 5;
																			goto IL_083e;
																			IL_083e:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0856;
																		}
																		break;
																		IL_0308:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0318:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0938;
												IL_0938:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_089c:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_08fd:
						break;
					}
					continue;
					end_IL_090d:
					break;
				}
				continue;
				end_IL_091d:
				break;
			}
		}
	}

	static Class19()
	{
		int num = 3;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 10;
			while (true)
			{
				if (num != 10)
				{
					if (num == 991)
					{
						switch (num)
						{
						default:
							continue;
						case 3:
							break;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						}
						break;
					}
				}
				else
				{
					Class300.smethod_0();
				}
				return;
			}
		}
	}
}
