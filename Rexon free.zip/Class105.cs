using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;

[Mod("Stilt Fixed Gun", "Super Infection/Casual [MASTERCLIENT]", "Spawns fixed stilts.", false, 2, ModType.const_0, false)]
internal class Class105 : Class93
{
	private static int int_3;

	private static double double_1;

	private static double double_2;

	private static int int_4;

	private static IntPtr[] ReplacementFallbackgetSystemPageSize;

	private static IntPtr[] GetGenericTypeDefinitionNextChannelSink;

	private static IntPtr[] CreateFromSignedFileSignHash;

	protected unsafe override string ModId
	{
		get
		{
			//The blocks IL_000e, IL_001c, IL_002c, IL_0399, IL_03ac, IL_03bf, IL_03cf, IL_03df, IL_03ec, IL_03fc, IL_040c, IL_041c, IL_042c, IL_043c, IL_044c, IL_045c, IL_0467, IL_0477, IL_04b7, IL_04d0, IL_04de, IL_0507, IL_051a, IL_0528, IL_053b, IL_0549, IL_0557, IL_0565, IL_056e, IL_057c, IL_0585, IL_05e7, IL_05fa, IL_0608, IL_064a, IL_0658, IL_0663, IL_0676, IL_0684, IL_0694, IL_06aa, IL_06ea, IL_0707, IL_071a, IL_072d, IL_073b, IL_0746, IL_0754, IL_076c, IL_077a, IL_0796, IL_07a1, IL_07af, IL_07bd, IL_07eb, IL_07f9, IL_0804, IL_0817, IL_0825, IL_0833, IL_0850, IL_089f, IL_08a9, IL_08d6, IL_08ea, IL_0901, IL_0914, IL_093b, IL_0949, IL_095c, IL_0975, IL_09b5, IL_09c9, IL_09dc, IL_09ef, IL_0a02, IL_0a10, IL_0a3c, IL_0a46, IL_0a54, IL_0a67, IL_0a75, IL_0a80, IL_0a8b, IL_0a9e, IL_0aac, IL_0aea, IL_0afd, IL_0b16, IL_0b2d, IL_0b3b, IL_0b4e, IL_0b59, IL_0b67, IL_0b7a, IL_0b88, IL_0ba9, IL_0bbc, IL_0bc7, IL_0bdb, IL_0c13, IL_0c26, IL_0c34, IL_0c42, IL_0c50, IL_0c59, IL_0c7a, IL_0c98, IL_0cbc, IL_0cdd, IL_0cf0, IL_0d15, IL_0d55, IL_0d69, IL_0d7c, IL_0d90, IL_0dcf, IL_0de8, IL_0df1, IL_0e0a, IL_0e18, IL_0e26, IL_0e34, IL_0e47, IL_0e52, IL_0e5c, IL_0e67, IL_0e77, IL_0e87, IL_0e97, IL_0ea7, IL_0eb7, IL_0ed0, IL_0ee0, IL_0ef0, IL_0f0b are reachable both inside and outside the pinned region starting at IL_0f05. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 84;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef12 = default(int);
				ref int reference = ref __rxRef12;
				object[] array8;
				int num7;
				byte* num8;
				byte* num10;
				int num11;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0ef0:
						num2 = 1;
						while (true)
						{
							IL_0ee0:
							num3 = num2 * 4;
							while (true)
							{
								IL_0ed0:
								num4 = num2 * 8;
								while (true)
								{
									IL_0eb7:
									array2 = new byte[4];
									num = 26;
									while (true)
									{
										IL_0ea7:
										array3 = new object[4];
										while (true)
										{
											IL_0e97:
											array4 = new int[4];
											while (true)
											{
												IL_0e87:
												array5 = new int[6];
												while (true)
												{
													IL_0e77:
													array6 = new long[4];
													while (true)
													{
														IL_0e67:
														array7 = new object[12];
														while (true)
														{
															IL_0e5c:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FSourceArgumentInvalidArrayType.LowLatencygetActivationArguments);
															while (true)
															{
																IL_0e52:
																ptr2 = ptr;
																while (true)
																{
																	IL_0e47:
																	num = 193;
																	while (true)
																	{
																		IL_0e34:
																		if (num5 != 1)
																		{
																			while (true)
																			{
																				IL_045c:
																				byte b = *ptr2;
																				while (true)
																				{
																					IL_044c:
																					ptr2++;
																					while (true)
																					{
																						IL_043c:
																						if (b >= 1)
																						{
																							while (b <= 22)
																							{
																								while (true)
																								{
																									IL_041c:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_040c:
																											if (11 > b)
																											{
																												while (true)
																												{
																													IL_03fc:
																													if (5 >= b)
																													{
																														while (true)
																														{
																															IL_03ec:
																															if (5 > b)
																															{
																																while (true)
																																{
																																	IL_03df:
																																	if (2 >= b)
																																	{
																																		while (true)
																																		{
																																			IL_03cf:
																																			if (2 > b)
																																			{
																																				while (1 >= b)
																																				{
																																					while (1 > b)
																																					{
																																						num = 223;
																																						while (num != 223)
																																						{
																																							if (num != 1204)
																																							{
																																								goto IL_0676;
																																							}
																																							switch (num)
																																							{
																																							case 84:
																																								break;
																																							default:
																																								continue;
																																							case 39:
																																								goto IL_03ac;
																																							case 74:
																																								goto IL_03bf;
																																							case 96:
																																								goto IL_03cf;
																																							case 17:
																																							case 126:
																																								goto IL_03df;
																																							case 136:
																																								goto IL_03ec;
																																							case 44:
																																							case 113:
																																								goto IL_03fc;
																																							case 194:
																																								goto IL_040c;
																																							case 34:
																																								goto IL_041c;
																																							case 20:
																																								goto IL_042c;
																																							case 88:
																																								goto IL_043c;
																																							case 79:
																																								goto IL_044c;
																																							case 99:
																																							case 158:
																																								goto IL_045c;
																																							case 9:
																																							case 116:
																																								goto IL_0467;
																																							case 21:
																																							case 118:
																																								goto IL_0477;
																																							case 93:
																																								goto IL_04b7;
																																							case 141:
																																								goto IL_04d0;
																																							case 43:
																																							case 73:
																																								goto IL_04de;
																																							case 119:
																																								goto IL_0507;
																																							case 149:
																																								goto IL_051a;
																																							case 24:
																																								goto IL_0528;
																																							case 129:
																																							case 152:
																																								goto IL_053b;
																																							case 101:
																																								goto IL_0549;
																																							case 3:
																																							case 35:
																																								goto IL_0557;
																																							case 103:
																																								goto IL_056e;
																																							case 46:
																																							case 76:
																																								goto IL_0585;
																																							case 150:
																																								goto IL_05e7;
																																							case 145:
																																								goto IL_05fa;
																																							case 131:
																																							case 138:
																																								goto IL_0608;
																																							case 172:
																																								goto IL_064a;
																																							case 91:
																																								goto IL_0658;
																																							case 18:
																																								goto IL_0663;
																																							case 180:
																																								goto IL_0676;
																																							case 100:
																																								goto IL_0684;
																																							case 183:
																																								goto IL_0694;
																																							case 181:
																																							case 190:
																																								goto IL_06aa;
																																							case 81:
																																								goto IL_06ea;
																																							case 175:
																																								goto IL_0707;
																																							case 192:
																																								goto IL_071a;
																																							case 117:
																																							case 196:
																																								goto IL_072d;
																																							case 127:
																																								goto IL_073b;
																																							case 51:
																																							case 57:
																																								goto IL_0746;
																																							case 14:
																																								goto IL_0754;
																																							case 16:
																																								goto IL_076c;
																																							case 189:
																																								goto IL_077a;
																																							case 75:
																																								goto IL_0796;
																																							case 97:
																																							case 165:
																																								goto IL_07a1;
																																							case 49:
																																								goto IL_07af;
																																							case 69:
																																							case 184:
																																								goto IL_07bd;
																																							case 104:
																																								goto IL_07eb;
																																							case 77:
																																							case 191:
																																								goto IL_07f9;
																																							case 0:
																																								goto IL_0804;
																																							case 154:
																																								goto IL_0817;
																																							case 7:
																																								goto IL_0825;
																																							case 36:
																																							case 63:
																																								goto IL_0833;
																																							case 186:
																																								goto IL_08ea;
																																							case 195:
																																								goto IL_0901;
																																							case 6:
																																							case 170:
																																								goto IL_0914;
																																							case 53:
																																								goto IL_093b;
																																							case 58:
																																								goto IL_0949;
																																							case 199:
																																								goto IL_095c;
																																							case 177:
																																							case 200:
																																								goto IL_0975;
																																							case 105:
																																								goto IL_09b5;
																																							case 179:
																																								goto IL_09c9;
																																							case 54:
																																							case 201:
																																								goto IL_09dc;
																																							case 203:
																																								goto IL_09ef;
																																							case 59:
																																							case 208:
																																								goto IL_0a02;
																																							case 71:
																																								goto IL_0a10;
																																							case 31:
																																								goto IL_0a3c;
																																							case 160:
																																								goto IL_0a46;
																																							case 159:
																																								goto IL_0a54;
																																							case 139:
																																							case 209:
																																								goto IL_0a67;
																																							case 144:
																																								goto IL_0a75;
																																							case 82:
																																							case 185:
																																								goto IL_0a80;
																																							case 8:
																																							case 12:
																																								goto IL_0a8b;
																																							case 106:
																																								goto IL_0a9e;
																																							case 61:
																																							case 78:
																																								goto IL_0aac;
																																							case 197:
																																								goto IL_0aea;
																																							case 122:
																																							case 169:
																																								goto IL_0afd;
																																							case 157:
																																								goto IL_0b16;
																																							case 42:
																																								goto IL_0b2d;
																																							case 110:
																																								goto IL_0b3b;
																																							case 207:
																																								goto IL_0b4e;
																																							case 10:
																																							case 205:
																																								goto IL_0b59;
																																							case 85:
																																								goto IL_0b67;
																																							case 115:
																																								goto IL_0b7a;
																																							case 37:
																																							case 142:
																																								goto IL_0b88;
																																							case 211:
																																								goto IL_0ba9;
																																							case 212:
																																								goto IL_0bbc;
																																							case 41:
																																							case 108:
																																								goto IL_0bc7;
																																							case 65:
																																								goto IL_0bdb;
																																							case 148:
																																								goto IL_0c13;
																																							case 213:
																																								goto IL_0c34;
																																							case 137:
																																								goto IL_0c42;
																																							case 151:
																																							case 202:
																																								goto IL_0c59;
																																							case 67:
																																								goto IL_0c7a;
																																							case 87:
																																								goto IL_0c98;
																																							case 72:
																																								goto IL_0cbc;
																																							case 188:
																																								goto IL_0cdd;
																																							case 156:
																																							case 215:
																																								goto IL_0cf0;
																																							case 68:
																																							case 89:
																																								goto IL_0d15;
																																							case 167:
																																								goto IL_0d55;
																																							case 121:
																																								goto IL_0d69;
																																							case 50:
																																							case 153:
																																								goto IL_0d7c;
																																							case 164:
																																								goto IL_0d90;
																																							case 216:
																																								goto IL_0dcf;
																																							case 13:
																																							case 15:
																																							case 22:
																																							case 23:
																																							case 27:
																																							case 28:
																																							case 30:
																																							case 33:
																																							case 40:
																																							case 56:
																																							case 60:
																																							case 62:
																																							case 66:
																																							case 70:
																																							case 90:
																																							case 92:
																																							case 94:
																																							case 98:
																																							case 107:
																																							case 109:
																																							case 112:
																																							case 114:
																																							case 123:
																																							case 125:
																																							case 130:
																																							case 132:
																																							case 155:
																																							case 161:
																																							case 168:
																																							case 173:
																																							case 176:
																																							case 178:
																																							case 182:
																																							case 198:
																																							case 204:
																																							case 206:
																																							case 210:
																																								goto end_IL_0399;
																																							case 147:
																																								goto IL_0e0a;
																																							case 128:
																																								goto IL_0e18;
																																							case 174:
																																								goto IL_0e26;
																																							case 1:
																																							case 2:
																																							case 4:
																																							case 11:
																																							case 19:
																																							case 25:
																																							case 32:
																																							case 38:
																																							case 45:
																																							case 47:
																																							case 48:
																																							case 55:
																																							case 80:
																																							case 86:
																																							case 95:
																																							case 102:
																																							case 120:
																																							case 133:
																																							case 134:
																																							case 140:
																																							case 166:
																																							case 171:
																																							case 187:
																																							case 193:
																																								goto IL_0e34;
																																							case 162:
																																								goto IL_0e47;
																																							case 143:
																																								goto IL_0e52;
																																							case 52:
																																								goto IL_0e5c;
																																							case 64:
																																								goto IL_0e67;
																																							case 111:
																																								goto IL_0e77;
																																							case 163:
																																								goto IL_0e87;
																																							case 135:
																																								goto IL_0e97;
																																							case 26:
																																								goto IL_0ea7;
																																							case 214:
																																								goto IL_0eb7;
																																							case 29:
																																								goto IL_0ed0;
																																							case 146:
																																								goto IL_0ee0;
																																							case 83:
																																								goto IL_0ef0;
																																							case 5:
																																							case 124:
																																								goto IL_0f0b;
																																							}
																																							goto end_IL_043c;
																																							continue;
																																							end_IL_0399:
																																							break;
																																						}
																																						break;
																																						IL_03ac:;
																																					}
																																					break;
																																					IL_03bf:;
																																				}
																																				break;
																																			}
																																			goto IL_0477;
																																			IL_0ba9:
																																			num6--;
																																			goto IL_0e34;
																																			IL_0477:
																																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																			goto IL_04b7;
																																			IL_04b7:
																																			array2[num6 - 2] = 0;
																																			goto IL_0ba9;
																																		}
																																		break;
																																	}
																																	goto IL_0467;
																																	IL_0a54:
																																	ptr2 += 8;
																																	goto IL_0e34;
																																	IL_0467:
																																	if (3 >= b)
																																	{
																																		goto IL_04d0;
																																	}
																																	goto IL_051a;
																																	IL_04d0:
																																	if (3 > b)
																																	{
																																		break;
																																	}
																																	goto IL_04de;
																																	IL_04de:
																																	reference = ref array5[*(int*)(ptr2 + num3)];
																																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																	goto IL_0507;
																																	IL_0507:
																																	ptr2 += 8;
																																	goto IL_09ef;
																																	IL_09ef:
																																	num6--;
																																	goto IL_0e34;
																																	IL_051a:
																																	if (4 < b)
																																	{
																																		break;
																																	}
																																	goto IL_0528;
																																	IL_0528:
																																	if (4 > b)
																																	{
																																		break;
																																	}
																																	goto IL_0a02;
																																	IL_0a02:
																																	array2[num6] = 0;
																																	goto IL_0a10;
																																	IL_0a10:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																	num = 31;
																																	goto IL_0a3c;
																																	IL_0a3c:
																																	array3[num6] = null;
																																	goto IL_0a46;
																																	IL_0a46:
																																	num6++;
																																	goto IL_0a54;
																																}
																																break;
																															}
																															goto IL_0d15;
																															IL_0d69:
																															num6--;
																															goto IL_0e34;
																															IL_0d15:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																															goto IL_0d55;
																															IL_0d55:
																															array2[num6 - 2] = 0;
																															goto IL_0d69;
																														}
																														break;
																													}
																													goto IL_053b;
																													IL_06ea:
																													array2[num6 - 2] = 0;
																													num = 175;
																													goto IL_0707;
																													IL_053b:
																													if (8 < b)
																													{
																														goto IL_0549;
																													}
																													goto IL_064a;
																													IL_0549:
																													if (9 < b)
																													{
																														goto IL_0557;
																													}
																													goto IL_05fa;
																													IL_0557:
																													if (10 < b)
																													{
																														break;
																													}
																													num = 103;
																													goto IL_056e;
																													IL_0707:
																													num6--;
																													goto IL_0e34;
																													IL_056e:
																													if (10 > b)
																													{
																														break;
																													}
																													num = 46;
																													goto IL_0585;
																													IL_09dc:
																													num6--;
																													goto IL_0e34;
																													IL_0585:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_05e7;
																													IL_05e7:
																													num6 -= 2;
																													goto IL_0e34;
																													IL_05fa:
																													if (9 > b)
																													{
																														break;
																													}
																													goto IL_0608;
																													IL_0608:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0694;
																													IL_0694:
																													array2[num6 - 2] = 0;
																													goto IL_071a;
																													IL_071a:
																													num6--;
																													goto IL_0e34;
																													IL_064a:
																													if (8 > b)
																													{
																														goto IL_0658;
																													}
																													goto IL_09dc;
																													IL_0658:
																													if (6 >= b)
																													{
																														goto IL_0663;
																													}
																													goto IL_0676;
																													IL_0663:
																													if (6 > b)
																													{
																														break;
																													}
																													goto IL_0975;
																													IL_0975:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_09b5;
																													IL_09b5:
																													array2[num6 - 2] = 0;
																													goto IL_09c9;
																													IL_09c9:
																													num6--;
																													goto IL_0e34;
																													IL_0676:
																													if (7 < b)
																													{
																														break;
																													}
																													goto IL_0684;
																													IL_0684:
																													if (7 > b)
																													{
																														break;
																													}
																													goto IL_06aa;
																													IL_06aa:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_06ea;
																												}
																												break;
																											}
																											goto IL_0d7c;
																											IL_0dcf:
																											ptr2 += 8;
																											num = 45;
																											goto IL_0e34;
																											IL_0d7c:
																											array2[num6 - 1] = 0;
																											goto IL_0d90;
																											IL_0d90:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)ReplacementFallbackgetSystemPageSize[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																											goto IL_0dcf;
																										}
																										break;
																									}
																									goto IL_072d;
																									IL_0b4e:
																									if (21 < b)
																									{
																										goto IL_0b59;
																									}
																									goto IL_0b7a;
																									IL_072d:
																									if (17 >= b)
																									{
																										goto IL_073b;
																									}
																									goto IL_0a67;
																									IL_073b:
																									if (17 <= b)
																									{
																										goto IL_0746;
																									}
																									goto IL_0796;
																									IL_0746:
																									array2[num6] = 5;
																									goto IL_0754;
																									IL_0754:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									goto IL_076c;
																									IL_076c:
																									num6++;
																									goto IL_077a;
																									IL_077a:
																									ptr2 += 8;
																									num = 47;
																									goto IL_0e34;
																									IL_0796:
																									if (14 < b)
																									{
																										goto IL_07a1;
																									}
																									goto IL_07eb;
																									IL_07a1:
																									if (15 >= b)
																									{
																										goto IL_07af;
																									}
																									goto IL_0c34;
																									IL_07af:
																									if (15 > b)
																									{
																										break;
																									}
																									goto IL_07bd;
																									IL_07bd:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_095c;
																									IL_095c:
																									array2[num6 - 1] = 5;
																									goto IL_0e34;
																									IL_0c34:
																									if (16 < b)
																									{
																										break;
																									}
																									goto IL_0c42;
																									IL_0c42:
																									if (16 > b)
																									{
																										break;
																									}
																									num = 151;
																									goto IL_0c59;
																									IL_0b59:
																									if (22 < b)
																									{
																										break;
																									}
																									goto IL_0b67;
																									IL_0c59:
																									array2[num6] = array2[num6 - 1];
																									num = 67;
																									goto IL_0c7a;
																									IL_0c7a:
																									array4[num6 - 0] = array4[num6 - 1];
																									goto IL_0c98;
																									IL_0c98:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0cbc;
																									IL_0cbc:
																									array3[num6] = array3[num6 - 1];
																									num = 188;
																									goto IL_0cdd;
																									IL_0cdd:
																									num6++;
																									goto IL_0e34;
																									IL_07eb:
																									if (14 > b)
																									{
																										goto IL_07f9;
																									}
																									goto IL_0914;
																									IL_07f9:
																									if (12 >= b)
																									{
																										goto IL_0804;
																									}
																									goto IL_0817;
																									IL_0804:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_0e34;
																									IL_0817:
																									if (13 < b)
																									{
																										break;
																									}
																									goto IL_0825;
																									IL_0825:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_0833;
																									IL_0833:
																									array8 = array3;
																									num7 = num6;
																									if (array == null)
																									{
																										goto IL_0842;
																									}
																									num8 = ptr2;
																									byte b2 = *num8;
																									ptr2 = num8 + 4;
																									int num9 = *(int*)(ptr2 + num3);
																									ptr2 += 8;
																									byte* ptr3 = ptr2 + num9;
																									byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																									while (ptr2 != ptr3)
																									{
																										*ptr4 = (byte)(*ptr2 ^ b2);
																										ptr2++;
																										ptr4++;
																									}
																									array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																									goto IL_08ea;
																									IL_0b67:
																									if (22 > b)
																									{
																										break;
																									}
																									goto IL_0cf0;
																									IL_0cf0:
																									num10 = ptr2;
																									num11 = -200;
																									num5 = 1;
																									ptr2 = num10 + num11;
																									num = 11;
																									goto IL_0e34;
																									IL_0b7a:
																									if (21 > b)
																									{
																										break;
																									}
																									goto IL_0b88;
																									IL_08ea:
																									array2[num6] = 5;
																									num = 195;
																									goto IL_0901;
																									IL_0901:
																									num6++;
																									goto IL_0e34;
																									IL_0914:
																									array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																									num = 53;
																									goto IL_093b;
																									IL_093b:
																									ptr2 += 8;
																									goto IL_0949;
																									IL_0949:
																									num6--;
																									goto IL_0e34;
																									IL_0a67:
																									if (20 >= b)
																									{
																										goto IL_0a75;
																									}
																									goto IL_0b4e;
																									IL_0a75:
																									if (20 > b)
																									{
																										goto IL_0a80;
																									}
																									goto IL_0afd;
																									IL_0a80:
																									if (18 < b)
																									{
																										goto IL_0a8b;
																									}
																									goto IL_0a9e;
																									IL_0a8b:
																									if (19 < b)
																									{
																										break;
																									}
																									goto IL_0bbc;
																									IL_0bbc:
																									if (19 > b)
																									{
																										num = 132;
																										break;
																									}
																									goto IL_0bc7;
																									IL_0bc7:
																									array2[num6 - 1] = 5;
																									goto IL_0bdb;
																									IL_0bdb:
																									array3[num6 - 1] = ((delegate*<string[], string>)ReplacementFallbackgetSystemPageSize[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_0c13;
																									IL_0c13:
																									ptr2 += 8;
																									goto IL_0e34;
																									IL_0b88:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									num = 32;
																									goto IL_0e34;
																									IL_0a9e:
																									if (18 > b)
																									{
																										break;
																									}
																									goto IL_0aac;
																									IL_0aac:
																									((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																									goto IL_0aea;
																									IL_0aea:
																									num6 -= 3;
																									goto IL_0e34;
																									IL_0afd:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0b16;
																									IL_0b16:
																									array2[num6] = 1;
																									num = 42;
																									goto IL_0b2d;
																									IL_0b2d:
																									num6++;
																									goto IL_0b3b;
																									IL_0b3b:
																									ptr2 += 16;
																									goto IL_0e34;
																								}
																								break;
																								IL_042c:;
																							}
																						}
																						else
																						{
																							num = 22;
																						}
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0e0a;
																						IL_0e18:
																						num6++;
																						goto IL_0e26;
																						IL_0e26:
																						ptr2 += 8;
																						goto IL_0e34;
																						IL_0e0a:
																						array2[num6] = 0;
																						goto IL_0e18;
																						continue;
																						end_IL_043c:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		goto IL_0f0b;
																		IL_0f0b:
																		return (string)array3[num6 - 1];
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0842:
				while (true)
				{
					IL_0842_2:
					array = new byte[4];
					while (true)
					{
						IL_0850:
						num8 = ptr2;
						byte b2 = *num8;
						ptr2 = num8 + 4;
						int num9 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num9;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							num = 195;
							while (true)
							{
								IL_0901_2:
								num6++;
								while (true)
								{
									IL_0e34_2:
									if (num5 != 1)
									{
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_043c_2:
													if (b >= 1)
													{
														while (b <= 22)
														{
															while (true)
															{
																IL_041c_2:
																if (11 >= b)
																{
																	while (true)
																	{
																		IL_040c_2:
																		if (11 > b)
																		{
																			while (true)
																			{
																				IL_03fc_2:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_03ec_2:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_03df_2:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_03cf_2:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (1 > b)
																												{
																													num = 223;
																													while (num != 223)
																													{
																														if (num != 1204)
																														{
																															goto IL_0676_2;
																														}
																														switch (num)
																														{
																														case 39:
																															goto IL_03ac_2;
																														case 74:
																															goto IL_03bf_2;
																														case 96:
																															goto IL_03cf_2;
																														case 17:
																														case 126:
																															goto IL_03df_2;
																														case 136:
																															goto IL_03ec_2;
																														case 44:
																														case 113:
																															goto IL_03fc_2;
																														case 194:
																															goto IL_040c_2;
																														case 34:
																															goto IL_041c_2;
																														case 20:
																															goto IL_042c_2;
																														case 88:
																															goto IL_043c_2;
																														case 79:
																															goto end_IL_043c_2;
																														case 99:
																														case 158:
																															goto end_IL_044c;
																														case 9:
																														case 116:
																															goto IL_0467_2;
																														case 21:
																														case 118:
																															goto IL_0477_2;
																														case 93:
																															goto IL_04b7_2;
																														case 141:
																															goto IL_04d0_2;
																														case 43:
																														case 73:
																															goto IL_04de_2;
																														case 119:
																															goto IL_0507_2;
																														case 149:
																															goto IL_051a_2;
																														case 24:
																															goto IL_0528_2;
																														case 129:
																														case 152:
																															goto IL_053b_2;
																														case 101:
																															goto IL_0549_2;
																														case 3:
																														case 35:
																															goto IL_0557_2;
																														case 103:
																															goto IL_056e_2;
																														case 46:
																														case 76:
																															goto IL_0585_2;
																														case 150:
																															goto IL_05e7_2;
																														case 145:
																															goto IL_05fa_2;
																														case 131:
																														case 138:
																															goto IL_0608_2;
																														case 172:
																															goto IL_064a_2;
																														case 91:
																															goto IL_0658_2;
																														case 18:
																															goto IL_0663_2;
																														case 180:
																															goto IL_0676_2;
																														case 100:
																															goto IL_0684_2;
																														case 183:
																															goto IL_0694_2;
																														case 181:
																														case 190:
																															goto IL_06aa_2;
																														case 81:
																															goto IL_06ea_2;
																														case 175:
																															goto IL_0707_2;
																														case 192:
																															goto IL_071a_2;
																														case 117:
																														case 196:
																															goto IL_072d_2;
																														case 127:
																															goto IL_073b_2;
																														case 51:
																														case 57:
																															goto IL_0746_2;
																														case 14:
																															goto IL_0754_2;
																														case 16:
																															goto IL_076c_2;
																														case 189:
																															goto IL_077a_2;
																														case 75:
																															goto IL_0796_2;
																														case 97:
																														case 165:
																															goto IL_07a1_2;
																														case 49:
																															goto IL_07af_2;
																														case 69:
																														case 184:
																															goto IL_07bd_2;
																														case 104:
																															goto IL_07eb_2;
																														case 77:
																														case 191:
																															goto IL_07f9_2;
																														case 0:
																															goto IL_0804_2;
																														case 154:
																															goto IL_0817_2;
																														case 7:
																															goto IL_0825_2;
																														case 36:
																														case 63:
																															goto IL_0833_2;
																														case 186:
																															goto end_IL_045c;
																														case 195:
																															goto IL_0901_2;
																														case 6:
																														case 170:
																															goto IL_0914_2;
																														case 53:
																															goto IL_093b_2;
																														case 58:
																															goto IL_0949_2;
																														case 199:
																															goto IL_095c_2;
																														case 177:
																														case 200:
																															goto IL_0975_2;
																														case 105:
																															goto IL_09b5_2;
																														case 179:
																															goto IL_09c9_2;
																														case 54:
																														case 201:
																															goto IL_09dc_2;
																														case 203:
																															goto IL_09ef_2;
																														case 59:
																														case 208:
																															goto IL_0a02_2;
																														case 71:
																															goto IL_0a10_2;
																														case 31:
																															goto IL_0a3c_2;
																														case 160:
																															goto IL_0a46_2;
																														case 159:
																															goto IL_0a54_2;
																														case 139:
																														case 209:
																															goto IL_0a67_2;
																														case 144:
																															goto IL_0a75_2;
																														case 82:
																														case 185:
																															goto IL_0a80_2;
																														case 8:
																														case 12:
																															goto IL_0a8b_2;
																														case 106:
																															goto IL_0a9e_2;
																														case 61:
																														case 78:
																															goto IL_0aac_2;
																														case 197:
																															goto IL_0aea_2;
																														case 122:
																														case 169:
																															goto IL_0afd_2;
																														case 157:
																															goto IL_0b16_2;
																														case 42:
																															goto IL_0b2d_2;
																														case 110:
																															goto IL_0b3b_2;
																														case 207:
																															goto IL_0b4e_2;
																														case 10:
																														case 205:
																															goto IL_0b59_2;
																														case 85:
																															goto IL_0b67_2;
																														case 115:
																															goto IL_0b7a_2;
																														case 37:
																														case 142:
																															goto IL_0b88_2;
																														case 211:
																															goto IL_0ba9_2;
																														case 212:
																															goto IL_0bbc_2;
																														case 41:
																														case 108:
																															goto IL_0bc7_2;
																														case 65:
																															goto IL_0bdb_2;
																														case 148:
																															goto IL_0c13_2;
																														case 213:
																															goto IL_0c34_2;
																														case 137:
																															goto IL_0c42_2;
																														case 151:
																														case 202:
																															goto IL_0c59_2;
																														case 67:
																															goto IL_0c7a_2;
																														case 87:
																															goto IL_0c98_2;
																														case 72:
																															goto IL_0cbc_2;
																														case 188:
																															goto IL_0cdd_2;
																														case 156:
																														case 215:
																															goto IL_0cf0_2;
																														case 68:
																														case 89:
																															goto IL_0d15_2;
																														case 167:
																															goto IL_0d55_2;
																														case 121:
																															goto IL_0d69_2;
																														case 50:
																														case 153:
																															goto IL_0d7c_2;
																														case 164:
																															goto IL_0d90_2;
																														case 216:
																															goto IL_0dcf_2;
																														case 13:
																														case 15:
																														case 22:
																														case 23:
																														case 27:
																														case 28:
																														case 30:
																														case 33:
																														case 40:
																														case 56:
																														case 60:
																														case 62:
																														case 66:
																														case 70:
																														case 90:
																														case 92:
																														case 94:
																														case 98:
																														case 107:
																														case 109:
																														case 112:
																														case 114:
																														case 123:
																														case 125:
																														case 130:
																														case 132:
																														case 155:
																														case 161:
																														case 168:
																														case 173:
																														case 176:
																														case 178:
																														case 182:
																														case 198:
																														case 204:
																														case 206:
																														case 210:
																															goto end_IL_0399_2;
																														case 147:
																															goto IL_0e0a_2;
																														case 128:
																															goto IL_0e18_2;
																														case 174:
																															goto IL_0e26_2;
																														case 1:
																														case 2:
																														case 4:
																														case 11:
																														case 19:
																														case 25:
																														case 32:
																														case 38:
																														case 45:
																														case 47:
																														case 48:
																														case 55:
																														case 80:
																														case 86:
																														case 95:
																														case 102:
																														case 120:
																														case 133:
																														case 134:
																														case 140:
																														case 166:
																														case 171:
																														case 187:
																														case 193:
																															goto IL_0e34_2;
																														case 162:
																															num = 193;
																															goto IL_0e34_2;
																														case 143:
																															ptr2 = ptr;
																															goto case 162;
																														case 52:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref FSourceArgumentInvalidArrayType.LowLatencygetActivationArguments);
																															goto case 143;
																														case 64:
																															array7 = new object[12];
																															goto case 52;
																														case 111:
																															array6 = new long[4];
																															goto case 64;
																														case 163:
																															array5 = new int[6];
																															goto case 111;
																														case 135:
																															array4 = new int[4];
																															goto case 163;
																														case 26:
																															array3 = new object[4];
																															goto case 135;
																														case 214:
																															array2 = new byte[4];
																															num = 26;
																															goto case 26;
																														case 29:
																															num4 = num2 * 8;
																															goto case 214;
																														case 146:
																															num3 = num2 * 4;
																															goto case 29;
																														case 83:
																															num2 = 1;
																															goto case 146;
																														case 84:
																															goto end_IL_08ea;
																														case 5:
																														case 124:
																															goto IL_0f0b_2;
																														}
																														continue;
																														end_IL_0399_2:
																														break;
																													}
																													break;
																													IL_03ac_2:;
																												}
																												break;
																												IL_03bf_2:;
																											}
																											break;
																										}
																										goto IL_0477_2;
																										IL_0ba9_2:
																										num6--;
																										goto IL_0e34_2;
																										IL_0477_2:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_04b7_2;
																										IL_04b7_2:
																										array2[num6 - 2] = 0;
																										goto IL_0ba9_2;
																									}
																									break;
																								}
																								goto IL_0467_2;
																								IL_0a54_2:
																								ptr2 += 8;
																								goto IL_0e34_2;
																								IL_0467_2:
																								if (3 >= b)
																								{
																									goto IL_04d0_2;
																								}
																								goto IL_051a_2;
																								IL_04d0_2:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_04de_2;
																								IL_04de_2:
																								reference = ref array5[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0507_2;
																								IL_0507_2:
																								ptr2 += 8;
																								goto IL_09ef_2;
																								IL_09ef_2:
																								num6--;
																								goto IL_0e34_2;
																								IL_051a_2:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0528_2;
																								IL_0528_2:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0a02_2;
																								IL_0a02_2:
																								array2[num6] = 0;
																								goto IL_0a10_2;
																								IL_0a10_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																								num = 31;
																								goto IL_0a3c_2;
																								IL_0a3c_2:
																								array3[num6] = null;
																								goto IL_0a46_2;
																								IL_0a46_2:
																								num6++;
																								goto IL_0a54_2;
																							}
																							break;
																						}
																						goto IL_0d15_2;
																						IL_0d69_2:
																						num6--;
																						goto IL_0e34_2;
																						IL_0d15_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0d55_2;
																						IL_0d55_2:
																						array2[num6 - 2] = 0;
																						goto IL_0d69_2;
																					}
																					break;
																				}
																				goto IL_053b_2;
																				IL_06ea_2:
																				array2[num6 - 2] = 0;
																				num = 175;
																				goto IL_0707_2;
																				IL_053b_2:
																				if (8 < b)
																				{
																					goto IL_0549_2;
																				}
																				goto IL_064a_2;
																				IL_0549_2:
																				if (9 < b)
																				{
																					goto IL_0557_2;
																				}
																				goto IL_05fa_2;
																				IL_0557_2:
																				if (10 < b)
																				{
																					break;
																				}
																				num = 103;
																				goto IL_056e_2;
																				IL_0707_2:
																				num6--;
																				goto IL_0e34_2;
																				IL_056e_2:
																				if (10 > b)
																				{
																					break;
																				}
																				num = 46;
																				goto IL_0585_2;
																				IL_09dc_2:
																				num6--;
																				goto IL_0e34_2;
																				IL_0585_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_05e7_2;
																				IL_05e7_2:
																				num6 -= 2;
																				goto IL_0e34_2;
																				IL_05fa_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0608_2;
																				IL_0608_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0694_2;
																				IL_0694_2:
																				array2[num6 - 2] = 0;
																				goto IL_071a_2;
																				IL_071a_2:
																				num6--;
																				goto IL_0e34_2;
																				IL_064a_2:
																				if (8 > b)
																				{
																					goto IL_0658_2;
																				}
																				goto IL_09dc_2;
																				IL_0658_2:
																				if (6 >= b)
																				{
																					goto IL_0663_2;
																				}
																				goto IL_0676_2;
																				IL_0663_2:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0975_2;
																				IL_0975_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_09b5_2;
																				IL_09b5_2:
																				array2[num6 - 2] = 0;
																				goto IL_09c9_2;
																				IL_09c9_2:
																				num6--;
																				goto IL_0e34_2;
																				IL_0676_2:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_0684_2;
																				IL_0684_2:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_06aa_2;
																				IL_06aa_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_06ea_2;
																			}
																			break;
																		}
																		goto IL_0d7c_2;
																		IL_0dcf_2:
																		ptr2 += 8;
																		num = 45;
																		goto IL_0e34_2;
																		IL_0d7c_2:
																		array2[num6 - 1] = 0;
																		goto IL_0d90_2;
																		IL_0d90_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<int, int>)ReplacementFallbackgetSystemPageSize[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0dcf_2;
																	}
																	break;
																}
																goto IL_072d_2;
																IL_0cf0_2:
																num10 = ptr2;
																num11 = -200;
																num5 = 1;
																ptr2 = num10 + num11;
																num = 11;
																goto IL_0e34_2;
																IL_072d_2:
																if (17 >= b)
																{
																	goto IL_073b_2;
																}
																goto IL_0a67_2;
																IL_073b_2:
																if (17 <= b)
																{
																	goto IL_0746_2;
																}
																goto IL_0796_2;
																IL_0746_2:
																array2[num6] = 5;
																goto IL_0754_2;
																IL_0754_2:
																array3[num6] = array7[*(int*)(ptr2 + num3)];
																goto IL_076c_2;
																IL_076c_2:
																num6++;
																goto IL_077a_2;
																IL_077a_2:
																ptr2 += 8;
																num = 47;
																goto IL_0e34_2;
																IL_0796_2:
																if (14 < b)
																{
																	goto IL_07a1_2;
																}
																goto IL_07eb_2;
																IL_07a1_2:
																if (15 >= b)
																{
																	goto IL_07af_2;
																}
																goto IL_0c34_2;
																IL_07af_2:
																if (15 > b)
																{
																	break;
																}
																goto IL_07bd_2;
																IL_07bd_2:
																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																goto IL_095c_2;
																IL_095c_2:
																array2[num6 - 1] = 5;
																goto IL_0e34_2;
																IL_0c34_2:
																if (16 < b)
																{
																	break;
																}
																goto IL_0c42_2;
																IL_0c42_2:
																if (16 > b)
																{
																	break;
																}
																num = 151;
																goto IL_0c59_2;
																IL_0b7a_2:
																if (21 > b)
																{
																	break;
																}
																goto IL_0b88_2;
																IL_0c59_2:
																array2[num6] = array2[num6 - 1];
																num = 67;
																goto IL_0c7a_2;
																IL_0c7a_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_0c98_2;
																IL_0c98_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_0cbc_2;
																IL_0cbc_2:
																array3[num6] = array3[num6 - 1];
																num = 188;
																goto IL_0cdd_2;
																IL_0cdd_2:
																num6++;
																goto IL_0e34_2;
																IL_07eb_2:
																if (14 > b)
																{
																	goto IL_07f9_2;
																}
																goto IL_0914_2;
																IL_07f9_2:
																if (12 >= b)
																{
																	goto IL_0804_2;
																}
																goto IL_0817_2;
																IL_0804_2:
																if (12 > b)
																{
																	break;
																}
																goto IL_0e34_2;
																IL_0817_2:
																if (13 < b)
																{
																	break;
																}
																goto IL_0825_2;
																IL_0825_2:
																if (13 > b)
																{
																	break;
																}
																goto IL_0833_2;
																IL_0833_2:
																array8 = array3;
																num7 = num6;
																if (array == null)
																{
																	goto IL_0842_2;
																}
																goto IL_0850;
																IL_0914_2:
																array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																num = 53;
																goto IL_093b_2;
																IL_093b_2:
																ptr2 += 8;
																goto IL_0949_2;
																IL_0949_2:
																num6--;
																goto IL_0e34_2;
																IL_0a67_2:
																if (20 >= b)
																{
																	goto IL_0a75_2;
																}
																goto IL_0b4e_2;
																IL_0a75_2:
																if (20 > b)
																{
																	goto IL_0a80_2;
																}
																goto IL_0afd_2;
																IL_0a80_2:
																if (18 < b)
																{
																	goto IL_0a8b_2;
																}
																goto IL_0a9e_2;
																IL_0a8b_2:
																if (19 < b)
																{
																	break;
																}
																goto IL_0bbc_2;
																IL_0bbc_2:
																if (19 > b)
																{
																	num = 132;
																	break;
																}
																goto IL_0bc7_2;
																IL_0bc7_2:
																array2[num6 - 1] = 5;
																goto IL_0bdb_2;
																IL_0bdb_2:
																array3[num6 - 1] = ((delegate*<string[], string>)ReplacementFallbackgetSystemPageSize[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_0c13_2;
																IL_0c13_2:
																ptr2 += 8;
																goto IL_0e34_2;
																IL_0b88_2:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 32;
																goto IL_0e34_2;
																IL_0a9e_2:
																if (18 > b)
																{
																	break;
																}
																goto IL_0aac_2;
																IL_0aac_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0aea_2;
																IL_0aea_2:
																num6 -= 3;
																goto IL_0e34_2;
																IL_0afd_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																goto IL_0b16_2;
																IL_0b16_2:
																array2[num6] = 1;
																num = 42;
																goto IL_0b2d_2;
																IL_0b2d_2:
																num6++;
																goto IL_0b3b_2;
																IL_0b3b_2:
																ptr2 += 16;
																goto IL_0e34_2;
																IL_0b4e_2:
																if (21 < b)
																{
																	goto IL_0b59_2;
																}
																goto IL_0b7a_2;
																IL_0b59_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_0b67_2;
																IL_0b67_2:
																if (22 > b)
																{
																	break;
																}
																goto IL_0cf0_2;
															}
															break;
															IL_042c_2:;
														}
													}
													else
													{
														num = 22;
													}
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
													goto IL_0e0a_2;
													IL_0e18_2:
													num6++;
													goto IL_0e26_2;
													IL_0e26_2:
													ptr2 += 8;
													goto IL_0e34_2;
													IL_0e0a_2:
													array2[num6] = 0;
													goto IL_0e18_2;
													continue;
													end_IL_043c_2:
													break;
												}
												continue;
												end_IL_044c:
												break;
											}
											continue;
											end_IL_045c:
											break;
										}
										break;
									}
									goto IL_0f0b_2;
									IL_0f0b_2:
									return (string)array3[num6 - 1];
								}
								break;
							}
							continue;
							end_IL_08ea:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	protected unsafe override string GadgetName
	{
		get
		{
			//The blocks IL_000e, IL_001e, IL_0367, IL_037a, IL_0393, IL_03a3, IL_03af, IL_03d4, IL_03ed, IL_03fd, IL_040d, IL_041d, IL_042d, IL_043d, IL_044d, IL_045d, IL_046d, IL_047d, IL_048d, IL_049d, IL_04a8, IL_04b3, IL_04c1, IL_04ea, IL_04f8, IL_050b, IL_0516, IL_0524, IL_0537, IL_0577, IL_0594, IL_05a7, IL_05e7, IL_05fb, IL_060e, IL_061c, IL_062a, IL_0638, IL_0646, IL_06a8, IL_06bb, IL_06c9, IL_0709, IL_071d, IL_0739, IL_0747, IL_0752, IL_0760, IL_07a0, IL_07b4, IL_07c7, IL_07d5, IL_07e3, IL_0823, IL_0837, IL_084a, IL_085d, IL_086b, IL_0879, IL_0887, IL_0892, IL_08a0, IL_08ae, IL_08c2, IL_08fa, IL_090d, IL_0918, IL_0926, IL_096d, IL_0980, IL_0999, IL_09a7, IL_09b5, IL_09c8, IL_09d3, IL_09e1, IL_09f9, IL_0a07, IL_0a15, IL_0a31, IL_0a3f, IL_0a4d, IL_0a5b, IL_0a69, IL_0a77, IL_0a94, IL_0ae3, IL_0aed, IL_0b1a, IL_0b2e, IL_0b3c, IL_0b4f, IL_0b6d, IL_0b7b, IL_0b8e, IL_0b99, IL_0ba7, IL_0bd0, IL_0be9, IL_0bf2, IL_0c00, IL_0c0e, IL_0c26, IL_0c44, IL_0c68, IL_0c80, IL_0c93, IL_0ca1, IL_0cb9, IL_0cc7, IL_0cd7, IL_0cf0, IL_0cfe, IL_0d0c, IL_0d1a, IL_0d2d, IL_0d37, IL_0d42, IL_0d52, IL_0d62, IL_0d72, IL_0d82, IL_0d92, IL_0da2, IL_0db2, IL_0dc2, IL_0ddd are reachable both inside and outside the pinned region starting at IL_0dd7. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
			int num = 19;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2;
				int num3;
				int num4;
				byte[] array2;
				object[] array3;
				int[] array4;
				int[] array5;
				long[] array6;
				object[] array7;
				byte* ptr;
				int __rxRef13 = default(int);
				ref int reference = ref __rxRef13;
				byte* num7;
				int num8;
				object[] array8;
				int num9;
				byte* num10;
				byte* ptr2;
				byte[] array = new byte[4];
				if (true)
				{
					while (true)
					{
						IL_0dc2:
						num2 = 1;
						while (true)
						{
							IL_0db2:
							num3 = num2 * 4;
							while (true)
							{
								IL_0da2:
								num4 = num2 * 8;
								while (true)
								{
									IL_0d92:
									array2 = new byte[4];
									while (true)
									{
										IL_0d82:
										array3 = new object[4];
										while (true)
										{
											IL_0d72:
											array4 = new int[4];
											while (true)
											{
												IL_0d62:
												array5 = new int[6];
												while (true)
												{
													IL_0d52:
													array6 = new long[4];
													while (true)
													{
														IL_0d42:
														array7 = new object[13];
														while (true)
														{
															IL_0d37:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getComparergetCreate.GetHashFromFileWsetInheritedObjectAceType);
															while (true)
															{
																IL_0d2d:
																ptr2 = ptr;
																while (true)
																{
																	if (num5 != 1)
																	{
																		while (true)
																		{
																			IL_04a8:
																			num = 174;
																			while (true)
																			{
																				IL_049d:
																				byte b = *ptr2;
																				while (true)
																				{
																					IL_048d:
																					ptr2++;
																					while (true)
																					{
																						IL_047d:
																						if (b >= 1)
																						{
																							while (b <= 21)
																							{
																								while (true)
																								{
																									IL_045d:
																									if (11 >= b)
																									{
																										while (11 > b)
																										{
																											while (true)
																											{
																												IL_043d:
																												if (5 >= b)
																												{
																													while (true)
																													{
																														IL_042d:
																														if (5 > b)
																														{
																															while (true)
																															{
																																IL_041d:
																																if (2 < b)
																																{
																																	while (true)
																																	{
																																		IL_040d:
																																		if (3 < b)
																																		{
																																			while (4 >= b)
																																			{
																																				while (4 <= b)
																																				{
																																					while (true)
																																					{
																																						IL_03d4:
																																						array2[num6] = 0;
																																						num = 6;
																																						while (true)
																																						{
																																							IL_03af:
																																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																																							while (true)
																																							{
																																								IL_03a3:
																																								array3[num6] = null;
																																								while (true)
																																								{
																																									IL_0393:
																																									num6++;
																																									while (true)
																																									{
																																										IL_037a:
																																										ptr2 += 8;
																																										num = 214;
																																										while (num != 214)
																																										{
																																											if (num != 1195)
																																											{
																																												goto IL_04c1;
																																											}
																																											switch (num)
																																											{
																																											case 19:
																																												break;
																																											default:
																																												continue;
																																											case 62:
																																												goto IL_037a;
																																											case 136:
																																												goto IL_0393;
																																											case 90:
																																												goto IL_03a3;
																																											case 6:
																																												goto IL_03af;
																																											case 43:
																																											case 195:
																																												goto IL_03d4;
																																											case 65:
																																												goto IL_03ed;
																																											case 42:
																																											case 144:
																																												goto IL_03fd;
																																											case 48:
																																											case 132:
																																												goto IL_040d;
																																											case 32:
																																											case 82:
																																												goto IL_041d;
																																											case 83:
																																												goto IL_042d;
																																											case 37:
																																											case 49:
																																												goto IL_043d;
																																											case 168:
																																												goto IL_044d;
																																											case 30:
																																												goto IL_045d;
																																											case 105:
																																												goto IL_046d;
																																											case 179:
																																												goto IL_047d;
																																											case 142:
																																												goto IL_048d;
																																											case 174:
																																												goto IL_049d;
																																											case 26:
																																												goto IL_04a8;
																																											case 87:
																																												goto IL_04b3;
																																											case 11:
																																											case 28:
																																												goto IL_04c1;
																																											case 125:
																																												goto IL_04ea;
																																											case 33:
																																												goto IL_04f8;
																																											case 198:
																																												goto IL_050b;
																																											case 180:
																																												goto IL_0516;
																																											case 145:
																																												goto IL_0524;
																																											case 109:
																																											case 147:
																																												goto IL_0537;
																																											case 76:
																																												goto IL_0577;
																																											case 148:
																																												goto IL_0594;
																																											case 9:
																																											case 120:
																																												goto IL_05a7;
																																											case 191:
																																												goto IL_05e7;
																																											case 53:
																																												goto IL_05fb;
																																											case 55:
																																												goto IL_060e;
																																											case 129:
																																											case 163:
																																												goto IL_061c;
																																											case 77:
																																												goto IL_062a;
																																											case 12:
																																												goto IL_0638;
																																											case 75:
																																											case 98:
																																												goto IL_0646;
																																											case 115:
																																												goto IL_06a8;
																																											case 192:
																																												goto IL_06bb;
																																											case 24:
																																											case 106:
																																												goto IL_06c9;
																																											case 20:
																																												goto IL_0709;
																																											case 7:
																																												goto IL_071d;
																																											case 200:
																																												goto IL_0739;
																																											case 68:
																																											case 177:
																																												goto IL_0747;
																																											case 154:
																																												goto IL_0752;
																																											case 58:
																																											case 162:
																																												goto IL_0760;
																																											case 61:
																																												goto IL_07a0;
																																											case 16:
																																												goto IL_07b4;
																																											case 197:
																																											case 204:
																																												goto IL_07c7;
																																											case 74:
																																												goto IL_07d5;
																																											case 121:
																																											case 165:
																																												goto IL_07e3;
																																											case 161:
																																												goto IL_0823;
																																											case 135:
																																												goto IL_0837;
																																											case 93:
																																											case 130:
																																												goto IL_084a;
																																											case 51:
																																											case 193:
																																												goto IL_085d;
																																											case 100:
																																											case 183:
																																												goto IL_086b;
																																											case 41:
																																												goto IL_0879;
																																											case 96:
																																											case 164:
																																												goto IL_0887;
																																											case 137:
																																												goto IL_0892;
																																											case 72:
																																												goto IL_08a0;
																																											case 27:
																																											case 173:
																																												goto IL_08ae;
																																											case 146:
																																												goto IL_08c2;
																																											case 184:
																																												goto IL_08fa;
																																											case 151:
																																												goto IL_090d;
																																											case 122:
																																											case 187:
																																												goto IL_0926;
																																											case 25:
																																												goto IL_096d;
																																											case 99:
																																											case 171:
																																												goto IL_0980;
																																											case 117:
																																												goto IL_0999;
																																											case 138:
																																												goto IL_09a7;
																																											case 189:
																																												goto IL_09b5;
																																											case 182:
																																												goto IL_09c8;
																																											case 167:
																																												goto IL_09d3;
																																											case 45:
																																											case 107:
																																												goto IL_09e1;
																																											case 150:
																																												goto IL_09f9;
																																											case 17:
																																												goto IL_0a07;
																																											case 57:
																																											case 104:
																																												goto IL_0a15;
																																											case 67:
																																												goto IL_0a31;
																																											case 66:
																																											case 176:
																																												goto IL_0a3f;
																																											case 194:
																																												goto IL_0a4d;
																																											case 31:
																																												goto IL_0a5b;
																																											case 157:
																																												goto IL_0a69;
																																											case 10:
																																											case 71:
																																												goto IL_0a77;
																																											case 156:
																																												goto IL_0b2e;
																																											case 190:
																																												goto IL_0b3c;
																																											case 34:
																																											case 52:
																																												goto IL_0b4f;
																																											case 199:
																																												goto IL_0b6d;
																																											case 70:
																																												goto IL_0b7b;
																																											case 134:
																																												goto IL_0b8e;
																																											case 128:
																																												goto IL_0b99;
																																											case 35:
																																											case 181:
																																												goto IL_0ba7;
																																											case 169:
																																												goto IL_0bd0;
																																											case 102:
																																											case 113:
																																												goto IL_0bf2;
																																											case 5:
																																												goto IL_0c00;
																																											case 141:
																																											case 152:
																																												goto IL_0c0e;
																																											case 1:
																																												goto IL_0c26;
																																											case 111:
																																												goto IL_0c44;
																																											case 81:
																																												goto IL_0c68;
																																											case 88:
																																												goto IL_0c80;
																																											case 36:
																																											case 46:
																																												goto IL_0c93;
																																											case 205:
																																												goto IL_0ca1;
																																											case 196:
																																												goto IL_0cb9;
																																											case 64:
																																												goto IL_0cc7;
																																											case 3:
																																											case 4:
																																											case 8:
																																											case 29:
																																											case 39:
																																											case 40:
																																											case 44:
																																											case 56:
																																											case 59:
																																											case 63:
																																											case 69:
																																											case 78:
																																											case 80:
																																											case 85:
																																											case 86:
																																											case 94:
																																											case 95:
																																											case 97:
																																											case 101:
																																											case 103:
																																											case 112:
																																											case 114:
																																											case 123:
																																											case 124:
																																											case 127:
																																											case 131:
																																											case 133:
																																											case 158:
																																											case 159:
																																											case 166:
																																											case 185:
																																											case 186:
																																											case 188:
																																											case 202:
																																											case 203:
																																											case 207:
																																												goto end_IL_03ed;
																																											case 116:
																																												goto IL_0cf0;
																																											case 175:
																																												goto IL_0cfe;
																																											case 178:
																																												goto IL_0d0c;
																																											case 0:
																																											case 2:
																																											case 13:
																																											case 15:
																																											case 22:
																																											case 23:
																																											case 38:
																																											case 47:
																																											case 73:
																																											case 79:
																																											case 91:
																																											case 118:
																																											case 119:
																																											case 126:
																																											case 139:
																																											case 140:
																																											case 143:
																																											case 149:
																																											case 155:
																																											case 160:
																																											case 170:
																																											case 172:
																																											case 206:
																																												goto end_IL_0367;
																																											case 108:
																																												goto IL_0d2d;
																																											case 54:
																																												goto IL_0d37;
																																											case 92:
																																												goto IL_0d42;
																																											case 14:
																																												goto IL_0d52;
																																											case 50:
																																												goto IL_0d62;
																																											case 201:
																																												goto IL_0d72;
																																											case 89:
																																												goto IL_0d82;
																																											case 84:
																																												goto IL_0d92;
																																											case 110:
																																												goto IL_0da2;
																																											case 153:
																																												goto IL_0db2;
																																											case 18:
																																												goto IL_0dc2;
																																											case 21:
																																											case 60:
																																												goto IL_0ddd;
																																											}
																																											goto end_IL_0d1a;
																																											continue;
																																											end_IL_0367:
																																											break;
																																										}
																																										break;
																																									}
																																									break;
																																								}
																																								break;
																																							}
																																							break;
																																						}
																																						break;
																																					}
																																					goto end_IL_044d;
																																					continue;
																																					end_IL_03ed:
																																					break;
																																					IL_03ed:;
																																				}
																																				break;
																																				IL_03fd:;
																																			}
																																			break;
																																		}
																																		goto IL_04b3;
																																		IL_04f8:
																																		num6--;
																																		goto end_IL_044d;
																																		IL_04b3:
																																		if (3 > b)
																																		{
																																			break;
																																		}
																																		goto IL_04c1;
																																		IL_04c1:
																																		reference = ref array5[*(int*)(ptr2 + num3)];
																																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																		goto IL_04ea;
																																		IL_04ea:
																																		ptr2 += 8;
																																		goto IL_04f8;
																																	}
																																	break;
																																}
																																goto IL_050b;
																																IL_0594:
																																num6--;
																																goto end_IL_044d;
																																IL_050b:
																																if (2 > b)
																																{
																																	goto IL_0516;
																																}
																																goto IL_0537;
																																IL_0516:
																																if (1 < b)
																																{
																																	break;
																																}
																																goto IL_0524;
																																IL_0524:
																																if (1 > b)
																																{
																																}
																																break;
																																IL_0537:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																																goto IL_0577;
																																IL_0577:
																																array2[num6 - 2] = 0;
																																num = 148;
																																goto IL_0594;
																															}
																															break;
																														}
																														goto IL_05a7;
																														IL_05fb:
																														num6--;
																														goto end_IL_044d;
																														IL_05a7:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_05e7;
																														IL_05e7:
																														array2[num6 - 2] = 0;
																														goto IL_05fb;
																													}
																													break;
																												}
																												goto IL_060e;
																												IL_084a:
																												num6--;
																												goto end_IL_044d;
																												IL_060e:
																												if (8 < b)
																												{
																													goto IL_061c;
																												}
																												goto IL_0739;
																												IL_061c:
																												if (9 < b)
																												{
																													goto IL_062a;
																												}
																												goto IL_06bb;
																												IL_062a:
																												if (10 < b)
																												{
																													break;
																												}
																												goto IL_0638;
																												IL_0638:
																												if (10 > b)
																												{
																													break;
																												}
																												goto IL_0646;
																												IL_0646:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_06a8;
																												IL_06a8:
																												num6 -= 2;
																												goto end_IL_044d;
																												IL_06bb:
																												if (9 > b)
																												{
																													break;
																												}
																												goto IL_06c9;
																												IL_06c9:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0709;
																												IL_0709:
																												array2[num6 - 2] = 0;
																												goto IL_071d;
																												IL_071d:
																												num6--;
																												num = 79;
																												goto end_IL_044d;
																												IL_0739:
																												if (8 > b)
																												{
																													goto IL_0747;
																												}
																												goto IL_084a;
																												IL_0747:
																												if (6 >= b)
																												{
																													goto IL_0752;
																												}
																												goto IL_07c7;
																												IL_0752:
																												if (6 > b)
																												{
																													break;
																												}
																												goto IL_0760;
																												IL_0760:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_07a0;
																												IL_07a0:
																												array2[num6 - 2] = 0;
																												goto IL_07b4;
																												IL_07b4:
																												num6--;
																												goto end_IL_044d;
																												IL_07c7:
																												if (7 < b)
																												{
																													break;
																												}
																												goto IL_07d5;
																												IL_07d5:
																												if (7 > b)
																												{
																													break;
																												}
																												goto IL_07e3;
																												IL_07e3:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												goto IL_0823;
																												IL_0823:
																												array2[num6 - 2] = 0;
																												goto IL_0837;
																												IL_0837:
																												num6--;
																												goto end_IL_044d;
																											}
																											goto end_IL_046d;
																											continue;
																											end_IL_044d:
																											break;
																											IL_044d:;
																										}
																										break;
																									}
																									goto IL_085d;
																									IL_0c68:
																									array3[num6] = array3[num6 - 1];
																									goto IL_0c80;
																									IL_085d:
																									if (16 < b)
																									{
																										goto IL_086b;
																									}
																									goto IL_0a31;
																									IL_086b:
																									if (19 >= b)
																									{
																										goto IL_0879;
																									}
																									goto IL_09c8;
																									IL_0879:
																									if (19 > b)
																									{
																										goto IL_0887;
																									}
																									goto IL_0980;
																									IL_0887:
																									if (17 < b)
																									{
																										goto IL_0892;
																									}
																									goto IL_090d;
																									IL_0892:
																									if (18 < b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_08a0;
																									IL_08a0:
																									if (18 > b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_08ae;
																									IL_08ae:
																									array2[num6 - 1] = 5;
																									goto IL_08c2;
																									IL_08c2:
																									array3[num6 - 1] = ((delegate*<string[], string>)GetGenericTypeDefinitionNextChannelSink[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																									goto IL_08fa;
																									IL_08fa:
																									ptr2 += 8;
																									break;
																									IL_090d:
																									if (17 > b)
																									{
																										num = 188;
																										goto end_IL_046d;
																									}
																									goto IL_0926;
																									IL_0c80:
																									num6++;
																									break;
																									IL_0926:
																									((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																									num = 25;
																									goto IL_096d;
																									IL_096d:
																									num6 -= 3;
																									break;
																									IL_0980:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0999;
																									IL_0999:
																									array2[num6] = 1;
																									goto IL_09a7;
																									IL_09a7:
																									num6++;
																									goto IL_09b5;
																									IL_09b5:
																									ptr2 += 16;
																									break;
																									IL_09c8:
																									if (20 >= b)
																									{
																										goto IL_09d3;
																									}
																									goto IL_09f9;
																									IL_09d3:
																									if (20 > b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_09e1;
																									IL_09e1:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									break;
																									IL_09f9:
																									if (21 < b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_0a07;
																									IL_0a07:
																									if (21 > b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_0a15;
																									IL_0a15:
																									num7 = ptr2;
																									num8 = -200;
																									num5 = 1;
																									ptr2 = num7 + num8;
																									break;
																									IL_0a31:
																									if (16 > b)
																									{
																										goto IL_0a3f;
																									}
																									goto IL_0c93;
																									IL_0a3f:
																									if (13 >= b)
																									{
																										goto IL_0a4d;
																									}
																									goto IL_0b8e;
																									IL_0a4d:
																									if (13 > b)
																									{
																										goto IL_0a5b;
																									}
																									goto IL_0b4f;
																									IL_0a5b:
																									if (12 < b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_0a69;
																									IL_0a69:
																									if (12 > b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_0a77;
																									IL_0a77:
																									array8 = array3;
																									num9 = num6;
																									if (array == null)
																									{
																										goto IL_0a86;
																									}
																									num10 = ptr2;
																									byte b2 = *num10;
																									ptr2 = num10 + 4;
																									int num11 = *(int*)(ptr2 + num3);
																									ptr2 += 8;
																									byte* ptr3 = ptr2 + num11;
																									byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																									while (ptr2 != ptr3)
																									{
																										*ptr4 = (byte)(*ptr2 ^ b2);
																										ptr2++;
																										ptr4++;
																									}
																									array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																									goto IL_0b2e;
																									IL_0c93:
																									array2[num6] = 5;
																									goto IL_0ca1;
																									IL_0ca1:
																									array3[num6] = array7[*(int*)(ptr2 + num3)];
																									goto IL_0cb9;
																									IL_0cb9:
																									num6++;
																									goto IL_0cc7;
																									IL_0b2e:
																									array2[num6] = 5;
																									goto IL_0b3c;
																									IL_0b3c:
																									num6++;
																									break;
																									IL_0b4f:
																									array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																									goto IL_0b6d;
																									IL_0b6d:
																									ptr2 += 8;
																									goto IL_0b7b;
																									IL_0b7b:
																									num6--;
																									break;
																									IL_0b8e:
																									if (14 >= b)
																									{
																										goto IL_0b99;
																									}
																									num = 102;
																									goto IL_0bf2;
																									IL_0b99:
																									if (14 > b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_0ba7;
																									IL_0ba7:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_0bd0;
																									IL_0bd0:
																									array2[num6 - 1] = 5;
																									break;
																									IL_0cc7:
																									ptr2 += 8;
																									break;
																									IL_0bf2:
																									if (15 < b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_0c00;
																									IL_0c00:
																									if (15 > b)
																									{
																										goto end_IL_046d;
																									}
																									goto IL_0c0e;
																									IL_0c0e:
																									array2[num6] = array2[num6 - 1];
																									goto IL_0c26;
																									IL_0c26:
																									array4[num6 - 0] = array4[num6 - 1];
																									goto IL_0c44;
																									IL_0c44:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																									goto IL_0c68;
																								}
																								goto end_IL_047d;
																								continue;
																								end_IL_046d:
																								break;
																								IL_046d:;
																							}
																						}
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0cf0;
																						IL_0d0c:
																						ptr2 += 8;
																						break;
																						IL_0cfe:
																						num6++;
																						goto IL_0d0c;
																						IL_0cf0:
																						array2[num6] = 0;
																						goto IL_0cfe;
																						continue;
																						end_IL_047d:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		continue;
																	}
																	goto IL_0ddd;
																	IL_0ddd:
																	return (string)array3[num6 - 1];
																	continue;
																	end_IL_0d1a:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
				}
				continue;
				IL_0a86:
				while (true)
				{
					IL_0a86_2:
					array = new byte[4];
					while (true)
					{
						IL_0a94:
						num10 = ptr2;
						byte b2 = *num10;
						ptr2 = num10 + 4;
						int num11 = *(int*)(ptr2 + num3);
						ptr2 += 8;
						byte* ptr3 = ptr2 + num11;
						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
						while (ptr2 != ptr3)
						{
							*ptr4 = (byte)(*ptr2 ^ b2);
							ptr2++;
							ptr4++;
						}
						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
						while (true)
						{
							array2[num6] = 5;
							while (true)
							{
								IL_0b3c_2:
								num6++;
								while (true)
								{
									if (num5 != 1)
									{
										while (true)
										{
											IL_04a8_2:
											num = 174;
											while (true)
											{
												IL_049d_2:
												byte b = *ptr2;
												while (true)
												{
													IL_048d_2:
													ptr2++;
													while (true)
													{
														IL_047d_2:
														if (b >= 1)
														{
															while (b <= 21)
															{
																while (true)
																{
																	IL_045d_2:
																	if (11 >= b)
																	{
																		while (11 > b)
																		{
																			while (true)
																			{
																				IL_043d_2:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_042d_2:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_041d_2:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_040d_2:
																										if (3 < b)
																										{
																											while (4 >= b)
																											{
																												while (4 <= b)
																												{
																													while (true)
																													{
																														IL_03d4_2:
																														array2[num6] = 0;
																														num = 6;
																														while (true)
																														{
																															IL_03af_2:
																															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																															while (true)
																															{
																																IL_03a3_2:
																																array3[num6] = null;
																																while (true)
																																{
																																	IL_0393_2:
																																	num6++;
																																	while (true)
																																	{
																																		IL_037a_2:
																																		ptr2 += 8;
																																		num = 214;
																																		while (num != 214)
																																		{
																																			if (num != 1195)
																																			{
																																				goto IL_04c1_2;
																																			}
																																			switch (num)
																																			{
																																			case 62:
																																				goto IL_037a_2;
																																			case 136:
																																				goto IL_0393_2;
																																			case 90:
																																				goto IL_03a3_2;
																																			case 6:
																																				goto IL_03af_2;
																																			case 43:
																																			case 195:
																																				goto IL_03d4_2;
																																			case 65:
																																				goto IL_03ed_2;
																																			case 42:
																																			case 144:
																																				goto IL_03fd_2;
																																			case 48:
																																			case 132:
																																				goto IL_040d_2;
																																			case 32:
																																			case 82:
																																				goto IL_041d_2;
																																			case 83:
																																				goto IL_042d_2;
																																			case 37:
																																			case 49:
																																				goto IL_043d_2;
																																			case 168:
																																				goto IL_044d_2;
																																			case 30:
																																				goto IL_045d_2;
																																			case 105:
																																				goto IL_046d_2;
																																			case 179:
																																				goto IL_047d_2;
																																			case 142:
																																				goto IL_048d_2;
																																			case 174:
																																				goto IL_049d_2;
																																			case 26:
																																				goto IL_04a8_2;
																																			case 87:
																																				goto IL_04b3_2;
																																			case 11:
																																			case 28:
																																				goto IL_04c1_2;
																																			case 125:
																																				goto IL_04ea_2;
																																			case 33:
																																				goto IL_04f8_2;
																																			case 198:
																																				goto IL_050b_2;
																																			case 180:
																																				goto IL_0516_2;
																																			case 145:
																																				goto IL_0524_2;
																																			case 109:
																																			case 147:
																																				goto IL_0537_2;
																																			case 76:
																																				goto IL_0577_2;
																																			case 148:
																																				goto IL_0594_2;
																																			case 9:
																																			case 120:
																																				goto IL_05a7_2;
																																			case 191:
																																				goto IL_05e7_2;
																																			case 53:
																																				goto IL_05fb_2;
																																			case 55:
																																				goto IL_060e_2;
																																			case 129:
																																			case 163:
																																				goto IL_061c_2;
																																			case 77:
																																				goto IL_062a_2;
																																			case 12:
																																				goto IL_0638_2;
																																			case 75:
																																			case 98:
																																				goto IL_0646_2;
																																			case 115:
																																				goto IL_06a8_2;
																																			case 192:
																																				goto IL_06bb_2;
																																			case 24:
																																			case 106:
																																				goto IL_06c9_2;
																																			case 20:
																																				goto IL_0709_2;
																																			case 7:
																																				goto IL_071d_2;
																																			case 200:
																																				goto IL_0739_2;
																																			case 68:
																																			case 177:
																																				goto IL_0747_2;
																																			case 154:
																																				goto IL_0752_2;
																																			case 58:
																																			case 162:
																																				goto IL_0760_2;
																																			case 61:
																																				goto IL_07a0_2;
																																			case 16:
																																				goto IL_07b4_2;
																																			case 197:
																																			case 204:
																																				goto IL_07c7_2;
																																			case 74:
																																				goto IL_07d5_2;
																																			case 121:
																																			case 165:
																																				goto IL_07e3_2;
																																			case 161:
																																				goto IL_0823_2;
																																			case 135:
																																				goto IL_0837_2;
																																			case 93:
																																			case 130:
																																				goto IL_084a_2;
																																			case 51:
																																			case 193:
																																				goto IL_085d_2;
																																			case 100:
																																			case 183:
																																				goto IL_086b_2;
																																			case 41:
																																				goto IL_0879_2;
																																			case 96:
																																			case 164:
																																				goto IL_0887_2;
																																			case 137:
																																				goto IL_0892_2;
																																			case 72:
																																				goto IL_08a0_2;
																																			case 27:
																																			case 173:
																																				goto IL_08ae_2;
																																			case 146:
																																				goto IL_08c2_2;
																																			case 184:
																																				goto IL_08fa_2;
																																			case 151:
																																				goto IL_090d_2;
																																			case 122:
																																			case 187:
																																				goto IL_0926_2;
																																			case 25:
																																				goto IL_096d_2;
																																			case 99:
																																			case 171:
																																				goto IL_0980_2;
																																			case 117:
																																				goto IL_0999_2;
																																			case 138:
																																				goto IL_09a7_2;
																																			case 189:
																																				goto IL_09b5_2;
																																			case 182:
																																				goto IL_09c8_2;
																																			case 167:
																																				goto IL_09d3_2;
																																			case 45:
																																			case 107:
																																				goto IL_09e1_2;
																																			case 150:
																																				goto IL_09f9_2;
																																			case 17:
																																				goto IL_0a07_2;
																																			case 57:
																																			case 104:
																																				goto IL_0a15_2;
																																			case 67:
																																				goto IL_0a31_2;
																																			case 66:
																																			case 176:
																																				goto IL_0a3f_2;
																																			case 194:
																																				goto IL_0a4d_2;
																																			case 31:
																																				goto IL_0a5b_2;
																																			case 157:
																																				goto IL_0a69_2;
																																			case 10:
																																			case 71:
																																				goto IL_0a77_2;
																																			case 156:
																																				goto end_IL_0d1a_2;
																																			case 190:
																																				goto IL_0b3c_2;
																																			case 34:
																																			case 52:
																																				goto IL_0b4f_2;
																																			case 199:
																																				goto IL_0b6d_2;
																																			case 70:
																																				goto IL_0b7b_2;
																																			case 134:
																																				goto IL_0b8e_2;
																																			case 128:
																																				goto IL_0b99_2;
																																			case 35:
																																			case 181:
																																				goto IL_0ba7_2;
																																			case 169:
																																				goto IL_0bd0_2;
																																			case 102:
																																			case 113:
																																				goto IL_0bf2_2;
																																			case 5:
																																				goto IL_0c00_2;
																																			case 141:
																																			case 152:
																																				goto IL_0c0e_2;
																																			case 1:
																																				goto IL_0c26_2;
																																			case 111:
																																				goto IL_0c44_2;
																																			case 81:
																																				goto IL_0c68_2;
																																			case 88:
																																				goto IL_0c80_2;
																																			case 36:
																																			case 46:
																																				goto IL_0c93_2;
																																			case 205:
																																				goto IL_0ca1_2;
																																			case 196:
																																				goto IL_0cb9_2;
																																			case 64:
																																				goto IL_0cc7_2;
																																			case 3:
																																			case 4:
																																			case 8:
																																			case 29:
																																			case 39:
																																			case 40:
																																			case 44:
																																			case 56:
																																			case 59:
																																			case 63:
																																			case 69:
																																			case 78:
																																			case 80:
																																			case 85:
																																			case 86:
																																			case 94:
																																			case 95:
																																			case 97:
																																			case 101:
																																			case 103:
																																			case 112:
																																			case 114:
																																			case 123:
																																			case 124:
																																			case 127:
																																			case 131:
																																			case 133:
																																			case 158:
																																			case 159:
																																			case 166:
																																			case 185:
																																			case 186:
																																			case 188:
																																			case 202:
																																			case 203:
																																			case 207:
																																				goto end_IL_03ed_2;
																																			case 116:
																																				goto IL_0cf0_2;
																																			case 175:
																																				goto IL_0cfe_2;
																																			case 178:
																																				goto IL_0d0c_2;
																																			case 0:
																																			case 2:
																																			case 13:
																																			case 15:
																																			case 22:
																																			case 23:
																																			case 38:
																																			case 47:
																																			case 73:
																																			case 79:
																																			case 91:
																																			case 118:
																																			case 119:
																																			case 126:
																																			case 139:
																																			case 140:
																																			case 143:
																																			case 149:
																																			case 155:
																																			case 160:
																																			case 170:
																																			case 172:
																																			case 206:
																																				goto end_IL_0367_2;
																																			case 108:
																																				ptr2 = ptr;
																																				goto end_IL_0367_2;
																																			case 54:
																																				ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getComparergetCreate.GetHashFromFileWsetInheritedObjectAceType);
																																				goto case 108;
																																			case 92:
																																				array7 = new object[13];
																																				goto case 54;
																																			case 14:
																																				array6 = new long[4];
																																				goto case 92;
																																			case 50:
																																				array5 = new int[6];
																																				goto case 14;
																																			case 201:
																																				array4 = new int[4];
																																				goto case 50;
																																			case 89:
																																				array3 = new object[4];
																																				goto case 201;
																																			case 84:
																																				array2 = new byte[4];
																																				goto case 89;
																																			case 110:
																																				num4 = num2 * 8;
																																				goto case 84;
																																			case 153:
																																				num3 = num2 * 4;
																																				goto case 110;
																																			case 18:
																																				num2 = 1;
																																				goto case 153;
																																			case 19:
																																				goto end_IL_0b2e;
																																			case 21:
																																			case 60:
																																				goto IL_0ddd_2;
																																			}
																																			continue;
																																			end_IL_0367_2:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													goto end_IL_044d_2;
																													continue;
																													end_IL_03ed_2:
																													break;
																													IL_03ed_2:;
																												}
																												break;
																												IL_03fd_2:;
																											}
																											break;
																										}
																										goto IL_04b3_2;
																										IL_04f8_2:
																										num6--;
																										goto end_IL_044d_2;
																										IL_04b3_2:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_04c1_2;
																										IL_04c1_2:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_04ea_2;
																										IL_04ea_2:
																										ptr2 += 8;
																										goto IL_04f8_2;
																									}
																									break;
																								}
																								goto IL_050b_2;
																								IL_0594_2:
																								num6--;
																								goto end_IL_044d_2;
																								IL_050b_2:
																								if (2 > b)
																								{
																									goto IL_0516_2;
																								}
																								goto IL_0537_2;
																								IL_0516_2:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0524_2;
																								IL_0524_2:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_0537_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_0577_2;
																								IL_0577_2:
																								array2[num6 - 2] = 0;
																								num = 148;
																								goto IL_0594_2;
																							}
																							break;
																						}
																						goto IL_05a7_2;
																						IL_05fb_2:
																						num6--;
																						goto end_IL_044d_2;
																						IL_05a7_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_05e7_2;
																						IL_05e7_2:
																						array2[num6 - 2] = 0;
																						goto IL_05fb_2;
																					}
																					break;
																				}
																				goto IL_060e_2;
																				IL_084a_2:
																				num6--;
																				goto end_IL_044d_2;
																				IL_060e_2:
																				if (8 < b)
																				{
																					goto IL_061c_2;
																				}
																				goto IL_0739_2;
																				IL_061c_2:
																				if (9 < b)
																				{
																					goto IL_062a_2;
																				}
																				goto IL_06bb_2;
																				IL_062a_2:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0638_2;
																				IL_0638_2:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_0646_2;
																				IL_0646_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06a8_2;
																				IL_06a8_2:
																				num6 -= 2;
																				goto end_IL_044d_2;
																				IL_06bb_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_06c9_2;
																				IL_06c9_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0709_2;
																				IL_0709_2:
																				array2[num6 - 2] = 0;
																				goto IL_071d_2;
																				IL_071d_2:
																				num6--;
																				num = 79;
																				goto end_IL_044d_2;
																				IL_0739_2:
																				if (8 > b)
																				{
																					goto IL_0747_2;
																				}
																				goto IL_084a_2;
																				IL_0747_2:
																				if (6 >= b)
																				{
																					goto IL_0752_2;
																				}
																				goto IL_07c7_2;
																				IL_0752_2:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0760_2;
																				IL_0760_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_07a0_2;
																				IL_07a0_2:
																				array2[num6 - 2] = 0;
																				goto IL_07b4_2;
																				IL_07b4_2:
																				num6--;
																				goto end_IL_044d_2;
																				IL_07c7_2:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_07d5_2;
																				IL_07d5_2:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_07e3_2;
																				IL_07e3_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				goto IL_0823_2;
																				IL_0823_2:
																				array2[num6 - 2] = 0;
																				goto IL_0837_2;
																				IL_0837_2:
																				num6--;
																				goto end_IL_044d_2;
																			}
																			goto end_IL_046d_2;
																			continue;
																			end_IL_044d_2:
																			break;
																			IL_044d_2:;
																		}
																		break;
																	}
																	goto IL_085d_2;
																	IL_0ca1_2:
																	array3[num6] = array7[*(int*)(ptr2 + num3)];
																	goto IL_0cb9_2;
																	IL_085d_2:
																	if (16 < b)
																	{
																		goto IL_086b_2;
																	}
																	goto IL_0a31_2;
																	IL_086b_2:
																	if (19 >= b)
																	{
																		goto IL_0879_2;
																	}
																	goto IL_09c8_2;
																	IL_0879_2:
																	if (19 > b)
																	{
																		goto IL_0887_2;
																	}
																	goto IL_0980_2;
																	IL_0887_2:
																	if (17 < b)
																	{
																		goto IL_0892_2;
																	}
																	goto IL_090d_2;
																	IL_0892_2:
																	if (18 < b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_08a0_2;
																	IL_08a0_2:
																	if (18 > b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_08ae_2;
																	IL_08ae_2:
																	array2[num6 - 1] = 5;
																	goto IL_08c2_2;
																	IL_08c2_2:
																	array3[num6 - 1] = ((delegate*<string[], string>)GetGenericTypeDefinitionNextChannelSink[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																	goto IL_08fa_2;
																	IL_08fa_2:
																	ptr2 += 8;
																	break;
																	IL_090d_2:
																	if (17 > b)
																	{
																		num = 188;
																		goto end_IL_046d_2;
																	}
																	goto IL_0926_2;
																	IL_0cb9_2:
																	num6++;
																	goto IL_0cc7_2;
																	IL_0926_2:
																	((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																	num = 25;
																	goto IL_096d_2;
																	IL_096d_2:
																	num6 -= 3;
																	break;
																	IL_0980_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																	goto IL_0999_2;
																	IL_0999_2:
																	array2[num6] = 1;
																	goto IL_09a7_2;
																	IL_09a7_2:
																	num6++;
																	goto IL_09b5_2;
																	IL_09b5_2:
																	ptr2 += 16;
																	break;
																	IL_09c8_2:
																	if (20 >= b)
																	{
																		goto IL_09d3_2;
																	}
																	goto IL_09f9_2;
																	IL_09d3_2:
																	if (20 > b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_09e1_2;
																	IL_09e1_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	IL_09f9_2:
																	if (21 < b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_0a07_2;
																	IL_0a07_2:
																	if (21 > b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_0a15_2;
																	IL_0a15_2:
																	num7 = ptr2;
																	num8 = -200;
																	num5 = 1;
																	ptr2 = num7 + num8;
																	break;
																	IL_0a31_2:
																	if (16 > b)
																	{
																		goto IL_0a3f_2;
																	}
																	goto IL_0c93_2;
																	IL_0a3f_2:
																	if (13 >= b)
																	{
																		goto IL_0a4d_2;
																	}
																	goto IL_0b8e_2;
																	IL_0a4d_2:
																	if (13 > b)
																	{
																		goto IL_0a5b_2;
																	}
																	goto IL_0b4f_2;
																	IL_0a5b_2:
																	if (12 < b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_0a69_2;
																	IL_0a69_2:
																	if (12 > b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_0a77_2;
																	IL_0a77_2:
																	array8 = array3;
																	num9 = num6;
																	if (array == null)
																	{
																		goto IL_0a86_2;
																	}
																	goto IL_0a94;
																	IL_0b4f_2:
																	array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																	goto IL_0b6d_2;
																	IL_0b6d_2:
																	ptr2 += 8;
																	goto IL_0b7b_2;
																	IL_0b7b_2:
																	num6--;
																	break;
																	IL_0b8e_2:
																	if (14 >= b)
																	{
																		goto IL_0b99_2;
																	}
																	num = 102;
																	goto IL_0bf2_2;
																	IL_0b99_2:
																	if (14 > b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_0ba7_2;
																	IL_0ba7_2:
																	array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																	goto IL_0bd0_2;
																	IL_0bd0_2:
																	array2[num6 - 1] = 5;
																	break;
																	IL_0cc7_2:
																	ptr2 += 8;
																	break;
																	IL_0bf2_2:
																	if (15 < b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_0c00_2;
																	IL_0c00_2:
																	if (15 > b)
																	{
																		goto end_IL_046d_2;
																	}
																	goto IL_0c0e_2;
																	IL_0c0e_2:
																	array2[num6] = array2[num6 - 1];
																	goto IL_0c26_2;
																	IL_0c26_2:
																	array4[num6 - 0] = array4[num6 - 1];
																	goto IL_0c44_2;
																	IL_0c44_2:
																	*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																	goto IL_0c68_2;
																	IL_0c68_2:
																	array3[num6] = array3[num6 - 1];
																	goto IL_0c80_2;
																	IL_0c80_2:
																	num6++;
																	break;
																	IL_0c93_2:
																	array2[num6] = 5;
																	goto IL_0ca1_2;
																}
																goto end_IL_047d_2;
																continue;
																end_IL_046d_2:
																break;
																IL_046d_2:;
															}
														}
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_0cf0_2;
														IL_0d0c_2:
														ptr2 += 8;
														break;
														IL_0cfe_2:
														num6++;
														goto IL_0d0c_2;
														IL_0cf0_2:
														array2[num6] = 0;
														goto IL_0cfe_2;
														continue;
														end_IL_047d_2:
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										continue;
									}
									goto IL_0ddd_2;
									IL_0ddd_2:
									return (string)array3[num6 - 1];
									continue;
									end_IL_0d1a_2:
									break;
								}
								break;
							}
							continue;
							end_IL_0b2e:
							break;
						}
						break;
					}
					break;
				}
			}
		}
	}

	public Class105()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private static int smethod_13(int int_5)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_5;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_14()
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref OnDeserializationChannelURI.TypeContainingContractsgetAsBool);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_02ed:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			if (8 < b)
																			{
																				while (true)
																				{
																					IL_02c0:
																					if (12 >= b)
																					{
																						while (true)
																						{
																							IL_02b0:
																							if (12 > b)
																							{
																								while (true)
																								{
																									IL_02a0:
																									if (10 < b)
																									{
																										num = 156;
																										while (true)
																										{
																											if (num != 156)
																											{
																												if (num != 1137)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 85:
																													goto IL_02a0;
																												case 30:
																													goto IL_02b0;
																												case 67:
																												case 148:
																													goto IL_02c0;
																												case 80:
																													goto end_IL_02c0;
																												case 58:
																													goto end_IL_02cd;
																												case 82:
																													goto IL_02ed;
																												case 9:
																													goto end_IL_02ed;
																												case 34:
																												case 48:
																													goto end_IL_02fd;
																												case 17:
																													goto IL_0318;
																												case 25:
																												case 39:
																													goto IL_032b;
																												case 14:
																												case 18:
																													goto end_IL_028d;
																												case 43:
																												case 72:
																													goto IL_0349;
																												case 66:
																													goto IL_0389;
																												case 1:
																													goto IL_039d;
																												case 101:
																													goto IL_03b0;
																												case 123:
																													goto IL_03c3;
																												case 22:
																												case 94:
																													goto IL_03d1;
																												case 87:
																													goto IL_03df;
																												case 11:
																												case 97:
																													goto IL_03ed;
																												case 114:
																													goto IL_044f;
																												case 63:
																												case 64:
																													goto IL_0462;
																												case 135:
																													goto IL_047e;
																												case 84:
																													goto IL_048c;
																												case 44:
																												case 144:
																													goto IL_04a8;
																												case 56:
																													goto IL_04b6;
																												case 54:
																													goto IL_04d9;
																												case 8:
																													goto IL_04e3;
																												case 36:
																													goto IL_04f1;
																												case 49:
																													goto IL_0504;
																												case 100:
																													goto IL_0512;
																												case 21:
																												case 62:
																													goto IL_0520;
																												case 61:
																													goto IL_0564;
																												case 6:
																													goto IL_0578;
																												case 112:
																													goto IL_058b;
																												case 71:
																												case 147:
																													goto IL_0599;
																												case 90:
																													goto IL_05a7;
																												case 41:
																												case 45:
																													goto IL_05b2;
																												case 124:
																													goto IL_05c0;
																												case 24:
																												case 136:
																													goto IL_05ce;
																												case 60:
																													goto IL_05f7;
																												case 146:
																													goto IL_0605;
																												case 29:
																													goto IL_0618;
																												case 19:
																												case 108:
																													goto IL_0623;
																												case 76:
																													goto IL_0631;
																												case 40:
																												case 120:
																													goto IL_063f;
																												case 95:
																													goto IL_064d;
																												case 104:
																													goto IL_0665;
																												case 129:
																													goto IL_0673;
																												case 128:
																												case 149:
																													goto IL_0686;
																												case 37:
																													goto IL_06c5;
																												case 88:
																													goto IL_06d8;
																												case 98:
																												case 113:
																													goto IL_06e6;
																												case 47:
																													goto IL_06f4;
																												case 81:
																													goto IL_06ff;
																												case 53:
																													goto IL_070d;
																												case 116:
																												case 133:
																													goto IL_071b;
																												case 74:
																													goto IL_073d;
																												case 99:
																													goto IL_0754;
																												case 117:
																													goto IL_0762;
																												case 132:
																												case 141:
																													goto IL_0775;
																												case 115:
																													goto IL_07b5;
																												case 50:
																													goto IL_07c9;
																												case 42:
																													goto IL_07dc;
																												case 46:
																													goto IL_07ea;
																												case 35:
																												case 139:
																													goto IL_07f8;
																												case 38:
																													goto IL_0821;
																												case 111:
																												case 127:
																													goto IL_0837;
																												case 10:
																													goto IL_0855;
																												case 12:
																													goto IL_086c;
																												case 0:
																												case 20:
																													goto IL_087c;
																												case 3:
																												case 5:
																												case 7:
																												case 15:
																												case 16:
																												case 26:
																												case 27:
																												case 28:
																												case 51:
																												case 55:
																												case 57:
																												case 65:
																												case 69:
																												case 77:
																												case 86:
																												case 89:
																												case 93:
																												case 102:
																												case 103:
																												case 105:
																												case 106:
																												case 118:
																												case 119:
																												case 130:
																												case 134:
																												case 138:
																												case 142:
																													goto end_IL_02dd;
																												case 2:
																												case 31:
																												case 52:
																												case 59:
																												case 68:
																												case 75:
																												case 78:
																												case 79:
																												case 92:
																												case 107:
																												case 109:
																												case 110:
																												case 121:
																												case 122:
																												case 125:
																												case 137:
																												case 140:
																												case 143:
																													goto end_IL_030d;
																												case 131:
																													goto end_IL_08a4;
																												case 23:
																													goto end_IL_08b7;
																												case 91:
																													goto end_IL_08c1;
																												case 145:
																													goto end_IL_08cc;
																												case 4:
																												case 96:
																													goto end_IL_08dc;
																												case 126:
																													goto end_IL_08ec;
																												case 70:
																												case 73:
																													goto end_IL_08fc;
																												case 32:
																													goto end_IL_090c;
																												case 33:
																													goto end_IL_091c;
																												case 13:
																												case 83:
																													goto IL_0937;
																												}
																												continue;
																											}
																											goto IL_0504;
																											IL_0564:
																											array[num5 - 2] = 0;
																											goto IL_0578;
																											IL_0578:
																											num5--;
																											goto end_IL_030d;
																											IL_0504:
																											if (11 < b)
																											{
																												goto end_IL_02dd;
																											}
																											goto IL_0512;
																											IL_0512:
																											if (11 > b)
																											{
																												goto end_IL_02dd;
																											}
																											goto IL_0520;
																											IL_0520:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																											goto IL_0564;
																											continue;
																											end_IL_028d:
																											break;
																										}
																										break;
																									}
																									goto IL_0318;
																									IL_047e:
																									if (9 < b)
																									{
																										goto end_IL_02dd;
																									}
																									goto IL_048c;
																									IL_048c:
																									if (9 <= b)
																									{
																										goto end_IL_030d;
																									}
																									num = 119;
																									goto end_IL_02dd;
																									IL_0318:
																									if (10 > b)
																									{
																										goto IL_047e;
																									}
																									goto IL_04a8;
																									IL_04a8:
																									array[num5] = 0;
																									goto IL_04b6;
																									IL_04b6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_04d9;
																									IL_04d9:
																									array2[num5] = null;
																									goto IL_04e3;
																									IL_04e3:
																									num5++;
																									goto IL_04f1;
																									IL_04f1:
																									ptr2 += 8;
																									goto end_IL_030d;
																								}
																								break;
																							}
																							goto IL_0349;
																							IL_039d:
																							num5--;
																							goto end_IL_030d;
																							IL_0349:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0389;
																							IL_0389:
																							array[num5 - 2] = 0;
																							goto IL_039d;
																						}
																						goto IL_0339;
																					}
																					goto IL_032b;
																					IL_0462:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_030d;
																					IL_032b:
																					if (14 < b)
																					{
																						goto IL_0339;
																					}
																					goto IL_03c3;
																					IL_0339:
																					if (15 < b)
																					{
																						goto end_IL_02dd;
																					}
																					goto IL_03b0;
																					IL_03b0:
																					if (15 <= b)
																					{
																					}
																					goto end_IL_02dd;
																					IL_03c3:
																					if (14 > b)
																					{
																						goto IL_03d1;
																					}
																					goto IL_0462;
																					IL_03d1:
																					if (13 < b)
																					{
																						goto end_IL_02dd;
																					}
																					goto IL_03df;
																					IL_03df:
																					if (13 > b)
																					{
																						goto end_IL_02dd;
																					}
																					goto IL_03ed;
																					IL_03ed:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_044f;
																					IL_044f:
																					num5 -= 2;
																					goto end_IL_030d;
																					continue;
																					end_IL_02c0:
																					break;
																				}
																				continue;
																			}
																			goto IL_058b;
																			IL_087c:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_030d;
																			IL_058b:
																			if (8 > b)
																			{
																				goto IL_0599;
																			}
																			goto IL_087c;
																			IL_0599:
																			if (4 < b)
																			{
																				goto IL_05a7;
																			}
																			goto IL_06d8;
																			IL_05a7:
																			if (6 < b)
																			{
																				goto IL_05b2;
																			}
																			goto IL_0618;
																			IL_05b2:
																			if (7 < b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_05c0;
																			IL_05c0:
																			if (7 > b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_05ce;
																			IL_05ce:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05f7;
																			IL_05f7:
																			ptr2 += 8;
																			goto IL_0605;
																			IL_0605:
																			num5--;
																			goto end_IL_030d;
																			IL_0618:
																			if (6 > b)
																			{
																				goto IL_0623;
																			}
																			goto IL_0686;
																			IL_0623:
																			if (5 < b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_0631;
																			IL_0631:
																			if (5 > b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_063f;
																			IL_063f:
																			array[num5] = 5;
																			goto IL_064d;
																			IL_064d:
																			array2[num5] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0665;
																			IL_0665:
																			num5++;
																			goto IL_0673;
																			IL_0673:
																			ptr2 += 8;
																			goto end_IL_030d;
																			IL_0686:
																			((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06c5;
																			IL_06c5:
																			num5 -= 3;
																			goto end_IL_030d;
																			IL_06d8:
																			if (4 > b)
																			{
																				goto IL_06e6;
																			}
																			goto IL_0837;
																			IL_06e6:
																			if (2 >= b)
																			{
																				goto IL_06f4;
																			}
																			goto IL_07dc;
																			IL_06f4:
																			if (2 > b)
																			{
																				goto IL_06ff;
																			}
																			goto IL_0775;
																			IL_06ff:
																			if (1 < b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_070d;
																			IL_070d:
																			if (1 > b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_071b;
																			IL_071b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			num = 74;
																			goto IL_073d;
																			IL_073d:
																			array[num5] = 0;
																			num = 99;
																			goto IL_0754;
																			IL_0754:
																			num5++;
																			goto IL_0762;
																			IL_0762:
																			ptr2 += 8;
																			goto end_IL_030d;
																			IL_0775:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07b5;
																			IL_07b5:
																			array[num5 - 2] = 0;
																			goto IL_07c9;
																			IL_07c9:
																			num5--;
																			goto end_IL_030d;
																			IL_07dc:
																			if (3 < b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_07ea;
																			IL_07ea:
																			if (3 > b)
																			{
																				goto end_IL_02dd;
																			}
																			goto IL_07f8;
																			IL_07f8:
																			array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0821;
																			IL_0821:
																			array[num5 - 1] = 5;
																			goto end_IL_030d;
																			IL_0837:
																			array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																			goto IL_0855;
																			IL_0855:
																			ptr2 += 8;
																			num = 12;
																			goto IL_086c;
																			IL_086c:
																			num5--;
																			goto end_IL_030d;
																			continue;
																			end_IL_02cd:
																			break;
																		}
																		continue;
																		end_IL_02dd:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_030d;
																continue;
																end_IL_02ed:
																break;
															}
															continue;
															end_IL_02fd:
															break;
														}
														continue;
														end_IL_030d:
														break;
													}
													continue;
												}
												goto IL_0937;
												IL_0937:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a4:
												break;
											}
											continue;
											end_IL_08b7:
											break;
										}
										continue;
										end_IL_08c1:
										break;
									}
									continue;
									end_IL_08cc:
									break;
								}
								continue;
								end_IL_08dc:
								break;
							}
							continue;
							end_IL_08ec:
							break;
						}
						continue;
						end_IL_08fc:
						break;
					}
					continue;
					end_IL_090c:
					break;
				}
				continue;
				end_IL_091c:
				break;
			}
		}
	}

	private unsafe static int smethod_15(int int_5)
	{
		int num = 45;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EmptyReadOnlyDictionaryInternalSorterGenericArray.CastThreadPoolWorkQueueThreadLocals);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_025e:
														byte b = *ptr2;
														while (true)
														{
															IL_024e:
															ptr2++;
															while (true)
															{
																IL_023e:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_021e:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0211:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_0204:
																							if (9 >= b)
																							{
																								while (9 <= b)
																								{
																									while (true)
																									{
																										IL_01d2:
																										byte* num5 = ptr2;
																										num4 = 1;
																										ptr2 = num5 + -200;
																										num = 108;
																										while (num != 108)
																										{
																											if (num != 1089)
																											{
																												goto IL_0498;
																											}
																											switch (num)
																											{
																											case 4:
																											case 94:
																												goto IL_01d2;
																											case 29:
																												goto IL_01f4;
																											case 47:
																											case 81:
																												goto IL_0204;
																											case 71:
																											case 74:
																												goto IL_0211;
																											case 6:
																												goto IL_021e;
																											case 12:
																												goto IL_022e;
																											case 54:
																												goto IL_023e;
																											case 28:
																												goto IL_024e;
																											case 14:
																											case 70:
																												goto IL_025e;
																											case 31:
																											case 89:
																												goto IL_0269;
																											case 17:
																												goto IL_0277;
																											case 76:
																												goto IL_028a;
																											case 32:
																												goto IL_0298;
																											case 33:
																												goto IL_02a3;
																											case 69:
																											case 77:
																												goto IL_02b1;
																											case 50:
																												goto IL_02f1;
																											case 13:
																												goto IL_0305;
																											case 87:
																												goto IL_0318;
																											case 53:
																												goto IL_0326;
																											case 8:
																											case 46:
																												goto IL_0334;
																											case 9:
																												goto IL_0357;
																											case 20:
																												goto IL_0365;
																											case 58:
																												goto IL_0373;
																											case 60:
																											case 97:
																												goto IL_0386;
																											case 63:
																												goto IL_03e8;
																											case 30:
																												goto IL_03fb;
																											case 0:
																											case 27:
																												goto IL_0409;
																											case 51:
																												goto IL_0420;
																											case 61:
																											case 88:
																												goto IL_0434;
																											case 40:
																												goto IL_0442;
																											case 86:
																											case 100:
																												goto IL_0450;
																											case 37:
																												goto IL_0469;
																											case 18:
																												goto IL_0477;
																											case 48:
																												goto IL_0485;
																											case 1:
																											case 5:
																												goto IL_0498;
																											case 57:
																												goto IL_04c1;
																											case 26:
																												goto IL_04cf;
																											case 52:
																												goto IL_04eb;
																											case 19:
																												goto IL_04f6;
																											case 11:
																												goto IL_0504;
																											case 25:
																												goto IL_0520;
																											case 36:
																											case 95:
																												goto IL_052b;
																											case 43:
																											case 73:
																												goto IL_0540;
																											case 35:
																												goto IL_054e;
																											case 23:
																												goto IL_0571;
																											case 7:
																												goto IL_057b;
																											case 92:
																												goto IL_0589;
																											case 3:
																											case 15:
																											case 21:
																											case 22:
																											case 49:
																											case 55:
																											case 56:
																											case 59:
																											case 68:
																											case 79:
																											case 80:
																											case 82:
																											case 84:
																											case 91:
																											case 98:
																											case 99:
																												goto end_IL_01f4;
																											case 2:
																											case 10:
																											case 16:
																											case 39:
																											case 42:
																											case 62:
																											case 65:
																											case 67:
																											case 72:
																											case 83:
																											case 90:
																											case 96:
																												goto end_IL_01bf;
																											case 64:
																												goto end_IL_05ac;
																											case 41:
																												goto end_IL_05bf;
																											case 78:
																												goto end_IL_05c9;
																											case 38:
																												goto end_IL_05d4;
																											case 66:
																											case 75:
																												goto end_IL_05e9;
																											case 85:
																												goto end_IL_05f9;
																											case 24:
																											case 34:
																												goto end_IL_0609;
																											case 44:
																												goto end_IL_0619;
																											case 45:
																												goto end_IL_0629;
																											case 93:
																											case 101:
																												goto IL_0644;
																											}
																											continue;
																											end_IL_01bf:
																											break;
																										}
																										break;
																									}
																									goto end_IL_023e;
																									continue;
																									end_IL_01f4:
																									break;
																									IL_01f4:;
																								}
																								break;
																							}
																							goto IL_0269;
																							IL_0277:
																							if (10 > b)
																							{
																							}
																							break;
																							IL_0269:
																							if (10 < b)
																							{
																								break;
																							}
																							goto IL_0277;
																						}
																						break;
																					}
																					goto IL_028a;
																					IL_03e8:
																					num6 -= 2;
																					goto end_IL_023e;
																					IL_028a:
																					if (8 > b)
																					{
																						goto IL_0298;
																					}
																					goto IL_0386;
																					IL_0298:
																					if (6 >= b)
																					{
																						goto IL_02a3;
																					}
																					goto IL_0318;
																					IL_02a3:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_02b1;
																					IL_02b1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_02f1;
																					IL_02f1:
																					array[num6 - 2] = 0;
																					goto IL_0305;
																					IL_0305:
																					num6--;
																					goto end_IL_023e;
																					IL_0318:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_0326;
																					IL_0326:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_0334;
																					IL_0334:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0357;
																					IL_0357:
																					array[num6] = 0;
																					goto IL_0365;
																					IL_0365:
																					num6++;
																					goto IL_0373;
																					IL_0373:
																					ptr2 += 8;
																					goto end_IL_023e;
																					IL_0386:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_03e8;
																				}
																				break;
																			}
																			goto IL_03fb;
																			IL_054e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0571;
																			IL_03fb:
																			if (5 > b)
																			{
																				goto IL_0409;
																			}
																			goto IL_0540;
																			IL_0409:
																			if (2 >= b)
																			{
																				num = 51;
																				goto IL_0420;
																			}
																			goto IL_04eb;
																			IL_0571:
																			array2[num6] = null;
																			goto IL_057b;
																			IL_0420:
																			if (2 > b)
																			{
																				num = 88;
																				goto IL_0434;
																			}
																			goto IL_0498;
																			IL_057b:
																			num6++;
																			goto IL_0589;
																			IL_0434:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0442;
																			IL_0442:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0450;
																			IL_0450:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0469;
																			IL_0469:
																			array[num6] = 0;
																			goto IL_0477;
																			IL_0477:
																			num6++;
																			goto IL_0485;
																			IL_0485:
																			ptr2 += 8;
																			goto end_IL_023e;
																			IL_0498:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_04c1;
																			IL_04c1:
																			ptr2 += 8;
																			goto IL_04cf;
																			IL_04cf:
																			num6--;
																			num = 90;
																			goto end_IL_023e;
																			IL_04eb:
																			if (3 < b)
																			{
																				goto IL_04f6;
																			}
																			num = 25;
																			goto IL_0520;
																			IL_04f6:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0504;
																			IL_0504:
																			if (4 <= b)
																			{
																				goto end_IL_023e;
																			}
																			break;
																			IL_0589:
																			ptr2 += 8;
																			goto end_IL_023e;
																			IL_0520:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_052b;
																			IL_052b:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_023e;
																			IL_0540:
																			array[num6] = 0;
																			goto IL_054e;
																		}
																		break;
																		IL_022e:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_023e:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0644;
												IL_0644:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05ac:
												break;
											}
											continue;
											end_IL_05bf:
											break;
										}
										continue;
										end_IL_05c9:
										break;
									}
									continue;
									end_IL_05d4:
									break;
								}
								continue;
								end_IL_05e9:
								break;
							}
							continue;
							end_IL_05f9:
							break;
						}
						continue;
						end_IL_0609:
						break;
					}
					continue;
					end_IL_0619:
					break;
				}
				continue;
				end_IL_0629:
				break;
			}
		}
	}

	private unsafe static int smethod_16(int int_5, int int_6)
	{
		int num = 17;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 14;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_5;
									while (true)
									{
										array3[1] = int_6;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UtcDateTimeParallelForReplicaTask.PtrToStringUniIsGenericMethodDefinition);
											while (true)
											{
												IL_0500:
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_020c:
															byte b = *ptr2;
															while (true)
															{
																IL_01fc:
																ptr2++;
																while (true)
																{
																	IL_01ec:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01cf:
																				if (4 < b)
																				{
																					while (true)
																					{
																						IL_01bf:
																						if (6 >= b)
																						{
																							while (6 > b)
																							{
																								num = 95;
																								while (true)
																								{
																									if (num != 95)
																									{
																										if (num != 1076)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 2:
																											goto IL_01ac;
																										case 13:
																											goto IL_01bf;
																										case 39:
																											goto IL_01cf;
																										case 35:
																											goto IL_01dc;
																										case 1:
																											goto IL_01ec;
																										case 36:
																											goto IL_01fc;
																										case 51:
																										case 75:
																											goto IL_020c;
																										case 19:
																											goto IL_0217;
																										case 27:
																										case 41:
																											goto IL_0222;
																										case 31:
																											goto IL_022d;
																										case 8:
																										case 23:
																											goto IL_023b;
																										case 9:
																											goto IL_024b;
																										case 24:
																											goto IL_0259;
																										case 50:
																											goto IL_0269;
																										case 38:
																										case 54:
																											goto IL_027c;
																										case 21:
																											goto IL_02a5;
																										case 10:
																											goto IL_02b3;
																										case 48:
																										case 62:
																											goto IL_02c6;
																										case 72:
																										case 82:
																											goto IL_030b;
																										case 60:
																											goto IL_0379;
																										case 84:
																											goto IL_038c;
																										case 80:
																											goto IL_03a0;
																										case 53:
																											goto IL_03bc;
																										case 67:
																											goto IL_03ca;
																										case 40:
																										case 49:
																											goto IL_03d8;
																										case 77:
																											goto IL_03f0;
																										case 0:
																										case 71:
																											goto IL_03fb;
																										case 42:
																											goto IL_0409;
																										case 12:
																										case 73:
																											goto IL_0417;
																										case 28:
																											goto IL_0433;
																										case 18:
																										case 64:
																											goto IL_043e;
																										case 76:
																											goto IL_044c;
																										case 6:
																											goto IL_046f;
																										case 66:
																											goto IL_0482;
																										case 4:
																											goto IL_0490;
																										case 15:
																										case 29:
																										case 32:
																										case 37:
																										case 43:
																										case 45:
																										case 46:
																										case 47:
																										case 52:
																										case 55:
																										case 58:
																										case 61:
																										case 63:
																										case 70:
																										case 74:
																										case 86:
																											goto end_IL_01dc;
																										case 44:
																											goto IL_04c3;
																										case 56:
																											goto IL_04d1;
																										case 88:
																											goto IL_04df;
																										case 5:
																										case 7:
																										case 25:
																										case 26:
																										case 30:
																										case 33:
																										case 34:
																										case 59:
																										case 78:
																										case 83:
																										case 87:
																											goto end_IL_01ac;
																										case 85:
																											goto IL_0500;
																										case 57:
																											goto end_IL_0199;
																										case 65:
																											goto end_IL_050a;
																										case 11:
																											goto end_IL_0515;
																										case 81:
																											goto end_IL_052a;
																										case 3:
																										case 20:
																											goto end_IL_053f;
																										case 14:
																											goto end_IL_054f;
																										case 68:
																										case 69:
																											goto end_IL_055f;
																										case 16:
																											goto end_IL_056f;
																										case 17:
																											goto end_IL_0588;
																										case 22:
																										case 79:
																											goto IL_05a3;
																										}
																										continue;
																									}
																									goto IL_03bc;
																									IL_03ca:
																									if (5 > b)
																									{
																										goto end_IL_01dc;
																									}
																									goto IL_03d8;
																									IL_03d8:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_01ac;
																									IL_03bc:
																									if (5 < b)
																									{
																										goto end_IL_01dc;
																									}
																									goto IL_03ca;
																									continue;
																									end_IL_0199:
																									break;
																								}
																								goto end_IL_04ed;
																								continue;
																								end_IL_01ac:
																								break;
																								IL_01ac:;
																							}
																							break;
																						}
																						goto IL_03f0;
																						IL_0490:
																						ptr2 += 8;
																						break;
																						IL_03f0:
																						if (7 < b)
																						{
																							goto IL_03fb;
																						}
																						goto IL_0433;
																						IL_03fb:
																						if (8 < b)
																						{
																							goto end_IL_01dc;
																						}
																						goto IL_0409;
																						IL_0409:
																						if (8 > b)
																						{
																							goto end_IL_01dc;
																						}
																						goto IL_0417;
																						IL_0417:
																						byte* num5 = ptr2;
																						num4 = 1;
																						ptr2 = num5 + -200;
																						break;
																						IL_0433:
																						if (7 > b)
																						{
																							goto end_IL_01dc;
																						}
																						goto IL_043e;
																						IL_043e:
																						array[num6] = 0;
																						goto IL_044c;
																						IL_044c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_046f;
																						IL_046f:
																						array2[num6] = null;
																						num = 66;
																						goto IL_0482;
																						IL_0482:
																						num6++;
																						goto IL_0490;
																					}
																					break;
																				}
																				goto IL_0217;
																				IL_02b3:
																				num6--;
																				break;
																				IL_0217:
																				if (4 > b)
																				{
																					goto IL_0222;
																				}
																				goto IL_027c;
																				IL_0222:
																				if (2 >= b)
																				{
																					goto IL_022d;
																				}
																				goto IL_024b;
																				IL_022d:
																				if (2 > b)
																				{
																					goto IL_023b;
																				}
																				goto IL_030b;
																				IL_023b:
																				if (1 < b)
																				{
																					goto end_IL_01dc;
																				}
																				goto IL_0269;
																				IL_0269:
																				if (1 <= b)
																				{
																				}
																				goto end_IL_01dc;
																				IL_030b:
																				ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0379;
																				IL_0379:
																				num6 -= 2;
																				break;
																				IL_024b:
																				if (3 < b)
																				{
																					goto end_IL_01dc;
																				}
																				goto IL_0259;
																				IL_0259:
																				if (3 > b)
																				{
																					goto end_IL_01dc;
																				}
																				goto IL_02c6;
																				IL_02c6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_038c;
																				IL_038c:
																				array[num6 - 2] = 0;
																				goto IL_03a0;
																				IL_03a0:
																				num6--;
																				num = 26;
																				break;
																				IL_027c:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_02a5;
																				IL_02a5:
																				ptr2 += 8;
																				goto IL_02b3;
																			}
																			goto end_IL_01ec;
																			continue;
																			end_IL_01dc:
																			break;
																			IL_01dc:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c3;
																	IL_04df:
																	ptr2 += 8;
																	break;
																	IL_04d1:
																	num6++;
																	goto IL_04df;
																	IL_04c3:
																	array[num6] = 0;
																	goto IL_04d1;
																	continue;
																	end_IL_01ec:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_05a3;
													IL_05a3:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_04ed:
													break;
												}
												break;
											}
											continue;
											end_IL_050a:
											break;
										}
										continue;
										end_IL_0515:
										break;
									}
									continue;
									end_IL_052a:
									break;
								}
								continue;
								end_IL_053f:
								break;
							}
							continue;
							end_IL_054f:
							break;
						}
						continue;
						end_IL_055f:
						break;
					}
					continue;
					end_IL_056f:
					break;
				}
				continue;
				end_IL_0588:
				break;
			}
		}
	}

	private unsafe static int smethod_17()
	{
		int num = 34;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					num = 50;
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref StlocSafeLocalAllocHandle.RestrictedErrorObjectgetParentWindowHandle);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_034a:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_032d:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_031d:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_030d:
																							if (4 < b)
																							{
																								while (true)
																								{
																									IL_02fd:
																									if (6 >= b)
																									{
																										while (true)
																										{
																											IL_02ed:
																											if (6 > b)
																											{
																												while (true)
																												{
																													IL_02dd:
																													if (5 >= b)
																													{
																														while (5 <= b)
																														{
																															while (true)
																															{
																																IL_02bd:
																																array[num5] = 5;
																																while (true)
																																{
																																	IL_029a:
																																	array2[num5] = array5[*(int*)(ptr2 + num3)];
																																	num = 158;
																																	while (true)
																																	{
																																		if (num != 158)
																																		{
																																			if (num != 1139)
																																			{
																																				break;
																																			}
																																			switch (num)
																																			{
																																			case 122:
																																				goto IL_029a;
																																			case 118:
																																			case 146:
																																				goto IL_02bd;
																																			case 59:
																																				goto IL_02cd;
																																			case 17:
																																			case 123:
																																				goto IL_02dd;
																																			case 11:
																																				goto IL_02ed;
																																			case 126:
																																			case 137:
																																				goto IL_02fd;
																																			case 91:
																																			case 95:
																																				goto IL_030d;
																																			case 51:
																																				goto IL_031d;
																																			case 136:
																																				goto IL_032d;
																																			case 47:
																																				goto IL_033a;
																																			case 92:
																																				goto IL_034a;
																																			case 57:
																																				goto end_IL_034a;
																																			case 60:
																																			case 90:
																																				goto end_IL_035a;
																																			case 42:
																																			case 46:
																																				goto IL_0375;
																																			case 103:
																																				goto IL_0383;
																																			case 18:
																																			case 97:
																																				goto IL_0391;
																																			case 67:
																																				goto IL_039c;
																																			case 49:
																																				goto IL_03a7;
																																			case 73:
																																			case 84:
																																				goto IL_03c0;
																																			case 106:
																																				goto IL_03d3;
																																			case 77:
																																			case 113:
																																				goto IL_03e6;
																																			case 2:
																																				goto IL_03f4;
																																			case 83:
																																			case 117:
																																				goto IL_0402;
																																			case 48:
																																				goto IL_0446;
																																			case 14:
																																			case 125:
																																				goto IL_045f;
																																			case 22:
																																			case 128:
																																				goto IL_04a4;
																																			case 13:
																																			case 76:
																																				goto IL_04b8;
																																			case 24:
																																				goto IL_04c3;
																																			case 138:
																																				goto IL_04e4;
																																			case 68:
																																			case 100:
																																				goto IL_04ef;
																																			case 82:
																																				goto IL_050b;
																																			case 5:
																																				goto IL_0519;
																																			case 0:
																																			case 28:
																																				goto IL_0527;
																																			case 53:
																																				goto IL_0589;
																																			case 142:
																																				goto IL_059c;
																																			case 61:
																																				goto IL_05b0;
																																			case 145:
																																				goto IL_05c3;
																																			case 147:
																																				goto IL_05d6;
																																			case 10:
																																				goto IL_05f9;
																																			case 4:
																																				goto IL_0603;
																																			case 54:
																																				goto IL_0611;
																																			case 129:
																																				goto IL_0632;
																																			case 8:
																																			case 85:
																																				goto IL_0653;
																																			case 72:
																																				goto IL_0692;
																																			case 19:
																																			case 96:
																																				goto IL_06a5;
																																			case 21:
																																				goto IL_06b3;
																																			case 37:
																																			case 119:
																																				goto IL_06c1;
																																			case 120:
																																				goto IL_06ea;
																																			case 132:
																																				goto IL_06f8;
																																			case 80:
																																				goto IL_070b;
																																			case 98:
																																			case 124:
																																				goto IL_0716;
																																			case 56:
																																				goto IL_0734;
																																			case 150:
																																				goto end_IL_0287;
																																			case 69:
																																			case 109:
																																				goto IL_075e;
																																			case 66:
																																			case 75:
																																				goto IL_0769;
																																			case 9:
																																				goto IL_0777;
																																			case 26:
																																			case 27:
																																				goto IL_0785;
																																			case 44:
																																				goto IL_07ae;
																																			case 71:
																																				goto IL_07c7;
																																			case 40:
																																			case 108:
																																				goto IL_07d2;
																																			case 144:
																																				goto IL_07e0;
																																			case 89:
																																			case 94:
																																				goto IL_07ee;
																																			case 39:
																																				goto IL_0807;
																																			case 64:
																																				goto IL_0815;
																																			case 41:
																																				goto IL_082c;
																																			case 3:
																																			case 31:
																																				goto IL_083f;
																																			case 130:
																																				goto IL_087f;
																																			case 38:
																																				goto IL_0893;
																																			case 107:
																																			case 112:
																																				goto IL_08a3;
																																			case 12:
																																			case 15:
																																			case 16:
																																			case 20:
																																			case 29:
																																			case 32:
																																			case 35:
																																			case 45:
																																			case 52:
																																			case 55:
																																			case 62:
																																			case 63:
																																			case 74:
																																			case 79:
																																			case 81:
																																			case 87:
																																			case 104:
																																			case 105:
																																			case 110:
																																			case 115:
																																			case 116:
																																			case 127:
																																			case 131:
																																			case 134:
																																			case 148:
																																			case 149:
																																				goto end_IL_02cd;
																																			case 1:
																																			case 6:
																																			case 7:
																																			case 23:
																																			case 25:
																																			case 36:
																																			case 58:
																																			case 65:
																																			case 70:
																																			case 88:
																																			case 93:
																																			case 99:
																																			case 102:
																																			case 114:
																																			case 121:
																																			case 133:
																																			case 135:
																																			case 140:
																																				goto end_IL_036a;
																																			case 101:
																																				goto end_IL_08cb;
																																			case 30:
																																				goto end_IL_08de;
																																			case 139:
																																				goto end_IL_08e8;
																																			case 43:
																																				goto end_IL_08f3;
																																			case 86:
																																			case 143:
																																				goto end_IL_0903;
																																			case 50:
																																				goto end_IL_0913;
																																			case 111:
																																			case 141:
																																				goto end_IL_0923;
																																			case 33:
																																				goto end_IL_0933;
																																			case 34:
																																				goto end_IL_094c;
																																			case 78:
																																			case 151:
																																				goto IL_0967;
																																			}
																																			continue;
																																		}
																																		num5++;
																																		goto IL_0632;
																																		IL_0632:
																																		ptr2 += 8;
																																		goto end_IL_036a;
																																		continue;
																																		end_IL_0287:
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto IL_0742;
																															continue;
																															end_IL_02cd:
																															break;
																															IL_02cd:;
																														}
																													}
																													else
																													{
																														num = 116;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0653;
																											IL_0692:
																											num5 -= 3;
																											goto end_IL_036a;
																											IL_0653:
																											((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_0692;
																										}
																										break;
																									}
																									goto IL_06a5;
																									IL_06f8:
																									num5--;
																									goto end_IL_036a;
																									IL_06a5:
																									if (7 < b)
																									{
																										break;
																									}
																									goto IL_06b3;
																									IL_06b3:
																									if (7 > b)
																									{
																										break;
																									}
																									goto IL_06c1;
																									IL_06c1:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_06ea;
																									IL_06ea:
																									ptr2 += 8;
																									goto IL_06f8;
																								}
																								break;
																							}
																							goto IL_070b;
																							IL_087f:
																							array[num5 - 2] = 0;
																							goto IL_0893;
																							IL_070b:
																							if (4 <= b)
																							{
																								goto IL_0716;
																							}
																							num = 109;
																							goto IL_075e;
																							IL_0716:
																							array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																							goto IL_0734;
																							IL_0734:
																							ptr2 += 8;
																							goto IL_0742;
																							IL_0742:
																							num5--;
																							goto end_IL_036a;
																							IL_0893:
																							num5--;
																							goto end_IL_036a;
																							IL_075e:
																							if (2 < b)
																							{
																								goto IL_0769;
																							}
																							goto IL_07c7;
																							IL_0769:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_0777;
																							IL_0777:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_0785;
																							IL_0785:
																							array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																							goto IL_07ae;
																							IL_07ae:
																							array[num5 - 1] = 5;
																							goto end_IL_036a;
																							IL_07c7:
																							if (2 > b)
																							{
																								goto IL_07d2;
																							}
																							goto IL_083f;
																							IL_07d2:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_07e0;
																							IL_07e0:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_07ee;
																							IL_07ee:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0807;
																							IL_0807:
																							array[num5] = 0;
																							goto IL_0815;
																							IL_0815:
																							num5++;
																							num = 41;
																							goto IL_082c;
																							IL_082c:
																							ptr2 += 8;
																							goto end_IL_036a;
																							IL_083f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_087f;
																						}
																						break;
																					}
																					goto IL_08a3;
																					IL_08a3:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_036a;
																				}
																				break;
																			}
																			goto IL_0375;
																			IL_050b:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0519;
																			IL_0375:
																			if (12 >= b)
																			{
																				goto IL_0383;
																			}
																			goto IL_04a4;
																			IL_0383:
																			if (12 > b)
																			{
																				goto IL_0391;
																			}
																			goto IL_045f;
																			IL_0391:
																			if (10 >= b)
																			{
																				goto IL_039c;
																			}
																			goto IL_03e6;
																			IL_039c:
																			if (10 > b)
																			{
																				goto IL_03a7;
																			}
																			num = 73;
																			goto IL_03c0;
																			IL_03a7:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_03d3;
																			IL_03d3:
																			if (9 > b)
																			{
																				break;
																			}
																			goto end_IL_036a;
																			IL_0519:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0527;
																			IL_03c0:
																			array[num5] = 0;
																			goto IL_05d6;
																			IL_05d6:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05f9;
																			IL_05f9:
																			array2[num5] = null;
																			goto IL_0603;
																			IL_0603:
																			num5++;
																			goto IL_0611;
																			IL_0611:
																			ptr2 += 8;
																			goto end_IL_036a;
																			IL_03e6:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_03f4;
																			IL_03f4:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_0402;
																			IL_0402:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0446;
																			IL_0446:
																			array[num5 - 2] = 0;
																			goto IL_05c3;
																			IL_05c3:
																			num5--;
																			goto end_IL_036a;
																			IL_045f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_059c;
																			IL_059c:
																			array[num5 - 2] = 0;
																			goto IL_05b0;
																			IL_05b0:
																			num5--;
																			goto end_IL_036a;
																			IL_04a4:
																			if (14 < b)
																			{
																				num = 76;
																				goto IL_04b8;
																			}
																			goto IL_04e4;
																			IL_0527:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0589;
																			IL_04b8:
																			if (15 < b)
																			{
																				num = 74;
																				break;
																			}
																			goto IL_04c3;
																			IL_04c3:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_0589:
																			num5 -= 2;
																			goto end_IL_036a;
																			IL_04e4:
																			if (14 <= b)
																			{
																				goto IL_04ef;
																			}
																			goto IL_050b;
																			IL_04ef:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_036a;
																		}
																		break;
																		IL_033a:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_036a;
																continue;
																end_IL_034a:
																break;
															}
															continue;
															end_IL_035a:
															break;
														}
														continue;
														end_IL_036a:
														break;
													}
													continue;
												}
												goto IL_0967;
												IL_0967:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08cb:
												break;
											}
											continue;
											end_IL_08de:
											break;
										}
										continue;
										end_IL_08e8:
										break;
									}
									continue;
									end_IL_08f3:
									break;
								}
								continue;
								end_IL_0903:
								break;
							}
							continue;
							end_IL_0913:
							break;
						}
						continue;
						end_IL_0923:
						break;
					}
					continue;
					end_IL_0933:
					break;
				}
				continue;
				end_IL_094c:
				break;
			}
		}
	}

	private unsafe static int smethod_18(int int_5)
	{
		int num = 99;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_0657:
					num = 41;
					while (true)
					{
						IL_0647:
						byte[] array = new byte[2];
						while (true)
						{
							IL_0637:
							object[] array2 = new object[2];
							while (true)
							{
								IL_0627:
								int[] array3 = new int[3];
								while (true)
								{
									IL_0617:
									long[] array4 = new long[2];
									while (true)
									{
										IL_0602:
										array3[0] = int_5;
										while (true)
										{
											IL_05ee:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct76.mnameHashAlgorithmName);
											num = 58;
											while (true)
											{
												IL_05e4:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_05d1:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0223:
															num = 43;
															while (true)
															{
																IL_0218:
																byte b = *ptr2;
																while (true)
																{
																	IL_0208:
																	ptr2++;
																	while (true)
																	{
																		IL_01f8:
																		if (b >= 1)
																		{
																			while (true)
																			{
																				IL_01e8:
																				if (b > 10)
																				{
																					num = 110;
																					while (num != 110)
																					{
																						if (num != 1091)
																						{
																							goto end_IL_01f8;
																						}
																						switch (num)
																						{
																						case 91:
																							goto IL_01e8;
																						case 24:
																							goto IL_01f8;
																						case 70:
																							goto IL_0208;
																						case 43:
																							goto IL_0218;
																						case 87:
																							goto IL_0223;
																						case 54:
																							goto IL_022e;
																						case 7:
																							goto IL_023c;
																						case 16:
																						case 40:
																							goto IL_024a;
																						case 26:
																							goto IL_0255;
																						case 29:
																							goto IL_0260;
																						case 39:
																							goto IL_026e;
																						case 20:
																						case 42:
																							goto IL_027c;
																						case 33:
																							goto IL_0295;
																						case 12:
																						case 56:
																							goto IL_02b6;
																						case 62:
																						case 63:
																							goto IL_02cf;
																						case 2:
																							goto IL_02dd;
																						case 14:
																							goto IL_0300;
																						case 59:
																							goto IL_030a;
																						case 66:
																							goto IL_031a;
																						case 68:
																							goto IL_0333;
																						case 72:
																						case 73:
																							goto IL_0346;
																						case 75:
																							goto IL_035e;
																						case 65:
																							goto IL_036c;
																						case 49:
																						case 84:
																							goto IL_037f;
																						case 6:
																							goto IL_038d;
																						case 48:
																						case 88:
																							goto IL_03a9;
																						case 52:
																							goto IL_03b7;
																						case 60:
																						case 80:
																							goto IL_03c2;
																						case 0:
																							goto IL_0424;
																						case 61:
																							goto IL_0440;
																						case 46:
																						case 74:
																							goto IL_044b;
																						case 82:
																							goto IL_045b;
																						case 47:
																						case 64:
																							goto IL_0469;
																						case 44:
																							goto IL_04a9;
																						case 78:
																							goto IL_04bd;
																						case 89:
																							goto IL_04d0;
																						case 23:
																						case 38:
																							goto IL_04de;
																						case 10:
																							goto IL_0501;
																						case 32:
																							goto IL_050f;
																						case 83:
																							goto IL_051d;
																						case 51:
																						case 95:
																							goto IL_0530;
																						case 45:
																							goto IL_053b;
																						case 27:
																						case 34:
																							goto IL_0546;
																						case 13:
																							goto IL_055f;
																						case 21:
																							goto IL_056a;
																						case 8:
																						case 97:
																							goto IL_0577;
																						case 22:
																							goto IL_05a0;
																						case 50:
																							goto IL_05ae;
																						case 4:
																						case 5:
																						case 9:
																						case 11:
																						case 15:
																						case 19:
																						case 28:
																						case 37:
																						case 57:
																						case 71:
																						case 76:
																						case 77:
																						case 81:
																						case 85:
																						case 94:
																						case 100:
																							goto end_IL_01d5;
																						case 17:
																						case 18:
																						case 31:
																						case 35:
																						case 36:
																						case 53:
																						case 67:
																						case 69:
																						case 90:
																						case 93:
																						case 96:
																						case 101:
																						case 103:
																							goto IL_05d1;
																						case 58:
																							goto IL_05e4;
																						case 55:
																							goto IL_05ee;
																						case 92:
																							goto IL_0602;
																						case 30:
																							goto IL_0617;
																						case 3:
																						case 102:
																							goto IL_0627;
																						case 86:
																							goto IL_0637;
																						case 41:
																							goto IL_0647;
																						case 79:
																							goto IL_0657;
																						case 98:
																							goto end_IL_01f8;
																						case 99:
																							goto end_IL_0662;
																						case 1:
																						case 25:
																							goto IL_067d;
																						}
																						continue;
																						end_IL_01d5:
																						break;
																					}
																					break;
																				}
																				goto IL_022e;
																				IL_04bd:
																				num5--;
																				goto IL_05d1;
																				IL_0530:
																				if (9 >= b)
																				{
																					goto IL_053b;
																				}
																				goto IL_055f;
																				IL_022e:
																				if (5 >= b)
																				{
																					goto IL_023c;
																				}
																				goto IL_03a9;
																				IL_023c:
																				if (5 > b)
																				{
																					goto IL_024a;
																				}
																				goto IL_02cf;
																				IL_024a:
																				if (2 >= b)
																				{
																					goto IL_0255;
																				}
																				goto IL_02b6;
																				IL_0255:
																				if (2 > b)
																				{
																					goto IL_0260;
																				}
																				num = 8;
																				goto IL_0577;
																				IL_0260:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_026e;
																				IL_026e:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_027c;
																				IL_027c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0295;
																				IL_0295:
																				array[num5] = 0;
																				goto IL_035e;
																				IL_035e:
																				num5++;
																				goto IL_036c;
																				IL_036c:
																				ptr2 += 8;
																				goto IL_05d1;
																				IL_053b:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0546;
																				IL_0577:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_05a0;
																				IL_05a0:
																				ptr2 += 8;
																				goto IL_05ae;
																				IL_05ae:
																				num5--;
																				goto IL_05d1;
																				IL_02b6:
																				if (3 >= b)
																				{
																					goto IL_031a;
																				}
																				num = 49;
																				goto IL_037f;
																				IL_0546:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto IL_05d1;
																				IL_037f:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_038d;
																				IL_038d:
																				if (4 > b)
																				{
																					break;
																				}
																				num = 96;
																				goto IL_05d1;
																				IL_055f:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_056a;
																				IL_031a:
																				if (3 > b)
																				{
																					num = 19;
																					break;
																				}
																				goto IL_0346;
																				IL_056a:
																				if (10 <= b)
																				{
																				}
																				break;
																				IL_0346:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_05d1;
																				IL_02cf:
																				array[num5] = 0;
																				goto IL_02dd;
																				IL_02dd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0300;
																				IL_0300:
																				array2[num5] = null;
																				goto IL_030a;
																				IL_030a:
																				num5++;
																				goto IL_0333;
																				IL_0333:
																				ptr2 += 8;
																				goto IL_05d1;
																				IL_03a9:
																				if (8 >= b)
																				{
																					goto IL_03b7;
																				}
																				goto IL_0530;
																				IL_03b7:
																				if (8 <= b)
																				{
																					goto IL_03c2;
																				}
																				goto IL_0440;
																				IL_03c2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0424;
																				IL_0424:
																				num5 -= 2;
																				num = 103;
																				goto IL_05d1;
																				IL_0440:
																				if (6 < b)
																				{
																					goto IL_044b;
																				}
																				goto IL_045b;
																				IL_044b:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_04d0;
																				IL_04d0:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_04de;
																				IL_04de:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0501;
																				IL_0501:
																				array[num5] = 0;
																				goto IL_050f;
																				IL_050f:
																				num5++;
																				goto IL_051d;
																				IL_051d:
																				ptr2 += 8;
																				goto IL_05d1;
																				IL_045b:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_0469;
																				IL_0469:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04a9;
																				IL_04a9:
																				array[num5 - 2] = 0;
																				goto IL_04bd;
																			}
																		}
																		ptr2 = ptr + *(int*)(ptr2 + num3);
																		goto IL_05d1;
																		continue;
																		end_IL_01f8:
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_067d;
													IL_067d:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_0662:
				break;
			}
		}
	}

	private unsafe static int smethod_19()
	{
		int num = 100;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ContinueWhenAllopSubtraction.JULIANgetNextActivator);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03b3:
														num = 19;
														while (true)
														{
															IL_03a8:
															byte b = *ptr2;
															while (true)
															{
																IL_0398:
																ptr2++;
																while (true)
																{
																	IL_0388:
																	if (b >= 1)
																	{
																		while (true)
																		{
																			IL_0378:
																			if (b <= 17)
																			{
																				while (true)
																				{
																					IL_036b:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_035b:
																							if (13 >= b)
																							{
																								while (true)
																								{
																									IL_034b:
																									if (13 <= b)
																									{
																										while (true)
																										{
																											IL_02e7:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											while (true)
																											{
																												IL_02ce:
																												num5 -= 2;
																												num = 171;
																												while (num != 171)
																												{
																													if (num != 1152)
																													{
																														goto IL_0866;
																													}
																													switch (num)
																													{
																													case 86:
																														goto IL_02ce;
																													case 102:
																													case 154:
																														goto IL_02e7;
																													case 50:
																														goto IL_034b;
																													case 113:
																													case 147:
																														goto IL_035b;
																													case 69:
																														goto IL_036b;
																													case 43:
																														goto IL_0378;
																													case 116:
																														goto IL_0388;
																													case 46:
																														goto IL_0398;
																													case 19:
																														goto IL_03a8;
																													case 87:
																														goto IL_03b3;
																													case 31:
																														goto IL_03be;
																													case 40:
																														goto IL_03cc;
																													case 44:
																														goto IL_03d7;
																													case 6:
																														goto IL_03e5;
																													case 67:
																														goto IL_03f2;
																													case 35:
																														goto IL_0400;
																													case 49:
																														goto IL_040e;
																													case 77:
																														goto IL_0421;
																													case 33:
																													case 83:
																														goto IL_0434;
																													case 5:
																													case 108:
																														goto IL_0447;
																													case 64:
																													case 107:
																														goto IL_0452;
																													case 11:
																														goto IL_0460;
																													case 52:
																														goto IL_0470;
																													case 65:
																														goto IL_047b;
																													case 98:
																													case 119:
																														goto IL_0497;
																													case 51:
																														goto IL_04d6;
																													case 106:
																													case 121:
																														goto IL_04e9;
																													case 18:
																														goto IL_0512;
																													case 93:
																													case 127:
																														goto IL_0525;
																													case 13:
																														goto IL_0533;
																													case 63:
																													case 131:
																														goto IL_0541;
																													case 25:
																													case 134:
																														goto IL_0559;
																													case 101:
																													case 135:
																														goto IL_057c;
																													case 104:
																														goto IL_05bc;
																													case 42:
																													case 141:
																														goto IL_05d2;
																													case 14:
																														goto IL_0612;
																													case 38:
																														goto IL_0626;
																													case 145:
																														goto IL_0639;
																													case 146:
																														goto IL_064c;
																													case 149:
																														goto IL_065f;
																													case 1:
																													case 16:
																														goto IL_066d;
																													case 34:
																														goto IL_0696;
																													case 152:
																														goto IL_06af;
																													case 91:
																														goto IL_06bd;
																													case 153:
																														goto IL_06cd;
																													case 94:
																														goto IL_06db;
																													case 156:
																														goto IL_06ee;
																													case 56:
																													case 72:
																														goto IL_06fc;
																													case 37:
																														goto IL_070a;
																													case 24:
																														goto IL_0722;
																													case 32:
																														goto IL_0730;
																													case 140:
																													case 157:
																														goto IL_0743;
																													case 39:
																														goto IL_075c;
																													case 92:
																														goto IL_076a;
																													case 130:
																														goto IL_0778;
																													case 163:
																														goto IL_078b;
																													case 124:
																													case 148:
																														goto IL_0796;
																													case 7:
																														goto IL_07da;
																													case 8:
																														goto IL_07ee;
																													case 59:
																														goto IL_0801;
																													case 164:
																														goto IL_080f;
																													case 9:
																													case 68:
																														goto IL_081d;
																													case 15:
																														goto IL_082b;
																													case 30:
																														goto IL_084e;
																													case 80:
																														goto IL_0858;
																													case 161:
																														goto IL_0866;
																													case 138:
																														goto IL_0879;
																													case 90:
																													case 143:
																														goto IL_0884;
																													case 47:
																													case 71:
																														goto IL_088f;
																													case 85:
																														goto IL_089d;
																													case 4:
																														goto IL_08b0;
																													case 0:
																													case 151:
																														goto IL_08be;
																													case 21:
																														goto IL_08da;
																													case 76:
																													case 159:
																														goto IL_08e8;
																													case 55:
																														goto IL_08f6;
																													case 58:
																													case 162:
																														goto IL_0904;
																													case 62:
																														goto IL_0918;
																													case 117:
																														goto IL_096c;
																													case 61:
																														goto IL_097a;
																													case 12:
																													case 97:
																														goto IL_098a;
																													case 10:
																													case 17:
																													case 20:
																													case 23:
																													case 27:
																													case 29:
																													case 36:
																													case 41:
																													case 48:
																													case 60:
																													case 66:
																													case 73:
																													case 75:
																													case 81:
																													case 88:
																													case 89:
																													case 95:
																													case 96:
																													case 109:
																													case 110:
																													case 112:
																													case 114:
																													case 120:
																													case 125:
																													case 126:
																													case 128:
																													case 133:
																													case 136:
																													case 144:
																													case 150:
																														goto IL_09ae;
																													case 2:
																													case 3:
																													case 26:
																													case 28:
																													case 54:
																													case 57:
																													case 70:
																													case 74:
																													case 82:
																													case 84:
																													case 103:
																													case 105:
																													case 111:
																													case 115:
																													case 123:
																													case 132:
																													case 139:
																													case 158:
																													case 160:
																														goto end_IL_02bb;
																													case 137:
																														goto end_IL_09c1;
																													case 118:
																														goto end_IL_09d4;
																													case 122:
																														goto end_IL_09de;
																													case 22:
																														goto end_IL_09e9;
																													case 45:
																													case 78:
																														goto end_IL_09f9;
																													case 155:
																														goto end_IL_0a09;
																													case 53:
																													case 142:
																														goto end_IL_0a19;
																													case 99:
																														goto end_IL_0a29;
																													case 100:
																														goto end_IL_0a39;
																													case 79:
																													case 129:
																														goto IL_0a54;
																													}
																													continue;
																													end_IL_02bb:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_03f2;
																									IL_0866:
																									ptr2 += 8;
																									break;
																									IL_03f2:
																									if (11 < b)
																									{
																										goto IL_0400;
																									}
																									goto IL_078b;
																									IL_0400:
																									if (12 >= b)
																									{
																										goto IL_040e;
																									}
																									goto IL_09ae;
																									IL_040e:
																									if (12 <= b)
																									{
																										goto IL_057c;
																									}
																									goto IL_09ae;
																									IL_057c:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									goto IL_05bc;
																									IL_05bc:
																									array[num5 - 2] = 0;
																									goto IL_0639;
																									IL_0639:
																									num5--;
																									break;
																									IL_078b:
																									if (11 <= b)
																									{
																										goto IL_0796;
																									}
																									goto IL_0801;
																									IL_0796:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																									goto IL_07da;
																									IL_07da:
																									array[num5 - 2] = 0;
																									goto IL_07ee;
																									IL_07ee:
																									num5--;
																									break;
																									IL_0801:
																									if (10 >= b)
																									{
																										goto IL_080f;
																									}
																									goto IL_09ae;
																									IL_080f:
																									if (10 <= b)
																									{
																										goto IL_081d;
																									}
																									goto IL_09ae;
																									IL_081d:
																									array[num5] = 0;
																									goto IL_082b;
																									IL_082b:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																									goto IL_084e;
																									IL_084e:
																									array2[num5] = null;
																									goto IL_0858;
																									IL_0858:
																									num5++;
																									goto IL_0866;
																								}
																								break;
																							}
																							goto IL_0879;
																							IL_098a:
																							num5--;
																							break;
																							IL_0879:
																							if (15 < b)
																							{
																								goto IL_0884;
																							}
																							goto IL_08da;
																							IL_0884:
																							if (16 < b)
																							{
																								goto IL_088f;
																							}
																							goto IL_08b0;
																							IL_088f:
																							if (17 >= b)
																							{
																								goto IL_089d;
																							}
																							goto IL_09ae;
																							IL_089d:
																							if (17 > b)
																							{
																							}
																							goto IL_09ae;
																							IL_08b0:
																							if (16 <= b)
																							{
																								goto IL_08be;
																							}
																							goto IL_09ae;
																							IL_08be:
																							byte* num6 = ptr2;
																							num4 = 1;
																							ptr2 = num6 + -200;
																							break;
																							IL_08da:
																							if (15 > b)
																							{
																								goto IL_08e8;
																							}
																							goto IL_098a;
																							IL_08e8:
																							if (14 >= b)
																							{
																								goto IL_08f6;
																							}
																							goto IL_09ae;
																							IL_08f6:
																							if (14 <= b)
																							{
																								goto IL_0904;
																							}
																							goto IL_09ae;
																							IL_0904:
																							array[num5 - 2] = 0;
																							goto IL_0918;
																							IL_0918:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)CreateFromSignedFileSignHash[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_096c;
																							IL_096c:
																							num5--;
																							goto IL_097a;
																							IL_097a:
																							ptr2 += 8;
																							break;
																						}
																						break;
																					}
																					goto IL_03be;
																					IL_0497:
																					((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_04d6;
																					IL_03be:
																					if (9 <= b)
																					{
																						break;
																					}
																					goto IL_03cc;
																					IL_03cc:
																					if (4 >= b)
																					{
																						goto IL_03d7;
																					}
																					goto IL_0447;
																					IL_03d7:
																					if (4 > b)
																					{
																						goto IL_03e5;
																					}
																					goto IL_0559;
																					IL_03e5:
																					if (2 >= b)
																					{
																						goto IL_0421;
																					}
																					goto IL_0434;
																					IL_0421:
																					if (2 <= b)
																					{
																						goto IL_05d2;
																					}
																					goto IL_06af;
																					IL_05d2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0612;
																					IL_0612:
																					array[num5 - 2] = 0;
																					goto IL_0626;
																					IL_0626:
																					num5--;
																					break;
																					IL_06af:
																					if (1 >= b)
																					{
																						goto IL_06bd;
																					}
																					goto IL_09ae;
																					IL_06bd:
																					if (1 <= b)
																					{
																						goto IL_0743;
																					}
																					goto IL_09ae;
																					IL_0743:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_075c;
																					IL_075c:
																					array[num5] = 0;
																					goto IL_076a;
																					IL_076a:
																					num5++;
																					goto IL_0778;
																					IL_0778:
																					ptr2 += 8;
																					break;
																					IL_0434:
																					if (3 >= b)
																					{
																						goto IL_065f;
																					}
																					goto IL_09ae;
																					IL_065f:
																					if (3 <= b)
																					{
																						goto IL_066d;
																					}
																					goto IL_09ae;
																					IL_066d:
																					array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																					goto IL_0696;
																					IL_0696:
																					array[num5 - 1] = 5;
																					break;
																					IL_0559:
																					array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																					goto IL_06cd;
																					IL_06cd:
																					ptr2 += 8;
																					goto IL_06db;
																					IL_06db:
																					num5--;
																					break;
																					IL_0447:
																					if (6 < b)
																					{
																						goto IL_0452;
																					}
																					goto IL_0470;
																					IL_0452:
																					if (7 >= b)
																					{
																						goto IL_0460;
																					}
																					goto IL_0525;
																					IL_0460:
																					if (7 <= b)
																					{
																						goto IL_04e9;
																					}
																					goto IL_09ae;
																					IL_04e9:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0512;
																					IL_0512:
																					ptr2 += 8;
																					goto IL_064c;
																					IL_064c:
																					num5--;
																					break;
																					IL_0525:
																					if (8 >= b)
																					{
																						goto IL_0533;
																					}
																					goto IL_09ae;
																					IL_0533:
																					if (8 <= b)
																					{
																						goto IL_0541;
																					}
																					goto IL_09ae;
																					IL_0541:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					break;
																					IL_0470:
																					if (6 > b)
																					{
																						goto IL_047b;
																					}
																					num = 119;
																					goto IL_0497;
																					IL_047b:
																					if (5 >= b)
																					{
																						goto IL_06ee;
																					}
																					goto IL_09ae;
																					IL_06ee:
																					if (5 <= b)
																					{
																						goto IL_06fc;
																					}
																					goto IL_09ae;
																					IL_06fc:
																					array[num5] = 5;
																					goto IL_070a;
																					IL_070a:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_0722;
																					IL_0722:
																					num5++;
																					goto IL_0730;
																					IL_0730:
																					ptr2 += 8;
																					break;
																					IL_04d6:
																					num5 -= 3;
																					break;
																				}
																				break;
																			}
																			num = 89;
																			goto IL_09ae;
																		}
																		break;
																	}
																	num = 136;
																	goto IL_09ae;
																	IL_09ae:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a54;
												IL_0a54:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09c1:
												break;
											}
											continue;
											end_IL_09d4:
											break;
										}
										continue;
										end_IL_09de:
										break;
									}
									continue;
									end_IL_09e9:
									break;
								}
								continue;
								end_IL_09f9:
								break;
							}
							continue;
							end_IL_0a09:
							break;
						}
						continue;
						end_IL_0a19:
						break;
					}
					continue;
					end_IL_0a29:
					break;
				}
				continue;
				end_IL_0a39:
				break;
			}
		}
	}

	private unsafe static int smethod_20(int int_5)
	{
		int num = 77;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							num = 85;
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[2];
									num = 29;
									while (true)
									{
										array3[0] = int_5;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref UnloadTaskContinuationOptions.GetRuntimeInterfaceAsObjectArraySortHelper);
											num = 60;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0245:
															byte b = *ptr2;
															while (true)
															{
																IL_0235:
																ptr2++;
																while (true)
																{
																	IL_0225:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			num = 99;
																			while (true)
																			{
																				IL_0202:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_01f2:
																						if (5 <= b)
																						{
																							num = 109;
																							while (true)
																							{
																								if (num != 109)
																								{
																									if (num != 1090)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 88:
																										goto IL_01f2;
																									case 99:
																										goto IL_0202;
																									case 46:
																										goto IL_0212;
																									case 64:
																										goto IL_0225;
																									case 67:
																										goto IL_0235;
																									case 33:
																									case 53:
																										goto IL_0245;
																									case 30:
																										goto IL_0250;
																									case 58:
																										goto IL_025b;
																									case 24:
																									case 86:
																										goto IL_026b;
																									case 56:
																										goto IL_0276;
																									case 32:
																										goto IL_0284;
																									case 92:
																										goto IL_0297;
																									case 81:
																									case 89:
																										goto IL_02a5;
																									case 96:
																										goto IL_02bd;
																									case 95:
																										goto IL_02cb;
																									case 34:
																									case 94:
																										goto IL_02d9;
																									case 44:
																										goto IL_02f2;
																									case 57:
																										goto IL_0300;
																									case 5:
																										goto IL_030e;
																									case 28:
																									case 97:
																										goto IL_0321;
																									case 25:
																										goto IL_034a;
																									case 20:
																										goto IL_0358;
																									case 19:
																										goto IL_036b;
																									case 43:
																										goto IL_0379;
																									case 42:
																										goto IL_039c;
																									case 40:
																										goto IL_03a6;
																									case 93:
																										goto IL_03b4;
																									case 82:
																										goto IL_03c7;
																									case 16:
																										goto IL_03d5;
																									case 47:
																									case 75:
																										goto IL_03e3;
																									case 2:
																									case 59:
																										goto IL_03ee;
																									case 38:
																										goto IL_03fc;
																									case 1:
																									case 52:
																										goto IL_040a;
																									case 61:
																										goto IL_042d;
																									case 22:
																										goto IL_043b;
																									case 74:
																										goto IL_0449;
																									case 27:
																										goto IL_045c;
																									case 3:
																									case 62:
																										goto IL_046a;
																									case 35:
																										goto IL_04aa;
																									case 7:
																										goto IL_04be;
																									case 71:
																									case 79:
																										goto IL_04d1;
																									case 36:
																										goto IL_0533;
																									case 51:
																										goto IL_0543;
																									case 84:
																										goto IL_054e;
																									case 87:
																									case 101:
																										goto IL_0559;
																									case 73:
																										goto IL_0572;
																									case 90:
																										goto IL_057d;
																									case 8:
																									case 9:
																									case 12:
																									case 13:
																									case 14:
																									case 17:
																									case 18:
																									case 21:
																									case 23:
																									case 26:
																									case 41:
																									case 50:
																									case 54:
																									case 55:
																									case 63:
																									case 72:
																									case 83:
																									case 98:
																									case 102:
																										goto end_IL_0212;
																									case 0:
																									case 4:
																									case 6:
																									case 31:
																									case 37:
																									case 48:
																									case 49:
																									case 65:
																									case 66:
																									case 78:
																									case 80:
																									case 91:
																									case 100:
																										goto end_IL_01df;
																									case 60:
																										goto end_IL_059b;
																									case 10:
																										goto end_IL_05ae;
																									case 29:
																										goto end_IL_05b8;
																									case 11:
																										goto end_IL_05cc;
																									case 85:
																										goto end_IL_05e1;
																									case 69:
																										goto end_IL_05fa;
																									case 70:
																										goto end_IL_060a;
																									case 15:
																									case 39:
																										goto end_IL_0615;
																									case 76:
																										goto end_IL_0625;
																									case 77:
																										goto end_IL_0635;
																									case 45:
																									case 68:
																										goto IL_0650;
																									}
																									continue;
																								}
																								goto IL_036b;
																								IL_03a6:
																								num5++;
																								goto IL_03b4;
																								IL_03b4:
																								ptr2 += 8;
																								break;
																								IL_036b:
																								array[num5] = 0;
																								goto IL_0379;
																								IL_0379:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_039c;
																								IL_039c:
																								array2[num5] = null;
																								goto IL_03a6;
																								continue;
																								end_IL_01df:
																								break;
																							}
																							break;
																						}
																						goto IL_0250;
																						IL_0297:
																						if (3 > b)
																						{
																							goto end_IL_0212;
																						}
																						goto IL_02a5;
																						IL_02a5:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						break;
																						IL_0250:
																						if (2 >= b)
																						{
																							goto IL_025b;
																						}
																						goto IL_026b;
																						IL_025b:
																						if (2 > b)
																						{
																							goto IL_02bd;
																						}
																						goto IL_0321;
																						IL_0321:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_034a;
																						IL_034a:
																						ptr2 += 8;
																						goto IL_0358;
																						IL_0358:
																						num5--;
																						break;
																						IL_02bd:
																						if (1 < b)
																						{
																							goto end_IL_0212;
																						}
																						goto IL_02cb;
																						IL_02cb:
																						if (1 > b)
																						{
																							goto end_IL_0212;
																						}
																						goto IL_02d9;
																						IL_02d9:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_02f2;
																						IL_02f2:
																						array[num5] = 0;
																						goto IL_0300;
																						IL_0300:
																						num5++;
																						goto IL_030e;
																						IL_030e:
																						ptr2 += 8;
																						break;
																						IL_026b:
																						if (3 < b)
																						{
																							goto IL_0276;
																						}
																						goto IL_0297;
																						IL_0276:
																						if (4 < b)
																						{
																							goto end_IL_0212;
																						}
																						goto IL_0284;
																						IL_0284:
																						if (4 <= b)
																						{
																							break;
																						}
																						goto end_IL_0212;
																					}
																					break;
																				}
																				goto IL_03c7;
																				IL_057d:
																				if (10 <= b)
																				{
																				}
																				goto end_IL_0212;
																				IL_03c7:
																				if (8 >= b)
																				{
																					goto IL_03d5;
																				}
																				goto IL_0543;
																				IL_03d5:
																				if (8 > b)
																				{
																					goto IL_03e3;
																				}
																				goto IL_04d1;
																				IL_03e3:
																				if (6 < b)
																				{
																					goto IL_03ee;
																				}
																				goto IL_045c;
																				IL_03ee:
																				if (7 < b)
																				{
																					goto end_IL_0212;
																				}
																				goto IL_03fc;
																				IL_03fc:
																				if (7 > b)
																				{
																					goto end_IL_0212;
																				}
																				goto IL_040a;
																				IL_040a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_042d;
																				IL_042d:
																				array[num5] = 0;
																				goto IL_043b;
																				IL_043b:
																				num5++;
																				goto IL_0449;
																				IL_0449:
																				ptr2 += 8;
																				break;
																				IL_045c:
																				if (6 > b)
																				{
																					goto end_IL_0212;
																				}
																				goto IL_046a;
																				IL_046a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04aa;
																				IL_04aa:
																				array[num5 - 2] = 0;
																				goto IL_04be;
																				IL_04be:
																				num5--;
																				break;
																				IL_04d1:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0533;
																				IL_0533:
																				num5 -= 2;
																				break;
																				IL_0543:
																				if (9 >= b)
																				{
																					goto IL_054e;
																				}
																				goto IL_0572;
																				IL_054e:
																				if (9 > b)
																				{
																					goto end_IL_0212;
																				}
																				goto IL_0559;
																				IL_0559:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0572:
																				if (10 < b)
																				{
																					goto end_IL_0212;
																				}
																				goto IL_057d;
																			}
																			goto end_IL_0225;
																			continue;
																			end_IL_0212:
																			break;
																			IL_0212:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0225:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0650;
													IL_0650:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_059b:
													break;
												}
												continue;
												end_IL_05ae:
												break;
											}
											continue;
											end_IL_05b8:
											break;
										}
										continue;
										end_IL_05cc:
										break;
									}
									continue;
									end_IL_05e1:
									break;
								}
								continue;
								end_IL_05fa:
								break;
							}
							continue;
							end_IL_060a:
							break;
						}
						continue;
						end_IL_0615:
						break;
					}
					continue;
					end_IL_0625:
					break;
				}
				continue;
				end_IL_0635:
				break;
			}
		}
	}

	static Class105()
	{
		int num = 1;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				IL_005b:
				Class300.smethod_0();
				while (true)
				{
					IL_0046:
					num = 12;
					while (true)
					{
						if (num != 12)
						{
							if (num != 993)
							{
								break;
							}
							switch (num)
							{
							case 2:
							case 3:
							case 4:
							case 5:
								goto IL_0046;
							case 0:
								goto IL_005b;
							case 1:
								goto end_IL_0039;
							}
							continue;
						}
						return;
						continue;
						end_IL_0039:
						break;
					}
					break;
				}
				break;
			}
		}
	}
}
