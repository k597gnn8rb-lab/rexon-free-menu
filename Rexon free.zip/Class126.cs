using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Button Clicker", "Settings", "Click buttons with mouse", false, 12, ModType.const_0, true)]
internal class Class126 : MonoBehaviour
{
	private static Camera camera_0;

	private static float float_0;

	private static MethodInfo methodInfo_0;

	private static MethodInfo methodInfo_1;

	private static Collider collider_0;

	private static double double_0;

	private static bool bool_0;

	private static float float_1;

	private static double double_1;

	private static int int_0;

	private static float float_2;

	private static int int_1;

	private static RaycastHit RuntimeTypeCacheTargetType;

	private static IntPtr[] EnterprisePolicyLevelLPUTFStr;

	private static IntPtr[] getSpecialKeygetAsyncWaitHandle;

	private static IntPtr[] GetFileSystemEntriesPreAllocatedOverlapped;

	private static IntPtr[] BleIServerChannelSinkStack;

	private static IntPtr[] AccountGuestSidCharArray;

	private static IntPtr[] TimeSpanRawInfoMemberCount;

	private unsafe static int smethod_0(int int_2, int int_3)
	{
		int num = 97;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 96;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref LoadAssemblyFromStringWeakTrackResurrection.PathFindComponentsByReference);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03ad:
																	if (b < 1)
																	{
																		goto IL_036c;
																	}
																	goto IL_039d;
																	IL_039d:
																	if (b <= 11)
																	{
																		goto IL_021e;
																	}
																	goto IL_036c;
																	IL_036c:
																	while (true)
																	{
																		IL_036c_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		num = 127;
																		while (true)
																		{
																			if (num != 127)
																			{
																				if (num != 1108)
																				{
																					break;
																				}
																				switch (num)
																				{
																				case 31:
																					goto IL_021e;
																				case 50:
																					goto IL_0229;
																				case 63:
																					goto IL_0239;
																				case 23:
																					goto IL_0247;
																				case 61:
																				case 71:
																					goto IL_0255;
																				case 8:
																				case 86:
																					goto IL_0271;
																				case 14:
																					goto IL_027c;
																				case 48:
																					goto IL_028a;
																				case 39:
																					goto IL_0295;
																				case 13:
																					goto IL_02a3;
																				case 54:
																					goto IL_02bf;
																				case 29:
																					goto IL_02d2;
																				case 2:
																				case 75:
																					goto end_IL_020b;
																				case 52:
																					goto IL_02eb;
																				case 43:
																					goto IL_02fb;
																				case 98:
																					goto IL_030b;
																				case 66:
																				case 82:
																					goto IL_0316;
																				case 62:
																					goto IL_0323;
																				case 100:
																					goto IL_0333;
																				case 58:
																				case 103:
																					goto IL_0343;
																				case 4:
																					goto IL_034e;
																				case 106:
																					goto IL_035e;
																				case 3:
																				case 6:
																				case 10:
																				case 26:
																				case 41:
																				case 45:
																				case 51:
																				case 64:
																				case 74:
																				case 84:
																				case 87:
																				case 89:
																				case 90:
																				case 94:
																				case 95:
																				case 101:
																				case 107:
																				case 114:
																				case 116:
																				case 120:
																					goto IL_036c_2;
																				case 111:
																					goto IL_039d;
																				case 1:
																					goto IL_03ad;
																				case 118:
																					goto end_IL_03ad;
																				case 0:
																				case 110:
																					goto end_IL_03ba;
																				case 69:
																				case 73:
																					goto IL_03d5;
																				case 5:
																				case 79:
																					goto IL_03ee;
																				case 11:
																					goto IL_042e;
																				case 20:
																				case 83:
																					goto IL_0450;
																				case 38:
																					goto IL_0479;
																				case 47:
																				case 77:
																					goto IL_0489;
																				case 81:
																					goto IL_04c9;
																				case 12:
																				case 18:
																					goto IL_04e2;
																				case 88:
																					goto IL_04f5;
																				case 55:
																				case 91:
																					goto IL_0508;
																				case 99:
																					goto IL_051b;
																				case 60:
																				case 78:
																					goto IL_052e;
																				case 102:
																					goto IL_056e;
																				case 105:
																					goto IL_0582;
																				case 21:
																				case 53:
																					goto IL_0595;
																				case 34:
																				case 108:
																					goto IL_05b1;
																				case 28:
																					goto IL_05ca;
																				case 9:
																					goto IL_05d8;
																				case 59:
																					goto IL_05e6;
																				case 109:
																					goto IL_05f9;
																				case 56:
																					goto IL_0656;
																				case 92:
																					goto IL_0664;
																				case 113:
																					goto IL_0677;
																				case 57:
																				case 117:
																					goto IL_068a;
																				case 65:
																					goto IL_06ca;
																				case 42:
																					goto IL_06de;
																				case 119:
																					goto IL_06ee;
																				case 7:
																					goto IL_0711;
																				case 33:
																					goto IL_071b;
																				case 35:
																					goto IL_0729;
																				case 68:
																					goto IL_0747;
																				case 80:
																					goto IL_0755;
																				case 15:
																				case 16:
																				case 17:
																				case 27:
																				case 32:
																				case 36:
																				case 37:
																				case 40:
																				case 49:
																				case 67:
																				case 70:
																				case 76:
																				case 115:
																					goto end_IL_03ca;
																				case 85:
																					goto end_IL_0763;
																				case 72:
																					goto end_IL_0776;
																				case 44:
																					goto end_IL_0780;
																				case 30:
																					goto end_IL_078b;
																				case 22:
																					goto end_IL_07a0;
																				case 25:
																				case 46:
																					goto end_IL_07b5;
																				case 104:
																					goto end_IL_07c5;
																				case 19:
																				case 112:
																					goto end_IL_07d5;
																				case 96:
																					goto end_IL_07e5;
																				case 97:
																					goto end_IL_07f5;
																				case 24:
																				case 93:
																					goto IL_0822;
																				}
																				continue;
																			}
																			array[num5] = 0;
																			goto IL_0747;
																			IL_0747:
																			num5++;
																			goto IL_0755;
																			IL_0755:
																			ptr2 += 8;
																			goto end_IL_03ca;
																			continue;
																			end_IL_020b:
																			break;
																		}
																		break;
																	}
																	goto IL_02dd;
																	IL_021e:
																	if (6 >= b)
																	{
																		goto IL_0229;
																	}
																	goto IL_0239;
																	IL_0229:
																	if (6 > b)
																	{
																		goto IL_0271;
																	}
																	goto IL_03ee;
																	IL_0271:
																	if (3 >= b)
																	{
																		goto IL_027c;
																	}
																	goto IL_02d2;
																	IL_027c:
																	if (3 > b)
																	{
																		goto IL_028a;
																	}
																	goto IL_0450;
																	IL_028a:
																	if (1 < b)
																	{
																		goto IL_0295;
																	}
																	goto IL_02bf;
																	IL_0295:
																	if (2 >= b)
																	{
																		goto IL_02a3;
																	}
																	goto IL_036c;
																	IL_02a3:
																	if (2 > b)
																	{
																		num = 64;
																		goto IL_036c;
																	}
																	goto IL_0489;
																	IL_0323:
																	if (10 > b)
																	{
																		goto IL_036c;
																	}
																	goto IL_0508;
																	IL_0489:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04c9;
																	IL_04c9:
																	array[num5 - 2] = 0;
																	goto IL_0677;
																	IL_0677:
																	num5--;
																	goto end_IL_03ca;
																	IL_02bf:
																	if (1 <= b)
																	{
																	}
																	goto IL_036c;
																	IL_0450:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0479;
																	IL_0479:
																	ptr2 += 8;
																	goto IL_04f5;
																	IL_04f5:
																	num5--;
																	goto end_IL_03ca;
																	IL_02d2:
																	if (4 < b)
																	{
																		goto IL_02dd;
																	}
																	goto IL_02fb;
																	IL_02dd:
																	if (5 >= b)
																	{
																		goto IL_02eb;
																	}
																	goto IL_036c;
																	IL_02eb:
																	if (5 > b)
																	{
																		goto IL_036c;
																	}
																	goto IL_04e2;
																	IL_04e2:
																	array[num5] = 0;
																	goto IL_06ee;
																	IL_06ee:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_0711;
																	IL_0711:
																	array2[num5] = null;
																	goto IL_071b;
																	IL_071b:
																	num5++;
																	goto IL_0729;
																	IL_0729:
																	ptr2 += 8;
																	goto end_IL_03ca;
																	IL_02fb:
																	if (4 > b)
																	{
																		goto IL_036c;
																	}
																	goto IL_068a;
																	IL_068a:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_06ca;
																	IL_06ca:
																	array[num5 - 2] = 0;
																	goto IL_06de;
																	IL_06de:
																	num5--;
																	goto end_IL_03ca;
																	IL_03ee:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_042e;
																	IL_042e:
																	array[num5 - 2] = 0;
																	num = 99;
																	goto IL_051b;
																	IL_051b:
																	num5--;
																	goto end_IL_03ca;
																	IL_0239:
																	if (9 >= b)
																	{
																		goto IL_0247;
																	}
																	goto IL_030b;
																	IL_0247:
																	if (9 > b)
																	{
																		goto IL_0255;
																	}
																	goto IL_03d5;
																	IL_0255:
																	if (7 >= b)
																	{
																		goto IL_0333;
																	}
																	num = 103;
																	goto IL_0343;
																	IL_0508:
																	num5--;
																	goto end_IL_03ca;
																	IL_0343:
																	if (8 >= b)
																	{
																		goto IL_034e;
																	}
																	goto IL_036c;
																	IL_034e:
																	if (8 > b)
																	{
																		goto IL_036c;
																	}
																	goto IL_052e;
																	IL_052e:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_056e;
																	IL_056e:
																	array[num5 - 2] = 0;
																	goto IL_0582;
																	IL_0582:
																	num5--;
																	goto end_IL_03ca;
																	IL_0333:
																	if (7 > b)
																	{
																		goto IL_036c;
																	}
																	goto IL_05b1;
																	IL_05b1:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_05ca;
																	IL_05ca:
																	array[num5] = 0;
																	goto IL_05d8;
																	IL_05d8:
																	num5++;
																	goto IL_05e6;
																	IL_05e6:
																	ptr2 += 8;
																	goto end_IL_03ca;
																	IL_03d5:
																	array[num5 - 2] = 0;
																	goto IL_05f9;
																	IL_05f9:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)TimeSpanRawInfoMemberCount[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																	num = 56;
																	goto IL_0656;
																	IL_0656:
																	num5--;
																	goto IL_0664;
																	IL_0664:
																	ptr2 += 8;
																	goto end_IL_03ca;
																	IL_030b:
																	if (10 < b)
																	{
																		goto IL_0316;
																	}
																	goto IL_0323;
																	IL_0316:
																	if (11 >= b)
																	{
																		goto IL_035e;
																	}
																	goto IL_036c;
																	IL_035e:
																	if (11 > b)
																	{
																		goto IL_036c;
																	}
																	goto IL_0595;
																	IL_0595:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	goto end_IL_03ca;
																	continue;
																	end_IL_03ad:
																	break;
																}
																continue;
																end_IL_03ba:
																break;
															}
															continue;
															end_IL_03ca:
															break;
														}
														continue;
													}
													num = 24;
													goto IL_0822;
													IL_0822:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0763:
													break;
												}
												continue;
												end_IL_0776:
												break;
											}
											continue;
											end_IL_0780:
											break;
										}
										continue;
										end_IL_078b:
										break;
									}
									continue;
									end_IL_07a0:
									break;
								}
								continue;
								end_IL_07b5:
								break;
							}
							continue;
							end_IL_07c5:
							break;
						}
						continue;
						end_IL_07d5:
						break;
					}
					continue;
					end_IL_07e5:
					break;
				}
				continue;
				end_IL_07f5:
				break;
			}
		}
	}

	private static int smethod_1(int int_2, int int_3)
	{
		int num = int_2;
		int num2 = int_3;
		if (num <= num2)
		{
			num = int_3;
			num2 = int_2;
			return num - num2;
		}
		num = int_2;
		num2 = int_3;
		return num - num2;
	}

	private unsafe static int smethod_3()
	{
		int num = 57;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							num = 113;
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TKINDDISPATCHResolver.DefineGenericParametersGuidTypeInfo);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0485:
														byte b = *ptr2;
														while (true)
														{
															IL_0475:
															ptr2++;
															while (true)
															{
																IL_0465:
																if (b >= 1)
																{
																	goto IL_0286;
																}
																goto IL_0444;
																IL_0444:
																while (true)
																{
																	IL_0444_2:
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	num = 153;
																	while (num != 153)
																	{
																		if (num != 1134)
																		{
																			goto IL_05f6;
																		}
																		switch (num)
																		{
																		case 31:
																			goto IL_0286;
																		case 33:
																			goto IL_0294;
																		case 59:
																			goto IL_02a2;
																		case 54:
																		case 132:
																			goto IL_02b0;
																		case 6:
																			goto IL_02bb;
																		case 75:
																		case 110:
																			goto IL_02c9;
																		case 62:
																		case 89:
																			goto IL_02d4;
																		case 36:
																			goto IL_02e2;
																		case 91:
																			goto IL_02f5;
																		case 115:
																			goto IL_0308;
																		case 38:
																		case 44:
																			goto IL_0313;
																		case 18:
																			goto IL_0321;
																		case 98:
																			goto IL_0334;
																		case 126:
																			goto IL_0342;
																		case 136:
																			goto IL_0355;
																		case 114:
																			goto IL_0360;
																		case 128:
																			goto IL_036e;
																		case 3:
																			goto IL_0379;
																		case 35:
																		case 88:
																			goto IL_0390;
																		case 27:
																			goto IL_039e;
																		case 84:
																			goto IL_03b1;
																		case 81:
																			goto IL_03bf;
																		case 76:
																			goto IL_03cf;
																		case 30:
																			goto IL_03da;
																		case 19:
																			goto IL_03e8;
																		case 7:
																			goto IL_03f3;
																		case 96:
																			goto IL_0403;
																		case 24:
																			goto IL_040e;
																		case 97:
																		case 138:
																			goto IL_041b;
																		case 69:
																			goto IL_0426;
																		case 143:
																			goto IL_0436;
																		case 15:
																		case 16:
																		case 20:
																		case 23:
																		case 26:
																		case 41:
																		case 45:
																		case 47:
																		case 48:
																		case 50:
																		case 51:
																		case 64:
																		case 67:
																		case 68:
																		case 72:
																		case 73:
																		case 100:
																		case 118:
																		case 119:
																		case 120:
																		case 123:
																		case 129:
																		case 133:
																		case 134:
																		case 137:
																		case 139:
																		case 142:
																			goto IL_0444_2;
																		case 5:
																			goto IL_0465;
																		case 4:
																			goto IL_0475;
																		case 71:
																		case 74:
																			goto IL_0485;
																		case 85:
																		case 106:
																			goto IL_0490;
																		case 107:
																		case 131:
																			goto IL_04a8;
																		case 17:
																			goto IL_04d1;
																		case 94:
																		case 112:
																			goto IL_04ea;
																		case 99:
																			goto IL_0508;
																		case 122:
																			goto IL_0516;
																		case 46:
																		case 101:
																			goto IL_0529;
																		case 53:
																			goto IL_0552;
																		case 117:
																			goto IL_0560;
																		case 22:
																		case 95:
																			goto IL_0573;
																		case 39:
																			goto IL_05b2;
																		case 40:
																		case 42:
																			goto IL_05c5;
																		case 70:
																			goto IL_05d3;
																		case 108:
																			goto IL_05f6;
																		case 77:
																			goto IL_0600;
																		case 86:
																			goto IL_060e;
																		case 21:
																		case 28:
																			goto IL_0621;
																		case 14:
																			goto IL_0665;
																		case 52:
																			goto IL_0679;
																		case 66:
																		case 135:
																			goto IL_068c;
																		case 61:
																			goto IL_06cc;
																		case 82:
																			goto IL_06e0;
																		case 65:
																		case 92:
																			goto IL_06fc;
																		case 2:
																			goto IL_075e;
																		case 10:
																		case 105:
																			goto IL_0771;
																		case 130:
																			goto IL_0793;
																		case 116:
																			goto IL_07a1;
																		case 60:
																			goto IL_07af;
																		case 25:
																		case 140:
																			goto IL_07c2;
																		case 90:
																		case 144:
																			goto IL_07de;
																		case 8:
																			goto IL_081e;
																		case 109:
																			goto IL_0832;
																		case 78:
																		case 146:
																			goto IL_0842;
																		case 125:
																			goto IL_0850;
																		case 11:
																			goto IL_0871;
																		case 29:
																			goto IL_087f;
																		case 0:
																		case 9:
																		case 12:
																		case 13:
																		case 34:
																		case 37:
																		case 43:
																		case 49:
																		case 55:
																		case 58:
																		case 80:
																		case 87:
																		case 102:
																		case 103:
																		case 124:
																		case 141:
																		case 145:
																			goto end_IL_0273;
																		case 32:
																			goto end_IL_088d;
																		case 79:
																			goto end_IL_08a0;
																		case 121:
																			goto end_IL_08aa;
																		case 113:
																			goto end_IL_08b5;
																		case 93:
																		case 104:
																			goto end_IL_08c5;
																		case 111:
																			goto end_IL_08d5;
																		case 63:
																		case 127:
																			goto end_IL_08ee;
																		case 56:
																			goto end_IL_08fe;
																		case 57:
																			goto end_IL_090e;
																		case 1:
																		case 83:
																			goto IL_0929;
																		}
																		continue;
																		end_IL_0273:
																		break;
																	}
																	break;
																}
																break;
																IL_0286:
																if (b <= 15)
																{
																	goto IL_0294;
																}
																goto IL_0444;
																IL_0294:
																if (8 >= b)
																{
																	goto IL_02a2;
																}
																goto IL_0355;
																IL_02a2:
																if (8 > b)
																{
																	goto IL_02b0;
																}
																goto IL_0490;
																IL_02b0:
																if (4 >= b)
																{
																	goto IL_02bb;
																}
																goto IL_0308;
																IL_02bb:
																if (4 > b)
																{
																	goto IL_02c9;
																}
																goto IL_04ea;
																IL_02c9:
																if (2 < b)
																{
																	goto IL_02d4;
																}
																goto IL_02f5;
																IL_02d4:
																if (3 >= b)
																{
																	goto IL_02e2;
																}
																goto IL_0444;
																IL_02e2:
																if (3 > b)
																{
																	goto IL_0444;
																}
																goto IL_04a8;
																IL_04a8:
																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_04d1;
																IL_04d1:
																array[num5 - 1] = 5;
																break;
																IL_02f5:
																if (2 > b)
																{
																	goto IL_041b;
																}
																goto IL_07de;
																IL_041b:
																if (1 >= b)
																{
																	goto IL_0426;
																}
																goto IL_0444;
																IL_0426:
																if (1 > b)
																{
																	goto IL_0444;
																}
																goto IL_0771;
																IL_0771:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																num = 130;
																goto IL_0793;
																IL_0793:
																array[num5] = 0;
																goto IL_07a1;
																IL_07a1:
																num5++;
																goto IL_07af;
																IL_07af:
																ptr2 += 8;
																break;
																IL_07de:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_081e;
																IL_081e:
																array[num5 - 2] = 0;
																goto IL_0832;
																IL_0832:
																num5--;
																break;
																IL_04ea:
																array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																goto IL_0508;
																IL_0508:
																ptr2 += 8;
																goto IL_0516;
																IL_0516:
																num5--;
																break;
																IL_0308:
																if (6 < b)
																{
																	goto IL_0313;
																}
																goto IL_0334;
																IL_0313:
																if (7 >= b)
																{
																	goto IL_0321;
																}
																goto IL_0444;
																IL_0321:
																if (7 > b)
																{
																	goto IL_0444;
																}
																goto IL_0529;
																IL_0529:
																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_0552;
																IL_0552:
																ptr2 += 8;
																goto IL_0560;
																IL_0560:
																num5--;
																break;
																IL_0334:
																if (6 > b)
																{
																	goto IL_0342;
																}
																goto IL_0573;
																IL_0342:
																if (5 >= b)
																{
																	goto IL_0436;
																}
																goto IL_0444;
																IL_0436:
																if (5 > b)
																{
																	goto IL_0444;
																}
																goto IL_0842;
																IL_0842:
																array[num5] = 5;
																goto IL_0850;
																IL_0850:
																array2[num5] = array5[*(int*)(ptr2 + num3)];
																num = 11;
																goto IL_0871;
																IL_0871:
																num5++;
																goto IL_087f;
																IL_087f:
																ptr2 += 8;
																break;
																IL_0573:
																((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_05b2;
																IL_05b2:
																num5 -= 3;
																break;
																IL_0490:
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																IL_0355:
																if (12 >= b)
																{
																	goto IL_0360;
																}
																goto IL_03cf;
																IL_0360:
																if (12 > b)
																{
																	goto IL_036e;
																}
																goto IL_068c;
																IL_036e:
																if (10 >= b)
																{
																	goto IL_0379;
																}
																goto IL_03b1;
																IL_0379:
																if (10 > b)
																{
																	num = 88;
																	goto IL_0390;
																}
																goto IL_05c5;
																IL_040e:
																if (15 > b)
																{
																}
																goto IL_0444;
																IL_0390:
																if (9 >= b)
																{
																	goto IL_039e;
																}
																goto IL_0444;
																IL_039e:
																if (9 <= b)
																{
																	break;
																}
																goto IL_0444;
																IL_05c5:
																array[num5] = 0;
																goto IL_05d3;
																IL_05d3:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																goto IL_05f6;
																IL_05f6:
																array2[num5] = null;
																goto IL_0600;
																IL_0600:
																num5++;
																goto IL_060e;
																IL_060e:
																ptr2 += 8;
																break;
																IL_03b1:
																if (11 >= b)
																{
																	goto IL_03bf;
																}
																goto IL_0444;
																IL_03bf:
																if (11 > b)
																{
																	goto IL_0444;
																}
																goto IL_0621;
																IL_0621:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																goto IL_0665;
																IL_0665:
																array[num5 - 2] = 0;
																goto IL_0679;
																IL_0679:
																num5--;
																break;
																IL_068c:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																goto IL_06cc;
																IL_06cc:
																array[num5 - 2] = 0;
																goto IL_06e0;
																IL_06e0:
																num5--;
																num = 80;
																break;
																IL_03cf:
																if (14 >= b)
																{
																	goto IL_03da;
																}
																goto IL_0403;
																IL_03da:
																if (14 > b)
																{
																	goto IL_03e8;
																}
																goto IL_07c2;
																IL_03e8:
																if (13 >= b)
																{
																	goto IL_03f3;
																}
																goto IL_0444;
																IL_03f3:
																if (13 > b)
																{
																	goto IL_0444;
																}
																goto IL_06fc;
																IL_06fc:
																ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																goto IL_075e;
																IL_075e:
																num5 -= 2;
																break;
																IL_07c2:
																byte* num6 = ptr2;
																num4 = 1;
																ptr2 = num6 + -200;
																break;
																IL_0403:
																if (15 >= b)
																{
																	goto IL_040e;
																}
																goto IL_0444;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0929;
												IL_0929:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_088d:
												break;
											}
											continue;
											end_IL_08a0:
											break;
										}
										continue;
										end_IL_08aa:
										break;
									}
									continue;
									end_IL_08b5:
									break;
								}
								continue;
								end_IL_08c5:
								break;
							}
							continue;
							end_IL_08d5:
							break;
						}
						continue;
						end_IL_08ee:
						break;
					}
					continue;
					end_IL_08fe:
					break;
				}
				continue;
				end_IL_090e:
				break;
			}
		}
	}

	private unsafe void OnDisable()
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				IL_09ce:
				int num3 = num2 * 4;
				while (true)
				{
					IL_09be:
					byte[] array = new byte[3];
					while (true)
					{
						IL_09ae:
						object[] array2 = new object[3];
						while (true)
						{
							IL_099e:
							int[] array3 = new int[6];
							while (true)
							{
								IL_098e:
								long[] array4 = new long[3];
								while (true)
								{
									IL_097a:
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref setDeploymentIdInterface.MulOvfCountedMbcsString);
									num = 58;
									while (true)
									{
										IL_0970:
										byte* ptr2 = ptr;
										while (true)
										{
											IL_0965:
											num = 56;
											while (true)
											{
												if (num4 == 1)
												{
													return;
												}
												while (true)
												{
													IL_0330:
													byte b = *ptr2;
													while (true)
													{
														IL_0320:
														ptr2++;
														while (true)
														{
															IL_0310:
															if (b >= 1)
															{
																while (b <= 16)
																{
																	while (true)
																	{
																		IL_02f0:
																		if (8 < b)
																		{
																			while (true)
																			{
																				IL_02e3:
																				if (12 >= b)
																				{
																					while (12 > b)
																					{
																						while (true)
																						{
																							IL_02c3:
																							if (10 >= b)
																							{
																								while (true)
																								{
																									IL_02b0:
																									if (10 > b)
																									{
																										num = 160;
																										while (true)
																										{
																											if (num != 160)
																											{
																												if (num != 1141)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 71:
																													goto IL_02b0;
																												case 141:
																													goto IL_02c3;
																												case 18:
																													goto IL_02d3;
																												case 72:
																												case 110:
																													goto IL_02e3;
																												case 27:
																													goto IL_02f0;
																												case 37:
																													goto IL_0300;
																												case 102:
																													goto IL_0310;
																												case 5:
																													goto IL_0320;
																												case 17:
																												case 48:
																													goto IL_0330;
																												case 33:
																													goto IL_033b;
																												case 79:
																													goto IL_0349;
																												case 10:
																												case 108:
																													goto IL_0357;
																												case 99:
																													goto IL_036b;
																												case 51:
																												case 126:
																													goto IL_037e;
																												case 2:
																													goto IL_03e0;
																												case 128:
																												case 143:
																													goto IL_03f3;
																												case 123:
																												case 138:
																													goto IL_03fe;
																												case 64:
																													goto IL_040c;
																												case 26:
																												case 49:
																													goto IL_041a;
																												case 146:
																													goto IL_0436;
																												case 39:
																												case 105:
																													goto IL_044d;
																												case 21:
																													goto IL_0461;
																												case 152:
																													goto IL_0474;
																												case 34:
																													goto IL_047f;
																												case 45:
																												case 137:
																													goto IL_048d;
																												case 96:
																													goto IL_04a0;
																												case 14:
																													goto IL_04ae;
																												case 86:
																													goto IL_04cf;
																												case 16:
																													goto IL_04dd;
																												case 20:
																												case 142:
																													goto IL_04eb;
																												case 136:
																													goto IL_052b;
																												case 80:
																													goto IL_053f;
																												case 101:
																													goto IL_0552;
																												case 6:
																													goto IL_0560;
																												case 93:
																												case 133:
																													goto IL_056e;
																												case 115:
																													goto IL_0582;
																												case 40:
																													goto IL_05c1;
																												case 95:
																													goto IL_05d4;
																												case 38:
																												case 62:
																													goto IL_05e2;
																												case 119:
																												case 125:
																													goto IL_05f0;
																												case 19:
																												case 57:
																													goto IL_05fe;
																												case 68:
																													goto IL_060c;
																												case 23:
																												case 88:
																													goto IL_061a;
																												case 116:
																													goto IL_065a;
																												case 140:
																													goto IL_066e;
																												case 81:
																													goto IL_0681;
																												case 8:
																												case 70:
																													goto IL_068c;
																												case 47:
																													goto IL_06cc;
																												case 144:
																													goto IL_06e0;
																												case 91:
																													goto IL_06f3;
																												case 147:
																													goto IL_070a;
																												case 74:
																												case 124:
																													goto IL_0718;
																												case 132:
																													goto IL_0758;
																												case 103:
																													goto IL_076c;
																												case 24:
																													goto IL_077f;
																												case 69:
																												case 75:
																													goto IL_078d;
																												case 131:
																													goto IL_079b;
																												case 25:
																												case 50:
																													goto IL_07a6;
																												case 59:
																													goto IL_07e6;
																												case 61:
																													goto IL_07fa;
																												case 106:
																													goto IL_080d;
																												case 7:
																													goto IL_081b;
																												case 97:
																													goto IL_082e;
																												case 84:
																													goto IL_083c;
																												case 63:
																												case 66:
																													goto IL_084a;
																												case 109:
																													goto IL_0873;
																												case 151:
																													goto IL_0881;
																												case 92:
																												case 130:
																													goto IL_0894;
																												case 0:
																													goto IL_08a2;
																												case 107:
																													goto IL_08c5;
																												case 114:
																													goto IL_08cf;
																												case 41:
																													goto IL_08dd;
																												case 1:
																												case 87:
																													goto IL_08ed;
																												case 3:
																												case 9:
																												case 12:
																												case 22:
																												case 31:
																												case 36:
																												case 44:
																												case 46:
																												case 52:
																												case 53:
																												case 55:
																												case 60:
																												case 76:
																												case 78:
																												case 94:
																												case 100:
																												case 104:
																												case 111:
																												case 112:
																												case 117:
																												case 122:
																												case 129:
																												case 135:
																												case 148:
																												case 149:
																													goto end_IL_0300;
																												case 54:
																													goto IL_091f;
																												case 153:
																													goto IL_0936;
																												case 43:
																													goto IL_0944;
																												case 4:
																												case 11:
																												case 13:
																												case 35:
																												case 42:
																												case 56:
																												case 65:
																												case 67:
																												case 82:
																												case 83:
																												case 85:
																												case 89:
																												case 90:
																												case 118:
																												case 120:
																												case 127:
																												case 139:
																												case 145:
																													goto end_IL_02d3;
																												case 15:
																													goto IL_0965;
																												case 58:
																													goto IL_0970;
																												case 77:
																													goto IL_097a;
																												case 134:
																													goto IL_098e;
																												case 32:
																												case 73:
																													goto IL_099e;
																												case 98:
																													goto IL_09ae;
																												case 121:
																												case 150:
																													goto IL_09be;
																												case 29:
																													goto IL_09ce;
																												case 30:
																													goto end_IL_029d;
																												case 28:
																												case 113:
																													return;
																												}
																												continue;
																											}
																											goto IL_04cf;
																											IL_052b:
																											array[num5 - 2] = 0;
																											goto IL_053f;
																											IL_053f:
																											num5--;
																											goto end_IL_02d3;
																											IL_04cf:
																											if (9 < b)
																											{
																												goto end_IL_0300;
																											}
																											goto IL_04dd;
																											IL_04dd:
																											if (9 > b)
																											{
																												goto end_IL_0300;
																											}
																											goto IL_04eb;
																											IL_04eb:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_052b;
																											continue;
																											end_IL_029d:
																											break;
																										}
																										break;
																									}
																									goto IL_037e;
																									IL_037e:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_03e0;
																									IL_03e0:
																									num5 -= 2;
																									goto end_IL_02d3;
																								}
																								break;
																							}
																							goto IL_0552;
																							IL_05c1:
																							ptr2 += 8;
																							goto end_IL_02d3;
																							IL_0552:
																							if (11 < b)
																							{
																								goto end_IL_0300;
																							}
																							goto IL_0560;
																							IL_0560:
																							if (11 > b)
																							{
																								goto end_IL_0300;
																							}
																							goto IL_056e;
																							IL_056e:
																							array[num5 - 1] = 0;
																							goto IL_0582;
																							IL_0582:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)getSpecialKeygetAsyncWaitHandle[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																							goto IL_05c1;
																						}
																						goto end_IL_0952;
																						continue;
																						end_IL_02d3:
																						break;
																						IL_02d3:;
																					}
																					break;
																				}
																				goto IL_033b;
																				IL_0461:
																				num5--;
																				break;
																				IL_033b:
																				if (14 >= b)
																				{
																					goto IL_0349;
																				}
																				goto IL_03f3;
																				IL_0349:
																				if (14 <= b)
																				{
																					goto IL_0357;
																				}
																				goto IL_0474;
																				IL_0357:
																				methodInfo_0 = (MethodInfo)array2[num5 - 1];
																				goto IL_036b;
																				IL_036b:
																				num5--;
																				break;
																				IL_0474:
																				if (13 < b)
																				{
																					num = 104;
																					goto end_IL_0300;
																				}
																				goto IL_047f;
																				IL_047f:
																				if (13 > b)
																				{
																					goto end_IL_0300;
																				}
																				goto IL_048d;
																				IL_048d:
																				array2[num5] = null;
																				num = 96;
																				goto IL_04a0;
																				IL_04a0:
																				array[num5] = 5;
																				goto IL_04ae;
																				IL_04ae:
																				num5++;
																				break;
																				IL_044d:
																				methodInfo_1 = (MethodInfo)array2[num5 - 1];
																				goto IL_0461;
																				IL_03f3:
																				if (15 < b)
																				{
																					goto IL_03fe;
																				}
																				goto IL_0436;
																				IL_03fe:
																				if (16 < b)
																				{
																					goto end_IL_0300;
																				}
																				goto IL_040c;
																				IL_040c:
																				if (16 > b)
																				{
																					goto end_IL_0300;
																				}
																				goto IL_041a;
																				IL_041a:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0436:
																				if (15 > b)
																				{
																					goto end_IL_0300;
																				}
																				num = 105;
																				goto IL_044d;
																			}
																			break;
																		}
																		goto IL_05d4;
																		IL_08dd:
																		ptr2 += 8;
																		break;
																		IL_05d4:
																		if (8 > b)
																		{
																			goto IL_05e2;
																		}
																		goto IL_08ed;
																		IL_05e2:
																		if (4 < b)
																		{
																			goto IL_05f0;
																		}
																		goto IL_077f;
																		IL_05f0:
																		if (6 < b)
																		{
																			goto IL_05fe;
																		}
																		goto IL_0681;
																		IL_05fe:
																		if (7 < b)
																		{
																			goto end_IL_0300;
																		}
																		goto IL_060c;
																		IL_060c:
																		if (7 > b)
																		{
																			goto end_IL_0300;
																		}
																		goto IL_061a;
																		IL_061a:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_065a;
																		IL_065a:
																		array[num5 - 2] = 0;
																		goto IL_066e;
																		IL_066e:
																		num5--;
																		break;
																		IL_0681:
																		if (6 <= b)
																		{
																			goto IL_068c;
																		}
																		goto IL_06f3;
																		IL_068c:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_06cc;
																		IL_06cc:
																		array[num5 - 2] = 0;
																		goto IL_06e0;
																		IL_06e0:
																		num5--;
																		break;
																		IL_06f3:
																		if (5 < b)
																		{
																			goto end_IL_0300;
																		}
																		num = 147;
																		goto IL_070a;
																		IL_08ed:
																		num5--;
																		break;
																		IL_070a:
																		if (5 > b)
																		{
																			goto end_IL_0300;
																		}
																		goto IL_0718;
																		IL_0718:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0758;
																		IL_0758:
																		array[num5 - 2] = 0;
																		goto IL_076c;
																		IL_076c:
																		num5--;
																		break;
																		IL_077f:
																		if (4 > b)
																		{
																			goto IL_078d;
																		}
																		goto IL_0894;
																		IL_078d:
																		if (2 >= b)
																		{
																			goto IL_079b;
																		}
																		goto IL_082e;
																		IL_079b:
																		if (2 <= b)
																		{
																			goto IL_07a6;
																		}
																		goto IL_080d;
																		IL_07a6:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_07e6;
																		IL_07e6:
																		array[num5 - 2] = 0;
																		goto IL_07fa;
																		IL_07fa:
																		num5--;
																		break;
																		IL_080d:
																		if (1 < b)
																		{
																			goto end_IL_0300;
																		}
																		goto IL_081b;
																		IL_081b:
																		if (1 > b)
																		{
																		}
																		goto end_IL_0300;
																		IL_082e:
																		if (3 < b)
																		{
																			goto end_IL_0300;
																		}
																		goto IL_083c;
																		IL_083c:
																		if (3 > b)
																		{
																			goto end_IL_0300;
																		}
																		goto IL_084a;
																		IL_084a:
																		ref int reference = ref array3[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																		goto IL_0873;
																		IL_0873:
																		ptr2 += 8;
																		goto IL_0881;
																		IL_0881:
																		num5--;
																		break;
																		IL_0894:
																		array[num5] = 0;
																		goto IL_08a2;
																		IL_08a2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_08c5;
																		IL_08c5:
																		array2[num5] = null;
																		goto IL_08cf;
																		IL_08cf:
																		num5++;
																		goto IL_08dd;
																	}
																	goto end_IL_0310;
																	continue;
																	end_IL_0300:
																	break;
																	IL_0300:;
																}
															}
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
															num = 54;
															goto IL_091f;
															IL_0944:
															ptr2 += 8;
															break;
															IL_0936:
															num5++;
															goto IL_0944;
															IL_091f:
															array[num5] = 0;
															num = 153;
															goto IL_0936;
															continue;
															end_IL_0310:
															break;
														}
														break;
													}
													break;
												}
												continue;
												end_IL_0952:
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2)
	{
		int num = 105;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						num = 75;
						while (true)
						{
							int[] array3 = new int[4];
							num = 117;
							while (true)
							{
								long[] array4 = new long[4];
								num = 63;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SetRootObjectMyMusic.GetMemberContinuationTaskFromTask);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												IL_0814:
												if (num4 != 1)
												{
													goto IL_000e;
												}
												num = 145;
												while (true)
												{
													if (num != 145)
													{
														if (num != 1126)
														{
															break;
														}
														switch (num)
														{
														case 88:
														case 109:
															break;
														case 85:
															goto IL_0017;
														case 118:
															goto IL_0025;
														case 132:
															goto IL_0033;
														case 87:
															goto IL_0041;
														case 121:
															goto IL_004f;
														case 32:
														case 84:
															goto IL_005d;
														case 13:
															goto IL_006b;
														case 115:
															goto IL_0079;
														case 30:
														case 33:
															goto IL_0084;
														case 73:
															goto IL_0092;
														case 17:
															goto IL_00b5;
														case 79:
															goto IL_00bf;
														case 22:
															goto IL_00cd;
														case 50:
														case 133:
															goto IL_00e0;
														case 19:
															goto IL_00ee;
														case 15:
														case 129:
															goto IL_0101;
														case 60:
															goto IL_010f;
														case 54:
														case 74:
															goto IL_011d;
														case 66:
															goto IL_015d;
														case 7:
															goto IL_0171;
														case 128:
															goto IL_0196;
														case 46:
														case 64:
															goto IL_01a1;
														case 130:
															goto IL_01b9;
														case 11:
															goto IL_01c4;
														case 62:
															goto IL_01d2;
														case 100:
														case 113:
															goto IL_01e0;
														case 52:
															goto IL_0209;
														case 136:
															goto IL_0217;
														case 2:
															goto IL_0233;
														case 41:
														case 114:
															goto IL_0241;
														case 16:
															goto IL_025a;
														case 34:
															goto IL_0268;
														case 138:
															goto IL_0276;
														case 21:
														case 83:
															goto IL_0289;
														case 26:
															goto IL_02c9;
														case 4:
															goto IL_02dd;
														case 116:
															goto IL_02f0;
														case 70:
															goto IL_02fe;
														case 126:
															goto IL_030c;
														case 38:
															goto IL_031a;
														case 57:
														case 65:
															goto IL_0325;
														case 81:
															goto IL_0387;
														case 29:
															goto IL_039a;
														case 45:
															goto IL_03a8;
														case 89:
														case 131:
															goto IL_03b6;
														case 24:
															goto IL_03d9;
														case 124:
															goto IL_03e7;
														case 8:
															goto IL_03f5;
														case 10:
															goto IL_0408;
														case 103:
															goto IL_0416;
														case 28:
														case 68:
															goto IL_0424;
														case 93:
															goto IL_0464;
														case 110:
															goto IL_0478;
														case 49:
														case 106:
															goto IL_048b;
														case 42:
															goto IL_049f;
														case 14:
															goto IL_04f3;
														case 102:
															goto IL_0501;
														case 58:
														case 94:
															goto IL_051d;
														case 25:
															goto IL_0528;
														case 27:
														case 123:
															goto IL_0533;
														case 86:
															goto IL_053e;
														case 91:
														case 107:
															goto IL_0549;
														case 71:
														case 72:
															goto IL_055c;
														case 47:
															goto IL_0578;
														case 90:
															goto IL_0583;
														case 3:
														case 5:
														case 6:
														case 9:
														case 12:
														case 20:
														case 31:
														case 36:
														case 39:
														case 48:
														case 51:
														case 53:
														case 55:
														case 56:
														case 61:
														case 69:
														case 77:
														case 78:
														case 92:
														case 96:
														case 99:
														case 108:
														case 119:
														case 120:
														case 127:
														case 134:
															goto end_IL_0801;
														default:
															continue;
														case 0:
														case 1:
														case 18:
														case 37:
														case 44:
														case 59:
														case 67:
														case 80:
														case 95:
														case 98:
														case 101:
														case 111:
														case 112:
														case 122:
														case 125:
														case 135:
														case 137:
															goto IL_0814;
														case 97:
															goto end_IL_0814;
														case 82:
															goto end_IL_0827;
														case 63:
															goto end_IL_0831;
														case 117:
															goto end_IL_083c;
														case 35:
														case 75:
															goto end_IL_0851;
														case 76:
															goto end_IL_086a;
														case 40:
														case 43:
															goto end_IL_0883;
														case 104:
															goto end_IL_089c;
														case 105:
															goto end_IL_08ac;
														case 23:
															goto IL_08c7;
														}
														goto IL_000e;
													}
													goto IL_08c7;
													IL_08c7:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0801:
													break;
												}
												goto IL_0599;
												IL_0549:
												num5--;
												continue;
												IL_055c:
												byte* num6 = ptr2;
												num4 = 1;
												ptr2 = num6 + -200;
												continue;
												IL_000e:
												b = *ptr2;
												goto IL_0017;
												IL_0017:
												ptr2++;
												goto IL_0025;
												IL_0025:
												if (b >= 1)
												{
													goto IL_0033;
												}
												num = 77;
												goto IL_0599;
												IL_0033:
												if (b <= 14)
												{
													goto IL_0041;
												}
												goto IL_0599;
												IL_0041:
												if (7 >= b)
												{
													goto IL_004f;
												}
												goto IL_02f0;
												IL_004f:
												if (7 > b)
												{
													goto IL_005d;
												}
												goto IL_0289;
												IL_005d:
												if (3 < b)
												{
													goto IL_006b;
												}
												num = 128;
												goto IL_0196;
												IL_006b:
												if (5 >= b)
												{
													goto IL_0079;
												}
												goto IL_0101;
												IL_0079:
												if (5 <= b)
												{
													goto IL_0084;
												}
												goto IL_00e0;
												IL_0084:
												array[num5] = 0;
												goto IL_0092;
												IL_0092:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_00b5;
												IL_00b5:
												array2[num5] = null;
												goto IL_00bf;
												IL_00bf:
												num5++;
												goto IL_00cd;
												IL_00cd:
												ptr2 += 8;
												continue;
												IL_00e0:
												if (4 >= b)
												{
													goto IL_00ee;
												}
												goto IL_0599;
												IL_00ee:
												if (4 <= b)
												{
													continue;
												}
												goto IL_0599;
												IL_0101:
												if (6 >= b)
												{
													goto IL_010f;
												}
												goto IL_0599;
												IL_010f:
												if (6 <= b)
												{
													goto IL_011d;
												}
												goto IL_0599;
												IL_011d:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_015d;
												IL_015d:
												array[num5 - 2] = 0;
												goto IL_0171;
												IL_0171:
												num5--;
												num = 122;
												continue;
												IL_0583:
												if (14 > b)
												{
												}
												goto IL_0599;
												IL_0196:
												if (3 <= b)
												{
													goto IL_01a1;
												}
												goto IL_01b9;
												IL_01a1:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_01b9:
												if (1 < b)
												{
													goto IL_01c4;
												}
												num = 2;
												goto IL_0233;
												IL_01c4:
												if (2 >= b)
												{
													goto IL_01d2;
												}
												goto IL_0599;
												IL_01d2:
												if (2 <= b)
												{
													goto IL_01e0;
												}
												goto IL_0599;
												IL_01e0:
												ref int reference = ref array3[*(int*)(ptr2 + num3)];
												reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0209;
												IL_0209:
												ptr2 += 8;
												goto IL_0217;
												IL_0217:
												num5--;
												continue;
												IL_0578:
												if (14 >= b)
												{
													goto IL_0583;
												}
												goto IL_0599;
												IL_0233:
												if (1 <= b)
												{
													goto IL_0241;
												}
												goto IL_0599;
												IL_0241:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
												goto IL_025a;
												IL_025a:
												array[num5] = 0;
												goto IL_0268;
												IL_0268:
												num5++;
												goto IL_0276;
												IL_0276:
												ptr2 += 8;
												continue;
												IL_0289:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_02c9;
												IL_02c9:
												array[num5 - 2] = 0;
												goto IL_02dd;
												IL_02dd:
												num5--;
												continue;
												IL_02f0:
												if (11 >= b)
												{
													goto IL_02fe;
												}
												num = 58;
												goto IL_051d;
												IL_02fe:
												if (11 > b)
												{
													goto IL_030c;
												}
												goto IL_048b;
												IL_030c:
												if (9 >= b)
												{
													goto IL_031a;
												}
												goto IL_0408;
												IL_031a:
												if (9 <= b)
												{
													goto IL_0325;
												}
												goto IL_039a;
												IL_0325:
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												goto IL_0387;
												IL_0387:
												num5 -= 2;
												continue;
												IL_039a:
												if (8 >= b)
												{
													goto IL_03a8;
												}
												goto IL_0599;
												IL_03a8:
												if (8 <= b)
												{
													goto IL_03b6;
												}
												goto IL_0599;
												IL_03b6:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
												goto IL_03d9;
												IL_03d9:
												array[num5] = 0;
												goto IL_03e7;
												IL_03e7:
												num5++;
												goto IL_03f5;
												IL_03f5:
												ptr2 += 8;
												continue;
												IL_0408:
												if (10 >= b)
												{
													goto IL_0416;
												}
												goto IL_0599;
												IL_0416:
												if (10 <= b)
												{
													goto IL_0424;
												}
												goto IL_0599;
												IL_0424:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												goto IL_0464;
												IL_0464:
												array[num5 - 2] = 0;
												goto IL_0478;
												IL_0478:
												num5--;
												continue;
												IL_048b:
												array[num5 - 2] = 0;
												goto IL_049f;
												IL_049f:
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)GetFileSystemEntriesPreAllocatedOverlapped[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
												goto IL_04f3;
												IL_04f3:
												num5--;
												goto IL_0501;
												IL_0501:
												ptr2 += 8;
												continue;
												IL_0599:
												ptr2 = ptr + *(int*)(ptr2 + num3);
												continue;
												IL_051d:
												if (13 >= b)
												{
													goto IL_0528;
												}
												goto IL_0578;
												IL_0528:
												if (13 > b)
												{
													goto IL_0533;
												}
												goto IL_055c;
												IL_0533:
												if (12 >= b)
												{
													goto IL_053e;
												}
												goto IL_0599;
												IL_053e:
												if (12 <= b)
												{
													goto IL_0549;
												}
												goto IL_0599;
												continue;
												end_IL_0814:
												break;
											}
											continue;
											end_IL_0827:
											break;
										}
										continue;
										end_IL_0831:
										break;
									}
									continue;
									end_IL_083c:
									break;
								}
								continue;
								end_IL_0851:
								break;
							}
							continue;
							end_IL_086a:
							break;
						}
						continue;
						end_IL_0883:
						break;
					}
					continue;
					end_IL_089c:
					break;
				}
				continue;
				end_IL_08ac:
				break;
			}
		}
	}

	public Class126()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_5(int int_2, int int_3)
	{
		int num = 66;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 115;
				while (true)
				{
					num = 59;
					while (true)
					{
						byte[] array = new byte[4];
						while (true)
						{
							object[] array2 = new object[4];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									long[] array4 = new long[4];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											array3[1] = int_3;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCurrentSizeDefineGlobalVariable.MethodAttributesGrantedSet);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																IL_0361:
																byte b = *ptr2;
																while (true)
																{
																	IL_0351:
																	ptr2++;
																	while (true)
																	{
																		IL_0341:
																		if (b >= 1)
																		{
																			while (b <= 12)
																			{
																				while (true)
																				{
																					IL_0321:
																					if (6 < b)
																					{
																						while (true)
																						{
																							IL_0314:
																							if (9 < b)
																							{
																								while (true)
																								{
																									IL_0304:
																									if (11 >= b)
																									{
																										while (true)
																										{
																											IL_02f4:
																											if (11 > b)
																											{
																												while (10 >= b)
																												{
																													while (10 <= b)
																													{
																														while (true)
																														{
																															IL_02b5:
																															array[num5 - 2] = 0;
																															num = 50;
																															while (true)
																															{
																																IL_025f:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)BleIServerChannelSinkStack[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																																while (true)
																																{
																																	IL_024f:
																																	num5--;
																																	while (true)
																																	{
																																		IL_0236:
																																		ptr2 += 8;
																																		num = 133;
																																		while (num != 133)
																																		{
																																			if (num != 1114)
																																			{
																																				goto IL_0606;
																																			}
																																			switch (num)
																																			{
																																			case 44:
																																				goto IL_0236;
																																			case 60:
																																				goto IL_024f;
																																			case 50:
																																				goto IL_025f;
																																			case 38:
																																			case 62:
																																				goto IL_02b5;
																																			case 15:
																																				goto IL_02d4;
																																			case 1:
																																			case 27:
																																				goto IL_02e4;
																																			case 86:
																																				goto IL_02f4;
																																			case 42:
																																				goto IL_0304;
																																			case 37:
																																			case 104:
																																				goto IL_0314;
																																			case 72:
																																				goto IL_0321;
																																			case 67:
																																				goto IL_0331;
																																			case 54:
																																				goto IL_0341;
																																			case 116:
																																				goto IL_0351;
																																			case 40:
																																			case 81:
																																				goto IL_0361;
																																			case 107:
																																				goto IL_036c;
																																			case 102:
																																				goto IL_0377;
																																			case 45:
																																				goto IL_0382;
																																			case 51:
																																				goto IL_0390;
																																			case 10:
																																			case 17:
																																				goto IL_039e;
																																			case 46:
																																				goto IL_03b7;
																																			case 99:
																																				goto IL_03ca;
																																			case 48:
																																			case 98:
																																				goto IL_03e3;
																																			case 30:
																																			case 117:
																																				goto IL_03f3;
																																			case 83:
																																				goto IL_0433;
																																			case 8:
																																				goto IL_0447;
																																			case 118:
																																				goto IL_045a;
																																			case 3:
																																				goto IL_047d;
																																			case 26:
																																				goto IL_0487;
																																			case 120:
																																				goto IL_049e;
																																			case 122:
																																				goto IL_04ba;
																																			case 68:
																																			case 95:
																																				goto IL_04c8;
																																			case 70:
																																				goto IL_04d6;
																																			case 14:
																																			case 20:
																																				goto IL_04e1;
																																			case 29:
																																				goto IL_0521;
																																			case 97:
																																				goto IL_0535;
																																			case 7:
																																			case 84:
																																				goto IL_0548;
																																			case 23:
																																			case 90:
																																				goto IL_0556;
																																			case 53:
																																				goto IL_0564;
																																			case 63:
																																			case 108:
																																				goto IL_0572;
																																			case 35:
																																				goto IL_05e0;
																																			case 21:
																																				goto IL_05f3;
																																			case 82:
																																			case 100:
																																				goto IL_0606;
																																			case 18:
																																				goto IL_0611;
																																			case 33:
																																			case 89:
																																				goto IL_061f;
																																			case 36:
																																				goto IL_0648;
																																			case 101:
																																				goto IL_0656;
																																			case 57:
																																				goto IL_0672;
																																			case 88:
																																				goto IL_0680;
																																			case 5:
																																			case 41:
																																				goto IL_068e;
																																			case 126:
																																				goto IL_06a6;
																																			case 61:
																																				goto IL_06bd;
																																			case 28:
																																			case 103:
																																				goto IL_06d9;
																																			case 64:
																																			case 119:
																																				goto IL_06e9;
																																			case 6:
																																				goto IL_06f4;
																																			case 43:
																																			case 87:
																																				goto IL_06ff;
																																			case 0:
																																			case 4:
																																			case 9:
																																			case 24:
																																			case 25:
																																			case 31:
																																			case 32:
																																			case 34:
																																			case 39:
																																			case 47:
																																			case 49:
																																			case 58:
																																			case 69:
																																			case 71:
																																			case 73:
																																			case 74:
																																			case 75:
																																			case 106:
																																			case 110:
																																			case 111:
																																			case 112:
																																			case 124:
																																			case 125:
																																				goto end_IL_02d4;
																																			case 77:
																																				goto IL_073b;
																																			case 78:
																																				goto IL_0749;
																																			case 93:
																																				goto IL_0757;
																																			case 13:
																																			case 22:
																																			case 52:
																																			case 55:
																																			case 56:
																																			case 85:
																																			case 91:
																																			case 92:
																																			case 96:
																																			case 109:
																																			case 113:
																																			case 114:
																																			case 121:
																																			case 123:
																																				goto end_IL_0223;
																																			case 2:
																																				goto end_IL_0765;
																																			case 94:
																																				goto end_IL_0778;
																																			case 19:
																																				goto end_IL_0782;
																																			case 16:
																																				goto end_IL_078d;
																																			case 79:
																																				goto end_IL_07a2;
																																			case 76:
																																			case 105:
																																				goto end_IL_07b7;
																																			case 11:
																																				goto end_IL_07c7;
																																			case 59:
																																				goto end_IL_07d7;
																																			case 115:
																																				goto end_IL_07e7;
																																			case 65:
																																				goto end_IL_07f7;
																																			case 66:
																																				goto end_IL_0802;
																																			case 12:
																																			case 80:
																																				goto IL_0826;
																																			}
																																			continue;
																																			end_IL_0223:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																														}
																														goto end_IL_0341;
																														continue;
																														end_IL_02d4:
																														break;
																														IL_02d4:;
																													}
																													break;
																													IL_02e4:;
																												}
																												break;
																											}
																											goto IL_06d9;
																											IL_06d9:
																											num5--;
																											goto end_IL_0341;
																										}
																										break;
																									}
																									goto IL_06e9;
																									IL_06ff:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_0341;
																									IL_06e9:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_06f4;
																									IL_06f4:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_06ff;
																								}
																								break;
																							}
																							goto IL_036c;
																							IL_0433:
																							array[num5 - 2] = 0;
																							goto IL_0447;
																							IL_036c:
																							if (9 > b)
																							{
																								goto IL_0377;
																							}
																							goto IL_03f3;
																							IL_0377:
																							if (7 < b)
																							{
																								goto IL_0382;
																							}
																							goto IL_03ca;
																							IL_0382:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_0390;
																							IL_0390:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_039e;
																							IL_039e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_03b7;
																							IL_03b7:
																							array[num5] = 0;
																							goto IL_06a6;
																							IL_06a6:
																							num5++;
																							num = 61;
																							goto IL_06bd;
																							IL_06bd:
																							ptr2 += 8;
																							num = 22;
																							goto end_IL_0341;
																							IL_03ca:
																							if (7 > b)
																							{
																								num = 71;
																								break;
																							}
																							goto IL_03e3;
																							IL_0447:
																							num5--;
																							goto end_IL_0341;
																							IL_03e3:
																							array[num5] = 0;
																							goto IL_045a;
																							IL_045a:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_047d;
																							IL_047d:
																							array2[num5] = null;
																							goto IL_0487;
																							IL_0487:
																							num5++;
																							num = 120;
																							goto IL_049e;
																							IL_049e:
																							ptr2 += 8;
																							num = 91;
																							goto end_IL_0341;
																							IL_03f3:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0433;
																						}
																						break;
																					}
																					goto IL_04ba;
																					IL_068e:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0341;
																					IL_04ba:
																					if (6 <= b)
																					{
																						goto end_IL_0341;
																					}
																					goto IL_04c8;
																					IL_04c8:
																					if (3 >= b)
																					{
																						goto IL_04d6;
																					}
																					goto IL_0606;
																					IL_04d6:
																					if (3 <= b)
																					{
																						goto IL_04e1;
																					}
																					goto IL_0548;
																					IL_04e1:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0521;
																					IL_0521:
																					array[num5 - 2] = 0;
																					goto IL_0535;
																					IL_0535:
																					num5--;
																					goto end_IL_0341;
																					IL_0548:
																					if (1 < b)
																					{
																						goto IL_0556;
																					}
																					goto IL_05f3;
																					IL_0556:
																					if (2 < b)
																					{
																						break;
																					}
																					goto IL_0564;
																					IL_0564:
																					if (2 > b)
																					{
																						break;
																					}
																					goto IL_0572;
																					IL_0572:
																					ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_05e0;
																					IL_05e0:
																					num5 -= 2;
																					goto end_IL_0341;
																					IL_05f3:
																					if (1 <= b)
																					{
																					}
																					break;
																					IL_0606:
																					if (4 >= b)
																					{
																						goto IL_0611;
																					}
																					goto IL_0672;
																					IL_0611:
																					if (4 > b)
																					{
																						break;
																					}
																					goto IL_061f;
																					IL_061f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0648;
																					IL_0648:
																					ptr2 += 8;
																					goto IL_0656;
																					IL_0656:
																					num5--;
																					num = 92;
																					goto end_IL_0341;
																					IL_0672:
																					if (5 < b)
																					{
																						break;
																					}
																					goto IL_0680;
																					IL_0680:
																					if (5 > b)
																					{
																						break;
																					}
																					goto IL_068e;
																				}
																				break;
																				IL_0331:;
																			}
																		}
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		goto IL_073b;
																		IL_0757:
																		ptr2 += 8;
																		break;
																		IL_0749:
																		num5++;
																		goto IL_0757;
																		IL_073b:
																		array[num5] = 0;
																		goto IL_0749;
																		continue;
																		end_IL_0341:
																		break;
																	}
																	break;
																}
																break;
															}
															continue;
														}
														goto IL_0826;
														IL_0826:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0765:
														break;
													}
													continue;
													end_IL_0778:
													break;
												}
												continue;
												end_IL_0782:
												break;
											}
											continue;
											end_IL_078d:
											break;
										}
										continue;
										end_IL_07a2:
										break;
									}
									continue;
									end_IL_07b7:
									break;
								}
								continue;
								end_IL_07c7:
								break;
							}
							continue;
							end_IL_07d7:
							break;
						}
						continue;
						end_IL_07e7:
						break;
					}
					continue;
					end_IL_07f7:
					break;
				}
				continue;
				end_IL_0802:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_2, int int_3)
	{
		int num = 59;
		long[] array4 = default(long[]);
		int num4 = default(int);
		byte* ptr = default(byte*);
		byte* ptr2 = default(byte*);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						num = 68;
						while (true)
						{
							int[] array3 = new int[3];
							num = 97;
							while (true)
							{
								if (num != 97)
								{
									if (num != 1078)
									{
										goto IL_0295;
									}
									switch (num)
									{
									case 68:
									case 71:
										goto end_IL_0193;
									case 38:
										goto end_IL_01a3;
									case 8:
									case 36:
										goto end_IL_01bc;
									case 58:
										goto end_IL_01d5;
									case 59:
										goto end_IL_01e5;
									case 73:
										goto IL_020e;
									case 21:
										goto IL_0221;
									case 23:
										goto IL_0234;
									case 90:
										goto IL_023d;
									case 4:
									case 18:
									case 34:
									case 44:
									case 51:
									case 52:
									case 60:
									case 64:
									case 70:
									case 78:
									case 85:
										goto IL_0245;
									case 67:
										goto IL_0255;
									case 61:
										goto IL_025e;
									case 46:
										goto IL_0267;
									case 66:
										goto IL_027e;
									case 62:
										goto IL_0295;
									case 79:
										goto IL_02a3;
									case 0:
									case 7:
										goto IL_02b1;
									case 26:
										goto IL_02bc;
									case 37:
									case 88:
										goto IL_02ca;
									case 5:
										goto IL_02d8;
									case 75:
									case 82:
										goto IL_02e6;
									case 16:
									case 20:
										goto IL_0307;
									case 47:
										goto IL_0312;
									case 6:
									case 86:
										goto IL_0320;
									case 31:
										goto IL_032e;
									case 56:
										goto IL_0351;
									case 43:
										goto IL_035b;
									case 81:
										goto IL_0369;
									case 41:
										goto IL_037c;
									case 89:
										goto IL_038a;
									case 13:
									case 15:
										goto IL_0398;
									case 40:
										goto IL_03b4;
									case 11:
									case 50:
										goto IL_03c2;
									case 53:
										goto IL_03d0;
									case 63:
									case 74:
										goto IL_03db;
									case 17:
										goto IL_03e9;
									case 49:
									case 77:
										goto IL_03fc;
									case 48:
										goto IL_046a;
									case 45:
										goto IL_0486;
									case 42:
										goto IL_0494;
									case 12:
									case 35:
										goto IL_04a2;
									case 55:
										goto IL_04eb;
									case 87:
										goto IL_04ff;
									case 9:
									case 72:
										goto IL_0512;
									case 10:
										goto IL_053b;
									case 28:
										goto IL_0549;
									case 29:
										goto IL_055c;
									case 54:
										goto IL_056a;
									case 3:
										goto IL_0581;
									case 1:
									case 2:
									case 14:
									case 22:
									case 25:
									case 27:
									case 30:
									case 32:
									case 33:
									case 39:
									case 57:
									case 65:
									case 69:
									case 76:
									case 80:
									case 83:
									case 84:
										goto IL_0594;
									case 19:
									case 24:
										goto IL_05b9;
									}
									continue;
								}
								array4 = new long[2];
								goto IL_020e;
								IL_0549:
								num4--;
								goto IL_0245;
								IL_055c:
								array[num4] = 0;
								goto IL_056a;
								IL_0594:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_055c;
								IL_020e:
								array3[0] = int_2;
								goto IL_0221;
								IL_0221:
								array3[1] = int_3;
								goto IL_0234;
								IL_0234:
								ptr2 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref DefineLabelgetWritableType.defineLabelgetWritableType_0);
								goto IL_023d;
								IL_023d:
								ptr = ptr2;
								goto IL_0245;
								IL_0245:
								if (num5 != 1)
								{
									goto IL_0255;
								}
								goto IL_05b9;
								IL_05b9:
								return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								IL_0255:
								num = 61;
								goto IL_025e;
								IL_025e:
								b = *ptr;
								goto IL_0267;
								IL_0267:
								ptr++;
								num = 66;
								goto IL_027e;
								IL_027e:
								if (b >= 1)
								{
									num = 62;
									goto IL_0295;
								}
								goto IL_0594;
								IL_056a:
								num4++;
								num = 3;
								goto IL_0581;
								IL_0295:
								if (b <= 8)
								{
									goto IL_02a3;
								}
								goto IL_0594;
								IL_02a3:
								if (4 < b)
								{
									goto IL_02b1;
								}
								goto IL_03b4;
								IL_02b1:
								if (6 >= b)
								{
									goto IL_02bc;
								}
								num = 16;
								goto IL_0307;
								IL_02bc:
								if (6 <= b)
								{
									goto IL_0245;
								}
								goto IL_02ca;
								IL_02ca:
								if (5 >= b)
								{
									goto IL_02d8;
								}
								goto IL_0594;
								IL_02d8:
								if (5 <= b)
								{
									goto IL_02e6;
								}
								goto IL_0594;
								IL_02e6:
								ptr = ptr2 + *(int*)(ptr + num3);
								goto IL_0245;
								IL_0581:
								ptr += 8;
								goto IL_0245;
								IL_0307:
								if (7 >= b)
								{
									goto IL_0312;
								}
								goto IL_037c;
								IL_0312:
								if (7 <= b)
								{
									goto IL_0320;
								}
								goto IL_0594;
								IL_0320:
								array[num4] = 0;
								goto IL_032e;
								IL_032e:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr + num3)];
								goto IL_0351;
								IL_0351:
								array2[num4] = null;
								goto IL_035b;
								IL_035b:
								num4++;
								goto IL_0369;
								IL_0369:
								ptr += 8;
								goto IL_0245;
								IL_037c:
								if (8 >= b)
								{
									goto IL_038a;
								}
								goto IL_0594;
								IL_038a:
								if (8 <= b)
								{
									goto IL_0398;
								}
								goto IL_0594;
								IL_0398:
								byte* num6 = ptr;
								num5 = 1;
								ptr = num6 + -200;
								goto IL_0245;
								IL_03b4:
								if (4 > b)
								{
									goto IL_03c2;
								}
								goto IL_0512;
								IL_03c2:
								if (2 >= b)
								{
									goto IL_03d0;
								}
								goto IL_0486;
								IL_03d0:
								if (2 > b)
								{
									goto IL_03db;
								}
								goto IL_03fc;
								IL_03db:
								if (1 >= b)
								{
									goto IL_03e9;
								}
								goto IL_0594;
								IL_03e9:
								if (1 > b)
								{
								}
								goto IL_0594;
								IL_03fc:
								ptr = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr + num3) - *(int*)(ptr + 8 + num3)) + *(int*)(ptr + 8 + num3) + ptr2;
								goto IL_046a;
								IL_046a:
								num4 -= 2;
								num = 70;
								goto IL_0245;
								IL_0486:
								if (3 >= b)
								{
									goto IL_0494;
								}
								goto IL_0594;
								IL_0494:
								if (3 <= b)
								{
									goto IL_04a2;
								}
								goto IL_0594;
								IL_04a2:
								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								num = 55;
								goto IL_04eb;
								IL_04eb:
								array[num4 - 2] = 0;
								goto IL_04ff;
								IL_04ff:
								num4--;
								goto IL_0245;
								IL_0512:
								ref int reference = ref array3[*(int*)(ptr + num3)];
								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
								goto IL_053b;
								IL_053b:
								ptr += 8;
								goto IL_0549;
								continue;
								end_IL_0193:
								break;
							}
							continue;
							end_IL_01a3:
							break;
						}
						continue;
						end_IL_01bc:
						break;
					}
					continue;
					end_IL_01d5:
					break;
				}
				continue;
				end_IL_01e5:
				break;
			}
		}
	}

	private unsafe void Update()
	{
		int num = 5;
		int num4 = default(int);
		int num5 = default(int);
		int num6 = default(int);
		int num7 = default(int);
		int num8 = default(int);
		int num9 = default(int);
		int num10 = default(int);
		object obj = default(object);
		string text = default(string);
		string text2 = default(string);
		string text3 = default(string);
		string text4 = default(string);
		string text5 = default(string);
		string text6 = default(string);
		string text7 = default(string);
		string text8 = default(string);
		string text9 = default(string);
		string text10 = default(string);
		string text11 = default(string);
		string text12 = default(string);
		string text13 = default(string);
		string text14 = default(string);
		string text15 = default(string);
		string text16 = default(string);
		string text17 = default(string);
		string text18 = default(string);
		string text19 = default(string);
		string text20 = default(string);
		string text21 = default(string);
		string text22 = default(string);
		string text23 = default(string);
		string text24 = default(string);
		string text25 = default(string);
		string text26 = default(string);
		string text27 = default(string);
		string text28 = default(string);
		string text29 = default(string);
		string text30 = default(string);
		string text31 = default(string);
		string text32 = default(string);
		string text33 = default(string);
		string text34 = default(string);
		string text35 = default(string);
		string text36 = default(string);
		string text37 = default(string);
		string text38 = default(string);
		string text39 = default(string);
		string text40 = default(string);
		GameObject gameObject = default(GameObject);
		GameObject gameObject2 = default(GameObject);
		RaycastHit raycastHit = default(RaycastHit);
		Component[] array = default(Component[]);
		int num11 = default(int);
		Component component = default(Component);
		Type type = default(Type);
		string text41 = default(string);
		while (true)
		{
			int num2 = 0;
			while (true)
			{
				int num3 = 0;
				while (true)
				{
					IL_0051:
					num3 = 0;
					num = 14;
					while (true)
					{
						if (num != 14)
						{
							if (num != 995)
							{
								break;
							}
							switch (num)
							{
							case 3:
								goto IL_0051;
							case 4:
								goto end_IL_0041;
							case 5:
								goto end_IL_005f;
							case 1:
								goto IL_0069;
							case 2:
								goto IL_00ea;
							case 7:
								goto IL_00f3;
							case 0:
							case 6:
								return;
							}
							continue;
						}
						goto IL_00ea;
						IL_00f3:
						num3 = 0;
						return;
						IL_0069:
						((delegate*<ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref int, ref object, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref string, ref GameObject, ref GameObject, ref RaycastHit, ref Component[], ref int, ref Component, ref Type, ref string, void>)EnterprisePolicyLevelLPUTFStr[num2])(ref num2, ref num3, ref num4, ref num5, ref num6, ref num7, ref num8, ref num9, ref num10, ref obj, ref text, ref text2, ref text3, ref text4, ref text5, ref text6, ref text7, ref text8, ref text9, ref text10, ref text11, ref text12, ref text13, ref text14, ref text15, ref text16, ref text17, ref text18, ref text19, ref text20, ref text21, ref text22, ref text23, ref text24, ref text25, ref text26, ref text27, ref text28, ref text29, ref text30, ref text31, ref text32, ref text33, ref text34, ref text35, ref text36, ref text37, ref text38, ref text39, ref text40, ref gameObject, ref gameObject2, ref raycastHit, ref array, ref num11, ref component, ref type, ref text41);
						goto IL_00ea;
						IL_00ea:
						if (num3 != 41)
						{
							goto IL_0069;
						}
						goto IL_00f3;
						continue;
						end_IL_0041:
						break;
					}
					break;
				}
				continue;
				end_IL_005f:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 148;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref TokenAppContainerSidCustomFormatClass.CreatorGroupServerSidLogSwitch);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0334:
														byte b = *ptr2;
														while (true)
														{
															IL_0324:
															ptr2++;
															while (true)
															{
																IL_0314:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_02f4:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_02d4:
																						if (4 < b)
																						{
																							num = 169;
																							while (true)
																							{
																								if (num != 169)
																								{
																									if (num != 1150)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 10:
																										goto IL_02d4;
																									case 134:
																										goto IL_02e4;
																									case 57:
																										goto IL_02f4;
																									case 156:
																										goto IL_0304;
																									case 106:
																										goto IL_0314;
																									case 101:
																										goto IL_0324;
																									case 55:
																									case 75:
																										goto end_IL_02c1;
																									case 51:
																										goto IL_033f;
																									case 25:
																										goto IL_034d;
																									case 7:
																										goto IL_0358;
																									case 40:
																										goto IL_0365;
																									case 52:
																										goto IL_0375;
																									case 54:
																										goto IL_0388;
																									case 22:
																									case 46:
																										goto IL_0396;
																									case 18:
																										goto IL_03bf;
																									case 47:
																									case 112:
																										goto IL_03d8;
																									case 6:
																									case 152:
																										goto IL_041d;
																									case 144:
																										goto IL_043b;
																									case 154:
																										goto IL_044e;
																									case 56:
																									case 60:
																										goto IL_045c;
																									case 32:
																										goto IL_0475;
																									case 80:
																										goto IL_0483;
																									case 16:
																										goto IL_049a;
																									case 158:
																										goto IL_04ad;
																									case 131:
																										goto IL_04c1;
																									case 161:
																										goto IL_04d4;
																									case 157:
																										goto IL_04e7;
																									case 44:
																									case 92:
																										goto IL_04f5;
																									case 11:
																										goto IL_0500;
																									case 135:
																										goto IL_050e;
																									case 26:
																									case 50:
																										goto IL_051c;
																									case 162:
																										goto IL_0534;
																									case 142:
																									case 145:
																										goto IL_0542;
																									case 139:
																										goto IL_056b;
																									case 12:
																										goto IL_0579;
																									case 118:
																										goto IL_0595;
																									case 62:
																										goto IL_05a0;
																									case 76:
																										goto IL_05ae;
																									case 77:
																									case 159:
																										goto IL_05bc;
																									case 31:
																										goto IL_05ca;
																									case 42:
																										goto IL_05e2;
																									case 110:
																										goto IL_05f0;
																									case 58:
																									case 127:
																										goto IL_060c;
																									case 100:
																										goto IL_064b;
																									case 5:
																										goto IL_065e;
																									case 33:
																										goto IL_066c;
																									case 96:
																									case 116:
																										goto IL_0677;
																									case 68:
																										goto IL_06d9;
																									case 63:
																									case 160:
																										goto IL_06ec;
																									case 90:
																										goto IL_06fa;
																									case 81:
																										goto IL_0708;
																									case 0:
																									case 140:
																										goto IL_0716;
																									case 21:
																										goto IL_0756;
																									case 64:
																										goto IL_076a;
																									case 39:
																										goto IL_0786;
																									case 53:
																									case 85:
																										goto IL_0791;
																									case 117:
																										goto IL_079f;
																									case 83:
																									case 143:
																										goto IL_07ad;
																									case 29:
																										goto IL_07bb;
																									case 87:
																										goto IL_07de;
																									case 129:
																										goto IL_07e8;
																									case 69:
																										goto IL_07f6;
																									case 73:
																									case 108:
																										goto IL_0809;
																									case 120:
																										goto IL_084d;
																									case 2:
																										goto IL_0861;
																									case 107:
																										goto IL_0874;
																									case 121:
																										goto IL_0882;
																									case 71:
																									case 132:
																										goto IL_0890;
																									case 99:
																										goto IL_089e;
																									case 28:
																									case 130:
																										goto IL_08ac;
																									case 15:
																										goto IL_08c0;
																									case 137:
																										goto IL_0914;
																									case 97:
																										goto IL_092b;
																									case 8:
																									case 82:
																										goto IL_0952;
																									case 17:
																										goto IL_096b;
																									case 20:
																										goto IL_0976;
																									case 128:
																										goto IL_0981;
																									case 24:
																										goto IL_0997;
																									case 84:
																									case 149:
																										goto IL_09a2;
																									case 1:
																									case 3:
																									case 4:
																									case 9:
																									case 13:
																									case 14:
																									case 30:
																									case 37:
																									case 38:
																									case 41:
																									case 43:
																									case 49:
																									case 61:
																									case 65:
																									case 67:
																									case 74:
																									case 79:
																									case 88:
																									case 93:
																									case 95:
																									case 102:
																									case 103:
																									case 104:
																									case 105:
																									case 109:
																									case 119:
																									case 126:
																									case 138:
																									case 141:
																									case 150:
																									case 153:
																										goto end_IL_0304;
																									case 19:
																									case 34:
																									case 35:
																									case 45:
																									case 48:
																									case 59:
																									case 66:
																									case 70:
																									case 72:
																									case 78:
																									case 86:
																									case 89:
																									case 91:
																									case 98:
																									case 111:
																									case 114:
																									case 115:
																									case 125:
																									case 146:
																									case 151:
																										goto end_IL_02e4;
																									case 113:
																										goto end_IL_09ce;
																									case 23:
																										goto end_IL_09e1;
																									case 136:
																										goto end_IL_09eb;
																									case 122:
																										goto end_IL_09f6;
																									case 124:
																									case 133:
																										goto end_IL_0a06;
																									case 123:
																										goto end_IL_0a16;
																									case 27:
																									case 94:
																										goto end_IL_0a26;
																									case 147:
																										goto end_IL_0a36;
																									case 148:
																										goto end_IL_0a46;
																									case 36:
																									case 155:
																										goto IL_0a61;
																									}
																									continue;
																								}
																								goto IL_04e7;
																								IL_064b:
																								num5 -= 3;
																								goto end_IL_02e4;
																								IL_060c:
																								((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_064b;
																								IL_04e7:
																								if (6 < b)
																								{
																									goto IL_04f5;
																								}
																								goto IL_0595;
																								IL_04f5:
																								if (7 < b)
																								{
																									goto IL_0500;
																								}
																								goto IL_0534;
																								IL_0500:
																								if (8 < b)
																								{
																									goto end_IL_0304;
																								}
																								goto IL_050e;
																								IL_050e:
																								if (8 > b)
																								{
																									goto end_IL_0304;
																								}
																								goto IL_051c;
																								IL_051c:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_02e4;
																								IL_0534:
																								if (7 > b)
																								{
																									goto end_IL_0304;
																								}
																								goto IL_0542;
																								IL_0542:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_056b;
																								IL_056b:
																								ptr2 += 8;
																								goto IL_0579;
																								IL_0579:
																								num5--;
																								num = 146;
																								goto end_IL_02e4;
																								IL_0595:
																								if (6 > b)
																								{
																									goto IL_05a0;
																								}
																								num = 58;
																								goto IL_060c;
																								IL_05a0:
																								if (5 < b)
																								{
																									goto end_IL_0304;
																								}
																								goto IL_05ae;
																								IL_05ae:
																								if (5 > b)
																								{
																									goto end_IL_0304;
																								}
																								goto IL_05bc;
																								IL_05bc:
																								array[num5] = 5;
																								goto IL_05ca;
																								IL_05ca:
																								array2[num5] = array5[*(int*)(ptr2 + num3)];
																								goto IL_05e2;
																								IL_05e2:
																								num5++;
																								goto IL_05f0;
																								IL_05f0:
																								ptr2 += 8;
																								goto end_IL_02e4;
																								continue;
																								end_IL_02c1:
																								break;
																							}
																							break;
																						}
																						goto IL_033f;
																						IL_043b:
																						ptr2 += 8;
																						goto IL_04d4;
																						IL_04d4:
																						num5--;
																						goto end_IL_02e4;
																						IL_033f:
																						if (4 > b)
																						{
																							goto IL_034d;
																						}
																						goto IL_041d;
																						IL_034d:
																						if (2 >= b)
																						{
																							goto IL_0358;
																						}
																						goto IL_0365;
																						IL_0358:
																						if (2 > b)
																						{
																							goto IL_0375;
																						}
																						goto IL_03d8;
																						IL_03d8:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_04ad;
																						IL_04ad:
																						array[num5 - 2] = 0;
																						goto IL_04c1;
																						IL_04c1:
																						num5--;
																						goto end_IL_02e4;
																						IL_0375:
																						if (1 < b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_044e;
																						IL_044e:
																						if (1 > b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_045c;
																						IL_045c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																						goto IL_0475;
																						IL_0475:
																						array[num5] = 0;
																						goto IL_0483;
																						IL_0483:
																						num5++;
																						num = 16;
																						goto IL_049a;
																						IL_049a:
																						ptr2 += 8;
																						goto end_IL_02e4;
																						IL_0365:
																						if (3 < b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_0388;
																						IL_0388:
																						if (3 > b)
																						{
																							goto end_IL_0304;
																						}
																						goto IL_0396;
																						IL_0396:
																						array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																						goto IL_03bf;
																						IL_03bf:
																						array[num5 - 1] = 5;
																						goto end_IL_02e4;
																						IL_041d:
																						array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																						goto IL_043b;
																					}
																					goto IL_0334;
																					continue;
																					end_IL_02e4:
																					break;
																					IL_02e4:;
																				}
																				break;
																			}
																			goto IL_065e;
																			IL_0981:
																			if (17 > b)
																			{
																			}
																			goto end_IL_0304;
																			IL_065e:
																			if (13 >= b)
																			{
																				goto IL_066c;
																			}
																			goto IL_0874;
																			IL_066c:
																			if (13 <= b)
																			{
																				goto IL_0677;
																			}
																			goto IL_06ec;
																			IL_0677:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_06d9;
																			IL_06d9:
																			num5 -= 2;
																			break;
																			IL_06ec:
																			if (11 < b)
																			{
																				goto IL_06fa;
																			}
																			num = 39;
																			goto IL_0786;
																			IL_06fa:
																			if (12 < b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_0708;
																			IL_0708:
																			if (12 > b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_0716;
																			IL_0716:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0756;
																			IL_0756:
																			array[num5 - 2] = 0;
																			goto IL_076a;
																			IL_076a:
																			num5--;
																			break;
																			IL_09a2:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			break;
																			IL_0786:
																			if (11 > b)
																			{
																				goto IL_0791;
																			}
																			goto IL_0809;
																			IL_0791:
																			if (10 < b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_079f;
																			IL_079f:
																			if (10 > b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_07ad;
																			IL_07ad:
																			array[num5] = 0;
																			goto IL_07bb;
																			IL_07bb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_07de;
																			IL_07de:
																			array2[num5] = null;
																			goto IL_07e8;
																			IL_07e8:
																			num5++;
																			goto IL_07f6;
																			IL_07f6:
																			ptr2 += 8;
																			break;
																			IL_0809:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_084d;
																			IL_084d:
																			array[num5 - 2] = 0;
																			goto IL_0861;
																			IL_0861:
																			num5--;
																			break;
																			IL_0874:
																			if (15 >= b)
																			{
																				goto IL_0882;
																			}
																			goto IL_096b;
																			IL_0882:
																			if (15 > b)
																			{
																				goto IL_0890;
																			}
																			goto IL_0952;
																			IL_0890:
																			if (14 < b)
																			{
																				num = 153;
																				goto end_IL_0304;
																			}
																			goto IL_089e;
																			IL_089e:
																			if (14 > b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_08ac;
																			IL_08ac:
																			array[num5 - 2] = 0;
																			goto IL_08c0;
																			IL_08c0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)AccountGuestSidCharArray[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0914;
																			IL_0914:
																			num5--;
																			num = 97;
																			goto IL_092b;
																			IL_092b:
																			ptr2 += 8;
																			num = 48;
																			break;
																			IL_0997:
																			if (16 > b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_09a2;
																			IL_0952:
																			num5--;
																			num = 91;
																			break;
																			IL_096b:
																			if (16 < b)
																			{
																				goto IL_0976;
																			}
																			num = 24;
																			goto IL_0997;
																			IL_0976:
																			if (17 < b)
																			{
																				goto end_IL_0304;
																			}
																			goto IL_0981;
																		}
																		goto end_IL_0314;
																		continue;
																		end_IL_0304:
																		break;
																		IL_0304:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0314:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0a61;
												IL_0a61:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_09ce:
												break;
											}
											continue;
											end_IL_09e1:
											break;
										}
										continue;
										end_IL_09eb:
										break;
									}
									continue;
									end_IL_09f6:
									break;
								}
								continue;
								end_IL_0a06:
								break;
							}
							continue;
							end_IL_0a16:
							break;
						}
						continue;
						end_IL_0a26:
						break;
					}
					continue;
					end_IL_0a36:
					break;
				}
				continue;
				end_IL_0a46:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_2, int int_3)
	{
		int num = 81;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 95;
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref removeReflectionOnlyAssemblyResolveCreateReference.LoadAssemblyFromStringdesc);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0281:
															byte b = *ptr2;
															while (true)
															{
																IL_0271:
																ptr2++;
																while (true)
																{
																	IL_0261:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			num = 30;
																			while (true)
																			{
																				IL_023e:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_022e:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_0221:
																								if (2 < b)
																								{
																									while (true)
																									{
																										IL_0211:
																										if (3 < b)
																										{
																											while (4 >= b)
																											{
																												num = 112;
																												while (true)
																												{
																													if (num != 112)
																													{
																														if (num != 1093)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 20:
																														case 53:
																															goto IL_01fe;
																														case 38:
																															goto IL_0211;
																														case 62:
																														case 97:
																															goto IL_0221;
																														case 25:
																															goto IL_022e;
																														case 30:
																															goto IL_023e;
																														case 10:
																															goto IL_024e;
																														case 11:
																															goto IL_0261;
																														case 75:
																															goto IL_0271;
																														case 4:
																														case 105:
																															goto IL_0281;
																														case 70:
																															goto IL_028c;
																														case 5:
																														case 26:
																															goto IL_0297;
																														case 40:
																															goto IL_02d7;
																														case 73:
																															goto IL_02ed;
																														case 17:
																															goto IL_02fb;
																														case 83:
																															goto IL_030e;
																														case 16:
																														case 98:
																															goto IL_0321;
																														case 33:
																														case 55:
																															goto IL_032f;
																														case 37:
																															goto IL_033a;
																														case 56:
																														case 74:
																															goto IL_0348;
																														case 13:
																															goto IL_0388;
																														case 58:
																															goto IL_039c;
																														case 9:
																														case 63:
																															goto IL_03b8;
																														case 18:
																															goto IL_03c6;
																														case 23:
																														case 102:
																															goto IL_03d4;
																														case 104:
																															goto IL_03f0;
																														case 50:
																														case 89:
																															goto IL_03fb;
																														case 27:
																															goto IL_0414;
																														case 48:
																															goto IL_0422;
																														case 54:
																															goto IL_0430;
																														case 71:
																															goto IL_0443;
																														case 84:
																															goto IL_0451;
																														case 1:
																														case 44:
																															goto IL_045f;
																														case 24:
																															goto IL_049f;
																														case 92:
																															goto IL_04b3;
																														case 60:
																														case 93:
																															goto IL_04d4;
																														case 100:
																															goto IL_0514;
																														case 65:
																															goto IL_0528;
																														case 39:
																															goto IL_053b;
																														case 88:
																														case 90:
																															goto IL_0549;
																														case 32:
																															goto IL_0572;
																														case 2:
																															goto IL_0580;
																														case 43:
																														case 67:
																															goto IL_0593;
																														case 34:
																															goto IL_05a1;
																														case 64:
																															goto IL_05c4;
																														case 82:
																															goto IL_05ce;
																														case 94:
																															goto IL_05dc;
																														case 0:
																														case 12:
																														case 14:
																														case 15:
																														case 21:
																														case 22:
																														case 31:
																														case 35:
																														case 41:
																														case 45:
																														case 52:
																														case 57:
																														case 68:
																														case 78:
																														case 79:
																														case 91:
																														case 99:
																														case 101:
																															goto end_IL_01fe;
																														case 87:
																															goto IL_060f;
																														case 36:
																															goto IL_061d;
																														case 28:
																															goto IL_062b;
																														case 3:
																														case 7:
																														case 29:
																														case 42:
																														case 46:
																														case 51:
																														case 61:
																														case 69:
																														case 72:
																														case 77:
																														case 103:
																															goto end_IL_01eb;
																														case 47:
																															goto end_IL_0639;
																														case 6:
																															goto end_IL_064c;
																														case 59:
																															goto end_IL_0656;
																														case 95:
																															goto end_IL_0661;
																														case 86:
																															goto end_IL_0676;
																														case 8:
																														case 76:
																															goto end_IL_068b;
																														case 96:
																															goto end_IL_06a4;
																														case 19:
																														case 66:
																															goto end_IL_06b4;
																														case 80:
																															goto end_IL_06c4;
																														case 81:
																															goto end_IL_06d4;
																														case 49:
																														case 85:
																															goto IL_06ef;
																														}
																														continue;
																													}
																													if (4 > b)
																													{
																														goto end_IL_01fe;
																													}
																													goto IL_04d4;
																													IL_04d4:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													goto IL_0514;
																													IL_0528:
																													num5--;
																													break;
																													IL_0514:
																													array[num5 - 2] = 0;
																													goto IL_0528;
																													continue;
																													end_IL_01eb:
																													break;
																												}
																												goto end_IL_0261;
																												continue;
																												end_IL_01fe:
																												break;
																												IL_01fe:;
																											}
																											break;
																										}
																										goto IL_053b;
																										IL_0580:
																										num5--;
																										goto end_IL_0261;
																										IL_053b:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_0549;
																										IL_0549:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0572;
																										IL_0572:
																										ptr2 += 8;
																										goto IL_0580;
																									}
																									break;
																								}
																								goto IL_028c;
																								IL_02fb:
																								if (1 > b)
																								{
																								}
																								break;
																								IL_028c:
																								if (2 <= b)
																								{
																									goto IL_0297;
																								}
																								goto IL_02ed;
																								IL_0297:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_02d7;
																								IL_02d7:
																								array[num5 - 2] = 0;
																								goto IL_030e;
																								IL_030e:
																								num5--;
																								goto end_IL_0261;
																								IL_02ed:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_02fb;
																							}
																							break;
																						}
																						goto IL_0593;
																						IL_05dc:
																						ptr2 += 8;
																						goto end_IL_0261;
																						IL_0593:
																						array[num5] = 0;
																						goto IL_05a1;
																						IL_05a1:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_05c4;
																						IL_05c4:
																						array2[num5] = null;
																						goto IL_05ce;
																						IL_05ce:
																						num5++;
																						goto IL_05dc;
																					}
																					break;
																				}
																				goto IL_0321;
																				IL_049f:
																				array[num5 - 2] = 0;
																				goto IL_04b3;
																				IL_0321:
																				if (7 < b)
																				{
																					goto IL_032f;
																				}
																				goto IL_03f0;
																				IL_032f:
																				if (8 >= b)
																				{
																					goto IL_033a;
																				}
																				num = 63;
																				goto IL_03b8;
																				IL_033a:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0348;
																				IL_0348:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0388;
																				IL_0388:
																				array[num5 - 2] = 0;
																				goto IL_039c;
																				IL_039c:
																				num5--;
																				goto end_IL_0261;
																				IL_04b3:
																				num5--;
																				goto end_IL_0261;
																				IL_03b8:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_03c6;
																				IL_03c6:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_03d4;
																				IL_03d4:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0261;
																				IL_03f0:
																				if (7 <= b)
																				{
																					goto IL_03fb;
																				}
																				goto IL_0443;
																				IL_03fb:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0414;
																				IL_0414:
																				array[num5] = 0;
																				goto IL_0422;
																				IL_0422:
																				num5++;
																				goto IL_0430;
																				IL_0430:
																				ptr2 += 8;
																				goto end_IL_0261;
																				IL_0443:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0451;
																				IL_0451:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_045f;
																				IL_045f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_049f;
																			}
																			break;
																			IL_024e:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_060f;
																	IL_062b:
																	ptr2 += 8;
																	break;
																	IL_061d:
																	num5++;
																	goto IL_062b;
																	IL_060f:
																	array[num5] = 0;
																	goto IL_061d;
																	continue;
																	end_IL_0261:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06ef;
													IL_06ef:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0639:
													break;
												}
												continue;
												end_IL_064c:
												break;
											}
											continue;
											end_IL_0656:
											break;
										}
										continue;
										end_IL_0661:
										break;
									}
									continue;
									end_IL_0676:
									break;
								}
								continue;
								end_IL_068b:
								break;
							}
							continue;
							end_IL_06a4:
							break;
						}
						continue;
						end_IL_06b4:
						break;
					}
					continue;
					end_IL_06c4:
					break;
				}
				continue;
				end_IL_06d4:
				break;
			}
		}
	}

	static Class126()
	{
		int num = 8;
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 7;
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 15;
					while (true)
					{
						if (num == 15 || num != 996)
						{
							return;
						}
						switch (num)
						{
						case 3:
							goto end_IL_0045;
						case 7:
							goto end_IL_0052;
						case 8:
							goto end_IL_005e;
						case 0:
							return;
						case 1:
							return;
						case 2:
							return;
						case 4:
							return;
						case 5:
							return;
						case 6:
							return;
						}
						continue;
						end_IL_0045:
						break;
					}
					continue;
					end_IL_0052:
					break;
				}
				continue;
				end_IL_005e:
				break;
			}
		}
	}
}
