using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Anti AFK", "Room", "Prevents AFK kick.", false, 5, ModType.const_0, false)]
internal class Class159 : MonoBehaviour
{
	internal sealed class _003CNudge_003Ed__3 : IEnumerator<object>, IEnumerator, IDisposable
	{
		private int int_0;

		private WaitForSeconds waitForSeconds_0;

		public Class159 class159_0;

		private Transform transform_0;

		private Vector3 vector3_0;

		private static IntPtr[] LowercaseLettergetURL;

		private static IntPtr[] CheckTypeSecurityHostProtectionException;

		object IEnumerator<object>.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		object IEnumerator.Current
		{
			get
			{
				object obj = waitForSeconds_0;
				return obj;
			}
		}

		public _003CNudge_003Ed__3(int _003C_003E1__state)
		{
			object obj = this;
			((_003CNudge_003Ed__3)obj).int_0 = _003C_003E1__state;
		}

		unsafe void IDisposable.Dispose()
		{
			int num = 47;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								long[] array3 = new long[3];
								while (true)
								{
									object[] array4 = new object[1];
									while (true)
									{
										array4[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrentlyExecutingTaskCountSecurityTreatAsSafeAttribute.GetSerialNumberGetOrAdd);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 25;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 22;
															while (true)
															{
																IL_01dc:
																if (b >= 1)
																{
																	while (b <= 7)
																	{
																		while (true)
																		{
																			if (4 >= b)
																			{
																				while (true)
																				{
																					if (4 > b)
																					{
																						while (true)
																						{
																							IL_019f:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_018f:
																									if (2 <= b)
																									{
																										while (true)
																										{
																											IL_017a:
																											array2[num5] = null;
																											num = 86;
																											while (true)
																											{
																												if (num != 86)
																												{
																													if (num != 1067)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 27:
																													case 49:
																														goto IL_017a;
																													case 4:
																														goto IL_018f;
																													case 56:
																														goto IL_019f;
																													case 45:
																														goto end_IL_019f;
																													case 19:
																														goto end_IL_01af;
																													case 61:
																														goto end_IL_01bc;
																													case 22:
																														goto IL_01dc;
																													case 10:
																														goto end_IL_01dc;
																													case 39:
																													case 64:
																														goto end_IL_01ec;
																													case 23:
																													case 57:
																														goto IL_0210;
																													case 40:
																														goto IL_0229;
																													case 38:
																														goto IL_0237;
																													case 3:
																														goto IL_0245;
																													case 71:
																													case 75:
																														goto IL_0258;
																													case 11:
																														goto IL_0266;
																													case 66:
																														goto IL_0287;
																													case 67:
																														goto end_IL_0167;
																													case 68:
																														goto IL_02a8;
																													case 53:
																													case 54:
																														goto IL_02b6;
																													case 21:
																														goto IL_02de;
																													case 15:
																														goto IL_02f1;
																													case 42:
																													case 76:
																														goto IL_02fc;
																													case 9:
																														goto IL_030a;
																													case 62:
																													case 78:
																														goto IL_0318;
																													case 35:
																														goto IL_0334;
																													case 16:
																													case 37:
																														goto IL_0342;
																													case 74:
																														goto IL_0350;
																													case 2:
																													case 33:
																														goto IL_035e;
																													case 73:
																														goto IL_039e;
																													case 17:
																														goto IL_03b2;
																													case 5:
																													case 48:
																														goto IL_03c5;
																													case 18:
																														goto IL_03fc;
																													case 0:
																													case 1:
																													case 7:
																													case 8:
																													case 14:
																													case 26:
																													case 30:
																													case 36:
																													case 52:
																													case 55:
																													case 60:
																													case 63:
																													case 70:
																														goto end_IL_01cc;
																													case 77:
																														goto IL_0424;
																													case 12:
																														goto IL_0432;
																													case 32:
																														goto IL_0440;
																													case 20:
																													case 24:
																													case 25:
																													case 29:
																													case 31:
																													case 43:
																													case 59:
																													case 65:
																													case 79:
																														goto end_IL_0205;
																													case 28:
																														goto end_IL_044e;
																													case 69:
																														goto end_IL_0461;
																													case 72:
																														goto end_IL_0474;
																													case 51:
																														goto end_IL_047f;
																													case 34:
																													case 50:
																														goto end_IL_048f;
																													case 44:
																														goto end_IL_049f;
																													case 6:
																													case 58:
																														goto end_IL_04af;
																													case 46:
																														goto end_IL_04bf;
																													case 47:
																														goto end_IL_04cf;
																													case 13:
																													case 41:
																														return;
																													}
																													continue;
																												}
																												array[num5] = 5;
																												goto IL_0287;
																												IL_0287:
																												num5++;
																												goto end_IL_0205;
																												continue;
																												end_IL_0167:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0258;
																									IL_0266:
																									if (1 > b)
																									{
																									}
																									goto end_IL_01cc;
																									IL_0258:
																									if (1 < b)
																									{
																										goto end_IL_01cc;
																									}
																									goto IL_0266;
																								}
																							}
																							if (3 < b)
																							{
																								goto end_IL_01cc;
																							}
																							goto IL_02a8;
																							IL_02de:
																							num5 -= 2;
																							goto end_IL_0205;
																							IL_02b6:
																							((_003CNudge_003Ed__3)array2[num5 - 2]).transform_0 = (Transform)array2[num5 - 1];
																							goto IL_02de;
																							IL_02a8:
																							if (3 > b)
																							{
																								goto end_IL_01cc;
																							}
																							goto IL_02b6;
																							continue;
																							end_IL_019f:
																							break;
																						}
																						continue;
																					}
																					goto IL_0210;
																					IL_0245:
																					ptr2 += 8;
																					goto end_IL_0205;
																					IL_0210:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0229;
																					IL_0229:
																					array[num5] = 0;
																					goto IL_0237;
																					IL_0237:
																					num5++;
																					goto IL_0245;
																					continue;
																					end_IL_01af:
																					break;
																				}
																				continue;
																			}
																			goto IL_02f1;
																			IL_03fc:
																			num5 -= 2;
																			goto end_IL_0205;
																			IL_02f1:
																			if (6 < b)
																			{
																				goto IL_02fc;
																			}
																			goto IL_0334;
																			IL_02fc:
																			if (7 < b)
																			{
																				goto end_IL_01cc;
																			}
																			goto IL_030a;
																			IL_030a:
																			if (7 > b)
																			{
																				goto end_IL_01cc;
																			}
																			goto IL_0318;
																			IL_0318:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0205;
																			IL_0334:
																			if (6 > b)
																			{
																				goto IL_0342;
																			}
																			goto IL_03c5;
																			IL_0342:
																			if (5 < b)
																			{
																				goto end_IL_01cc;
																			}
																			goto IL_0350;
																			IL_0350:
																			if (5 > b)
																			{
																				goto end_IL_01cc;
																			}
																			goto IL_035e;
																			IL_035e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																			goto IL_039e;
																			IL_039e:
																			array[num5 - 2] = 0;
																			goto IL_03b2;
																			IL_03b2:
																			num5--;
																			goto end_IL_0205;
																			IL_03c5:
																			((_003CNudge_003Ed__3)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array3[num5 - 1]);
																			num = 18;
																			goto IL_03fc;
																			continue;
																			end_IL_01bc:
																			break;
																		}
																		continue;
																		end_IL_01cc:
																		break;
																	}
																}
																array2[num5] = array4[*(int*)(ptr2 + num3)];
																goto IL_0424;
																IL_0440:
																ptr2 += 8;
																goto end_IL_0205;
																IL_0432:
																num5++;
																goto IL_0440;
																IL_0424:
																array[num5] = 5;
																goto IL_0432;
																continue;
																end_IL_01dc:
																break;
															}
															continue;
															end_IL_01ec:
															break;
														}
														continue;
														end_IL_0205:
														break;
													}
													continue;
													end_IL_044e:
													break;
												}
												continue;
												end_IL_0461:
												break;
											}
											continue;
											end_IL_0474:
											break;
										}
										continue;
										end_IL_047f:
										break;
									}
									continue;
									end_IL_048f:
									break;
								}
								continue;
								end_IL_049f:
								break;
							}
							continue;
							end_IL_04af:
							break;
						}
						continue;
						end_IL_04bf:
						break;
					}
					continue;
					end_IL_04cf:
					break;
				}
			}
		}

		private unsafe bool MoveNext()
		{
			int num = 160;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						byte[] array = new byte[5];
						num = 10;
						while (true)
						{
							object[] array2 = new object[5];
							while (true)
							{
								int[] array3 = new int[1];
								while (true)
								{
									long[] array4 = new long[5];
									while (true)
									{
										object[] array5 = new object[2];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref PinningHelperIDelayEvaluatedEvidence.VTEMPTYMyMusic);
												num = 187;
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																byte b = *ptr2;
																while (true)
																{
																	ptr2++;
																	while (true)
																	{
																		IL_051d:
																		if (b >= 1)
																		{
																			while (b <= 30)
																			{
																				num = 125;
																				while (true)
																				{
																					IL_04f7:
																					if (15 >= b)
																					{
																						num = 52;
																						while (true)
																						{
																							IL_04e7:
																							if (15 > b)
																							{
																								while (true)
																								{
																									IL_04d7:
																									if (7 >= b)
																									{
																										while (true)
																										{
																											IL_04c7:
																											if (7 > b)
																											{
																												while (true)
																												{
																													IL_04b7:
																													if (3 < b)
																													{
																														while (true)
																														{
																															IL_04a7:
																															if (5 < b)
																															{
																																while (6 >= b)
																																{
																																	while (6 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_046e:
																																			array[num5] = 0;
																																			num = 268;
																																			while (true)
																																			{
																																				if (num != 268)
																																				{
																																					if (num != 1249)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 71:
																																					case 230:
																																						goto IL_046e;
																																					case 58:
																																						goto IL_0487;
																																					case 105:
																																						goto IL_0497;
																																					case 228:
																																						goto IL_04a7;
																																					case 127:
																																						goto IL_04b7;
																																					case 245:
																																						goto IL_04c7;
																																					case 150:
																																						goto IL_04d7;
																																					case 52:
																																						goto IL_04e7;
																																					case 125:
																																						goto IL_04f7;
																																					case 113:
																																						goto IL_050a;
																																					case 260:
																																						goto IL_051d;
																																					case 246:
																																						goto end_IL_051d;
																																					case 135:
																																					case 192:
																																						goto end_IL_052d;
																																					case 85:
																																						goto IL_0553;
																																					case 98:
																																						goto IL_0566;
																																					case 49:
																																						goto IL_0574;
																																					case 57:
																																						goto IL_0582;
																																					case 77:
																																					case 123:
																																						goto IL_0595;
																																					case 78:
																																						goto IL_05f0;
																																					case 126:
																																						goto IL_0603;
																																					case 140:
																																						goto IL_0616;
																																					case 99:
																																						goto IL_062d;
																																					case 55:
																																					case 151:
																																						goto IL_063b;
																																					case 67:
																																						goto IL_0673;
																																					case 154:
																																						goto IL_0687;
																																					case 120:
																																					case 222:
																																						goto IL_069a;
																																					case 201:
																																					case 232:
																																						goto IL_06d1;
																																					case 237:
																																						goto IL_06f1;
																																					case 106:
																																					case 161:
																																						goto IL_06ff;
																																					case 213:
																																						goto IL_073d;
																																					case 176:
																																						goto IL_0751;
																																					case 244:
																																						goto IL_0764;
																																					case 36:
																																						goto IL_0772;
																																					case 259:
																																						goto IL_0785;
																																					case 241:
																																						goto IL_0793;
																																					case 225:
																																						goto IL_07d2;
																																					case 14:
																																						goto IL_07dc;
																																					case 107:
																																						goto IL_07ea;
																																					case 103:
																																						goto IL_0806;
																																					case 59:
																																						goto IL_0814;
																																					case 199:
																																						goto IL_0822;
																																					case 20:
																																						goto IL_0830;
																																					case 2:
																																					case 182:
																																						goto IL_083b;
																																					case 128:
																																						goto IL_089d;
																																					case 121:
																																						goto IL_08b9;
																																					case 117:
																																						goto IL_08c7;
																																					case 33:
																																					case 190:
																																						goto IL_08d5;
																																					case 111:
																																						goto IL_08ee;
																																					case 193:
																																						goto IL_08fc;
																																					case 30:
																																						goto IL_090a;
																																					case 229:
																																						goto IL_091d;
																																					case 215:
																																						goto IL_092b;
																																					case 95:
																																					case 231:
																																						goto IL_0942;
																																					case 54:
																																					case 200:
																																						goto IL_095e;
																																					case 64:
																																						goto IL_0995;
																																					case 73:
																																						goto IL_09a8;
																																					case 173:
																																						goto IL_09b6;
																																					case 81:
																																					case 137:
																																						goto IL_09c1;
																																					case 223:
																																						goto IL_09f9;
																																					case 79:
																																						goto IL_0a0d;
																																					case 186:
																																						goto IL_0a20;
																																					case 60:
																																						goto IL_0a2e;
																																					case 141:
																																					case 157:
																																						goto IL_0a3c;
																																					case 207:
																																						goto IL_0a4a;
																																					case 177:
																																						goto IL_0a68;
																																					case 132:
																																						goto IL_0a76;
																																					case 155:
																																						goto IL_0a89;
																																					case 191:
																																						goto IL_0a97;
																																					case 9:
																																					case 65:
																																						goto IL_0aa5;
																																					case 146:
																																						goto IL_0ab9;
																																					case 221:
																																						goto IL_0af1;
																																					case 26:
																																					case 108:
																																						goto IL_0b04;
																																					case 204:
																																						goto IL_0b31;
																																					case 116:
																																						goto IL_0b44;
																																					case 69:
																																						goto IL_0b52;
																																					case 40:
																																					case 62:
																																						goto IL_0b60;
																																					case 100:
																																						goto IL_0b74;
																																					case 252:
																																						goto IL_0bd7;
																																					case 90:
																																						goto IL_0be5;
																																					case 209:
																																						goto IL_0bf8;
																																					case 28:
																																						goto IL_0c06;
																																					case 0:
																																						goto IL_0c14;
																																					case 218:
																																						goto IL_0c22;
																																					case 48:
																																					case 185:
																																						goto IL_0c2d;
																																					case 255:
																																						goto IL_0c41;
																																					case 122:
																																						goto IL_0c7e;
																																					case 50:
																																						goto IL_0c91;
																																					case 254:
																																						goto IL_0c9f;
																																					case 152:
																																					case 210:
																																						goto IL_0cad;
																																					case 165:
																																						goto IL_0ce5;
																																					case 91:
																																						goto IL_0cf9;
																																					case 89:
																																						goto IL_0d15;
																																					case 56:
																																						goto IL_0d23;
																																					case 87:
																																					case 224:
																																						goto IL_0d31;
																																					case 133:
																																						goto IL_0d5e;
																																					case 168:
																																					case 249:
																																						goto IL_0d71;
																																					case 15:
																																						goto IL_0d88;
																																					case 75:
																																						goto IL_0da6;
																																					case 219:
																																						goto IL_0db4;
																																					case 156:
																																						goto IL_0dc7;
																																					case 248:
																																						goto IL_0dd5;
																																					case 70:
																																					case 211:
																																						goto IL_0de0;
																																					case 233:
																																						goto IL_0e1d;
																																					case 94:
																																						goto IL_0e31;
																																					case 61:
																																						goto IL_0e44;
																																					case 253:
																																						goto IL_0e52;
																																					case 247:
																																					case 251:
																																						goto IL_0e60;
																																					case 256:
																																						goto IL_0e9e;
																																					case 138:
																																						goto IL_0eac;
																																					case 110:
																																						goto IL_0ebf;
																																					case 203:
																																						goto IL_0ecd;
																																					case 197:
																																					case 216:
																																						goto IL_0edb;
																																					case 149:
																																						goto IL_0ef5;
																																					case 31:
																																						goto IL_0f03;
																																					case 51:
																																						goto end_IL_045b;
																																					case 19:
																																						goto IL_0f2d;
																																					case 46:
																																						goto IL_0f3b;
																																					case 23:
																																					case 34:
																																						goto IL_0f46;
																																					case 257:
																																						goto IL_0f73;
																																					case 29:
																																						goto IL_0f86;
																																					case 148:
																																						goto IL_0f94;
																																					case 82:
																																					case 163:
																																						goto IL_0f9f;
																																					case 25:
																																						goto IL_0fdc;
																																					case 188:
																																						goto IL_0fea;
																																					case 130:
																																						goto IL_0ffd;
																																					case 167:
																																						goto IL_100b;
																																					case 5:
																																					case 220:
																																						goto IL_1019;
																																					case 195:
																																						goto IL_1036;
																																					case 175:
																																						goto IL_1090;
																																					case 124:
																																						goto IL_109e;
																																					case 180:
																																						goto IL_10b1;
																																					case 147:
																																						goto IL_10bf;
																																					case 17:
																																					case 68:
																																						goto IL_10cd;
																																					case 32:
																																						goto IL_10e1;
																																					case 261:
																																						goto IL_111a;
																																					case 43:
																																						goto IL_1136;
																																					case 202:
																																						goto IL_1144;
																																					case 162:
																																						goto IL_114f;
																																					case 47:
																																						goto IL_115d;
																																					case 4:
																																					case 181:
																																						goto IL_116b;
																																					case 101:
																																						goto IL_1179;
																																					case 240:
																																						goto IL_1191;
																																					case 21:
																																						goto IL_119f;
																																					case 1:
																																					case 86:
																																						goto IL_11b2;
																																					case 139:
																																						goto IL_11bc;
																																					case 92:
																																						goto IL_11ca;
																																					case 166:
																																						goto IL_11dd;
																																					case 63:
																																						goto IL_11e8;
																																					case 83:
																																					case 84:
																																						goto IL_11fc;
																																					case 143:
																																						goto IL_1224;
																																					case 3:
																																					case 6:
																																					case 8:
																																					case 13:
																																					case 27:
																																					case 37:
																																					case 38:
																																					case 39:
																																					case 41:
																																					case 45:
																																					case 72:
																																					case 74:
																																					case 80:
																																					case 88:
																																					case 93:
																																					case 109:
																																					case 112:
																																					case 114:
																																					case 131:
																																					case 134:
																																					case 142:
																																					case 164:
																																					case 172:
																																					case 178:
																																					case 179:
																																					case 184:
																																					case 189:
																																					case 194:
																																					case 198:
																																					case 217:
																																					case 238:
																																					case 250:
																																					case 258:
																																						goto end_IL_0487;
																																					case 239:
																																						goto IL_124c;
																																					case 12:
																																						goto IL_125a;
																																					case 205:
																																						goto IL_1268;
																																					case 7:
																																					case 16:
																																					case 18:
																																					case 24:
																																					case 35:
																																					case 42:
																																					case 44:
																																					case 66:
																																					case 76:
																																					case 102:
																																					case 104:
																																					case 118:
																																					case 119:
																																					case 129:
																																					case 136:
																																					case 144:
																																					case 153:
																																					case 158:
																																					case 170:
																																					case 171:
																																					case 174:
																																					case 183:
																																					case 196:
																																					case 206:
																																					case 212:
																																					case 214:
																																					case 226:
																																					case 227:
																																					case 234:
																																					case 235:
																																					case 242:
																																					case 243:
																																						goto end_IL_053d;
																																					case 187:
																																						goto end_IL_1276;
																																					case 96:
																																						goto end_IL_1289;
																																					case 22:
																																						goto end_IL_1293;
																																					case 145:
																																						goto end_IL_12a7;
																																					case 115:
																																						goto end_IL_12b7;
																																					case 208:
																																					case 236:
																																						goto end_IL_12c7;
																																					case 10:
																																						goto end_IL_12d7;
																																					case 53:
																																					case 97:
																																						goto end_IL_12e7;
																																					case 159:
																																						goto end_IL_12f7;
																																					case 160:
																																						goto end_IL_1310;
																																					case 11:
																																					case 169:
																																						goto IL_132b;
																																					}
																																					continue;
																																				}
																																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																				goto IL_07d2;
																																				IL_07d2:
																																				array2[num5] = null;
																																				goto IL_07dc;
																																				IL_07ea:
																																				ptr2 += 8;
																																				num = 183;
																																				goto end_IL_053d;
																																				IL_07dc:
																																				num5++;
																																				goto IL_07ea;
																																				continue;
																																				end_IL_045b:
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_0f1a;
																																		continue;
																																		end_IL_0487:
																																		break;
																																		IL_0487:;
																																	}
																																	break;
																																	IL_0497:;
																																}
																																break;
																															}
																															goto IL_0553;
																															IL_0673:
																															array[num5 - 1] = 5;
																															goto IL_0687;
																															IL_0553:
																															if (5 > b)
																															{
																																goto IL_0616;
																															}
																															goto IL_06d1;
																															IL_06d1:
																															array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																															goto IL_0764;
																															IL_0764:
																															ptr2 += 8;
																															goto IL_0772;
																															IL_0772:
																															num5--;
																															goto end_IL_053d;
																															IL_0616:
																															if (4 < b)
																															{
																																break;
																															}
																															num = 99;
																															goto IL_062d;
																															IL_0687:
																															ptr2 += 8;
																															goto end_IL_053d;
																															IL_062d:
																															if (4 > b)
																															{
																																break;
																															}
																															goto IL_063b;
																															IL_063b:
																															array2[num5 - 1] = ((delegate*<_003CNudge_003Ed__3, Class159>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((_003CNudge_003Ed__3)array2[num5 - 1]);
																															goto IL_0673;
																														}
																														break;
																													}
																													num = 98;
																													goto IL_0566;
																													IL_0785:
																													ptr2 += 8;
																													goto IL_0793;
																													IL_0793:
																													num5--;
																													num = 174;
																													goto end_IL_053d;
																													IL_0566:
																													if (3 > b)
																													{
																														goto IL_0574;
																													}
																													goto IL_069a;
																													IL_0574:
																													if (1 >= b)
																													{
																														goto IL_0582;
																													}
																													goto IL_0603;
																													IL_0582:
																													if (1 > b)
																													{
																													}
																													break;
																													IL_0603:
																													if (2 < b)
																													{
																														break;
																													}
																													goto IL_06f1;
																													IL_06f1:
																													if (2 > b)
																													{
																														break;
																													}
																													goto IL_06ff;
																													IL_06ff:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<_003CNudge_003Ed__3, int>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((_003CNudge_003Ed__3)array2[num5 - 1]);
																													goto IL_073d;
																													IL_073d:
																													array[num5 - 1] = 0;
																													goto IL_0751;
																													IL_0751:
																													ptr2 += 8;
																													goto end_IL_053d;
																													IL_069a:
																													ref int reference = ref array3[*(int*)(ptr2 + num3)];
																													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																													num = 259;
																													goto IL_0785;
																												}
																												break;
																											}
																											goto IL_0595;
																											IL_05f0:
																											num5--;
																											goto end_IL_053d;
																											IL_0595:
																											ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											num = 78;
																											goto IL_05f0;
																										}
																										break;
																									}
																									goto IL_0806;
																									IL_0ab9:
																									array2[num5 - 1] = ((delegate*<Component, Transform>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 1]);
																									goto IL_0af1;
																									IL_0806:
																									if (11 >= b)
																									{
																										goto IL_0814;
																									}
																									goto IL_09a8;
																									IL_0814:
																									if (11 > b)
																									{
																										goto IL_0822;
																									}
																									goto IL_095e;
																									IL_0822:
																									if (9 >= b)
																									{
																										goto IL_0830;
																									}
																									goto IL_091d;
																									IL_0830:
																									if (9 <= b)
																									{
																										goto IL_083b;
																									}
																									goto IL_08b9;
																									IL_083b:
																									ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																									goto IL_089d;
																									IL_089d:
																									num5 -= 2;
																									num = 196;
																									goto end_IL_053d;
																									IL_08b9:
																									if (8 < b)
																									{
																										break;
																									}
																									goto IL_08c7;
																									IL_08c7:
																									if (8 > b)
																									{
																										break;
																									}
																									goto IL_08d5;
																									IL_08d5:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																									goto IL_08ee;
																									IL_08ee:
																									array[num5] = 0;
																									goto IL_08fc;
																									IL_08fc:
																									num5++;
																									goto IL_090a;
																									IL_090a:
																									ptr2 += 8;
																									goto end_IL_053d;
																									IL_091d:
																									if (10 < b)
																									{
																										break;
																									}
																									goto IL_092b;
																									IL_092b:
																									if (10 > b)
																									{
																										break;
																									}
																									num = 231;
																									goto IL_0942;
																									IL_0af1:
																									ptr2 += 8;
																									goto end_IL_053d;
																									IL_0942:
																									byte* num6 = ptr2;
																									num4 = 1;
																									ptr2 = num6 + -200;
																									goto end_IL_053d;
																									IL_095e:
																									((_003CNudge_003Ed__3)array2[num5 - 2]).int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																									num = 64;
																									goto IL_0995;
																									IL_0995:
																									num5 -= 2;
																									goto end_IL_053d;
																									IL_09a8:
																									if (13 >= b)
																									{
																										goto IL_09b6;
																									}
																									goto IL_0a89;
																									IL_09b6:
																									if (13 <= b)
																									{
																										goto IL_09c1;
																									}
																									goto IL_0a20;
																									IL_09c1:
																									array2[num5 - 1] = ((delegate*<GorillaTagger, VRRig>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 1]);
																									goto IL_09f9;
																									IL_09f9:
																									array[num5 - 1] = 5;
																									goto IL_0a0d;
																									IL_0a0d:
																									ptr2 += 8;
																									goto end_IL_053d;
																									IL_0a20:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_0a2e;
																									IL_0a2e:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_0a3c;
																									IL_0a3c:
																									array[num5] = 5;
																									goto IL_0a4a;
																									IL_0a4a:
																									array2[num5] = ((delegate*<GorillaTagger>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])();
																									goto IL_0a68;
																									IL_0a68:
																									num5++;
																									goto IL_0a76;
																									IL_0a76:
																									ptr2 += 8;
																									goto end_IL_053d;
																									IL_0a89:
																									if (14 < b)
																									{
																										break;
																									}
																									goto IL_0a97;
																									IL_0a97:
																									if (14 > b)
																									{
																										break;
																									}
																									goto IL_0aa5;
																									IL_0aa5:
																									array[num5 - 1] = 5;
																									goto IL_0ab9;
																								}
																								break;
																							}
																							goto IL_0b04;
																							IL_0b31:
																							num5 -= 2;
																							goto end_IL_053d;
																							IL_0b04:
																							((_003CNudge_003Ed__3)array2[num5 - 2]).transform_0 = (Transform)array2[num5 - 1];
																							goto IL_0b31;
																						}
																						break;
																					}
																					goto IL_0b44;
																					IL_1224:
																					num5 -= 2;
																					goto end_IL_053d;
																					IL_11fc:
																					((Class159)array2[num5 - 2]).coroutine_0 = (Coroutine)array2[num5 - 1];
																					goto IL_1224;
																					IL_0b44:
																					if (23 >= b)
																					{
																						goto IL_0b52;
																					}
																					goto IL_0f2d;
																					IL_0b52:
																					if (23 <= b)
																					{
																						goto IL_0b60;
																					}
																					goto IL_0bf8;
																					IL_0b60:
																					array[num5 - 3] = 5;
																					goto IL_0b74;
																					IL_0b74:
																					array2[num5 - 3] = ((delegate*<float, float, float, object>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])));
																					goto IL_0bd7;
																					IL_0bd7:
																					num5 -= 2;
																					goto IL_0be5;
																					IL_0be5:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_0bf8:
																					if (19 >= b)
																					{
																						goto IL_0c06;
																					}
																					goto IL_0dc7;
																					IL_0c06:
																					if (19 > b)
																					{
																						goto IL_0c14;
																					}
																					goto IL_0d71;
																					IL_0c14:
																					if (17 >= b)
																					{
																						goto IL_0c22;
																					}
																					goto IL_0d15;
																					IL_0c22:
																					if (17 <= b)
																					{
																						goto IL_0c2d;
																					}
																					goto IL_0c91;
																					IL_0c2d:
																					array[num5 - 1] = 4;
																					goto IL_0c41;
																					IL_0c41:
																					array2[num5 - 1] = ((delegate*<Transform, Vector3>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 1]);
																					goto IL_0c7e;
																					IL_0c7e:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_0c91:
																					if (16 < b)
																					{
																						break;
																					}
																					goto IL_0c9f;
																					IL_0c9f:
																					if (16 > b)
																					{
																						break;
																					}
																					goto IL_0cad;
																					IL_0cad:
																					array2[num5 - 1] = ((delegate*<_003CNudge_003Ed__3, Transform>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((_003CNudge_003Ed__3)array2[num5 - 1]);
																					goto IL_0ce5;
																					IL_0ce5:
																					array[num5 - 1] = 5;
																					goto IL_0cf9;
																					IL_0cf9:
																					ptr2 += 8;
																					num = 206;
																					goto end_IL_053d;
																					IL_0d15:
																					if (18 < b)
																					{
																						break;
																					}
																					goto IL_0d23;
																					IL_0d23:
																					if (18 > b)
																					{
																						break;
																					}
																					goto IL_0d31;
																					IL_0d31:
																					((_003CNudge_003Ed__3)array2[num5 - 2]).vector3_0 = (Vector3)array2[num5 - 1];
																					goto IL_0d5e;
																					IL_0d5e:
																					num5 -= 2;
																					goto end_IL_053d;
																					IL_0d71:
																					array[num5] = 5;
																					num = 15;
																					goto IL_0d88;
																					IL_0d88:
																					array2[num5] = ((delegate*<GorillaTagger>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])();
																					goto IL_0da6;
																					IL_0da6:
																					num5++;
																					goto IL_0db4;
																					IL_0db4:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_0dc7:
																					if (21 >= b)
																					{
																						goto IL_0dd5;
																					}
																					goto IL_0ebf;
																					IL_0dd5:
																					if (21 <= b)
																					{
																						goto IL_0de0;
																					}
																					goto IL_0e44;
																					IL_0de0:
																					array2[num5 - 1] = ((delegate*<_003CNudge_003Ed__3, Vector3>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((_003CNudge_003Ed__3)array2[num5 - 1]);
																					goto IL_0e1d;
																					IL_0e1d:
																					array[num5 - 1] = 4;
																					goto IL_0e31;
																					IL_0e31:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_0e44:
																					if (20 < b)
																					{
																						break;
																					}
																					goto IL_0e52;
																					IL_0e52:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0e60;
																					IL_0e60:
																					((delegate*<Behaviour, bool, void>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((VRRig)array2[num5 - 2], (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0);
																					goto IL_0e9e;
																					IL_0e9e:
																					num5 -= 2;
																					goto IL_0eac;
																					IL_0eac:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_0ebf:
																					if (22 < b)
																					{
																						break;
																					}
																					goto IL_0ecd;
																					IL_0ecd:
																					if (22 > b)
																					{
																						break;
																					}
																					goto IL_0edb;
																					IL_0edb:
																					*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(float*)(ptr2 + num3);
																					goto IL_0ef5;
																					IL_0ef5:
																					array[num5] = 3;
																					goto IL_0f03;
																					IL_0f03:
																					num5++;
																					num = 51;
																					goto IL_0f1a;
																					IL_0f1a:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_0f2d:
																					if (27 >= b)
																					{
																						goto IL_0f3b;
																					}
																					goto IL_1136;
																					IL_0f3b:
																					if (27 <= b)
																					{
																						goto IL_0f46;
																					}
																					goto IL_0f86;
																					IL_0f46:
																					((_003CNudge_003Ed__3)array2[num5 - 2]).waitForSeconds_0 = (WaitForSeconds)array2[num5 - 1];
																					goto IL_0f73;
																					IL_0f73:
																					num5 -= 2;
																					goto end_IL_053d;
																					IL_0f86:
																					if (25 >= b)
																					{
																						goto IL_0f94;
																					}
																					goto IL_10b1;
																					IL_0f94:
																					if (25 <= b)
																					{
																						goto IL_0f9f;
																					}
																					goto IL_0ffd;
																					IL_0f9f:
																					((delegate*<Transform, Vector3, void>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((Transform)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																					goto IL_0fdc;
																					IL_0fdc:
																					num5 -= 2;
																					goto IL_0fea;
																					IL_0fea:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_0ffd:
																					if (24 < b)
																					{
																						break;
																					}
																					goto IL_100b;
																					IL_100b:
																					if (24 > b)
																					{
																						break;
																					}
																					goto IL_1019;
																					IL_1019:
																					array[num5 - 2] = 4;
																					num = 195;
																					goto IL_1036;
																					IL_1036:
																					array2[num5 - 2] = ((delegate*<Vector3, Vector3, Vector3>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((Vector3)array2[num5 - 2], (Vector3)array2[num5 - 1]);
																					num = 175;
																					goto IL_1090;
																					IL_1090:
																					num5--;
																					goto IL_109e;
																					IL_109e:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_10b1:
																					if (26 < b)
																					{
																						break;
																					}
																					goto IL_10bf;
																					IL_10bf:
																					if (26 > b)
																					{
																						break;
																					}
																					goto IL_10cd;
																					IL_10cd:
																					array[num5 - 1] = 5;
																					goto IL_10e1;
																					IL_10e1:
																					array2[num5 - 1] = ((delegate*<float, WaitForSeconds>)LowercaseLettergetURL[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])));
																					goto IL_111a;
																					IL_111a:
																					ptr2 += 8;
																					num = 104;
																					goto end_IL_053d;
																					IL_1136:
																					if (29 >= b)
																					{
																						goto IL_1144;
																					}
																					goto IL_11dd;
																					IL_1144:
																					if (29 > b)
																					{
																						goto IL_114f;
																					}
																					goto IL_11b2;
																					IL_114f:
																					if (28 < b)
																					{
																						break;
																					}
																					goto IL_115d;
																					IL_115d:
																					if (28 > b)
																					{
																						break;
																					}
																					goto IL_116b;
																					IL_116b:
																					array[num5] = 5;
																					goto IL_1179;
																					IL_1179:
																					array2[num5] = array5[*(int*)(ptr2 + num3)];
																					goto IL_1191;
																					IL_1191:
																					num5++;
																					goto IL_119f;
																					IL_119f:
																					ptr2 += 8;
																					goto end_IL_053d;
																					IL_11b2:
																					array2[num5] = null;
																					goto IL_11bc;
																					IL_11bc:
																					array[num5] = 5;
																					goto IL_11ca;
																					IL_11ca:
																					num5++;
																					goto end_IL_053d;
																					IL_11dd:
																					if (30 < b)
																					{
																						break;
																					}
																					goto IL_11e8;
																					IL_11e8:
																					if (30 > b)
																					{
																						break;
																					}
																					num = 84;
																					goto IL_11fc;
																				}
																				break;
																				IL_050a:;
																			}
																		}
																		array2[num5] = array5[*(int*)(ptr2 + num3)];
																		goto IL_124c;
																		IL_1268:
																		ptr2 += 8;
																		goto end_IL_053d;
																		IL_125a:
																		num5++;
																		goto IL_1268;
																		IL_124c:
																		array[num5] = 5;
																		goto IL_125a;
																		continue;
																		end_IL_051d:
																		break;
																	}
																	continue;
																	end_IL_052d:
																	break;
																}
																continue;
																end_IL_053d:
																break;
															}
															continue;
														}
														goto IL_132b;
														IL_132b:
														return (byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) != 0;
														continue;
														end_IL_1276:
														break;
													}
													continue;
													end_IL_1289:
													break;
												}
												continue;
												end_IL_1293:
												break;
											}
											continue;
											end_IL_12a7:
											break;
										}
										continue;
										end_IL_12b7:
										break;
									}
									continue;
									end_IL_12c7:
									break;
								}
								continue;
								end_IL_12d7:
								break;
							}
							continue;
							end_IL_12e7:
							break;
						}
						continue;
						end_IL_12f7:
						break;
					}
					continue;
					end_IL_1310:
					break;
				}
			}
		}

		bool IEnumerator.MoveNext()
		{
			//ILSpy generated this explicit interface implementation from .override directive in MoveNext
			return this.MoveNext();
		}

		unsafe void IEnumerator.Reset()
		{
			int num = 21;
			int num4 = default(int);
			int num5 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					num = 17;
					while (true)
					{
						byte[] array = new byte[1];
						while (true)
						{
							object[] array2 = new object[1];
							while (true)
							{
								num = 15;
								while (true)
								{
									byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref EventInfoLoadAssemblyFromString.LdelemRWhenAny);
									num = 19;
									while (true)
									{
										byte* ptr2 = ptr;
										while (true)
										{
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														if (b >= 1)
														{
															num = 42;
															while (true)
															{
																if (num != 42)
																{
																	if (num != 1023)
																	{
																		goto IL_0116;
																	}
																	switch (num)
																	{
																	case 23:
																		goto end_IL_00c5;
																	case 31:
																		goto end_IL_00d5;
																	case 6:
																	case 16:
																		goto end_IL_00e5;
																	case 25:
																		goto IL_010b;
																	case 3:
																		goto IL_0116;
																	case 1:
																	case 33:
																		goto IL_012c;
																	case 29:
																		goto IL_0137;
																	case 2:
																	case 4:
																	case 10:
																	case 12:
																	case 13:
																	case 18:
																	case 28:
																	case 34:
																		goto IL_0145;
																	case 27:
																		goto IL_0153;
																	case 32:
																		goto IL_0171;
																	case 5:
																		goto IL_017f;
																	case 0:
																	case 9:
																	case 22:
																		goto end_IL_00f5;
																	case 19:
																		goto end_IL_018d;
																	case 15:
																		goto end_IL_01a0;
																	case 7:
																	case 14:
																		goto end_IL_01aa;
																	case 35:
																		goto end_IL_01be;
																	case 8:
																	case 17:
																		goto end_IL_01c9;
																	case 20:
																		goto end_IL_01d9;
																	case 21:
																		goto end_IL_01e9;
																	case 11:
																	case 30:
																		goto IL_020d;
																	case 24:
																	case 26:
																		return;
																	}
																	continue;
																}
																if (b <= 2)
																{
																	goto IL_010b;
																}
																goto IL_0145;
																IL_020d:
																throw (Exception)array2[num5 - 1];
																IL_0137:
																if (2 > b)
																{
																	goto IL_0145;
																}
																goto IL_020d;
																IL_012c:
																if (2 >= b)
																{
																	goto IL_0137;
																}
																goto IL_0145;
																IL_010b:
																if (1 >= b)
																{
																	goto IL_0116;
																}
																num = 33;
																goto IL_012c;
																IL_0116:
																if (1 <= b)
																{
																}
																goto IL_0145;
																continue;
																end_IL_00c5:
																break;
															}
															continue;
														}
														goto IL_0145;
														IL_0171:
														num5++;
														goto IL_017f;
														IL_017f:
														ptr2 += 8;
														goto end_IL_00f5;
														IL_0145:
														array[num5] = 5;
														goto IL_0153;
														IL_0153:
														array2[num5] = ((delegate*<NotSupportedException>)CheckTypeSecurityHostProtectionException[*(int*)(ptr2 + num3)])();
														goto IL_0171;
														continue;
														end_IL_00d5:
														break;
													}
													continue;
													end_IL_00e5:
													break;
												}
												continue;
												end_IL_00f5:
												break;
											}
											continue;
											end_IL_018d:
											break;
										}
										continue;
										end_IL_01a0:
										break;
									}
									continue;
									end_IL_01aa:
									break;
								}
								continue;
								end_IL_01be:
								break;
							}
							continue;
							end_IL_01c9:
							break;
						}
						continue;
						end_IL_01d9:
						break;
					}
					continue;
					end_IL_01e9:
					break;
				}
			}
		}

		static _003CNudge_003Ed__3()
		{
			int num = 5;
			while (true)
			{
				Class296.Aw4EYyy3h();
				num = 13;
				while (true)
				{
					if (num != 13)
					{
						if (num == 994)
						{
							switch (num)
							{
							default:
								continue;
							case 5:
								break;
							case 0:
								return;
							case 1:
								return;
							case 2:
								return;
							case 3:
								return;
							case 4:
								return;
							case 6:
								return;
							}
							break;
						}
					}
					else
					{
						Class300.smethod_0();
					}
					return;
				}
			}
		}
	}

	private float float_0;

	private Coroutine coroutine_0;

	private static double double_0;

	private static float float_1;

	private static double double_1;

	private static int int_0;

	private static float float_2;

	private static bool bool_0;

	private static float float_3;

	private static IntPtr[] getCursorLeftFileSection;

	private static IntPtr[] getMinorVersionGet;

	private static IntPtr[] AsyncDelegateStackEnumerator;

	private static IntPtr[] GetDigitValuegetFormatJapaneseFirstYearAsANumber;

	private static IntPtr[] TupleChannelURI;

	private unsafe void Update()
	{
		int num = 246;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IsCompatibilitySwitchSetAppendText.getAccessControlTypeSecurityTreatAsSafeAttribute);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														if (num5 == 1)
														{
															return;
														}
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_06f7:
																	if (b >= 1)
																	{
																		while (b <= 47)
																		{
																			while (true)
																			{
																				IL_06d7:
																				if (24 < b)
																				{
																					while (true)
																					{
																						IL_06ca:
																						if (36 < b)
																						{
																							while (true)
																							{
																								IL_06bd:
																								if (42 < b)
																								{
																									while (true)
																									{
																										IL_06ad:
																										if (45 >= b)
																										{
																											num = 332;
																											while (true)
																											{
																												IL_069d:
																												if (45 > b)
																												{
																													while (true)
																													{
																														IL_068d:
																														if (43 < b)
																														{
																															while (44 >= b)
																															{
																																num = 399;
																																while (true)
																																{
																																	if (num != 399)
																																	{
																																		if (num != 1380)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 123:
																																			goto IL_067a;
																																		case 247:
																																			goto IL_068d;
																																		case 332:
																																			goto IL_069d;
																																		case 159:
																																			goto IL_06ad;
																																		case 371:
																																			goto IL_06bd;
																																		case 208:
																																			goto IL_06ca;
																																		case 12:
																																			goto IL_06d7;
																																		case 73:
																																			goto IL_06e7;
																																		case 164:
																																			goto IL_06f7;
																																		case 280:
																																			goto end_IL_06f7;
																																		case 102:
																																		case 344:
																																			goto end_IL_0707;
																																		case 18:
																																			goto IL_0722;
																																		case 52:
																																			goto IL_072f;
																																		case 77:
																																			goto IL_0748;
																																		case 118:
																																			goto IL_075b;
																																		case 136:
																																			goto IL_076e;
																																		case 119:
																																		case 140:
																																			goto IL_0781;
																																		case 157:
																																			goto IL_07e4;
																																		case 49:
																																			goto IL_07f2;
																																		case 190:
																																			goto IL_0805;
																																		case 172:
																																			goto IL_0810;
																																		case 100:
																																			goto IL_081e;
																																		case 58:
																																		case 59:
																																			goto IL_083a;
																																		case 143:
																																			goto IL_0844;
																																		case 217:
																																			goto IL_0852;
																																		case 188:
																																		case 232:
																																			goto IL_0865;
																																		case 90:
																																			goto IL_08d3;
																																		case 180:
																																		case 249:
																																			goto IL_08e6;
																																		case 253:
																																			goto IL_092b;
																																		case 8:
																																		case 134:
																																			goto IL_0939;
																																		case 255:
																																			goto IL_0952;
																																		case 91:
																																			goto IL_0960;
																																		case 267:
																																			goto IL_097c;
																																		case 129:
																																			goto IL_098a;
																																		case 50:
																																			goto IL_0995;
																																		case 304:
																																			goto IL_09a8;
																																		case 63:
																																		case 126:
																																			goto IL_09b6;
																																		case 310:
																																			goto IL_09cf;
																																		case 24:
																																			goto IL_09da;
																																		case 183:
																																			goto IL_09ed;
																																		case 322:
																																			goto IL_0a00;
																																		case 238:
																																		case 324:
																																			goto IL_0a44;
																																		case 331:
																																			goto IL_0a5d;
																																		case 2:
																																		case 300:
																																			goto IL_0a6b;
																																		case 323:
																																			goto IL_0aab;
																																		case 155:
																																			goto IL_0abf;
																																		case 334:
																																			goto IL_0ad2;
																																		case 336:
																																			goto IL_0ae5;
																																		case 297:
																																		case 317:
																																			goto IL_0af3;
																																		case 257:
																																			goto IL_0b0d;
																																		case 62:
																																			goto IL_0b1b;
																																		case 347:
																																			goto IL_0b2e;
																																		case 292:
																																			goto IL_0b6d;
																																		case 353:
																																			goto IL_0b80;
																																		case 135:
																																			goto IL_0b8e;
																																		case 293:
																																		case 318:
																																			goto IL_0b9c;
																																		case 346:
																																			goto IL_0bb9;
																																		case 107:
																																			goto IL_0c06;
																																		case 76:
																																			goto IL_0c1d;
																																		case 309:
																																			goto IL_0c30;
																																		case 290:
																																			goto IL_0c3e;
																																		case 165:
																																		case 348:
																																			goto IL_0c4c;
																																		case 235:
																																			goto IL_0c5a;
																																		case 113:
																																			goto IL_0c7e;
																																		case 320:
																																			goto IL_0c8c;
																																		case 148:
																																		case 359:
																																			goto IL_0c9f;
																																		case 185:
																																			goto IL_0cdd;
																																		case 307:
																																			goto IL_0cf1;
																																		case 368:
																																			goto IL_0d04;
																																		case 370:
																																			goto IL_0d17;
																																		case 5:
																																		case 193:
																																			goto IL_0d22;
																																		case 121:
																																			goto IL_0d4f;
																																		case 53:
																																			goto IL_0d62;
																																		case 114:
																																			goto IL_0d70;
																																		case 38:
																																		case 82:
																																			goto IL_0d7b;
																																		case 1:
																																			goto IL_0d89;
																																		case 189:
																																			goto IL_0da7;
																																		case 51:
																																			goto IL_0db5;
																																		case 43:
																																			goto IL_0dc8;
																																		case 329:
																																			goto IL_0dd6;
																																		case 110:
																																		case 305:
																																			goto IL_0ded;
																																		case 262:
																																			goto IL_0e01;
																																		case 335:
																																			goto IL_0e49;
																																		case 98:
																																			goto IL_0e5c;
																																		case 236:
																																			goto IL_0e6f;
																																		case 122:
																																			goto IL_0e7d;
																																		case 64:
																																		case 351:
																																			goto IL_0e94;
																																		case 341:
																																			goto IL_0ea8;
																																		case 354:
																																			goto IL_0ee9;
																																		case 294:
																																			goto IL_0f05;
																																		case 79:
																																			goto IL_0f13;
																																		case 84:
																																		case 130:
																																			goto IL_0f2a;
																																		case 225:
																																			goto IL_0f3e;
																																		case 182:
																																			goto IL_0f8a;
																																		case 285:
																																			goto IL_0f98;
																																		case 372:
																																			goto IL_0fab;
																																		case 379:
																																			goto IL_0fbe;
																																		case 47:
																																		case 311:
																																			goto IL_0fd5;
																																		case 381:
																																			goto IL_0ff1;
																																		case 342:
																																			goto IL_1005;
																																		case 382:
																																			goto IL_1018;
																																		case 21:
																																			goto IL_1026;
																																		case 357:
																																			goto IL_1034;
																																		case 92:
																																		case 377:
																																			goto IL_103f;
																																		case 16:
																																			goto IL_1058;
																																		case 179:
																																			goto IL_1066;
																																		case 209:
																																			goto IL_1074;
																																		case 0:
																																			goto IL_1087;
																																		case 278:
																																			goto IL_1095;
																																		case 327:
																																			goto IL_10a3;
																																		case 260:
																																			goto IL_10b1;
																																		case 151:
																																			goto IL_10bf;
																																		case 93:
																																			goto IL_10ca;
																																		case 75:
																																		case 369:
																																			goto IL_10d8;
																																		case 160:
																																			goto IL_10f1;
																																		case 204:
																																			goto IL_10ff;
																																		case 198:
																																			goto IL_110d;
																																		case 60:
																																			goto IL_1120;
																																		case 70:
																																			goto IL_112e;
																																		case 162:
																																		case 170:
																																			goto IL_113c;
																																		case 166:
																																			goto IL_117c;
																																		case 214:
																																			goto IL_1190;
																																		case 89:
																																		case 268:
																																			goto IL_11a3;
																																		case 44:
																																			goto IL_11cc;
																																		case 99:
																																			goto IL_11da;
																																		case 254:
																																			goto IL_11ed;
																																		case 167:
																																			goto IL_11f8;
																																		case 264:
																																			goto IL_120b;
																																		case 41:
																																			goto IL_1219;
																																		case 276:
																																		case 306:
																																			goto IL_1227;
																																		case 274:
																																			goto IL_1267;
																																		case 3:
																																			goto IL_127b;
																																		case 104:
																																		case 326:
																																			goto IL_128e;
																																		case 283:
																																			goto IL_12ce;
																																		case 216:
																																			goto IL_12eb;
																																		case 19:
																																			goto IL_12fe;
																																		case 156:
																																			goto IL_130c;
																																		case 178:
																																		case 210:
																																			goto IL_1317;
																																		case 286:
																																			goto IL_1357;
																																		case 153:
																																			goto IL_136b;
																																		case 65:
																																			goto IL_1387;
																																		case 103:
																																			goto IL_1392;
																																		case 275:
																																		case 308:
																																			goto IL_13a0;
																																		case 88:
																																			goto IL_13e0;
																																		case 206:
																																			goto IL_13f4;
																																		case 271:
																																			goto IL_1407;
																																		case 33:
																																			goto IL_1415;
																																		case 228:
																																		case 233:
																																			goto IL_1423;
																																		case 138:
																																			goto IL_1436;
																																		case 137:
																																			goto IL_1444;
																																		case 196:
																																		case 234:
																																			goto IL_1452;
																																		case 169:
																																			goto IL_14b4;
																																		case 315:
																																			goto IL_14d0;
																																		case 37:
																																			goto IL_14de;
																																		case 195:
																																			goto IL_14f1;
																																		case 242:
																																			goto IL_14ff;
																																		case 330:
																																		case 360:
																																			goto IL_150a;
																																		case 127:
																																			goto IL_1538;
																																		case 251:
																																			goto IL_154b;
																																		case 83:
																																			goto IL_1559;
																																		case 34:
																																		case 252:
																																			goto IL_1564;
																																		case 149:
																																			goto IL_15b6;
																																		case 303:
																																			goto IL_15c9;
																																		case 197:
																																			goto IL_15d4;
																																		case 14:
																																		case 296:
																																			goto IL_15e2;
																																		case 68:
																																			goto IL_15fa;
																																		case 116:
																																			goto IL_1608;
																																		case 145:
																																		case 289:
																																			goto IL_1616;
																																		case 67:
																																			goto IL_1657;
																																		case 175:
																																			goto IL_166b;
																																		case 316:
																																			goto IL_167e;
																																		case 97:
																																			goto IL_1689;
																																		case 220:
																																		case 284:
																																			goto IL_1697;
																																		case 48:
																																			goto IL_16af;
																																		case 221:
																																			goto IL_16bd;
																																		case 131:
																																			goto IL_16cb;
																																		case 146:
																																			goto IL_16de;
																																		case 282:
																																			goto IL_16ec;
																																		case 13:
																																		case 248:
																																			goto IL_16fa;
																																		case 250:
																																			goto IL_1708;
																																		case 378:
																																			goto IL_172c;
																																		case 226:
																																			goto IL_173a;
																																		case 6:
																																			goto IL_174d;
																																		case 124:
																																			goto IL_175b;
																																		case 106:
																																		case 199:
																																			goto IL_1766;
																																		case 161:
																																			goto IL_17ba;
																																		case 4:
																																			goto IL_17cd;
																																		case 223:
																																			goto IL_17d8;
																																		case 31:
																																		case 66:
																																			goto IL_17e6;
																																		case 56:
																																			goto IL_1811;
																																		case 298:
																																			goto IL_182a;
																																		case 355:
																																			goto IL_1838;
																																		case 61:
																																		case 269:
																																			goto IL_1846;
																																		case 343:
																																			goto IL_187e;
																																		case 26:
																																			goto IL_1892;
																																		case 301:
																																			goto IL_18a5;
																																		case 367:
																																			goto IL_18b0;
																																		case 337:
																																		case 363:
																																			goto IL_18be;
																																		case 328:
																																			goto IL_18d7;
																																		case 229:
																																			goto IL_18e5;
																																		case 71:
																																			goto IL_18fc;
																																		case 222:
																																			goto IL_190f;
																																		case 243:
																																			goto IL_191d;
																																		case 32:
																																		case 191:
																																			goto IL_192b;
																																		case 244:
																																			goto IL_193f;
																																		case 218:
																																			goto IL_197e;
																																		case 69:
																																		case 259:
																																			goto IL_1991;
																																		case 230:
																																			goto IL_19da;
																																		case 212:
																																			goto IL_19f7;
																																		case 349:
																																		case 383:
																																			goto IL_1a13;
																																		case 87:
																																			goto IL_1a21;
																																		case 295:
																																			goto IL_1a44;
																																		case 365:
																																			goto IL_1a4e;
																																		case 171:
																																			goto IL_1a5c;
																																		case 387:
																																			goto IL_1a6f;
																																		case 256:
																																			goto IL_1aae;
																																		case 375:
																																		case 389:
																																			goto IL_1ac1;
																																		case 154:
																																			goto IL_1acf;
																																		case 366:
																																			goto IL_1af3;
																																		case 54:
																																			goto IL_1b01;
																																		case 391:
																																			goto IL_1b14;
																																		case 42:
																																			goto IL_1b2b;
																																		case 270:
																																		case 361:
																																			goto IL_1b39;
																																		case 109:
																																			goto IL_1b47;
																																		case 10:
																																			goto IL_1b65;
																																		case 288:
																																			goto IL_1b73;
																																		case 22:
																																		case 142:
																																			goto IL_1b94;
																																		case 78:
																																			goto IL_1bcc;
																																		case 385:
																																			goto IL_1be9;
																																		case 74:
																																		case 111:
																																			goto IL_1bfc;
																																		case 241:
																																			goto IL_1c10;
																																		case 374:
																																			goto IL_1c5d;
																																		case 173:
																																			goto IL_1c6b;
																																		case 7:
																																		case 11:
																																		case 15:
																																		case 17:
																																		case 36:
																																		case 40:
																																		case 46:
																																		case 55:
																																		case 57:
																																		case 72:
																																		case 81:
																																		case 85:
																																		case 86:
																																		case 96:
																																		case 105:
																																		case 115:
																																		case 128:
																																		case 132:
																																		case 147:
																																		case 163:
																																		case 168:
																																		case 174:
																																		case 176:
																																		case 181:
																																		case 184:
																																		case 187:
																																		case 192:
																																		case 194:
																																		case 201:
																																		case 205:
																																		case 224:
																																		case 263:
																																		case 265:
																																		case 266:
																																		case 277:
																																		case 279:
																																		case 281:
																																		case 291:
																																		case 302:
																																		case 313:
																																		case 319:
																																		case 321:
																																		case 338:
																																		case 339:
																																		case 352:
																																		case 362:
																																		case 364:
																																		case 384:
																																		case 388:
																																		case 390:
																																			goto end_IL_0667;
																																		case 23:
																																		case 25:
																																		case 27:
																																		case 28:
																																		case 29:
																																		case 35:
																																		case 39:
																																		case 45:
																																		case 80:
																																		case 94:
																																		case 101:
																																		case 108:
																																		case 112:
																																		case 120:
																																		case 125:
																																		case 139:
																																		case 141:
																																		case 144:
																																		case 150:
																																		case 152:
																																		case 158:
																																		case 177:
																																		case 202:
																																		case 203:
																																		case 207:
																																		case 211:
																																		case 215:
																																		case 219:
																																		case 227:
																																		case 231:
																																		case 237:
																																		case 239:
																																		case 240:
																																		case 258:
																																		case 261:
																																		case 272:
																																		case 273:
																																		case 287:
																																		case 299:
																																		case 312:
																																		case 314:
																																		case 325:
																																		case 333:
																																		case 345:
																																		case 350:
																																		case 356:
																																		case 358:
																																		case 376:
																																		case 380:
																																		case 392:
																																			goto end_IL_0717;
																																		case 30:
																																			goto end_IL_1c8e;
																																		case 186:
																																			goto end_IL_1ca1;
																																		case 117:
																																			goto end_IL_1cab;
																																		case 20:
																																			goto end_IL_1cb6;
																																		case 340:
																																			goto end_IL_1cc6;
																																		case 95:
																																		case 386:
																																			goto end_IL_1cd6;
																																		case 200:
																																			goto end_IL_1ce6;
																																		case 213:
																																			goto end_IL_1cf6;
																																		case 133:
																																			goto end_IL_1d06;
																																		case 245:
																																			goto end_IL_1d16;
																																		case 246:
																																			goto end_IL_1d26;
																																		case 9:
																																		case 373:
																																			return;
																																		}
																																		continue;
																																	}
																																	if (44 > b)
																																	{
																																		break;
																																	}
																																	goto IL_1b94;
																																	IL_1b94:
																																	array2[num6 - 1] = ((delegate*<GorillaTagger, VRRig>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 1]);
																																	goto IL_1bcc;
																																	IL_1be9:
																																	ptr2 += 8;
																																	goto end_IL_0717;
																																	IL_1bcc:
																																	array[num6 - 1] = 5;
																																	num = 385;
																																	goto IL_1be9;
																																	continue;
																																	end_IL_0667:
																																	break;
																																}
																																break;
																																IL_067a:;
																															}
																															break;
																														}
																														goto IL_092b;
																														IL_0ad2:
																														ptr2 += 8;
																														goto end_IL_0717;
																														IL_092b:
																														if (43 > b)
																														{
																															break;
																														}
																														goto IL_0939;
																														IL_0939:
																														array[num6 - 1] = 3;
																														goto IL_0a00;
																														IL_0a00:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																														goto IL_0ad2;
																													}
																													break;
																												}
																												goto IL_1bfc;
																												IL_1c6b:
																												ptr2 += 8;
																												goto end_IL_0717;
																												IL_1bfc:
																												array[num6 - 2] = 0;
																												goto IL_1c10;
																												IL_1c10:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])((VRRig)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																												goto IL_1c5d;
																												IL_1c5d:
																												num6--;
																												goto IL_1c6b;
																											}
																											break;
																										}
																										goto IL_072f;
																										IL_1aae:
																										ptr2 += 8;
																										goto end_IL_0717;
																										IL_0952:
																										if (47 < b)
																										{
																											break;
																										}
																										goto IL_0960;
																										IL_072f:
																										if (46 >= b)
																										{
																											num = 136;
																											goto IL_076e;
																										}
																										goto IL_0952;
																										IL_0960:
																										if (47 <= b)
																										{
																											num = 105;
																										}
																										break;
																										IL_076e:
																										if (46 > b)
																										{
																											break;
																										}
																										goto IL_0a44;
																										IL_0a44:
																										array[num6 - 1] = 3;
																										goto IL_1a6f;
																										IL_1a6f:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																										goto IL_1aae;
																									}
																									break;
																								}
																								goto IL_0722;
																								IL_0c5a:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = (((delegate*<bool>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])() ? 1 : 0);
																								goto IL_0c7e;
																								IL_0722:
																								if (42 > b)
																								{
																									goto IL_075b;
																								}
																								goto IL_0781;
																								IL_0781:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0d04;
																								IL_0d04:
																								num6--;
																								goto end_IL_0717;
																								IL_075b:
																								if (39 >= b)
																								{
																									goto IL_0805;
																								}
																								goto IL_0b80;
																								IL_0805:
																								if (39 > b)
																								{
																									goto IL_0810;
																								}
																								num = 58;
																								goto IL_083a;
																								IL_0810:
																								if (37 >= b)
																								{
																									goto IL_081e;
																								}
																								goto IL_1b14;
																								IL_081e:
																								if (37 > b)
																								{
																									break;
																								}
																								goto IL_08e6;
																								IL_08e6:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_0ff1;
																								IL_0ff1:
																								array[num6 - 2] = 3;
																								goto IL_1005;
																								IL_1005:
																								num6--;
																								goto end_IL_0717;
																								IL_1b14:
																								if (38 < b)
																								{
																									break;
																								}
																								num = 42;
																								goto IL_1b2b;
																								IL_0c8c:
																								ptr2 += 8;
																								goto end_IL_0717;
																								IL_1b2b:
																								if (38 > b)
																								{
																									break;
																								}
																								goto IL_1b39;
																								IL_1b39:
																								array[num6] = 5;
																								goto IL_1b47;
																								IL_1b47:
																								array2[num6] = ((delegate*<GorillaTagger>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])();
																								goto IL_1b65;
																								IL_1b65:
																								num6++;
																								goto IL_1b73;
																								IL_1b73:
																								ptr2 += 8;
																								goto end_IL_0717;
																								IL_0c7e:
																								num6++;
																								goto IL_0c8c;
																								IL_083a:
																								array2[num6] = null;
																								goto IL_0844;
																								IL_0844:
																								array[num6] = 5;
																								goto IL_0852;
																								IL_0852:
																								num6++;
																								goto end_IL_0717;
																								IL_0b80:
																								if (40 >= b)
																								{
																									goto IL_0b8e;
																								}
																								goto IL_0c30;
																								IL_0b8e:
																								if (40 > b)
																								{
																									break;
																								}
																								goto IL_0b9c;
																								IL_0b9c:
																								array[num6 - 2] = 0;
																								num = 346;
																								goto IL_0bb9;
																								IL_0bb9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = (((delegate*<UnityEngine.Object, UnityEngine.Object, bool>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (UnityEngine.Object)array2[num6 - 1]) ? 1 : 0);
																								goto IL_0c06;
																								IL_0c06:
																								num6--;
																								num = 76;
																								goto IL_0c1d;
																								IL_0c1d:
																								ptr2 += 8;
																								goto end_IL_0717;
																								IL_0c30:
																								if (41 < b)
																								{
																									break;
																								}
																								goto IL_0c3e;
																								IL_0c3e:
																								if (41 > b)
																								{
																									break;
																								}
																								goto IL_0c4c;
																								IL_0c4c:
																								array[num6] = 0;
																								goto IL_0c5a;
																							}
																							break;
																						}
																						goto IL_0748;
																						IL_0f3e:
																						array2[num6 - 2] = ((delegate*<MonoBehaviour, IEnumerator, Coroutine>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num6 - 2], (IEnumerator)array2[num6 - 1]);
																						goto IL_0f8a;
																						IL_0748:
																						if (36 > b)
																						{
																							goto IL_07e4;
																						}
																						goto IL_0865;
																						IL_07e4:
																						if (30 < b)
																						{
																							goto IL_07f2;
																						}
																						goto IL_0d17;
																						IL_07f2:
																						if (33 >= b)
																						{
																							goto IL_097c;
																						}
																						goto IL_09cf;
																						IL_097c:
																						if (33 > b)
																						{
																							goto IL_098a;
																						}
																						goto IL_1ac1;
																						IL_098a:
																						if (31 < b)
																						{
																							goto IL_0995;
																						}
																						goto IL_09a8;
																						IL_0995:
																						if (32 < b)
																						{
																							break;
																						}
																						goto IL_0a5d;
																						IL_0a5d:
																						if (32 > b)
																						{
																							break;
																						}
																						goto IL_0a6b;
																						IL_0a6b:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_0aab;
																						IL_0aab:
																						array[num6 - 2] = 3;
																						goto IL_0abf;
																						IL_0abf:
																						num6--;
																						goto end_IL_0717;
																						IL_09a8:
																						if (31 > b)
																						{
																							break;
																						}
																						goto IL_09b6;
																						IL_09b6:
																						array[num6 - 1] = 3;
																						goto IL_0b2e;
																						IL_0b2e:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						goto IL_0b6d;
																						IL_0b6d:
																						ptr2 += 8;
																						goto end_IL_0717;
																						IL_1ac1:
																						array[num6] = 3;
																						goto IL_1acf;
																						IL_1acf:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])();
																						goto IL_1af3;
																						IL_1af3:
																						num6++;
																						goto IL_1b01;
																						IL_1b01:
																						ptr2 += 8;
																						goto end_IL_0717;
																						IL_09cf:
																						if (34 >= b)
																						{
																							goto IL_09da;
																						}
																						goto IL_09ed;
																						IL_09da:
																						if (34 > b)
																						{
																							break;
																						}
																						goto IL_0c9f;
																						IL_0c9f:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<Class159, float>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])((Class159)array2[num6 - 1]);
																						goto IL_0cdd;
																						IL_0cdd:
																						array[num6 - 1] = 3;
																						goto IL_0cf1;
																						IL_0cf1:
																						ptr2 += 8;
																						goto end_IL_0717;
																						IL_09ed:
																						if (35 < b)
																						{
																							break;
																						}
																						goto IL_0ae5;
																						IL_0ae5:
																						if (35 > b)
																						{
																							break;
																						}
																						goto IL_0af3;
																						IL_0af3:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(float*)(ptr2 + num3);
																						goto IL_0b0d;
																						IL_0b0d:
																						array[num6] = 3;
																						goto IL_0b1b;
																						IL_0b1b:
																						num6++;
																						goto IL_0fab;
																						IL_0fab:
																						ptr2 += 8;
																						goto end_IL_0717;
																						IL_0d17:
																						if (30 <= b)
																						{
																							goto IL_0d22;
																						}
																						goto IL_0d62;
																						IL_0d22:
																						((Class159)array2[num6 - 2]).coroutine_0 = (Coroutine)array2[num6 - 1];
																						goto IL_0d4f;
																						IL_0d4f:
																						num6 -= 2;
																						goto end_IL_0717;
																						IL_0d62:
																						if (27 >= b)
																						{
																							goto IL_0d70;
																						}
																						goto IL_0e6f;
																						IL_0d70:
																						if (27 <= b)
																						{
																							goto IL_0d7b;
																						}
																						goto IL_0dc8;
																						IL_0d7b:
																						array[num6] = 5;
																						goto IL_0d89;
																						IL_0d89:
																						array2[num6] = ((delegate*<GorillaTagger>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])();
																						goto IL_0da7;
																						IL_0da7:
																						num6++;
																						goto IL_0db5;
																						IL_0db5:
																						ptr2 += 8;
																						goto end_IL_0717;
																						IL_0dc8:
																						if (25 >= b)
																						{
																							goto IL_0dd6;
																						}
																						goto IL_0e5c;
																						IL_0dd6:
																						if (25 > b)
																						{
																							break;
																						}
																						num = 110;
																						goto IL_0ded;
																						IL_0f8a:
																						num6--;
																						goto IL_0f98;
																						IL_0ded:
																						array[num6 - 1] = 0;
																						goto IL_0e01;
																						IL_0e01:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, int>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																						num = 335;
																						goto IL_0e49;
																						IL_0e49:
																						ptr2 += 8;
																						goto end_IL_0717;
																						IL_0e5c:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_0fbe;
																						IL_0fbe:
																						if (26 > b)
																						{
																							break;
																						}
																						num = 311;
																						goto IL_0fd5;
																						IL_0f98:
																						ptr2 += 8;
																						goto end_IL_0717;
																						IL_0fd5:
																						byte* num7 = ptr2;
																						num5 = 1;
																						ptr2 = num7 + -200;
																						goto end_IL_0717;
																						IL_0e6f:
																						if (28 >= b)
																						{
																							goto IL_0e7d;
																						}
																						goto IL_0f05;
																						IL_0e7d:
																						if (28 > b)
																						{
																							break;
																						}
																						num = 351;
																						goto IL_0e94;
																						IL_0865:
																						ptr2 = (((!(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) <= *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]))) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_08d3;
																						IL_0e94:
																						array[num6 - 1] = 5;
																						goto IL_0ea8;
																						IL_0ea8:
																						array2[num6 - 1] = ((delegate*<Class159, IEnumerator>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])((Class159)array2[num6 - 1]);
																						num = 354;
																						goto IL_0ee9;
																						IL_0ee9:
																						ptr2 += 8;
																						num = 211;
																						goto end_IL_0717;
																						IL_0f05:
																						if (29 < b)
																						{
																							break;
																						}
																						goto IL_0f13;
																						IL_0f13:
																						if (29 > b)
																						{
																							break;
																						}
																						num = 130;
																						goto IL_0f2a;
																						IL_08d3:
																						num6 -= 2;
																						goto end_IL_0717;
																						IL_0f2a:
																						array[num6 - 2] = 5;
																						goto IL_0f3e;
																					}
																					break;
																				}
																				goto IL_1018;
																				IL_19f7:
																				num6--;
																				num = 358;
																				goto end_IL_0717;
																				IL_1018:
																				if (24 > b)
																				{
																					goto IL_1026;
																				}
																				goto IL_1991;
																				IL_1026:
																				if (12 >= b)
																				{
																					goto IL_1034;
																				}
																				goto IL_14f1;
																				IL_1034:
																				if (12 <= b)
																				{
																					goto IL_103f;
																				}
																				goto IL_1087;
																				IL_103f:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				goto IL_1058;
																				IL_1058:
																				array[num6] = 1;
																				goto IL_1066;
																				IL_1066:
																				num6++;
																				goto IL_1074;
																				IL_1074:
																				ptr2 += 16;
																				goto end_IL_0717;
																				IL_1087:
																				if (6 >= b)
																				{
																					goto IL_1095;
																				}
																				goto IL_12fe;
																				IL_1095:
																				if (6 > b)
																				{
																					goto IL_10a3;
																				}
																				goto IL_128e;
																				IL_10a3:
																				if (3 >= b)
																				{
																					goto IL_10b1;
																				}
																				goto IL_11ed;
																				IL_10b1:
																				if (3 > b)
																				{
																					goto IL_10bf;
																				}
																				goto IL_11a3;
																				IL_10bf:
																				if (1 >= b)
																				{
																					goto IL_10ca;
																				}
																				goto IL_1120;
																				IL_10ca:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_10d8;
																				IL_10d8:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_10f1;
																				IL_10f1:
																				array[num6] = 0;
																				goto IL_10ff;
																				IL_10ff:
																				num6++;
																				goto IL_110d;
																				IL_110d:
																				ptr2 += 8;
																				goto end_IL_0717;
																				IL_1120:
																				if (2 < b)
																				{
																					break;
																				}
																				goto IL_112e;
																				IL_112e:
																				if (2 > b)
																				{
																					break;
																				}
																				goto IL_113c;
																				IL_113c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_117c;
																				IL_117c:
																				array[num6 - 2] = 0;
																				goto IL_1190;
																				IL_1190:
																				num6--;
																				goto end_IL_0717;
																				IL_11a3:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_11cc;
																				IL_11cc:
																				ptr2 += 8;
																				goto IL_11da;
																				IL_11da:
																				num6--;
																				goto end_IL_0717;
																				IL_11ed:
																				if (4 >= b)
																				{
																					goto IL_11f8;
																				}
																				goto IL_120b;
																				IL_11f8:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_1a13;
																				IL_1a13:
																				array[num6] = 0;
																				goto IL_1a21;
																				IL_1a21:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_1a44;
																				IL_1a44:
																				array2[num6] = null;
																				goto IL_1a4e;
																				IL_1a4e:
																				num6++;
																				goto IL_1a5c;
																				IL_1a5c:
																				ptr2 += 8;
																				goto end_IL_0717;
																				IL_120b:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_1219;
																				IL_1219:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_1227;
																				IL_1227:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1267;
																				IL_1267:
																				array[num6 - 2] = 0;
																				goto IL_127b;
																				IL_127b:
																				num6--;
																				goto end_IL_0717;
																				IL_128e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_12ce;
																				IL_12ce:
																				array[num6 - 2] = 0;
																				num = 216;
																				goto IL_12eb;
																				IL_12eb:
																				num6--;
																				goto end_IL_0717;
																				IL_12fe:
																				if (9 >= b)
																				{
																					goto IL_130c;
																				}
																				goto IL_1436;
																				IL_130c:
																				if (9 <= b)
																				{
																					goto IL_1317;
																				}
																				goto IL_1387;
																				IL_1317:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1357;
																				IL_1357:
																				array[num6 - 2] = 0;
																				goto IL_136b;
																				IL_136b:
																				num6--;
																				num = 35;
																				goto end_IL_0717;
																				IL_1387:
																				if (7 >= b)
																				{
																					goto IL_1392;
																				}
																				goto IL_1407;
																				IL_1392:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_13a0;
																				IL_13a0:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_13e0;
																				IL_13e0:
																				array[num6 - 2] = 0;
																				goto IL_13f4;
																				IL_13f4:
																				num6--;
																				goto end_IL_0717;
																				IL_1407:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_1415;
																				IL_1415:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_1423;
																				IL_1423:
																				num6--;
																				goto end_IL_0717;
																				IL_1436:
																				if (10 >= b)
																				{
																					goto IL_1444;
																				}
																				goto IL_14d0;
																				IL_1444:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_1452;
																				IL_1452:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_14b4;
																				IL_14b4:
																				num6 -= 2;
																				num = 287;
																				goto end_IL_0717;
																				IL_14d0:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_14de;
																				IL_14de:
																				if (11 > b)
																				{
																					break;
																				}
																				goto end_IL_0717;
																				IL_14f1:
																				if (18 >= b)
																				{
																					goto IL_14ff;
																				}
																				goto IL_174d;
																				IL_14ff:
																				if (18 <= b)
																				{
																					goto IL_150a;
																				}
																				goto IL_154b;
																				IL_150a:
																				((Class159)array2[num6 - 2]).float_0 = (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_1538;
																				IL_1538:
																				num6 -= 2;
																				goto end_IL_0717;
																				IL_154b:
																				if (15 >= b)
																				{
																					goto IL_1559;
																				}
																				goto IL_167e;
																				IL_1559:
																				if (15 <= b)
																				{
																					goto IL_1564;
																				}
																				goto IL_15c9;
																				IL_1564:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_15b6;
																				IL_15b6:
																				num6--;
																				goto end_IL_0717;
																				IL_15c9:
																				if (13 >= b)
																				{
																					goto IL_15d4;
																				}
																				goto IL_15fa;
																				IL_15d4:
																				if (13 > b)
																				{
																					break;
																				}
																				goto IL_15e2;
																				IL_15e2:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0717;
																				IL_15fa:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_1608;
																				IL_1608:
																				if (14 > b)
																				{
																					break;
																				}
																				goto IL_1616;
																				IL_1616:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																				goto IL_1657;
																				IL_1657:
																				array[num6 - 2] = 0;
																				goto IL_166b;
																				IL_166b:
																				num6--;
																				goto end_IL_0717;
																				IL_167e:
																				if (16 >= b)
																				{
																					goto IL_1689;
																				}
																				goto IL_16de;
																				IL_1689:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_1697;
																				IL_1697:
																				array2[num6] = array5[*(int*)(ptr2 + num3)];
																				goto IL_16af;
																				IL_16af:
																				array[num6] = 5;
																				goto IL_16bd;
																				IL_16bd:
																				num6++;
																				goto IL_16cb;
																				IL_16cb:
																				ptr2 += 8;
																				goto end_IL_0717;
																				IL_16de:
																				if (17 < b)
																				{
																					break;
																				}
																				goto IL_16ec;
																				IL_16ec:
																				if (17 > b)
																				{
																					break;
																				}
																				goto IL_16fa;
																				IL_16fa:
																				array[num6] = 3;
																				goto IL_1708;
																				IL_1708:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<float>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])();
																				goto IL_172c;
																				IL_172c:
																				num6++;
																				goto IL_173a;
																				IL_173a:
																				ptr2 += 8;
																				goto end_IL_0717;
																				IL_174d:
																				if (21 >= b)
																				{
																					goto IL_175b;
																				}
																				goto IL_18a5;
																				IL_175b:
																				if (21 <= b)
																				{
																					goto IL_1766;
																				}
																				goto IL_17cd;
																				IL_1766:
																				ptr2 = (((array2[num6 - 1] == null) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_17ba;
																				IL_17ba:
																				num6--;
																				goto end_IL_0717;
																				IL_17cd:
																				if (19 >= b)
																				{
																					goto IL_17d8;
																				}
																				goto IL_182a;
																				IL_17d8:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_17e6;
																				IL_17e6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_1811;
																				IL_1811:
																				array[num6 - 1] = 0;
																				goto end_IL_0717;
																				IL_182a:
																				if (20 < b)
																				{
																					break;
																				}
																				goto IL_1838;
																				IL_1838:
																				if (20 > b)
																				{
																					break;
																				}
																				goto IL_1846;
																				IL_1846:
																				array2[num6 - 1] = ((delegate*<Class159, Coroutine>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])((Class159)array2[num6 - 1]);
																				goto IL_187e;
																				IL_187e:
																				array[num6 - 1] = 5;
																				goto IL_1892;
																				IL_1892:
																				ptr2 += 8;
																				goto end_IL_0717;
																				IL_18a5:
																				if (22 >= b)
																				{
																					goto IL_18b0;
																				}
																				goto IL_190f;
																				IL_18b0:
																				if (22 > b)
																				{
																					break;
																				}
																				goto IL_18be;
																				IL_18be:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(double*)(ptr2 + num4);
																				goto IL_18d7;
																				IL_18d7:
																				array[num6] = 3;
																				goto IL_18e5;
																				IL_18e5:
																				num6++;
																				num = 71;
																				goto IL_18fc;
																				IL_18fc:
																				ptr2 += 16;
																				goto end_IL_0717;
																				IL_190f:
																				if (23 < b)
																				{
																					break;
																				}
																				goto IL_191d;
																				IL_191d:
																				if (23 > b)
																				{
																					break;
																				}
																				goto IL_192b;
																				IL_192b:
																				array[num6 - 1] = 3;
																				goto IL_193f;
																				IL_193f:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<double, double>)getCursorLeftFileSection[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_197e;
																				IL_197e:
																				ptr2 += 8;
																				goto end_IL_0717;
																				IL_1991:
																				*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				num = 230;
																				goto IL_19da;
																				IL_19da:
																				array[num6 - 2] = 3;
																				num = 212;
																				goto IL_19f7;
																			}
																			break;
																			IL_06e7:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_0717;
																	continue;
																	end_IL_06f7:
																	break;
																}
																continue;
																end_IL_0707:
																break;
															}
															continue;
															end_IL_0717:
															break;
														}
														continue;
														end_IL_1c8e:
														break;
													}
													continue;
													end_IL_1ca1:
													break;
												}
												continue;
												end_IL_1cab:
												break;
											}
											continue;
											end_IL_1cb6:
											break;
										}
										continue;
										end_IL_1cc6:
										break;
									}
									continue;
									end_IL_1cd6:
									break;
								}
								continue;
								end_IL_1ce6:
								break;
							}
							continue;
							end_IL_1cf6:
							break;
						}
						continue;
						end_IL_1d06:
						break;
					}
					continue;
					end_IL_1d16:
					break;
				}
				continue;
				end_IL_1d26:
				break;
			}
		}
	}

	private IEnumerator method_0()
	{
		int num = 108;
		num = 27;
		num = 455;
		num = 35;
		num = 27;
		num = 56;
		num = 59;
		num = 59;
		num = 52;
		num = 26;
		num = 138;
		num = 46;
		num = 26;
		num = 72;
		num = 1252;
		num = 1252;
		num = 1311;
		num = 1482;
		num = 114;
		num = 0;
		int num2 = 0;
		do
		{
			if (num2 == 0)
			{
				num = 1;
				num2 = 1;
			}
			num = num2;
		}
		while (num != 1);
		num = 0;
		_003CNudge_003Ed__3 _003CNudge_003Ed__ = new _003CNudge_003Ed__3(0);
		object obj = _003CNudge_003Ed__;
		object obj2 = obj;
		((_003CNudge_003Ed__3)obj2).class159_0 = this;
		return (IEnumerator)obj;
	}

	private unsafe void OnDisable()
	{
		int num = 164;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								num = 160;
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WaitAsyncCanCastTo.IsMulticastIRegistrationServices);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_03f4:
																if (b >= 1)
																{
																	while (b <= 21)
																	{
																		while (true)
																		{
																			IL_03d7:
																			if (11 < b)
																			{
																				while (true)
																				{
																					IL_03c7:
																					if (16 >= b)
																					{
																						while (true)
																						{
																							IL_03b7:
																							if (16 > b)
																							{
																								while (true)
																								{
																									IL_03a7:
																									if (13 < b)
																									{
																										while (true)
																										{
																											IL_0397:
																											if (14 >= b)
																											{
																												while (14 <= b)
																												{
																													num = 213;
																													while (true)
																													{
																														if (num != 213)
																														{
																															if (num != 1194)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 147:
																																goto IL_0384;
																															case 33:
																															case 42:
																																goto IL_0397;
																															case 72:
																															case 77:
																																goto IL_03a7;
																															case 87:
																																goto IL_03b7;
																															case 47:
																																goto IL_03c7;
																															case 109:
																																goto IL_03d7;
																															case 155:
																																goto IL_03e4;
																															case 99:
																																goto IL_03f4;
																															case 44:
																																goto end_IL_03f4;
																															case 126:
																															case 130:
																																goto end_IL_0404;
																															case 121:
																																goto IL_041f;
																															case 64:
																															case 108:
																																goto IL_042a;
																															case 14:
																																goto IL_0441;
																															case 141:
																																goto IL_0465;
																															case 125:
																																goto IL_0473;
																															case 28:
																															case 148:
																																goto IL_0486;
																															case 65:
																																goto IL_0491;
																															case 49:
																																goto IL_04a4;
																															case 80:
																																goto IL_04b2;
																															case 117:
																															case 133:
																																goto IL_04c9;
																															case 52:
																																goto IL_04d4;
																															case 84:
																															case 145:
																																goto IL_04e2;
																															case 143:
																																goto IL_0522;
																															case 78:
																																goto IL_053f;
																															case 107:
																																goto IL_0552;
																															case 152:
																																goto IL_0565;
																															case 51:
																																goto IL_0573;
																															case 48:
																															case 86:
																																goto IL_0581;
																															case 5:
																																goto IL_05c1;
																															case 110:
																															case 167:
																																goto IL_05da;
																															case 56:
																																goto IL_05e5;
																															case 41:
																																goto IL_05f8;
																															case 34:
																																goto IL_0603;
																															case 4:
																															case 23:
																																goto IL_0611;
																															case 55:
																																goto IL_063f;
																															case 97:
																															case 173:
																																goto IL_0652;
																															case 88:
																															case 181:
																																goto IL_0665;
																															case 9:
																																goto IL_06a5;
																															case 61:
																																goto IL_06c2;
																															case 183:
																																goto IL_06d5;
																															case 127:
																																goto IL_06e3;
																															case 98:
																															case 184:
																																goto IL_06ff;
																															case 76:
																																goto IL_070a;
																															case 11:
																															case 119:
																																goto IL_0718;
																															case 24:
																																goto IL_0760;
																															case 82:
																															case 188:
																																goto IL_0781;
																															case 103:
																																goto IL_07c1;
																															case 156:
																																goto IL_07d5;
																															case 193:
																																goto IL_07e8;
																															case 22:
																															case 115:
																																goto IL_07f6;
																															case 131:
																																goto IL_0804;
																															case 68:
																																goto IL_0827;
																															case 30:
																																goto IL_0831;
																															case 142:
																																goto IL_083f;
																															case 194:
																																goto IL_0852;
																															case 195:
																																goto IL_0865;
																															case 63:
																															case 192:
																																goto IL_0873;
																															case 180:
																																goto IL_08d5;
																															case 187:
																															case 199:
																																goto IL_08e8;
																															case 21:
																																goto IL_08f6;
																															case 26:
																															case 201:
																																goto IL_0904;
																															case 105:
																																goto IL_091d;
																															case 2:
																																goto IL_092b;
																															case 165:
																																goto IL_0939;
																															case 202:
																																goto IL_094c;
																															case 31:
																															case 92:
																																goto IL_095a;
																															case 1:
																																goto IL_099a;
																															case 157:
																																goto IL_09ae;
																															case 95:
																															case 205:
																																goto IL_09c1;
																															case 40:
																																goto IL_09d4;
																															case 6:
																																goto IL_0a0c;
																															case 37:
																																goto IL_0a20;
																															case 13:
																																goto IL_0a33;
																															case 75:
																															case 197:
																																goto IL_0a3e;
																															case 174:
																																goto IL_0a56;
																															case 18:
																																goto IL_0a64;
																															case 15:
																																goto IL_0a72;
																															case 89:
																																goto IL_0a85;
																															case 8:
																																goto IL_0a93;
																															case 7:
																															case 198:
																																goto IL_0aa6;
																															case 123:
																																goto IL_0ab4;
																															case 159:
																																goto IL_0ad2;
																															case 203:
																																goto IL_0ae0;
																															case 112:
																															case 154:
																																goto IL_0af3;
																															case 81:
																															case 122:
																																goto IL_0afe;
																															case 144:
																																goto IL_0b09;
																															case 20:
																															case 153:
																																goto IL_0b17;
																															case 101:
																																goto IL_0b33;
																															case 70:
																																goto IL_0b41;
																															case 182:
																																goto IL_0b54;
																															case 106:
																															case 170:
																																goto IL_0b62;
																															case 10:
																															case 158:
																																goto IL_0b6d;
																															case 53:
																																goto IL_0b7b;
																															case 94:
																															case 113:
																																goto IL_0b89;
																															case 43:
																																goto IL_0b93;
																															case 27:
																																goto IL_0ba1;
																															case 62:
																																goto IL_0bb4;
																															case 96:
																															case 139:
																																goto IL_0bc2;
																															case 67:
																																goto IL_0bff;
																															case 111:
																																goto IL_0c16;
																															case 17:
																															case 185:
																																goto IL_0c26;
																															case 137:
																																goto IL_0c4e;
																															case 3:
																															case 16:
																															case 19:
																															case 29:
																															case 32:
																															case 36:
																															case 45:
																															case 46:
																															case 50:
																															case 57:
																															case 58:
																															case 59:
																															case 69:
																															case 71:
																															case 73:
																															case 90:
																															case 100:
																															case 102:
																															case 118:
																															case 120:
																															case 128:
																															case 135:
																															case 136:
																															case 138:
																															case 140:
																															case 149:
																															case 150:
																															case 168:
																															case 171:
																															case 172:
																															case 175:
																															case 176:
																															case 178:
																															case 189:
																															case 200:
																															case 204:
																																goto end_IL_0371;
																															case 0:
																															case 12:
																															case 38:
																															case 39:
																															case 74:
																															case 91:
																															case 93:
																															case 104:
																															case 114:
																															case 116:
																															case 124:
																															case 129:
																															case 132:
																															case 146:
																															case 151:
																															case 161:
																															case 162:
																															case 169:
																															case 177:
																															case 179:
																															case 186:
																															case 190:
																															case 191:
																															case 206:
																																goto end_IL_0414;
																															case 25:
																																goto end_IL_0c71;
																															case 83:
																																goto end_IL_0c84;
																															case 54:
																																goto end_IL_0c8e;
																															case 160:
																																goto end_IL_0c99;
																															case 66:
																																goto end_IL_0ca9;
																															case 35:
																															case 60:
																																goto end_IL_0cb9;
																															case 196:
																																goto end_IL_0cd2;
																															case 134:
																															case 166:
																																goto end_IL_0ce2;
																															case 163:
																																goto end_IL_0cf2;
																															case 164:
																																goto end_IL_0d02;
																															case 79:
																															case 85:
																																return;
																															}
																															continue;
																														}
																														goto IL_09d4;
																														IL_0a0c:
																														array[num5 - 1] = 5;
																														goto IL_0a20;
																														IL_0a20:
																														ptr2 += 8;
																														goto end_IL_0414;
																														IL_09d4:
																														array2[num5 - 1] = ((delegate*<Class159, Coroutine>)getMinorVersionGet[*(int*)(ptr2 + num3)])((Class159)array2[num5 - 1]);
																														goto IL_0a0c;
																														continue;
																														end_IL_0371:
																														break;
																													}
																													break;
																													IL_0384:;
																												}
																												break;
																											}
																											goto IL_06ff;
																											IL_0760:
																											num5--;
																											goto end_IL_0414;
																											IL_06ff:
																											if (15 < b)
																											{
																												num = 29;
																												break;
																											}
																											goto IL_070a;
																											IL_070a:
																											if (15 > b)
																											{
																												break;
																											}
																											goto IL_0718;
																											IL_0718:
																											ptr2 = ((array2[num5 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											goto IL_0760;
																										}
																										break;
																									}
																									goto IL_0a33;
																									IL_0a93:
																									if (12 > b)
																									{
																										break;
																									}
																									goto end_IL_0414;
																									IL_0a33:
																									if (13 <= b)
																									{
																										goto IL_0a3e;
																									}
																									goto IL_0a85;
																									IL_0a3e:
																									array2[num5] = array5[*(int*)(ptr2 + num3)];
																									goto IL_0a56;
																									IL_0a56:
																									array[num5] = 5;
																									goto IL_0a64;
																									IL_0a64:
																									num5++;
																									goto IL_0a72;
																									IL_0a72:
																									ptr2 += 8;
																									goto end_IL_0414;
																									IL_0a85:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_0a93;
																								}
																								break;
																							}
																							goto IL_0aa6;
																							IL_0ae0:
																							ptr2 += 8;
																							goto end_IL_0414;
																							IL_0aa6:
																							array[num5] = 5;
																							goto IL_0ab4;
																							IL_0ab4:
																							array2[num5] = ((delegate*<GorillaTagger>)getMinorVersionGet[*(int*)(ptr2 + num3)])();
																							goto IL_0ad2;
																							IL_0ad2:
																							num5++;
																							goto IL_0ae0;
																						}
																						break;
																					}
																					goto IL_0af3;
																					IL_0c4e:
																					num5 -= 2;
																					goto end_IL_0414;
																					IL_0af3:
																					if (19 < b)
																					{
																						goto IL_0afe;
																					}
																					goto IL_0b54;
																					IL_0afe:
																					if (20 >= b)
																					{
																						goto IL_0b09;
																					}
																					goto IL_0b33;
																					IL_0b09:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0b17;
																					IL_0b17:
																					byte* num6 = ptr2;
																					num4 = 1;
																					ptr2 = num6 + -200;
																					goto end_IL_0414;
																					IL_0b33:
																					if (21 < b)
																					{
																						break;
																					}
																					goto IL_0b41;
																					IL_0b41:
																					if (21 <= b)
																					{
																					}
																					break;
																					IL_0b54:
																					if (19 > b)
																					{
																						goto IL_0b62;
																					}
																					goto IL_0c26;
																					IL_0b62:
																					if (17 < b)
																					{
																						goto IL_0b6d;
																					}
																					goto IL_0bb4;
																					IL_0b6d:
																					if (18 < b)
																					{
																						break;
																					}
																					goto IL_0b7b;
																					IL_0b7b:
																					if (18 > b)
																					{
																						break;
																					}
																					goto IL_0b89;
																					IL_0b89:
																					array2[num5] = null;
																					goto IL_0b93;
																					IL_0b93:
																					array[num5] = 5;
																					goto IL_0ba1;
																					IL_0ba1:
																					num5++;
																					goto end_IL_0414;
																					IL_0bb4:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_0bc2;
																					IL_0bc2:
																					((delegate*<MonoBehaviour, Coroutine, void>)getMinorVersionGet[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (Coroutine)array2[num5 - 1]);
																					goto IL_0bff;
																					IL_0bff:
																					num5 -= 2;
																					num = 111;
																					goto IL_0c16;
																					IL_0c16:
																					ptr2 += 8;
																					goto end_IL_0414;
																					IL_0c26:
																					((Class159)array2[num5 - 2]).coroutine_0 = (Coroutine)array2[num5 - 1];
																					goto IL_0c4e;
																				}
																				break;
																			}
																			goto IL_041f;
																			IL_0873:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_08d5;
																			IL_041f:
																			if (11 <= b)
																			{
																				goto IL_042a;
																			}
																			goto IL_0486;
																			IL_042a:
																			array[num5] = 0;
																			num = 14;
																			goto IL_0441;
																			IL_0441:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)getMinorVersionGet[*(int*)(ptr2 + num3)])();
																			goto IL_0465;
																			IL_0465:
																			num5++;
																			goto IL_0473;
																			IL_0473:
																			ptr2 += 8;
																			goto end_IL_0414;
																			IL_0486:
																			if (5 >= b)
																			{
																				goto IL_0491;
																			}
																			goto IL_04a4;
																			IL_0491:
																			if (5 > b)
																			{
																				goto IL_05da;
																			}
																			goto IL_0665;
																			IL_05da:
																			if (2 >= b)
																			{
																				goto IL_05e5;
																			}
																			goto IL_05f8;
																			IL_05e5:
																			if (2 <= b)
																			{
																				goto IL_0781;
																			}
																			goto IL_08e8;
																			IL_08e8:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_08f6;
																			IL_08f6:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0904;
																			IL_0904:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																			goto IL_091d;
																			IL_091d:
																			array[num5] = 0;
																			goto IL_092b;
																			IL_092b:
																			num5++;
																			goto IL_0939;
																			IL_0939:
																			ptr2 += 8;
																			goto end_IL_0414;
																			IL_0781:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_07c1;
																			IL_07c1:
																			array[num5 - 2] = 0;
																			goto IL_07d5;
																			IL_07d5:
																			num5--;
																			goto end_IL_0414;
																			IL_05f8:
																			if (3 >= b)
																			{
																				goto IL_0603;
																			}
																			goto IL_063f;
																			IL_0603:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0611;
																			IL_0611:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06d5;
																			IL_06d5:
																			ptr2 += 8;
																			goto IL_06e3;
																			IL_06e3:
																			num5--;
																			num = 93;
																			goto end_IL_0414;
																			IL_063f:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_07e8;
																			IL_07e8:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_07f6;
																			IL_07f6:
																			array[num5] = 0;
																			goto IL_0804;
																			IL_0804:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0827;
																			IL_0827:
																			array2[num5] = null;
																			goto IL_0831;
																			IL_0831:
																			num5++;
																			goto IL_083f;
																			IL_083f:
																			ptr2 += 8;
																			goto end_IL_0414;
																			IL_0665:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_06a5;
																			IL_06a5:
																			array[num5 - 2] = 0;
																			num = 61;
																			goto IL_06c2;
																			IL_06c2:
																			num5--;
																			goto end_IL_0414;
																			IL_04a4:
																			if (8 >= b)
																			{
																				goto IL_04b2;
																			}
																			goto IL_0565;
																			IL_04b2:
																			if (8 > b)
																			{
																				num = 133;
																				goto IL_04c9;
																			}
																			goto IL_09c1;
																			IL_08d5:
																			num5 -= 2;
																			goto end_IL_0414;
																			IL_04c9:
																			if (6 >= b)
																			{
																				goto IL_04d4;
																			}
																			goto IL_0552;
																			IL_04d4:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_04e2;
																			IL_04e2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0522;
																			IL_0522:
																			array[num5 - 2] = 0;
																			num = 78;
																			goto IL_053f;
																			IL_053f:
																			num5--;
																			goto end_IL_0414;
																			IL_0552:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_094c;
																			IL_094c:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_095a;
																			IL_095a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_099a;
																			IL_099a:
																			array[num5 - 2] = 0;
																			goto IL_09ae;
																			IL_09ae:
																			num5--;
																			goto end_IL_0414;
																			IL_09c1:
																			num5--;
																			goto end_IL_0414;
																			IL_0565:
																			if (9 >= b)
																			{
																				goto IL_0573;
																			}
																			goto IL_0652;
																			IL_0573:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_0581;
																			IL_0581:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_05c1;
																			IL_05c1:
																			array[num5 - 2] = 0;
																			goto IL_0852;
																			IL_0852:
																			num5--;
																			goto end_IL_0414;
																			IL_0652:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0865;
																			IL_0865:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0873;
																		}
																		break;
																		IL_03e4:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0414;
																continue;
																end_IL_03f4:
																break;
															}
															continue;
															end_IL_0404:
															break;
														}
														continue;
														end_IL_0414:
														break;
													}
													continue;
													end_IL_0c71:
													break;
												}
												continue;
												end_IL_0c84:
												break;
											}
											continue;
											end_IL_0c8e:
											break;
										}
										continue;
										end_IL_0c99:
										break;
									}
									continue;
									end_IL_0ca9:
									break;
								}
								continue;
								end_IL_0cb9:
								break;
							}
							continue;
							end_IL_0cd2:
							break;
						}
						continue;
						end_IL_0ce2:
						break;
					}
					continue;
					end_IL_0cf2:
					break;
				}
				continue;
				end_IL_0d02:
				break;
			}
		}
	}

	private unsafe void method_1()
	{
		int num = 152;
		byte b = default(byte);
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 147;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											array5[0] = this;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AptcagetVisualizerObjectSourceTypeName.getMutexRightsGetXmlNamespaceForMethodCall);
												while (true)
												{
													byte* ptr2 = ptr;
													num = 266;
													while (true)
													{
														if (num != 266)
														{
															if (num != 1247)
															{
																goto IL_071b;
															}
															switch (num)
															{
															case 188:
																goto end_IL_0437;
															case 210:
																goto end_IL_044a;
															case 46:
																goto end_IL_045d;
															case 241:
																goto end_IL_0468;
															case 47:
																goto end_IL_0478;
															case 49:
															case 253:
																goto end_IL_0488;
															case 124:
																goto end_IL_0498;
															case 149:
																goto end_IL_04a8;
															case 147:
																goto end_IL_04b8;
															case 151:
																goto end_IL_04c8;
															case 152:
																goto end_IL_04d8;
															case 177:
															case 229:
																goto IL_04fc;
															case 82:
																goto IL_0505;
															case 131:
																goto IL_0513;
															case 123:
																goto IL_0521;
															case 21:
																goto IL_0538;
															case 153:
																goto IL_0546;
															case 92:
																goto IL_0554;
															case 62:
																goto IL_0562;
															case 25:
																goto IL_0570;
															case 155:
																goto IL_057e;
															case 202:
																goto IL_058c;
															case 20:
																goto IL_059a;
															case 160:
																goto IL_05a8;
															case 158:
															case 242:
																goto IL_05b6;
															case 103:
																goto IL_05f6;
															case 16:
																goto IL_060a;
															case 87:
															case 116:
																goto IL_0626;
															case 79:
																goto IL_0666;
															case 22:
																goto IL_067a;
															case 240:
																goto IL_068d;
															case 175:
																goto IL_069b;
															case 36:
															case 144:
																goto IL_06a9;
															case 7:
																goto IL_06e9;
															case 142:
																goto IL_06fd;
															case 212:
																goto IL_0710;
															case 63:
															case 244:
																goto IL_071b;
															case 243:
																goto IL_0729;
															case 132:
																goto IL_074c;
															case 81:
																goto IL_0756;
															case 115:
																goto IL_0764;
															case 237:
																goto IL_0777;
															case 108:
																goto IL_0785;
															case 42:
															case 245:
																goto IL_0790;
															case 70:
																goto IL_07d0;
															case 44:
																goto IL_07e4;
															case 101:
																goto IL_07f7;
															case 120:
																goto IL_0805;
															case 8:
															case 109:
																goto IL_0813;
															case 57:
																goto IL_082c;
															case 88:
																goto IL_083a;
															case 201:
																goto IL_0851;
															case 83:
																goto IL_0864;
															case 80:
																goto IL_0872;
															case 119:
															case 249:
																goto IL_0880;
															case 179:
																goto IL_08a9;
															case 163:
																goto IL_08b7;
															case 133:
															case 238:
																goto IL_08ca;
															case 207:
																goto IL_08dd;
															case 122:
																goto IL_08eb;
															case 145:
																goto IL_08f9;
															case 216:
																goto IL_0907;
															case 51:
															case 224:
																goto IL_0912;
															case 200:
																goto IL_0974;
															case 129:
																goto IL_0987;
															case 166:
																goto IL_0995;
															case 110:
															case 234:
																goto IL_09a3;
															case 60:
																goto IL_09e3;
															case 211:
																goto IL_09f7;
															case 256:
																goto IL_0a0a;
															case 165:
																goto IL_0a18;
															case 29:
															case 189:
																goto IL_0a26;
															case 30:
																goto IL_0a3a;
															case 130:
																goto IL_0a79;
															case 41:
																goto IL_0a8c;
															case 86:
																goto IL_0a9a;
															case 61:
															case 146:
																goto IL_0aa5;
															case 99:
																goto IL_0abd;
															case 2:
																goto IL_0acb;
															case 23:
															case 138:
																goto IL_0ad9;
															case 117:
																goto IL_0af2;
															case 0:
																goto IL_0b00;
															case 220:
																goto IL_0b0e;
															case 172:
																goto IL_0b21;
															case 259:
																goto IL_0b2f;
															case 14:
															case 222:
																goto IL_0b3d;
															case 125:
																goto IL_0b7e;
															case 194:
																goto IL_0b9b;
															case 230:
															case 236:
																goto IL_0bae;
															case 164:
																goto IL_0c00;
															case 56:
																goto IL_0c13;
															case 105:
																goto IL_0c21;
															case 65:
															case 102:
																goto IL_0c2c;
															case 33:
																goto IL_0c64;
															case 67:
																goto IL_0c78;
															case 199:
																goto IL_0c8b;
															case 170:
																goto IL_0c99;
															case 90:
																goto IL_0ca7;
															case 137:
																goto IL_0cb5;
															case 69:
															case 182:
																goto IL_0cc0;
															case 52:
																goto IL_0cd3;
															case 68:
																goto IL_0ce1;
															case 246:
																goto IL_0cf4;
															case 111:
																goto IL_0d02;
															case 9:
															case 173:
																goto IL_0d10;
															case 26:
																goto IL_0d28;
															case 187:
																goto IL_0d36;
															case 181:
																goto IL_0d44;
															case 121:
																goto IL_0d57;
															case 5:
																goto IL_0d65;
															case 77:
															case 106:
																goto IL_0d73;
															case 72:
																goto IL_0d9b;
															case 104:
															case 140:
																goto IL_0dae;
															case 139:
																goto IL_0dc7;
															case 97:
																goto IL_0dd5;
															case 13:
																goto IL_0dec;
															case 221:
																goto IL_0e08;
															case 136:
																goto IL_0e16;
															case 206:
																goto IL_0e24;
															case 48:
																goto IL_0e32;
															case 197:
															case 258:
																goto IL_0e40;
															case 96:
																goto IL_0e80;
															case 190:
																goto IL_0e94;
															case 235:
															case 248:
																goto IL_0ea7;
															case 218:
																goto IL_0ebb;
															case 214:
																goto IL_0efa;
															case 4:
																goto IL_0f0d;
															case 45:
																goto IL_0f1b;
															case 50:
															case 255:
																goto IL_0f32;
															case 186:
																goto IL_0f40;
															case 225:
																goto IL_0f5e;
															case 174:
																goto IL_0f75;
															case 219:
																goto IL_0f88;
															case 251:
																goto IL_0f96;
															case 180:
																goto IL_0fa4;
															case 113:
																goto IL_0fb2;
															case 55:
															case 183:
																goto IL_0fbd;
															case 98:
																goto IL_0fe8;
															case 76:
																goto IL_1001;
															case 203:
																goto IL_100f;
															case 15:
															case 35:
																goto IL_101d;
															case 31:
																goto IL_105a;
															case 95:
																goto IL_1068;
															case 128:
																goto IL_107b;
															case 205:
																goto IL_1089;
															case 3:
															case 94:
																goto IL_1097;
															case 40:
																goto IL_10df;
															case 74:
															case 195:
																goto IL_10f2;
															case 191:
																goto IL_1106;
															case 78:
																goto IL_114e;
															case 213:
																goto IL_1161;
															case 114:
																goto IL_116c;
															case 107:
																goto IL_117a;
															case 192:
																goto IL_118d;
															case 19:
															case 118:
																goto IL_1198;
															case 1:
																goto IL_11b4;
															case 250:
																goto IL_11bf;
															case 226:
															case 228:
																goto IL_11ca;
															case 127:
																goto IL_120a;
															case 157:
																goto IL_121e;
															case 11:
															case 24:
															case 37:
															case 38:
															case 43:
															case 53:
															case 54:
															case 58:
															case 59:
															case 64:
															case 85:
															case 91:
															case 126:
															case 150:
															case 154:
															case 156:
															case 161:
															case 162:
															case 167:
															case 168:
															case 178:
															case 184:
															case 185:
															case 196:
															case 204:
															case 208:
															case 215:
															case 217:
															case 227:
															case 233:
															case 239:
															case 247:
															case 254:
															case 257:
																goto IL_122e;
															case 6:
															case 10:
															case 12:
															case 17:
															case 18:
															case 27:
															case 28:
															case 32:
															case 34:
															case 39:
															case 66:
															case 71:
															case 73:
															case 75:
															case 84:
															case 89:
															case 93:
															case 100:
															case 134:
															case 135:
															case 141:
															case 143:
															case 148:
															case 159:
															case 169:
															case 176:
															case 193:
															case 198:
															case 209:
															case 223:
															case 231:
															case 232:
															case 252:
																goto IL_1241;
															case 112:
															case 171:
																return;
															}
															continue;
														}
														goto IL_1241;
														IL_11bf:
														if (29 <= b)
														{
															goto IL_11ca;
														}
														goto IL_122e;
														IL_11ca:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_120a;
														IL_1241:
														if (num6 == 1)
														{
															return;
														}
														goto IL_04fc;
														IL_04fc:
														b = *ptr2;
														goto IL_0505;
														IL_0505:
														ptr2++;
														goto IL_0513;
														IL_0513:
														if (b >= 1)
														{
															goto IL_0521;
														}
														goto IL_122e;
														IL_0521:
														if (b <= 31)
														{
															num = 21;
															goto IL_0538;
														}
														goto IL_122e;
														IL_120a:
														array[num5 - 2] = 3;
														goto IL_121e;
														IL_0538:
														if (16 >= b)
														{
															goto IL_0546;
														}
														goto IL_0c13;
														IL_0546:
														if (16 > b)
														{
															goto IL_0554;
														}
														goto IL_0bae;
														IL_0554:
														if (8 >= b)
														{
															goto IL_0562;
														}
														goto IL_08dd;
														IL_0562:
														if (8 > b)
														{
															goto IL_0570;
														}
														goto IL_08ca;
														IL_0570:
														if (4 < b)
														{
															goto IL_057e;
														}
														goto IL_0710;
														IL_057e:
														if (6 >= b)
														{
															goto IL_058c;
														}
														goto IL_068d;
														IL_058c:
														if (6 > b)
														{
															goto IL_059a;
														}
														num = 87;
														goto IL_0626;
														IL_059a:
														if (5 >= b)
														{
															goto IL_05a8;
														}
														goto IL_122e;
														IL_05a8:
														if (5 <= b)
														{
															goto IL_05b6;
														}
														goto IL_122e;
														IL_05b6:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_05f6;
														IL_05f6:
														array[num5 - 2] = 0;
														goto IL_060a;
														IL_060a:
														num5--;
														goto IL_1241;
														IL_121e:
														num5--;
														goto IL_1241;
														IL_0626:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0666;
														IL_0666:
														array[num5 - 2] = 0;
														goto IL_067a;
														IL_067a:
														num5--;
														goto IL_1241;
														IL_068d:
														if (7 >= b)
														{
															goto IL_069b;
														}
														goto IL_122e;
														IL_069b:
														if (7 <= b)
														{
															goto IL_06a9;
														}
														goto IL_122e;
														IL_06a9:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_06e9;
														IL_06e9:
														array[num5 - 2] = 0;
														goto IL_06fd;
														IL_06fd:
														num5--;
														goto IL_1241;
														IL_0710:
														if (4 <= b)
														{
															goto IL_071b;
														}
														goto IL_0777;
														IL_071b:
														array[num5] = 0;
														goto IL_0729;
														IL_0729:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
														goto IL_074c;
														IL_074c:
														array2[num5] = null;
														goto IL_0756;
														IL_0756:
														num5++;
														goto IL_0764;
														IL_0764:
														ptr2 += 8;
														goto IL_1241;
														IL_0777:
														if (2 >= b)
														{
															goto IL_0785;
														}
														goto IL_0864;
														IL_0785:
														if (2 <= b)
														{
															goto IL_0790;
														}
														goto IL_07f7;
														IL_0790:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_07d0;
														IL_07d0:
														array[num5 - 2] = 0;
														goto IL_07e4;
														IL_07e4:
														num5--;
														goto IL_1241;
														IL_07f7:
														if (1 >= b)
														{
															goto IL_0805;
														}
														goto IL_122e;
														IL_0805:
														if (1 <= b)
														{
															goto IL_0813;
														}
														goto IL_122e;
														IL_0813:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
														goto IL_082c;
														IL_082c:
														array[num5] = 0;
														goto IL_083a;
														IL_083a:
														num5++;
														num = 201;
														goto IL_0851;
														IL_0851:
														ptr2 += 8;
														goto IL_1241;
														IL_0864:
														if (3 >= b)
														{
															goto IL_0872;
														}
														goto IL_122e;
														IL_0872:
														if (3 <= b)
														{
															goto IL_0880;
														}
														goto IL_122e;
														IL_0880:
														ref int reference = ref array3[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_08a9;
														IL_08a9:
														ptr2 += 8;
														goto IL_08b7;
														IL_08b7:
														num5--;
														goto IL_1241;
														IL_08ca:
														num5--;
														goto IL_1241;
														IL_08dd:
														if (12 >= b)
														{
															goto IL_08eb;
														}
														goto IL_0a8c;
														IL_08eb:
														if (12 > b)
														{
															goto IL_08f9;
														}
														goto IL_1241;
														IL_08f9:
														if (10 >= b)
														{
															goto IL_0907;
														}
														goto IL_0a0a;
														IL_0907:
														if (10 <= b)
														{
															goto IL_0912;
														}
														goto IL_0987;
														IL_0912:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0974;
														IL_0974:
														num5 -= 2;
														goto IL_1241;
														IL_0987:
														if (9 >= b)
														{
															goto IL_0995;
														}
														goto IL_122e;
														IL_0995:
														if (9 <= b)
														{
															goto IL_09a3;
														}
														goto IL_122e;
														IL_09a3:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_09e3;
														IL_09e3:
														array[num5 - 2] = 0;
														goto IL_09f7;
														IL_09f7:
														num5--;
														goto IL_1241;
														IL_0a0a:
														if (11 >= b)
														{
															goto IL_0a18;
														}
														goto IL_122e;
														IL_0a18:
														if (11 <= b)
														{
															goto IL_0a26;
														}
														goto IL_122e;
														IL_0a26:
														array[num5 - 1] = 0;
														goto IL_0a3a;
														IL_0a3a:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)AsyncDelegateStackEnumerator[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
														goto IL_0a79;
														IL_0a79:
														ptr2 += 8;
														goto IL_1241;
														IL_0a8c:
														if (14 >= b)
														{
															goto IL_0a9a;
														}
														goto IL_0b21;
														IL_0a9a:
														if (14 <= b)
														{
															goto IL_0aa5;
														}
														goto IL_0abd;
														IL_0aa5:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_1241;
														IL_0abd:
														if (13 >= b)
														{
															goto IL_0acb;
														}
														goto IL_122e;
														IL_0acb:
														if (13 <= b)
														{
															goto IL_0ad9;
														}
														goto IL_122e;
														IL_0ad9:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)(ptr2 + num4);
														goto IL_0af2;
														IL_0af2:
														array[num5] = 1;
														goto IL_0b00;
														IL_0b00:
														num5++;
														goto IL_0b0e;
														IL_0b0e:
														ptr2 += 16;
														goto IL_1241;
														IL_0b21:
														if (15 >= b)
														{
															goto IL_0b2f;
														}
														goto IL_122e;
														IL_0b2f:
														if (15 <= b)
														{
															goto IL_0b3d;
														}
														goto IL_122e;
														IL_0b3d:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0);
														goto IL_0b7e;
														IL_0b7e:
														array[num5 - 2] = 0;
														num = 194;
														goto IL_0b9b;
														IL_0b9b:
														num5--;
														goto IL_1241;
														IL_0bae:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0c00;
														IL_0c00:
														num5--;
														goto IL_1241;
														IL_0c13:
														if (24 >= b)
														{
															goto IL_0c21;
														}
														goto IL_0f88;
														IL_0c21:
														if (24 <= b)
														{
															goto IL_0c2c;
														}
														goto IL_0c8b;
														IL_0c2c:
														array2[num5 - 1] = ((delegate*<Class159, Coroutine>)AsyncDelegateStackEnumerator[*(int*)(ptr2 + num3)])((Class159)array2[num5 - 1]);
														goto IL_0c64;
														IL_0c64:
														array[num5 - 1] = 5;
														goto IL_0c78;
														IL_0c78:
														ptr2 += 8;
														goto IL_1241;
														IL_0c8b:
														if (20 >= b)
														{
															goto IL_0c99;
														}
														goto IL_0e08;
														IL_0c99:
														if (20 > b)
														{
															goto IL_0ca7;
														}
														goto IL_0dae;
														IL_0ca7:
														if (18 >= b)
														{
															goto IL_0cb5;
														}
														goto IL_0d57;
														IL_0cb5:
														if (18 <= b)
														{
															goto IL_0cc0;
														}
														goto IL_0cf4;
														IL_0cc0:
														array2[num5] = null;
														num = 52;
														goto IL_0cd3;
														IL_0cd3:
														array[num5] = 5;
														goto IL_0ce1;
														IL_0ce1:
														num5++;
														goto IL_1241;
														IL_0cf4:
														if (17 >= b)
														{
															goto IL_0d02;
														}
														goto IL_122e;
														IL_0d02:
														if (17 <= b)
														{
															goto IL_0d10;
														}
														goto IL_122e;
														IL_0d10:
														array2[num5] = array5[*(int*)(ptr2 + num3)];
														goto IL_0d28;
														IL_0d28:
														array[num5] = 5;
														goto IL_0d36;
														IL_0d36:
														num5++;
														goto IL_0d44;
														IL_0d44:
														ptr2 += 8;
														goto IL_1241;
														IL_0d57:
														if (19 >= b)
														{
															goto IL_0d65;
														}
														goto IL_122e;
														IL_0d65:
														if (19 <= b)
														{
															goto IL_0d73;
														}
														goto IL_122e;
														IL_0d73:
														((Class159)array2[num5 - 2]).coroutine_0 = (Coroutine)array2[num5 - 1];
														goto IL_0d9b;
														IL_0d9b:
														num5 -= 2;
														goto IL_1241;
														IL_0dae:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(double*)(ptr2 + num4);
														goto IL_0dc7;
														IL_0dc7:
														array[num5] = 3;
														goto IL_0dd5;
														IL_0dd5:
														num5++;
														num = 13;
														goto IL_0dec;
														IL_0dec:
														ptr2 += 16;
														num = 148;
														goto IL_1241;
														IL_0e08:
														if (22 >= b)
														{
															goto IL_0e16;
														}
														goto IL_0f0d;
														IL_0e16:
														if (22 > b)
														{
															goto IL_0e24;
														}
														goto IL_0ea7;
														IL_0e24:
														if (21 >= b)
														{
															goto IL_0e32;
														}
														goto IL_122e;
														IL_0e32:
														if (21 <= b)
														{
															goto IL_0e40;
														}
														goto IL_122e;
														IL_0e40:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0e80;
														IL_0e80:
														array[num5 - 2] = 3;
														goto IL_0e94;
														IL_0e94:
														num5--;
														goto IL_1241;
														IL_0ea7:
														array[num5 - 1] = 0;
														goto IL_0ebb;
														IL_0ebb:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<double, int>)AsyncDelegateStackEnumerator[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
														goto IL_0efa;
														IL_0efa:
														ptr2 += 8;
														goto IL_1241;
														IL_0f0d:
														if (23 >= b)
														{
															goto IL_0f1b;
														}
														goto IL_122e;
														IL_0f1b:
														if (23 <= b)
														{
															num = 50;
															goto IL_0f32;
														}
														goto IL_122e;
														IL_122e:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_1241;
														IL_0f32:
														array[num5] = 5;
														goto IL_0f40;
														IL_0f40:
														array2[num5] = ((delegate*<GorillaTagger>)AsyncDelegateStackEnumerator[*(int*)(ptr2 + num3)])();
														goto IL_0f5e;
														IL_0f5e:
														num5++;
														num = 174;
														goto IL_0f75;
														IL_0f75:
														ptr2 += 8;
														goto IL_1241;
														IL_0f88:
														if (28 >= b)
														{
															goto IL_0f96;
														}
														goto IL_1161;
														IL_0f96:
														if (28 > b)
														{
															goto IL_0fa4;
														}
														goto IL_10f2;
														IL_0fa4:
														if (26 >= b)
														{
															goto IL_0fb2;
														}
														goto IL_107b;
														IL_0fb2:
														if (26 <= b)
														{
															goto IL_0fbd;
														}
														goto IL_1001;
														IL_0fbd:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0fe8;
														IL_0fe8:
														array[num5 - 1] = 0;
														goto IL_1241;
														IL_1001:
														if (25 >= b)
														{
															goto IL_100f;
														}
														goto IL_122e;
														IL_100f:
														if (25 <= b)
														{
															goto IL_101d;
														}
														goto IL_122e;
														IL_101d:
														((delegate*<MonoBehaviour, Coroutine, void>)AsyncDelegateStackEnumerator[*(int*)(ptr2 + num3)])((GorillaTagger)array2[num5 - 2], (Coroutine)array2[num5 - 1]);
														goto IL_105a;
														IL_105a:
														num5 -= 2;
														goto IL_1068;
														IL_1068:
														ptr2 += 8;
														goto IL_1241;
														IL_107b:
														if (27 >= b)
														{
															goto IL_1089;
														}
														goto IL_122e;
														IL_1089:
														if (27 <= b)
														{
															goto IL_1097;
														}
														goto IL_122e;
														IL_1097:
														ptr2 = ((array2[num5 - 1] == null) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_10df;
														IL_10df:
														num5--;
														goto IL_1241;
														IL_10f2:
														array[num5 - 1] = 3;
														goto IL_1106;
														IL_1106:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<double, double>)AsyncDelegateStackEnumerator[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
														num = 78;
														goto IL_114e;
														IL_114e:
														ptr2 += 8;
														goto IL_1241;
														IL_1161:
														if (30 < b)
														{
															goto IL_116c;
														}
														goto IL_118d;
														IL_116c:
														if (31 >= b)
														{
															goto IL_117a;
														}
														goto IL_122e;
														IL_117a:
														if (31 > b)
														{
														}
														goto IL_122e;
														IL_118d:
														if (30 <= b)
														{
															goto IL_1198;
														}
														goto IL_11b4;
														IL_1198:
														byte* num7 = ptr2;
														num6 = 1;
														ptr2 = num7 + -200;
														goto IL_1241;
														IL_11b4:
														if (29 >= b)
														{
															goto IL_11bf;
														}
														goto IL_122e;
														continue;
														end_IL_0437:
														break;
													}
													continue;
													end_IL_044a:
													break;
												}
												continue;
												end_IL_045d:
												break;
											}
											continue;
											end_IL_0468:
											break;
										}
										continue;
										end_IL_0478:
										break;
									}
									continue;
									end_IL_0488:
									break;
								}
								continue;
								end_IL_0498:
								break;
							}
							continue;
							end_IL_04a8:
							break;
						}
						continue;
						end_IL_04b8:
						break;
					}
					continue;
					end_IL_04c8:
					break;
				}
				continue;
				end_IL_04d8:
				break;
			}
		}
	}

	public Class159()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	private unsafe static int smethod_0(int int_1)
	{
		int num = 53;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					num = 81;
					while (true)
					{
						IL_061f:
						byte[] array = new byte[2];
						while (true)
						{
							IL_060f:
							object[] array2 = new object[2];
							while (true)
							{
								IL_05ff:
								int[] array3 = new int[3];
								while (true)
								{
									IL_05ef:
									long[] array4 = new long[2];
									while (true)
									{
										IL_05da:
										array3[0] = int_1;
										while (true)
										{
											IL_05cf:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IEquatablesetExtraInfo.ISOCurrencySymbolgetProcessArchitecture);
											while (true)
											{
												IL_05c5:
												byte* ptr2 = ptr;
												while (true)
												{
													IL_05b2:
													if (num4 != 1)
													{
														while (true)
														{
															IL_0251:
															byte b = *ptr2;
															while (true)
															{
																IL_0241:
																ptr2++;
																while (true)
																{
																	IL_0231:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_0214:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0207:
																						if (8 < b)
																						{
																							while (true)
																							{
																								IL_01f7:
																								if (9 < b)
																								{
																									while (10 >= b)
																									{
																										num = 109;
																										while (true)
																										{
																											if (num != 109)
																											{
																												if (num != 1090)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 88:
																												case 100:
																													goto IL_01e4;
																												case 43:
																													goto IL_01f7;
																												case 8:
																													goto IL_0207;
																												case 48:
																													goto IL_0214;
																												case 16:
																													goto IL_0221;
																												case 18:
																													goto IL_0231;
																												case 95:
																													goto IL_0241;
																												case 21:
																												case 90:
																													goto IL_0251;
																												case 7:
																													goto IL_025c;
																												case 42:
																													goto IL_026c;
																												case 25:
																													goto IL_027a;
																												case 28:
																												case 33:
																													goto IL_0288;
																												case 11:
																													goto IL_0296;
																												case 19:
																												case 46:
																													goto IL_02a9;
																												case 49:
																													goto IL_030d;
																												case 4:
																												case 38:
																													goto IL_031b;
																												case 51:
																													goto IL_0344;
																												case 55:
																													goto IL_0357;
																												case 62:
																												case 66:
																													goto IL_0365;
																												case 44:
																													goto IL_0373;
																												case 74:
																													goto IL_0386;
																												case 61:
																												case 79:
																													goto IL_0399;
																												case 77:
																													goto IL_03a7;
																												case 56:
																													goto IL_03ca;
																												case 13:
																													goto IL_03d4;
																												case 12:
																													goto IL_03e2;
																												case 85:
																													goto IL_03f5;
																												case 17:
																													goto IL_0403;
																												case 5:
																												case 87:
																													goto IL_0416;
																												case 86:
																													goto IL_0439;
																												case 26:
																													goto IL_0447;
																												case 31:
																													goto IL_0455;
																												case 92:
																													goto IL_0468;
																												case 27:
																												case 41:
																													goto IL_0476;
																												case 71:
																													goto IL_04b6;
																												case 60:
																													goto IL_04ca;
																												case 97:
																													goto IL_04dd;
																												case 101:
																													goto IL_04f0;
																												case 37:
																													goto IL_04fb;
																												case 54:
																												case 98:
																													goto IL_0509;
																												case 1:
																													goto IL_0522;
																												case 72:
																													goto IL_0530;
																												case 76:
																													goto IL_053e;
																												case 50:
																												case 102:
																													goto IL_0559;
																												case 65:
																													goto IL_057b;
																												case 47:
																												case 64:
																													goto IL_0586;
																												case 6:
																												case 9:
																												case 10:
																												case 15:
																												case 20:
																												case 22:
																												case 34:
																												case 36:
																												case 39:
																												case 68:
																												case 70:
																												case 73:
																												case 75:
																												case 82:
																												case 83:
																												case 89:
																												case 93:
																												case 94:
																												case 96:
																													goto end_IL_01e4;
																												case 0:
																												case 2:
																												case 3:
																												case 23:
																												case 35:
																												case 40:
																												case 57:
																												case 58:
																												case 59:
																												case 63:
																												case 78:
																												case 80:
																												case 91:
																													goto IL_05b2;
																												case 24:
																													goto IL_05c5;
																												case 14:
																													goto IL_05cf;
																												case 30:
																													goto IL_05da;
																												case 45:
																													goto IL_05ef;
																												case 32:
																												case 84:
																													goto IL_05ff;
																												case 67:
																													goto IL_060f;
																												case 81:
																													goto IL_061f;
																												case 99:
																													goto end_IL_01d1;
																												case 52:
																													goto end_IL_062f;
																												case 53:
																													goto end_IL_063a;
																												case 29:
																												case 69:
																													goto IL_0655;
																												}
																												continue;
																											}
																											if (10 > b)
																											{
																											}
																											goto end_IL_01e4;
																											continue;
																											end_IL_01d1:
																											break;
																										}
																										goto end_IL_0231;
																										continue;
																										end_IL_01e4:
																										break;
																										IL_01e4:;
																									}
																									break;
																								}
																								goto IL_057b;
																								IL_0586:
																								byte* num5 = ptr2;
																								num4 = 1;
																								ptr2 = num5 + -200;
																								goto IL_05b2;
																								IL_057b:
																								if (9 > b)
																								{
																									break;
																								}
																								goto IL_0586;
																							}
																							break;
																						}
																						goto IL_025c;
																						IL_04ca:
																						num6--;
																						goto IL_05b2;
																						IL_025c:
																						if (8 <= b)
																						{
																							goto IL_02a9;
																						}
																						goto IL_0357;
																						IL_02a9:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0386;
																						IL_0386:
																						num6 -= 2;
																						goto IL_05b2;
																						IL_0357:
																						if (6 < b)
																						{
																							goto IL_0365;
																						}
																						goto IL_0468;
																						IL_0365:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0373;
																						IL_0373:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_0416;
																						IL_0416:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0439;
																						IL_0439:
																						array[num6] = 0;
																						goto IL_0447;
																						IL_0447:
																						num6++;
																						goto IL_0455;
																						IL_0455:
																						ptr2 += 8;
																						goto IL_05b2;
																						IL_0468:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0476;
																						IL_0476:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																						goto IL_04b6;
																						IL_04b6:
																						array[num6 - 2] = 0;
																						goto IL_04ca;
																					}
																					break;
																				}
																				goto IL_026c;
																				IL_03d4:
																				num6++;
																				goto IL_03e2;
																				IL_026c:
																				if (5 > b)
																				{
																					goto IL_027a;
																				}
																				goto IL_0399;
																				IL_027a:
																				if (2 < b)
																				{
																					goto IL_0288;
																				}
																				goto IL_030d;
																				IL_0288:
																				if (3 >= b)
																				{
																					goto IL_0296;
																				}
																				goto IL_03f5;
																				IL_0296:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0559;
																				IL_0559:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_05b2;
																				IL_03f5:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0403;
																				IL_0403:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_05b2;
																				IL_030d:
																				if (2 <= b)
																				{
																					goto IL_031b;
																				}
																				goto IL_04f0;
																				IL_031b:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_0344;
																				IL_0344:
																				ptr2 += 8;
																				goto IL_04dd;
																				IL_04dd:
																				num6--;
																				goto IL_05b2;
																				IL_04f0:
																				if (1 < b)
																				{
																					num = 15;
																					break;
																				}
																				goto IL_04fb;
																				IL_04fb:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0509;
																				IL_0509:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																				goto IL_0522;
																				IL_0522:
																				array[num6] = 0;
																				goto IL_0530;
																				IL_0530:
																				num6++;
																				goto IL_053e;
																				IL_053e:
																				ptr2 += 8;
																				goto IL_05b2;
																				IL_03e2:
																				ptr2 += 8;
																				goto IL_05b2;
																				IL_0399:
																				array[num6] = 0;
																				goto IL_03a7;
																				IL_03a7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_03ca;
																				IL_03ca:
																				array2[num6] = null;
																				goto IL_03d4;
																			}
																			break;
																			IL_0221:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto IL_05b2;
																	continue;
																	end_IL_0231:
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													goto IL_0655;
													IL_0655:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					continue;
					end_IL_062f:
					break;
				}
				continue;
				end_IL_063a:
				break;
			}
		}
	}

	private unsafe static int smethod_1()
	{
		int num = 70;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WaitingForActivationGetKeyList.waitingForActivationGetKeyList_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_03cd:
														byte b = *ptr2;
														while (true)
														{
															IL_03bd:
															ptr2++;
															while (true)
															{
																IL_03ad:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_038d:
																			if (9 >= b)
																			{
																				while (9 > b)
																				{
																					while (true)
																					{
																						IL_0370:
																						if (4 >= b)
																						{
																							while (true)
																							{
																								IL_0360:
																								if (4 > b)
																								{
																									while (true)
																									{
																										IL_034d:
																										if (2 >= b)
																										{
																											num = 53;
																											while (true)
																											{
																												IL_033d:
																												if (2 <= b)
																												{
																													while (true)
																													{
																														IL_02fb:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																														while (true)
																														{
																															IL_02dc:
																															array[num5 - 2] = 0;
																															num = 171;
																															while (true)
																															{
																																if (num != 171)
																																{
																																	if (num != 1152)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 128:
																																		goto IL_02dc;
																																	case 97:
																																	case 116:
																																		goto IL_02fb;
																																	case 53:
																																		goto IL_033d;
																																	case 66:
																																		goto IL_034d;
																																	case 131:
																																		goto IL_0360;
																																	case 17:
																																		goto IL_0370;
																																	case 87:
																																		goto IL_037d;
																																	case 94:
																																		goto IL_038d;
																																	case 121:
																																		goto IL_039d;
																																	case 7:
																																		goto IL_03ad;
																																	case 112:
																																		goto IL_03bd;
																																	case 141:
																																	case 160:
																																		goto IL_03cd;
																																	case 4:
																																	case 18:
																																		goto IL_03d8;
																																	case 25:
																																		goto IL_03e6;
																																	case 41:
																																		goto IL_03f3;
																																	case 49:
																																		goto IL_0403;
																																	case 67:
																																		goto IL_0413;
																																	case 0:
																																	case 91:
																																		goto IL_0426;
																																	case 81:
																																	case 113:
																																		goto IL_0454;
																																	case 32:
																																		goto IL_0462;
																																	case 55:
																																	case 103:
																																		goto IL_0470;
																																	case 118:
																																		goto IL_0488;
																																	case 9:
																																	case 124:
																																		goto IL_0498;
																																	case 31:
																																	case 100:
																																		goto IL_04a6;
																																	case 48:
																																		goto IL_04b4;
																																	case 12:
																																		goto IL_04c2;
																																	case 14:
																																	case 42:
																																		goto IL_04d0;
																																	case 89:
																																	case 127:
																																		goto IL_04f5;
																																	case 115:
																																		goto IL_0534;
																																	case 129:
																																		goto IL_0547;
																																	case 51:
																																	case 122:
																																		goto IL_0552;
																																	case 93:
																																		goto end_IL_02c9;
																																	case 40:
																																		goto IL_05c7;
																																	case 96:
																																		goto IL_05d5;
																																	case 38:
																																	case 71:
																																		goto IL_05e3;
																																	case 63:
																																	case 136:
																																		goto IL_05ff;
																																	case 43:
																																		goto IL_0618;
																																	case 3:
																																	case 5:
																																		goto IL_0626;
																																	case 26:
																																		goto IL_0634;
																																	case 6:
																																	case 137:
																																		goto IL_0651;
																																	case 123:
																																		goto IL_065f;
																																	case 61:
																																	case 88:
																																		goto IL_066d;
																																	case 98:
																																		goto IL_0686;
																																	case 37:
																																		goto IL_0694;
																																	case 78:
																																	case 142:
																																		goto IL_06a4;
																																	case 16:
																																		goto IL_06cd;
																																	case 144:
																																		goto IL_06ef;
																																	case 58:
																																	case 145:
																																		goto IL_0702;
																																	case 99:
																																		goto IL_0746;
																																	case 19:
																																		goto IL_075a;
																																	case 147:
																																		goto IL_0776;
																																	case 10:
																																		goto IL_0784;
																																	case 149:
																																		goto IL_0797;
																																	case 95:
																																	case 119:
																																		goto IL_07a5;
																																	case 148:
																																		goto IL_07b3;
																																	case 126:
																																		goto IL_07d6;
																																	case 104:
																																		goto IL_07e0;
																																	case 30:
																																		goto IL_07ee;
																																	case 152:
																																		goto IL_0801;
																																	case 83:
																																		goto IL_080f;
																																	case 159:
																																		goto IL_082b;
																																	case 15:
																																	case 153:
																																		goto IL_0836;
																																	case 102:
																																	case 139:
																																		goto IL_0849;
																																	case 162:
																																		goto IL_085c;
																																	case 130:
																																		goto IL_086a;
																																	case 65:
																																	case 163:
																																		goto IL_0886;
																																	case 105:
																																		goto IL_089d;
																																	case 68:
																																	case 84:
																																		goto IL_08ab;
																																	case 92:
																																		goto IL_08eb;
																																	case 90:
																																		goto IL_08ff;
																																	case 164:
																																		goto IL_0912;
																																	case 45:
																																	case 151:
																																		goto IL_0920;
																																	case 156:
																																		goto IL_0934;
																																	case 73:
																																		goto IL_0988;
																																	case 62:
																																		goto IL_0996;
																																	case 57:
																																	case 143:
																																		goto IL_09bf;
																																	case 64:
																																		goto IL_09dd;
																																	case 108:
																																		goto IL_09eb;
																																	case 1:
																																	case 11:
																																	case 13:
																																	case 22:
																																	case 24:
																																	case 28:
																																	case 29:
																																	case 33:
																																	case 35:
																																	case 36:
																																	case 46:
																																	case 47:
																																	case 52:
																																	case 54:
																																	case 56:
																																	case 59:
																																	case 72:
																																	case 75:
																																	case 82:
																																	case 85:
																																	case 86:
																																	case 106:
																																	case 107:
																																	case 110:
																																	case 125:
																																	case 135:
																																	case 138:
																																	case 154:
																																	case 157:
																																		goto end_IL_039d;
																																	case 2:
																																	case 20:
																																	case 23:
																																	case 34:
																																	case 39:
																																	case 44:
																																	case 60:
																																	case 76:
																																	case 80:
																																	case 101:
																																	case 109:
																																	case 114:
																																	case 132:
																																	case 134:
																																	case 140:
																																	case 146:
																																	case 150:
																																	case 155:
																																	case 158:
																																	case 161:
																																		goto end_IL_037d;
																																	case 111:
																																		goto end_IL_0a0e;
																																	case 74:
																																		goto end_IL_0a21;
																																	case 77:
																																		goto end_IL_0a2b;
																																	case 117:
																																		goto end_IL_0a36;
																																	case 120:
																																	case 133:
																																		goto end_IL_0a46;
																																	case 21:
																																		goto end_IL_0a56;
																																	case 27:
																																	case 79:
																																		goto end_IL_0a66;
																																	case 69:
																																		goto end_IL_0a76;
																																	case 70:
																																		goto end_IL_0a86;
																																	case 8:
																																	case 50:
																																		goto IL_0aaa;
																																	}
																																	continue;
																																}
																																num5--;
																																goto end_IL_037d;
																																continue;
																																end_IL_02c9:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0651;
																												IL_06ef:
																												ptr2 += 8;
																												goto end_IL_037d;
																												IL_0651:
																												if (1 < b)
																												{
																													goto end_IL_039d;
																												}
																												goto IL_065f;
																												IL_065f:
																												if (1 > b)
																												{
																													goto end_IL_039d;
																												}
																												goto IL_066d;
																												IL_066d:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_0686;
																												IL_0686:
																												array[num5] = 0;
																												goto IL_0694;
																												IL_0694:
																												num5++;
																												goto IL_06ef;
																											}
																											break;
																										}
																										goto IL_03f3;
																										IL_06a4:
																										array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_06cd;
																										IL_06cd:
																										array[num5 - 1] = 5;
																										num = 114;
																										goto end_IL_037d;
																										IL_03f3:
																										if (3 < b)
																										{
																											goto end_IL_039d;
																										}
																										goto IL_0413;
																										IL_0413:
																										if (3 > b)
																										{
																											goto end_IL_039d;
																										}
																										goto IL_06a4;
																									}
																									break;
																								}
																								num = 143;
																								goto IL_09bf;
																								IL_09dd:
																								ptr2 += 8;
																								goto IL_09eb;
																								IL_09eb:
																								num5--;
																								goto end_IL_037d;
																								IL_09bf:
																								array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																								goto IL_09dd;
																							}
																							break;
																						}
																						goto IL_03d8;
																						IL_04f5:
																						((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0534;
																						IL_03d8:
																						if (6 < b)
																						{
																							goto IL_03e6;
																						}
																						goto IL_0488;
																						IL_03e6:
																						if (7 >= b)
																						{
																							goto IL_0403;
																						}
																						goto IL_0454;
																						IL_0454:
																						if (8 < b)
																						{
																							goto end_IL_039d;
																						}
																						goto IL_0462;
																						IL_0462:
																						if (8 > b)
																						{
																							goto end_IL_039d;
																						}
																						goto IL_0470;
																						IL_0470:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto end_IL_037d;
																						IL_0403:
																						if (7 > b)
																						{
																							goto end_IL_039d;
																						}
																						goto IL_0426;
																						IL_0426:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_085c;
																						IL_085c:
																						ptr2 += 8;
																						goto IL_086a;
																						IL_086a:
																						num5--;
																						num = 39;
																						goto end_IL_037d;
																						IL_0488:
																						if (6 <= b)
																						{
																							goto IL_04f5;
																						}
																						goto IL_05ff;
																						IL_05ff:
																						if (5 < b)
																						{
																							num = 85;
																							goto end_IL_039d;
																						}
																						goto IL_0618;
																						IL_0534:
																						num5 -= 3;
																						goto end_IL_037d;
																						IL_0618:
																						if (5 > b)
																						{
																							goto end_IL_039d;
																						}
																						goto IL_0626;
																						IL_0626:
																						array[num5] = 5;
																						goto IL_0634;
																						IL_0634:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0776;
																						IL_0776:
																						num5++;
																						goto IL_0784;
																						IL_0784:
																						ptr2 += 8;
																						goto end_IL_037d;
																					}
																					goto IL_05b4;
																					continue;
																					end_IL_037d:
																					break;
																					IL_037d:;
																				}
																				break;
																			}
																			goto IL_0498;
																			IL_089d:
																			if (12 > b)
																			{
																				goto end_IL_039d;
																			}
																			goto IL_08ab;
																			IL_0498:
																			if (13 < b)
																			{
																				goto IL_04a6;
																			}
																			goto IL_0547;
																			IL_04a6:
																			if (15 < b)
																			{
																				goto IL_04b4;
																			}
																			goto IL_082b;
																			IL_04b4:
																			if (16 >= b)
																			{
																				goto IL_04c2;
																			}
																			goto IL_0801;
																			IL_04c2:
																			if (16 > b)
																			{
																				goto end_IL_039d;
																			}
																			goto IL_04d0;
																			IL_04d0:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 2;
																			break;
																			IL_0801:
																			if (17 < b)
																			{
																				goto end_IL_039d;
																			}
																			goto IL_080f;
																			IL_080f:
																			if (17 <= b)
																			{
																				num = 106;
																			}
																			goto end_IL_039d;
																			IL_08ab:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_08eb;
																			IL_082b:
																			if (15 > b)
																			{
																				goto IL_0836;
																			}
																			goto IL_0849;
																			IL_0836:
																			if (14 < b)
																			{
																				goto end_IL_039d;
																			}
																			goto IL_0912;
																			IL_0912:
																			if (14 > b)
																			{
																				goto end_IL_039d;
																			}
																			goto IL_0920;
																			IL_0920:
																			array[num5 - 2] = 0;
																			goto IL_0934;
																			IL_0934:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((delegate*<int, int, int>)GetDigitValuegetFormatJapaneseFirstYearAsANumber[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																			goto IL_0988;
																			IL_0988:
																			num5--;
																			goto IL_0996;
																			IL_0996:
																			ptr2 += 8;
																			break;
																			IL_0849:
																			num5--;
																			break;
																			IL_0547:
																			if (13 <= b)
																			{
																				goto IL_0552;
																			}
																			goto IL_05c7;
																			IL_0552:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_05b4;
																			IL_05b4:
																			num5 -= 2;
																			break;
																			IL_05c7:
																			if (11 >= b)
																			{
																				goto IL_05d5;
																			}
																			goto IL_0886;
																			IL_05d5:
																			if (11 > b)
																			{
																				goto IL_05e3;
																			}
																			goto IL_0702;
																			IL_05e3:
																			if (10 < b)
																			{
																				goto end_IL_039d;
																			}
																			num = 149;
																			goto IL_0797;
																			IL_08eb:
																			array[num5 - 2] = 0;
																			goto IL_08ff;
																			IL_0797:
																			if (10 > b)
																			{
																				goto end_IL_039d;
																			}
																			goto IL_07a5;
																			IL_07a5:
																			array[num5] = 0;
																			goto IL_07b3;
																			IL_07b3:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_07d6;
																			IL_07d6:
																			array2[num5] = null;
																			goto IL_07e0;
																			IL_07e0:
																			num5++;
																			goto IL_07ee;
																			IL_07ee:
																			ptr2 += 8;
																			break;
																			IL_0702:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_0746;
																			IL_0746:
																			array[num5 - 2] = 0;
																			goto IL_075a;
																			IL_075a:
																			num5--;
																			num = 101;
																			break;
																			IL_0886:
																			if (12 < b)
																			{
																				goto end_IL_039d;
																			}
																			num = 105;
																			goto IL_089d;
																			IL_08ff:
																			num5--;
																			break;
																		}
																		goto end_IL_03ad;
																		continue;
																		end_IL_039d:
																		break;
																		IL_039d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_03ad:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												num = 50;
												goto IL_0aaa;
												IL_0aaa:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0a0e:
												break;
											}
											continue;
											end_IL_0a21:
											break;
										}
										continue;
										end_IL_0a2b:
										break;
									}
									continue;
									end_IL_0a36:
									break;
								}
								continue;
								end_IL_0a46:
								break;
							}
							continue;
							end_IL_0a56:
							break;
						}
						continue;
						end_IL_0a66:
						break;
					}
					continue;
					end_IL_0a76:
					break;
				}
				continue;
				end_IL_0a86:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1)
	{
		int num = 21;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				num = 31;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 66;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SignStaticIndexRangePartitionerForArray.SupportsDynamicPartitionsBinaryCrossAppDomainMap);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 76;
															while (true)
															{
																IL_023d:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0220:
																			if (5 < b)
																			{
																				while (true)
																				{
																					IL_0210:
																					if (8 < b)
																					{
																						while (true)
																						{
																							IL_0203:
																							if (9 < b)
																							{
																								while (10 >= b)
																								{
																									while (10 <= b)
																									{
																										num = 108;
																										while (num != 108)
																										{
																											if (num != 1089)
																											{
																												goto IL_04de;
																											}
																											switch (num)
																											{
																											case 23:
																												goto IL_01e0;
																											case 14:
																												goto IL_01f3;
																											case 57:
																												goto IL_0203;
																											case 6:
																												goto IL_0210;
																											case 42:
																												goto IL_0220;
																											case 39:
																												goto IL_022d;
																											case 76:
																												goto IL_023d;
																											case 46:
																												goto end_IL_023d;
																											case 27:
																											case 41:
																												goto end_IL_024d;
																											case 0:
																												goto IL_0271;
																											case 52:
																												goto IL_0284;
																											case 37:
																												goto IL_028f;
																											case 24:
																												goto IL_029d;
																											case 13:
																											case 36:
																												goto IL_02a8;
																											case 28:
																												goto IL_02d1;
																											case 44:
																											case 58:
																												goto IL_02ea;
																											case 71:
																												goto IL_02fd;
																											case 18:
																												goto IL_030b;
																											case 2:
																											case 73:
																												goto IL_031e;
																											case 88:
																												goto IL_033a;
																											case 38:
																											case 90:
																												goto IL_034d;
																											case 59:
																												goto IL_0358;
																											case 50:
																												goto IL_0368;
																											case 65:
																												goto IL_0376;
																											case 4:
																											case 93:
																												goto IL_0389;
																											case 94:
																												goto IL_03a1;
																											case 80:
																												goto IL_03c4;
																											case 9:
																												goto IL_03ce;
																											case 17:
																												goto IL_03dc;
																											case 12:
																											case 99:
																												goto IL_03ef;
																											case 86:
																												goto IL_0408;
																											case 54:
																												goto IL_0416;
																											case 33:
																												goto IL_0424;
																											case 81:
																												goto IL_0437;
																											case 25:
																											case 98:
																												goto IL_0442;
																											case 67:
																												goto IL_04a4;
																											case 70:
																												goto IL_04b7;
																											case 87:
																											case 92:
																												goto IL_04c2;
																											case 34:
																												goto IL_04d0;
																											case 49:
																											case 74:
																												goto IL_04de;
																											case 45:
																												goto IL_0501;
																											case 53:
																												goto IL_050f;
																											case 60:
																												goto IL_0526;
																											case 64:
																												goto IL_0539;
																											case 15:
																											case 84:
																												goto IL_0544;
																											case 40:
																												goto IL_0584;
																											case 78:
																												goto IL_0598;
																											case 3:
																											case 26:
																											case 35:
																											case 43:
																											case 48:
																											case 56:
																											case 61:
																											case 68:
																											case 69:
																											case 72:
																											case 79:
																											case 85:
																											case 89:
																											case 91:
																											case 95:
																											case 96:
																											case 97:
																											case 101:
																												goto end_IL_01cd;
																											case 5:
																											case 7:
																											case 11:
																											case 16:
																											case 19:
																											case 29:
																											case 30:
																											case 32:
																											case 47:
																											case 55:
																											case 62:
																											case 82:
																											case 83:
																												goto end_IL_0266;
																											case 75:
																												goto end_IL_05bb;
																											case 77:
																												goto end_IL_05ce;
																											case 22:
																												goto end_IL_05d8;
																											case 66:
																												goto end_IL_05e3;
																											case 10:
																											case 63:
																												goto end_IL_05f8;
																											case 51:
																												goto end_IL_0608;
																											case 31:
																											case 100:
																												goto end_IL_0621;
																											case 20:
																												goto end_IL_0631;
																											case 21:
																												goto end_IL_0641;
																											case 1:
																											case 8:
																												goto IL_0665;
																											}
																											continue;
																											end_IL_01cd:
																											break;
																										}
																										break;
																										IL_01e0:;
																									}
																									break;
																									IL_01f3:;
																								}
																								break;
																							}
																							goto IL_0271;
																							IL_031e:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_0266;
																							IL_0271:
																							if (9 > b)
																							{
																								break;
																							}
																							goto IL_031e;
																						}
																						break;
																					}
																					goto IL_0437;
																					IL_0598:
																					num6--;
																					goto end_IL_0266;
																					IL_0437:
																					if (8 <= b)
																					{
																						goto IL_0442;
																					}
																					goto IL_04b7;
																					IL_0442:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_04a4;
																					IL_04a4:
																					num6 -= 2;
																					goto end_IL_0266;
																					IL_04b7:
																					if (6 < b)
																					{
																						goto IL_04c2;
																					}
																					goto IL_0539;
																					IL_04c2:
																					if (7 < b)
																					{
																						break;
																					}
																					goto IL_04d0;
																					IL_04d0:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_04de;
																					IL_04de:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0501;
																					IL_0501:
																					array[num6] = 0;
																					goto IL_050f;
																					IL_050f:
																					num6++;
																					num = 60;
																					goto IL_0526;
																					IL_0526:
																					ptr2 += 8;
																					goto end_IL_0266;
																					IL_0539:
																					if (6 > b)
																					{
																						break;
																					}
																					goto IL_0544;
																					IL_0544:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0584;
																					IL_0584:
																					array[num6 - 2] = 0;
																					goto IL_0598;
																				}
																				break;
																			}
																			goto IL_0284;
																			IL_03dc:
																			ptr2 += 8;
																			goto end_IL_0266;
																			IL_0284:
																			if (5 > b)
																			{
																				goto IL_028f;
																			}
																			goto IL_02ea;
																			IL_028f:
																			if (2 >= b)
																			{
																				goto IL_029d;
																			}
																			goto IL_034d;
																			IL_029d:
																			if (2 <= b)
																			{
																				goto IL_02a8;
																			}
																			goto IL_02fd;
																			IL_02a8:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_02d1;
																			IL_02d1:
																			ptr2 += 8;
																			num = 88;
																			goto IL_033a;
																			IL_033a:
																			num6--;
																			goto end_IL_0266;
																			IL_02fd:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_030b;
																			IL_030b:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_03ef;
																			IL_03ef:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0408;
																			IL_0408:
																			array[num6] = 0;
																			goto IL_0416;
																			IL_0416:
																			num6++;
																			goto IL_0424;
																			IL_0424:
																			ptr2 += 8;
																			goto end_IL_0266;
																			IL_034d:
																			if (3 >= b)
																			{
																				goto IL_0358;
																			}
																			goto IL_0368;
																			IL_0358:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_0389;
																			IL_0389:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0266;
																			IL_0368:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_0376;
																			IL_0376:
																			if (4 <= b)
																			{
																				goto end_IL_0266;
																			}
																			break;
																			IL_02ea:
																			array[num6] = 0;
																			goto IL_03a1;
																			IL_03a1:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_03c4;
																			IL_03c4:
																			array2[num6] = null;
																			goto IL_03ce;
																			IL_03ce:
																			num6++;
																			goto IL_03dc;
																		}
																		break;
																		IL_022d:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0266;
																continue;
																end_IL_023d:
																break;
															}
															continue;
															end_IL_024d:
															break;
														}
														continue;
														end_IL_0266:
														break;
													}
													continue;
												}
												goto IL_0665;
												IL_0665:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_05bb:
												break;
											}
											continue;
											end_IL_05ce:
											break;
										}
										continue;
										end_IL_05d8:
										break;
									}
									continue;
									end_IL_05e3:
									break;
								}
								continue;
								end_IL_05f8:
								break;
							}
							continue;
							end_IL_0608:
							break;
						}
						continue;
						end_IL_0621:
						break;
					}
					continue;
					end_IL_0631:
					break;
				}
				continue;
				end_IL_0641:
				break;
			}
		}
	}

	private unsafe static int smethod_3()
	{
		int num = 107;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 106;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref HIJRIAtIdrefs.IComparerCoClassAttribute);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														num = 91;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0333:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			IL_0316:
																			if (8 >= b)
																			{
																				while (true)
																				{
																					IL_0306:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02f6:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02e6:
																									if (4 > b)
																									{
																										while (true)
																										{
																											IL_02d6:
																											if (2 < b)
																											{
																												while (true)
																												{
																													IL_02c6:
																													if (3 >= b)
																													{
																														while (3 <= b)
																														{
																															while (true)
																															{
																																IL_0282:
																																array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																																num = 152;
																																while (true)
																																{
																																	if (num != 152)
																																	{
																																		if (num != 1133)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 11:
																																		case 89:
																																			goto IL_0282;
																																		case 125:
																																			goto IL_02b6;
																																		case 62:
																																		case 142:
																																			goto IL_02c6;
																																		case 84:
																																		case 96:
																																			goto IL_02d6;
																																		case 72:
																																			goto IL_02e6;
																																		case 34:
																																		case 80:
																																			goto IL_02f6;
																																		case 55:
																																			goto IL_0306;
																																		case 92:
																																			goto IL_0316;
																																		case 113:
																																			goto IL_0323;
																																		case 118:
																																			goto IL_0333;
																																		case 91:
																																			goto end_IL_0333;
																																		case 6:
																																		case 12:
																																			goto end_IL_0343;
																																		case 38:
																																		case 53:
																																			goto IL_0367;
																																		case 10:
																																			goto IL_0372;
																																		case 0:
																																		case 17:
																																			goto IL_037d;
																																		case 7:
																																			goto IL_03c2;
																																		case 1:
																																		case 47:
																																			goto IL_03cd;
																																		case 25:
																																			goto IL_03dd;
																																		case 40:
																																			goto IL_03ed;
																																		case 59:
																																			goto IL_03fb;
																																		case 37:
																																			goto IL_0409;
																																		case 70:
																																		case 73:
																																			goto IL_041c;
																																		case 67:
																																			goto IL_042a;
																																		case 101:
																																			goto IL_043d;
																																		case 26:
																																		case 97:
																																			goto IL_044b;
																																		case 16:
																																			goto IL_048f;
																																		case 69:
																																			goto IL_04a3;
																																		case 103:
																																			goto IL_04b6;
																																		case 46:
																																		case 93:
																																			goto IL_04c4;
																																		case 32:
																																			goto IL_04d2;
																																		case 114:
																																			goto IL_04e2;
																																		case 66:
																																			goto IL_04ff;
																																		case 85:
																																		case 123:
																																			goto IL_0512;
																																		case 110:
																																		case 132:
																																			goto IL_0576;
																																		case 137:
																																			goto IL_0592;
																																		case 76:
																																		case 145:
																																			goto IL_05a5;
																																		case 112:
																																			goto IL_05bc;
																																		case 102:
																																			goto IL_05df;
																																		case 52:
																																			goto IL_05e9;
																																		case 124:
																																			goto IL_05f7;
																																		case 30:
																																			goto IL_0631;
																																		case 81:
																																		case 94:
																																			goto IL_063c;
																																		case 41:
																																			goto IL_067c;
																																		case 128:
																																			goto IL_0690;
																																		case 140:
																																			goto IL_06a3;
																																		case 119:
																																			goto IL_06b1;
																																		case 82:
																																		case 122:
																																			goto IL_06bf;
																																		case 50:
																																			goto IL_06d8;
																																		case 13:
																																			goto IL_06e6;
																																		case 98:
																																			goto IL_06f4;
																																		case 121:
																																		case 141:
																																			goto IL_0707;
																																		case 130:
																																			goto IL_0725;
																																		case 143:
																																			goto IL_0733;
																																		case 56:
																																			goto IL_0746;
																																		case 42:
																																			goto IL_0754;
																																		case 95:
																																		case 139:
																																			goto IL_075f;
																																		case 133:
																																			goto IL_076d;
																																		case 22:
																																		case 117:
																																			goto IL_077b;
																																		case 65:
																																			goto end_IL_026f;
																																		case 64:
																																			goto IL_07aa;
																																		case 49:
																																			goto IL_07b8;
																																		case 79:
																																		case 86:
																																			goto IL_07d4;
																																		case 57:
																																			goto IL_0813;
																																		case 138:
																																			goto IL_0826;
																																		case 144:
																																			goto IL_0831;
																																		case 51:
																																		case 104:
																																			goto IL_083c;
																																		case 21:
																																			goto IL_0865;
																																		case 77:
																																			goto IL_0873;
																																		case 63:
																																		case 111:
																																			goto IL_0883;
																																		case 2:
																																		case 3:
																																		case 4:
																																		case 5:
																																		case 23:
																																		case 27:
																																		case 31:
																																		case 33:
																																		case 35:
																																		case 39:
																																		case 43:
																																		case 58:
																																		case 60:
																																		case 68:
																																		case 75:
																																		case 83:
																																		case 87:
																																		case 99:
																																		case 116:
																																		case 120:
																																		case 126:
																																		case 127:
																																		case 131:
																																		case 135:
																																			goto end_IL_02b6;
																																		case 8:
																																		case 9:
																																		case 14:
																																		case 15:
																																		case 18:
																																		case 36:
																																		case 44:
																																		case 54:
																																		case 61:
																																		case 71:
																																		case 74:
																																		case 78:
																																		case 105:
																																		case 108:
																																		case 115:
																																		case 129:
																																		case 134:
																																		case 136:
																																			goto end_IL_0353;
																																		case 19:
																																			goto end_IL_08ab;
																																		case 28:
																																			goto end_IL_08be;
																																		case 88:
																																			goto end_IL_08c8;
																																		case 48:
																																			goto end_IL_08d3;
																																		case 29:
																																		case 45:
																																			goto end_IL_08e3;
																																		case 20:
																																			goto end_IL_08f3;
																																		case 24:
																																		case 109:
																																			goto end_IL_0903;
																																		case 106:
																																			goto end_IL_0913;
																																		case 107:
																																			goto end_IL_0923;
																																		case 90:
																																		case 100:
																																			goto IL_0947;
																																		}
																																		continue;
																																	}
																																	array[num5 - 1] = 5;
																																	goto end_IL_0353;
																																	continue;
																																	end_IL_026f:
																																	break;
																																}
																																break;
																															}
																															goto IL_0792;
																															continue;
																															end_IL_02b6:
																															break;
																															IL_02b6:;
																														}
																													}
																													else
																													{
																														num = 120;
																													}
																													break;
																												}
																												break;
																											}
																											goto IL_0631;
																											IL_06f4:
																											ptr2 += 8;
																											goto end_IL_0353;
																											IL_0631:
																											if (2 <= b)
																											{
																												goto IL_063c;
																											}
																											goto IL_06a3;
																											IL_063c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											goto IL_067c;
																											IL_067c:
																											array[num5 - 2] = 0;
																											goto IL_0690;
																											IL_0690:
																											num5--;
																											goto end_IL_0353;
																											IL_06a3:
																											if (1 < b)
																											{
																												break;
																											}
																											goto IL_06b1;
																											IL_06b1:
																											if (1 > b)
																											{
																												break;
																											}
																											goto IL_06bf;
																											IL_06bf:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																											goto IL_06d8;
																											IL_06d8:
																											array[num5] = 0;
																											goto IL_06e6;
																											IL_06e6:
																											num5++;
																											goto IL_06f4;
																										}
																										break;
																									}
																									goto IL_0707;
																									IL_0733:
																									num5--;
																									goto end_IL_0353;
																									IL_0707:
																									array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																									goto IL_0725;
																									IL_0725:
																									ptr2 += 8;
																									goto IL_0733;
																								}
																								break;
																							}
																							goto IL_0746;
																							IL_0873:
																							num5--;
																							goto end_IL_0353;
																							IL_0746:
																							if (6 >= b)
																							{
																								goto IL_0754;
																							}
																							goto IL_0826;
																							IL_0754:
																							if (6 > b)
																							{
																								goto IL_075f;
																							}
																							goto IL_07d4;
																							IL_075f:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_076d;
																							IL_076d:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_077b;
																							IL_077b:
																							array[num5] = 5;
																							num = 65;
																							goto IL_0792;
																							IL_0792:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_07aa;
																							IL_07aa:
																							num5++;
																							goto IL_07b8;
																							IL_07b8:
																							ptr2 += 8;
																							num = 8;
																							goto end_IL_0353;
																							IL_07d4:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0813;
																							IL_0813:
																							num5 -= 3;
																							goto end_IL_0353;
																							IL_0826:
																							if (7 < b)
																							{
																								break;
																							}
																							goto IL_0831;
																							IL_0831:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_083c;
																							IL_083c:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0865;
																							IL_0865:
																							ptr2 += 8;
																							goto IL_0873;
																						}
																						break;
																					}
																					goto IL_0883;
																					IL_0883:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0353;
																				}
																				break;
																			}
																			goto IL_0367;
																			IL_0576:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0353;
																			IL_0367:
																			if (12 >= b)
																			{
																				goto IL_0372;
																			}
																			goto IL_03ed;
																			IL_0372:
																			if (12 <= b)
																			{
																				goto IL_037d;
																			}
																			goto IL_03c2;
																			IL_037d:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_04e2;
																			IL_04e2:
																			array[num5 - 2] = 0;
																			num = 66;
																			goto IL_04ff;
																			IL_04ff:
																			num5--;
																			goto end_IL_0353;
																			IL_03c2:
																			if (10 < b)
																			{
																				goto IL_03cd;
																			}
																			goto IL_03dd;
																			IL_03cd:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_043d;
																			IL_043d:
																			if (11 > b)
																			{
																				break;
																			}
																			goto IL_044b;
																			IL_044b:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_048f;
																			IL_048f:
																			array[num5 - 2] = 0;
																			goto IL_04a3;
																			IL_04a3:
																			num5--;
																			goto end_IL_0353;
																			IL_03dd:
																			if (10 > b)
																			{
																				goto IL_041c;
																			}
																			goto IL_05a5;
																			IL_041c:
																			if (9 < b)
																			{
																				break;
																			}
																			goto IL_042a;
																			IL_042a:
																			if (9 <= b)
																			{
																				goto end_IL_0353;
																			}
																			break;
																			IL_05a5:
																			array[num5] = 0;
																			num = 112;
																			goto IL_05bc;
																			IL_05bc:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05df;
																			IL_05df:
																			array2[num5] = null;
																			goto IL_05e9;
																			IL_05e9:
																			num5++;
																			goto IL_05f7;
																			IL_05f7:
																			ptr2 += 8;
																			goto end_IL_0353;
																			IL_03ed:
																			if (14 < b)
																			{
																				goto IL_03fb;
																			}
																			goto IL_04b6;
																			IL_03fb:
																			if (15 < b)
																			{
																				break;
																			}
																			goto IL_0409;
																			IL_0409:
																			if (15 > b)
																			{
																			}
																			break;
																			IL_04b6:
																			if (14 > b)
																			{
																				goto IL_04c4;
																			}
																			goto IL_0576;
																			IL_04c4:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_04d2;
																			IL_04d2:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0512;
																			IL_0512:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0592;
																			IL_0592:
																			num5 -= 2;
																			goto end_IL_0353;
																		}
																		break;
																		IL_0323:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0353;
																continue;
																end_IL_0333:
																break;
															}
															continue;
															end_IL_0343:
															break;
														}
														continue;
														end_IL_0353:
														break;
													}
													continue;
												}
												goto IL_0947;
												IL_0947:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08ab:
												break;
											}
											continue;
											end_IL_08be:
											break;
										}
										continue;
										end_IL_08c8:
										break;
									}
									continue;
									end_IL_08d3:
									break;
								}
								continue;
								end_IL_08e3:
								break;
							}
							continue;
							end_IL_08f3:
							break;
						}
						continue;
						end_IL_0903:
						break;
					}
					continue;
					end_IL_0913:
					break;
				}
				continue;
				end_IL_0923:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1, int int_2)
	{
		int num = 6;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							num = 12;
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref addResourceResolveTlsContents.FullNameNoKey);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_01f4:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_01d4:
																				if (4 < b)
																				{
																					goto IL_0397;
																				}
																				while (true)
																				{
																					IL_01c7:
																					if (4 > b)
																					{
																						while (true)
																						{
																							IL_01b7:
																							if (2 >= b)
																							{
																								while (true)
																								{
																									IL_01a4:
																									if (2 <= b)
																									{
																										num = 93;
																										while (true)
																										{
																											if (num != 93)
																											{
																												if (num != 1074)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 55:
																													goto IL_01a4;
																												case 20:
																													goto IL_01b7;
																												case 84:
																													goto IL_01c7;
																												case 58:
																													goto IL_01d4;
																												case 16:
																													goto end_IL_01d4;
																												case 79:
																													goto IL_01f4;
																												case 67:
																													goto end_IL_01f4;
																												case 30:
																												case 33:
																													goto end_IL_0204;
																												case 23:
																												case 64:
																													goto IL_021f;
																												case 44:
																													goto IL_0248;
																												case 82:
																													goto IL_0256;
																												case 15:
																													goto IL_0269;
																												case 21:
																													goto IL_02e0;
																												case 86:
																													goto IL_02f3;
																												case 13:
																													goto IL_0301;
																												case 83:
																													goto IL_0314;
																												case 68:
																													goto IL_0322;
																												case 60:
																												case 76:
																													goto IL_0330;
																												case 57:
																													goto IL_0370;
																												case 59:
																													goto IL_0384;
																												case 38:
																													goto IL_0397;
																												case 7:
																												case 29:
																													goto IL_03a5;
																												case 10:
																													goto end_IL_0191;
																												case 11:
																													goto IL_03be;
																												case 50:
																												case 62:
																													goto IL_03cc;
																												case 63:
																													goto IL_03e8;
																												case 26:
																												case 66:
																													goto IL_03f6;
																												case 3:
																													goto IL_0404;
																												case 71:
																													goto IL_0430;
																												case 73:
																													goto IL_043a;
																												case 42:
																													goto IL_0451;
																												case 9:
																													goto IL_0464;
																												case 72:
																													goto IL_0472;
																												case 14:
																													goto IL_0486;
																												case 25:
																												case 36:
																													goto IL_0491;
																												case 1:
																												case 2:
																												case 24:
																												case 27:
																												case 28:
																												case 40:
																												case 41:
																												case 45:
																												case 47:
																												case 48:
																												case 51:
																												case 53:
																												case 54:
																												case 65:
																												case 77:
																												case 80:
																												case 81:
																													goto end_IL_01e4;
																												case 69:
																													goto IL_04c9;
																												case 39:
																													goto IL_04d7;
																												case 75:
																													goto IL_04e5;
																												case 8:
																												case 17:
																												case 18:
																												case 19:
																												case 22:
																												case 31:
																												case 34:
																												case 37:
																												case 43:
																												case 49:
																												case 61:
																													goto end_IL_0214;
																												case 70:
																													goto end_IL_04f3;
																												case 85:
																													goto end_IL_0506;
																												case 74:
																													goto end_IL_0510;
																												case 0:
																													goto end_IL_051b;
																												case 12:
																													goto end_IL_0530;
																												case 46:
																												case 52:
																													goto end_IL_0545;
																												case 32:
																													goto end_IL_0555;
																												case 35:
																												case 56:
																													goto end_IL_056e;
																												case 5:
																													goto end_IL_057e;
																												case 6:
																													goto end_IL_058e;
																												case 4:
																												case 78:
																													goto IL_05a9;
																												}
																												continue;
																											}
																											goto IL_0269;
																											IL_0269:
																											ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																											num = 21;
																											goto IL_02e0;
																											IL_02e0:
																											num5 -= 2;
																											goto end_IL_0214;
																											continue;
																											end_IL_0191:
																											break;
																										}
																										break;
																									}
																									goto IL_02f3;
																									IL_02f3:
																									if (1 < b)
																									{
																										goto end_IL_01e4;
																									}
																									goto IL_0301;
																									IL_0301:
																									if (1 <= b)
																									{
																									}
																									goto end_IL_01e4;
																								}
																								break;
																							}
																							goto IL_0314;
																							IL_0384:
																							num5--;
																							goto end_IL_0214;
																							IL_0314:
																							if (3 < b)
																							{
																								goto end_IL_01e4;
																							}
																							goto IL_0322;
																							IL_0322:
																							if (3 > b)
																							{
																								goto end_IL_01e4;
																							}
																							goto IL_0330;
																							IL_0330:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0370;
																							IL_0370:
																							array[num5 - 2] = 0;
																							goto IL_0384;
																						}
																						break;
																					}
																					goto IL_021f;
																					IL_0256:
																					num5--;
																					goto end_IL_0214;
																					IL_021f:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0248;
																					IL_0248:
																					ptr2 += 8;
																					goto IL_0256;
																				}
																				goto IL_03b0;
																				IL_0486:
																				if (5 > b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_0491;
																				IL_0397:
																				if (6 < b)
																				{
																					goto IL_03a5;
																				}
																				goto IL_0464;
																				IL_03a5:
																				if (7 < b)
																				{
																					goto IL_03b0;
																				}
																				goto IL_03e8;
																				IL_03b0:
																				if (8 < b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03be;
																				IL_03be:
																				if (8 > b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03cc;
																				IL_03cc:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0214;
																				IL_03e8:
																				if (7 > b)
																				{
																					goto end_IL_01e4;
																				}
																				goto IL_03f6;
																				IL_03f6:
																				array[num5] = 0;
																				goto IL_0404;
																				IL_0404:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 71;
																				goto IL_0430;
																				IL_0430:
																				array2[num5] = null;
																				goto IL_043a;
																				IL_043a:
																				num5++;
																				num = 42;
																				goto IL_0451;
																				IL_0451:
																				ptr2 += 8;
																				goto end_IL_0214;
																				IL_0464:
																				if (6 <= b)
																				{
																					goto end_IL_0214;
																				}
																				goto IL_0472;
																				IL_0472:
																				if (5 < b)
																				{
																					goto end_IL_01e4;
																				}
																				num = 14;
																				goto IL_0486;
																				IL_0491:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0214;
																				continue;
																				end_IL_01d4:
																				break;
																			}
																			continue;
																			end_IL_01e4:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c9;
																	IL_04e5:
																	ptr2 += 8;
																	goto end_IL_0214;
																	IL_04d7:
																	num5++;
																	goto IL_04e5;
																	IL_04c9:
																	array[num5] = 0;
																	goto IL_04d7;
																	continue;
																	end_IL_01f4:
																	break;
																}
																continue;
																end_IL_0204:
																break;
															}
															continue;
															end_IL_0214:
															break;
														}
														continue;
													}
													goto IL_05a9;
													IL_05a9:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f3:
													break;
												}
												continue;
												end_IL_0506:
												break;
											}
											continue;
											end_IL_0510:
											break;
										}
										continue;
										end_IL_051b:
										break;
									}
									continue;
									end_IL_0530:
									break;
								}
								continue;
								end_IL_0545:
								break;
							}
							continue;
							end_IL_0555:
							break;
						}
						continue;
						end_IL_056e:
						break;
					}
					continue;
					end_IL_057e:
					break;
				}
				continue;
				end_IL_058e:
				break;
			}
		}
	}

	private static int smethod_5(int int_1)
	{
		int num = 0;
		int num2 = 0;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			int num4 = int_1;
			if (num >= num4)
			{
				break;
			}
			num = num2;
			num4 = num3;
			num += num4;
			num2 = num;
			num = num3;
			num4 = 1;
			num++;
			num3 = num;
		}
		return num2;
	}

	private unsafe static int smethod_6()
	{
		int num = 119;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MethodSpecGreen.NativeNameCheckValueWritePermission);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															num = 68;
															while (true)
															{
																IL_0324:
																if (b >= 1)
																{
																	while (b <= 17)
																	{
																		while (true)
																		{
																			IL_0304:
																			if (9 < b)
																			{
																				while (true)
																				{
																					IL_02f4:
																					if (13 < b)
																					{
																						while (true)
																						{
																							IL_02e4:
																							if (15 < b)
																							{
																								while (true)
																								{
																									IL_02d7:
																									if (16 >= b)
																									{
																										while (16 <= b)
																										{
																											num = 165;
																											while (true)
																											{
																												if (num != 165)
																												{
																													if (num != 1146)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 100:
																														goto IL_02c4;
																													case 132:
																														goto IL_02d7;
																													case 18:
																													case 24:
																														goto IL_02e4;
																													case 49:
																													case 124:
																														goto IL_02f4;
																													case 12:
																														goto IL_0304;
																													case 103:
																														goto IL_0314;
																													case 68:
																														goto IL_0324;
																													case 131:
																														goto end_IL_0324;
																													case 32:
																													case 70:
																														goto end_IL_0334;
																													case 33:
																													case 126:
																														goto IL_0358;
																													case 94:
																														goto IL_0366;
																													case 111:
																														goto IL_0379;
																													case 135:
																														goto IL_0395;
																													case 76:
																													case 137:
																														goto IL_03a9;
																													case 6:
																														goto IL_03bc;
																													case 110:
																														goto IL_03ca;
																													case 53:
																													case 106:
																														goto IL_03d8;
																													case 4:
																														goto IL_03ec;
																													case 73:
																														goto IL_0440;
																													case 65:
																														goto IL_044e;
																													case 5:
																														goto IL_0461;
																													case 85:
																													case 152:
																														goto IL_046c;
																													case 99:
																														goto IL_04d7;
																													case 129:
																														goto IL_04ea;
																													case 144:
																														goto IL_04f8;
																													case 1:
																													case 95:
																														goto IL_0503;
																													case 66:
																														goto IL_0511;
																													case 16:
																													case 30:
																														goto end_IL_02b1;
																													case 17:
																														goto IL_052d;
																													case 9:
																														goto IL_0550;
																													case 122:
																														goto IL_055a;
																													case 42:
																														goto IL_0568;
																													case 71:
																													case 78:
																														goto IL_057b;
																													case 57:
																														goto IL_05bf;
																													case 37:
																														goto IL_05d3;
																													case 116:
																														goto IL_05e6;
																													case 23:
																														goto IL_05f4;
																													case 47:
																													case 140:
																														goto IL_0602;
																													case 58:
																														goto IL_0642;
																													case 40:
																														goto IL_0656;
																													case 128:
																														goto IL_0672;
																													case 147:
																														goto IL_0680;
																													case 150:
																														goto IL_068e;
																													case 2:
																													case 96:
																														goto IL_0699;
																													case 88:
																														goto IL_06b7;
																													case 31:
																														goto IL_06c5;
																													case 139:
																													case 156:
																														goto IL_06d8;
																													case 21:
																													case 83:
																														goto IL_06e3;
																													case 93:
																														goto IL_06f1;
																													case 8:
																													case 130:
																														goto IL_06ff;
																													case 38:
																														goto IL_0728;
																													case 28:
																														goto IL_0741;
																													case 108:
																													case 114:
																														goto IL_074c;
																													case 90:
																														goto IL_078c;
																													case 11:
																														goto IL_07a0;
																													case 149:
																														goto IL_07b3;
																													case 113:
																														goto IL_07c1;
																													case 7:
																													case 97:
																														goto IL_07cf;
																													case 61:
																														goto IL_07e8;
																													case 52:
																														goto IL_07f6;
																													case 81:
																														goto IL_0804;
																													case 59:
																														goto IL_0817;
																													case 50:
																														goto IL_0825;
																													case 89:
																													case 92:
																														goto IL_0830;
																													case 155:
																														goto IL_083e;
																													case 36:
																													case 86:
																														goto IL_084c;
																													case 115:
																														goto IL_085a;
																													case 138:
																														goto IL_0872;
																													case 54:
																														goto IL_0889;
																													case 25:
																													case 77:
																														goto IL_089c;
																													case 125:
																														goto IL_08db;
																													case 13:
																														goto IL_08f7;
																													case 145:
																														goto IL_0902;
																													case 39:
																													case 56:
																														goto IL_090d;
																													case 34:
																														goto IL_0936;
																													case 121:
																														goto IL_0944;
																													case 62:
																														goto IL_0954;
																													case 74:
																														goto IL_095f;
																													case 3:
																													case 146:
																														goto IL_096a;
																													case 14:
																													case 19:
																													case 22:
																													case 41:
																													case 45:
																													case 48:
																													case 55:
																													case 63:
																													case 64:
																													case 67:
																													case 69:
																													case 79:
																													case 82:
																													case 87:
																													case 98:
																													case 102:
																													case 105:
																													case 107:
																													case 120:
																													case 123:
																													case 133:
																													case 141:
																													case 151:
																													case 154:
																													case 158:
																														goto end_IL_02c4;
																													case 10:
																													case 20:
																													case 26:
																													case 27:
																													case 29:
																													case 43:
																													case 44:
																													case 46:
																													case 51:
																													case 60:
																													case 75:
																													case 84:
																													case 91:
																													case 104:
																													case 109:
																													case 117:
																													case 127:
																													case 143:
																													case 153:
																													case 157:
																														goto end_IL_034d;
																													case 72:
																														goto end_IL_0992;
																													case 0:
																														goto end_IL_09a5;
																													case 80:
																														goto end_IL_09af;
																													case 148:
																														goto end_IL_09ba;
																													case 35:
																													case 112:
																														goto end_IL_09ca;
																													case 15:
																														goto end_IL_09da;
																													case 134:
																													case 136:
																														goto end_IL_09ea;
																													case 118:
																														goto end_IL_09fa;
																													case 119:
																														goto end_IL_0a0a;
																													case 101:
																													case 142:
																														goto IL_0a25;
																													}
																													continue;
																												}
																												goto IL_0379;
																												IL_0379:
																												byte* num5 = ptr2;
																												num4 = 1;
																												ptr2 = num5 + -200;
																												goto end_IL_034d;
																												continue;
																												end_IL_02b1:
																												break;
																											}
																											goto IL_051f;
																											continue;
																											end_IL_02c4:
																											break;
																											IL_02c4:;
																										}
																										break;
																									}
																									goto IL_0358;
																									IL_0366:
																									if (17 > b)
																									{
																									}
																									break;
																									IL_0358:
																									if (17 < b)
																									{
																										break;
																									}
																									goto IL_0366;
																								}
																								break;
																							}
																							goto IL_0395;
																							IL_0440:
																							num6--;
																							goto IL_044e;
																							IL_0395:
																							if (15 <= b)
																							{
																								num = 137;
																								goto IL_03a9;
																							}
																							goto IL_03bc;
																							IL_044e:
																							ptr2 += 8;
																							goto end_IL_034d;
																							IL_03a9:
																							num6--;
																							goto end_IL_034d;
																							IL_03bc:
																							if (14 < b)
																							{
																								break;
																							}
																							goto IL_03ca;
																							IL_03ca:
																							if (14 > b)
																							{
																								break;
																							}
																							goto IL_03d8;
																							IL_03d8:
																							array[num6 - 2] = 0;
																							goto IL_03ec;
																							IL_03ec:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)TupleChannelURI[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																							goto IL_0440;
																						}
																						break;
																					}
																					goto IL_0461;
																					IL_0656:
																					num6--;
																					num = 91;
																					goto end_IL_034d;
																					IL_0461:
																					if (13 <= b)
																					{
																						goto IL_046c;
																					}
																					goto IL_04ea;
																					IL_046c:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					num = 99;
																					goto IL_04d7;
																					IL_04d7:
																					num6 -= 2;
																					goto end_IL_034d;
																					IL_04ea:
																					if (11 >= b)
																					{
																						goto IL_04f8;
																					}
																					goto IL_05e6;
																					IL_04f8:
																					if (11 > b)
																					{
																						goto IL_0503;
																					}
																					goto IL_057b;
																					IL_0503:
																					if (10 < b)
																					{
																						break;
																					}
																					goto IL_0511;
																					IL_0511:
																					if (10 > b)
																					{
																						break;
																					}
																					goto IL_051f;
																					IL_051f:
																					array[num6] = 0;
																					goto IL_052d;
																					IL_052d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_0550;
																					IL_0550:
																					array2[num6] = null;
																					goto IL_055a;
																					IL_055a:
																					num6++;
																					goto IL_0568;
																					IL_0568:
																					ptr2 += 8;
																					goto end_IL_034d;
																					IL_057b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((int[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_05bf;
																					IL_05bf:
																					array[num6 - 2] = 0;
																					goto IL_05d3;
																					IL_05d3:
																					num6--;
																					goto end_IL_034d;
																					IL_05e6:
																					if (12 < b)
																					{
																						break;
																					}
																					goto IL_05f4;
																					IL_05f4:
																					if (12 > b)
																					{
																						break;
																					}
																					goto IL_0602;
																					IL_0602:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0642;
																					IL_0642:
																					array[num6 - 2] = 0;
																					goto IL_0656;
																				}
																				break;
																			}
																			goto IL_0672;
																			IL_096a:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_034d;
																			IL_0672:
																			if (9 <= b)
																			{
																				goto end_IL_034d;
																			}
																			goto IL_0680;
																			IL_0680:
																			if (4 >= b)
																			{
																				goto IL_068e;
																			}
																			goto IL_0817;
																			IL_068e:
																			if (4 <= b)
																			{
																				goto IL_0699;
																			}
																			goto IL_06d8;
																			IL_0699:
																			array5[*(int*)(ptr2 + num3)] = array2[num6 - 1];
																			goto IL_06b7;
																			IL_06b7:
																			ptr2 += 8;
																			goto IL_06c5;
																			IL_06c5:
																			num6--;
																			goto end_IL_034d;
																			IL_06d8:
																			if (2 < b)
																			{
																				goto IL_06e3;
																			}
																			goto IL_0741;
																			IL_06e3:
																			if (3 < b)
																			{
																				break;
																			}
																			goto IL_06f1;
																			IL_06f1:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_06ff;
																			IL_06ff:
																			array2[num6 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																			goto IL_0728;
																			IL_0728:
																			array[num6 - 1] = 5;
																			goto end_IL_034d;
																			IL_0741:
																			if (2 <= b)
																			{
																				goto IL_074c;
																			}
																			goto IL_07b3;
																			IL_074c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_078c;
																			IL_078c:
																			array[num6 - 2] = 0;
																			goto IL_07a0;
																			IL_07a0:
																			num6--;
																			goto end_IL_034d;
																			IL_07b3:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_07c1;
																			IL_07c1:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_07cf;
																			IL_07cf:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_07e8;
																			IL_07e8:
																			array[num6] = 0;
																			goto IL_07f6;
																			IL_07f6:
																			num6++;
																			goto IL_0804;
																			IL_0804:
																			ptr2 += 8;
																			goto end_IL_034d;
																			IL_0817:
																			if (6 >= b)
																			{
																				goto IL_0825;
																			}
																			goto IL_08f7;
																			IL_0825:
																			if (6 > b)
																			{
																				goto IL_0830;
																			}
																			goto IL_089c;
																			IL_0830:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_083e;
																			IL_083e:
																			if (5 > b)
																			{
																				break;
																			}
																			goto IL_084c;
																			IL_084c:
																			array[num6] = 5;
																			goto IL_085a;
																			IL_085a:
																			array2[num6] = array5[*(int*)(ptr2 + num3)];
																			goto IL_0872;
																			IL_0872:
																			num6++;
																			num = 54;
																			goto IL_0889;
																			IL_0889:
																			ptr2 += 8;
																			goto end_IL_034d;
																			IL_089c:
																			((int[])array2[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_08db;
																			IL_08db:
																			num6 -= 3;
																			num = 75;
																			goto end_IL_034d;
																			IL_08f7:
																			if (7 >= b)
																			{
																				goto IL_0902;
																			}
																			goto IL_0954;
																			IL_0902:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_090d;
																			IL_090d:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0936;
																			IL_0936:
																			ptr2 += 8;
																			goto IL_0944;
																			IL_0944:
																			num6--;
																			goto end_IL_034d;
																			IL_0954:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_095f;
																			IL_095f:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_096a;
																		}
																		break;
																		IL_0314:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_034d;
																continue;
																end_IL_0324:
																break;
															}
															continue;
															end_IL_0334:
															break;
														}
														continue;
														end_IL_034d:
														break;
													}
													continue;
												}
												goto IL_0a25;
												IL_0a25:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0992:
												break;
											}
											continue;
											end_IL_09a5:
											break;
										}
										continue;
										end_IL_09af:
										break;
									}
									continue;
									end_IL_09ba:
									break;
								}
								continue;
								end_IL_09ca:
								break;
							}
							continue;
							end_IL_09da:
							break;
						}
						continue;
						end_IL_09ea:
						break;
					}
					continue;
					end_IL_09fa:
					break;
				}
				continue;
				end_IL_0a0a:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1, int int_2)
	{
		int num = 38;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								num = 65;
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AddTickssetPermissionType.IStackWalkDss);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0356:
															byte b = *ptr2;
															while (true)
															{
																IL_0346:
																ptr2++;
																while (true)
																{
																	IL_0336:
																	if (b >= 1)
																	{
																		goto IL_020b;
																	}
																	goto IL_030e;
																	IL_030e:
																	while (true)
																	{
																		IL_030e_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																		while (true)
																		{
																			IL_01fb:
																			array[num5] = 0;
																			while (true)
																			{
																				IL_01eb:
																				num5++;
																				while (true)
																				{
																					IL_01d2:
																					ptr2 += 8;
																					num = 108;
																					while (num != 108)
																					{
																						if (num != 1089)
																						{
																							goto IL_0522;
																						}
																						switch (num)
																						{
																						case 28:
																							goto IL_01d2;
																						case 96:
																							goto IL_01eb;
																						case 82:
																							goto IL_01fb;
																						case 5:
																							goto IL_020b;
																						case 14:
																							goto IL_0219;
																						case 0:
																							goto IL_0224;
																						case 50:
																							goto IL_0234;
																						case 55:
																							goto IL_0242;
																						case 1:
																						case 42:
																							goto IL_0250;
																						case 25:
																						case 61:
																							goto IL_0260;
																						case 70:
																							goto IL_026b;
																						case 60:
																							goto IL_0276;
																						case 68:
																							goto IL_0284;
																						case 26:
																							goto IL_0294;
																						case 78:
																							goto IL_02a4;
																						case 93:
																							goto IL_02b4;
																						case 63:
																							goto IL_02c2;
																						case 34:
																							goto IL_02cd;
																						case 101:
																							goto IL_02da;
																						case 4:
																						case 15:
																							goto IL_02e5;
																						case 75:
																							goto IL_02f0;
																						case 81:
																							goto IL_0300;
																						case 11:
																						case 12:
																						case 19:
																						case 21:
																						case 23:
																						case 24:
																						case 30:
																						case 40:
																						case 45:
																						case 53:
																						case 64:
																						case 66:
																						case 86:
																						case 92:
																						case 95:
																						case 97:
																							goto IL_030e_2;
																						case 99:
																							goto IL_0336;
																						case 62:
																							goto IL_0346;
																						case 47:
																						case 80:
																							goto IL_0356;
																						case 20:
																						case 43:
																							goto IL_0361;
																						case 32:
																							goto IL_0383;
																						case 9:
																						case 58:
																							goto IL_0396;
																						case 7:
																						case 74:
																							goto IL_03db;
																						case 17:
																							goto IL_03e9;
																						case 52:
																							goto IL_040c;
																						case 72:
																							goto IL_0416;
																						case 49:
																						case 77:
																							goto IL_0426;
																						case 83:
																							goto IL_0454;
																						case 79:
																						case 91:
																							goto IL_0467;
																						case 41:
																							goto IL_04a7;
																						case 67:
																							goto IL_04bb;
																						case 3:
																						case 46:
																							goto IL_04ce;
																						case 33:
																							goto IL_050e;
																						case 8:
																							goto IL_0522;
																						case 94:
																							goto IL_053e;
																						case 76:
																							goto IL_0552;
																						case 98:
																							goto IL_0565;
																						case 71:
																							goto IL_0573;
																						case 100:
																							goto IL_0586;
																						case 31:
																							goto IL_0594;
																						case 6:
																						case 44:
																							goto IL_05b0;
																						case 35:
																						case 69:
																							goto IL_05c9;
																						case 48:
																							goto IL_0609;
																						case 39:
																							goto IL_061d;
																						case 2:
																						case 27:
																						case 36:
																						case 54:
																						case 57:
																						case 59:
																						case 73:
																						case 84:
																						case 87:
																						case 88:
																							goto end_IL_01bf;
																						case 29:
																							goto end_IL_062b;
																						case 89:
																							goto end_IL_063e;
																						case 90:
																							goto end_IL_0648;
																						case 65:
																							goto end_IL_0653;
																						case 16:
																							goto end_IL_0668;
																						case 13:
																						case 56:
																							goto end_IL_067d;
																						case 85:
																							goto end_IL_0696;
																						case 18:
																						case 51:
																							goto end_IL_06a6;
																						case 37:
																							goto end_IL_06b6;
																						case 38:
																							goto end_IL_06c6;
																						case 10:
																						case 22:
																							goto IL_06e1;
																						}
																						continue;
																						end_IL_01bf:
																						break;
																					}
																					break;
																				}
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																	IL_020b:
																	if (b <= 9)
																	{
																		goto IL_0219;
																	}
																	goto IL_030e;
																	IL_0219:
																	if (5 >= b)
																	{
																		goto IL_0224;
																	}
																	goto IL_0234;
																	IL_0224:
																	if (5 > b)
																	{
																		goto IL_0260;
																	}
																	goto IL_03db;
																	IL_03db:
																	array[num5] = 0;
																	goto IL_03e9;
																	IL_03e9:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_040c;
																	IL_040c:
																	array2[num5] = null;
																	goto IL_0416;
																	IL_0416:
																	num5++;
																	goto IL_0454;
																	IL_0454:
																	ptr2 += 8;
																	break;
																	IL_0260:
																	if (2 < b)
																	{
																		goto IL_026b;
																	}
																	goto IL_02b4;
																	IL_026b:
																	if (3 < b)
																	{
																		goto IL_0276;
																	}
																	goto IL_0294;
																	IL_0276:
																	if (4 >= b)
																	{
																		goto IL_0284;
																	}
																	goto IL_030e;
																	IL_0284:
																	if (4 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_0396;
																	IL_0396:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_053e;
																	IL_053e:
																	array[num5 - 2] = 0;
																	goto IL_0552;
																	IL_0552:
																	num5--;
																	break;
																	IL_0294:
																	if (3 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_0426;
																	IL_0426:
																	ref int reference = ref array3[*(int*)(ptr2 + num3)];
																	reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0565;
																	IL_0565:
																	ptr2 += 8;
																	goto IL_0573;
																	IL_0573:
																	num5--;
																	break;
																	IL_02b4:
																	if (2 > b)
																	{
																		goto IL_02c2;
																	}
																	goto IL_04ce;
																	IL_02c2:
																	if (1 >= b)
																	{
																		goto IL_02cd;
																	}
																	goto IL_030e;
																	IL_02cd:
																	if (1 > b)
																	{
																	}
																	goto IL_030e;
																	IL_04ce:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_050e;
																	IL_050e:
																	array[num5 - 2] = 0;
																	goto IL_0522;
																	IL_0522:
																	num5--;
																	num = 36;
																	break;
																	IL_0234:
																	if (7 >= b)
																	{
																		goto IL_0242;
																	}
																	goto IL_02da;
																	IL_0242:
																	if (7 > b)
																	{
																		goto IL_0250;
																	}
																	goto IL_0361;
																	IL_0250:
																	if (6 >= b)
																	{
																		goto IL_02a4;
																	}
																	goto IL_030e;
																	IL_02a4:
																	if (6 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_0467;
																	IL_0467:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_04a7;
																	IL_04a7:
																	array[num5 - 2] = 0;
																	goto IL_04bb;
																	IL_04bb:
																	num5--;
																	break;
																	IL_0361:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	num = 32;
																	goto IL_0383;
																	IL_0383:
																	array[num5] = 0;
																	goto IL_0586;
																	IL_0586:
																	num5++;
																	goto IL_0594;
																	IL_0594:
																	ptr2 += 8;
																	break;
																	IL_02da:
																	if (8 < b)
																	{
																		goto IL_02e5;
																	}
																	goto IL_0300;
																	IL_02e5:
																	if (9 >= b)
																	{
																		goto IL_02f0;
																	}
																	goto IL_030e;
																	IL_02f0:
																	if (9 > b)
																	{
																		goto IL_030e;
																	}
																	num = 44;
																	goto IL_05b0;
																	IL_061d:
																	num5--;
																	break;
																	IL_05b0:
																	byte* num6 = ptr2;
																	num4 = 1;
																	ptr2 = num6 + -200;
																	break;
																	IL_0300:
																	if (8 > b)
																	{
																		goto IL_030e;
																	}
																	goto IL_05c9;
																	IL_05c9:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																	goto IL_0609;
																	IL_0609:
																	array[num5 - 2] = 0;
																	goto IL_061d;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_06e1;
													IL_06e1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_062b:
													break;
												}
												continue;
												end_IL_063e:
												break;
											}
											continue;
											end_IL_0648:
											break;
										}
										continue;
										end_IL_0653:
										break;
									}
									continue;
									end_IL_0668:
									break;
								}
								continue;
								end_IL_067d:
								break;
							}
							continue;
							end_IL_0696:
							break;
						}
						continue;
						end_IL_06a6:
						break;
					}
					continue;
					end_IL_06b6:
					break;
				}
				continue;
				end_IL_06c6:
				break;
			}
		}
	}

	static Class159()
	{
		int num = 6;
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 15;
					while (true)
					{
						if (num == 15 || num != 996)
						{
							return;
						}
						switch (num)
						{
						case 0:
						case 1:
						case 2:
						case 3:
						case 7:
						case 8:
							goto end_IL_004b;
						case 5:
							goto end_IL_0058;
						case 6:
							goto end_IL_0073;
						case 4:
							return;
						}
						continue;
						end_IL_004b:
						break;
					}
					continue;
					end_IL_0058:
					break;
				}
				continue;
				end_IL_0073:
				break;
			}
		}
	}
}
