using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using UnityEngine;

[Mod("Menu Style: Current", "Settings", "Cycle menu appearance.", false, 21, ModType.const_1, false)]
internal class Class134 : MonoBehaviour
{
	private static int int_0;

	private static string[] string_0;

	private static float float_0;

	private static double double_0;

	private static float float_1;

	private static float float_2;

	private static IntPtr[] getPersistEndChildrenCallback;

	private static IntPtr[] SignatureDescriptionCheckExecutionRights;

	private static IntPtr[] NextgetExceptionTypeToken;

	private static IntPtr[] rootGuidScheme;

	private static IntPtr[] HiddenSwitchWrappers;

	private static IntPtr[] ToSerializedStringSignatureID;

	private static IntPtr[] DebuggerStepperBoundaryAttributeEventSourceOptions;

	public unsafe static int CurrentStyle
	{
		get
		{
			int num = 30;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								num = 111;
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetXmlNamespaceForMethodCallAccessRuleFactory.ContextMarshalExceptionSetAttributes);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0381:
																	if (b >= 1)
																	{
																		while (b <= 16)
																		{
																			while (true)
																			{
																				IL_0361:
																				if (8 >= b)
																				{
																					while (true)
																					{
																						IL_0351:
																						if (8 > b)
																						{
																							while (true)
																							{
																								IL_0344:
																								if (4 < b)
																								{
																									while (true)
																									{
																										IL_0334:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_0324:
																												if (6 <= b)
																												{
																													while (true)
																													{
																														IL_02d9:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																														num = 158;
																														while (true)
																														{
																															IL_02ba:
																															array[num6 - 2] = 0;
																															num = 166;
																															while (true)
																															{
																																if (num != 166)
																																{
																																	if (num != 1147)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 158:
																																		goto IL_02ba;
																																	case 116:
																																	case 126:
																																		goto IL_02d9;
																																	case 68:
																																		goto IL_0324;
																																	case 106:
																																		goto IL_0334;
																																	case 151:
																																		goto IL_0344;
																																	case 38:
																																		goto IL_0351;
																																	case 137:
																																		goto IL_0361;
																																	case 154:
																																		goto end_IL_0361;
																																	case 18:
																																		goto IL_0381;
																																	case 49:
																																		goto end_IL_0381;
																																	case 0:
																																	case 11:
																																		goto end_IL_0391;
																																	case 55:
																																		goto IL_03ac;
																																	case 57:
																																	case 82:
																																		goto IL_03c5;
																																	case 89:
																																		goto IL_03d3;
																																	case 3:
																																	case 97:
																																		goto IL_0404;
																																	case 5:
																																		goto IL_0412;
																																	case 53:
																																	case 98:
																																		goto IL_0425;
																																	case 71:
																																	case 121:
																																		goto IL_0438;
																																	case 10:
																																		goto IL_0446;
																																	case 109:
																																	case 132:
																																		goto IL_0459;
																																	case 40:
																																		goto IL_0464;
																																	case 34:
																																	case 67:
																																		goto IL_0472;
																																	case 115:
																																		goto IL_04b2;
																																	case 27:
																																		goto IL_04c6;
																																	case 52:
																																		goto IL_04d9;
																																	case 46:
																																		goto IL_04e7;
																																	case 15:
																																	case 56:
																																		goto IL_04f5;
																																	case 139:
																																		goto IL_0520;
																																	case 62:
																																		goto IL_052a;
																																	case 39:
																																		goto IL_0538;
																																	case 141:
																																		goto IL_054b;
																																	case 133:
																																		goto IL_0559;
																																	case 86:
																																	case 149:
																																		goto IL_056c;
																																	case 12:
																																		goto IL_05ac;
																																	case 108:
																																		goto IL_05c0;
																																	case 114:
																																	case 152:
																																		goto IL_05d3;
																																	case 123:
																																	case 134:
																																		goto IL_05e1;
																																	case 148:
																																		goto IL_05ef;
																																	case 33:
																																	case 122:
																																		goto IL_05fd;
																																	case 78:
																																		goto IL_061a;
																																	case 128:
																																		goto IL_0659;
																																	case 80:
																																		goto IL_066c;
																																	case 6:
																																	case 43:
																																		goto IL_0677;
																																	case 103:
																																		goto IL_0685;
																																	case 1:
																																	case 100:
																																		goto IL_0695;
																																	case 36:
																																		goto IL_06f7;
																																	case 138:
																																	case 153:
																																		goto IL_070a;
																																	case 13:
																																		goto IL_074a;
																																	case 147:
																																		goto IL_075e;
																																	case 32:
																																	case 155:
																																		goto IL_077a;
																																	case 107:
																																		goto IL_0791;
																																	case 130:
																																	case 156:
																																		goto end_IL_02a7;
																																	case 113:
																																		goto IL_07bb;
																																	case 129:
																																	case 131:
																																		goto IL_07c6;
																																	case 125:
																																		goto IL_07de;
																																	case 19:
																																		goto IL_07ec;
																																	case 73:
																																	case 143:
																																		goto IL_07fa;
																																	case 99:
																																		goto IL_081c;
																																	case 48:
																																		goto IL_082a;
																																	case 7:
																																		goto IL_0838;
																																	case 65:
																																		goto IL_084b;
																																	case 84:
																																	case 85:
																																		goto IL_0856;
																																	case 50:
																																		goto IL_0864;
																																	case 4:
																																	case 22:
																																		goto IL_0872;
																																	case 37:
																																		goto IL_088e;
																																	case 60:
																																	case 142:
																																		goto IL_089c;
																																	case 101:
																																		goto IL_08c0;
																																	case 14:
																																		goto IL_08ce;
																																	case 70:
																																		goto IL_08dc;
																																	case 91:
																																		goto IL_0902;
																																	case 35:
																																		goto IL_090d;
																																	case 9:
																																	case 58:
																																		goto IL_0918;
																																	case 42:
																																		goto IL_0958;
																																	case 144:
																																		goto IL_096c;
																																	case 17:
																																	case 20:
																																	case 21:
																																	case 25:
																																	case 44:
																																	case 47:
																																	case 54:
																																	case 59:
																																	case 61:
																																	case 63:
																																	case 66:
																																	case 69:
																																	case 74:
																																	case 75:
																																	case 76:
																																	case 77:
																																	case 83:
																																	case 87:
																																	case 93:
																																	case 96:
																																	case 104:
																																	case 105:
																																	case 110:
																																	case 117:
																																	case 120:
																																	case 135:
																																	case 136:
																																	case 145:
																																		goto end_IL_0371;
																																	case 140:
																																		goto IL_0995;
																																	case 146:
																																		goto IL_09a3;
																																	case 26:
																																		goto IL_09b1;
																																	case 8:
																																	case 16:
																																	case 23:
																																	case 24:
																																	case 28:
																																	case 41:
																																	case 45:
																																	case 64:
																																	case 72:
																																	case 79:
																																	case 88:
																																	case 90:
																																	case 95:
																																	case 102:
																																	case 112:
																																	case 119:
																																	case 127:
																																	case 150:
																																	case 159:
																																		goto end_IL_03a1;
																																	case 118:
																																		goto end_IL_09bf;
																																	case 51:
																																		goto end_IL_09d2;
																																	case 81:
																																		goto end_IL_09dc;
																																	case 111:
																																	case 157:
																																		goto end_IL_09e7;
																																	case 31:
																																		goto end_IL_09f7;
																																	case 92:
																																		goto end_IL_0a07;
																																	case 2:
																																		goto end_IL_0a20;
																																	case 29:
																																		goto end_IL_0a30;
																																	case 30:
																																		goto end_IL_0a40;
																																	case 94:
																																	case 124:
																																		goto IL_0a64;
																																	}
																																	continue;
																																}
																																num6--;
																																goto end_IL_03a1;
																																continue;
																																end_IL_02a7:
																																break;
																															}
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												goto IL_0404;
																												IL_05c0:
																												num6--;
																												goto end_IL_03a1;
																												IL_0404:
																												if (5 < b)
																												{
																													goto end_IL_0371;
																												}
																												goto IL_0412;
																												IL_0412:
																												if (5 > b)
																												{
																													goto end_IL_0371;
																												}
																												goto IL_056c;
																												IL_056c:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																												goto IL_05ac;
																												IL_05ac:
																												array[num6 - 2] = 0;
																												goto IL_05c0;
																											}
																											break;
																										}
																										goto IL_0902;
																										IL_096c:
																										num6--;
																										goto end_IL_03a1;
																										IL_0902:
																										if (7 < b)
																										{
																											goto end_IL_0371;
																										}
																										goto IL_090d;
																										IL_090d:
																										if (7 > b)
																										{
																											goto end_IL_0371;
																										}
																										goto IL_0918;
																										IL_0918:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																										goto IL_0958;
																										IL_0958:
																										array[num6 - 2] = 0;
																										goto IL_096c;
																									}
																									break;
																								}
																								goto IL_03ac;
																								IL_03d3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																								num = 139;
																								goto IL_0520;
																								IL_03ac:
																								if (4 <= b)
																								{
																									goto IL_03c5;
																								}
																								num = 132;
																								goto IL_0459;
																								IL_0520:
																								array2[num6] = null;
																								goto IL_052a;
																								IL_0459:
																								if (2 >= b)
																								{
																									goto IL_0464;
																								}
																								goto IL_04d9;
																								IL_0464:
																								if (2 <= b)
																								{
																									goto IL_0472;
																								}
																								goto IL_077a;
																								IL_0472:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_04b2;
																								IL_04b2:
																								array[num6 - 2] = 0;
																								goto IL_04c6;
																								IL_04c6:
																								num6--;
																								goto end_IL_03a1;
																								IL_077a:
																								if (1 < b)
																								{
																									goto end_IL_0371;
																								}
																								num = 107;
																								goto IL_0791;
																								IL_052a:
																								num6++;
																								goto IL_0538;
																								IL_0791:
																								if (1 <= b)
																								{
																									num = 59;
																								}
																								goto end_IL_0371;
																								IL_0538:
																								ptr2 += 8;
																								goto end_IL_03a1;
																								IL_04d9:
																								if (3 < b)
																								{
																									goto end_IL_0371;
																								}
																								goto IL_04e7;
																								IL_04e7:
																								if (3 > b)
																								{
																									goto end_IL_0371;
																								}
																								goto IL_04f5;
																								IL_04f5:
																								ref int reference = ref array3[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																								goto IL_054b;
																								IL_054b:
																								ptr2 += 8;
																								goto IL_0559;
																								IL_0559:
																								num6--;
																								goto end_IL_03a1;
																								IL_03c5:
																								array[num6] = 0;
																								goto IL_03d3;
																							}
																							break;
																						}
																						goto IL_0425;
																						IL_0425:
																						num6--;
																						goto end_IL_03a1;
																					}
																					goto IL_07ad;
																				}
																				goto IL_0438;
																				IL_08dc:
																				ptr2 += 8;
																				goto end_IL_03a1;
																				IL_0438:
																				if (12 >= b)
																				{
																					goto IL_0446;
																				}
																				goto IL_07ad;
																				IL_0446:
																				if (12 <= b)
																				{
																					goto end_IL_03a1;
																				}
																				goto IL_05d3;
																				IL_05d3:
																				if (10 < b)
																				{
																					goto IL_05e1;
																				}
																				goto IL_066c;
																				IL_05e1:
																				if (11 < b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_05ef;
																				IL_05ef:
																				if (11 > b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_05fd;
																				IL_05fd:
																				array[num6 - 1] = 0;
																				num = 78;
																				goto IL_061a;
																				IL_061a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = ((delegate*<int, int>)getPersistEndChildrenCallback[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																				goto IL_0659;
																				IL_0659:
																				ptr2 += 8;
																				goto end_IL_03a1;
																				IL_066c:
																				if (10 > b)
																				{
																					goto IL_0677;
																				}
																				goto IL_0695;
																				IL_0677:
																				if (9 < b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_0685;
																				IL_0685:
																				if (9 > b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_070a;
																				IL_070a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_074a;
																				IL_074a:
																				array[num6 - 2] = 0;
																				goto IL_075e;
																				IL_075e:
																				num6--;
																				num = 112;
																				goto end_IL_03a1;
																				IL_0695:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_06f7;
																				IL_06f7:
																				num6 -= 2;
																				goto end_IL_03a1;
																				IL_07ad:
																				if (14 >= b)
																				{
																					goto IL_07bb;
																				}
																				goto IL_084b;
																				IL_07bb:
																				if (14 <= b)
																				{
																					goto IL_07c6;
																				}
																				goto IL_07de;
																				IL_07c6:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_03a1;
																				IL_07de:
																				if (13 < b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_07ec;
																				IL_07ec:
																				if (13 > b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_07fa;
																				IL_07fa:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				num = 99;
																				goto IL_081c;
																				IL_081c:
																				array[num6] = 1;
																				goto IL_082a;
																				IL_082a:
																				num6++;
																				goto IL_0838;
																				IL_0838:
																				ptr2 += 16;
																				goto end_IL_03a1;
																				IL_084b:
																				if (15 < b)
																				{
																					goto IL_0856;
																				}
																				goto IL_088e;
																				IL_0856:
																				if (16 < b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_0864;
																				IL_0864:
																				if (16 > b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_0872;
																				IL_0872:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_03a1;
																				IL_088e:
																				if (15 > b)
																				{
																					goto end_IL_0371;
																				}
																				goto IL_089c;
																				IL_089c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)getPersistEndChildrenCallback[*(int*)(ptr2 + num3)])();
																				goto IL_08c0;
																				IL_08c0:
																				array[num6] = 0;
																				goto IL_08ce;
																				IL_08ce:
																				num6++;
																				goto IL_08dc;
																				continue;
																				end_IL_0361:
																				break;
																			}
																			continue;
																			end_IL_0371:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	goto IL_0995;
																	IL_09b1:
																	ptr2 += 8;
																	goto end_IL_03a1;
																	IL_09a3:
																	num6++;
																	goto IL_09b1;
																	IL_0995:
																	array[num6] = 0;
																	goto IL_09a3;
																	continue;
																	end_IL_0381:
																	break;
																}
																continue;
																end_IL_0391:
																break;
															}
															continue;
															end_IL_03a1:
															break;
														}
														continue;
													}
													num = 94;
													goto IL_0a64;
													IL_0a64:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_09bf:
													break;
												}
												continue;
												end_IL_09d2:
												break;
											}
											continue;
											end_IL_09dc:
											break;
										}
										continue;
										end_IL_09e7:
										break;
									}
									continue;
									end_IL_09f7:
									break;
								}
								continue;
								end_IL_0a07:
								break;
							}
							continue;
							end_IL_0a20:
							break;
						}
						continue;
						end_IL_0a30:
						break;
					}
					continue;
					end_IL_0a40:
					break;
				}
			}
		}
		set
		{
			int num = 65;
			byte b = default(byte);
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[4];
							while (true)
							{
								object[] array2 = new object[4];
								num = 189;
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[4];
										while (true)
										{
											array3[0] = value;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IStoreCreateActContextParametersSourceDefinitionAppid.getMvidValueResponseXmlNamespace);
												num = 97;
												while (true)
												{
													byte* ptr2 = ptr;
													num = 215;
													while (true)
													{
														if (num != 215)
														{
															if (num != 1196)
															{
																goto IL_0da7;
															}
															switch (num)
															{
															case 97:
																goto end_IL_036b;
															case 185:
																goto end_IL_037e;
															case 4:
																goto end_IL_0391;
															case 159:
																goto end_IL_03a5;
															case 109:
															case 189:
																goto end_IL_03ba;
															case 119:
																goto end_IL_03ca;
															case 165:
																goto end_IL_03da;
															case 193:
																goto end_IL_03f3;
															case 64:
																goto end_IL_0403;
															case 65:
																goto end_IL_0413;
															case 0:
															case 6:
															case 9:
															case 13:
															case 50:
															case 51:
															case 57:
															case 72:
															case 77:
															case 108:
															case 112:
															case 118:
															case 121:
															case 132:
															case 138:
															case 140:
															case 152:
															case 180:
															case 184:
															case 187:
															case 192:
															case 196:
															case 197:
															case 205:
																goto IL_0437;
															case 66:
															case 79:
																goto IL_0447;
															case 195:
																goto IL_0450;
															case 52:
																goto IL_045e;
															case 135:
																goto IL_046c;
															case 83:
																goto IL_047a;
															case 80:
																goto IL_0488;
															case 11:
															case 126:
																goto IL_049f;
															case 17:
																goto IL_04ad;
															case 158:
															case 162:
																goto IL_04b8;
															case 25:
																goto IL_04f8;
															case 46:
																goto IL_050c;
															case 183:
																goto IL_051f;
															case 93:
															case 156:
																goto IL_052d;
															case 35:
																goto IL_053b;
															case 141:
																goto IL_0549;
															case 61:
															case 177:
																goto IL_0557;
															case 176:
																goto IL_056e;
															case 208:
																goto IL_0591;
															case 124:
																goto IL_059b;
															case 166:
																goto IL_05a9;
															case 48:
																goto IL_05c5;
															case 27:
															case 36:
																goto IL_05d3;
															case 63:
																goto IL_05fc;
															case 38:
																goto IL_060a;
															case 169:
																goto IL_061d;
															case 29:
															case 102:
																goto IL_0628;
															case 145:
																goto IL_0668;
															case 168:
																goto IL_067c;
															case 55:
															case 200:
																goto IL_068f;
															case 54:
																goto IL_069d;
															case 3:
																goto IL_06b0;
															case 22:
																goto IL_06be;
															case 10:
															case 146:
																goto IL_06cc;
															case 2:
																goto IL_06d7;
															case 92:
															case 190:
																goto IL_06e5;
															case 161:
																goto IL_0725;
															case 120:
																goto IL_0739;
															case 42:
																goto IL_074c;
															case 18:
																goto IL_075a;
															case 26:
															case 71:
																goto IL_0768;
															case 96:
																goto IL_07a8;
															case 110:
																goto IL_07bc;
															case 95:
															case 204:
																goto IL_07cf;
															case 69:
															case 207:
																goto IL_07e2;
															case 181:
																goto IL_07ed;
															case 43:
															case 136:
																goto IL_07fb;
															case 19:
																goto IL_083b;
															case 15:
																goto IL_084f;
															case 53:
																goto IL_0862;
															case 182:
																goto IL_0870;
															case 133:
															case 151:
																goto IL_087e;
															case 33:
																goto IL_08e0;
															case 100:
															case 149:
																goto IL_08f3;
															case 7:
																goto IL_0910;
															case 186:
																goto IL_094f;
															case 170:
																goto IL_0962;
															case 14:
															case 58:
																goto IL_0970;
															case 114:
															case 157:
																goto IL_097b;
															case 31:
																goto IL_0986;
															case 47:
															case 84:
																goto IL_0994;
															case 76:
																goto IL_09ae;
															case 89:
																goto IL_09c1;
															case 88:
																goto IL_09cf;
															case 137:
															case 144:
																goto IL_09dd;
															case 199:
																goto IL_09f9;
															case 44:
															case 101:
																goto IL_0a07;
															case 60:
															case 90:
																goto IL_0a15;
															case 143:
																goto IL_0a23;
															case 62:
															case 127:
																goto IL_0a31;
															case 179:
																goto IL_0a71;
															case 73:
																goto IL_0a85;
															case 94:
																goto IL_0a98;
															case 172:
															case 191:
																goto IL_0aa6;
															case 174:
																goto IL_0ad1;
															case 75:
															case 171:
																goto IL_0aea;
															case 153:
																goto IL_0afe;
															case 167:
																goto IL_0b67;
															case 20:
																goto IL_0b75;
															case 198:
																goto IL_0b88;
															case 32:
															case 98:
																goto IL_0b93;
															case 5:
																goto IL_0bbd;
															case 82:
																goto IL_0bd6;
															case 8:
															case 147:
																goto IL_0be4;
															case 74:
															case 86:
																goto IL_0bef;
															case 78:
																goto IL_0bfd;
															case 12:
															case 40:
																goto IL_0c0b;
															case 85:
																goto IL_0c29;
															case 188:
																goto IL_0c37;
															case 28:
																goto IL_0c45;
															case 178:
																goto IL_0c58;
															case 49:
															case 68:
																goto IL_0c66;
															case 129:
																goto IL_0c89;
															case 106:
																goto IL_0c97;
															case 125:
																goto IL_0ca5;
															case 107:
																goto IL_0cb8;
															case 70:
																goto IL_0cc6;
															case 34:
															case 104:
																goto IL_0cd1;
															case 24:
																goto IL_0ce8;
															case 154:
															case 175:
																goto IL_0cf6;
															case 201:
																goto IL_0d0f;
															case 59:
																goto IL_0d1d;
															case 160:
																goto IL_0d2b;
															case 194:
																goto IL_0d3e;
															case 56:
															case 67:
																goto IL_0d57;
															case 117:
																goto IL_0d78;
															case 142:
																goto IL_0d86;
															case 122:
																goto IL_0d94;
															case 1:
															case 16:
															case 21:
															case 23:
															case 30:
															case 37:
															case 39:
															case 41:
															case 45:
															case 81:
															case 87:
															case 91:
															case 99:
															case 105:
															case 113:
															case 115:
															case 116:
															case 123:
															case 128:
															case 130:
															case 131:
															case 134:
															case 139:
															case 148:
															case 150:
															case 155:
															case 163:
															case 164:
															case 173:
															case 202:
															case 203:
															case 206:
																goto IL_0da7;
															case 103:
															case 111:
																return;
															}
															continue;
														}
														num = 192;
														goto IL_0437;
														IL_0d3e:
														if (12 <= b)
														{
															goto IL_0437;
														}
														goto IL_0da7;
														IL_0d57:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														num = 152;
														goto IL_0437;
														IL_0d86:
														num5++;
														goto IL_0d94;
														IL_0437:
														if (num6 == 1)
														{
															return;
														}
														goto IL_0447;
														IL_0447:
														b = *ptr2;
														goto IL_0450;
														IL_0450:
														ptr2++;
														goto IL_045e;
														IL_045e:
														if (b >= 1)
														{
															goto IL_046c;
														}
														goto IL_0da7;
														IL_046c:
														if (b <= 22)
														{
															goto IL_047a;
														}
														goto IL_0da7;
														IL_047a:
														if (11 >= b)
														{
															goto IL_0488;
														}
														goto IL_0962;
														IL_0488:
														if (11 > b)
														{
															num = 11;
															goto IL_049f;
														}
														goto IL_08f3;
														IL_0da7:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
														goto IL_0d78;
														IL_049f:
														if (5 >= b)
														{
															goto IL_04ad;
														}
														goto IL_06b0;
														IL_04ad:
														if (5 <= b)
														{
															goto IL_04b8;
														}
														goto IL_051f;
														IL_04b8:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_04f8;
														IL_04f8:
														array[num5 - 2] = 0;
														goto IL_050c;
														IL_050c:
														num5--;
														goto IL_0437;
														IL_051f:
														if (2 < b)
														{
															goto IL_052d;
														}
														goto IL_061d;
														IL_052d:
														if (3 < b)
														{
															goto IL_053b;
														}
														num = 48;
														goto IL_05c5;
														IL_053b:
														if (4 >= b)
														{
															goto IL_0549;
														}
														goto IL_0da7;
														IL_0549:
														if (4 <= b)
														{
															goto IL_0557;
														}
														goto IL_0da7;
														IL_0557:
														array[num5] = 0;
														num = 176;
														goto IL_056e;
														IL_056e:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0591;
														IL_0591:
														array2[num5] = null;
														goto IL_059b;
														IL_059b:
														num5++;
														goto IL_05a9;
														IL_05a9:
														ptr2 += 8;
														goto IL_0437;
														IL_0d78:
														array[num5] = 0;
														goto IL_0d86;
														IL_05c5:
														if (3 <= b)
														{
															goto IL_05d3;
														}
														goto IL_0da7;
														IL_05d3:
														ref int reference = ref array3[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_05fc;
														IL_05fc:
														ptr2 += 8;
														goto IL_060a;
														IL_060a:
														num5--;
														goto IL_0437;
														IL_061d:
														if (2 <= b)
														{
															goto IL_0628;
														}
														goto IL_068f;
														IL_0628:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0668;
														IL_0668:
														array[num5 - 2] = 0;
														goto IL_067c;
														IL_067c:
														num5--;
														goto IL_0437;
														IL_068f:
														if (1 >= b)
														{
															goto IL_069d;
														}
														goto IL_0da7;
														IL_069d:
														if (1 > b)
														{
														}
														goto IL_0da7;
														IL_06b0:
														if (8 >= b)
														{
															goto IL_06be;
														}
														goto IL_07e2;
														IL_06be:
														if (8 > b)
														{
															goto IL_06cc;
														}
														goto IL_07cf;
														IL_06cc:
														if (6 >= b)
														{
															goto IL_06d7;
														}
														goto IL_074c;
														IL_06d7:
														if (6 <= b)
														{
															goto IL_06e5;
														}
														goto IL_0da7;
														IL_06e5:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0725;
														IL_0725:
														array[num5 - 2] = 0;
														goto IL_0739;
														IL_0739:
														num5--;
														goto IL_0437;
														IL_074c:
														if (7 >= b)
														{
															goto IL_075a;
														}
														goto IL_0da7;
														IL_075a:
														if (7 <= b)
														{
															goto IL_0768;
														}
														goto IL_0da7;
														IL_0768:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_07a8;
														IL_07a8:
														array[num5 - 2] = 0;
														goto IL_07bc;
														IL_07bc:
														num5--;
														goto IL_0437;
														IL_07cf:
														num5--;
														goto IL_0437;
														IL_07e2:
														if (9 >= b)
														{
															goto IL_07ed;
														}
														goto IL_0862;
														IL_07ed:
														if (9 <= b)
														{
															goto IL_07fb;
														}
														goto IL_0da7;
														IL_07fb:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_083b;
														IL_083b:
														array[num5 - 2] = 0;
														goto IL_084f;
														IL_084f:
														num5--;
														goto IL_0437;
														IL_0862:
														if (10 >= b)
														{
															goto IL_0870;
														}
														goto IL_0da7;
														IL_0870:
														if (10 <= b)
														{
															goto IL_087e;
														}
														goto IL_0da7;
														IL_087e:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_08e0;
														IL_08e0:
														num5 -= 2;
														goto IL_0437;
														IL_08f3:
														array[num5 - 1] = 0;
														num = 7;
														goto IL_0910;
														IL_0910:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)SignatureDescriptionCheckExecutionRights[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
														goto IL_094f;
														IL_094f:
														ptr2 += 8;
														goto IL_0437;
														IL_0962:
														if (17 < b)
														{
															goto IL_0970;
														}
														goto IL_0b88;
														IL_0970:
														if (20 < b)
														{
															goto IL_097b;
														}
														goto IL_09f9;
														IL_097b:
														if (21 >= b)
														{
															goto IL_0986;
														}
														goto IL_09c1;
														IL_0986:
														if (21 <= b)
														{
															goto IL_0994;
														}
														goto IL_0da7;
														IL_0994:
														int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_09ae;
														IL_09ae:
														num5--;
														goto IL_0437;
														IL_09c1:
														if (22 >= b)
														{
															goto IL_09cf;
														}
														goto IL_0da7;
														IL_09cf:
														if (22 <= b)
														{
															goto IL_09dd;
														}
														goto IL_0da7;
														IL_09dd:
														byte* num7 = ptr2;
														num6 = 1;
														ptr2 = num7 + -200;
														goto IL_0437;
														IL_09f9:
														if (20 > b)
														{
															goto IL_0a07;
														}
														goto IL_0aea;
														IL_0a07:
														if (18 < b)
														{
															goto IL_0a15;
														}
														goto IL_0a98;
														IL_0a15:
														if (19 >= b)
														{
															goto IL_0a23;
														}
														goto IL_0da7;
														IL_0a23:
														if (19 <= b)
														{
															goto IL_0a31;
														}
														goto IL_0da7;
														IL_0a31:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														goto IL_0a71;
														IL_0a71:
														array[num5 - 2] = 0;
														goto IL_0a85;
														IL_0a85:
														num5--;
														goto IL_0437;
														IL_0a98:
														if (18 <= b)
														{
															goto IL_0aa6;
														}
														goto IL_0da7;
														IL_0aa6:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
														goto IL_0ad1;
														IL_0ad1:
														array[num5 - 1] = 0;
														goto IL_0437;
														IL_0aea:
														array[num5 - 3] = 0;
														goto IL_0afe;
														IL_0afe:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 3]) = ((delegate*<int, int, int, int>)SignatureDescriptionCheckExecutionRights[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
														goto IL_0b67;
														IL_0b67:
														num5 -= 2;
														goto IL_0b75;
														IL_0b75:
														ptr2 += 8;
														goto IL_0437;
														IL_0b88:
														if (17 <= b)
														{
															goto IL_0b93;
														}
														goto IL_0bd6;
														IL_0b93:
														*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (nint)((string[])array2[num5 - 1]).LongLength;
														goto IL_0bbd;
														IL_0bbd:
														array[num5 - 1] = 2;
														goto IL_0437;
														IL_0bd6:
														if (14 < b)
														{
															goto IL_0be4;
														}
														goto IL_0cb8;
														IL_0be4:
														if (15 < b)
														{
															goto IL_0bef;
														}
														goto IL_0c58;
														IL_0bef:
														if (16 >= b)
														{
															goto IL_0bfd;
														}
														goto IL_0da7;
														IL_0bfd:
														if (16 <= b)
														{
															goto IL_0c0b;
														}
														goto IL_0da7;
														IL_0c0b:
														array2[num5] = ((delegate*<string[]>)SignatureDescriptionCheckExecutionRights[*(int*)(ptr2 + num3)])();
														goto IL_0c29;
														IL_0c29:
														array[num5] = 5;
														goto IL_0c37;
														IL_0c37:
														num5++;
														goto IL_0c45;
														IL_0c45:
														ptr2 += 8;
														goto IL_0437;
														IL_0c58:
														if (15 <= b)
														{
															goto IL_0c66;
														}
														goto IL_0da7;
														IL_0c66:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0c89;
														IL_0c89:
														array[num5] = 0;
														goto IL_0c97;
														IL_0c97:
														num5++;
														goto IL_0ca5;
														IL_0ca5:
														ptr2 += 8;
														goto IL_0437;
														IL_0cb8:
														if (14 > b)
														{
															goto IL_0cc6;
														}
														num = 56;
														goto IL_0d57;
														IL_0cc6:
														if (12 < b)
														{
															goto IL_0cd1;
														}
														goto IL_0d3e;
														IL_0cd1:
														if (13 >= b)
														{
															num = 24;
															goto IL_0ce8;
														}
														goto IL_0da7;
														IL_0d94:
														ptr2 += 8;
														goto IL_0437;
														IL_0ce8:
														if (13 <= b)
														{
															goto IL_0cf6;
														}
														goto IL_0da7;
														IL_0cf6:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(long*)(ptr2 + num4);
														goto IL_0d0f;
														IL_0d0f:
														array[num5] = 1;
														goto IL_0d1d;
														IL_0d1d:
														num5++;
														goto IL_0d2b;
														IL_0d2b:
														ptr2 += 16;
														goto IL_0437;
														continue;
														end_IL_036b:
														break;
													}
													continue;
													end_IL_037e:
													break;
												}
												continue;
												end_IL_0391:
												break;
											}
											continue;
											end_IL_03a5:
											break;
										}
										continue;
										end_IL_03ba:
										break;
									}
									continue;
									end_IL_03ca:
									break;
								}
								continue;
								end_IL_03da:
								break;
							}
							continue;
							end_IL_03f3:
							break;
						}
						continue;
						end_IL_0403:
						break;
					}
					continue;
					end_IL_0413:
					break;
				}
			}
		}
	}

	private unsafe void OnEnable()
	{
		//The blocks IL_0586, IL_0596, IL_059f, IL_05a8, IL_05b6, IL_05c4, IL_05d2, IL_05e0, IL_05ee, IL_0606, IL_0624, IL_0648, IL_0660, IL_0673, IL_0681, IL_068f, IL_069a, IL_06a8, IL_06b6, IL_06df, IL_06f8, IL_0706, IL_0714, IL_0722, IL_073f, IL_078e, IL_0798, IL_07c5, IL_07d9, IL_07e7, IL_07fa, IL_0818, IL_0826, IL_0839, IL_0847, IL_0855, IL_0863, IL_0871, IL_087a, IL_08dc, IL_08ef, IL_08fa, IL_0908, IL_0916, IL_0929, IL_0969, IL_097d, IL_0990, IL_099e, IL_09ac, IL_09ba, IL_09c5, IL_0a05, IL_0a19, IL_0a2c, IL_0a35, IL_0a43, IL_0a51, IL_0a5f, IL_0a82, IL_0a8c, IL_0a9a, IL_0aad, IL_0abb, IL_0ac9, IL_0ad2, IL_0b12, IL_0b2f, IL_0b42, IL_0b50, IL_0b5e, IL_0b69, IL_0b7c, IL_0b85, IL_0b93, IL_0b9e, IL_0bac, IL_0bec, IL_0c00, IL_0c13, IL_0c45, IL_0c53, IL_0c66, IL_0caf, IL_0cc3, IL_0cd6, IL_0ce4, IL_0cef, IL_0d2f, IL_0d43, IL_0d56, IL_0d64, IL_0d72, IL_0d80, IL_0d8e, IL_0d97, IL_0da5, IL_0dcc, IL_0dda, IL_0de8, IL_0e04, IL_0e2e, IL_0e47, IL_0e55, IL_0e63, IL_0e8e, IL_0ea7, IL_0eb5, IL_0ec3, IL_0ece, IL_0f0c, IL_0f1f, IL_0f2d, IL_0f3b, IL_0f49, IL_0f61, IL_0f6f, IL_0f82, IL_0f90, IL_0f9e, IL_0fb2, IL_0fea, IL_0ffd, IL_1021, IL_102f, IL_103d, IL_1050, IL_105e, IL_1069, IL_1092, IL_10a0, IL_10b3, IL_10c1, IL_10cc, IL_1105, IL_1119, IL_112c, IL_113a, IL_1148, IL_1162, IL_1175, IL_1183, IL_1191, IL_11a5, IL_11f1, IL_11ff, IL_1212, IL_1220, IL_122b, IL_1239, IL_1247, IL_1263, IL_126e, IL_127c, IL_128a, IL_12ab, IL_12b9, IL_12c7, IL_12da, IL_1303, IL_1311, IL_1324, IL_1332, IL_1340, IL_1353, IL_136e are reachable both inside and outside the pinned region starting at IL_056f. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 287;
		int num3;
		byte[] array2;
		object[] array3;
		int[] array4;
		int[] array5;
		long[] array6;
		object[] array7;
		byte* ptr = default(byte*);
		byte* num4;
		int num5;
		int num6 = default(int);
		int num7 = default(int);
		object[] array8;
		int num8;
		byte* num9;
		int __rxRef49 = default(int);
		ref int reference = ref __rxRef49;
		byte* ptr2 = default(byte*);
		byte b = default(byte);
		while (true)
		{
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_055a:
					int num2 = 1;
					while (true)
					{
						IL_054a:
						num3 = num2 * 4;
						while (true)
						{
							IL_053f:
							num = 34;
							while (true)
							{
								IL_052f:
								array2 = new byte[4];
								while (true)
								{
									IL_051f:
									array3 = new object[4];
									while (true)
									{
										IL_050f:
										array4 = new int[4];
										while (true)
										{
											IL_04ff:
											array5 = new int[6];
											while (true)
											{
												IL_04ef:
												array6 = new long[4];
												while (true)
												{
													IL_04df:
													array7 = new object[12];
													while (true)
													{
														IL_04c6:
														array7[0] = this;
														num = 297;
														while (true)
														{
															if (num != 297)
															{
																if (num != 1278)
																{
																	goto IL_1353;
																}
																switch (num)
																{
																case 287:
																	break;
																default:
																	continue;
																case 248:
																	goto IL_04c6;
																case 125:
																	goto IL_04df;
																case 244:
																	goto IL_04ef;
																case 57:
																	goto IL_04ff;
																case 18:
																	goto IL_050f;
																case 6:
																	goto IL_051f;
																case 34:
																	goto IL_052f;
																case 255:
																	goto IL_053f;
																case 166:
																	goto IL_054a;
																case 286:
																	goto IL_055a;
																case 50:
																	goto IL_057e;
																case 10:
																case 11:
																case 13:
																case 28:
																case 31:
																case 35:
																case 38:
																case 51:
																case 62:
																case 68:
																case 84:
																case 105:
																case 129:
																case 131:
																case 138:
																case 142:
																case 148:
																case 161:
																case 182:
																case 185:
																case 195:
																case 204:
																case 219:
																case 221:
																case 222:
																case 224:
																case 235:
																case 239:
																case 256:
																case 265:
																case 275:
																case 284:
																case 288:
																	goto IL_0586;
																case 247:
																	goto IL_0596;
																case 180:
																	goto IL_059f;
																case 82:
																	goto IL_05a8;
																case 63:
																	goto IL_05b6;
																case 89:
																	goto IL_05c4;
																case 101:
																	goto IL_05d2;
																case 24:
																	goto IL_05e0;
																case 5:
																case 27:
																	goto IL_05ee;
																case 116:
																	goto IL_0606;
																case 65:
																	goto IL_0624;
																case 160:
																	goto IL_0648;
																case 270:
																	goto IL_0660;
																case 143:
																case 258:
																	goto IL_0673;
																case 174:
																case 242:
																	goto IL_0681;
																case 25:
																	goto IL_068f;
																case 109:
																case 164:
																	goto IL_069a;
																case 98:
																	goto IL_06a8;
																case 171:
																case 282:
																	goto IL_06b6;
																case 78:
																	goto IL_06df;
																case 193:
																	goto IL_06f8;
																case 208:
																case 251:
																	goto IL_0706;
																case 190:
																	goto IL_0714;
																case 152:
																case 243:
																	goto IL_0722;
																case 209:
																	goto IL_07d9;
																case 151:
																	goto IL_07e7;
																case 112:
																case 259:
																	goto IL_07fa;
																case 279:
																	goto IL_0818;
																case 156:
																	goto IL_0826;
																case 12:
																	goto IL_0839;
																case 107:
																case 196:
																	goto IL_0847;
																case 1:
																case 49:
																	goto IL_0855;
																case 220:
																	goto IL_0863;
																case 141:
																case 200:
																	goto IL_087a;
																case 14:
																	goto IL_08dc;
																case 172:
																	goto IL_08ef;
																case 42:
																case 277:
																	goto IL_08fa;
																case 72:
																	goto IL_0908;
																case 79:
																case 232:
																	goto IL_0916;
																case 154:
																case 189:
																	goto IL_0929;
																case 217:
																	goto IL_0969;
																case 273:
																	goto IL_097d;
																case 53:
																	goto IL_0990;
																case 144:
																case 283:
																	goto IL_099e;
																case 9:
																case 268:
																	goto IL_09ac;
																case 186:
																	goto IL_09ba;
																case 137:
																case 280:
																	goto IL_09c5;
																case 128:
																	goto IL_0a05;
																case 178:
																	goto IL_0a19;
																case 70:
																case 165:
																	goto IL_0a35;
																case 118:
																	goto IL_0a43;
																case 225:
																case 240:
																	goto IL_0a51;
																case 188:
																	goto IL_0a5f;
																case 139:
																	goto IL_0a82;
																case 2:
																	goto IL_0a8c;
																case 230:
																	goto IL_0a9a;
																case 192:
																	goto IL_0aad;
																case 201:
																	goto IL_0abb;
																case 30:
																case 150:
																	goto IL_0ad2;
																case 37:
																	goto IL_0b12;
																case 206:
																	goto IL_0b2f;
																case 214:
																	goto IL_0b50;
																case 215:
																	goto IL_0b5e;
																case 123:
																	goto IL_0b69;
																case 117:
																case 134:
																	goto IL_0b85;
																case 94:
																	goto IL_0b93;
																case 26:
																case 271:
																	goto IL_0bac;
																case 177:
																	goto IL_0bec;
																case 60:
																	goto IL_0c00;
																case 23:
																case 213:
																	goto IL_0c13;
																case 81:
																	goto IL_0c45;
																case 96:
																	goto IL_0c53;
																case 20:
																case 250:
																	goto IL_0c66;
																case 80:
																	goto IL_0caf;
																case 191:
																	goto IL_0cc3;
																case 8:
																	goto IL_0cd6;
																case 59:
																	goto IL_0ce4;
																case 147:
																case 234:
																	goto IL_0cef;
																case 233:
																	goto IL_0d2f;
																case 86:
																	goto IL_0d43;
																case 199:
																	goto IL_0d56;
																case 7:
																case 54:
																	goto IL_0d64;
																case 157:
																	goto IL_0d72;
																case 183:
																	goto IL_0d80;
																case 41:
																	goto IL_0d97;
																case 126:
																case 146:
																	goto IL_0da5;
																case 267:
																	goto IL_0dcc;
																case 254:
																	goto IL_0dda;
																case 110:
																	goto IL_0de8;
																case 170:
																case 216:
																	goto IL_0e04;
																case 97:
																	goto IL_0e2e;
																case 159:
																	goto IL_0e47;
																case 184:
																	goto IL_0e55;
																case 168:
																case 290:
																	goto IL_0e63;
																case 69:
																	goto IL_0e8e;
																case 212:
																	goto IL_0ea7;
																case 102:
																case 237:
																	goto IL_0eb5;
																case 127:
																	goto IL_0ec3;
																case 77:
																case 245:
																	goto IL_0ece;
																case 4:
																	goto IL_0f0c;
																case 169:
																	goto IL_0f1f;
																case 223:
																	goto IL_0f2d;
																case 179:
																case 261:
																	goto IL_0f3b;
																case 140:
																	goto IL_0f49;
																case 15:
																	goto IL_0f61;
																case 61:
																	goto IL_0f6f;
																case 252:
																	goto IL_0f82;
																case 91:
																	goto IL_0f90;
																case 67:
																case 231:
																	goto IL_0f9e;
																case 115:
																	goto IL_0fb2;
																case 64:
																	goto IL_0fea;
																case 93:
																case 176:
																	goto IL_0ffd;
																case 83:
																	goto IL_1021;
																case 238:
																	goto IL_102f;
																case 130:
																	goto IL_103d;
																case 103:
																	goto IL_1050;
																case 43:
																	goto IL_105e;
																case 276:
																case 278:
																	goto IL_1069;
																case 121:
																	goto IL_1092;
																case 167:
																	goto IL_10a0;
																case 40:
																	goto IL_10b3;
																case 45:
																	goto IL_10c1;
																case 155:
																case 285:
																	goto IL_10cc;
																case 210:
																	goto IL_1105;
																case 228:
																	goto IL_1119;
																case 104:
																	goto IL_112c;
																case 218:
																	goto IL_113a;
																case 22:
																case 113:
																	goto IL_1148;
																case 21:
																	goto IL_1162;
																case 92:
																case 281:
																	goto IL_1175;
																case 17:
																	goto IL_1183;
																case 241:
																case 262:
																	goto IL_1191;
																case 120:
																	goto IL_11a5;
																case 75:
																	goto IL_11f1;
																case 132:
																	goto IL_11ff;
																case 29:
																	goto IL_1220;
																case 114:
																case 249:
																	goto IL_122b;
																case 16:
																	goto IL_1239;
																case 52:
																case 95:
																	goto IL_1247;
																case 149:
																	goto IL_1263;
																case 55:
																case 66:
																	goto IL_126e;
																case 272:
																	goto IL_127c;
																case 175:
																case 260:
																	goto IL_128a;
																case 124:
																	goto IL_12ab;
																case 108:
																	goto IL_12b9;
																case 253:
																	goto IL_12c7;
																case 269:
																case 274:
																	goto IL_12da;
																case 246:
																	goto IL_1303;
																case 36:
																	goto IL_1311;
																case 135:
																	goto IL_1324;
																case 194:
																	goto IL_1332;
																case 162:
																	goto IL_1340;
																case 0:
																case 3:
																case 19:
																case 33:
																case 39:
																case 44:
																case 46:
																case 47:
																case 48:
																case 56:
																case 58:
																case 71:
																case 73:
																case 74:
																case 76:
																case 85:
																case 87:
																case 88:
																case 90:
																case 99:
																case 100:
																case 106:
																case 111:
																case 119:
																case 122:
																case 133:
																case 136:
																case 145:
																case 153:
																case 158:
																case 163:
																case 173:
																case 181:
																case 187:
																case 197:
																case 198:
																case 202:
																case 203:
																case 205:
																case 207:
																case 211:
																case 226:
																case 227:
																case 229:
																case 257:
																case 263:
																case 264:
																case 266:
																case 289:
																	goto IL_1353;
																case 32:
																case 236:
																	return;
																}
																break;
															}
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref queueIsMailNewsSave.VerificationExceptionUntrusted);
															goto IL_057e;
															IL_1247:
															num4 = ptr2;
															num5 = -200;
															num6 = 1;
															ptr2 = num4 + num5;
															goto IL_0586;
															IL_126e:
															if (28 >= b)
															{
																goto IL_127c;
															}
															goto IL_1353;
															IL_1263:
															if (29 > b)
															{
																goto IL_126e;
															}
															goto IL_12da;
															IL_057e:
															ptr2 = ptr;
															goto IL_0586;
															IL_0586:
															if (num6 == 1)
															{
																num = 32;
																return;
															}
															goto IL_0596;
															IL_127c:
															if (28 <= b)
															{
																goto IL_128a;
															}
															goto IL_1353;
															IL_0596:
															num = 180;
															goto IL_059f;
															IL_059f:
															b = *ptr2;
															goto IL_05a8;
															IL_05a8:
															ptr2++;
															goto IL_05b6;
															IL_05b6:
															if (b >= 1)
															{
																goto IL_05c4;
															}
															goto IL_1353;
															IL_05c4:
															if (b <= 30)
															{
																goto IL_05d2;
															}
															goto IL_1353;
															IL_05d2:
															if (15 >= b)
															{
																goto IL_05e0;
															}
															goto IL_0cd6;
															IL_05e0:
															if (15 <= b)
															{
																goto IL_05ee;
															}
															goto IL_0673;
															IL_05ee:
															array2[num7] = array2[num7 - 1];
															goto IL_0606;
															IL_0606:
															array4[num7 - 0] = array4[num7 - 1];
															goto IL_0624;
															IL_0624:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															goto IL_0648;
															IL_0648:
															array3[num7] = array3[num7 - 1];
															goto IL_0660;
															IL_0660:
															num7++;
															goto IL_0586;
															IL_0673:
															if (7 < b)
															{
																goto IL_0681;
															}
															goto IL_0990;
															IL_0681:
															if (11 < b)
															{
																goto IL_068f;
															}
															goto IL_0839;
															IL_068f:
															if (13 < b)
															{
																goto IL_069a;
															}
															goto IL_06f8;
															IL_069a:
															if (14 >= b)
															{
																goto IL_06a8;
															}
															goto IL_1353;
															IL_06a8:
															if (14 <= b)
															{
																goto IL_06b6;
															}
															goto IL_1353;
															IL_06b6:
															array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
															goto IL_06df;
															IL_06df:
															array2[num7 - 1] = 5;
															goto IL_0586;
															IL_06f8:
															if (13 > b)
															{
																goto IL_0706;
															}
															goto IL_07fa;
															IL_0706:
															if (12 >= b)
															{
																goto IL_0714;
															}
															goto IL_1353;
															IL_0714:
															if (12 <= b)
															{
																goto IL_0722;
															}
															goto IL_1353;
															IL_0722:
															array8 = array3;
															num8 = num7;
															if (array == null)
															{
																goto end_IL_0565;
															}
															num9 = ptr2;
															byte b2 = *num9;
															ptr2 = num9 + 4;
															int num10 = *(int*)(ptr2 + num3);
															ptr2 += 8;
															byte* ptr3 = ptr2 + num10;
															byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
															while (ptr2 != ptr3)
															{
																*ptr4 = (byte)(*ptr2 ^ b2);
																ptr2++;
																ptr4++;
															}
															array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
															goto IL_07d9;
															IL_128a:
															array3[num7] = array7[*(int*)(ptr2 + num3)];
															num = 124;
															goto IL_12ab;
															IL_12ab:
															array2[num7] = 5;
															goto IL_12b9;
															IL_12b9:
															num7++;
															goto IL_12c7;
															IL_07d9:
															array2[num7] = 5;
															goto IL_07e7;
															IL_07e7:
															num7++;
															goto IL_0586;
															IL_07fa:
															array7[*(int*)(ptr2 + num3)] = array3[num7 - 1];
															goto IL_0818;
															IL_0818:
															ptr2 += 8;
															goto IL_0826;
															IL_0826:
															num7--;
															goto IL_0586;
															IL_0839:
															if (11 <= b)
															{
																goto IL_0586;
															}
															goto IL_0847;
															IL_0847:
															if (9 < b)
															{
																goto IL_0855;
															}
															goto IL_08ef;
															IL_0855:
															if (10 >= b)
															{
																goto IL_0863;
															}
															goto IL_1353;
															IL_0863:
															if (10 <= b)
															{
																num = 200;
																goto IL_087a;
															}
															goto IL_1353;
															IL_12c7:
															ptr2 += 8;
															goto IL_0586;
															IL_087a:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_08dc;
															IL_08dc:
															num7 -= 2;
															goto IL_0586;
															IL_08ef:
															if (9 > b)
															{
																goto IL_08fa;
															}
															goto IL_0929;
															IL_08fa:
															if (8 >= b)
															{
																goto IL_0908;
															}
															goto IL_1353;
															IL_0908:
															if (8 <= b)
															{
																goto IL_0916;
															}
															goto IL_1353;
															IL_0916:
															num7--;
															goto IL_0586;
															IL_0929:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															goto IL_0969;
															IL_0969:
															array2[num7 - 2] = 0;
															goto IL_097d;
															IL_097d:
															num7--;
															goto IL_0586;
															IL_0990:
															if (7 > b)
															{
																goto IL_099e;
															}
															goto IL_0c66;
															IL_099e:
															if (3 < b)
															{
																goto IL_09ac;
															}
															goto IL_0b50;
															IL_09ac:
															if (5 >= b)
															{
																goto IL_09ba;
															}
															goto IL_0aad;
															IL_09ba:
															if (5 <= b)
															{
																goto IL_09c5;
															}
															num = 70;
															goto IL_0a35;
															IL_09c5:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															goto IL_0a05;
															IL_0a05:
															array2[num7 - 2] = 0;
															goto IL_0a19;
															IL_0a19:
															num7--;
															goto IL_0586;
															IL_12da:
															((delegate*<UnityEngine.Object, void>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((Class134)array3[num7 - 1]);
															goto IL_1303;
															IL_0a35:
															if (4 >= b)
															{
																goto IL_0a43;
															}
															goto IL_1353;
															IL_0a43:
															if (4 <= b)
															{
																goto IL_0a51;
															}
															goto IL_1353;
															IL_0a51:
															array2[num7] = 0;
															goto IL_0a5f;
															IL_0a5f:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = array5[*(int*)(ptr2 + num3)];
															goto IL_0a82;
															IL_0a82:
															array3[num7] = null;
															goto IL_0a8c;
															IL_0a8c:
															num7++;
															goto IL_0a9a;
															IL_0a9a:
															ptr2 += 8;
															goto IL_0586;
															IL_0aad:
															if (6 >= b)
															{
																goto IL_0abb;
															}
															num = 100;
															goto IL_1353;
															IL_0abb:
															if (6 <= b)
															{
																num = 30;
																goto IL_0ad2;
															}
															goto IL_1353;
															IL_1311:
															ptr2 += 8;
															goto IL_0586;
															IL_0ad2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															goto IL_0b12;
															IL_0b12:
															array2[num7 - 2] = 0;
															num = 206;
															goto IL_0b2f;
															IL_0b2f:
															num7--;
															goto IL_0586;
															IL_1303:
															num7--;
															goto IL_1311;
															IL_0b50:
															if (3 > b)
															{
																goto IL_0b5e;
															}
															goto IL_0c13;
															IL_0b5e:
															if (1 >= b)
															{
																goto IL_0b69;
															}
															num = 117;
															goto IL_0b85;
															IL_0b69:
															if (1 > b)
															{
															}
															goto IL_1353;
															IL_1353:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(int*)(ptr2 + num3);
															goto IL_1324;
															IL_0b85:
															if (2 >= b)
															{
																goto IL_0b93;
															}
															goto IL_1353;
															IL_0b93:
															if (2 <= b)
															{
																goto IL_0bac;
															}
															num = 48;
															goto IL_1353;
															IL_1324:
															array2[num7] = 0;
															goto IL_1332;
															IL_0bac:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															goto IL_0bec;
															IL_0bec:
															array2[num7 - 2] = 0;
															goto IL_0c00;
															IL_0c00:
															num7--;
															goto IL_0586;
															IL_0c13:
															reference = ref array5[*(int*)(ptr2 + num3)];
															reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															num = 81;
															goto IL_0c45;
															IL_0c45:
															ptr2 += 8;
															goto IL_0c53;
															IL_0c53:
															num7--;
															goto IL_0586;
															IL_0c66:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															num = 80;
															goto IL_0caf;
															IL_0caf:
															array2[num7 - 2] = 0;
															goto IL_0cc3;
															IL_0cc3:
															num7--;
															goto IL_0586;
															IL_0cd6:
															if (23 >= b)
															{
																goto IL_0ce4;
															}
															goto IL_1050;
															IL_0ce4:
															if (23 <= b)
															{
																goto IL_0cef;
															}
															goto IL_0d56;
															IL_0cef:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															goto IL_0d2f;
															IL_0d2f:
															array2[num7 - 2] = 0;
															goto IL_0d43;
															IL_0d43:
															num7--;
															goto IL_0586;
															IL_0d56:
															if (19 < b)
															{
																goto IL_0d64;
															}
															goto IL_0ea7;
															IL_0d64:
															if (21 >= b)
															{
																goto IL_0d72;
															}
															goto IL_0e47;
															IL_0d72:
															if (21 > b)
															{
																goto IL_0d80;
															}
															goto IL_0e04;
															IL_0d80:
															if (20 >= b)
															{
																num = 41;
																goto IL_0d97;
															}
															goto IL_1353;
															IL_1332:
															num7++;
															goto IL_1340;
															IL_0d97:
															if (20 <= b)
															{
																goto IL_0da5;
															}
															goto IL_1353;
															IL_0da5:
															array3[num7] = ((delegate*<string[]>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])();
															num = 267;
															goto IL_0dcc;
															IL_0dcc:
															array2[num7] = 5;
															goto IL_0dda;
															IL_0dda:
															num7++;
															goto IL_0de8;
															IL_0de8:
															ptr2 += 8;
															num = 10;
															goto IL_0586;
															IL_0e04:
															*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]) = (nint)((string[])array3[num7 - 1]).LongLength;
															goto IL_0e2e;
															IL_0e2e:
															array2[num7 - 1] = 2;
															goto IL_0586;
															IL_0e47:
															if (22 >= b)
															{
																goto IL_0e55;
															}
															goto IL_1353;
															IL_0e55:
															if (22 <= b)
															{
																goto IL_0e63;
															}
															goto IL_1353;
															IL_0e63:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]));
															goto IL_0e8e;
															IL_0e8e:
															array2[num7 - 1] = 0;
															goto IL_0586;
															IL_0ea7:
															if (19 > b)
															{
																goto IL_0eb5;
															}
															goto IL_0ffd;
															IL_0eb5:
															if (17 >= b)
															{
																goto IL_0ec3;
															}
															goto IL_0f82;
															IL_0ec3:
															if (17 <= b)
															{
																goto IL_0ece;
															}
															goto IL_0f1f;
															IL_0ece:
															((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2])] = (string)array3[num7 - 1];
															goto IL_0f0c;
															IL_0f0c:
															num7 -= 3;
															goto IL_0586;
															IL_0f1f:
															if (16 >= b)
															{
																goto IL_0f2d;
															}
															goto IL_1353;
															IL_0f2d:
															if (16 <= b)
															{
																goto IL_0f3b;
															}
															goto IL_1353;
															IL_0f3b:
															array2[num7] = 5;
															goto IL_0f49;
															IL_0f49:
															array3[num7] = array7[*(int*)(ptr2 + num3)];
															goto IL_0f61;
															IL_0f61:
															num7++;
															goto IL_0f6f;
															IL_0f6f:
															ptr2 += 8;
															goto IL_0586;
															IL_0f82:
															if (18 >= b)
															{
																goto IL_0f90;
															}
															goto IL_1353;
															IL_0f90:
															if (18 <= b)
															{
																goto IL_0f9e;
															}
															goto IL_1353;
															IL_0f9e:
															array2[num7 - 1] = 5;
															goto IL_0fb2;
															IL_0fb2:
															array3[num7 - 1] = ((delegate*<string[], string>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
															goto IL_0fea;
															IL_0fea:
															ptr2 += 8;
															goto IL_0586;
															IL_0ffd:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = ((delegate*<int>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])();
															goto IL_1021;
															IL_1021:
															array2[num7] = 0;
															goto IL_102f;
															IL_102f:
															num7++;
															goto IL_103d;
															IL_103d:
															ptr2 += 8;
															goto IL_0586;
															IL_1050:
															if (27 >= b)
															{
																goto IL_105e;
															}
															goto IL_1220;
															IL_105e:
															if (27 <= b)
															{
																goto IL_1069;
															}
															goto IL_10b3;
															IL_1069:
															((delegate*<string, void>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((string)array3[num7 - 1]);
															goto IL_1092;
															IL_1092:
															num7--;
															goto IL_10a0;
															IL_10a0:
															ptr2 += 8;
															goto IL_0586;
															IL_10b3:
															if (25 >= b)
															{
																goto IL_10c1;
															}
															goto IL_1175;
															IL_10c1:
															if (25 <= b)
															{
																goto IL_10cc;
															}
															goto IL_112c;
															IL_10cc:
															array3[num7 - 2] = ((string[])array3[num7 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
															goto IL_1105;
															IL_1105:
															array2[num7 - 2] = 5;
															goto IL_1119;
															IL_1119:
															num7--;
															goto IL_0586;
															IL_112c:
															if (24 >= b)
															{
																goto IL_113a;
															}
															goto IL_1353;
															IL_113a:
															if (24 <= b)
															{
																goto IL_1148;
															}
															goto IL_1353;
															IL_1148:
															int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
															goto IL_1162;
															IL_1162:
															num7--;
															goto IL_0586;
															IL_1175:
															if (26 >= b)
															{
																goto IL_1183;
															}
															goto IL_1353;
															IL_1183:
															if (26 <= b)
															{
																goto IL_1191;
															}
															num = 289;
															goto IL_1353;
															IL_1191:
															array2[num7 - 2] = 5;
															goto IL_11a5;
															IL_11a5:
															array3[num7 - 2] = ((delegate*<string, string, string>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((string)array3[num7 - 2], (string)array3[num7 - 1]);
															goto IL_11f1;
															IL_11f1:
															num7--;
															goto IL_11ff;
															IL_11ff:
															ptr2 += 8;
															goto IL_0586;
															IL_1340:
															ptr2 += 8;
															goto IL_0586;
															IL_1220:
															if (29 < b)
															{
																goto IL_122b;
															}
															goto IL_1263;
															IL_122b:
															if (30 >= b)
															{
																goto IL_1239;
															}
															goto IL_1353;
															IL_1239:
															if (30 <= b)
															{
																goto IL_1247;
															}
															goto IL_1353;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			end_IL_0565:
			break;
		}
		while (true)
		{
			byte[] array = new byte[4];
			do
			{
				num9 = ptr2;
				byte b2 = *num9;
				ptr2 = num9 + 4;
				int num10 = *(int*)(ptr2 + num3);
				ptr2 += 8;
				byte* ptr3 = ptr2 + num10;
				byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
				while (ptr2 != ptr3)
				{
					*ptr4 = (byte)(*ptr2 ^ b2);
					ptr2++;
					ptr4++;
				}
				array8[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
				array2[num7] = 5;
				num7++;
				while (true)
				{
					if (num6 != 1)
					{
						num = 180;
						b = *ptr2;
						ptr2++;
						if (b >= 1 && b <= 30)
						{
							if (15 >= b)
							{
								if (15 <= b)
								{
									array2[num7] = array2[num7 - 1];
									array4[num7 - 0] = array4[num7 - 1];
									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
									array3[num7] = array3[num7 - 1];
									num7++;
									continue;
								}
								if (7 < b)
								{
									if (11 < b)
									{
										if (13 < b)
										{
											if (14 >= b && 14 <= b)
											{
												array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
												array2[num7 - 1] = 5;
												continue;
											}
										}
										else
										{
											if (13 <= b)
											{
												array7[*(int*)(ptr2 + num3)] = array3[num7 - 1];
												ptr2 += 8;
												num7--;
												continue;
											}
											if (12 >= b && 12 <= b)
											{
												break;
											}
										}
									}
									else
									{
										if (11 <= b)
										{
											continue;
										}
										if (9 < b)
										{
											if (10 >= b && 10 <= b)
											{
												num = 200;
												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
												num7 -= 2;
												continue;
											}
										}
										else
										{
											if (9 <= b)
											{
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
												array2[num7 - 2] = 0;
												num7--;
												continue;
											}
											if (8 >= b && 8 <= b)
											{
												num7--;
												continue;
											}
										}
									}
								}
								else
								{
									if (7 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
										num = 80;
										array2[num7 - 2] = 0;
										num7--;
										continue;
									}
									if (3 < b)
									{
										if (5 >= b)
										{
											if (5 <= b)
											{
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
												array2[num7 - 2] = 0;
												num7--;
												continue;
											}
											num = 70;
											if (4 >= b && 4 <= b)
											{
												array2[num7] = 0;
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = array5[*(int*)(ptr2 + num3)];
												array3[num7] = null;
												num7++;
												ptr2 += 8;
												continue;
											}
										}
										else if (6 >= b)
										{
											if (6 <= b)
											{
												num = 30;
												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
												array2[num7 - 2] = 0;
												num = 206;
												num7--;
												continue;
											}
										}
										else
										{
											num = 100;
										}
									}
									else
									{
										if (3 <= b)
										{
											reference = ref array5[*(int*)(ptr2 + num3)];
											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
											num = 81;
											ptr2 += 8;
											num7--;
											continue;
										}
										if (1 >= b)
										{
											if (1 > b)
											{
											}
										}
										else
										{
											num = 117;
											if (2 >= b)
											{
												if (2 <= b)
												{
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
													array2[num7 - 2] = 0;
													num7--;
													continue;
												}
												num = 48;
											}
										}
									}
								}
							}
							else if (23 >= b)
							{
								if (23 <= b)
								{
									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
									array2[num7 - 2] = 0;
									num7--;
									continue;
								}
								if (19 < b)
								{
									if (21 >= b)
									{
										if (21 <= b)
										{
											*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]) = (nint)((string[])array3[num7 - 1]).LongLength;
											array2[num7 - 1] = 2;
											continue;
										}
										if (20 >= b)
										{
											num = 41;
											if (20 <= b)
											{
												array3[num7] = ((delegate*<string[]>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])();
												num = 267;
												array2[num7] = 5;
												num7++;
												ptr2 += 8;
												num = 10;
												continue;
											}
										}
									}
									else if (22 >= b && 22 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]));
										array2[num7 - 1] = 0;
										continue;
									}
								}
								else
								{
									if (19 <= b)
									{
										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = ((delegate*<int>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])();
										array2[num7] = 0;
										num7++;
										ptr2 += 8;
										continue;
									}
									if (17 >= b)
									{
										if (17 <= b)
										{
											((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 2])] = (string)array3[num7 - 1];
											num7 -= 3;
											continue;
										}
										if (16 >= b && 16 <= b)
										{
											array2[num7] = 5;
											array3[num7] = array7[*(int*)(ptr2 + num3)];
											num7++;
											ptr2 += 8;
											continue;
										}
									}
									else if (18 >= b && 18 <= b)
									{
										array2[num7 - 1] = 5;
										array3[num7 - 1] = ((delegate*<string[], string>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
										ptr2 += 8;
										continue;
									}
								}
							}
							else if (27 >= b)
							{
								if (27 <= b)
								{
									((delegate*<string, void>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((string)array3[num7 - 1]);
									num7--;
									ptr2 += 8;
									continue;
								}
								if (25 >= b)
								{
									if (25 <= b)
									{
										array3[num7 - 2] = ((string[])array3[num7 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1])];
										array2[num7 - 2] = 5;
										num7--;
										continue;
									}
									if (24 >= b && 24 <= b)
									{
										int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7 - 1]);
										num7--;
										continue;
									}
								}
								else if (26 >= b)
								{
									if (26 <= b)
									{
										array2[num7 - 2] = 5;
										array3[num7 - 2] = ((delegate*<string, string, string>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((string)array3[num7 - 2], (string)array3[num7 - 1]);
										num7--;
										ptr2 += 8;
										continue;
									}
									num = 289;
								}
							}
							else if (29 < b)
							{
								if (30 >= b && 30 <= b)
								{
									num4 = ptr2;
									num5 = -200;
									num6 = 1;
									ptr2 = num4 + num5;
									continue;
								}
							}
							else
							{
								if (29 <= b)
								{
									((delegate*<UnityEngine.Object, void>)NextgetExceptionTypeToken[*(int*)(ptr2 + num3)])((Class134)array3[num7 - 1]);
									num7--;
									ptr2 += 8;
									continue;
								}
								if (28 >= b && 28 <= b)
								{
									array3[num7] = array7[*(int*)(ptr2 + num3)];
									num = 124;
									array2[num7] = 5;
									num7++;
									ptr2 += 8;
									continue;
								}
							}
						}
						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num7]) = *(int*)(ptr2 + num3);
						array2[num7] = 0;
						num7++;
						ptr2 += 8;
						continue;
					}
					num = 32;
					return;
				}
				array8 = array3;
				num8 = num7;
			}
			while (array != null);
		}
	}

	public unsafe static string smethod_0()
	{
		int num = 132;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 131;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						num = 5;
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[7];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SYSWINZeros.getApplicationIdgetIsOut);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num5 != 1)
												{
													while (true)
													{
														IL_042e:
														byte b = *ptr2;
														while (true)
														{
															IL_041e:
															ptr2++;
															while (true)
															{
																IL_040e:
																if (b >= 1)
																{
																	while (b <= 21)
																	{
																		num = 24;
																		while (true)
																		{
																			IL_03eb:
																			if (11 < b)
																			{
																				while (true)
																				{
																					IL_03db:
																					if (16 >= b)
																					{
																						while (true)
																						{
																							IL_03cb:
																							if (16 > b)
																							{
																								while (true)
																								{
																									IL_03be:
																									if (13 < b)
																									{
																										while (true)
																										{
																											IL_03ae:
																											if (14 >= b)
																											{
																												while (14 <= b)
																												{
																													while (true)
																													{
																														IL_0380:
																														ptr2 = ptr + *(int*)(ptr2 + num3);
																														num = 212;
																														while (num != 212)
																														{
																															if (num != 1193)
																															{
																																goto end_IL_039e;
																															}
																															switch (num)
																															{
																															case 34:
																															case 112:
																																goto IL_0380;
																															case 22:
																																goto IL_039e;
																															case 136:
																															case 144:
																																goto IL_03ae;
																															case 142:
																															case 200:
																																goto IL_03be;
																															case 170:
																																goto IL_03cb;
																															case 63:
																																goto IL_03db;
																															case 24:
																																goto IL_03eb;
																															case 116:
																																goto IL_03fb;
																															case 118:
																																goto IL_040e;
																															case 39:
																																goto IL_041e;
																															case 94:
																															case 122:
																																goto IL_042e;
																															case 33:
																																goto IL_0439;
																															case 7:
																															case 57:
																																goto IL_0447;
																															case 84:
																																goto IL_0460;
																															case 98:
																																goto IL_046e;
																															case 154:
																																goto IL_0481;
																															case 36:
																																goto IL_048f;
																															case 128:
																																goto IL_049d;
																															case 15:
																															case 86:
																																goto IL_04a8;
																															case 85:
																																goto IL_04e8;
																															case 79:
																																goto IL_04fc;
																															case 16:
																															case 74:
																																goto IL_0518;
																															case 20:
																															case 135:
																																goto IL_052f;
																															case 1:
																																goto IL_053d;
																															case 26:
																															case 140:
																																goto IL_054b;
																															case 130:
																																goto IL_057d;
																															case 54:
																																goto IL_058b;
																															case 107:
																															case 143:
																																goto IL_059e;
																															case 6:
																																goto IL_05b2;
																															case 17:
																																goto IL_060f;
																															case 92:
																															case 163:
																																goto IL_0622;
																															case 83:
																																goto IL_0630;
																															case 0:
																															case 31:
																																goto IL_063e;
																															case 127:
																																goto IL_0649;
																															case 51:
																															case 77:
																																goto IL_0657;
																															case 61:
																																goto IL_0697;
																															case 32:
																																goto IL_06b9;
																															case 28:
																																goto IL_06c7;
																															case 9:
																															case 158:
																																goto IL_06da;
																															case 65:
																															case 164:
																																goto IL_06ed;
																															case 162:
																																goto IL_06f8;
																															case 150:
																																goto IL_0706;
																															case 166:
																																goto IL_0727;
																															case 101:
																															case 148:
																																goto IL_0732;
																															case 10:
																																goto IL_0740;
																															case 13:
																															case 155:
																																goto IL_0753;
																															case 138:
																																goto IL_0793;
																															case 117:
																																goto IL_07a7;
																															case 168:
																																goto IL_07ba;
																															case 172:
																																goto IL_07cd;
																															case 14:
																															case 173:
																																goto IL_07e0;
																															case 55:
																																goto IL_0820;
																															case 68:
																																goto IL_083d;
																															case 95:
																															case 179:
																																goto IL_0850;
																															case 146:
																																goto IL_0872;
																															case 59:
																																goto IL_0880;
																															case 176:
																																goto IL_088e;
																															case 123:
																															case 189:
																																goto IL_08a1;
																															case 125:
																																goto IL_08af;
																															case 35:
																															case 192:
																																goto IL_08bd;
																															case 82:
																																goto IL_08cb;
																															case 145:
																																goto IL_08ee;
																															case 18:
																																goto IL_08f8;
																															case 27:
																																goto IL_0906;
																															case 90:
																															case 195:
																																goto IL_0919;
																															case 50:
																																goto IL_097b;
																															case 78:
																															case 199:
																																goto IL_098e;
																															case 160:
																																goto IL_09ce;
																															case 93:
																																goto IL_09e2;
																															case 167:
																															case 202:
																																goto IL_09f5;
																															case 104:
																																goto IL_0a03;
																															case 203:
																																goto IL_0a16;
																															case 204:
																																goto IL_0a29;
																															case 8:
																																goto IL_0a3c;
																															case 88:
																																goto IL_0a4a;
																															case 121:
																															case 188:
																																goto IL_0a58;
																															case 46:
																																goto IL_0a99;
																															case 96:
																																goto IL_0ab6;
																															case 45:
																															case 194:
																																goto IL_0ac9;
																															case 87:
																																goto IL_0b1b;
																															case 124:
																																goto IL_0b2e;
																															case 81:
																															case 183:
																																goto IL_0b39;
																															case 201:
																																goto IL_0b44;
																															case 43:
																															case 137:
																																goto IL_0b52;
																															case 30:
																																goto IL_0b6e;
																															case 37:
																																goto IL_0b7c;
																															case 147:
																																goto IL_0b8f;
																															case 177:
																															case 178:
																																goto IL_0ba6;
																															case 4:
																																goto IL_0bb1;
																															case 44:
																															case 75:
																																goto IL_0bbf;
																															case 69:
																																goto IL_0bdd;
																															case 71:
																																goto IL_0beb;
																															case 185:
																																goto IL_0bf9;
																															case 105:
																																goto IL_0c0c;
																															case 23:
																																goto IL_0c1a;
																															case 141:
																															case 182:
																																goto IL_0c28;
																															case 53:
																																goto IL_0c4c;
																															case 113:
																																goto IL_0c5a;
																															case 111:
																																goto IL_0c68;
																															case 64:
																															case 181:
																																goto IL_0c78;
																															case 80:
																																goto IL_0cb1;
																															case 133:
																																goto IL_0cc5;
																															case 2:
																															case 11:
																															case 12:
																															case 21:
																															case 29:
																															case 40:
																															case 41:
																															case 42:
																															case 47:
																															case 48:
																															case 49:
																															case 56:
																															case 60:
																															case 62:
																															case 66:
																															case 67:
																															case 70:
																															case 72:
																															case 73:
																															case 76:
																															case 97:
																															case 99:
																															case 102:
																															case 103:
																															case 114:
																															case 115:
																															case 134:
																															case 169:
																															case 171:
																															case 174:
																															case 175:
																															case 186:
																															case 190:
																															case 191:
																															case 197:
																															case 198:
																															case 205:
																																goto end_IL_039e;
																															case 3:
																															case 19:
																															case 38:
																															case 52:
																															case 89:
																															case 100:
																															case 108:
																															case 110:
																															case 119:
																															case 120:
																															case 126:
																															case 129:
																															case 139:
																															case 149:
																															case 151:
																															case 152:
																															case 156:
																															case 157:
																															case 159:
																															case 161:
																															case 165:
																															case 184:
																															case 187:
																																goto end_IL_036d;
																															case 193:
																																goto end_IL_0cf1;
																															case 109:
																																goto end_IL_0d04;
																															case 180:
																																goto end_IL_0d0e;
																															case 25:
																															case 58:
																																goto end_IL_0d19;
																															case 5:
																																goto end_IL_0d29;
																															case 153:
																																goto end_IL_0d39;
																															case 196:
																																goto end_IL_0d49;
																															case 131:
																																goto end_IL_0d62;
																															case 132:
																																goto end_IL_0d72;
																															case 91:
																															case 106:
																																goto IL_0d96;
																															}
																															continue;
																															end_IL_036d:
																															break;
																														}
																														break;
																													}
																													goto end_IL_040e;
																													continue;
																													end_IL_039e:
																													break;
																													IL_039e:;
																												}
																												break;
																											}
																											goto IL_0a3c;
																											IL_0ab6:
																											num6--;
																											goto end_IL_040e;
																											IL_0a3c:
																											if (15 < b)
																											{
																												break;
																											}
																											goto IL_0a4a;
																											IL_0a4a:
																											if (15 > b)
																											{
																												break;
																											}
																											goto IL_0a58;
																											IL_0a58:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0);
																											goto IL_0a99;
																											IL_0a99:
																											array[num6 - 2] = 0;
																											num = 96;
																											goto IL_0ab6;
																										}
																										break;
																									}
																									goto IL_0439;
																									IL_0a03:
																									if (12 > b)
																									{
																										break;
																									}
																									goto end_IL_040e;
																									IL_0439:
																									if (13 <= b)
																									{
																										goto IL_0447;
																									}
																									goto IL_09f5;
																									IL_0447:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																									goto IL_0460;
																									IL_0460:
																									array[num6] = 1;
																									goto IL_046e;
																									IL_046e:
																									num6++;
																									goto IL_07cd;
																									IL_07cd:
																									ptr2 += 16;
																									goto end_IL_040e;
																									IL_09f5:
																									if (12 < b)
																									{
																										break;
																									}
																									goto IL_0a03;
																								}
																								break;
																							}
																							goto IL_0ac9;
																							IL_0b1b:
																							num6--;
																							goto end_IL_040e;
																							IL_0ac9:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0b1b;
																						}
																						break;
																					}
																					goto IL_0b2e;
																					IL_0cb1:
																					array[num6 - 2] = 5;
																					goto IL_0cc5;
																					IL_0b2e:
																					if (19 < b)
																					{
																						goto IL_0b39;
																					}
																					goto IL_0b8f;
																					IL_0b39:
																					if (20 >= b)
																					{
																						goto IL_0b44;
																					}
																					goto IL_0b6e;
																					IL_0b44:
																					if (20 > b)
																					{
																						break;
																					}
																					goto IL_0b52;
																					IL_0b52:
																					byte* num7 = ptr2;
																					num5 = 1;
																					ptr2 = num7 + -200;
																					goto end_IL_040e;
																					IL_0b6e:
																					if (21 < b)
																					{
																						break;
																					}
																					goto IL_0b7c;
																					IL_0b7c:
																					if (21 <= b)
																					{
																					}
																					break;
																					IL_0b8f:
																					if (19 > b)
																					{
																						num = 177;
																						goto IL_0ba6;
																					}
																					goto IL_0c78;
																					IL_0cc5:
																					num6--;
																					num = 89;
																					goto end_IL_040e;
																					IL_0ba6:
																					if (17 >= b)
																					{
																						goto IL_0bb1;
																					}
																					goto IL_0c0c;
																					IL_0bb1:
																					if (17 > b)
																					{
																						break;
																					}
																					goto IL_0bbf;
																					IL_0bbf:
																					array2[num6] = ((delegate*<string[]>)rootGuidScheme[*(int*)(ptr2 + num3)])();
																					goto IL_0bdd;
																					IL_0bdd:
																					array[num6] = 5;
																					goto IL_0beb;
																					IL_0beb:
																					num6++;
																					goto IL_0bf9;
																					IL_0bf9:
																					ptr2 += 8;
																					goto end_IL_040e;
																					IL_0c0c:
																					if (18 < b)
																					{
																						break;
																					}
																					goto IL_0c1a;
																					IL_0c1a:
																					if (18 > b)
																					{
																						break;
																					}
																					goto IL_0c28;
																					IL_0c28:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)rootGuidScheme[*(int*)(ptr2 + num3)])();
																					goto IL_0c4c;
																					IL_0c4c:
																					array[num6] = 0;
																					goto IL_0c5a;
																					IL_0c5a:
																					num6++;
																					goto IL_0c68;
																					IL_0c68:
																					ptr2 += 8;
																					goto end_IL_040e;
																					IL_0c78:
																					array2[num6 - 2] = ((string[])array2[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])];
																					goto IL_0cb1;
																				}
																				break;
																			}
																			goto IL_0481;
																			IL_059e:
																			array[num6 - 2] = 0;
																			goto IL_05b2;
																			IL_0481:
																			if (11 > b)
																			{
																				goto IL_048f;
																			}
																			goto IL_059e;
																			IL_048f:
																			if (5 >= b)
																			{
																				goto IL_049d;
																			}
																			goto IL_0622;
																			IL_049d:
																			if (5 <= b)
																			{
																				goto IL_04a8;
																			}
																			num = 74;
																			goto IL_0518;
																			IL_04a8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_04e8;
																			IL_04e8:
																			array[num6 - 2] = 0;
																			goto IL_04fc;
																			IL_04fc:
																			num6--;
																			goto end_IL_040e;
																			IL_05b2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = ((delegate*<int, int, int>)rootGuidScheme[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
																			num = 17;
																			goto IL_060f;
																			IL_0518:
																			if (2 < b)
																			{
																				num = 135;
																				goto IL_052f;
																			}
																			goto IL_0727;
																			IL_060f:
																			num6--;
																			goto IL_0a16;
																			IL_052f:
																			if (3 >= b)
																			{
																				goto IL_053d;
																			}
																			goto IL_08a1;
																			IL_053d:
																			if (3 > b)
																			{
																				break;
																			}
																			goto IL_054b;
																			IL_054b:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			num = 130;
																			goto IL_057d;
																			IL_057d:
																			ptr2 += 8;
																			goto IL_058b;
																			IL_058b:
																			num6--;
																			goto end_IL_040e;
																			IL_08a1:
																			if (4 < b)
																			{
																				break;
																			}
																			goto IL_08af;
																			IL_08af:
																			if (4 > b)
																			{
																				break;
																			}
																			goto IL_08bd;
																			IL_08bd:
																			array[num6] = 0;
																			goto IL_08cb;
																			IL_08cb:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_08ee;
																			IL_08ee:
																			array2[num6] = null;
																			goto IL_08f8;
																			IL_08f8:
																			num6++;
																			goto IL_0906;
																			IL_0906:
																			ptr2 += 8;
																			goto end_IL_040e;
																			IL_0727:
																			if (2 > b)
																			{
																				goto IL_0732;
																			}
																			goto IL_0753;
																			IL_0732:
																			if (1 < b)
																			{
																				break;
																			}
																			goto IL_0740;
																			IL_0740:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_0850;
																			IL_0850:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			num = 146;
																			goto IL_0872;
																			IL_0872:
																			array[num6] = 0;
																			goto IL_0880;
																			IL_0880:
																			num6++;
																			goto IL_088e;
																			IL_088e:
																			ptr2 += 8;
																			goto end_IL_040e;
																			IL_0753:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0793;
																			IL_0793:
																			array[num6 - 2] = 0;
																			goto IL_07a7;
																			IL_07a7:
																			num6--;
																			goto end_IL_040e;
																			IL_0622:
																			if (8 >= b)
																			{
																				goto IL_0630;
																			}
																			goto IL_06ed;
																			IL_0630:
																			if (8 > b)
																			{
																				goto IL_063e;
																			}
																			goto IL_06da;
																			IL_063e:
																			if (6 >= b)
																			{
																				goto IL_0649;
																			}
																			goto IL_06b9;
																			IL_0649:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_0657;
																			IL_0657:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0697;
																			IL_0697:
																			array[num6 - 2] = 0;
																			num = 204;
																			goto IL_0a29;
																			IL_0a29:
																			num6--;
																			goto end_IL_040e;
																			IL_06b9:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_06c7;
																			IL_06c7:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_07e0;
																			IL_07e0:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0820;
																			IL_0820:
																			array[num6 - 2] = 0;
																			num = 68;
																			goto IL_083d;
																			IL_083d:
																			num6--;
																			goto end_IL_040e;
																			IL_06da:
																			num6--;
																			goto end_IL_040e;
																			IL_06ed:
																			if (9 < b)
																			{
																				goto IL_06f8;
																			}
																			num = 168;
																			goto IL_07ba;
																			IL_06f8:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0706;
																			IL_0706:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0919;
																			IL_0919:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_097b;
																			IL_097b:
																			num6 -= 2;
																			goto end_IL_040e;
																			IL_0a16:
																			ptr2 += 8;
																			goto end_IL_040e;
																			IL_07ba:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_098e;
																			IL_098e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_09ce;
																			IL_09ce:
																			array[num6 - 2] = 0;
																			goto IL_09e2;
																			IL_09e2:
																			num6--;
																			goto end_IL_040e;
																		}
																		break;
																		IL_03fb:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_040e:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_0d96;
												IL_0d96:
												return (string)array2[num6 - 1];
												continue;
												end_IL_0cf1:
												break;
											}
											continue;
											end_IL_0d04:
											break;
										}
										continue;
										end_IL_0d0e:
										break;
									}
									continue;
									end_IL_0d19:
									break;
								}
								continue;
								end_IL_0d29:
								break;
							}
							continue;
							end_IL_0d39:
							break;
						}
						continue;
						end_IL_0d49:
						break;
					}
					continue;
					end_IL_0d62:
					break;
				}
				continue;
				end_IL_0d72:
				break;
			}
		}
	}

	public unsafe static void smethod_1()
	{
		//The blocks IL_000e, IL_001c, IL_002a, IL_003a, IL_04a7, IL_04ba, IL_04cd, IL_04dd, IL_04ed, IL_04fa, IL_0507, IL_0517, IL_0527, IL_053a, IL_054a, IL_055a, IL_0565, IL_0578, IL_0586, IL_0591, IL_059f, IL_05ad, IL_05bb, IL_0609, IL_0617, IL_062a, IL_0691, IL_06ae, IL_06fd, IL_0707, IL_0734, IL_0748, IL_0756, IL_0769, IL_0777, IL_0785, IL_0793, IL_07a1, IL_07e1, IL_07f5, IL_0808, IL_0813, IL_0821, IL_0834, IL_0847, IL_085a, IL_0865, IL_08a5, IL_08b9, IL_08d5, IL_08e3, IL_08ec, IL_08fa, IL_093a, IL_094e, IL_0961, IL_096f, IL_097d, IL_0996, IL_09a4, IL_09b2, IL_09c5, IL_09d3, IL_09e1, IL_0a13, IL_0a21, IL_0a34, IL_0a48, IL_0a64, IL_0a77, IL_0a9a, IL_0aa4, IL_0ab2, IL_0ac5, IL_0b05, IL_0b19, IL_0b2c, IL_0b3a, IL_0b58, IL_0b6f, IL_0b82, IL_0bab, IL_0bc4, IL_0bd2, IL_0be0, IL_0bf8, IL_0c16, IL_0c3a, IL_0c52, IL_0c65, IL_0c73, IL_0c81, IL_0c8f, IL_0ca7, IL_0cb5, IL_0cc8, IL_0d0f, IL_0d22, IL_0d30, IL_0d3b, IL_0d74, IL_0d88, IL_0da4, IL_0db2, IL_0dbd, IL_0dfe, IL_0e1b, IL_0e2e, IL_0e3c, IL_0e47, IL_0e55, IL_0e63, IL_0e77, IL_0eaf, IL_0ec2, IL_0ee4, IL_0efb, IL_0f09, IL_0f1c, IL_0f2a, IL_0f38, IL_0f50, IL_0f5e, IL_0f69, IL_0f87, IL_0f95, IL_0fa3, IL_0fb6, IL_0fc4, IL_0fd2, IL_1024, IL_1037, IL_1045, IL_1053, IL_1077, IL_1085, IL_1093, IL_10a6, IL_10b4, IL_10bf, IL_10d3, IL_1112, IL_1125, IL_1133, IL_113e, IL_1167, IL_1175, IL_1188, IL_1196, IL_11a4, IL_11b8, IL_1204, IL_1212, IL_1225, IL_1233, IL_1241, IL_125a, IL_1268, IL_1276, IL_1289, IL_1297, IL_12a2, IL_12bf, IL_12fe, IL_1311, IL_131f, IL_132d, IL_136d, IL_1381, IL_139a, IL_13a5, IL_13b0, IL_13c9, IL_13d4, IL_13df, IL_13e8, IL_13fb, IL_140e, IL_1421, IL_142c, IL_143c, IL_144c, IL_145c, IL_146c, IL_1485, IL_1495, IL_14a5, IL_14be are reachable both inside and outside the pinned region starting at IL_14d3. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 175;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef50 = default(int);
			ref int reference = ref __rxRef50;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_14be:
					num2 = 1;
					while (true)
					{
						IL_14a5:
						num3 = num2 * 4;
						num = 206;
						while (true)
						{
							IL_1495:
							num4 = num2 * 8;
							while (true)
							{
								IL_1485:
								array2 = new byte[4];
								while (true)
								{
									IL_146c:
									array3 = new object[4];
									num = 159;
									while (true)
									{
										IL_145c:
										array4 = new int[4];
										while (true)
										{
											IL_144c:
											array5 = new int[7];
											while (true)
											{
												IL_143c:
												array6 = new long[4];
												while (true)
												{
													IL_142c:
													array7 = new object[11];
													while (true)
													{
														IL_1421:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref XmlNsForClrTypeWithAssemblyResourceManagerManifestResourceAccessDenied.getDisallowPublisherPolicyAllocateBufferAged);
														while (true)
														{
															IL_140e:
															ptr2 = ptr;
															num = 272;
															while (true)
															{
																IL_13fb:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_055a:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_054a:
																		ptr2++;
																		while (true)
																		{
																			IL_053a:
																			if (b >= 1)
																			{
																				while (b <= 33)
																				{
																					num = 111;
																					while (true)
																					{
																						IL_0517:
																						if (17 >= b)
																						{
																							while (true)
																							{
																								IL_0507:
																								if (17 > b)
																								{
																									while (true)
																									{
																										IL_04fa:
																										if (8 < b)
																										{
																											while (true)
																											{
																												IL_04ed:
																												if (12 < b)
																												{
																													while (true)
																													{
																														IL_04dd:
																														if (14 >= b)
																														{
																															while (true)
																															{
																																IL_04cd:
																																if (14 > b)
																																{
																																	while (13 >= b)
																																	{
																																		num = 287;
																																		while (true)
																																		{
																																			if (num != 287)
																																			{
																																				if (num != 1268)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 175:
																																					break;
																																				default:
																																					continue;
																																				case 3:
																																					goto IL_04ba;
																																				case 134:
																																					goto IL_04cd;
																																				case 15:
																																					goto IL_04dd;
																																				case 180:
																																					goto IL_04ed;
																																				case 169:
																																					goto IL_04fa;
																																				case 188:
																																					goto IL_0507;
																																				case 111:
																																					goto IL_0517;
																																				case 224:
																																					goto IL_0527;
																																				case 254:
																																					goto IL_053a;
																																				case 83:
																																					goto IL_054a;
																																				case 48:
																																				case 49:
																																					goto IL_055a;
																																				case 32:
																																					goto IL_0565;
																																				case 136:
																																					goto IL_0578;
																																				case 42:
																																					goto IL_0586;
																																				case 109:
																																					goto IL_0591;
																																				case 128:
																																					goto IL_059f;
																																				case 129:
																																					goto IL_05ad;
																																				case 71:
																																				case 74:
																																					goto IL_05bb;
																																				case 59:
																																					goto IL_0609;
																																				case 148:
																																					goto IL_0617;
																																				case 88:
																																				case 201:
																																					goto IL_062a;
																																				case 120:
																																				case 202:
																																					goto IL_0691;
																																				case 9:
																																					goto IL_0748;
																																				case 179:
																																					goto IL_0756;
																																				case 214:
																																					goto IL_0769;
																																				case 37:
																																					goto IL_0777;
																																				case 104:
																																					goto IL_0785;
																																				case 189:
																																					goto IL_0793;
																																				case 126:
																																				case 160:
																																					goto IL_07a1;
																																				case 101:
																																					goto IL_07e1;
																																				case 177:
																																					goto IL_07f5;
																																				case 50:
																																					goto IL_0808;
																																				case 131:
																																					goto IL_0813;
																																				case 168:
																																					goto IL_0821;
																																				case 216:
																																					goto IL_0834;
																																				case 164:
																																				case 217:
																																					goto IL_0847;
																																				case 222:
																																					goto IL_085a;
																																				case 122:
																																				case 144:
																																					goto IL_0865;
																																				case 218:
																																					goto IL_08a5;
																																				case 91:
																																					goto IL_08b9;
																																				case 52:
																																					goto IL_08d5;
																																				case 209:
																																					goto IL_08ec;
																																				case 64:
																																				case 100:
																																					goto IL_08fa;
																																				case 1:
																																					goto IL_093a;
																																				case 223:
																																					goto IL_094e;
																																				case 250:
																																					goto IL_0961;
																																				case 86:
																																					goto IL_096f;
																																				case 123:
																																				case 233:
																																					goto IL_097d;
																																				case 181:
																																					goto IL_0996;
																																				case 33:
																																					goto IL_09a4;
																																				case 73:
																																					goto IL_09b2;
																																				case 263:
																																					goto IL_09c5;
																																				case 98:
																																					goto IL_09d3;
																																				case 135:
																																				case 261:
																																					goto IL_09e1;
																																				case 245:
																																					goto IL_0a13;
																																				case 185:
																																					goto IL_0a21;
																																				case 269:
																																					goto IL_0a34;
																																				case 146:
																																					goto IL_0a48;
																																				case 18:
																																				case 271:
																																					goto IL_0a64;
																																				case 273:
																																					goto IL_0a77;
																																				case 43:
																																					goto IL_0a9a;
																																				case 276:
																																					goto IL_0aa4;
																																				case 30:
																																					goto IL_0ab2;
																																				case 77:
																																				case 278:
																																					goto IL_0ac5;
																																				case 35:
																																					goto IL_0b05;
																																				case 55:
																																					goto IL_0b19;
																																				case 79:
																																				case 147:
																																					goto IL_0b3a;
																																				case 264:
																																					goto IL_0b58;
																																				case 110:
																																					goto IL_0b6f;
																																				case 171:
																																				case 199:
																																					goto IL_0b82;
																																				case 102:
																																					goto IL_0bab;
																																				case 108:
																																					goto IL_0bc4;
																																				case 219:
																																					goto IL_0bd2;
																																				case 8:
																																				case 22:
																																					goto IL_0be0;
																																				case 241:
																																					goto IL_0bf8;
																																				case 194:
																																					goto IL_0c16;
																																				case 173:
																																					goto IL_0c3a;
																																				case 47:
																																					goto IL_0c52;
																																				case 44:
																																					goto IL_0c65;
																																				case 141:
																																					goto IL_0c73;
																																				case 182:
																																				case 268:
																																					goto IL_0c81;
																																				case 31:
																																					goto IL_0c8f;
																																				case 125:
																																					goto IL_0ca7;
																																				case 107:
																																					goto IL_0cb5;
																																				case 57:
																																				case 208:
																																					goto IL_0cc8;
																																				case 170:
																																					goto IL_0d0f;
																																				case 232:
																																					goto IL_0d22;
																																				case 240:
																																					goto IL_0d30;
																																				case 151:
																																				case 165:
																																					goto IL_0d3b;
																																				case 85:
																																					goto IL_0d74;
																																				case 257:
																																					goto IL_0d88;
																																				case 191:
																																					goto IL_0da4;
																																				case 93:
																																					goto IL_0db2;
																																				case 95:
																																				case 207:
																																					goto IL_0dbd;
																																				case 2:
																																					goto IL_0dfe;
																																				case 221:
																																					goto IL_0e1b;
																																				case 76:
																																					goto IL_0e2e;
																																				case 63:
																																					goto IL_0e3c;
																																				case 84:
																																					goto IL_0e47;
																																				case 198:
																																					goto IL_0e55;
																																				case 121:
																																				case 247:
																																					goto IL_0e63;
																																				case 203:
																																					goto IL_0e77;
																																				case 114:
																																					goto IL_0eaf;
																																				case 87:
																																				case 153:
																																					goto IL_0ec2;
																																				case 228:
																																					goto IL_0ee4;
																																				case 13:
																																					goto IL_0efb;
																																				case 80:
																																					goto IL_0f09;
																																				case 237:
																																					goto IL_0f1c;
																																				case 12:
																																					goto end_IL_04a7;
																																				case 113:
																																				case 212:
																																					goto IL_0f38;
																																				case 39:
																																					goto IL_0f50;
																																				case 138:
																																					goto IL_0f5e;
																																				case 21:
																																				case 239:
																																					goto IL_0f69;
																																				case 20:
																																					goto IL_0f87;
																																				case 172:
																																					goto IL_0f95;
																																				case 118:
																																					goto IL_0fa3;
																																				case 266:
																																					goto IL_0fb6;
																																				case 275:
																																					goto IL_0fc4;
																																				case 133:
																																				case 225:
																																					goto IL_0fd2;
																																				case 167:
																																					goto IL_1024;
																																				case 236:
																																					goto IL_1037;
																																				case 45:
																																					goto IL_1045;
																																				case 46:
																																				case 92:
																																					goto IL_1053;
																																				case 0:
																																					goto IL_1077;
																																				case 176:
																																					goto IL_1085;
																																				case 116:
																																					goto IL_1093;
																																				case 204:
																																					goto IL_10a6;
																																				case 213:
																																					goto IL_10b4;
																																				case 7:
																																				case 97:
																																					goto IL_10bf;
																																				case 235:
																																					goto IL_10d3;
																																				case 193:
																																					goto IL_1112;
																																				case 29:
																																					goto IL_1125;
																																				case 69:
																																					goto IL_1133;
																																				case 186:
																																				case 244:
																																					goto IL_113e;
																																				case 252:
																																					goto IL_1167;
																																				case 277:
																																					goto IL_1175;
																																				case 262:
																																					goto IL_1188;
																																				case 274:
																																					goto IL_1196;
																																				case 51:
																																				case 145:
																																					goto IL_11a4;
																																				case 200:
																																					goto IL_11b8;
																																				case 248:
																																					goto IL_1204;
																																				case 267:
																																					goto IL_1212;
																																				case 19:
																																					goto IL_1225;
																																				case 24:
																																					goto IL_1233;
																																				case 143:
																																				case 197:
																																					goto IL_1241;
																																				case 242:
																																					goto IL_125a;
																																				case 227:
																																					goto IL_1268;
																																				case 82:
																																					goto IL_1276;
																																				case 234:
																																					goto IL_1289;
																																				case 26:
																																					goto IL_1297;
																																				case 61:
																																				case 105:
																																					goto IL_12a2;
																																				case 41:
																																					goto IL_12bf;
																																				case 25:
																																					goto IL_12fe;
																																				case 27:
																																					goto IL_1311;
																																				case 56:
																																					goto IL_131f;
																																				case 130:
																																				case 260:
																																					goto IL_132d;
																																				case 66:
																																					goto IL_136d;
																																				case 115:
																																					goto IL_1381;
																																				case 255:
																																					goto IL_139a;
																																				case 178:
																																					goto IL_13a5;
																																				case 137:
																																				case 161:
																																					goto IL_13b0;
																																				case 132:
																																					goto IL_13c9;
																																				case 72:
																																					goto IL_13d4;
																																				case 4:
																																				case 6:
																																				case 14:
																																				case 17:
																																				case 28:
																																				case 38:
																																				case 40:
																																				case 58:
																																				case 65:
																																				case 67:
																																				case 68:
																																				case 70:
																																				case 75:
																																				case 78:
																																				case 81:
																																				case 90:
																																				case 94:
																																				case 96:
																																				case 99:
																																				case 117:
																																				case 119:
																																				case 140:
																																				case 142:
																																				case 152:
																																				case 156:
																																				case 184:
																																				case 205:
																																				case 210:
																																				case 230:
																																				case 238:
																																				case 246:
																																				case 253:
																																				case 256:
																																				case 265:
																																				case 270:
																																				case 279:
																																					goto end_IL_04ba;
																																				case 11:
																																				case 23:
																																				case 34:
																																				case 36:
																																				case 53:
																																				case 54:
																																				case 60:
																																				case 89:
																																				case 103:
																																				case 106:
																																				case 112:
																																				case 124:
																																				case 139:
																																				case 149:
																																				case 150:
																																				case 154:
																																				case 157:
																																				case 158:
																																				case 162:
																																				case 163:
																																				case 166:
																																				case 183:
																																				case 187:
																																				case 190:
																																				case 192:
																																				case 195:
																																				case 196:
																																				case 211:
																																				case 220:
																																				case 226:
																																				case 231:
																																				case 243:
																																				case 258:
																																				case 259:
																																				case 272:
																																				case 280:
																																					goto IL_13fb;
																																				case 16:
																																					goto IL_140e;
																																				case 62:
																																					goto IL_1421;
																																				case 215:
																																					goto IL_142c;
																																				case 229:
																																					goto IL_143c;
																																				case 251:
																																					goto IL_144c;
																																				case 159:
																																					goto IL_145c;
																																				case 155:
																																					goto IL_146c;
																																				case 5:
																																					goto IL_1485;
																																				case 206:
																																					goto IL_1495;
																																				case 10:
																																					goto IL_14a5;
																																				case 174:
																																					goto IL_14be;
																																				case 127:
																																				case 249:
																																					return;
																																				}
																																				goto end_IL_053a;
																																			}
																																			if (13 > b)
																																			{
																																				goto end_IL_04ba;
																																			}
																																			goto IL_0b3a;
																																			IL_0b3a:
																																			array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																																			goto IL_0b58;
																																			IL_0b6f:
																																			num6--;
																																			goto IL_13fb;
																																			IL_0b58:
																																			ptr2 += 8;
																																			num = 110;
																																			goto IL_0b6f;
																																			continue;
																																			end_IL_04a7:
																																			break;
																																		}
																																		goto IL_0f2a;
																																		continue;
																																		end_IL_04ba:
																																		break;
																																		IL_04ba:;
																																	}
																																	break;
																																}
																																goto IL_0b82;
																																IL_0bab:
																																array2[num6 - 1] = 5;
																																goto IL_13fb;
																																IL_0b82:
																																array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																																goto IL_0bab;
																															}
																															break;
																														}
																														goto IL_0bc4;
																														IL_0cb5:
																														ptr2 += 8;
																														goto IL_13fb;
																														IL_0bc4:
																														if (15 >= b)
																														{
																															goto IL_0bd2;
																														}
																														goto IL_0c65;
																														IL_0bd2:
																														if (15 > b)
																														{
																															break;
																														}
																														goto IL_0be0;
																														IL_0be0:
																														array2[num6] = array2[num6 - 1];
																														goto IL_0bf8;
																														IL_0bf8:
																														array4[num6 - 0] = array4[num6 - 1];
																														goto IL_0c16;
																														IL_0c16:
																														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_0c3a;
																														IL_0c3a:
																														array3[num6] = array3[num6 - 1];
																														goto IL_0c52;
																														IL_0c52:
																														num6++;
																														goto IL_13fb;
																														IL_0c65:
																														if (16 < b)
																														{
																															break;
																														}
																														goto IL_0c73;
																														IL_0c73:
																														if (16 > b)
																														{
																															break;
																														}
																														goto IL_0c81;
																														IL_0c81:
																														array2[num6] = 5;
																														goto IL_0c8f;
																														IL_0c8f:
																														array3[num6] = array7[*(int*)(ptr2 + num3)];
																														goto IL_0ca7;
																														IL_0ca7:
																														num6++;
																														goto IL_0cb5;
																													}
																													break;
																												}
																												goto IL_0578;
																												IL_0748:
																												array2[num6] = 5;
																												goto IL_0756;
																												IL_0578:
																												if (12 > b)
																												{
																													goto IL_0586;
																												}
																												goto IL_0691;
																												IL_0586:
																												if (10 >= b)
																												{
																													goto IL_0591;
																												}
																												goto IL_0609;
																												IL_0591:
																												if (10 > b)
																												{
																													goto IL_059f;
																												}
																												goto IL_062a;
																												IL_059f:
																												if (9 < b)
																												{
																													break;
																												}
																												goto IL_05ad;
																												IL_05ad:
																												if (9 > b)
																												{
																													break;
																												}
																												goto IL_05bb;
																												IL_05bb:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																												num = 269;
																												goto IL_0a34;
																												IL_0a34:
																												array2[num6 - 2] = 0;
																												goto IL_0a48;
																												IL_0a48:
																												num6--;
																												num = 23;
																												goto IL_13fb;
																												IL_062a:
																												ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												goto IL_0834;
																												IL_0834:
																												num6 -= 2;
																												goto IL_13fb;
																												IL_0609:
																												if (11 < b)
																												{
																													break;
																												}
																												goto IL_0617;
																												IL_0617:
																												if (11 > b)
																												{
																													break;
																												}
																												goto IL_13fb;
																												IL_0691:
																												array8 = array3;
																												num7 = num6;
																												if (array == null)
																												{
																													goto IL_06a0;
																												}
																												num8 = ptr2;
																												byte b2 = *num8;
																												ptr2 = num8 + 4;
																												int num9 = *(int*)(ptr2 + num3);
																												ptr2 += 8;
																												byte* ptr3 = ptr2 + num9;
																												byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																												while (ptr2 != ptr3)
																												{
																													*ptr4 = (byte)(*ptr2 ^ b2);
																													ptr2++;
																													ptr4++;
																												}
																												array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																												goto IL_0748;
																												IL_0756:
																												num6++;
																												goto IL_13fb;
																											}
																											break;
																										}
																										goto IL_0565;
																										IL_093a:
																										array2[num6 - 2] = 0;
																										goto IL_094e;
																										IL_0565:
																										if (8 > b)
																										{
																											goto IL_0769;
																										}
																										goto IL_0a64;
																										IL_0a64:
																										num6--;
																										goto IL_13fb;
																										IL_0769:
																										if (4 >= b)
																										{
																											goto IL_0777;
																										}
																										goto IL_0808;
																										IL_0777:
																										if (4 > b)
																										{
																											goto IL_0785;
																										}
																										goto IL_0847;
																										IL_0785:
																										if (2 >= b)
																										{
																											goto IL_0793;
																										}
																										goto IL_09c5;
																										IL_0793:
																										if (2 <= b)
																										{
																											goto IL_07a1;
																										}
																										goto IL_0961;
																										IL_07a1:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_07e1;
																										IL_07e1:
																										array2[num6 - 2] = 0;
																										goto IL_07f5;
																										IL_07f5:
																										num6--;
																										goto IL_13fb;
																										IL_0961:
																										if (1 < b)
																										{
																											break;
																										}
																										goto IL_096f;
																										IL_096f:
																										if (1 > b)
																										{
																											break;
																										}
																										goto IL_097d;
																										IL_097d:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																										goto IL_0996;
																										IL_0996:
																										array2[num6] = 0;
																										goto IL_09a4;
																										IL_09a4:
																										num6++;
																										goto IL_09b2;
																										IL_09b2:
																										ptr2 += 8;
																										goto IL_13fb;
																										IL_09c5:
																										if (3 < b)
																										{
																											break;
																										}
																										goto IL_09d3;
																										IL_09d3:
																										if (3 > b)
																										{
																											break;
																										}
																										goto IL_09e1;
																										IL_09e1:
																										reference = ref array5[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										num = 245;
																										goto IL_0a13;
																										IL_0a13:
																										ptr2 += 8;
																										goto IL_0a21;
																										IL_0a21:
																										num6--;
																										goto IL_13fb;
																										IL_0847:
																										array2[num6] = 0;
																										goto IL_0a77;
																										IL_0a77:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																										goto IL_0a9a;
																										IL_0a9a:
																										array3[num6] = null;
																										goto IL_0aa4;
																										IL_0aa4:
																										num6++;
																										goto IL_0ab2;
																										IL_0ab2:
																										ptr2 += 8;
																										goto IL_13fb;
																										IL_0808:
																										if (6 < b)
																										{
																											goto IL_0813;
																										}
																										goto IL_085a;
																										IL_0813:
																										if (7 < b)
																										{
																											break;
																										}
																										goto IL_0821;
																										IL_0821:
																										if (7 > b)
																										{
																											break;
																										}
																										goto IL_0ac5;
																										IL_0ac5:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0b05;
																										IL_0b05:
																										array2[num6 - 2] = 0;
																										goto IL_0b19;
																										IL_0b19:
																										num6--;
																										goto IL_13fb;
																										IL_085a:
																										if (6 <= b)
																										{
																											goto IL_0865;
																										}
																										goto IL_08d5;
																										IL_0865:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_08a5;
																										IL_08a5:
																										array2[num6 - 2] = 0;
																										goto IL_08b9;
																										IL_08b9:
																										num6--;
																										num = 162;
																										goto IL_13fb;
																										IL_08d5:
																										if (5 < b)
																										{
																											break;
																										}
																										num = 209;
																										goto IL_08ec;
																										IL_094e:
																										num6--;
																										goto IL_13fb;
																										IL_08ec:
																										if (5 > b)
																										{
																											break;
																										}
																										goto IL_08fa;
																										IL_08fa:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_093a;
																									}
																									break;
																								}
																								goto IL_0cc8;
																								IL_0d0f:
																								num6 -= 3;
																								goto IL_13fb;
																								IL_0cc8:
																								((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																								num = 170;
																								goto IL_0d0f;
																							}
																							break;
																						}
																						goto IL_0d22;
																						IL_13d4:
																						if (33 <= b)
																						{
																							num = 140;
																						}
																						break;
																						IL_0d22:
																						if (25 >= b)
																						{
																							goto IL_0d30;
																						}
																						goto IL_10a6;
																						IL_0d30:
																						if (25 <= b)
																						{
																							goto IL_0d3b;
																						}
																						goto IL_0da4;
																						IL_0d3b:
																						array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_0d74;
																						IL_0d74:
																						array2[num6 - 2] = 5;
																						goto IL_0d88;
																						IL_0d88:
																						num6--;
																						num = 34;
																						goto IL_13fb;
																						IL_0da4:
																						if (21 >= b)
																						{
																							goto IL_0db2;
																						}
																						goto IL_0f50;
																						IL_0db2:
																						if (21 <= b)
																						{
																							goto IL_0dbd;
																						}
																						goto IL_0e2e;
																						IL_0dbd:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						goto IL_0dfe;
																						IL_0dfe:
																						array2[num6 - 2] = 0;
																						num = 221;
																						goto IL_0e1b;
																						IL_0e1b:
																						num6--;
																						goto IL_13fb;
																						IL_0e2e:
																						if (19 >= b)
																						{
																							goto IL_0e3c;
																						}
																						goto IL_0f1c;
																						IL_0e3c:
																						if (19 > b)
																						{
																							goto IL_0e47;
																						}
																						goto IL_0ec2;
																						IL_0e47:
																						if (18 < b)
																						{
																							break;
																						}
																						goto IL_0e55;
																						IL_0e55:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_0e63;
																						IL_0e63:
																						array2[num6 - 1] = 5;
																						goto IL_0e77;
																						IL_0e77:
																						array3[num6 - 1] = ((delegate*<string[], string>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_0eaf;
																						IL_0eaf:
																						ptr2 += 8;
																						goto IL_13fb;
																						IL_0ec2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						num = 228;
																						goto IL_0ee4;
																						IL_0ee4:
																						array2[num6] = 1;
																						num = 13;
																						goto IL_0efb;
																						IL_0efb:
																						num6++;
																						goto IL_0f09;
																						IL_0f09:
																						ptr2 += 16;
																						goto IL_13fb;
																						IL_0f1c:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_0f2a;
																						IL_0f2a:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_0f38;
																						IL_0f38:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_13fb;
																						IL_0f50:
																						if (23 >= b)
																						{
																							goto IL_0f5e;
																						}
																						goto IL_1037;
																						IL_0f5e:
																						if (23 <= b)
																						{
																							goto IL_0f69;
																						}
																						goto IL_0fb6;
																						IL_0f69:
																						array3[num6] = ((delegate*<string[]>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])();
																						goto IL_0f87;
																						IL_0f87:
																						array2[num6] = 5;
																						goto IL_0f95;
																						IL_0f95:
																						num6++;
																						goto IL_0fa3;
																						IL_0fa3:
																						ptr2 += 8;
																						goto IL_13fb;
																						IL_0fb6:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_0fc4;
																						IL_0fc4:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_0fd2;
																						IL_0fd2:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_1024;
																						IL_1024:
																						num6--;
																						goto IL_13fb;
																						IL_1037:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_1045;
																						IL_1045:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_1053;
																						IL_1053:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])();
																						goto IL_1077;
																						IL_1077:
																						array2[num6] = 0;
																						goto IL_1085;
																						IL_1085:
																						num6++;
																						goto IL_1093;
																						IL_1093:
																						ptr2 += 8;
																						goto IL_13fb;
																						IL_10a6:
																						if (29 >= b)
																						{
																							goto IL_10b4;
																						}
																						goto IL_1289;
																						IL_10b4:
																						if (29 <= b)
																						{
																							goto IL_10bf;
																						}
																						goto IL_1125;
																						IL_10bf:
																						array2[num6 - 1] = 3;
																						goto IL_10d3;
																						IL_10d3:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_1112;
																						IL_1112:
																						ptr2 += 8;
																						goto IL_13fb;
																						IL_1125:
																						if (27 >= b)
																						{
																							goto IL_1133;
																						}
																						goto IL_1225;
																						IL_1133:
																						if (27 <= b)
																						{
																							goto IL_113e;
																						}
																						goto IL_1188;
																						IL_113e:
																						((delegate*<string, void>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																						goto IL_1167;
																						IL_1167:
																						num6--;
																						goto IL_1175;
																						IL_1175:
																						ptr2 += 8;
																						goto IL_13fb;
																						IL_1188:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_1196;
																						IL_1196:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_11a4;
																						IL_11a4:
																						array2[num6 - 2] = 5;
																						goto IL_11b8;
																						IL_11b8:
																						array3[num6 - 2] = ((delegate*<string, string, string>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																						goto IL_1204;
																						IL_1204:
																						num6--;
																						goto IL_1212;
																						IL_1212:
																						ptr2 += 8;
																						goto IL_13fb;
																						IL_1225:
																						if (28 < b)
																						{
																							break;
																						}
																						goto IL_1233;
																						IL_1233:
																						if (28 > b)
																						{
																							break;
																						}
																						goto IL_1241;
																						IL_1241:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																						goto IL_125a;
																						IL_125a:
																						array2[num6] = 3;
																						goto IL_1268;
																						IL_1268:
																						num6++;
																						goto IL_1276;
																						IL_1276:
																						ptr2 += 16;
																						goto IL_13fb;
																						IL_1289:
																						if (31 >= b)
																						{
																							goto IL_1297;
																						}
																						goto IL_139a;
																						IL_1297:
																						if (31 <= b)
																						{
																							goto IL_12a2;
																						}
																						goto IL_1311;
																						IL_12a2:
																						array2[num6 - 1] = 0;
																						num = 41;
																						goto IL_12bf;
																						IL_12bf:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																						goto IL_12fe;
																						IL_12fe:
																						ptr2 += 8;
																						goto IL_13fb;
																						IL_1311:
																						if (30 < b)
																						{
																							break;
																						}
																						goto IL_131f;
																						IL_131f:
																						if (30 > b)
																						{
																							break;
																						}
																						goto IL_132d;
																						IL_132d:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_136d;
																						IL_136d:
																						array2[num6 - 2] = 3;
																						goto IL_1381;
																						IL_1381:
																						num6--;
																						num = 187;
																						goto IL_13fb;
																						IL_139a:
																						if (32 >= b)
																						{
																							goto IL_13a5;
																						}
																						goto IL_13c9;
																						IL_13a5:
																						if (32 > b)
																						{
																							break;
																						}
																						goto IL_13b0;
																						IL_13b0:
																						num10 = ptr2;
																						num11 = -200;
																						num5 = 1;
																						ptr2 = num10 + num11;
																						goto IL_13fb;
																						IL_13c9:
																						if (33 < b)
																						{
																							break;
																						}
																						goto IL_13d4;
																					}
																					break;
																					IL_0527:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_13fb;
																			continue;
																			end_IL_053a:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_06a0:
			while (true)
			{
				IL_06a0_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						IL_0748_2:
						array2[num6] = 5;
						while (true)
						{
							IL_0756_2:
							num6++;
							while (true)
							{
								IL_13fb_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_053a_2:
											if (b >= 1)
											{
												while (b <= 33)
												{
													num = 111;
													while (true)
													{
														IL_0517_2:
														if (17 >= b)
														{
															while (true)
															{
																IL_0507_2:
																if (17 > b)
																{
																	while (true)
																	{
																		IL_04fa_2:
																		if (8 < b)
																		{
																			while (true)
																			{
																				IL_04ed_2:
																				if (12 < b)
																				{
																					while (true)
																					{
																						IL_04dd_2:
																						if (14 >= b)
																						{
																							while (true)
																							{
																								IL_04cd_2:
																								if (14 > b)
																								{
																									while (13 >= b)
																									{
																										num = 287;
																										while (true)
																										{
																											if (num != 287)
																											{
																												if (num != 1268)
																												{
																													break;
																												}
																												switch (num)
																												{
																												case 3:
																													goto IL_04ba_2;
																												case 134:
																													goto IL_04cd_2;
																												case 15:
																													goto IL_04dd_2;
																												case 180:
																													goto IL_04ed_2;
																												case 169:
																													goto IL_04fa_2;
																												case 188:
																													goto IL_0507_2;
																												case 111:
																													goto IL_0517_2;
																												case 224:
																													goto IL_0527_2;
																												case 254:
																													goto IL_053a_2;
																												case 83:
																													goto end_IL_053a_2;
																												case 48:
																												case 49:
																													goto end_IL_054a;
																												case 32:
																													goto IL_0565_2;
																												case 136:
																													goto IL_0578_2;
																												case 42:
																													goto IL_0586_2;
																												case 109:
																													goto IL_0591_2;
																												case 128:
																													goto IL_059f_2;
																												case 129:
																													goto IL_05ad_2;
																												case 71:
																												case 74:
																													goto IL_05bb_2;
																												case 59:
																													goto IL_0609_2;
																												case 148:
																													goto IL_0617_2;
																												case 88:
																												case 201:
																													goto IL_062a_2;
																												case 120:
																												case 202:
																													goto end_IL_055a;
																												case 9:
																													goto IL_0748_2;
																												case 179:
																													goto IL_0756_2;
																												case 214:
																													goto IL_0769_2;
																												case 37:
																													goto IL_0777_2;
																												case 104:
																													goto IL_0785_2;
																												case 189:
																													goto IL_0793_2;
																												case 126:
																												case 160:
																													goto IL_07a1_2;
																												case 101:
																													goto IL_07e1_2;
																												case 177:
																													goto IL_07f5_2;
																												case 50:
																													goto IL_0808_2;
																												case 131:
																													goto IL_0813_2;
																												case 168:
																													goto IL_0821_2;
																												case 216:
																													goto IL_0834_2;
																												case 164:
																												case 217:
																													goto IL_0847_2;
																												case 222:
																													goto IL_085a_2;
																												case 122:
																												case 144:
																													goto IL_0865_2;
																												case 218:
																													goto IL_08a5_2;
																												case 91:
																													goto IL_08b9_2;
																												case 52:
																													goto IL_08d5_2;
																												case 209:
																													goto IL_08ec_2;
																												case 64:
																												case 100:
																													goto IL_08fa_2;
																												case 1:
																													goto IL_093a_2;
																												case 223:
																													goto IL_094e_2;
																												case 250:
																													goto IL_0961_2;
																												case 86:
																													goto IL_096f_2;
																												case 123:
																												case 233:
																													goto IL_097d_2;
																												case 181:
																													goto IL_0996_2;
																												case 33:
																													goto IL_09a4_2;
																												case 73:
																													goto IL_09b2_2;
																												case 263:
																													goto IL_09c5_2;
																												case 98:
																													goto IL_09d3_2;
																												case 135:
																												case 261:
																													goto IL_09e1_2;
																												case 245:
																													goto IL_0a13_2;
																												case 185:
																													goto IL_0a21_2;
																												case 269:
																													goto IL_0a34_2;
																												case 146:
																													goto IL_0a48_2;
																												case 18:
																												case 271:
																													goto IL_0a64_2;
																												case 273:
																													goto IL_0a77_2;
																												case 43:
																													goto IL_0a9a_2;
																												case 276:
																													goto IL_0aa4_2;
																												case 30:
																													goto IL_0ab2_2;
																												case 77:
																												case 278:
																													goto IL_0ac5_2;
																												case 35:
																													goto IL_0b05_2;
																												case 55:
																													goto IL_0b19_2;
																												case 79:
																												case 147:
																													goto IL_0b3a_2;
																												case 264:
																													goto IL_0b58_2;
																												case 110:
																													goto IL_0b6f_2;
																												case 171:
																												case 199:
																													goto IL_0b82_2;
																												case 102:
																													goto IL_0bab_2;
																												case 108:
																													goto IL_0bc4_2;
																												case 219:
																													goto IL_0bd2_2;
																												case 8:
																												case 22:
																													goto IL_0be0_2;
																												case 241:
																													goto IL_0bf8_2;
																												case 194:
																													goto IL_0c16_2;
																												case 173:
																													goto IL_0c3a_2;
																												case 47:
																													goto IL_0c52_2;
																												case 44:
																													goto IL_0c65_2;
																												case 141:
																													goto IL_0c73_2;
																												case 182:
																												case 268:
																													goto IL_0c81_2;
																												case 31:
																													goto IL_0c8f_2;
																												case 125:
																													goto IL_0ca7_2;
																												case 107:
																													goto IL_0cb5_2;
																												case 57:
																												case 208:
																													goto IL_0cc8_2;
																												case 170:
																													goto IL_0d0f_2;
																												case 232:
																													goto IL_0d22_2;
																												case 240:
																													goto IL_0d30_2;
																												case 151:
																												case 165:
																													goto IL_0d3b_2;
																												case 85:
																													goto IL_0d74_2;
																												case 257:
																													goto IL_0d88_2;
																												case 191:
																													goto IL_0da4_2;
																												case 93:
																													goto IL_0db2_2;
																												case 95:
																												case 207:
																													goto IL_0dbd_2;
																												case 2:
																													goto IL_0dfe_2;
																												case 221:
																													goto IL_0e1b_2;
																												case 76:
																													goto IL_0e2e_2;
																												case 63:
																													goto IL_0e3c_2;
																												case 84:
																													goto IL_0e47_2;
																												case 198:
																													goto IL_0e55_2;
																												case 121:
																												case 247:
																													goto IL_0e63_2;
																												case 203:
																													goto IL_0e77_2;
																												case 114:
																													goto IL_0eaf_2;
																												case 87:
																												case 153:
																													goto IL_0ec2_2;
																												case 228:
																													goto IL_0ee4_2;
																												case 13:
																													goto IL_0efb_2;
																												case 80:
																													goto IL_0f09_2;
																												case 237:
																													goto IL_0f1c_2;
																												case 12:
																													goto end_IL_04a7_2;
																												case 113:
																												case 212:
																													goto IL_0f38_2;
																												case 39:
																													goto IL_0f50_2;
																												case 138:
																													goto IL_0f5e_2;
																												case 21:
																												case 239:
																													goto IL_0f69_2;
																												case 20:
																													goto IL_0f87_2;
																												case 172:
																													goto IL_0f95_2;
																												case 118:
																													goto IL_0fa3_2;
																												case 266:
																													goto IL_0fb6_2;
																												case 275:
																													goto IL_0fc4_2;
																												case 133:
																												case 225:
																													goto IL_0fd2_2;
																												case 167:
																													goto IL_1024_2;
																												case 236:
																													goto IL_1037_2;
																												case 45:
																													goto IL_1045_2;
																												case 46:
																												case 92:
																													goto IL_1053_2;
																												case 0:
																													goto IL_1077_2;
																												case 176:
																													goto IL_1085_2;
																												case 116:
																													goto IL_1093_2;
																												case 204:
																													goto IL_10a6_2;
																												case 213:
																													goto IL_10b4_2;
																												case 7:
																												case 97:
																													goto IL_10bf_2;
																												case 235:
																													goto IL_10d3_2;
																												case 193:
																													goto IL_1112_2;
																												case 29:
																													goto IL_1125_2;
																												case 69:
																													goto IL_1133_2;
																												case 186:
																												case 244:
																													goto IL_113e_2;
																												case 252:
																													goto IL_1167_2;
																												case 277:
																													goto IL_1175_2;
																												case 262:
																													goto IL_1188_2;
																												case 274:
																													goto IL_1196_2;
																												case 51:
																												case 145:
																													goto IL_11a4_2;
																												case 200:
																													goto IL_11b8_2;
																												case 248:
																													goto IL_1204_2;
																												case 267:
																													goto IL_1212_2;
																												case 19:
																													goto IL_1225_2;
																												case 24:
																													goto IL_1233_2;
																												case 143:
																												case 197:
																													goto IL_1241_2;
																												case 242:
																													goto IL_125a_2;
																												case 227:
																													goto IL_1268_2;
																												case 82:
																													goto IL_1276_2;
																												case 234:
																													goto IL_1289_2;
																												case 26:
																													goto IL_1297_2;
																												case 61:
																												case 105:
																													goto IL_12a2_2;
																												case 41:
																													goto IL_12bf_2;
																												case 25:
																													goto IL_12fe_2;
																												case 27:
																													goto IL_1311_2;
																												case 56:
																													goto IL_131f_2;
																												case 130:
																												case 260:
																													goto IL_132d_2;
																												case 66:
																													goto IL_136d_2;
																												case 115:
																													goto IL_1381_2;
																												case 255:
																													goto IL_139a_2;
																												case 178:
																													goto IL_13a5_2;
																												case 137:
																												case 161:
																													goto IL_13b0_2;
																												case 132:
																													goto IL_13c9_2;
																												case 72:
																													goto IL_13d4_2;
																												case 4:
																												case 6:
																												case 14:
																												case 17:
																												case 28:
																												case 38:
																												case 40:
																												case 58:
																												case 65:
																												case 67:
																												case 68:
																												case 70:
																												case 75:
																												case 78:
																												case 81:
																												case 90:
																												case 94:
																												case 96:
																												case 99:
																												case 117:
																												case 119:
																												case 140:
																												case 142:
																												case 152:
																												case 156:
																												case 184:
																												case 205:
																												case 210:
																												case 230:
																												case 238:
																												case 246:
																												case 253:
																												case 256:
																												case 265:
																												case 270:
																												case 279:
																													goto end_IL_04ba_2;
																												case 11:
																												case 23:
																												case 34:
																												case 36:
																												case 53:
																												case 54:
																												case 60:
																												case 89:
																												case 103:
																												case 106:
																												case 112:
																												case 124:
																												case 139:
																												case 149:
																												case 150:
																												case 154:
																												case 157:
																												case 158:
																												case 162:
																												case 163:
																												case 166:
																												case 183:
																												case 187:
																												case 190:
																												case 192:
																												case 195:
																												case 196:
																												case 211:
																												case 220:
																												case 226:
																												case 231:
																												case 243:
																												case 258:
																												case 259:
																												case 272:
																												case 280:
																													goto IL_13fb_2;
																												case 16:
																													ptr2 = ptr;
																													num = 272;
																													goto IL_13fb_2;
																												case 62:
																													ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref XmlNsForClrTypeWithAssemblyResourceManagerManifestResourceAccessDenied.getDisallowPublisherPolicyAllocateBufferAged);
																													goto case 16;
																												case 215:
																													array7 = new object[11];
																													goto case 62;
																												case 229:
																													array6 = new long[4];
																													goto case 215;
																												case 251:
																													array5 = new int[7];
																													goto case 229;
																												case 159:
																													array4 = new int[4];
																													goto case 251;
																												case 155:
																													array3 = new object[4];
																													num = 159;
																													goto case 159;
																												case 5:
																													array2 = new byte[4];
																													goto case 155;
																												case 206:
																													num4 = num2 * 8;
																													goto case 5;
																												case 10:
																													num3 = num2 * 4;
																													num = 206;
																													goto case 206;
																												case 174:
																													num2 = 1;
																													goto case 10;
																												case 175:
																													goto end_IL_06ae;
																												case 127:
																												case 249:
																													return;
																												}
																												continue;
																											}
																											if (13 > b)
																											{
																												goto end_IL_04ba_2;
																											}
																											goto IL_0b3a_2;
																											IL_0b3a_2:
																											array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																											goto IL_0b58_2;
																											IL_0b6f_2:
																											num6--;
																											goto IL_13fb_2;
																											IL_0b58_2:
																											ptr2 += 8;
																											num = 110;
																											goto IL_0b6f_2;
																											continue;
																											end_IL_04a7_2:
																											break;
																										}
																										goto IL_0f2a_2;
																										continue;
																										end_IL_04ba_2:
																										break;
																										IL_04ba_2:;
																									}
																									break;
																								}
																								goto IL_0b82_2;
																								IL_0bab_2:
																								array2[num6 - 1] = 5;
																								goto IL_13fb_2;
																								IL_0b82_2:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																								goto IL_0bab_2;
																							}
																							break;
																						}
																						goto IL_0bc4_2;
																						IL_0cb5_2:
																						ptr2 += 8;
																						goto IL_13fb_2;
																						IL_0bc4_2:
																						if (15 >= b)
																						{
																							goto IL_0bd2_2;
																						}
																						goto IL_0c65_2;
																						IL_0bd2_2:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_0be0_2;
																						IL_0be0_2:
																						array2[num6] = array2[num6 - 1];
																						goto IL_0bf8_2;
																						IL_0bf8_2:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_0c16_2;
																						IL_0c16_2:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0c3a_2;
																						IL_0c3a_2:
																						array3[num6] = array3[num6 - 1];
																						goto IL_0c52_2;
																						IL_0c52_2:
																						num6++;
																						goto IL_13fb_2;
																						IL_0c65_2:
																						if (16 < b)
																						{
																							break;
																						}
																						goto IL_0c73_2;
																						IL_0c73_2:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_0c81_2;
																						IL_0c81_2:
																						array2[num6] = 5;
																						goto IL_0c8f_2;
																						IL_0c8f_2:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_0ca7_2;
																						IL_0ca7_2:
																						num6++;
																						goto IL_0cb5_2;
																					}
																					break;
																				}
																				goto IL_0578_2;
																				IL_0617_2:
																				if (11 > b)
																				{
																					break;
																				}
																				goto IL_13fb_2;
																				IL_0578_2:
																				if (12 <= b)
																				{
																					goto end_IL_055a;
																				}
																				goto IL_0586_2;
																				IL_0586_2:
																				if (10 >= b)
																				{
																					goto IL_0591_2;
																				}
																				goto IL_0609_2;
																				IL_0591_2:
																				if (10 > b)
																				{
																					goto IL_059f_2;
																				}
																				goto IL_062a_2;
																				IL_059f_2:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_05ad_2;
																				IL_05ad_2:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_05bb_2;
																				IL_05bb_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																				num = 269;
																				goto IL_0a34_2;
																				IL_0a34_2:
																				array2[num6 - 2] = 0;
																				goto IL_0a48_2;
																				IL_0a48_2:
																				num6--;
																				num = 23;
																				goto IL_13fb_2;
																				IL_062a_2:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0834_2;
																				IL_0834_2:
																				num6 -= 2;
																				goto IL_13fb_2;
																				IL_0609_2:
																				if (11 < b)
																				{
																					break;
																				}
																				goto IL_0617_2;
																			}
																			break;
																		}
																		goto IL_0565_2;
																		IL_093a_2:
																		array2[num6 - 2] = 0;
																		goto IL_094e_2;
																		IL_0565_2:
																		if (8 > b)
																		{
																			goto IL_0769_2;
																		}
																		goto IL_0a64_2;
																		IL_0a64_2:
																		num6--;
																		goto IL_13fb_2;
																		IL_0769_2:
																		if (4 >= b)
																		{
																			goto IL_0777_2;
																		}
																		goto IL_0808_2;
																		IL_0777_2:
																		if (4 > b)
																		{
																			goto IL_0785_2;
																		}
																		goto IL_0847_2;
																		IL_0785_2:
																		if (2 >= b)
																		{
																			goto IL_0793_2;
																		}
																		goto IL_09c5_2;
																		IL_0793_2:
																		if (2 <= b)
																		{
																			goto IL_07a1_2;
																		}
																		goto IL_0961_2;
																		IL_07a1_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_07e1_2;
																		IL_07e1_2:
																		array2[num6 - 2] = 0;
																		goto IL_07f5_2;
																		IL_07f5_2:
																		num6--;
																		goto IL_13fb_2;
																		IL_0961_2:
																		if (1 < b)
																		{
																			break;
																		}
																		goto IL_096f_2;
																		IL_096f_2:
																		if (1 > b)
																		{
																			break;
																		}
																		goto IL_097d_2;
																		IL_097d_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																		goto IL_0996_2;
																		IL_0996_2:
																		array2[num6] = 0;
																		goto IL_09a4_2;
																		IL_09a4_2:
																		num6++;
																		goto IL_09b2_2;
																		IL_09b2_2:
																		ptr2 += 8;
																		goto IL_13fb_2;
																		IL_09c5_2:
																		if (3 < b)
																		{
																			break;
																		}
																		goto IL_09d3_2;
																		IL_09d3_2:
																		if (3 > b)
																		{
																			break;
																		}
																		goto IL_09e1_2;
																		IL_09e1_2:
																		reference = ref array5[*(int*)(ptr2 + num3)];
																		reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		num = 245;
																		goto IL_0a13_2;
																		IL_0a13_2:
																		ptr2 += 8;
																		goto IL_0a21_2;
																		IL_0a21_2:
																		num6--;
																		goto IL_13fb_2;
																		IL_0847_2:
																		array2[num6] = 0;
																		goto IL_0a77_2;
																		IL_0a77_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																		goto IL_0a9a_2;
																		IL_0a9a_2:
																		array3[num6] = null;
																		goto IL_0aa4_2;
																		IL_0aa4_2:
																		num6++;
																		goto IL_0ab2_2;
																		IL_0ab2_2:
																		ptr2 += 8;
																		goto IL_13fb_2;
																		IL_0808_2:
																		if (6 < b)
																		{
																			goto IL_0813_2;
																		}
																		goto IL_085a_2;
																		IL_0813_2:
																		if (7 < b)
																		{
																			break;
																		}
																		goto IL_0821_2;
																		IL_0821_2:
																		if (7 > b)
																		{
																			break;
																		}
																		goto IL_0ac5_2;
																		IL_0ac5_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0b05_2;
																		IL_0b05_2:
																		array2[num6 - 2] = 0;
																		goto IL_0b19_2;
																		IL_0b19_2:
																		num6--;
																		goto IL_13fb_2;
																		IL_085a_2:
																		if (6 <= b)
																		{
																			goto IL_0865_2;
																		}
																		goto IL_08d5_2;
																		IL_0865_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_08a5_2;
																		IL_08a5_2:
																		array2[num6 - 2] = 0;
																		goto IL_08b9_2;
																		IL_08b9_2:
																		num6--;
																		num = 162;
																		goto IL_13fb_2;
																		IL_08d5_2:
																		if (5 < b)
																		{
																			break;
																		}
																		num = 209;
																		goto IL_08ec_2;
																		IL_094e_2:
																		num6--;
																		goto IL_13fb_2;
																		IL_08ec_2:
																		if (5 > b)
																		{
																			break;
																		}
																		goto IL_08fa_2;
																		IL_08fa_2:
																		*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_093a_2;
																	}
																	break;
																}
																goto IL_0cc8_2;
																IL_0d0f_2:
																num6 -= 3;
																goto IL_13fb_2;
																IL_0cc8_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																num = 170;
																goto IL_0d0f_2;
															}
															break;
														}
														goto IL_0d22_2;
														IL_13d4_2:
														if (33 <= b)
														{
															num = 140;
														}
														break;
														IL_0d22_2:
														if (25 >= b)
														{
															goto IL_0d30_2;
														}
														goto IL_10a6_2;
														IL_0d30_2:
														if (25 <= b)
														{
															goto IL_0d3b_2;
														}
														goto IL_0da4_2;
														IL_0d3b_2:
														array3[num6 - 2] = ((string[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_0d74_2;
														IL_0d74_2:
														array2[num6 - 2] = 5;
														goto IL_0d88_2;
														IL_0d88_2:
														num6--;
														num = 34;
														goto IL_13fb_2;
														IL_0da4_2:
														if (21 >= b)
														{
															goto IL_0db2_2;
														}
														goto IL_0f50_2;
														IL_0db2_2:
														if (21 <= b)
														{
															goto IL_0dbd_2;
														}
														goto IL_0e2e_2;
														IL_0dbd_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														goto IL_0dfe_2;
														IL_0dfe_2:
														array2[num6 - 2] = 0;
														num = 221;
														goto IL_0e1b_2;
														IL_0e1b_2:
														num6--;
														goto IL_13fb_2;
														IL_0e2e_2:
														if (19 >= b)
														{
															goto IL_0e3c_2;
														}
														goto IL_0f1c_2;
														IL_0e3c_2:
														if (19 > b)
														{
															goto IL_0e47_2;
														}
														goto IL_0ec2_2;
														IL_0e47_2:
														if (18 < b)
														{
															break;
														}
														goto IL_0e55_2;
														IL_0e55_2:
														if (18 > b)
														{
															break;
														}
														goto IL_0e63_2;
														IL_0e63_2:
														array2[num6 - 1] = 5;
														goto IL_0e77_2;
														IL_0e77_2:
														array3[num6 - 1] = ((delegate*<string[], string>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_0eaf_2;
														IL_0eaf_2:
														ptr2 += 8;
														goto IL_13fb_2;
														IL_0ec2_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														num = 228;
														goto IL_0ee4_2;
														IL_0ee4_2:
														array2[num6] = 1;
														num = 13;
														goto IL_0efb_2;
														IL_0efb_2:
														num6++;
														goto IL_0f09_2;
														IL_0f09_2:
														ptr2 += 16;
														goto IL_13fb_2;
														IL_0f1c_2:
														if (20 < b)
														{
															break;
														}
														goto IL_0f2a_2;
														IL_0f2a_2:
														if (20 > b)
														{
															break;
														}
														goto IL_0f38_2;
														IL_0f38_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_13fb_2;
														IL_0f50_2:
														if (23 >= b)
														{
															goto IL_0f5e_2;
														}
														goto IL_1037_2;
														IL_0f5e_2:
														if (23 <= b)
														{
															goto IL_0f69_2;
														}
														goto IL_0fb6_2;
														IL_0f69_2:
														array3[num6] = ((delegate*<string[]>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])();
														goto IL_0f87_2;
														IL_0f87_2:
														array2[num6] = 5;
														goto IL_0f95_2;
														IL_0f95_2:
														num6++;
														goto IL_0fa3_2;
														IL_0fa3_2:
														ptr2 += 8;
														goto IL_13fb_2;
														IL_0fb6_2:
														if (22 < b)
														{
															break;
														}
														goto IL_0fc4_2;
														IL_0fc4_2:
														if (22 > b)
														{
															break;
														}
														goto IL_0fd2_2;
														IL_0fd2_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_1024_2;
														IL_1024_2:
														num6--;
														goto IL_13fb_2;
														IL_1037_2:
														if (24 < b)
														{
															break;
														}
														goto IL_1045_2;
														IL_1045_2:
														if (24 > b)
														{
															break;
														}
														goto IL_1053_2;
														IL_1053_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])();
														goto IL_1077_2;
														IL_1077_2:
														array2[num6] = 0;
														goto IL_1085_2;
														IL_1085_2:
														num6++;
														goto IL_1093_2;
														IL_1093_2:
														ptr2 += 8;
														goto IL_13fb_2;
														IL_10a6_2:
														if (29 >= b)
														{
															goto IL_10b4_2;
														}
														goto IL_1289_2;
														IL_10b4_2:
														if (29 <= b)
														{
															goto IL_10bf_2;
														}
														goto IL_1125_2;
														IL_10bf_2:
														array2[num6 - 1] = 3;
														goto IL_10d3_2;
														IL_10d3_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_1112_2;
														IL_1112_2:
														ptr2 += 8;
														goto IL_13fb_2;
														IL_1125_2:
														if (27 >= b)
														{
															goto IL_1133_2;
														}
														goto IL_1225_2;
														IL_1133_2:
														if (27 <= b)
														{
															goto IL_113e_2;
														}
														goto IL_1188_2;
														IL_113e_2:
														((delegate*<string, void>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
														goto IL_1167_2;
														IL_1167_2:
														num6--;
														goto IL_1175_2;
														IL_1175_2:
														ptr2 += 8;
														goto IL_13fb_2;
														IL_1188_2:
														if (26 < b)
														{
															break;
														}
														goto IL_1196_2;
														IL_1196_2:
														if (26 > b)
														{
															break;
														}
														goto IL_11a4_2;
														IL_11a4_2:
														array2[num6 - 2] = 5;
														goto IL_11b8_2;
														IL_11b8_2:
														array3[num6 - 2] = ((delegate*<string, string, string>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
														goto IL_1204_2;
														IL_1204_2:
														num6--;
														goto IL_1212_2;
														IL_1212_2:
														ptr2 += 8;
														goto IL_13fb_2;
														IL_1225_2:
														if (28 < b)
														{
															break;
														}
														goto IL_1233_2;
														IL_1233_2:
														if (28 > b)
														{
															break;
														}
														goto IL_1241_2;
														IL_1241_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
														goto IL_125a_2;
														IL_125a_2:
														array2[num6] = 3;
														goto IL_1268_2;
														IL_1268_2:
														num6++;
														goto IL_1276_2;
														IL_1276_2:
														ptr2 += 16;
														goto IL_13fb_2;
														IL_1289_2:
														if (31 >= b)
														{
															goto IL_1297_2;
														}
														goto IL_139a_2;
														IL_1297_2:
														if (31 <= b)
														{
															goto IL_12a2_2;
														}
														goto IL_1311_2;
														IL_12a2_2:
														array2[num6 - 1] = 0;
														num = 41;
														goto IL_12bf_2;
														IL_12bf_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)HiddenSwitchWrappers[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
														goto IL_12fe_2;
														IL_12fe_2:
														ptr2 += 8;
														goto IL_13fb_2;
														IL_1311_2:
														if (30 < b)
														{
															break;
														}
														goto IL_131f_2;
														IL_131f_2:
														if (30 > b)
														{
															break;
														}
														goto IL_132d_2;
														IL_132d_2:
														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_136d_2;
														IL_136d_2:
														array2[num6 - 2] = 3;
														goto IL_1381_2;
														IL_1381_2:
														num6--;
														num = 187;
														goto IL_13fb_2;
														IL_139a_2:
														if (32 >= b)
														{
															goto IL_13a5_2;
														}
														goto IL_13c9_2;
														IL_13a5_2:
														if (32 > b)
														{
															break;
														}
														goto IL_13b0_2;
														IL_13b0_2:
														num10 = ptr2;
														num11 = -200;
														num5 = 1;
														ptr2 = num10 + num11;
														goto IL_13fb_2;
														IL_13c9_2:
														if (33 < b)
														{
															break;
														}
														goto IL_13d4_2;
													}
													break;
													IL_0527_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_13fb_2;
											continue;
											end_IL_053a_2:
											break;
										}
										continue;
										end_IL_054a:
										break;
									}
									continue;
									end_IL_055a:
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_06a0_2;
					}
					continue;
					end_IL_06ae:
					break;
				}
				break;
			}
		}
	}

	public Class134()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class134()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_0305, IL_0318, IL_032b, IL_033b, IL_034b, IL_035b, IL_0368, IL_0378, IL_0388, IL_0398, IL_03a3, IL_03b1, IL_03d3, IL_03e1, IL_03ef, IL_0402, IL_0410, IL_0429, IL_043c, IL_044a, IL_0455, IL_0460, IL_0473, IL_0488, IL_049b, IL_04a9, IL_04b7, IL_04ca, IL_04d5, IL_04e3, IL_04ee, IL_050c, IL_051f, IL_0528, IL_053d, IL_0550, IL_0563, IL_0571, IL_058e, IL_05dd, IL_05e7, IL_0614, IL_0628, IL_0636, IL_0649, IL_0657, IL_066c, IL_067f, IL_0692, IL_06a0, IL_06ae, IL_06c3, IL_06d6, IL_06f4, IL_0702, IL_0715, IL_0723, IL_073f, IL_074a, IL_0758, IL_0766, IL_077a, IL_07b2, IL_07c5, IL_07df, IL_07f2, IL_0800, IL_080e, IL_081c, IL_082a, IL_0838, IL_0878, IL_088c, IL_089f, IL_08c8, IL_08e1, IL_08ea, IL_08f5, IL_0903, IL_0911, IL_091f, IL_0937, IL_0945, IL_0958, IL_0966, IL_097e, IL_09a5, IL_09c9, IL_09ea, IL_09fa, IL_0a38, IL_0a48, IL_0a5d, IL_0a6b, IL_0a7e, IL_0a88, IL_0a93, IL_0aac, IL_0abc, IL_0acc, IL_0adc, IL_0aec, IL_0afc, IL_0b23, IL_0b2f, IL_0b36 are reachable both inside and outside the pinned region starting at IL_0b11. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 98;
		int num4 = default(int);
		int num7 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			num = 97;
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					num = 121;
					while (true)
					{
						int num2;
						int num3;
						byte[] array2;
						object[] array3;
						int[] array4;
						long[] array5;
						object[] array6;
						byte* ptr;
						byte* num5;
						int num6;
						object[] array7;
						int num8;
						byte* num9;
						byte* ptr2;
						byte[] array = new byte[4];
						if (true)
						{
							num = 115;
							while (true)
							{
								IL_0afc:
								num2 = 1;
								while (true)
								{
									IL_0aec:
									num3 = num2 * 4;
									while (true)
									{
										IL_0adc:
										array2 = new byte[4];
										while (true)
										{
											IL_0acc:
											array3 = new object[4];
											while (true)
											{
												IL_0abc:
												array4 = new int[4];
												while (true)
												{
													IL_0aac:
													array5 = new long[4];
													while (true)
													{
														IL_0a93:
														array6 = new object[20];
														num = 140;
														while (true)
														{
															IL_0a88:
															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCheckIdLeftArrow.GetTimeIMoniker);
															while (true)
															{
																IL_0a7e:
																ptr2 = ptr;
																while (true)
																{
																	IL_0a6b:
																	if (num4 == 1)
																	{
																		return;
																	}
																	while (true)
																	{
																		IL_0398:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0388:
																			ptr2++;
																			while (true)
																			{
																				IL_0378:
																				if (b >= 1)
																				{
																					while (b <= 18)
																					{
																						while (true)
																						{
																							IL_035b:
																							if (9 < b)
																							{
																								while (true)
																								{
																									IL_034b:
																									if (14 < b)
																									{
																										while (true)
																										{
																											IL_033b:
																											if (16 < b)
																											{
																												while (true)
																												{
																													IL_032b:
																													if (17 < b)
																													{
																														while (18 >= b)
																														{
																															num = 186;
																															while (true)
																															{
																																if (num != 186)
																																{
																																	if (num != 1167)
																																	{
																																		break;
																																	}
																																	switch (num)
																																	{
																																	case 177:
																																		break;
																																	default:
																																		continue;
																																	case 76:
																																		goto IL_0318;
																																	case 10:
																																	case 49:
																																		goto IL_032b;
																																	case 35:
																																	case 100:
																																		goto IL_033b;
																																	case 124:
																																		goto IL_034b;
																																	case 2:
																																		goto IL_035b;
																																	case 136:
																																		goto IL_0368;
																																	case 93:
																																		goto IL_0378;
																																	case 117:
																																		goto IL_0388;
																																	case 84:
																																	case 131:
																																		goto IL_0398;
																																	case 1:
																																		goto IL_03a3;
																																	case 53:
																																	case 108:
																																		goto IL_03b1;
																																	case 104:
																																		goto IL_03d3;
																																	case 129:
																																		goto IL_03e1;
																																	case 59:
																																		goto IL_03ef;
																																	case 141:
																																		goto IL_0402;
																																	case 83:
																																	case 116:
																																		goto IL_0410;
																																	case 48:
																																		goto IL_0429;
																																	case 69:
																																	case 148:
																																		goto IL_043c;
																																	case 13:
																																	case 39:
																																		goto IL_044a;
																																	case 125:
																																		goto IL_0455;
																																	case 118:
																																		goto IL_0460;
																																	case 15:
																																	case 52:
																																		goto IL_0473;
																																	case 79:
																																		goto IL_0488;
																																	case 57:
																																		goto IL_049b;
																																	case 5:
																																		goto IL_04a9;
																																	case 45:
																																		goto IL_04b7;
																																	case 122:
																																		goto IL_04ca;
																																	case 127:
																																		goto IL_04d5;
																																	case 73:
																																		goto IL_04e3;
																																	case 41:
																																	case 50:
																																		goto IL_04ee;
																																	case 109:
																																		goto IL_050c;
																																	case 36:
																																	case 147:
																																		goto IL_0528;
																																	case 80:
																																		goto IL_053d;
																																	case 22:
																																	case 152:
																																		goto IL_0550;
																																	case 155:
																																		goto IL_0563;
																																	case 70:
																																	case 142:
																																		goto IL_0571;
																																	case 67:
																																		goto IL_0628;
																																	case 101:
																																		goto IL_0636;
																																	case 158:
																																		goto IL_0649;
																																	case 87:
																																	case 135:
																																		goto IL_0657;
																																	case 153:
																																		goto IL_066c;
																																	case 159:
																																		goto IL_067f;
																																	case 46:
																																	case 163:
																																		goto IL_0692;
																																	case 37:
																																		goto IL_06a0;
																																	case 92:
																																	case 143:
																																		goto IL_06ae;
																																	case 56:
																																		goto IL_06c3;
																																	case 166:
																																	case 167:
																																		goto IL_06d6;
																																	case 91:
																																		goto IL_06f4;
																																	case 134:
																																		goto IL_0702;
																																	case 157:
																																	case 175:
																																		goto IL_0723;
																																	case 34:
																																		goto IL_073f;
																																	case 82:
																																		goto IL_074a;
																																	case 173:
																																		goto IL_0758;
																																	case 31:
																																	case 38:
																																		goto IL_0766;
																																	case 0:
																																		goto IL_077a;
																																	case 102:
																																		goto IL_07b2;
																																	case 18:
																																	case 165:
																																		goto IL_07c5;
																																	case 133:
																																		goto IL_07df;
																																	case 60:
																																		goto IL_07f2;
																																	case 128:
																																	case 150:
																																		goto IL_0800;
																																	case 114:
																																		goto IL_080e;
																																	case 26:
																																	case 27:
																																		goto IL_081c;
																																	case 23:
																																		goto IL_082a;
																																	case 9:
																																	case 149:
																																		goto IL_0838;
																																	case 113:
																																		goto IL_0878;
																																	case 58:
																																		goto IL_088c;
																																	case 61:
																																	case 132:
																																		goto IL_089f;
																																	case 126:
																																		goto IL_08c8;
																																	case 3:
																																	case 164:
																																		goto IL_08ea;
																																	case 71:
																																	case 146:
																																		goto IL_08f5;
																																	case 72:
																																		goto IL_0903;
																																	case 6:
																																	case 120:
																																		goto IL_0911;
																																	case 42:
																																		goto IL_091f;
																																	case 119:
																																		goto IL_0937;
																																	case 105:
																																		goto IL_0945;
																																	case 96:
																																		goto IL_0958;
																																	case 40:
																																	case 81:
																																		goto IL_0966;
																																	case 55:
																																		goto IL_097e;
																																	case 176:
																																		goto IL_09a5;
																																	case 14:
																																		goto IL_09c9;
																																	case 32:
																																		goto IL_09ea;
																																	case 86:
																																	case 178:
																																		goto IL_09fa;
																																	case 172:
																																		goto IL_0a38;
																																	case 7:
																																	case 8:
																																	case 11:
																																	case 16:
																																	case 17:
																																	case 19:
																																	case 20:
																																	case 21:
																																	case 25:
																																	case 29:
																																	case 33:
																																	case 44:
																																	case 47:
																																	case 68:
																																	case 88:
																																	case 94:
																																	case 103:
																																	case 107:
																																	case 110:
																																	case 111:
																																	case 112:
																																	case 123:
																																	case 137:
																																	case 138:
																																	case 139:
																																	case 154:
																																	case 156:
																																	case 162:
																																	case 169:
																																	case 171:
																																	case 179:
																																		goto end_IL_0305;
																																	case 64:
																																		goto IL_0a5d;
																																	case 24:
																																	case 28:
																																	case 51:
																																	case 54:
																																	case 63:
																																	case 65:
																																	case 66:
																																	case 75:
																																	case 78:
																																	case 85:
																																	case 89:
																																	case 90:
																																	case 95:
																																	case 99:
																																	case 144:
																																	case 151:
																																	case 161:
																																	case 168:
																																	case 170:
																																	case 174:
																																		goto IL_0a6b;
																																	case 4:
																																		goto IL_0a7e;
																																	case 140:
																																		goto IL_0a88;
																																	case 43:
																																		goto IL_0a93;
																																	case 30:
																																		goto IL_0aac;
																																	case 130:
																																		goto IL_0abc;
																																	case 62:
																																		goto IL_0acc;
																																	case 74:
																																	case 77:
																																		goto IL_0adc;
																																	case 106:
																																		goto IL_0aec;
																																	case 115:
																																		goto IL_0afc;
																																	case 121:
																																		break;
																																	case 12:
																																		num = 121;
																																		break;
																																	case 97:
																																		Class300.smethod_0();
																																		goto case 12;
																																	case 98:
																																		Class296.Aw4EYyy3h();
																																		num = 97;
																																		goto case 97;
																																	case 145:
																																	case 160:
																																		return;
																																	}
																																	goto end_IL_0378;
																																}
																																if (18 > b)
																																{
																																	break;
																																}
																																goto IL_0723;
																																IL_0723:
																																num5 = ptr2;
																																num6 = -200;
																																num4 = 1;
																																ptr2 = num5 + num6;
																																goto IL_0a6b;
																																continue;
																																end_IL_0305:
																																break;
																															}
																															break;
																															IL_0318:;
																														}
																														break;
																													}
																													goto IL_0402;
																													IL_0429:
																													num7--;
																													goto IL_0a6b;
																													IL_0402:
																													if (17 > b)
																													{
																														break;
																													}
																													goto IL_0410;
																													IL_0410:
																													string_0 = (string[])array3[num7 - 1];
																													goto IL_0429;
																												}
																												break;
																											}
																											goto IL_073f;
																											IL_07df:
																											num7--;
																											goto IL_0a6b;
																											IL_073f:
																											if (16 > b)
																											{
																												goto IL_074a;
																											}
																											goto IL_07c5;
																											IL_074a:
																											if (15 < b)
																											{
																												break;
																											}
																											goto IL_0758;
																											IL_0758:
																											if (15 > b)
																											{
																												break;
																											}
																											goto IL_0766;
																											IL_0766:
																											array2[num7 - 1] = 5;
																											goto IL_077a;
																											IL_077a:
																											array3[num7 - 1] = ((delegate*<string[], string>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
																											goto IL_07b2;
																											IL_07b2:
																											ptr2 += 8;
																											goto IL_0a6b;
																											IL_07c5:
																											int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																											goto IL_07df;
																										}
																										break;
																									}
																									goto IL_07f2;
																									IL_09fa:
																									((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2])] = (string)array3[num7 - 1];
																									goto IL_0a38;
																									IL_07f2:
																									if (14 > b)
																									{
																										goto IL_0800;
																									}
																									goto IL_09fa;
																									IL_0800:
																									if (11 >= b)
																									{
																										goto IL_080e;
																									}
																									num = 164;
																									goto IL_08ea;
																									IL_080e:
																									if (11 > b)
																									{
																										goto IL_081c;
																									}
																									goto IL_089f;
																									IL_081c:
																									if (10 < b)
																									{
																										break;
																									}
																									goto IL_082a;
																									IL_082a:
																									if (10 > b)
																									{
																										break;
																									}
																									goto IL_0838;
																									IL_0838:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																									goto IL_0878;
																									IL_0878:
																									array2[num7 - 2] = 0;
																									goto IL_088c;
																									IL_088c:
																									num7--;
																									goto IL_0a6b;
																									IL_089f:
																									array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1])];
																									goto IL_08c8;
																									IL_08c8:
																									array2[num7 - 1] = 5;
																									goto IL_0a6b;
																									IL_0a38:
																									num7 -= 3;
																									goto IL_0a6b;
																									IL_08ea:
																									if (12 < b)
																									{
																										goto IL_08f5;
																									}
																									goto IL_0958;
																									IL_08f5:
																									if (13 < b)
																									{
																										break;
																									}
																									goto IL_0903;
																									IL_0903:
																									if (13 > b)
																									{
																										break;
																									}
																									goto IL_0911;
																									IL_0911:
																									array2[num7] = 5;
																									goto IL_091f;
																									IL_091f:
																									array3[num7] = array6[*(int*)(ptr2 + num3)];
																									goto IL_0937;
																									IL_0937:
																									num7++;
																									goto IL_0945;
																									IL_0945:
																									ptr2 += 8;
																									goto IL_0a6b;
																									IL_0958:
																									if (12 > b)
																									{
																										break;
																									}
																									goto IL_0966;
																									IL_0966:
																									array2[num7] = array2[num7 - 1];
																									goto IL_097e;
																									IL_097e:
																									array4[num7 - 0] = array4[num7 - 1];
																									num = 176;
																									goto IL_09a5;
																									IL_09a5:
																									*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																									goto IL_09c9;
																									IL_09c9:
																									array3[num7] = array3[num7 - 1];
																									num = 32;
																									goto IL_09ea;
																									IL_09ea:
																									num7++;
																									goto IL_0a6b;
																								}
																								break;
																							}
																							goto IL_03a3;
																							IL_06ae:
																							((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																							goto IL_06c3;
																							IL_03a3:
																							if (9 <= b)
																							{
																								goto IL_03b1;
																							}
																							goto IL_043c;
																							IL_03b1:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(int*)(ptr2 + num3);
																							num = 104;
																							goto IL_03d3;
																							IL_03d3:
																							array2[num7] = 0;
																							goto IL_03e1;
																							IL_03e1:
																							num7++;
																							goto IL_03ef;
																							IL_03ef:
																							ptr2 += 8;
																							goto IL_0a6b;
																							IL_043c:
																							if (4 < b)
																							{
																								goto IL_044a;
																							}
																							goto IL_04ca;
																							IL_044a:
																							if (6 >= b)
																							{
																								goto IL_0455;
																							}
																							goto IL_049b;
																							IL_0455:
																							if (6 > b)
																							{
																								goto IL_0460;
																							}
																							goto IL_0473;
																							IL_0460:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_0649;
																							IL_0649:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_0657;
																							IL_0657:
																							((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																							goto IL_066c;
																							IL_066c:
																							ptr2 += 8;
																							goto IL_0a6b;
																							IL_0473:
																							((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																							goto IL_0488;
																							IL_0488:
																							ptr2 += 8;
																							goto IL_0a6b;
																							IL_049b:
																							if (7 < b)
																							{
																								goto IL_04a9;
																							}
																							goto IL_0563;
																							IL_04a9:
																							if (8 < b)
																							{
																								break;
																							}
																							goto IL_04b7;
																							IL_04b7:
																							if (8 > b)
																							{
																								break;
																							}
																							goto IL_06d6;
																							IL_06d6:
																							array6[*(int*)(ptr2 + num3)] = array3[num7 - 1];
																							goto IL_06f4;
																							IL_06f4:
																							ptr2 += 8;
																							goto IL_0702;
																							IL_0702:
																							num7--;
																							goto IL_0a6b;
																							IL_0563:
																							if (7 > b)
																							{
																								break;
																							}
																							goto IL_0571;
																							IL_0571:
																							array7 = array3;
																							num8 = num7;
																							if (array == null)
																							{
																								goto IL_0580;
																							}
																							num9 = ptr2;
																							byte b2 = *num9;
																							ptr2 = num9 + 4;
																							int num10 = *(int*)(ptr2 + num3);
																							ptr2 += 8;
																							byte* ptr3 = ptr2 + num10;
																							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																							while (ptr2 != ptr3)
																							{
																								*ptr4 = (byte)(*ptr2 ^ b2);
																								ptr2++;
																								ptr4++;
																							}
																							array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																							goto IL_0628;
																							IL_06c3:
																							ptr2 += 8;
																							goto IL_0a6b;
																							IL_053d:
																							ptr2 += 8;
																							goto IL_0a6b;
																							IL_0528:
																							((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																							goto IL_053d;
																							IL_0628:
																							array2[num7] = 5;
																							goto IL_0636;
																							IL_0636:
																							num7++;
																							goto IL_0a6b;
																							IL_04ca:
																							if (4 > b)
																							{
																								goto IL_04d5;
																							}
																							num = 36;
																							goto IL_0528;
																							IL_04d5:
																							if (2 >= b)
																							{
																								goto IL_04e3;
																							}
																							goto IL_0692;
																							IL_04e3:
																							if (2 <= b)
																							{
																								goto IL_04ee;
																							}
																							goto IL_0550;
																							IL_04ee:
																							((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																							num = 109;
																							goto IL_050c;
																							IL_050c:
																							ptr2 += 8;
																							goto IL_0a6b;
																							IL_0550:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_067f;
																							IL_067f:
																							if (1 <= b)
																							{
																							}
																							break;
																							IL_0692:
																							if (3 < b)
																							{
																								break;
																							}
																							goto IL_06a0;
																							IL_06a0:
																							if (3 > b)
																							{
																								break;
																							}
																							goto IL_06ae;
																						}
																						break;
																						IL_0368:;
																					}
																				}
																				((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																				goto IL_0a5d;
																				IL_0a5d:
																				ptr2 += 8;
																				goto IL_0a6b;
																				continue;
																				end_IL_0378:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
						}
						continue;
						IL_0580:
						while (true)
						{
							IL_0580_2:
							array = new byte[4];
							while (true)
							{
								IL_058e:
								num9 = ptr2;
								byte b2 = *num9;
								ptr2 = num9 + 4;
								int num10 = *(int*)(ptr2 + num3);
								ptr2 += 8;
								byte* ptr3 = ptr2 + num10;
								byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
								while (ptr2 != ptr3)
								{
									*ptr4 = (byte)(*ptr2 ^ b2);
									ptr2++;
									ptr4++;
								}
								array7[num8] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
								while (true)
								{
									array2[num7] = 5;
									while (true)
									{
										IL_0636_2:
										num7++;
										while (true)
										{
											IL_0a6b_2:
											if (num4 == 1)
											{
												return;
											}
											while (true)
											{
												byte b = *ptr2;
												while (true)
												{
													ptr2++;
													while (true)
													{
														IL_0378_2:
														if (b >= 1)
														{
															while (b <= 18)
															{
																while (true)
																{
																	IL_035b_2:
																	if (9 < b)
																	{
																		while (true)
																		{
																			IL_034b_2:
																			if (14 < b)
																			{
																				while (true)
																				{
																					IL_033b_2:
																					if (16 < b)
																					{
																						while (true)
																						{
																							IL_032b_2:
																							if (17 < b)
																							{
																								while (18 >= b)
																								{
																									num = 186;
																									while (true)
																									{
																										if (num != 186)
																										{
																											if (num != 1167)
																											{
																												break;
																											}
																											switch (num)
																											{
																											case 76:
																												goto IL_0318_2;
																											case 10:
																											case 49:
																												goto IL_032b_2;
																											case 35:
																											case 100:
																												goto IL_033b_2;
																											case 124:
																												goto IL_034b_2;
																											case 2:
																												goto IL_035b_2;
																											case 136:
																												goto IL_0368_2;
																											case 93:
																												goto IL_0378_2;
																											case 117:
																												goto end_IL_0378_2;
																											case 84:
																											case 131:
																												goto end_IL_0388;
																											case 1:
																												goto IL_03a3_2;
																											case 53:
																											case 108:
																												goto IL_03b1_2;
																											case 104:
																												goto IL_03d3_2;
																											case 129:
																												goto IL_03e1_2;
																											case 59:
																												goto IL_03ef_2;
																											case 141:
																												goto IL_0402_2;
																											case 83:
																											case 116:
																												goto IL_0410_2;
																											case 48:
																												goto IL_0429_2;
																											case 69:
																											case 148:
																												goto IL_043c_2;
																											case 13:
																											case 39:
																												goto IL_044a_2;
																											case 125:
																												goto IL_0455_2;
																											case 118:
																												goto IL_0460_2;
																											case 15:
																											case 52:
																												goto IL_0473_2;
																											case 79:
																												goto IL_0488_2;
																											case 57:
																												goto IL_049b_2;
																											case 5:
																												goto IL_04a9_2;
																											case 45:
																												goto IL_04b7_2;
																											case 122:
																												goto IL_04ca_2;
																											case 127:
																												goto IL_04d5_2;
																											case 73:
																												goto IL_04e3_2;
																											case 41:
																											case 50:
																												goto IL_04ee_2;
																											case 109:
																												goto IL_050c_2;
																											case 36:
																											case 147:
																												goto IL_0528_2;
																											case 80:
																												goto IL_053d_2;
																											case 22:
																											case 152:
																												goto IL_0550_2;
																											case 155:
																												goto IL_0563_2;
																											case 70:
																											case 142:
																												goto IL_0571_2;
																											case 67:
																												goto end_IL_0398;
																											case 101:
																												goto IL_0636_2;
																											case 158:
																												goto IL_0649_2;
																											case 87:
																											case 135:
																												goto IL_0657_2;
																											case 153:
																												goto IL_066c_2;
																											case 159:
																												goto IL_067f_2;
																											case 46:
																											case 163:
																												goto IL_0692_2;
																											case 37:
																												goto IL_06a0_2;
																											case 92:
																											case 143:
																												goto IL_06ae_2;
																											case 56:
																												goto IL_06c3_2;
																											case 166:
																											case 167:
																												goto IL_06d6_2;
																											case 91:
																												goto IL_06f4_2;
																											case 134:
																												goto IL_0702_2;
																											case 157:
																											case 175:
																												goto IL_0723_2;
																											case 34:
																												goto IL_073f_2;
																											case 82:
																												goto IL_074a_2;
																											case 173:
																												goto IL_0758_2;
																											case 31:
																											case 38:
																												goto IL_0766_2;
																											case 0:
																												goto IL_077a_2;
																											case 102:
																												goto IL_07b2_2;
																											case 18:
																											case 165:
																												goto IL_07c5_2;
																											case 133:
																												goto IL_07df_2;
																											case 60:
																												goto IL_07f2_2;
																											case 128:
																											case 150:
																												goto IL_0800_2;
																											case 114:
																												goto IL_080e_2;
																											case 26:
																											case 27:
																												goto IL_081c_2;
																											case 23:
																												goto IL_082a_2;
																											case 9:
																											case 149:
																												goto IL_0838_2;
																											case 113:
																												goto IL_0878_2;
																											case 58:
																												goto IL_088c_2;
																											case 61:
																											case 132:
																												goto IL_089f_2;
																											case 126:
																												goto IL_08c8_2;
																											case 3:
																											case 164:
																												goto IL_08ea_2;
																											case 71:
																											case 146:
																												goto IL_08f5_2;
																											case 72:
																												goto IL_0903_2;
																											case 6:
																											case 120:
																												goto IL_0911_2;
																											case 42:
																												goto IL_091f_2;
																											case 119:
																												goto IL_0937_2;
																											case 105:
																												goto IL_0945_2;
																											case 96:
																												goto IL_0958_2;
																											case 40:
																											case 81:
																												goto IL_0966_2;
																											case 55:
																												goto IL_097e_2;
																											case 176:
																												goto IL_09a5_2;
																											case 14:
																												goto IL_09c9_2;
																											case 32:
																												goto IL_09ea_2;
																											case 86:
																											case 178:
																												goto IL_09fa_2;
																											case 172:
																												goto IL_0a38_2;
																											case 7:
																											case 8:
																											case 11:
																											case 16:
																											case 17:
																											case 19:
																											case 20:
																											case 21:
																											case 25:
																											case 29:
																											case 33:
																											case 44:
																											case 47:
																											case 68:
																											case 88:
																											case 94:
																											case 103:
																											case 107:
																											case 110:
																											case 111:
																											case 112:
																											case 123:
																											case 137:
																											case 138:
																											case 139:
																											case 154:
																											case 156:
																											case 162:
																											case 169:
																											case 171:
																											case 179:
																												goto end_IL_0305_2;
																											case 64:
																												goto IL_0a5d_2;
																											case 24:
																											case 28:
																											case 51:
																											case 54:
																											case 63:
																											case 65:
																											case 66:
																											case 75:
																											case 78:
																											case 85:
																											case 89:
																											case 90:
																											case 95:
																											case 99:
																											case 144:
																											case 151:
																											case 161:
																											case 168:
																											case 170:
																											case 174:
																												goto IL_0a6b_2;
																											case 4:
																												ptr2 = ptr;
																												goto IL_0a6b_2;
																											case 140:
																												ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getCheckIdLeftArrow.GetTimeIMoniker);
																												goto case 4;
																											case 43:
																												array6 = new object[20];
																												num = 140;
																												goto case 140;
																											case 30:
																												array5 = new long[4];
																												goto case 43;
																											case 130:
																												array4 = new int[4];
																												goto case 30;
																											case 62:
																												array3 = new object[4];
																												goto case 130;
																											case 74:
																											case 77:
																												array2 = new byte[4];
																												goto case 62;
																											case 106:
																												num3 = num2 * 4;
																												goto case 74;
																											case 115:
																												num2 = 1;
																												goto case 106;
																											case 121:
																											case 177:
																												goto end_IL_0628;
																											case 12:
																												goto end_IL_0b07;
																											case 97:
																												goto end_IL_0b23;
																											case 98:
																												goto end_IL_0b2f;
																											case 145:
																											case 160:
																												return;
																											}
																											continue;
																										}
																										if (18 > b)
																										{
																											break;
																										}
																										goto IL_0723_2;
																										IL_0723_2:
																										num5 = ptr2;
																										num6 = -200;
																										num4 = 1;
																										ptr2 = num5 + num6;
																										goto IL_0a6b_2;
																										continue;
																										end_IL_0305_2:
																										break;
																									}
																									break;
																									IL_0318_2:;
																								}
																								break;
																							}
																							goto IL_0402_2;
																							IL_0429_2:
																							num7--;
																							goto IL_0a6b_2;
																							IL_0402_2:
																							if (17 > b)
																							{
																								break;
																							}
																							goto IL_0410_2;
																							IL_0410_2:
																							string_0 = (string[])array3[num7 - 1];
																							goto IL_0429_2;
																						}
																						break;
																					}
																					goto IL_073f_2;
																					IL_07df_2:
																					num7--;
																					goto IL_0a6b_2;
																					IL_073f_2:
																					if (16 > b)
																					{
																						goto IL_074a_2;
																					}
																					goto IL_07c5_2;
																					IL_074a_2:
																					if (15 < b)
																					{
																						break;
																					}
																					goto IL_0758_2;
																					IL_0758_2:
																					if (15 > b)
																					{
																						break;
																					}
																					goto IL_0766_2;
																					IL_0766_2:
																					array2[num7 - 1] = 5;
																					goto IL_077a_2;
																					IL_077a_2:
																					array3[num7 - 1] = ((delegate*<string[], string>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])((string[])array3[num7 - 1]);
																					goto IL_07b2_2;
																					IL_07b2_2:
																					ptr2 += 8;
																					goto IL_0a6b_2;
																					IL_07c5_2:
																					int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																					goto IL_07df_2;
																				}
																				break;
																			}
																			goto IL_07f2_2;
																			IL_09fa_2:
																			((string[])array3[num7 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2])] = (string)array3[num7 - 1];
																			goto IL_0a38_2;
																			IL_07f2_2:
																			if (14 > b)
																			{
																				goto IL_0800_2;
																			}
																			goto IL_09fa_2;
																			IL_0800_2:
																			if (11 >= b)
																			{
																				goto IL_080e_2;
																			}
																			num = 164;
																			goto IL_08ea_2;
																			IL_080e_2:
																			if (11 > b)
																			{
																				goto IL_081c_2;
																			}
																			goto IL_089f_2;
																			IL_081c_2:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_082a_2;
																			IL_082a_2:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0838_2;
																			IL_0838_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																			goto IL_0878_2;
																			IL_0878_2:
																			array2[num7 - 2] = 0;
																			goto IL_088c_2;
																			IL_088c_2:
																			num7--;
																			goto IL_0a6b_2;
																			IL_089f_2:
																			array3[num7 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1])];
																			goto IL_08c8_2;
																			IL_08c8_2:
																			array2[num7 - 1] = 5;
																			goto IL_0a6b_2;
																			IL_0a38_2:
																			num7 -= 3;
																			goto IL_0a6b_2;
																			IL_08ea_2:
																			if (12 < b)
																			{
																				goto IL_08f5_2;
																			}
																			goto IL_0958_2;
																			IL_08f5_2:
																			if (13 < b)
																			{
																				break;
																			}
																			goto IL_0903_2;
																			IL_0903_2:
																			if (13 > b)
																			{
																				break;
																			}
																			goto IL_0911_2;
																			IL_0911_2:
																			array2[num7] = 5;
																			goto IL_091f_2;
																			IL_091f_2:
																			array3[num7] = array6[*(int*)(ptr2 + num3)];
																			goto IL_0937_2;
																			IL_0937_2:
																			num7++;
																			goto IL_0945_2;
																			IL_0945_2:
																			ptr2 += 8;
																			goto IL_0a6b_2;
																			IL_0958_2:
																			if (12 > b)
																			{
																				break;
																			}
																			goto IL_0966_2;
																			IL_0966_2:
																			array2[num7] = array2[num7 - 1];
																			goto IL_097e_2;
																			IL_097e_2:
																			array4[num7 - 0] = array4[num7 - 1];
																			num = 176;
																			goto IL_09a5_2;
																			IL_09a5_2:
																			*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7 - 1]);
																			goto IL_09c9_2;
																			IL_09c9_2:
																			array3[num7] = array3[num7 - 1];
																			num = 32;
																			goto IL_09ea_2;
																			IL_09ea_2:
																			num7++;
																			goto IL_0a6b_2;
																		}
																		break;
																	}
																	goto IL_03a3_2;
																	IL_0528_2:
																	((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																	goto IL_053d_2;
																	IL_03a3_2:
																	if (9 <= b)
																	{
																		goto IL_03b1_2;
																	}
																	goto IL_043c_2;
																	IL_03b1_2:
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num7]) = *(int*)(ptr2 + num3);
																	num = 104;
																	goto IL_03d3_2;
																	IL_03d3_2:
																	array2[num7] = 0;
																	goto IL_03e1_2;
																	IL_03e1_2:
																	num7++;
																	goto IL_03ef_2;
																	IL_03ef_2:
																	ptr2 += 8;
																	goto IL_0a6b_2;
																	IL_043c_2:
																	if (4 < b)
																	{
																		goto IL_044a_2;
																	}
																	goto IL_04ca_2;
																	IL_044a_2:
																	if (6 >= b)
																	{
																		goto IL_0455_2;
																	}
																	goto IL_049b_2;
																	IL_0455_2:
																	if (6 > b)
																	{
																		goto IL_0460_2;
																	}
																	goto IL_0473_2;
																	IL_0460_2:
																	if (5 < b)
																	{
																		break;
																	}
																	goto IL_0649_2;
																	IL_0649_2:
																	if (5 > b)
																	{
																		break;
																	}
																	goto IL_0657_2;
																	IL_0657_2:
																	((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																	goto IL_066c_2;
																	IL_066c_2:
																	ptr2 += 8;
																	goto IL_0a6b_2;
																	IL_0473_2:
																	((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																	goto IL_0488_2;
																	IL_0488_2:
																	ptr2 += 8;
																	goto IL_0a6b_2;
																	IL_049b_2:
																	if (7 < b)
																	{
																		goto IL_04a9_2;
																	}
																	goto IL_0563_2;
																	IL_04a9_2:
																	if (8 < b)
																	{
																		break;
																	}
																	goto IL_04b7_2;
																	IL_04b7_2:
																	if (8 > b)
																	{
																		break;
																	}
																	goto IL_06d6_2;
																	IL_06d6_2:
																	array6[*(int*)(ptr2 + num3)] = array3[num7 - 1];
																	goto IL_06f4_2;
																	IL_06f4_2:
																	ptr2 += 8;
																	goto IL_0702_2;
																	IL_0702_2:
																	num7--;
																	goto IL_0a6b_2;
																	IL_0563_2:
																	if (7 > b)
																	{
																		break;
																	}
																	goto IL_0571_2;
																	IL_0571_2:
																	array7 = array3;
																	num8 = num7;
																	if (array == null)
																	{
																		goto IL_0580_2;
																	}
																	goto IL_058e;
																	IL_04ca_2:
																	if (4 > b)
																	{
																		goto IL_04d5_2;
																	}
																	num = 36;
																	goto IL_0528_2;
																	IL_04d5_2:
																	if (2 >= b)
																	{
																		goto IL_04e3_2;
																	}
																	goto IL_0692_2;
																	IL_04e3_2:
																	if (2 <= b)
																	{
																		goto IL_04ee_2;
																	}
																	goto IL_0550_2;
																	IL_04ee_2:
																	((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																	num = 109;
																	goto IL_050c_2;
																	IL_050c_2:
																	ptr2 += 8;
																	goto IL_0a6b_2;
																	IL_0550_2:
																	if (1 < b)
																	{
																		break;
																	}
																	goto IL_067f_2;
																	IL_067f_2:
																	if (1 <= b)
																	{
																	}
																	break;
																	IL_0692_2:
																	if (3 < b)
																	{
																		break;
																	}
																	goto IL_06a0_2;
																	IL_06a0_2:
																	if (3 > b)
																	{
																		break;
																	}
																	goto IL_06ae_2;
																	IL_06ae_2:
																	((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
																	goto IL_06c3_2;
																	IL_06c3_2:
																	ptr2 += 8;
																	goto IL_0a6b_2;
																	IL_053d_2:
																	ptr2 += 8;
																	goto IL_0a6b_2;
																}
																break;
																IL_0368_2:;
															}
														}
														((delegate*<void>)ToSerializedStringSignatureID[*(int*)(ptr2 + num3)])();
														goto IL_0a5d_2;
														IL_0a5d_2:
														ptr2 += 8;
														goto IL_0a6b_2;
														continue;
														end_IL_0378_2:
														break;
													}
													continue;
													end_IL_0388:
													break;
												}
												continue;
												end_IL_0398:
												break;
											}
											break;
										}
										break;
									}
									continue;
									end_IL_0628:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_0b07:
						break;
					}
					continue;
					end_IL_0b23:
					break;
				}
				continue;
				end_IL_0b2f:
				break;
			}
		}
	}

	private unsafe static int smethod_2(int int_1, int int_2)
	{
		int num = 31;
		int num4 = default(int);
		int num5 = default(int);
		byte b = default(byte);
		while (true)
		{
			int num2 = 1;
			num = 30;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 67;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										array3[1] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref SafeArrayWebName.TYPEFLAGFNONEXTENSIBLEIOException);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 96;
												while (true)
												{
													if (num == 96)
													{
														goto IL_0257;
													}
													if (num != 1077)
													{
														goto IL_02a8;
													}
													switch (num)
													{
													case 71:
														goto end_IL_018f;
													case 21:
														goto end_IL_01a2;
													case 1:
														goto end_IL_01b5;
													case 64:
														goto end_IL_01c0;
													case 0:
														goto end_IL_01d5;
													case 27:
													case 36:
														goto end_IL_01ea;
													case 67:
														goto end_IL_01fa;
													case 43:
													case 74:
														goto end_IL_020a;
													case 30:
														goto end_IL_021a;
													case 31:
														goto end_IL_0233;
													case 15:
													case 17:
													case 18:
													case 22:
													case 24:
													case 34:
													case 54:
													case 69:
													case 72:
													case 83:
														goto IL_0257;
													case 85:
													case 88:
														goto IL_0267;
													case 35:
														goto IL_0270;
													case 75:
														goto IL_027e;
													case 26:
														goto IL_028c;
													case 76:
														goto IL_029a;
													case 42:
													case 45:
														goto IL_02a8;
													case 39:
														goto IL_02bc;
													case 62:
														goto IL_02c7;
													case 60:
														goto IL_02d5;
													case 41:
													case 82:
														goto IL_02e3;
													case 77:
														goto IL_02fb;
													case 7:
													case 47:
														goto IL_0306;
													case 57:
														goto IL_0314;
													case 12:
													case 38:
														goto IL_0322;
													case 33:
														goto IL_033e;
													case 11:
													case 89:
														goto IL_034c;
													case 14:
														goto IL_035a;
													case 50:
														goto IL_037d;
													case 79:
														goto IL_0387;
													case 61:
														goto IL_0395;
													case 59:
														goto IL_03a8;
													case 23:
													case 32:
														goto IL_03b3;
													case 84:
														goto IL_03dc;
													case 78:
														goto IL_03ea;
													case 73:
														goto IL_03fd;
													case 58:
													case 66:
														goto IL_040b;
													case 46:
														goto IL_0419;
													case 53:
													case 65:
														goto IL_0427;
													case 10:
														goto IL_0467;
													case 29:
														goto IL_047b;
													case 4:
														goto IL_048e;
													case 20:
													case 28:
														goto IL_0499;
													case 19:
														goto IL_04a7;
													case 16:
													case 49:
														goto IL_04ba;
													case 44:
														goto IL_0531;
													case 2:
														goto IL_0544;
													case 70:
														goto IL_0552;
													case 80:
														goto IL_0560;
													case 5:
													case 6:
													case 8:
													case 9:
													case 13:
													case 25:
													case 37:
													case 40:
													case 48:
													case 51:
													case 52:
													case 55:
													case 63:
													case 68:
													case 81:
													case 86:
													case 87:
														goto IL_0573;
													case 3:
													case 56:
														goto IL_0598;
													}
													continue;
													IL_0544:
													array[num4] = 0;
													goto IL_0552;
													IL_0552:
													num4++;
													goto IL_0560;
													IL_0257:
													if (num5 != 1)
													{
														goto IL_0267;
													}
													goto IL_0598;
													IL_0598:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													IL_0267:
													b = *ptr2;
													goto IL_0270;
													IL_0270:
													ptr2++;
													goto IL_027e;
													IL_027e:
													if (b >= 1)
													{
														goto IL_028c;
													}
													goto IL_0573;
													IL_028c:
													if (b <= 8)
													{
														goto IL_029a;
													}
													goto IL_0573;
													IL_029a:
													if (4 < b)
													{
														goto IL_02a8;
													}
													goto IL_03a8;
													IL_02a8:
													if (6 >= b)
													{
														num = 39;
														goto IL_02bc;
													}
													goto IL_02fb;
													IL_0560:
													ptr2 += 8;
													goto IL_0257;
													IL_02bc:
													if (6 <= b)
													{
														goto IL_0257;
													}
													goto IL_02c7;
													IL_02c7:
													if (5 >= b)
													{
														goto IL_02d5;
													}
													goto IL_0573;
													IL_02d5:
													if (5 <= b)
													{
														goto IL_02e3;
													}
													goto IL_0573;
													IL_02e3:
													ptr2 = ptr + *(int*)(ptr2 + num3);
													goto IL_0257;
													IL_02fb:
													if (7 < b)
													{
														goto IL_0306;
													}
													goto IL_033e;
													IL_0306:
													if (8 >= b)
													{
														goto IL_0314;
													}
													goto IL_0573;
													IL_0314:
													if (8 <= b)
													{
														goto IL_0322;
													}
													goto IL_0573;
													IL_0322:
													byte* num6 = ptr2;
													num5 = 1;
													ptr2 = num6 + -200;
													goto IL_0257;
													IL_033e:
													if (7 <= b)
													{
														goto IL_034c;
													}
													goto IL_0573;
													IL_034c:
													array[num4] = 0;
													goto IL_035a;
													IL_035a:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_037d;
													IL_037d:
													array2[num4] = null;
													goto IL_0387;
													IL_0387:
													num4++;
													goto IL_0395;
													IL_0395:
													ptr2 += 8;
													goto IL_0257;
													IL_03a8:
													if (4 <= b)
													{
														goto IL_03b3;
													}
													goto IL_03fd;
													IL_03b3:
													ref int reference = ref array3[*(int*)(ptr2 + num3)];
													reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_03dc;
													IL_03dc:
													ptr2 += 8;
													goto IL_03ea;
													IL_03ea:
													num4--;
													goto IL_0257;
													IL_03fd:
													if (2 < b)
													{
														goto IL_040b;
													}
													goto IL_048e;
													IL_040b:
													if (3 >= b)
													{
														goto IL_0419;
													}
													goto IL_0573;
													IL_0419:
													if (3 <= b)
													{
														goto IL_0427;
													}
													goto IL_0573;
													IL_0427:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1]);
													goto IL_0467;
													IL_0467:
													array[num4 - 2] = 0;
													goto IL_047b;
													IL_047b:
													num4--;
													goto IL_0257;
													IL_048e:
													if (2 > b)
													{
														goto IL_0499;
													}
													goto IL_04ba;
													IL_0499:
													if (1 >= b)
													{
														goto IL_04a7;
													}
													goto IL_0573;
													IL_04a7:
													if (1 <= b)
													{
													}
													goto IL_0573;
													IL_04ba:
													ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
													num = 44;
													goto IL_0531;
													IL_0531:
													num4 -= 2;
													goto IL_0257;
													IL_0573:
													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num4]) = array3[*(int*)(ptr2 + num3)];
													goto IL_0544;
													continue;
													end_IL_018f:
													break;
												}
												continue;
												end_IL_01a2:
												break;
											}
											continue;
											end_IL_01b5:
											break;
										}
										continue;
										end_IL_01c0:
										break;
									}
									continue;
									end_IL_01d5:
									break;
								}
								continue;
								end_IL_01ea:
								break;
							}
							continue;
							end_IL_01fa:
							break;
						}
						continue;
						end_IL_020a:
						break;
					}
					continue;
					end_IL_021a:
					break;
				}
				continue;
				end_IL_0233:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_1)
	{
		int num = 81;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref Struct82.StackCrawlMarkContainerID);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														IL_0262:
														byte b = *ptr2;
														while (true)
														{
															IL_0252:
															ptr2++;
															while (true)
															{
																IL_0242:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_0225:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_0218:
																					if (5 > b)
																					{
																						while (true)
																						{
																							IL_0208:
																							if (2 < b)
																							{
																								while (true)
																								{
																									IL_01f8:
																									if (3 >= b)
																									{
																										while (3 <= b)
																										{
																											while (true)
																											{
																												IL_01ca:
																												ptr2 = ptr + *(int*)(ptr2 + num3);
																												num = 106;
																												while (num != 106)
																												{
																													if (num != 1087)
																													{
																														goto IL_061f;
																													}
																													switch (num)
																													{
																													case 12:
																													case 49:
																														goto IL_01ca;
																													case 54:
																														goto IL_01e8;
																													case 4:
																													case 18:
																														goto IL_01f8;
																													case 85:
																														goto IL_0208;
																													case 79:
																														goto IL_0218;
																													case 95:
																														goto IL_0225;
																													case 53:
																														goto IL_0232;
																													case 37:
																														goto IL_0242;
																													case 38:
																														goto IL_0252;
																													case 72:
																													case 73:
																														goto IL_0262;
																													case 40:
																													case 69:
																														goto IL_026d;
																													case 44:
																													case 70:
																														goto IL_027d;
																													case 31:
																														goto IL_028b;
																													case 77:
																														goto IL_02ae;
																													case 0:
																														goto IL_02b8;
																													case 30:
																														goto IL_02c6;
																													case 93:
																														goto IL_02d9;
																													case 55:
																														goto IL_02e4;
																													case 42:
																													case 58:
																														goto IL_02f2;
																													case 82:
																														goto IL_030e;
																													case 10:
																														goto IL_0325;
																													case 96:
																														goto IL_0338;
																													case 24:
																													case 65:
																														goto IL_0343;
																													case 33:
																														goto IL_03a5;
																													case 97:
																														goto IL_03b8;
																													case 47:
																													case 52:
																														goto IL_03c3;
																													case 88:
																														goto IL_03d1;
																													case 13:
																													case 16:
																														goto IL_03df;
																													case 60:
																														goto IL_0402;
																													case 46:
																														goto IL_0410;
																													case 23:
																														goto IL_041e;
																													case 15:
																														goto IL_0431;
																													case 2:
																													case 45:
																														goto IL_043f;
																													case 78:
																														goto IL_047f;
																													case 76:
																														goto IL_0493;
																													case 62:
																														goto IL_04a6;
																													case 92:
																														goto IL_04b4;
																													case 59:
																														goto IL_04c7;
																													case 36:
																													case 51:
																														goto IL_04d2;
																													case 32:
																														goto IL_04fb;
																													case 1:
																														goto IL_0509;
																													case 74:
																														goto IL_0519;
																													case 57:
																														goto IL_0524;
																													case 7:
																													case 35:
																														goto IL_052f;
																													case 48:
																														goto IL_0548;
																													case 11:
																														goto IL_0556;
																													case 98:
																														goto IL_0564;
																													case 14:
																													case 20:
																													case 22:
																													case 26:
																													case 27:
																													case 28:
																													case 39:
																													case 50:
																													case 56:
																													case 63:
																													case 66:
																													case 83:
																													case 84:
																													case 86:
																													case 91:
																													case 99:
																														goto end_IL_01e8;
																													case 3:
																													case 5:
																													case 17:
																													case 19:
																													case 21:
																													case 29:
																													case 43:
																													case 61:
																													case 64:
																													case 67:
																													case 68:
																													case 90:
																														goto end_IL_01b7;
																													case 41:
																														goto end_IL_0587;
																													case 34:
																														goto end_IL_059a;
																													case 75:
																														goto end_IL_05a4;
																													case 8:
																														goto end_IL_05af;
																													case 6:
																													case 94:
																														goto end_IL_05c4;
																													case 87:
																														goto end_IL_05d4;
																													case 25:
																													case 71:
																														goto end_IL_05e4;
																													case 80:
																														goto end_IL_05f4;
																													case 81:
																														goto end_IL_0604;
																													case 9:
																													case 89:
																														goto IL_061f;
																													}
																													continue;
																													end_IL_01b7:
																													break;
																												}
																												break;
																											}
																											goto end_IL_0242;
																											continue;
																											end_IL_01e8:
																											break;
																											IL_01e8:;
																										}
																										break;
																									}
																									goto IL_04a6;
																									IL_04b4:
																									if (4 <= b)
																									{
																										goto end_IL_0242;
																									}
																									break;
																									IL_04a6:
																									if (4 < b)
																									{
																										break;
																									}
																									goto IL_04b4;
																								}
																								break;
																							}
																							goto IL_04c7;
																							IL_0564:
																							ptr2 += 8;
																							goto end_IL_0242;
																							IL_04c7:
																							if (2 <= b)
																							{
																								goto IL_04d2;
																							}
																							goto IL_0519;
																							IL_04d2:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_04fb;
																							IL_04fb:
																							ptr2 += 8;
																							goto IL_0509;
																							IL_0509:
																							num5--;
																							goto end_IL_0242;
																							IL_0519:
																							if (1 < b)
																							{
																								break;
																							}
																							goto IL_0524;
																							IL_0524:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_052f;
																							IL_052f:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0548;
																							IL_0548:
																							array[num5] = 0;
																							goto IL_0556;
																							IL_0556:
																							num5++;
																							goto IL_0564;
																						}
																						break;
																					}
																					goto IL_027d;
																					IL_02c6:
																					ptr2 += 8;
																					goto end_IL_0242;
																					IL_027d:
																					array[num5] = 0;
																					goto IL_028b;
																					IL_028b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_02ae;
																					IL_02ae:
																					array2[num5] = null;
																					goto IL_02b8;
																					IL_02b8:
																					num5++;
																					goto IL_02c6;
																				}
																				break;
																			}
																			goto IL_026d;
																			IL_047f:
																			array[num5 - 2] = 0;
																			goto IL_0493;
																			IL_026d:
																			if (8 < b)
																			{
																				goto IL_02d9;
																			}
																			goto IL_0338;
																			IL_02d9:
																			if (9 >= b)
																			{
																				goto IL_02e4;
																			}
																			goto IL_030e;
																			IL_02e4:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_02f2;
																			IL_02f2:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0242;
																			IL_030e:
																			if (10 < b)
																			{
																				break;
																			}
																			num = 10;
																			goto IL_0325;
																			IL_0493:
																			num5--;
																			goto end_IL_0242;
																			IL_0325:
																			if (10 > b)
																			{
																			}
																			break;
																			IL_0338:
																			if (8 <= b)
																			{
																				goto IL_0343;
																			}
																			goto IL_03b8;
																			IL_0343:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03a5;
																			IL_03a5:
																			num5 -= 2;
																			goto end_IL_0242;
																			IL_03b8:
																			if (6 < b)
																			{
																				goto IL_03c3;
																			}
																			goto IL_0431;
																			IL_03c3:
																			if (7 < b)
																			{
																				break;
																			}
																			goto IL_03d1;
																			IL_03d1:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_03df;
																			IL_03df:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0402;
																			IL_0402:
																			array[num5] = 0;
																			goto IL_0410;
																			IL_0410:
																			num5++;
																			goto IL_041e;
																			IL_041e:
																			ptr2 += 8;
																			goto end_IL_0242;
																			IL_0431:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_043f;
																			IL_043f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_047f;
																		}
																		break;
																		IL_0232:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																break;
																continue;
																end_IL_0242:
																break;
															}
															break;
														}
														break;
													}
													continue;
												}
												goto IL_061f;
												IL_061f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0587:
												break;
											}
											continue;
											end_IL_059a:
											break;
										}
										continue;
										end_IL_05a4:
										break;
									}
									continue;
									end_IL_05af:
									break;
								}
								continue;
								end_IL_05c4:
								break;
							}
							continue;
							end_IL_05d4:
							break;
						}
						continue;
						end_IL_05e4:
						break;
					}
					continue;
					end_IL_05f4:
					break;
				}
				continue;
				end_IL_0604:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_1)
	{
		int num = 11;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						num = 41;
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getLocalVariablesSystemAlarmCallbackObject.getLocalVariablesSystemAlarmCallbackObject_0);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0281:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0264:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0254:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0244:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0237:
																									if (4 < b)
																									{
																										while (true)
																										{
																											IL_0224:
																											if (5 < b)
																											{
																												num = 125;
																												while (num != 125)
																												{
																													if (num != 1106)
																													{
																														goto IL_05b9;
																													}
																													switch (num)
																													{
																													case 93:
																														goto IL_0224;
																													case 44:
																													case 86:
																														goto IL_0237;
																													case 7:
																													case 46:
																														goto IL_0244;
																													case 105:
																														goto IL_0254;
																													case 25:
																														goto IL_0264;
																													case 115:
																														goto IL_0271;
																													case 1:
																														goto IL_0281;
																													case 31:
																														goto end_IL_0281;
																													case 110:
																													case 114:
																														goto end_IL_0291;
																													case 39:
																														goto IL_02ac;
																													case 64:
																														goto IL_02bf;
																													case 73:
																													case 96:
																														goto IL_02d2;
																													case 6:
																													case 45:
																														goto IL_02dd;
																													case 48:
																													case 76:
																														goto IL_02e8;
																													case 79:
																														goto IL_02fb;
																													case 57:
																													case 94:
																														goto IL_0309;
																													case 50:
																														goto IL_032e;
																													case 68:
																													case 83:
																														goto IL_033c;
																													case 0:
																													case 36:
																														goto IL_034a;
																													case 91:
																														goto IL_0358;
																													case 18:
																													case 99:
																														goto IL_036f;
																													case 26:
																													case 107:
																														goto IL_0397;
																													case 62:
																														goto IL_03a5;
																													case 21:
																														goto IL_03c8;
																													case 23:
																														goto IL_03d2;
																													case 20:
																														goto IL_03e0;
																													case 51:
																													case 108:
																														goto IL_03f3;
																													case 72:
																														goto IL_045e;
																													case 111:
																														goto IL_0471;
																													case 112:
																														goto IL_048d;
																													case 77:
																														goto IL_049b;
																													case 47:
																														goto IL_04a9;
																													case 113:
																														goto IL_04bc;
																													case 60:
																													case 66:
																														goto IL_04ca;
																													case 87:
																														goto IL_050a;
																													case 78:
																														goto IL_051e;
																													case 2:
																														goto IL_0531;
																													case 82:
																													case 97:
																														goto IL_053f;
																													case 34:
																													case 52:
																														goto IL_054a;
																													case 98:
																														goto IL_0558;
																													case 116:
																													case 117:
																														goto IL_0566;
																													case 59:
																														goto IL_0598;
																													case 71:
																														goto IL_05a6;
																													case 19:
																														goto IL_05b9;
																													case 24:
																													case 61:
																														goto IL_05c7;
																													case 106:
																														goto IL_05e0;
																													case 101:
																														goto IL_05ee;
																													case 80:
																														goto IL_05fc;
																													case 15:
																													case 49:
																														goto IL_060f;
																													case 90:
																													case 104:
																														goto IL_062d;
																													case 5:
																														goto IL_066d;
																													case 37:
																														goto IL_0681;
																													case 3:
																													case 4:
																													case 8:
																													case 17:
																													case 27:
																													case 28:
																													case 29:
																													case 35:
																													case 38:
																													case 55:
																													case 56:
																													case 65:
																													case 69:
																													case 74:
																													case 75:
																													case 81:
																													case 85:
																													case 88:
																													case 89:
																													case 95:
																													case 100:
																														goto end_IL_0211;
																													case 9:
																													case 12:
																													case 13:
																													case 40:
																													case 43:
																													case 54:
																													case 58:
																													case 63:
																													case 67:
																													case 84:
																													case 92:
																													case 102:
																													case 103:
																													case 118:
																														goto end_IL_02a1;
																													case 33:
																														goto end_IL_06a4;
																													case 53:
																														goto end_IL_06b7;
																													case 109:
																														goto end_IL_06c1;
																													case 22:
																														goto end_IL_06cc;
																													case 32:
																													case 41:
																														goto end_IL_06e1;
																													case 70:
																														goto end_IL_06f1;
																													case 16:
																													case 30:
																														goto end_IL_0701;
																													case 10:
																														goto end_IL_071a;
																													case 11:
																														goto end_IL_072a;
																													case 14:
																													case 42:
																														goto IL_0745;
																													}
																													continue;
																													end_IL_0211:
																													break;
																												}
																												break;
																											}
																											goto IL_02bf;
																											IL_03d2:
																											num5++;
																											goto IL_03e0;
																											IL_03e0:
																											ptr2 += 8;
																											goto end_IL_02a1;
																											IL_02bf:
																											if (5 > b)
																											{
																												break;
																											}
																											goto IL_0397;
																											IL_0397:
																											array[num5] = 0;
																											goto IL_03a5;
																											IL_03a5:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																											goto IL_03c8;
																											IL_03c8:
																											array2[num5] = null;
																											goto IL_03d2;
																										}
																										break;
																									}
																									goto IL_02ac;
																									IL_02ac:
																									if (4 > b)
																									{
																										break;
																									}
																									goto end_IL_02a1;
																								}
																								break;
																							}
																							goto IL_0531;
																							IL_060f:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							num = 54;
																							goto end_IL_02a1;
																							IL_0531:
																							if (3 > b)
																							{
																								goto IL_053f;
																							}
																							goto IL_060f;
																							IL_053f:
																							if (1 < b)
																							{
																								goto IL_054a;
																							}
																							goto IL_05b9;
																							IL_054a:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_0558;
																							IL_0558:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0566;
																							IL_0566:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 59;
																							goto IL_0598;
																							IL_0598:
																							ptr2 += 8;
																							goto IL_05a6;
																							IL_05a6:
																							num5--;
																							goto end_IL_02a1;
																							IL_05b9:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_05c7;
																							IL_05c7:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_05e0;
																							IL_05e0:
																							array[num5] = 0;
																							goto IL_05ee;
																							IL_05ee:
																							num5++;
																							goto IL_05fc;
																							IL_05fc:
																							ptr2 += 8;
																							goto end_IL_02a1;
																						}
																						break;
																					}
																					goto IL_062d;
																					IL_0681:
																					num5--;
																					goto end_IL_02a1;
																					IL_062d:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_066d;
																					IL_066d:
																					array[num5 - 2] = 0;
																					goto IL_0681;
																				}
																				break;
																			}
																			goto IL_02d2;
																			IL_051e:
																			num5--;
																			goto end_IL_02a1;
																			IL_02d2:
																			if (9 < b)
																			{
																				goto IL_02dd;
																			}
																			goto IL_032e;
																			IL_02dd:
																			if (10 < b)
																			{
																				goto IL_02e8;
																			}
																			goto IL_02fb;
																			IL_02e8:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0471;
																			IL_0471:
																			if (11 > b)
																			{
																				num = 29;
																			}
																			break;
																			IL_03f3:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 72;
																			goto IL_045e;
																			IL_02fb:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_0309;
																			IL_0309:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			num = 13;
																			goto end_IL_02a1;
																			IL_032e:
																			if (9 > b)
																			{
																				goto IL_033c;
																			}
																			goto IL_03f3;
																			IL_033c:
																			if (7 < b)
																			{
																				goto IL_034a;
																			}
																			goto IL_04bc;
																			IL_034a:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0358;
																			IL_0358:
																			if (8 > b)
																			{
																				break;
																			}
																			num = 99;
																			goto IL_036f;
																			IL_045e:
																			num5 -= 2;
																			goto end_IL_02a1;
																			IL_036f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_048d;
																			IL_048d:
																			array[num5] = 0;
																			goto IL_049b;
																			IL_049b:
																			num5++;
																			goto IL_04a9;
																			IL_04a9:
																			ptr2 += 8;
																			goto end_IL_02a1;
																			IL_04bc:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04ca;
																			IL_04ca:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_050a;
																			IL_050a:
																			array[num5 - 2] = 0;
																			goto IL_051e;
																		}
																		break;
																		IL_0271:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a1;
																continue;
																end_IL_0281:
																break;
															}
															continue;
															end_IL_0291:
															break;
														}
														continue;
														end_IL_02a1:
														break;
													}
													continue;
												}
												goto IL_0745;
												IL_0745:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06a4:
												break;
											}
											continue;
											end_IL_06b7:
											break;
										}
										continue;
										end_IL_06c1:
										break;
									}
									continue;
									end_IL_06cc:
									break;
								}
								continue;
								end_IL_06e1:
								break;
							}
							continue;
							end_IL_06f1:
							break;
						}
						continue;
						end_IL_0701:
						break;
					}
					continue;
					end_IL_071a:
					break;
				}
				continue;
				end_IL_072a:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_1)
	{
		int num = 102;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					IL_08b7:
					num = 122;
					while (true)
					{
						IL_089e:
						byte[] array = new byte[3];
						num = 22;
						while (true)
						{
							IL_088e:
							object[] array2 = new object[3];
							while (true)
							{
								IL_087e:
								int[] array3 = new int[4];
								while (true)
								{
									IL_086e:
									long[] array4 = new long[3];
									while (true)
									{
										IL_0859:
										array3[0] = int_1;
										while (true)
										{
											IL_084e:
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getDateStartDESCKINDMAX.POLICYCREATESECRETProviderDefined);
											while (true)
											{
												IL_0844:
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0374:
															byte b = *ptr2;
															while (true)
															{
																IL_0364:
																ptr2++;
																while (true)
																{
																	IL_0354:
																	if (b >= 1)
																	{
																		while (b <= 14)
																		{
																			while (true)
																			{
																				IL_0334:
																				if (7 >= b)
																				{
																					while (true)
																					{
																						IL_0324:
																						if (7 > b)
																						{
																							while (true)
																							{
																								IL_0317:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0307:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_02f7:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														while (2 <= b)
																														{
																															while (true)
																															{
																																IL_02a3:
																																ref int reference = ref array3[*(int*)(ptr2 + num3)];
																																reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																																num = 100;
																																while (true)
																																{
																																	IL_0293:
																																	ptr2 += 8;
																																	while (true)
																																	{
																																		IL_027a:
																																		num5--;
																																		num = 150;
																																		while (num != 150)
																																		{
																																			if (num != 1131)
																																			{
																																				goto end_IL_0831;
																																			}
																																			switch (num)
																																			{
																																			case 46:
																																				goto IL_027a;
																																			case 100:
																																				goto IL_0293;
																																			case 91:
																																			case 113:
																																				goto IL_02a3;
																																			case 109:
																																				goto IL_02d7;
																																			case 59:
																																			case 74:
																																				goto IL_02e7;
																																			case 69:
																																				goto IL_02f7;
																																			case 0:
																																				goto IL_0307;
																																			case 88:
																																			case 104:
																																				goto IL_0317;
																																			case 54:
																																				goto IL_0324;
																																			case 10:
																																				goto IL_0334;
																																			case 120:
																																				goto IL_0344;
																																			case 18:
																																				goto IL_0354;
																																			case 8:
																																				goto IL_0364;
																																			case 108:
																																			case 123:
																																				goto IL_0374;
																																			case 60:
																																			case 81:
																																				goto IL_037f;
																																			case 103:
																																				goto IL_038d;
																																			case 26:
																																			case 33:
																																				goto IL_0398;
																																			case 112:
																																			case 114:
																																				goto IL_03a8;
																																			case 28:
																																			case 117:
																																				goto IL_03b8;
																																			case 131:
																																				goto IL_03d0;
																																			case 135:
																																				goto IL_03e3;
																																			case 97:
																																				goto IL_0406;
																																			case 16:
																																				goto IL_0410;
																																			case 43:
																																				goto IL_041e;
																																			case 119:
																																			case 140:
																																				goto IL_0431;
																																			case 129:
																																				goto IL_043f;
																																			case 24:
																																			case 138:
																																				goto IL_044d;
																																			case 37:
																																				goto IL_048d;
																																			case 64:
																																				goto IL_04a1;
																																			case 50:
																																				goto IL_04b4;
																																			case 105:
																																			case 130:
																																				goto IL_04c2;
																																			case 53:
																																				goto IL_04db;
																																			case 57:
																																				goto IL_04e9;
																																			case 49:
																																				goto IL_04f7;
																																			case 62:
																																			case 133:
																																				goto IL_050a;
																																			case 13:
																																				goto IL_0553;
																																			case 2:
																																				goto IL_0567;
																																			case 132:
																																				goto IL_057a;
																																			case 3:
																																			case 73:
																																				goto IL_0588;
																																			case 5:
																																			case 14:
																																				goto IL_0593;
																																			case 38:
																																				goto IL_05a1;
																																			case 21:
																																				goto IL_05b4;
																																			case 19:
																																			case 106:
																																				goto IL_05bf;
																																			case 136:
																																				goto IL_05db;
																																			case 20:
																																				goto IL_05e9;
																																			case 71:
																																			case 143:
																																				goto IL_05f7;
																																			case 29:
																																				goto IL_0613;
																																			case 32:
																																				goto IL_0621;
																																			case 82:
																																				goto IL_062f;
																																			case 70:
																																			case 127:
																																				goto IL_0646;
																																			case 48:
																																				goto IL_0654;
																																			case 77:
																																			case 137:
																																				goto IL_0662;
																																			case 36:
																																				goto IL_0685;
																																			case 94:
																																				goto IL_069c;
																																			case 98:
																																				goto IL_06aa;
																																			case 80:
																																			case 142:
																																				goto IL_06bd;
																																			case 139:
																																				goto IL_071f;
																																			case 58:
																																				goto IL_0732;
																																			case 93:
																																				goto IL_0740;
																																			case 35:
																																			case 65:
																																				goto IL_074e;
																																			case 79:
																																				goto IL_078e;
																																			case 23:
																																				goto IL_07a2;
																																			case 7:
																																			case 45:
																																				goto IL_07b2;
																																			case 75:
																																				goto IL_07c6;
																																			case 116:
																																				goto IL_080e;
																																			case 1:
																																			case 6:
																																			case 11:
																																			case 12:
																																			case 15:
																																			case 17:
																																			case 25:
																																			case 30:
																																			case 34:
																																			case 40:
																																			case 42:
																																			case 44:
																																			case 55:
																																			case 56:
																																			case 63:
																																			case 68:
																																			case 72:
																																			case 76:
																																			case 84:
																																			case 87:
																																			case 90:
																																			case 95:
																																			case 96:
																																			case 110:
																																			case 118:
																																			case 121:
																																			case 125:
																																			case 128:
																																			case 134:
																																				goto end_IL_02d7;
																																			case 4:
																																			case 9:
																																			case 27:
																																			case 31:
																																			case 39:
																																			case 47:
																																			case 51:
																																			case 78:
																																			case 83:
																																			case 85:
																																			case 92:
																																			case 99:
																																			case 107:
																																			case 115:
																																			case 124:
																																			case 126:
																																				goto end_IL_0267;
																																			case 66:
																																				goto IL_0844;
																																			case 141:
																																				goto IL_084e;
																																			case 89:
																																				goto IL_0859;
																																			case 52:
																																				goto IL_086e;
																																			case 41:
																																			case 86:
																																				goto IL_087e;
																																			case 22:
																																				goto IL_088e;
																																			case 122:
																																				goto IL_089e;
																																			case 61:
																																				goto IL_08b7;
																																			case 101:
																																				goto end_IL_0831;
																																			case 102:
																																				goto end_IL_08c2;
																																			case 67:
																																			case 111:
																																				goto IL_08dd;
																																			}
																																			continue;
																																			end_IL_0267:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															goto end_IL_0354;
																															continue;
																															end_IL_02d7:
																															break;
																															IL_02d7:;
																														}
																														break;
																														IL_02e7:;
																													}
																													break;
																												}
																												goto IL_04b4;
																												IL_04f7:
																												ptr2 += 8;
																												goto end_IL_0354;
																												IL_04b4:
																												if (1 > b)
																												{
																													break;
																												}
																												goto IL_04c2;
																												IL_04c2:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																												goto IL_04db;
																												IL_04db:
																												array[num5] = 0;
																												goto IL_04e9;
																												IL_04e9:
																												num5++;
																												goto IL_04f7;
																											}
																											break;
																										}
																										goto IL_03b8;
																										IL_03b8:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_0354;
																									}
																									break;
																								}
																								goto IL_037f;
																								IL_04a1:
																								num5--;
																								goto end_IL_0354;
																								IL_037f:
																								if (5 >= b)
																								{
																									goto IL_038d;
																								}
																								goto IL_0431;
																								IL_038d:
																								if (5 > b)
																								{
																									goto IL_0398;
																								}
																								goto IL_03a8;
																								IL_0398:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_03d0;
																								IL_03d0:
																								if (4 <= b)
																								{
																									goto end_IL_0354;
																								}
																								break;
																								IL_03a8:
																								array[num5] = 0;
																								goto IL_03e3;
																								IL_03e3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_0406;
																								IL_0406:
																								array2[num5] = null;
																								goto IL_0410;
																								IL_0410:
																								num5++;
																								goto IL_041e;
																								IL_041e:
																								ptr2 += 8;
																								goto end_IL_0354;
																								IL_0431:
																								if (6 < b)
																								{
																									break;
																								}
																								goto IL_043f;
																								IL_043f:
																								if (6 > b)
																								{
																									break;
																								}
																								goto IL_044d;
																								IL_044d:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_048d;
																								IL_048d:
																								array[num5 - 2] = 0;
																								goto IL_04a1;
																							}
																							break;
																						}
																						goto IL_050a;
																						IL_0567:
																						num5--;
																						goto end_IL_0354;
																						IL_050a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 13;
																						goto IL_0553;
																						IL_0553:
																						array[num5 - 2] = 0;
																						goto IL_0567;
																					}
																					break;
																				}
																				goto IL_057a;
																				IL_07c6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = ((delegate*<int, int>)DebuggerStepperBoundaryAttributeEventSourceOptions[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																				num = 116;
																				goto IL_080e;
																				IL_057a:
																				if (11 < b)
																				{
																					goto IL_0588;
																				}
																				goto IL_0613;
																				IL_0588:
																				if (13 < b)
																				{
																					goto IL_0593;
																				}
																				goto IL_05b4;
																				IL_0593:
																				if (14 < b)
																				{
																					break;
																				}
																				goto IL_05a1;
																				IL_05a1:
																				if (14 <= b)
																				{
																				}
																				break;
																				IL_05b4:
																				if (13 <= b)
																				{
																					goto IL_05bf;
																				}
																				goto IL_05db;
																				IL_05bf:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0354;
																				IL_05db:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_05e9;
																				IL_05e9:
																				if (12 > b)
																				{
																					break;
																				}
																				goto IL_05f7;
																				IL_05f7:
																				num5--;
																				num = 126;
																				goto end_IL_0354;
																				IL_0613:
																				if (11 > b)
																				{
																					goto IL_0621;
																				}
																				goto IL_07b2;
																				IL_0621:
																				if (9 >= b)
																				{
																					goto IL_062f;
																				}
																				goto IL_0732;
																				IL_062f:
																				if (9 > b)
																				{
																					num = 127;
																					goto IL_0646;
																				}
																				goto IL_06bd;
																				IL_080e:
																				ptr2 += 8;
																				goto end_IL_0354;
																				IL_0646:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_0654;
																				IL_0654:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0662;
																				IL_0662:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0685;
																				IL_0685:
																				array[num5] = 0;
																				num = 94;
																				goto IL_069c;
																				IL_069c:
																				num5++;
																				goto IL_06aa;
																				IL_06aa:
																				ptr2 += 8;
																				goto end_IL_0354;
																				IL_06bd:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_071f;
																				IL_071f:
																				num5 -= 2;
																				goto end_IL_0354;
																				IL_0732:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0740;
																				IL_0740:
																				if (10 > b)
																				{
																					break;
																				}
																				goto IL_074e;
																				IL_074e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_078e;
																				IL_078e:
																				array[num5 - 2] = 0;
																				goto IL_07a2;
																				IL_07a2:
																				num5--;
																				goto end_IL_0354;
																				IL_07b2:
																				array[num5 - 1] = 0;
																				goto IL_07c6;
																			}
																			break;
																			IL_0344:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0354:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_08dd;
													IL_08dd:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0831:
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
				continue;
				end_IL_08c2:
				break;
			}
		}
	}

	private unsafe static int smethod_6(int int_1)
	{
		int num = 42;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2 = 1;
			num = 41;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRuntimePropertygetURL.GetReferencedAssembliesgetParameters);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0274:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0257:
																			if (6 < b)
																			{
																				while (true)
																				{
																					IL_0247:
																					if (9 < b)
																					{
																						while (true)
																						{
																							IL_0237:
																							if (10 < b)
																							{
																								while (11 >= b)
																								{
																									while (11 <= b)
																									{
																										num = 121;
																										while (num != 121)
																										{
																											if (num != 1102)
																											{
																												goto end_IL_0274;
																											}
																											switch (num)
																											{
																											case 99:
																												goto IL_0214;
																											case 4:
																											case 77:
																												goto IL_0227;
																											case 90:
																												goto IL_0237;
																											case 100:
																												goto IL_0247;
																											case 44:
																												goto IL_0257;
																											case 87:
																												goto IL_0264;
																											case 58:
																												goto IL_0274;
																											case 55:
																												goto end_IL_0274;
																											case 45:
																											case 57:
																												goto end_IL_0284;
																											case 85:
																												goto IL_029f;
																											case 49:
																											case 66:
																												goto IL_02ad;
																											case 91:
																												goto IL_02f2;
																											case 23:
																											case 53:
																												goto IL_02fd;
																											case 5:
																												goto IL_035f;
																											case 95:
																												goto IL_0372;
																											case 86:
																												goto IL_037d;
																											case 104:
																												goto IL_038b;
																											case 30:
																											case 54:
																												goto IL_0399;
																											case 10:
																												goto IL_03bc;
																											case 94:
																												goto IL_03ca;
																											case 51:
																												goto IL_03d8;
																											case 105:
																												goto IL_03eb;
																											case 56:
																											case 65:
																												goto IL_03f9;
																											case 33:
																												goto IL_0439;
																											case 75:
																												goto IL_044d;
																											case 3:
																											case 107:
																												goto IL_0460;
																											case 93:
																												goto IL_046e;
																											case 11:
																											case 28:
																												goto IL_0479;
																											case 8:
																												goto IL_0491;
																											case 61:
																												goto IL_049c;
																											case 25:
																											case 43:
																												goto IL_04af;
																											case 13:
																												goto IL_04bd;
																											case 70:
																											case 92:
																												goto IL_04cb;
																											case 16:
																												goto IL_04f4;
																											case 80:
																												goto IL_0502;
																											case 109:
																												goto IL_0515;
																											case 20:
																												goto IL_0529;
																											case 96:
																											case 111:
																												goto IL_053c;
																											case 19:
																												goto IL_0555;
																											case 39:
																												goto IL_0563;
																											case 9:
																												goto IL_0571;
																											case 103:
																											case 112:
																												goto IL_0584;
																											case 78:
																												goto IL_058f;
																											case 46:
																											case 113:
																												goto IL_05a2;
																											case 27:
																												goto IL_05b0;
																											case 72:
																											case 110:
																												goto IL_05bb;
																											case 63:
																												goto IL_05c9;
																											case 24:
																												goto IL_05ec;
																											case 26:
																												goto IL_05f6;
																											case 18:
																												goto IL_0604;
																											case 69:
																												goto IL_061f;
																											case 68:
																											case 97:
																												goto IL_062a;
																											case 0:
																											case 6:
																											case 7:
																											case 12:
																											case 14:
																											case 21:
																											case 22:
																											case 29:
																											case 34:
																											case 35:
																											case 59:
																											case 60:
																											case 62:
																											case 64:
																											case 67:
																											case 76:
																											case 81:
																											case 84:
																											case 88:
																											case 89:
																											case 98:
																												goto end_IL_0201;
																											case 1:
																											case 2:
																											case 17:
																											case 36:
																											case 37:
																											case 38:
																											case 52:
																											case 71:
																											case 73:
																											case 74:
																											case 83:
																											case 101:
																											case 102:
																											case 106:
																												goto end_IL_0294;
																											case 47:
																												goto end_IL_0656;
																											case 32:
																												goto end_IL_0669;
																											case 79:
																												goto end_IL_0673;
																											case 31:
																												goto end_IL_067e;
																											case 40:
																											case 82:
																												goto end_IL_0693;
																											case 114:
																												goto end_IL_06a3;
																											case 15:
																											case 108:
																												goto end_IL_06b3;
																											case 41:
																												goto end_IL_06c3;
																											case 42:
																												goto end_IL_06d3;
																											case 48:
																											case 50:
																												goto IL_06f7;
																											}
																											continue;
																											end_IL_0201:
																											break;
																										}
																										break;
																										IL_0214:;
																									}
																									break;
																									IL_0227:;
																								}
																								break;
																							}
																							goto IL_061f;
																							IL_062a:
																							byte* num5 = ptr2;
																							num4 = 1;
																							ptr2 = num5 + -200;
																							goto end_IL_0294;
																							IL_061f:
																							if (10 > b)
																							{
																								break;
																							}
																							goto IL_062a;
																						}
																						break;
																					}
																					goto IL_02f2;
																					IL_044d:
																					num6--;
																					goto end_IL_0294;
																					IL_02f2:
																					if (9 <= b)
																					{
																						goto IL_02fd;
																					}
																					goto IL_0372;
																					IL_02fd:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_035f;
																					IL_035f:
																					num6 -= 2;
																					goto end_IL_0294;
																					IL_0372:
																					if (7 < b)
																					{
																						goto IL_037d;
																					}
																					goto IL_03eb;
																					IL_037d:
																					if (8 < b)
																					{
																						break;
																					}
																					goto IL_038b;
																					IL_038b:
																					if (8 > b)
																					{
																						break;
																					}
																					goto IL_0399;
																					IL_0399:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_03bc;
																					IL_03bc:
																					array[num6] = 0;
																					goto IL_03ca;
																					IL_03ca:
																					num6++;
																					goto IL_03d8;
																					IL_03d8:
																					ptr2 += 8;
																					goto end_IL_0294;
																					IL_03eb:
																					if (7 > b)
																					{
																						break;
																					}
																					goto IL_03f9;
																					IL_03f9:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																					goto IL_0439;
																					IL_0439:
																					array[num6 - 2] = 0;
																					goto IL_044d;
																				}
																				break;
																			}
																			goto IL_029f;
																			IL_0604:
																			ptr2 += 8;
																			goto end_IL_0294;
																			IL_029f:
																			if (6 <= b)
																			{
																				goto IL_02ad;
																			}
																			goto IL_0460;
																			IL_02ad:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_0515;
																			IL_0515:
																			array[num6 - 2] = 0;
																			goto IL_0529;
																			IL_0529:
																			num6--;
																			goto end_IL_0294;
																			IL_0460:
																			if (3 >= b)
																			{
																				goto IL_046e;
																			}
																			goto IL_0584;
																			IL_046e:
																			if (3 <= b)
																			{
																				goto IL_0479;
																			}
																			goto IL_0491;
																			IL_0479:
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_0294;
																			IL_0491:
																			if (1 >= b)
																			{
																				goto IL_049c;
																			}
																			goto IL_04af;
																			IL_049c:
																			if (1 > b)
																			{
																				break;
																			}
																			goto IL_053c;
																			IL_053c:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																			goto IL_0555;
																			IL_0555:
																			array[num6] = 0;
																			goto IL_0563;
																			IL_0563:
																			num6++;
																			goto IL_0571;
																			IL_0571:
																			ptr2 += 8;
																			goto end_IL_0294;
																			IL_04af:
																			if (2 < b)
																			{
																				break;
																			}
																			goto IL_04bd;
																			IL_04bd:
																			if (2 > b)
																			{
																				break;
																			}
																			goto IL_04cb;
																			IL_04cb:
																			ref int reference = ref array3[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																			goto IL_04f4;
																			IL_04f4:
																			ptr2 += 8;
																			goto IL_0502;
																			IL_0502:
																			num6--;
																			goto end_IL_0294;
																			IL_0584:
																			if (4 >= b)
																			{
																				goto IL_058f;
																			}
																			goto IL_05a2;
																			IL_058f:
																			if (4 > b)
																			{
																				break;
																			}
																			goto end_IL_0294;
																			IL_05a2:
																			if (5 < b)
																			{
																				break;
																			}
																			goto IL_05b0;
																			IL_05b0:
																			if (5 > b)
																			{
																				num = 34;
																				break;
																			}
																			goto IL_05bb;
																			IL_05bb:
																			array[num6] = 0;
																			goto IL_05c9;
																			IL_05c9:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_05ec;
																			IL_05ec:
																			array2[num6] = null;
																			goto IL_05f6;
																			IL_05f6:
																			num6++;
																			goto IL_0604;
																		}
																		break;
																		IL_0264:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_0294;
																continue;
																end_IL_0274:
																break;
															}
															continue;
															end_IL_0284:
															break;
														}
														continue;
														end_IL_0294:
														break;
													}
													continue;
												}
												goto IL_06f7;
												IL_06f7:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
												continue;
												end_IL_0656:
												break;
											}
											continue;
											end_IL_0669:
											break;
										}
										continue;
										end_IL_0673:
										break;
									}
									continue;
									end_IL_067e:
									break;
								}
								continue;
								end_IL_0693:
								break;
							}
							continue;
							end_IL_06a3:
							break;
						}
						continue;
						end_IL_06b3:
						break;
					}
					continue;
					end_IL_06c3:
					break;
				}
				continue;
				end_IL_06d3:
				break;
			}
		}
	}

	private unsafe static int smethod_7(int int_1)
	{
		int num = 72;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref WaitForFullGCCompletegetSecond.CustomPropertyImplgetUrl);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												num = 61;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_027b:
															byte b = *ptr2;
															num = 9;
															while (true)
															{
																IL_026b:
																ptr2++;
																while (true)
																{
																	IL_025b:
																	if (b >= 1)
																	{
																		while (b <= 10)
																		{
																			while (true)
																			{
																				IL_023b:
																				if (5 >= b)
																				{
																					while (true)
																					{
																						IL_022b:
																						if (5 > b)
																						{
																							while (true)
																							{
																								IL_021b:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_020b:
																										if (2 > b)
																										{
																											while (1 >= b)
																											{
																												while (true)
																												{
																													IL_01e8:
																													if (1 > b)
																													{
																														num = 110;
																														while (num != 110)
																														{
																															if (num != 1091)
																															{
																																goto end_IL_025b;
																															}
																															switch (num)
																															{
																															case 21:
																																goto IL_01e8;
																															case 75:
																															case 90:
																																goto IL_01fb;
																															case 78:
																																goto IL_020b;
																															case 50:
																															case 91:
																																goto IL_021b;
																															case 55:
																																goto IL_022b;
																															case 87:
																																goto IL_023b;
																															case 99:
																																goto IL_024b;
																															case 58:
																																goto IL_025b;
																															case 9:
																																goto IL_026b;
																															case 26:
																															case 27:
																																goto IL_027b;
																															case 5:
																															case 84:
																																goto IL_028f;
																															case 93:
																																goto IL_02a8;
																															case 34:
																																goto IL_02b6;
																															case 100:
																																goto IL_02c4;
																															case 35:
																															case 46:
																																goto IL_02d7;
																															case 44:
																																goto IL_0309;
																															case 68:
																																goto IL_0317;
																															case 19:
																																goto IL_032a;
																															case 11:
																																goto IL_0335;
																															case 85:
																															case 86:
																																goto IL_0343;
																															case 69:
																																goto IL_035b;
																															case 22:
																																goto IL_0369;
																															case 24:
																															case 64:
																																goto IL_037c;
																															case 77:
																																goto IL_038a;
																															case 80:
																																goto IL_03ad;
																															case 95:
																																goto IL_03b7;
																															case 73:
																																goto IL_03c5;
																															case 62:
																																goto IL_03d8;
																															case 2:
																																goto IL_03e6;
																															case 65:
																															case 96:
																																goto IL_03f1;
																															case 17:
																																goto IL_0453;
																															case 7:
																																goto IL_0466;
																															case 13:
																																goto IL_0471;
																															case 51:
																															case 74:
																																goto IL_047f;
																															case 70:
																																goto IL_04bf;
																															case 41:
																																goto IL_04d3;
																															case 45:
																																goto IL_04ef;
																															case 30:
																																goto IL_04fa;
																															case 38:
																															case 56:
																																goto IL_0508;
																															case 33:
																																goto IL_052b;
																															case 54:
																																goto IL_0539;
																															case 101:
																																goto IL_0547;
																															case 8:
																																goto IL_0562;
																															case 32:
																																goto IL_056d;
																															case 63:
																															case 83:
																																goto IL_0578;
																															case 102:
																																goto IL_059a;
																															case 67:
																																goto IL_05a5;
																															case 1:
																															case 4:
																															case 12:
																															case 14:
																															case 16:
																															case 28:
																															case 29:
																															case 31:
																															case 36:
																															case 40:
																															case 48:
																															case 52:
																															case 53:
																															case 60:
																															case 76:
																															case 79:
																															case 88:
																															case 89:
																															case 94:
																															case 97:
																																goto end_IL_01d5;
																															case 0:
																															case 10:
																															case 18:
																															case 23:
																															case 25:
																															case 37:
																															case 43:
																															case 47:
																															case 61:
																															case 82:
																															case 92:
																															case 98:
																																goto end_IL_025b;
																															case 66:
																																goto end_IL_05cc;
																															case 6:
																																goto end_IL_05df;
																															case 59:
																																goto end_IL_05ea;
																															case 49:
																																goto end_IL_05f4;
																															case 42:
																																goto end_IL_05ff;
																															case 15:
																															case 57:
																																goto end_IL_0614;
																															case 3:
																																goto end_IL_0624;
																															case 81:
																															case 103:
																																goto end_IL_0634;
																															case 71:
																																goto end_IL_0644;
																															case 72:
																																goto end_IL_0654;
																															case 20:
																															case 39:
																																goto IL_066f;
																															}
																															continue;
																															end_IL_01d5:
																															break;
																														}
																														break;
																													}
																													goto IL_028f;
																													IL_02b6:
																													num5++;
																													goto IL_02c4;
																													IL_02c4:
																													ptr2 += 8;
																													goto end_IL_025b;
																													IL_028f:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_02a8;
																													IL_02a8:
																													array[num5] = 0;
																													goto IL_02b6;
																												}
																												break;
																												IL_01fb:;
																											}
																											break;
																										}
																										goto IL_02d7;
																										IL_0317:
																										num5--;
																										goto end_IL_025b;
																										IL_02d7:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										num = 44;
																										goto IL_0309;
																										IL_0309:
																										ptr2 += 8;
																										goto IL_0317;
																									}
																									break;
																								}
																								goto IL_032a;
																								IL_0369:
																								if (4 <= b)
																								{
																									goto end_IL_025b;
																								}
																								break;
																								IL_032a:
																								if (3 >= b)
																								{
																									goto IL_0335;
																								}
																								goto IL_035b;
																								IL_0335:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0343;
																								IL_0343:
																								ptr2 = ptr + *(int*)(ptr2 + num3);
																								goto end_IL_025b;
																								IL_035b:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0369;
																							}
																							break;
																						}
																						goto IL_037c;
																						IL_03c5:
																						ptr2 += 8;
																						goto end_IL_025b;
																						IL_037c:
																						array[num5] = 0;
																						goto IL_038a;
																						IL_038a:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_03ad;
																						IL_03ad:
																						array2[num5] = null;
																						goto IL_03b7;
																						IL_03b7:
																						num5++;
																						goto IL_03c5;
																					}
																					break;
																				}
																				goto IL_03d8;
																				IL_059a:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_05a5;
																				IL_03d8:
																				if (8 >= b)
																				{
																					goto IL_03e6;
																				}
																				goto IL_0562;
																				IL_03e6:
																				if (8 <= b)
																				{
																					goto IL_03f1;
																				}
																				goto IL_0466;
																				IL_03f1:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0453;
																				IL_0453:
																				num5 -= 2;
																				goto end_IL_025b;
																				IL_0466:
																				if (6 >= b)
																				{
																					goto IL_0471;
																				}
																				goto IL_04ef;
																				IL_0471:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_047f;
																				IL_047f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04bf;
																				IL_04bf:
																				array[num5 - 2] = 0;
																				goto IL_04d3;
																				IL_04d3:
																				num5--;
																				num = 98;
																				goto end_IL_025b;
																				IL_04ef:
																				if (7 < b)
																				{
																					num = 29;
																					break;
																				}
																				goto IL_04fa;
																				IL_04fa:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0508;
																				IL_0508:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_052b;
																				IL_052b:
																				array[num5] = 0;
																				goto IL_0539;
																				IL_0539:
																				num5++;
																				goto IL_0547;
																				IL_0547:
																				ptr2 += 8;
																				goto end_IL_025b;
																				IL_05a5:
																				if (10 <= b)
																				{
																					num = 88;
																				}
																				break;
																				IL_0562:
																				if (9 >= b)
																				{
																					goto IL_056d;
																				}
																				goto IL_059a;
																				IL_056d:
																				if (9 > b)
																				{
																					break;
																				}
																				goto IL_0578;
																				IL_0578:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				num = 47;
																				goto end_IL_025b;
																			}
																			break;
																			IL_024b:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_025b:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_066f;
													IL_066f:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_05cc:
													break;
												}
												continue;
												end_IL_05df:
												break;
											}
											continue;
											end_IL_05ea:
											break;
										}
										continue;
										end_IL_05f4:
										break;
									}
									continue;
									end_IL_05ff:
									break;
								}
								continue;
								end_IL_0614:
								break;
							}
							continue;
							end_IL_0624:
							break;
						}
						continue;
						end_IL_0634:
						break;
					}
					continue;
					end_IL_0644:
					break;
				}
				continue;
				end_IL_0654:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_1)
	{
		int num = 114;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetChannelDataHidden.BinderStateNumberFormat);
										while (true)
										{
											byte* ptr2 = ptr;
											num = 24;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0288:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_026b:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_025b:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_024b:
																							if (3 >= b)
																							{
																								while (true)
																								{
																									IL_023b:
																									if (3 > b)
																									{
																										while (true)
																										{
																											IL_022b:
																											if (1 >= b)
																											{
																												while (true)
																												{
																													IL_0218:
																													if (1 > b)
																													{
																														num = 122;
																														while (num != 122 && num == 1103)
																														{
																															switch (num)
																															{
																															case 104:
																																goto IL_0218;
																															case 36:
																																goto IL_022b;
																															case 64:
																																goto IL_023b;
																															case 25:
																															case 92:
																																goto IL_024b;
																															case 37:
																																goto IL_025b;
																															case 26:
																																goto IL_026b;
																															case 14:
																																goto IL_0278;
																															case 15:
																																goto IL_0288;
																															case 11:
																																goto end_IL_0288;
																															case 13:
																															case 87:
																																goto end_IL_0298;
																															case 5:
																															case 18:
																																goto IL_02b3;
																															case 33:
																															case 44:
																																goto IL_02d1;
																															case 17:
																															case 68:
																																goto IL_02e9;
																															case 28:
																																goto IL_02f7;
																															case 9:
																															case 60:
																																goto IL_0302;
																															case 8:
																																goto IL_0310;
																															case 46:
																															case 73:
																																goto IL_0327;
																															case 40:
																																goto IL_0367;
																															case 50:
																															case 84:
																																goto IL_0380;
																															case 74:
																																goto IL_03e2;
																															case 58:
																															case 91:
																																goto IL_03f5;
																															case 57:
																																goto IL_0403;
																															case 83:
																															case 93:
																																goto IL_0416;
																															case 48:
																																goto IL_0421;
																															case 47:
																																goto IL_042f;
																															case 76:
																															case 80:
																																goto IL_043d;
																															case 51:
																																goto IL_044b;
																															case 4:
																																goto IL_047c;
																															case 0:
																															case 99:
																																goto IL_048f;
																															case 35:
																																goto IL_049a;
																															case 45:
																															case 85:
																																goto IL_04a8;
																															case 30:
																															case 81:
																																goto IL_04cd;
																															case 56:
																																goto IL_04db;
																															case 100:
																																goto IL_04ee;
																															case 53:
																																goto IL_04fc;
																															case 61:
																																goto IL_050a;
																															case 109:
																																goto IL_051d;
																															case 103:
																															case 110:
																																goto IL_0530;
																															case 101:
																																goto IL_0553;
																															case 32:
																																goto IL_0561;
																															case 89:
																																goto IL_056f;
																															case 115:
																																goto IL_0582;
																															case 55:
																																goto IL_058c;
																															case 72:
																																goto IL_059a;
																															case 31:
																															case 108:
																																goto IL_05ad;
																															case 105:
																																goto IL_05bb;
																															case 6:
																															case 34:
																																goto IL_05d2;
																															case 77:
																																goto IL_0604;
																															case 10:
																																goto IL_0612;
																															case 86:
																															case 88:
																																goto IL_0625;
																															case 70:
																																goto IL_0665;
																															case 107:
																																goto IL_0682;
																															case 1:
																															case 2:
																															case 3:
																															case 12:
																															case 20:
																															case 21:
																															case 38:
																															case 41:
																															case 43:
																															case 59:
																															case 65:
																															case 66:
																															case 67:
																															case 69:
																															case 95:
																															case 97:
																															case 98:
																															case 106:
																															case 111:
																																goto end_IL_0205;
																															case 7:
																															case 19:
																															case 22:
																															case 24:
																															case 27:
																															case 29:
																															case 42:
																															case 52:
																															case 63:
																															case 75:
																															case 78:
																															case 79:
																															case 82:
																															case 96:
																																goto end_IL_02a8;
																															case 90:
																																goto end_IL_06a5;
																															case 102:
																																goto end_IL_06b8;
																															case 94:
																																goto end_IL_06cb;
																															case 39:
																																goto end_IL_06d6;
																															case 16:
																															case 54:
																																goto end_IL_06eb;
																															case 49:
																																goto end_IL_06fb;
																															case 71:
																															case 112:
																																goto end_IL_070b;
																															case 113:
																																goto end_IL_071b;
																															case 114:
																																goto end_IL_072b;
																															case 23:
																															case 62:
																																goto IL_0746;
																															}
																															continue;
																															end_IL_0205:
																															break;
																														}
																														break;
																													}
																													goto IL_02b3;
																													IL_04fc:
																													num5++;
																													goto IL_050a;
																													IL_050a:
																													ptr2 += 8;
																													goto end_IL_02a8;
																													IL_02b3:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																													goto IL_04ee;
																													IL_04ee:
																													array[num5] = 0;
																													goto IL_04fc;
																												}
																												break;
																											}
																											goto IL_05ad;
																											IL_0604:
																											ptr2 += 8;
																											goto IL_0612;
																											IL_05ad:
																											if (2 < b)
																											{
																												break;
																											}
																											goto IL_05bb;
																											IL_05bb:
																											if (2 > b)
																											{
																												break;
																											}
																											num = 6;
																											goto IL_05d2;
																											IL_0612:
																											num5--;
																											goto end_IL_02a8;
																											IL_05d2:
																											ref int reference = ref array3[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																											num = 77;
																											goto IL_0604;
																										}
																										break;
																									}
																									goto IL_02d1;
																									IL_02d1:
																									ptr2 = ptr + *(int*)(ptr2 + num3);
																									goto end_IL_02a8;
																								}
																								break;
																							}
																							goto IL_0416;
																							IL_047c:
																							if (4 > b)
																							{
																								break;
																							}
																							goto end_IL_02a8;
																							IL_0416:
																							if (4 < b)
																							{
																								goto IL_0421;
																							}
																							num = 4;
																							goto IL_047c;
																							IL_0421:
																							if (5 < b)
																							{
																								break;
																							}
																							goto IL_042f;
																							IL_042f:
																							if (5 > b)
																							{
																								break;
																							}
																							goto IL_043d;
																							IL_043d:
																							array[num5] = 0;
																							goto IL_044b;
																							IL_044b:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																							goto IL_0582;
																							IL_0582:
																							array2[num5] = null;
																							goto IL_058c;
																							IL_058c:
																							num5++;
																							goto IL_059a;
																							IL_059a:
																							ptr2 += 8;
																							goto end_IL_02a8;
																						}
																						break;
																					}
																					goto IL_0625;
																					IL_0682:
																					num5--;
																					goto end_IL_02a8;
																					IL_0625:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0665;
																					IL_0665:
																					array[num5 - 2] = 0;
																					num = 107;
																					goto IL_0682;
																				}
																				break;
																			}
																			goto IL_02e9;
																			IL_04db:
																			if (11 <= b)
																			{
																			}
																			break;
																			IL_02e9:
																			if (9 >= b)
																			{
																				goto IL_02f7;
																			}
																			goto IL_048f;
																			IL_02f7:
																			if (9 > b)
																			{
																				goto IL_0302;
																			}
																			goto IL_0380;
																			IL_0302:
																			if (7 >= b)
																			{
																				goto IL_0310;
																			}
																			goto IL_03f5;
																			IL_0310:
																			if (7 > b)
																			{
																				break;
																			}
																			num = 46;
																			goto IL_0327;
																			IL_04cd:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_04db;
																			IL_0327:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_0367;
																			IL_0367:
																			array[num5 - 2] = 0;
																			goto IL_051d;
																			IL_051d:
																			num5--;
																			goto end_IL_02a8;
																			IL_03f5:
																			if (8 < b)
																			{
																				break;
																			}
																			goto IL_0403;
																			IL_0403:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_0530;
																			IL_0530:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0553;
																			IL_0553:
																			array[num5] = 0;
																			goto IL_0561;
																			IL_0561:
																			num5++;
																			goto IL_056f;
																			IL_056f:
																			ptr2 += 8;
																			goto end_IL_02a8;
																			IL_0380:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_03e2;
																			IL_03e2:
																			num5 -= 2;
																			goto end_IL_02a8;
																			IL_048f:
																			if (10 >= b)
																			{
																				goto IL_049a;
																			}
																			num = 30;
																			goto IL_04cd;
																			IL_049a:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_04a8;
																			IL_04a8:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02a8;
																		}
																		break;
																		IL_0278:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a8;
																continue;
																end_IL_0288:
																break;
															}
															continue;
															end_IL_0298:
															break;
														}
														continue;
														end_IL_02a8:
														break;
													}
													continue;
												}
												goto IL_0746;
												IL_0746:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_06a5:
												break;
											}
											continue;
											end_IL_06b8:
											break;
										}
										continue;
										end_IL_06cb:
										break;
									}
									continue;
									end_IL_06d6:
									break;
								}
								continue;
								end_IL_06eb:
								break;
							}
							continue;
							end_IL_06fb:
							break;
						}
						continue;
						end_IL_070b:
						break;
					}
					continue;
					end_IL_071b:
					break;
				}
				continue;
				end_IL_072b:
				break;
			}
		}
	}

	private unsafe static int smethod_9(int int_1)
	{
		int num = 30;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_1;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetRuntimeDirectoryTKINDCOCLASS.RectArraygetPropertyToken);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0229:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			IL_020c:
																			if (5 >= b)
																			{
																				while (true)
																				{
																					IL_01ff:
																					if (5 <= b)
																					{
																						while (true)
																						{
																							IL_01e6:
																							array[num5] = 0;
																							num = 113;
																							while (true)
																							{
																								if (num != 113)
																								{
																									if (num != 1094)
																									{
																										break;
																									}
																									switch (num)
																									{
																									case 5:
																									case 22:
																										goto IL_01e6;
																									case 96:
																										goto IL_01ff;
																									case 40:
																										goto IL_020c;
																									case 17:
																										goto IL_0219;
																									case 47:
																										goto IL_0229;
																									case 24:
																										goto end_IL_0229;
																									case 59:
																									case 93:
																										goto end_IL_0239;
																									case 26:
																									case 38:
																										goto IL_025f;
																									case 3:
																										goto IL_026a;
																									case 25:
																									case 28:
																										goto IL_0275;
																									case 14:
																										goto IL_0288;
																									case 39:
																										goto IL_029b;
																									case 51:
																										goto IL_02a9;
																									case 15:
																									case 52:
																										goto IL_02b6;
																									case 34:
																										goto IL_02c4;
																									case 0:
																									case 50:
																										goto IL_02d2;
																									case 10:
																									case 54:
																										goto IL_0300;
																									case 64:
																										goto IL_031c;
																									case 23:
																									case 37:
																										goto IL_032a;
																									case 67:
																										goto IL_0378;
																									case 45:
																									case 73:
																										goto IL_038b;
																									case 13:
																									case 82:
																										goto IL_03a7;
																									case 72:
																										goto IL_0412;
																									case 88:
																										goto IL_0425;
																									case 62:
																										goto IL_0439;
																									case 90:
																										goto IL_044c;
																									case 68:
																										goto IL_045a;
																									case 19:
																									case 97:
																										goto IL_046d;
																									case 9:
																										goto IL_0478;
																									case 56:
																									case 60:
																										goto IL_0486;
																									case 94:
																										goto IL_049e;
																									case 63:
																										goto IL_04a9;
																									case 101:
																										goto IL_04ca;
																									case 41:
																									case 103:
																										goto IL_04d8;
																									case 53:
																										goto IL_04fb;
																									case 35:
																										goto IL_0509;
																									case 75:
																										goto IL_0517;
																									case 104:
																										goto IL_052a;
																									case 61:
																										goto IL_0538;
																									case 58:
																									case 105:
																										goto IL_054b;
																									case 95:
																										goto IL_0564;
																									case 106:
																										goto IL_0572;
																									case 100:
																										goto IL_0580;
																									case 44:
																										goto IL_05b3;
																									case 7:
																										goto IL_05bd;
																									case 36:
																										goto IL_05cb;
																									case 1:
																									case 6:
																									case 12:
																									case 18:
																									case 20:
																									case 27:
																									case 32:
																									case 43:
																									case 49:
																									case 55:
																									case 76:
																									case 77:
																									case 78:
																									case 81:
																									case 83:
																									case 84:
																									case 86:
																									case 87:
																									case 91:
																									case 99:
																									case 102:
																										goto end_IL_01d3;
																									case 8:
																									case 16:
																									case 21:
																									case 31:
																									case 57:
																									case 65:
																									case 66:
																									case 69:
																									case 70:
																									case 71:
																									case 80:
																									case 92:
																									case 98:
																										goto end_IL_0249;
																									case 48:
																										goto end_IL_05f7;
																									case 46:
																										goto end_IL_060a;
																									case 89:
																										goto end_IL_0614;
																									case 33:
																										goto end_IL_061f;
																									case 2:
																									case 4:
																										goto end_IL_0634;
																									case 79:
																										goto end_IL_0644;
																									case 11:
																									case 74:
																										goto end_IL_0654;
																									case 29:
																										goto end_IL_0664;
																									case 30:
																										goto end_IL_0674;
																									case 42:
																									case 85:
																										goto IL_068f;
																									}
																									continue;
																								}
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																								goto IL_05b3;
																								IL_05b3:
																								array2[num5] = null;
																								goto IL_05bd;
																								IL_05cb:
																								ptr2 += 8;
																								goto end_IL_0249;
																								IL_05bd:
																								num5++;
																								goto IL_05cb;
																								continue;
																								end_IL_01d3:
																								break;
																							}
																							break;
																						}
																						break;
																					}
																					num = 15;
																					goto IL_02b6;
																					IL_049e:
																					if (4 < b)
																					{
																						num = 18;
																						break;
																					}
																					goto IL_04a9;
																					IL_04a9:
																					if (4 > b)
																					{
																						break;
																					}
																					goto end_IL_0249;
																					IL_02b6:
																					if (2 >= b)
																					{
																						goto IL_02c4;
																					}
																					goto IL_046d;
																					IL_02c4:
																					if (2 <= b)
																					{
																						goto IL_02d2;
																					}
																					goto IL_044c;
																					IL_02d2:
																					ref int reference = ref array3[*(int*)(ptr2 + num3)];
																					reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_052a;
																					IL_052a:
																					ptr2 += 8;
																					goto IL_0538;
																					IL_0538:
																					num5--;
																					goto end_IL_0249;
																					IL_044c:
																					if (1 < b)
																					{
																						break;
																					}
																					goto IL_045a;
																					IL_045a:
																					if (1 > b)
																					{
																						break;
																					}
																					goto IL_054b;
																					IL_054b:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																					goto IL_0564;
																					IL_0564:
																					array[num5] = 0;
																					goto IL_0572;
																					IL_0572:
																					num5++;
																					goto IL_0580;
																					IL_0580:
																					ptr2 += 8;
																					goto end_IL_0249;
																					IL_046d:
																					if (3 >= b)
																					{
																						goto IL_0478;
																					}
																					goto IL_049e;
																					IL_0478:
																					if (3 > b)
																					{
																						break;
																					}
																					goto IL_0486;
																					IL_0486:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_0249;
																				}
																				break;
																			}
																			goto IL_025f;
																			IL_03a7:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 72;
																			goto IL_0412;
																			IL_025f:
																			if (8 < b)
																			{
																				goto IL_026a;
																			}
																			goto IL_029b;
																			IL_026a:
																			if (9 < b)
																			{
																				goto IL_0275;
																			}
																			goto IL_0288;
																			IL_0275:
																			if (10 < b)
																			{
																				break;
																			}
																			goto IL_0378;
																			IL_0378:
																			if (10 <= b)
																			{
																			}
																			break;
																			IL_0288:
																			if (9 > b)
																			{
																				break;
																			}
																			goto IL_038b;
																			IL_038b:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_0249;
																			IL_029b:
																			if (8 > b)
																			{
																				goto IL_02a9;
																			}
																			goto IL_03a7;
																			IL_02a9:
																			if (6 < b)
																			{
																				goto IL_0300;
																			}
																			goto IL_031c;
																			IL_0300:
																			if (7 < b)
																			{
																				break;
																			}
																			num = 101;
																			goto IL_04ca;
																			IL_0412:
																			num5 -= 2;
																			goto end_IL_0249;
																			IL_04ca:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_04d8;
																			IL_04d8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_04fb;
																			IL_04fb:
																			array[num5] = 0;
																			goto IL_0509;
																			IL_0509:
																			num5++;
																			goto IL_0517;
																			IL_0517:
																			ptr2 += 8;
																			goto end_IL_0249;
																			IL_031c:
																			if (6 > b)
																			{
																				break;
																			}
																			goto IL_032a;
																			IL_032a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			num = 88;
																			goto IL_0425;
																			IL_0425:
																			array[num5 - 2] = 0;
																			goto IL_0439;
																			IL_0439:
																			num5--;
																			goto end_IL_0249;
																		}
																		break;
																		IL_0219:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																num = 80;
																goto end_IL_0249;
																continue;
																end_IL_0229:
																break;
															}
															continue;
															end_IL_0239:
															break;
														}
														continue;
														end_IL_0249:
														break;
													}
													continue;
												}
												goto IL_068f;
												IL_068f:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05f7:
												break;
											}
											continue;
											end_IL_060a:
											break;
										}
										continue;
										end_IL_0614:
										break;
									}
									continue;
									end_IL_061f:
									break;
								}
								continue;
								end_IL_0634:
								break;
							}
							continue;
							end_IL_0644:
							break;
						}
						continue;
						end_IL_0654:
						break;
					}
					continue;
					end_IL_0664:
					break;
				}
				continue;
				end_IL_0674:
				break;
			}
		}
	}
}
