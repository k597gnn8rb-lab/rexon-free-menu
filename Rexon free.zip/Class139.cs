using System;
using System.Runtime.CompilerServices;
using Rexon_Menu.Core.Attributes;
using Rexon_Menu.Interface;
using UnityEngine;

[Mod("Theme: Original", "Settings", "Click to cycle themes", false, 1, ModType.const_1, false)]
internal class Class139 : MonoBehaviour
{
	internal readonly struct ThemeData
	{
		public readonly string string_0;

		public readonly Color color_0;

		private static IntPtr[] VolumeSeparatorCharM;

		internal static object object_0;

		public unsafe ThemeData(string name, Color color)
		{
			Class296.Aw4EYyy3h();
			Class300.smethod_0();
			int num = 0;
			int num2 = 0;
			num2 = 0;
			int num3 = default(int);
			while (num2 != 2)
			{
				((delegate*<ref int, ref int, ref int, ref ThemeData, string, Color, void>)VolumeSeparatorCharM[num])(ref num, ref num2, ref num3, ref this, name, color);
			}
			num2 = 0;
		}

		static ThemeData()
		{
			int num = 1;
			while (true)
			{
				Class296.Aw4EYyy3h();
				num = 9;
				while (true)
				{
					if (num != 9)
					{
						if (num == 990)
						{
							switch (num)
							{
							default:
								continue;
							case 1:
								break;
							case 0:
								return;
							case 2:
								return;
							}
							break;
						}
					}
					else
					{
						Class300.smethod_0();
					}
					return;
				}
			}
		}

		internal static bool smethod_0()
		{
			return object_0 == null;
		}

		internal static object smethod_1()
		{
			return object_0;
		}
	}

	private static int int_0;

	private static ThemeData[] themeData_0;

	private static int int_1;

	private static float float_0;

	private static bool bool_0;

	private static double double_0;

	private static IntPtr[] POLICYNOTIFICATIONNS;

	private static IntPtr[] LimitCountControlEvidence;

	private static IntPtr[] CORESERVERIChannelSinkBase;

	private static IntPtr[] setAsCyWrappedObject;

	private static IntPtr[] NewEnumFileAssociationProgID;

	private static IntPtr[] MinValuesetResponseXmlElementName;

	private static IntPtr[] WhenAnyEventToken;

	public unsafe static int CurrentIndex
	{
		get
		{
			int num = 102;
			int num5 = default(int);
			int num6 = default(int);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[3];
							while (true)
							{
								object[] array2 = new object[3];
								while (true)
								{
									int[] array3 = new int[6];
									while (true)
									{
										long[] array4 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref CurrencyTargetFrameworkName.itemsetObjectAceType);
											while (true)
											{
												byte* ptr2 = ptr;
												num = 14;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_033f:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_031f:
																				if (8 < b)
																				{
																					goto IL_064c;
																				}
																				while (true)
																				{
																					IL_0312:
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_0302:
																							if (4 >= b)
																							{
																								while (true)
																								{
																									IL_02f5:
																									if (4 <= b)
																									{
																										while (true)
																										{
																											IL_02e5:
																											array[num6] = 0;
																											while (true)
																											{
																												IL_02c0:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
																												while (true)
																												{
																													IL_02ab:
																													array2[num6] = null;
																													num = 10;
																													while (true)
																													{
																														IL_0292:
																														num6++;
																														num = 156;
																														while (true)
																														{
																															if (num != 156)
																															{
																																if (num != 1137)
																																{
																																	break;
																																}
																																switch (num)
																																{
																																case 10:
																																	goto IL_0292;
																																case 22:
																																	goto IL_02ab;
																																case 19:
																																	goto IL_02c0;
																																case 42:
																																case 133:
																																	goto IL_02e5;
																																case 68:
																																	goto IL_02f5;
																																case 108:
																																	goto IL_0302;
																																case 54:
																																	goto IL_0312;
																																case 90:
																																	goto IL_031f;
																																case 62:
																																	goto end_IL_031f;
																																case 44:
																																	goto IL_033f;
																																case 57:
																																	goto end_IL_033f;
																																case 110:
																																case 111:
																																	goto end_IL_034c;
																																case 2:
																																case 31:
																																	goto IL_0375;
																																case 37:
																																case 80:
																																	goto IL_0382;
																																case 105:
																																	goto IL_0395;
																																case 107:
																																	goto IL_03ae;
																																case 139:
																																	goto IL_03ca;
																																case 18:
																																case 82:
																																	goto IL_03d5;
																																case 16:
																																	goto IL_03e3;
																																case 51:
																																case 137:
																																	goto IL_03f6;
																																case 109:
																																	goto IL_0436;
																																case 120:
																																	goto IL_044a;
																																case 135:
																																case 147:
																																	goto IL_045d;
																																case 38:
																																	goto IL_0486;
																																case 96:
																																	goto IL_049d;
																																case 28:
																																case 39:
																																	goto IL_04c3;
																																case 11:
																																case 49:
																																	goto IL_04d1;
																																case 122:
																																	goto IL_04df;
																																case 89:
																																case 145:
																																	goto IL_04ed;
																																case 138:
																																	goto IL_052d;
																																case 125:
																																	goto IL_0541;
																																case 63:
																																	goto IL_0554;
																																case 15:
																																case 143:
																																	goto IL_0562;
																																case 43:
																																	goto IL_0570;
																																case 85:
																																case 117:
																																	goto IL_057e;
																																case 0:
																																	goto IL_05be;
																																case 75:
																																	goto IL_05d2;
																																case 55:
																																case 146:
																																	goto IL_05e5;
																																case 5:
																																	goto IL_0625;
																																case 127:
																																	goto IL_0639;
																																case 81:
																																	goto IL_064c;
																																case 123:
																																case 130:
																																	goto IL_065a;
																																case 141:
																																	goto IL_0668;
																																case 99:
																																	goto IL_0673;
																																case 131:
																																	goto IL_0681;
																																case 52:
																																case 126:
																																	goto end_IL_027f;
																																case 94:
																																case 113:
																																	goto IL_06a7;
																																case 104:
																																	goto IL_06cb;
																																case 149:
																																	goto IL_06d9;
																																case 140:
																																	goto IL_06e7;
																																case 67:
																																	goto IL_0703;
																																case 47:
																																	goto IL_0711;
																																case 40:
																																case 128:
																																	goto IL_071f;
																																case 114:
																																	goto IL_073b;
																																case 88:
																																	goto IL_0749;
																																case 4:
																																case 77:
																																	goto IL_0754;
																																case 29:
																																	goto IL_0762;
																																case 35:
																																	goto IL_0775;
																																case 24:
																																case 115:
																																	goto IL_0783;
																																case 132:
																																	goto IL_0791;
																																case 6:
																																case 92:
																																	goto IL_079f;
																																case 64:
																																	goto IL_07df;
																																case 83:
																																	goto IL_07f3;
																																case 76:
																																case 103:
																																	goto IL_0806;
																																case 91:
																																	goto IL_0868;
																																case 46:
																																case 71:
																																	goto IL_087b;
																																case 23:
																																	goto IL_089d;
																																case 9:
																																	goto IL_08ab;
																																case 61:
																																	goto IL_08b9;
																																case 1:
																																case 12:
																																case 13:
																																case 21:
																																case 26:
																																case 30:
																																case 41:
																																case 50:
																																case 58:
																																case 72:
																																case 74:
																																case 79:
																																case 87:
																																case 95:
																																case 97:
																																case 98:
																																case 100:
																																case 106:
																																case 112:
																																case 116:
																																case 121:
																																case 124:
																																case 129:
																																case 134:
																																case 142:
																																case 148:
																																	goto end_IL_032f;
																																case 136:
																																	goto IL_08eb;
																																case 119:
																																	goto IL_08f9;
																																case 144:
																																	goto IL_0907;
																																case 3:
																																case 7:
																																case 8:
																																case 14:
																																case 17:
																																case 25:
																																case 27:
																																case 34:
																																case 36:
																																case 48:
																																case 59:
																																case 60:
																																case 65:
																																case 66:
																																case 69:
																																case 73:
																																case 86:
																																case 118:
																																	goto end_IL_035c;
																																case 53:
																																	goto end_IL_0915;
																																case 33:
																																	goto end_IL_0928;
																																case 70:
																																	goto end_IL_093b;
																																case 20:
																																case 78:
																																	goto end_IL_0946;
																																case 84:
																																	goto end_IL_0956;
																																case 93:
																																	goto end_IL_0966;
																																case 56:
																																	goto end_IL_0976;
																																case 101:
																																	goto end_IL_0986;
																																case 102:
																																	goto end_IL_0996;
																																case 32:
																																case 45:
																																	goto IL_09b1;
																																}
																																continue;
																															}
																															ptr2 += 8;
																															goto end_IL_035c;
																															continue;
																															end_IL_027f:
																															break;
																														}
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									goto IL_0375;
																									IL_045d:
																									ref int reference = ref array3[*(int*)(ptr2 + num3)];
																									reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0486;
																									IL_0375:
																									if (2 < b)
																									{
																										goto IL_0395;
																									}
																									goto IL_03ca;
																									IL_03ca:
																									if (2 > b)
																									{
																										goto IL_03d5;
																									}
																									goto IL_03f6;
																									IL_03d5:
																									if (1 < b)
																									{
																										goto end_IL_032f;
																									}
																									goto IL_03e3;
																									IL_03e3:
																									if (1 > b)
																									{
																									}
																									goto end_IL_032f;
																									IL_03f6:
																									*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																									goto IL_0436;
																									IL_0436:
																									array[num6 - 2] = 0;
																									goto IL_044a;
																									IL_044a:
																									num6--;
																									goto end_IL_035c;
																									IL_0395:
																									if (3 < b)
																									{
																										num = 58;
																										goto end_IL_032f;
																									}
																									goto IL_03ae;
																									IL_0486:
																									ptr2 += 8;
																									num = 96;
																									goto IL_049d;
																									IL_03ae:
																									if (3 > b)
																									{
																										num = 98;
																										goto end_IL_032f;
																									}
																									goto IL_045d;
																									IL_049d:
																									num6--;
																									goto end_IL_035c;
																								}
																								break;
																							}
																							goto IL_04c3;
																							IL_0639:
																							num6--;
																							goto end_IL_035c;
																							IL_04c3:
																							if (6 < b)
																							{
																								goto IL_04d1;
																							}
																							goto IL_0554;
																							IL_04d1:
																							if (7 < b)
																							{
																								goto end_IL_032f;
																							}
																							goto IL_04df;
																							IL_04df:
																							if (7 > b)
																							{
																								goto end_IL_032f;
																							}
																							goto IL_04ed;
																							IL_04ed:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_052d;
																							IL_052d:
																							array[num6 - 2] = 0;
																							goto IL_0541;
																							IL_0541:
																							num6--;
																							goto end_IL_035c;
																							IL_0554:
																							if (6 > b)
																							{
																								goto IL_0562;
																							}
																							goto IL_05e5;
																							IL_0562:
																							if (5 < b)
																							{
																								goto end_IL_032f;
																							}
																							goto IL_0570;
																							IL_0570:
																							if (5 > b)
																							{
																								goto end_IL_032f;
																							}
																							goto IL_057e;
																							IL_057e:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_05be;
																							IL_05be:
																							array[num6 - 2] = 0;
																							goto IL_05d2;
																							IL_05d2:
																							num6--;
																							goto end_IL_035c;
																							IL_05e5:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																							goto IL_0625;
																							IL_0625:
																							array[num6 - 2] = 0;
																							goto IL_0639;
																						}
																						break;
																					}
																					goto IL_0382;
																					IL_0382:
																					num6--;
																					goto end_IL_035c;
																				}
																				goto IL_068f;
																				IL_08b9:
																				ptr2 += 16;
																				goto end_IL_035c;
																				IL_064c:
																				if (12 < b)
																				{
																					goto IL_065a;
																				}
																				goto IL_073b;
																				IL_065a:
																				if (14 >= b)
																				{
																					goto IL_0668;
																				}
																				goto IL_0703;
																				IL_0668:
																				if (14 > b)
																				{
																					goto IL_0673;
																				}
																				goto IL_06a7;
																				IL_0673:
																				if (13 < b)
																				{
																					goto end_IL_032f;
																				}
																				goto IL_0681;
																				IL_0681:
																				if (13 > b)
																				{
																					goto end_IL_032f;
																				}
																				goto IL_068f;
																				IL_068f:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_035c;
																				IL_06a7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)NewEnumFileAssociationProgID[*(int*)(ptr2 + num3)])();
																				goto IL_06cb;
																				IL_06cb:
																				array[num6] = 0;
																				goto IL_06d9;
																				IL_06d9:
																				num6++;
																				goto IL_06e7;
																				IL_06e7:
																				ptr2 += 8;
																				num = 27;
																				goto end_IL_035c;
																				IL_0703:
																				if (15 < b)
																				{
																					goto end_IL_032f;
																				}
																				goto IL_0711;
																				IL_0711:
																				if (15 > b)
																				{
																					goto end_IL_032f;
																				}
																				goto IL_071f;
																				IL_071f:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_035c;
																				IL_073b:
																				if (12 > b)
																				{
																					goto IL_0749;
																				}
																				goto IL_087b;
																				IL_0749:
																				if (10 < b)
																				{
																					goto IL_0754;
																				}
																				goto IL_0775;
																				IL_0754:
																				if (11 < b)
																				{
																					goto end_IL_032f;
																				}
																				goto IL_0762;
																				IL_0762:
																				if (11 <= b)
																				{
																					goto end_IL_035c;
																				}
																				goto end_IL_032f;
																				IL_0775:
																				if (10 > b)
																				{
																					goto IL_0783;
																				}
																				goto IL_0806;
																				IL_0783:
																				if (9 < b)
																				{
																					goto end_IL_032f;
																				}
																				goto IL_0791;
																				IL_0791:
																				if (9 > b)
																				{
																					goto end_IL_032f;
																				}
																				goto IL_079f;
																				IL_079f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
																				goto IL_07df;
																				IL_07df:
																				array[num6 - 2] = 0;
																				goto IL_07f3;
																				IL_07f3:
																				num6--;
																				goto end_IL_035c;
																				IL_0806:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_0868;
																				IL_0868:
																				num6 -= 2;
																				goto end_IL_035c;
																				IL_087b:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
																				num = 23;
																				goto IL_089d;
																				IL_089d:
																				array[num6] = 1;
																				goto IL_08ab;
																				IL_08ab:
																				num6++;
																				goto IL_08b9;
																				continue;
																				end_IL_031f:
																				break;
																			}
																			continue;
																			end_IL_032f:
																			break;
																		}
																	}
																	else
																	{
																		num = 106;
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
																	num = 136;
																	goto IL_08eb;
																	IL_08f9:
																	num6++;
																	goto IL_0907;
																	IL_0907:
																	ptr2 += 8;
																	goto end_IL_035c;
																	IL_08eb:
																	array[num6] = 0;
																	goto IL_08f9;
																	continue;
																	end_IL_033f:
																	break;
																}
																continue;
																end_IL_034c:
																break;
															}
															continue;
															end_IL_035c:
															break;
														}
														continue;
													}
													goto IL_09b1;
													IL_09b1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
													continue;
													end_IL_0915:
													break;
												}
												continue;
												end_IL_0928:
												break;
											}
											continue;
											end_IL_093b:
											break;
										}
										continue;
										end_IL_0946:
										break;
									}
									continue;
									end_IL_0956:
									break;
								}
								continue;
								end_IL_0966:
								break;
							}
							continue;
							end_IL_0976:
							break;
						}
						continue;
						end_IL_0986:
						break;
					}
					continue;
					end_IL_0996:
					break;
				}
			}
		}
		set
		{
			int num = 68;
			int num5 = default(int);
			int num6 = default(int);
			byte b = default(byte);
			while (true)
			{
				int num2 = 1;
				while (true)
				{
					int num3 = num2 * 4;
					num = 173;
					while (true)
					{
						int num4 = num2 * 8;
						while (true)
						{
							byte[] array = new byte[4];
							while (true)
							{
								object[] array2 = new object[4];
								while (true)
								{
									int[] array3 = new int[7];
									while (true)
									{
										long[] array4 = new long[4];
										num = 114;
										while (true)
										{
											array3[0] = value;
											while (true)
											{
												byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AssumeLocalsetSponsorshipTimeout.HostNativeVersionInfo);
												while (true)
												{
													byte* ptr2 = ptr;
													while (true)
													{
														IL_0d24:
														if (num5 != 1)
														{
															goto IL_000e;
														}
														num = 221;
														while (true)
														{
															if (num != 221)
															{
																if (num != 1202)
																{
																	break;
																}
																switch (num)
																{
																case 104:
																case 108:
																	break;
																case 63:
																	goto IL_0017;
																case 23:
																	goto IL_0025;
																case 106:
																	goto IL_0033;
																case 214:
																	goto IL_0041;
																case 5:
																	goto IL_004f;
																case 15:
																case 28:
																	goto IL_005a;
																case 101:
																	goto IL_0068;
																case 119:
																	goto IL_008c;
																case 178:
																	goto IL_009a;
																case 0:
																	goto IL_00ad;
																case 31:
																case 159:
																	goto IL_00bb;
																case 184:
																	goto IL_00c9;
																case 132:
																	goto IL_00d7;
																case 172:
																case 183:
																	goto IL_00ee;
																case 142:
																	goto IL_0105;
																case 72:
																case 201:
																	goto IL_0113;
																case 52:
																	goto IL_0153;
																case 90:
																	goto IL_0167;
																case 18:
																	goto IL_017a;
																case 87:
																case 125:
																	goto IL_0188;
																case 71:
																	goto IL_01c8;
																case 151:
																	goto IL_01e5;
																case 88:
																case 118:
																	goto IL_01f8;
																case 113:
																	goto IL_0214;
																case 75:
																case 120:
																	goto IL_0222;
																case 191:
																	goto IL_0230;
																case 32:
																case 179:
																	goto IL_023e;
																case 107:
																	goto IL_02a0;
																case 102:
																	goto IL_02b3;
																case 36:
																case 155:
																	goto IL_02c1;
																case 94:
																	goto IL_0301;
																case 186:
																	goto IL_0315;
																case 199:
																	goto IL_0328;
																case 33:
																case 80:
																	goto IL_0333;
																case 144:
																	goto IL_0373;
																case 112:
																	goto IL_0387;
																case 1:
																	goto IL_039a;
																case 204:
																	goto IL_03a8;
																case 61:
																case 78:
																	goto IL_03b3;
																case 200:
																	goto IL_03c1;
																case 79:
																case 175:
																	goto IL_03d4;
																case 205:
																	goto IL_0414;
																case 195:
																	goto IL_0428;
																case 91:
																	goto IL_043b;
																case 14:
																case 57:
																	goto IL_0449;
																case 7:
																	goto IL_0460;
																case 11:
																case 64:
																	goto IL_046e;
																case 81:
																	goto IL_047c;
																case 153:
																	goto IL_049f;
																case 128:
																	goto IL_04a9;
																case 168:
																	goto IL_04b7;
																case 111:
																	goto IL_04d3;
																case 29:
																case 99:
																	goto IL_04e1;
																case 210:
																	goto IL_050a;
																case 13:
																	goto IL_0518;
																case 163:
																	goto IL_052b;
																case 24:
																	goto IL_0539;
																case 35:
																case 40:
																	goto IL_0544;
																case 169:
																	goto IL_056e;
																case 65:
																	goto IL_0587;
																case 134:
																	goto IL_0595;
																case 77:
																case 164:
																	goto IL_05a3;
																case 103:
																	goto IL_05ae;
																case 74:
																	goto IL_05c1;
																case 148:
																	goto IL_05cf;
																case 54:
																case 145:
																	goto IL_05dd;
																case 8:
																	goto IL_05f6;
																case 3:
																	goto IL_0604;
																case 116:
																	goto IL_0612;
																case 176:
																case 193:
																	goto IL_0625;
																case 126:
																	goto IL_063d;
																case 50:
																	goto IL_0648;
																case 41:
																case 202:
																	goto IL_0656;
																case 20:
																	goto IL_0679;
																case 170:
																	goto IL_0687;
																case 174:
																	goto IL_0695;
																case 198:
																	goto IL_06a8;
																case 34:
																	goto IL_06b6;
																case 143:
																case 203:
																	goto IL_06c4;
																case 10:
																	goto IL_06e2;
																case 152:
																	goto IL_06f9;
																case 209:
																	goto IL_0707;
																case 149:
																	goto IL_071a;
																case 56:
																	goto IL_0728;
																case 157:
																case 181:
																	goto IL_0736;
																case 46:
																	goto IL_074a;
																case 9:
																	goto IL_07b3;
																case 208:
																	goto IL_07c1;
																case 69:
																	goto end_IL_0d11;
																case 110:
																	goto IL_07df;
																case 2:
																case 70:
																	goto IL_07ed;
																case 188:
																	goto IL_0818;
																case 19:
																	goto IL_0831;
																case 162:
																	goto IL_083f;
																case 76:
																case 89:
																	goto IL_084d;
																case 105:
																	goto IL_088d;
																case 37:
																	goto IL_08a1;
																case 44:
																case 136:
																	goto IL_08b4;
																case 192:
																case 197:
																	goto IL_08c8;
																case 212:
																	goto IL_08d3;
																case 60:
																case 135:
																	goto IL_08de;
																case 177:
																	goto IL_08fa;
																case 95:
																case 97:
																	goto IL_0910;
																case 66:
																	goto IL_0933;
																case 4:
																case 16:
																case 17:
																case 21:
																case 25:
																case 26:
																case 30:
																case 39:
																case 43:
																case 48:
																case 49:
																case 51:
																case 55:
																case 58:
																case 59:
																case 62:
																case 73:
																case 92:
																case 93:
																case 98:
																case 100:
																case 109:
																case 115:
																case 117:
																case 121:
																case 122:
																case 130:
																case 131:
																case 133:
																case 138:
																case 139:
																case 141:
																case 146:
																case 147:
																case 154:
																case 156:
																case 165:
																case 166:
																case 182:
																case 196:
																case 213:
																	goto IL_0946;
																case 45:
																	goto IL_095f;
																case 42:
																	goto IL_096d;
																case 86:
																	goto IL_097b;
																default:
																	continue;
																case 6:
																case 22:
																case 27:
																case 38:
																case 47:
																case 53:
																case 82:
																case 85:
																case 96:
																case 123:
																case 127:
																case 129:
																case 137:
																case 140:
																case 150:
																case 158:
																case 160:
																case 171:
																case 185:
																case 187:
																case 190:
																case 194:
																case 206:
																case 207:
																case 211:
																	goto IL_0d24;
																case 180:
																	goto end_IL_0d24;
																case 167:
																	goto end_IL_0d37;
																case 114:
																	goto end_IL_0d41;
																case 83:
																	goto end_IL_0d4c;
																case 12:
																case 84:
																	goto end_IL_0d61;
																case 124:
																	goto end_IL_0d7a;
																case 189:
																	goto end_IL_0d8a;
																case 173:
																	goto end_IL_0d9a;
																case 67:
																	goto end_IL_0daa;
																case 68:
																	goto end_IL_0dba;
																case 161:
																	return;
																}
																goto IL_000e;
															}
															return;
															continue;
															end_IL_0d11:
															break;
														}
														goto IL_07d4;
														IL_097b:
														ptr2 += 8;
														continue;
														IL_0910:
														int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														num = 66;
														goto IL_0933;
														IL_000e:
														b = *ptr2;
														goto IL_0017;
														IL_0017:
														ptr2++;
														goto IL_0025;
														IL_0025:
														if (b >= 1)
														{
															goto IL_0033;
														}
														goto IL_0946;
														IL_0033:
														if (b <= 22)
														{
															goto IL_0041;
														}
														goto IL_0946;
														IL_0041:
														if (11 >= b)
														{
															goto IL_004f;
														}
														goto IL_052b;
														IL_004f:
														if (11 <= b)
														{
															goto IL_005a;
														}
														goto IL_00ad;
														IL_005a:
														array[num6] = 0;
														goto IL_0068;
														IL_0068:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = ((delegate*<int>)MinValuesetResponseXmlElementName[*(int*)(ptr2 + num3)])();
														goto IL_008c;
														IL_008c:
														num6++;
														goto IL_009a;
														IL_009a:
														ptr2 += 8;
														continue;
														IL_00ad:
														if (5 < b)
														{
															goto IL_00bb;
														}
														goto IL_0328;
														IL_00bb:
														if (8 >= b)
														{
															goto IL_00c9;
														}
														goto IL_0214;
														IL_00c9:
														if (8 > b)
														{
															goto IL_00d7;
														}
														goto IL_01f8;
														IL_00d7:
														if (6 < b)
														{
															num = 183;
															goto IL_00ee;
														}
														goto IL_017a;
														IL_0933:
														num6--;
														continue;
														IL_00ee:
														if (7 >= b)
														{
															num = 142;
															goto IL_0105;
														}
														goto IL_0946;
														IL_0946:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(int*)(ptr2 + num3);
														goto IL_095f;
														IL_0105:
														if (7 <= b)
														{
															goto IL_0113;
														}
														goto IL_0946;
														IL_0113:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														goto IL_0153;
														IL_0153:
														array[num6 - 2] = 0;
														goto IL_0167;
														IL_0167:
														num6--;
														continue;
														IL_017a:
														if (6 <= b)
														{
															goto IL_0188;
														}
														goto IL_0946;
														IL_0188:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														goto IL_01c8;
														IL_01c8:
														array[num6 - 2] = 0;
														num = 151;
														goto IL_01e5;
														IL_01e5:
														num6--;
														continue;
														IL_01f8:
														num6--;
														num = 96;
														continue;
														IL_0214:
														if (9 < b)
														{
															goto IL_0222;
														}
														goto IL_02b3;
														IL_0222:
														if (10 >= b)
														{
															goto IL_0230;
														}
														goto IL_0946;
														IL_0230:
														if (10 <= b)
														{
															goto IL_023e;
														}
														goto IL_0946;
														IL_023e:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_02a0;
														IL_02a0:
														num6 -= 2;
														continue;
														IL_02b3:
														if (9 <= b)
														{
															goto IL_02c1;
														}
														goto IL_0946;
														IL_02c1:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														goto IL_0301;
														IL_0301:
														array[num6 - 2] = 0;
														goto IL_0315;
														IL_0315:
														num6--;
														continue;
														IL_0328:
														if (5 <= b)
														{
															goto IL_0333;
														}
														goto IL_039a;
														IL_0333:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														goto IL_0373;
														IL_0373:
														array[num6 - 2] = 0;
														goto IL_0387;
														IL_0387:
														num6--;
														continue;
														IL_039a:
														if (2 >= b)
														{
															goto IL_03a8;
														}
														goto IL_043b;
														IL_03a8:
														if (2 > b)
														{
															goto IL_03b3;
														}
														goto IL_03d4;
														IL_03b3:
														if (1 >= b)
														{
															goto IL_03c1;
														}
														goto IL_0946;
														IL_03c1:
														if (1 > b)
														{
														}
														goto IL_0946;
														IL_03d4:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														goto IL_0414;
														IL_0414:
														array[num6 - 2] = 0;
														goto IL_0428;
														IL_0428:
														num6--;
														continue;
														IL_043b:
														if (3 < b)
														{
															goto IL_0449;
														}
														goto IL_04d3;
														IL_0449:
														if (4 >= b)
														{
															num = 7;
															goto IL_0460;
														}
														goto IL_0946;
														IL_095f:
														array[num6] = 0;
														goto IL_096d;
														IL_0460:
														if (4 <= b)
														{
															goto IL_046e;
														}
														goto IL_0946;
														IL_046e:
														array[num6] = 0;
														goto IL_047c;
														IL_047c:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
														goto IL_049f;
														IL_049f:
														array2[num6] = null;
														goto IL_04a9;
														IL_04a9:
														num6++;
														goto IL_04b7;
														IL_04b7:
														ptr2 += 8;
														num = 47;
														continue;
														IL_04d3:
														if (3 <= b)
														{
															goto IL_04e1;
														}
														goto IL_0946;
														IL_04e1:
														ref int reference = ref array3[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														goto IL_050a;
														IL_050a:
														ptr2 += 8;
														goto IL_0518;
														IL_0518:
														num6--;
														continue;
														IL_052b:
														if (17 >= b)
														{
															goto IL_0539;
														}
														goto IL_071a;
														IL_0539:
														if (17 <= b)
														{
															goto IL_0544;
														}
														goto IL_0587;
														IL_0544:
														*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (nint)((ThemeData[])array2[num6 - 1]).LongLength;
														goto IL_056e;
														IL_056e:
														array[num6 - 1] = 2;
														continue;
														IL_0587:
														if (14 >= b)
														{
															goto IL_0595;
														}
														goto IL_063d;
														IL_0595:
														if (14 > b)
														{
															goto IL_05a3;
														}
														goto IL_0625;
														IL_05a3:
														if (12 >= b)
														{
															goto IL_05ae;
														}
														goto IL_05c1;
														IL_05ae:
														if (12 <= b)
														{
															continue;
														}
														goto IL_0946;
														IL_05c1:
														if (13 >= b)
														{
															goto IL_05cf;
														}
														goto IL_0946;
														IL_05cf:
														if (13 <= b)
														{
															goto IL_05dd;
														}
														goto IL_0946;
														IL_05dd:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = *(long*)(ptr2 + num4);
														goto IL_05f6;
														IL_05f6:
														array[num6] = 1;
														goto IL_0604;
														IL_0604:
														num6++;
														goto IL_0612;
														IL_0612:
														ptr2 += 16;
														continue;
														IL_0625:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														continue;
														IL_063d:
														if (15 >= b)
														{
															goto IL_0648;
														}
														goto IL_06a8;
														IL_0648:
														if (15 <= b)
														{
															goto IL_0656;
														}
														goto IL_0946;
														IL_0656:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6]) = array3[*(int*)(ptr2 + num3)];
														goto IL_0679;
														IL_0679:
														array[num6] = 0;
														goto IL_0687;
														IL_0687:
														num6++;
														goto IL_0695;
														IL_0695:
														ptr2 += 8;
														continue;
														IL_06a8:
														if (16 >= b)
														{
															goto IL_06b6;
														}
														goto IL_0946;
														IL_06b6:
														if (16 <= b)
														{
															goto IL_06c4;
														}
														goto IL_0946;
														IL_06c4:
														array2[num6] = ((delegate*<ThemeData[]>)MinValuesetResponseXmlElementName[*(int*)(ptr2 + num3)])();
														goto IL_06e2;
														IL_06e2:
														array[num6] = 5;
														num = 152;
														goto IL_06f9;
														IL_06f9:
														num6++;
														goto IL_0707;
														IL_0707:
														ptr2 += 8;
														continue;
														IL_071a:
														if (20 >= b)
														{
															goto IL_0728;
														}
														goto IL_08b4;
														IL_0728:
														if (20 <= b)
														{
															goto IL_0736;
														}
														goto IL_07d4;
														IL_0736:
														array[num6 - 3] = 0;
														goto IL_074a;
														IL_074a:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]) = ((delegate*<int, int, int, int>)MinValuesetResponseXmlElementName[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 3]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
														goto IL_07b3;
														IL_07b3:
														num6 -= 2;
														goto IL_07c1;
														IL_07c1:
														ptr2 += 8;
														continue;
														IL_07d4:
														if (18 >= b)
														{
															goto IL_07df;
														}
														goto IL_0831;
														IL_07df:
														if (18 <= b)
														{
															goto IL_07ed;
														}
														goto IL_0946;
														IL_07ed:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]));
														goto IL_0818;
														IL_0818:
														array[num6 - 1] = 0;
														continue;
														IL_0831:
														if (19 >= b)
														{
															goto IL_083f;
														}
														goto IL_0946;
														IL_083f:
														if (19 <= b)
														{
															goto IL_084d;
														}
														goto IL_0946;
														IL_084d:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num6 - 1]);
														goto IL_088d;
														IL_088d:
														array[num6 - 2] = 0;
														goto IL_08a1;
														IL_08a1:
														num6--;
														continue;
														IL_08b4:
														if (21 < b)
														{
															num = 192;
															goto IL_08c8;
														}
														goto IL_08fa;
														IL_096d:
														num6++;
														goto IL_097b;
														IL_08c8:
														if (22 >= b)
														{
															goto IL_08d3;
														}
														goto IL_0946;
														IL_08d3:
														if (22 <= b)
														{
															goto IL_08de;
														}
														goto IL_0946;
														IL_08de:
														byte* num7 = ptr2;
														num5 = 1;
														ptr2 = num7 + -200;
														continue;
														IL_08fa:
														if (21 <= b)
														{
															goto IL_0910;
														}
														num = 115;
														goto IL_0946;
														continue;
														end_IL_0d24:
														break;
													}
													continue;
													end_IL_0d37:
													break;
												}
												continue;
												end_IL_0d41:
												break;
											}
											continue;
											end_IL_0d4c:
											break;
										}
										continue;
										end_IL_0d61:
										break;
									}
									continue;
									end_IL_0d7a:
									break;
								}
								continue;
								end_IL_0d8a:
								break;
							}
							continue;
							end_IL_0d9a:
							break;
						}
						continue;
						end_IL_0daa:
						break;
					}
					continue;
					end_IL_0dba:
					break;
				}
			}
		}
	}

	private unsafe void OnEnable()
	{
		int num = 121;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[6];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										array5[0] = this;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getLoaderExceptionsFromResult.SerializationExceptionRegisterObjectParam);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 == 1)
													{
														return;
													}
													while (true)
													{
														num = 8;
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_03d9:
																	if (b >= 1)
																	{
																		while (b <= 20)
																		{
																			while (true)
																			{
																				IL_03bc:
																				if (10 < b)
																				{
																					while (true)
																					{
																						IL_03ac:
																						if (15 >= b)
																						{
																							while (true)
																							{
																								IL_039c:
																								if (15 > b)
																								{
																									while (true)
																									{
																										IL_0389:
																										if (12 < b)
																										{
																											num = 12;
																											while (true)
																											{
																												IL_0379:
																												if (13 >= b)
																												{
																													while (true)
																													{
																														IL_0366:
																														if (13 > b)
																														{
																															num = 202;
																															while (num != 202)
																															{
																																if (num != 1183)
																																{
																																	goto IL_0883;
																																}
																																switch (num)
																																{
																																case 5:
																																	goto IL_0366;
																																case 12:
																																case 21:
																																	goto IL_0379;
																																case 31:
																																case 46:
																																	goto IL_0389;
																																case 37:
																																	goto IL_039c;
																																case 188:
																																	goto IL_03ac;
																																case 40:
																																	goto IL_03bc;
																																case 194:
																																	goto IL_03c9;
																																case 58:
																																	goto IL_03d9;
																																case 159:
																																	goto end_IL_03d9;
																																case 8:
																																	goto end_IL_03e9;
																																case 118:
																																	goto end_IL_03f9;
																																case 57:
																																	goto IL_040f;
																																case 130:
																																	goto IL_041d;
																																case 35:
																																	goto IL_042b;
																																case 74:
																																case 128:
																																	goto IL_0439;
																																case 72:
																																	goto IL_0444;
																																case 22:
																																	goto IL_0457;
																																case 27:
																																case 75:
																																	goto IL_0462;
																																case 98:
																																	goto IL_0470;
																																case 49:
																																	goto IL_0483;
																																case 33:
																																case 91:
																																	goto IL_0491;
																																case 67:
																																	goto IL_04ba;
																																case 116:
																																	goto IL_04c8;
																																case 138:
																																case 146:
																																	goto IL_04db;
																																case 96:
																																	goto IL_053d;
																																case 133:
																																case 157:
																																	goto IL_0550;
																																case 158:
																																	goto IL_056c;
																																case 54:
																																	goto IL_0577;
																																case 88:
																																case 109:
																																	goto IL_058b;
																																case 51:
																																	goto IL_0599;
																																case 162:
																																	goto IL_05b5;
																																case 47:
																																case 149:
																																	goto IL_05c3;
																																case 169:
																																	goto IL_05d6;
																																case 89:
																																case 106:
																																	goto IL_05ec;
																																case 60:
																																	goto IL_062c;
																																case 84:
																																	goto IL_0640;
																																case 81:
																																case 171:
																																	goto IL_0653;
																																case 144:
																																	goto IL_0661;
																																case 147:
																																case 166:
																																	goto IL_066f;
																																case 77:
																																	goto IL_06af;
																																case 153:
																																	goto IL_06c3;
																																case 175:
																																	goto IL_06d6;
																																case 34:
																																	goto IL_06f9;
																																case 7:
																																	goto IL_0703;
																																case 136:
																																	goto IL_0711;
																																case 180:
																																	goto IL_0724;
																																case 164:
																																	goto IL_0732;
																																case 143:
																																case 184:
																																	goto IL_0745;
																																case 78:
																																	goto IL_0785;
																																case 170:
																																	goto IL_0799;
																																case 119:
																																case 185:
																																	goto IL_07b5;
																																case 173:
																																	goto IL_07f5;
																																case 76:
																																	goto IL_0809;
																																case 73:
																																case 189:
																																	goto IL_081c;
																																case 44:
																																	goto IL_085c;
																																case 17:
																																	goto IL_0870;
																																case 168:
																																case 178:
																																	goto IL_0883;
																																case 151:
																																	goto IL_08a1;
																																case 142:
																																	goto IL_08af;
																																case 126:
																																	goto IL_08bd;
																																case 99:
																																case 129:
																																	goto IL_08d0;
																																case 13:
																																	goto IL_08de;
																																case 39:
																																case 86:
																																	goto IL_08ec;
																																case 102:
																																	goto IL_0916;
																																case 193:
																																	goto IL_092f;
																																case 4:
																																case 115:
																																	goto IL_093a;
																																case 25:
																																	goto IL_0948;
																																case 26:
																																case 192:
																																	goto IL_095b;
																																case 190:
																																	goto IL_097f;
																																case 61:
																																	goto IL_098d;
																																case 100:
																																	goto IL_099b;
																																case 85:
																																case 148:
																																	goto IL_09ae;
																																case 66:
																																	goto IL_09e2;
																																case 111:
																																	goto IL_0a04;
																																case 69:
																																	goto IL_0a12;
																																case 52:
																																case 155:
																																	goto IL_0a1d;
																																case 174:
																																	goto IL_0a35;
																																case 114:
																																	goto IL_0a43;
																																case 113:
																																	goto IL_0a51;
																																case 122:
																																	goto IL_0a64;
																																case 63:
																																	goto IL_0a6f;
																																case 15:
																																case 29:
																																	goto IL_0a7d;
																																case 135:
																																	goto IL_0abd;
																																case 45:
																																	goto IL_0ad1;
																																case 179:
																																	goto IL_0ae4;
																																case 134:
																																	goto IL_0af2;
																																case 64:
																																case 94:
																																	goto IL_0b0b;
																																case 140:
																																	goto IL_0b25;
																																case 117:
																																	goto IL_0b41;
																																case 191:
																																	goto IL_0b4c;
																																case 42:
																																case 90:
																																	goto IL_0b57;
																																case 23:
																																	goto IL_0b80;
																																case 1:
																																	goto IL_0b8e;
																																case 43:
																																	goto IL_0b9e;
																																case 11:
																																	goto IL_0ba9;
																																case 82:
																																case 167:
																																	goto IL_0bb4;
																																case 0:
																																case 2:
																																case 9:
																																case 16:
																																case 19:
																																case 20:
																																case 24:
																																case 30:
																																case 36:
																																case 38:
																																case 41:
																																case 48:
																																case 56:
																																case 59:
																																case 62:
																																case 83:
																																case 93:
																																case 101:
																																case 105:
																																case 108:
																																case 110:
																																case 112:
																																case 124:
																																case 131:
																																case 132:
																																case 137:
																																case 139:
																																case 152:
																																case 161:
																																case 165:
																																case 172:
																																case 182:
																																case 186:
																																case 195:
																																	goto end_IL_0353;
																																case 32:
																																	goto IL_0be6;
																																case 6:
																																	goto IL_0bf4;
																																case 181:
																																	goto IL_0c02;
																																case 14:
																																case 18:
																																case 50:
																																case 55:
																																case 68:
																																case 80:
																																case 92:
																																case 95:
																																case 104:
																																case 107:
																																case 123:
																																case 125:
																																case 127:
																																case 141:
																																case 145:
																																case 150:
																																case 154:
																																case 156:
																																case 160:
																																case 163:
																																case 177:
																																case 183:
																																case 187:
																																	goto end_IL_0404;
																																case 97:
																																	goto end_IL_0c10;
																																case 3:
																																	goto end_IL_0c23;
																																case 87:
																																	goto end_IL_0c2d;
																																case 176:
																																	goto end_IL_0c38;
																																case 10:
																																	goto end_IL_0c48;
																																case 53:
																																case 79:
																																	goto end_IL_0c58;
																																case 71:
																																	goto end_IL_0c68;
																																case 28:
																																case 65:
																																	goto end_IL_0c78;
																																case 120:
																																	goto end_IL_0c88;
																																case 121:
																																	goto end_IL_0c98;
																																case 70:
																																case 103:
																																	return;
																																}
																																continue;
																																end_IL_0353:
																																break;
																															}
																															break;
																														}
																														goto IL_0883;
																														IL_08af:
																														num5++;
																														goto IL_08bd;
																														IL_08bd:
																														ptr2 += 8;
																														goto end_IL_0404;
																														IL_0883:
																														array2[num5] = ((delegate*<ThemeData[]>)POLICYNOTIFICATIONNS[*(int*)(ptr2 + num3)])();
																														goto IL_08a1;
																														IL_08a1:
																														array[num5] = 5;
																														goto IL_08af;
																													}
																													break;
																												}
																												goto IL_08d0;
																												IL_0916:
																												array[num5 - 1] = 2;
																												goto end_IL_0404;
																												IL_08d0:
																												if (14 < b)
																												{
																													break;
																												}
																												goto IL_08de;
																												IL_08de:
																												if (14 > b)
																												{
																													break;
																												}
																												goto IL_08ec;
																												IL_08ec:
																												*(IntPtr*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (nint)((ThemeData[])array2[num5 - 1]).LongLength;
																												goto IL_0916;
																											}
																											break;
																										}
																										goto IL_092f;
																										IL_098d:
																										num5++;
																										goto IL_099b;
																										IL_099b:
																										ptr2 += 8;
																										goto end_IL_0404;
																										IL_092f:
																										if (12 > b)
																										{
																											goto IL_093a;
																										}
																										goto IL_095b;
																										IL_093a:
																										if (11 < b)
																										{
																											break;
																										}
																										goto IL_0948;
																										IL_0948:
																										if (11 <= b)
																										{
																											goto end_IL_0404;
																										}
																										break;
																										IL_095b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = ((delegate*<int>)POLICYNOTIFICATIONNS[*(int*)(ptr2 + num3)])();
																										goto IL_097f;
																										IL_097f:
																										array[num5] = 0;
																										goto IL_098d;
																									}
																									break;
																								}
																								goto IL_09ae;
																								IL_09e2:
																								array[num5 - 1] = 0;
																								num = 163;
																								goto end_IL_0404;
																								IL_09ae:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]) = (int)(*(nint*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]));
																								num = 66;
																								goto IL_09e2;
																							}
																							break;
																						}
																						goto IL_0a04;
																						IL_0ba9:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_0bb4;
																						IL_0a04:
																						if (18 >= b)
																						{
																							goto IL_0a12;
																						}
																						goto IL_0b41;
																						IL_0a12:
																						if (18 <= b)
																						{
																							goto IL_0a1d;
																						}
																						goto IL_0a64;
																						IL_0a1d:
																						array2[num5] = array5[*(int*)(ptr2 + num3)];
																						goto IL_0a35;
																						IL_0a35:
																						array[num5] = 5;
																						goto IL_0a43;
																						IL_0a43:
																						num5++;
																						goto IL_0a51;
																						IL_0a51:
																						ptr2 += 8;
																						goto end_IL_0404;
																						IL_0a64:
																						if (16 >= b)
																						{
																							goto IL_0a6f;
																						}
																						goto IL_0ae4;
																						IL_0a6f:
																						if (16 > b)
																						{
																							break;
																						}
																						goto IL_0a7d;
																						IL_0a7d:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) % *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0abd;
																						IL_0abd:
																						array[num5 - 2] = 0;
																						goto IL_0ad1;
																						IL_0ad1:
																						num5--;
																						goto end_IL_0404;
																						IL_0ae4:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0af2;
																						IL_0af2:
																						if (17 > b)
																						{
																							num = 20;
																							break;
																						}
																						goto IL_0b0b;
																						IL_0bb4:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0404;
																						IL_0b0b:
																						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0b25;
																						IL_0b25:
																						num5--;
																						num = 50;
																						goto end_IL_0404;
																						IL_0b41:
																						if (19 >= b)
																						{
																							goto IL_0b4c;
																						}
																						goto IL_0b9e;
																						IL_0b4c:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_0b57;
																						IL_0b57:
																						((delegate*<Class139, void>)POLICYNOTIFICATIONNS[*(int*)(ptr2 + num3)])((Class139)array2[num5 - 1]);
																						goto IL_0b80;
																						IL_0b80:
																						num5--;
																						goto IL_0b8e;
																						IL_0b8e:
																						ptr2 += 8;
																						goto end_IL_0404;
																						IL_0b9e:
																						if (20 < b)
																						{
																							break;
																						}
																						goto IL_0ba9;
																					}
																					break;
																				}
																				goto IL_040f;
																				IL_062c:
																				array[num5 - 2] = 0;
																				goto IL_0640;
																				IL_040f:
																				if (10 > b)
																				{
																					goto IL_041d;
																				}
																				goto IL_04db;
																				IL_041d:
																				if (5 >= b)
																				{
																					goto IL_042b;
																				}
																				goto IL_056c;
																				IL_042b:
																				if (5 > b)
																				{
																					goto IL_0439;
																				}
																				goto IL_0745;
																				IL_0439:
																				if (2 >= b)
																				{
																					goto IL_0444;
																				}
																				goto IL_0457;
																				IL_0444:
																				if (2 > b)
																				{
																					goto IL_0724;
																				}
																				goto IL_07b5;
																				IL_07b5:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_07f5;
																				IL_07f5:
																				array[num5 - 2] = 0;
																				goto IL_0809;
																				IL_0809:
																				num5--;
																				goto end_IL_0404;
																				IL_0724:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0732;
																				IL_0732:
																				if (1 <= b)
																				{
																				}
																				break;
																				IL_0457:
																				if (3 < b)
																				{
																					goto IL_0462;
																				}
																				goto IL_0483;
																				IL_0462:
																				if (4 < b)
																				{
																					break;
																				}
																				goto IL_0470;
																				IL_0470:
																				if (4 > b)
																				{
																					break;
																				}
																				goto IL_0550;
																				IL_0550:
																				array[num5] = 0;
																				num = 175;
																				goto IL_06d6;
																				IL_06d6:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_06f9;
																				IL_06f9:
																				array2[num5] = null;
																				goto IL_0703;
																				IL_0703:
																				num5++;
																				goto IL_0711;
																				IL_0711:
																				ptr2 += 8;
																				goto end_IL_0404;
																				IL_0483:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_0491;
																				IL_0491:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04ba;
																				IL_04ba:
																				ptr2 += 8;
																				goto IL_04c8;
																				IL_04c8:
																				num5--;
																				goto end_IL_0404;
																				IL_0745:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0785;
																				IL_0785:
																				array[num5 - 2] = 0;
																				goto IL_0799;
																				IL_0799:
																				num5--;
																				num = 145;
																				goto end_IL_0404;
																				IL_056c:
																				if (7 < b)
																				{
																					goto IL_0577;
																				}
																				goto IL_05d6;
																				IL_0577:
																				if (8 < b)
																				{
																					num = 88;
																					goto IL_058b;
																				}
																				goto IL_05b5;
																				IL_0640:
																				num5--;
																				goto end_IL_0404;
																				IL_058b:
																				if (9 < b)
																				{
																					break;
																				}
																				goto IL_0599;
																				IL_0599:
																				if (9 > b)
																				{
																					num = 182;
																					break;
																				}
																				goto IL_081c;
																				IL_04db:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_053d;
																				IL_081c:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_085c;
																				IL_085c:
																				array[num5 - 2] = 0;
																				goto IL_0870;
																				IL_0870:
																				num5--;
																				goto end_IL_0404;
																				IL_05b5:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_05c3;
																				IL_05c3:
																				num5--;
																				goto end_IL_0404;
																				IL_05d6:
																				if (7 <= b)
																				{
																					goto IL_05ec;
																				}
																				num = 81;
																				goto IL_0653;
																				IL_053d:
																				num5 -= 2;
																				goto end_IL_0404;
																				IL_0653:
																				if (6 < b)
																				{
																					break;
																				}
																				goto IL_0661;
																				IL_0661:
																				if (6 > b)
																				{
																					break;
																				}
																				goto IL_066f;
																				IL_066f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_06af;
																				IL_06af:
																				array[num5 - 2] = 0;
																				goto IL_06c3;
																				IL_06c3:
																				num5--;
																				goto end_IL_0404;
																				IL_05ec:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_062c;
																			}
																			break;
																			IL_03c9:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																	goto IL_0be6;
																	IL_0c02:
																	ptr2 += 8;
																	goto end_IL_0404;
																	IL_0bf4:
																	num5++;
																	goto IL_0c02;
																	IL_0be6:
																	array[num5] = 0;
																	goto IL_0bf4;
																	continue;
																	end_IL_03d9:
																	break;
																}
																continue;
																end_IL_03e9:
																break;
															}
															continue;
															end_IL_03f9:
															break;
														}
														continue;
														end_IL_0404:
														break;
													}
													continue;
													end_IL_0c10:
													break;
												}
												continue;
												end_IL_0c23:
												break;
											}
											continue;
											end_IL_0c2d:
											break;
										}
										continue;
										end_IL_0c38:
										break;
									}
									continue;
									end_IL_0c48:
									break;
								}
								continue;
								end_IL_0c58:
								break;
							}
							continue;
							end_IL_0c68:
							break;
						}
						continue;
						end_IL_0c78:
						break;
					}
					continue;
					end_IL_0c88:
					break;
				}
				continue;
				end_IL_0c98:
				break;
			}
		}
	}

	private unsafe void method_0()
	{
		//The blocks IL_000e, IL_001e, IL_05ef, IL_0602, IL_061b, IL_063b, IL_064b, IL_065b, IL_066b, IL_067b, IL_068b, IL_069b, IL_06a8, IL_06b8, IL_06c8, IL_06d8, IL_06e3, IL_06ee, IL_06f9, IL_070c, IL_0760, IL_076b, IL_077e, IL_0791, IL_079c, IL_07a7, IL_07ba, IL_07c8, IL_07db, IL_07e9, IL_07f4, IL_0802, IL_0815, IL_0823, IL_0861, IL_087d, IL_0886, IL_089f, IL_08ad, IL_08bb, IL_08ce, IL_091a, IL_0928, IL_0933, IL_0943, IL_0951, IL_0964, IL_0989, IL_099d, IL_09b9, IL_09c7, IL_09d5, IL_09e3, IL_09ee, IL_0a2e, IL_0a42, IL_0a55, IL_0a63, IL_0a71, IL_0a8a, IL_0a98, IL_0aa6, IL_0ab9, IL_0ac4, IL_0ad2, IL_0ae0, IL_0aee, IL_0b11, IL_0b29, IL_0b32, IL_0b40, IL_0b69, IL_0b7c, IL_0bbc, IL_0bd0, IL_0be3, IL_0bee, IL_0bfc, IL_0c07, IL_0c1a, IL_0c28, IL_0c3b, IL_0c49, IL_0c57, IL_0c97, IL_0cab, IL_0cbe, IL_0ccc, IL_0cdf, IL_0ced, IL_0cfb, IL_0d5d, IL_0d70, IL_0db0, IL_0dc4, IL_0dd7, IL_0dea, IL_0e02, IL_0e10, IL_0e1b, IL_0e29, IL_0e42, IL_0e55, IL_0e63, IL_0e71, IL_0eb1, IL_0ec5, IL_0ed8, IL_0ee1, IL_0ef5, IL_0f34, IL_0f47, IL_0f55, IL_0f60, IL_0f7e, IL_0f8c, IL_0f9f, IL_0fad, IL_0fbb, IL_0fd8, IL_1027, IL_1031, IL_105e, IL_1072, IL_1089, IL_109c, IL_10a7, IL_10ba, IL_10c8, IL_10d6, IL_10ee, IL_110c, IL_1130, IL_1148, IL_115b, IL_1184, IL_119d, IL_11ab, IL_11c3, IL_11d1, IL_11e4, IL_11f7, IL_1237, IL_124b, IL_125e, IL_127b, IL_12b3, IL_12c6, IL_12d4, IL_12e7, IL_12f5, IL_1303, IL_130c, IL_1339, IL_1347, IL_1355, IL_1368, IL_1373, IL_13b3, IL_13c7, IL_13da, IL_13e8, IL_13f6, IL_1413, IL_1465, IL_1473, IL_1486, IL_1494, IL_14a2, IL_14cc, IL_14da, IL_14ed, IL_14f6, IL_1533, IL_1547, IL_155a, IL_1565, IL_1579, IL_15b8, IL_15cb, IL_15d9, IL_15e4, IL_15fd, IL_1614, IL_1622, IL_1635, IL_1643, IL_1651, IL_165a, IL_1668, IL_167c, IL_16c8, IL_16d6, IL_16e9, IL_16f7, IL_1705, IL_172e, IL_173c, IL_174f, IL_175a, IL_1792, IL_17a6, IL_17b9, IL_17c7, IL_17d5, IL_1801, IL_180f, IL_1826, IL_1839, IL_1847, IL_1852, IL_1866, IL_18a5, IL_18c1, IL_18cf, IL_18d8, IL_18e6, IL_1903, IL_1942, IL_1955, IL_1963, IL_1971, IL_19b1, IL_19c5, IL_19d8, IL_19e3, IL_19ec, IL_19fa, IL_1a37, IL_1a4b, IL_1a5b, IL_1a66, IL_1a6f, IL_1a7a, IL_1aa3, IL_1ab1, IL_1ac1, IL_1ad4, IL_1ae7, IL_1af1, IL_1afc, IL_1b0c, IL_1b1c, IL_1b2c, IL_1b3c, IL_1b4c, IL_1b5c, IL_1b6c, IL_1b7c are reachable both inside and outside the pinned region starting at IL_1b91. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 209;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			byte* num7;
			int num8;
			int __rxRef55 = default(int);
			ref int reference = ref __rxRef55;
			object[] array8;
			int num9;
			byte* num10;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1b7c:
					num2 = 1;
					while (true)
					{
						IL_1b6c:
						num3 = num2 * 4;
						while (true)
						{
							IL_1b5c:
							num4 = num2 * 8;
							while (true)
							{
								IL_1b4c:
								array2 = new byte[4];
								while (true)
								{
									IL_1b3c:
									array3 = new object[4];
									while (true)
									{
										IL_1b2c:
										array4 = new int[4];
										while (true)
										{
											IL_1b1c:
											array5 = new int[7];
											while (true)
											{
												IL_1b0c:
												array6 = new long[4];
												while (true)
												{
													IL_1afc:
													array7 = new object[15];
													while (true)
													{
														IL_1af1:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetIssuerNameManagedMask.DynamicSecurityMethodAttributeCreateCopy);
														while (true)
														{
															IL_1ae7:
															ptr2 = ptr;
															while (true)
															{
																IL_1ad4:
																if (num5 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_06d8:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_06c8:
																		ptr2++;
																		while (true)
																		{
																			IL_06b8:
																			if (b >= 1)
																			{
																				while (b <= 44)
																				{
																					while (true)
																					{
																						IL_069b:
																						if (22 < b)
																						{
																							while (true)
																							{
																								IL_068b:
																								if (33 < b)
																								{
																									while (true)
																									{
																										IL_067b:
																										if (39 >= b)
																										{
																											while (true)
																											{
																												IL_066b:
																												if (39 > b)
																												{
																													while (true)
																													{
																														IL_065b:
																														if (36 < b)
																														{
																															while (true)
																															{
																																IL_064b:
																																if (37 >= b)
																																{
																																	while (37 <= b)
																																	{
																																		while (true)
																																		{
																																			IL_061b:
																																			array3[num6] = ((delegate*<ThemeData[]>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])();
																																			while (true)
																																			{
																																				IL_0602:
																																				array2[num6] = 5;
																																				num = 376;
																																				while (true)
																																				{
																																					if (num != 376)
																																					{
																																						if (num != 1357)
																																						{
																																							break;
																																						}
																																						switch (num)
																																						{
																																						case 209:
																																							break;
																																						default:
																																							continue;
																																						case 229:
																																							goto IL_0602;
																																						case 25:
																																						case 176:
																																							goto IL_061b;
																																						case 61:
																																							goto IL_063b;
																																						case 194:
																																							goto IL_064b;
																																						case 28:
																																							goto IL_065b;
																																						case 166:
																																							goto IL_066b;
																																						case 351:
																																							goto IL_067b;
																																						case 115:
																																							goto IL_068b;
																																						case 62:
																																							goto IL_069b;
																																						case 252:
																																							goto IL_06a8;
																																						case 221:
																																							goto IL_06b8;
																																						case 359:
																																							goto IL_06c8;
																																						case 12:
																																						case 65:
																																							goto IL_06d8;
																																						case 11:
																																							goto IL_06e3;
																																						case 136:
																																							goto IL_06ee;
																																						case 173:
																																							goto end_IL_05ef;
																																						case 96:
																																						case 188:
																																							goto IL_070c;
																																						case 224:
																																							goto IL_0760;
																																						case 149:
																																							goto IL_076b;
																																						case 247:
																																							goto IL_077e;
																																						case 302:
																																							goto IL_0791;
																																						case 257:
																																							goto IL_079c;
																																						case 104:
																																							goto IL_07a7;
																																						case 273:
																																							goto IL_07ba;
																																						case 49:
																																							goto IL_07c8;
																																						case 271:
																																							goto IL_07db;
																																						case 280:
																																							goto IL_07e9;
																																						case 119:
																																							goto IL_07f4;
																																						case 45:
																																							goto IL_0802;
																																						case 200:
																																							goto IL_0815;
																																						case 83:
																																						case 127:
																																							goto IL_0823;
																																						case 204:
																																							goto IL_0861;
																																						case 55:
																																						case 116:
																																							goto IL_0886;
																																						case 249:
																																							goto IL_089f;
																																						case 298:
																																							goto IL_08ad;
																																						case 60:
																																							goto IL_08bb;
																																						case 291:
																																						case 304:
																																							goto IL_08ce;
																																						case 314:
																																							goto IL_091a;
																																						case 15:
																																							goto IL_0928;
																																						case 54:
																																							goto IL_0933;
																																						case 264:
																																							goto IL_0943;
																																						case 100:
																																							goto IL_0951;
																																						case 26:
																																						case 318:
																																							goto IL_0964;
																																						case 325:
																																							goto IL_0989;
																																						case 186:
																																							goto IL_099d;
																																						case 333:
																																							goto IL_09b9;
																																						case 117:
																																							goto IL_09c7;
																																						case 38:
																																							goto IL_09d5;
																																						case 164:
																																							goto IL_09e3;
																																						case 6:
																																						case 222:
																																							goto IL_09ee;
																																						case 170:
																																							goto IL_0a2e;
																																						case 227:
																																							goto IL_0a42;
																																						case 147:
																																							goto IL_0a55;
																																						case 207:
																																							goto IL_0a63;
																																						case 23:
																																						case 125:
																																							goto IL_0a71;
																																						case 27:
																																							goto IL_0a8a;
																																						case 202:
																																							goto IL_0a98;
																																						case 85:
																																							goto IL_0aa6;
																																						case 120:
																																							goto IL_0ab9;
																																						case 175:
																																							goto IL_0ac4;
																																						case 153:
																																							goto IL_0ad2;
																																						case 191:
																																						case 283:
																																							goto IL_0ae0;
																																						case 51:
																																							goto IL_0aee;
																																						case 66:
																																							goto IL_0b11;
																																						case 48:
																																							goto IL_0b32;
																																						case 99:
																																						case 156:
																																							goto IL_0b40;
																																						case 246:
																																							goto IL_0b69;
																																						case 256:
																																						case 315:
																																							goto IL_0b7c;
																																						case 148:
																																							goto IL_0bbc;
																																						case 192:
																																							goto IL_0bd0;
																																						case 69:
																																							goto IL_0be3;
																																						case 190:
																																							goto IL_0bee;
																																						case 309:
																																							goto IL_0bfc;
																																						case 230:
																																							goto IL_0c07;
																																						case 196:
																																							goto IL_0c1a;
																																						case 199:
																																							goto IL_0c28;
																																						case 212:
																																							goto IL_0c3b;
																																						case 294:
																																							goto IL_0c49;
																																						case 4:
																																						case 107:
																																							goto IL_0c57;
																																						case 22:
																																							goto IL_0c97;
																																						case 77:
																																							goto IL_0cab;
																																						case 339:
																																							goto IL_0cbe;
																																						case 91:
																																							goto IL_0ccc;
																																						case 340:
																																							goto IL_0cdf;
																																						case 303:
																																							goto IL_0ced;
																																						case 274:
																																						case 285:
																																							goto IL_0cfb;
																																						case 163:
																																							goto IL_0d5d;
																																						case 112:
																																						case 341:
																																							goto IL_0d70;
																																						case 193:
																																							goto IL_0db0;
																																						case 44:
																																							goto IL_0dc4;
																																						case 139:
																																						case 342:
																																							goto IL_0dd7;
																																						case 275:
																																						case 345:
																																							goto IL_0dea;
																																						case 346:
																																							goto IL_0e02;
																																						case 336:
																																							goto IL_0e10;
																																						case 57:
																																							goto IL_0e1b;
																																						case 201:
																																						case 337:
																																							goto IL_0e29;
																																						case 141:
																																							goto IL_0e42;
																																						case 332:
																																							goto IL_0e55;
																																						case 239:
																																							goto IL_0e63;
																																						case 21:
																																						case 53:
																																							goto IL_0e71;
																																						case 240:
																																							goto IL_0eb1;
																																						case 310:
																																							goto IL_0ec5;
																																						case 220:
																																						case 270:
																																							goto IL_0ee1;
																																						case 145:
																																							goto IL_0ef5;
																																						case 121:
																																							goto IL_0f34;
																																						case 352:
																																							goto IL_0f47;
																																						case 250:
																																							goto IL_0f55;
																																						case 94:
																																						case 185:
																																							goto IL_0f60;
																																						case 157:
																																							goto IL_0f7e;
																																						case 262:
																																							goto IL_0f8c;
																																						case 338:
																																							goto IL_0f9f;
																																						case 260:
																																							goto IL_0fad;
																																						case 82:
																																						case 181:
																																							goto IL_0fbb;
																																						case 73:
																																							goto IL_1072;
																																						case 95:
																																							goto IL_1089;
																																						case 312:
																																							goto IL_109c;
																																						case 184:
																																							goto IL_10a7;
																																						case 59:
																																							goto IL_10ba;
																																						case 347:
																																							goto IL_10c8;
																																						case 36:
																																						case 289:
																																							goto IL_10d6;
																																						case 88:
																																							goto IL_10ee;
																																						case 137:
																																							goto IL_110c;
																																						case 281:
																																							goto IL_1130;
																																						case 319:
																																							goto IL_1148;
																																						case 276:
																																						case 355:
																																							goto IL_115b;
																																						case 328:
																																							goto IL_1184;
																																						case 131:
																																						case 358:
																																							goto IL_119d;
																																						case 140:
																																							goto IL_11ab;
																																						case 16:
																																							goto IL_11c3;
																																						case 292:
																																							goto IL_11d1;
																																						case 363:
																																							goto IL_11e4;
																																						case 128:
																																						case 364:
																																							goto IL_11f7;
																																						case 135:
																																							goto IL_1237;
																																						case 167:
																																							goto IL_124b;
																																						case 311:
																																						case 368:
																																							goto IL_125e;
																																						case 144:
																																							goto IL_127b;
																																						case 86:
																																							goto IL_12b3;
																																						case 290:
																																							goto IL_12d4;
																																						case 211:
																																							goto IL_12e7;
																																						case 8:
																																							goto IL_12f5;
																																						case 7:
																																						case 286:
																																							goto IL_130c;
																																						case 14:
																																							goto IL_1339;
																																						case 172:
																																							goto IL_1347;
																																						case 106:
																																							goto IL_1355;
																																						case 253:
																																							goto IL_1368;
																																						case 231:
																																						case 343:
																																							goto IL_1373;
																																						case 282:
																																							goto IL_13b3;
																																						case 108:
																																							goto IL_13c7;
																																						case 255:
																																							goto IL_13da;
																																						case 142:
																																							goto IL_13e8;
																																						case 159:
																																						case 324:
																																							goto IL_13f6;
																																						case 2:
																																							goto IL_1413;
																																						case 349:
																																							goto IL_1465;
																																						case 152:
																																							goto IL_1473;
																																						case 237:
																																							goto IL_1486;
																																						case 63:
																																							goto IL_1494;
																																						case 98:
																																						case 179:
																																							goto IL_14a2;
																																						case 226:
																																							goto IL_14cc;
																																						case 241:
																																							goto IL_14da;
																																						case 101:
																																						case 182:
																																							goto IL_14f6;
																																						case 151:
																																							goto IL_1533;
																																						case 234:
																																							goto IL_1547;
																																						case 313:
																																							goto IL_155a;
																																						case 219:
																																						case 279:
																																							goto IL_1565;
																																						case 33:
																																							goto IL_1579;
																																						case 150:
																																							goto IL_15b8;
																																						case 329:
																																							goto IL_15cb;
																																						case 34:
																																							goto IL_15d9;
																																						case 97:
																																						case 265:
																																							goto IL_15e4;
																																						case 92:
																																							goto IL_15fd;
																																						case 20:
																																							goto IL_1614;
																																						case 46:
																																							goto IL_1622;
																																						case 109:
																																							goto IL_1635;
																																						case 75:
																																							goto IL_1643;
																																						case 189:
																																							goto IL_165a;
																																						case 79:
																																						case 330:
																																							goto IL_1668;
																																						case 30:
																																							goto IL_167c;
																																						case 233:
																																							goto IL_16c8;
																																						case 197:
																																							goto IL_16d6;
																																						case 288:
																																							goto IL_16e9;
																																						case 225:
																																							goto IL_16f7;
																																						case 32:
																																						case 171:
																																							goto IL_1705;
																																						case 40:
																																							goto IL_172e;
																																						case 350:
																																							goto IL_173c;
																																						case 316:
																																							goto IL_174f;
																																						case 64:
																																						case 143:
																																							goto IL_175a;
																																						case 50:
																																							goto IL_1792;
																																						case 58:
																																							goto IL_17a6;
																																						case 47:
																																							goto IL_17b9;
																																						case 367:
																																							goto IL_17c7;
																																						case 76:
																																						case 110:
																																							goto IL_17d5;
																																						case 251:
																																							goto IL_1801;
																																						case 214:
																																							goto IL_180f;
																																						case 154:
																																							goto IL_1826;
																																						case 0:
																																							goto IL_1839;
																																						case 205:
																																							goto IL_1847;
																																						case 39:
																																						case 267:
																																							goto IL_1852;
																																						case 18:
																																							goto IL_1866;
																																						case 187:
																																							goto IL_18a5;
																																						case 1:
																																							goto IL_18c1;
																																						case 67:
																																							goto IL_18d8;
																																						case 308:
																																						case 321:
																																							goto IL_18e6;
																																						case 268:
																																							goto IL_1903;
																																						case 263:
																																							goto IL_1942;
																																						case 130:
																																							goto IL_1955;
																																						case 113:
																																							goto IL_1963;
																																						case 215:
																																						case 357:
																																							goto IL_1971;
																																						case 5:
																																							goto IL_19b1;
																																						case 361:
																																							goto IL_19c5;
																																						case 331:
																																							goto IL_19d8;
																																						case 299:
																																							goto IL_19ec;
																																						case 165:
																																						case 354:
																																							goto IL_19fa;
																																						case 366:
																																							goto IL_1a37;
																																						case 162:
																																							goto IL_1a4b;
																																						case 206:
																																							goto IL_1a5b;
																																						case 146:
																																							goto IL_1a6f;
																																						case 203:
																																						case 242:
																																							goto IL_1a7a;
																																						case 178:
																																							goto IL_1aa3;
																																						case 123:
																																							goto IL_1ab1;
																																						case 3:
																																						case 9:
																																						case 10:
																																						case 17:
																																						case 19:
																																						case 24:
																																						case 31:
																																						case 37:
																																						case 56:
																																						case 71:
																																						case 74:
																																						case 81:
																																						case 102:
																																						case 103:
																																						case 118:
																																						case 124:
																																						case 129:
																																						case 132:
																																						case 133:
																																						case 134:
																																						case 138:
																																						case 158:
																																						case 174:
																																						case 177:
																																						case 183:
																																						case 195:
																																						case 213:
																																						case 232:
																																						case 235:
																																						case 238:
																																						case 248:
																																						case 254:
																																						case 258:
																																						case 272:
																																						case 277:
																																						case 284:
																																						case 293:
																																						case 295:
																																						case 296:
																																						case 297:
																																						case 305:
																																						case 317:
																																						case 335:
																																						case 348:
																																						case 360:
																																						case 362:
																																						case 369:
																																							goto end_IL_063b;
																																						case 13:
																																						case 29:
																																						case 41:
																																						case 43:
																																						case 52:
																																						case 68:
																																						case 70:
																																						case 72:
																																						case 78:
																																						case 80:
																																						case 84:
																																						case 87:
																																						case 89:
																																						case 90:
																																						case 93:
																																						case 105:
																																						case 111:
																																						case 114:
																																						case 122:
																																						case 126:
																																						case 155:
																																						case 160:
																																						case 161:
																																						case 168:
																																						case 169:
																																						case 210:
																																						case 216:
																																						case 217:
																																						case 223:
																																						case 228:
																																						case 236:
																																						case 244:
																																						case 261:
																																						case 266:
																																						case 269:
																																						case 278:
																																						case 300:
																																						case 307:
																																						case 320:
																																						case 322:
																																						case 323:
																																						case 326:
																																						case 327:
																																						case 334:
																																						case 344:
																																						case 353:
																																						case 365:
																																							goto IL_1ad4;
																																						case 356:
																																							goto IL_1ae7;
																																						case 42:
																																							goto IL_1af1;
																																						case 245:
																																							goto IL_1afc;
																																						case 306:
																																							goto IL_1b0c;
																																						case 180:
																																							goto IL_1b1c;
																																						case 218:
																																							goto IL_1b2c;
																																						case 301:
																																							goto IL_1b3c;
																																						case 35:
																																							goto IL_1b4c;
																																						case 259:
																																							goto IL_1b5c;
																																						case 198:
																																							goto IL_1b6c;
																																						case 208:
																																							goto IL_1b7c;
																																						case 243:
																																						case 287:
																																							return;
																																						}
																																						goto end_IL_06b8;
																																					}
																																					num6++;
																																					goto IL_12d4;
																																					IL_12d4:
																																					ptr2 += 8;
																																					goto IL_1ad4;
																																					continue;
																																					end_IL_05ef:
																																					break;
																																				}
																																				break;
																																			}
																																			break;
																																		}
																																		goto IL_06f9;
																																		continue;
																																		end_IL_063b:
																																		break;
																																		IL_063b:;
																																	}
																																	break;
																																}
																																goto IL_12e7;
																																IL_1347:
																																num6++;
																																goto IL_1355;
																																IL_12e7:
																																if (38 < b)
																																{
																																	break;
																																}
																																goto IL_12f5;
																																IL_12f5:
																																if (38 > b)
																																{
																																	break;
																																}
																																num = 7;
																																goto IL_130c;
																																IL_1355:
																																ptr2 += 8;
																																goto IL_1ad4;
																																IL_130c:
																																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])();
																																num = 14;
																																goto IL_1339;
																																IL_1339:
																																array2[num6] = 0;
																																goto IL_1347;
																															}
																															break;
																														}
																														goto IL_1368;
																														IL_14da:
																														ptr2 += 8;
																														goto IL_1ad4;
																														IL_1368:
																														if (36 <= b)
																														{
																															goto IL_1373;
																														}
																														goto IL_13da;
																														IL_1373:
																														*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																														goto IL_13b3;
																														IL_13b3:
																														array2[num6 - 2] = 3;
																														goto IL_13c7;
																														IL_13c7:
																														num6--;
																														goto IL_1ad4;
																														IL_13da:
																														if (34 >= b)
																														{
																															goto IL_13e8;
																														}
																														goto IL_1486;
																														IL_13e8:
																														if (34 > b)
																														{
																															break;
																														}
																														goto IL_13f6;
																														IL_13f6:
																														array2[num6 - 2] = 0;
																														num = 2;
																														goto IL_1413;
																														IL_1413:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																														goto IL_1465;
																														IL_1465:
																														num6--;
																														goto IL_1473;
																														IL_1473:
																														ptr2 += 8;
																														goto IL_1ad4;
																														IL_1486:
																														if (35 < b)
																														{
																															break;
																														}
																														goto IL_1494;
																														IL_1494:
																														if (35 > b)
																														{
																															break;
																														}
																														goto IL_14a2;
																														IL_14a2:
																														((delegate*<bool, void>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																														goto IL_14cc;
																														IL_14cc:
																														num6--;
																														goto IL_14da;
																													}
																													break;
																												}
																												num = 101;
																												goto IL_14f6;
																												IL_1533:
																												array2[num6 - 2] = 4;
																												goto IL_1547;
																												IL_1547:
																												num6--;
																												goto IL_1ad4;
																												IL_14f6:
																												array3[num6 - 2] = ((ThemeData[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																												goto IL_1533;
																											}
																											break;
																										}
																										goto IL_091a;
																										IL_0ef5:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																										goto IL_0f34;
																										IL_091a:
																										if (42 < b)
																										{
																											goto IL_0928;
																										}
																										goto IL_0e02;
																										IL_0928:
																										if (43 >= b)
																										{
																											goto IL_0933;
																										}
																										goto IL_0943;
																										IL_0933:
																										if (43 > b)
																										{
																											break;
																										}
																										goto IL_0964;
																										IL_0964:
																										num7 = ptr2;
																										num8 = -200;
																										num5 = 1;
																										ptr2 = num7 + num8;
																										num = 278;
																										goto IL_1ad4;
																										IL_0943:
																										if (44 < b)
																										{
																											break;
																										}
																										goto IL_0951;
																										IL_0951:
																										if (44 > b)
																										{
																										}
																										break;
																										IL_0e02:
																										if (42 > b)
																										{
																											goto IL_0e10;
																										}
																										num = 220;
																										goto IL_0ee1;
																										IL_0e10:
																										if (40 >= b)
																										{
																											goto IL_0e1b;
																										}
																										goto IL_0e55;
																										IL_0e1b:
																										if (40 > b)
																										{
																											break;
																										}
																										goto IL_0e29;
																										IL_0e29:
																										global::_003CModule_003E.themeData_0 = (ThemeData)array3[num6 - 1];
																										goto IL_0e42;
																										IL_0e42:
																										num6--;
																										goto IL_1ad4;
																										IL_0e55:
																										if (41 < b)
																										{
																											break;
																										}
																										goto IL_0e63;
																										IL_0e63:
																										if (41 > b)
																										{
																											break;
																										}
																										goto IL_0e71;
																										IL_0e71:
																										*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																										goto IL_0eb1;
																										IL_0eb1:
																										array2[num6 - 2] = 3;
																										goto IL_0ec5;
																										IL_0ec5:
																										num6--;
																										goto IL_1ad4;
																										IL_0f34:
																										ptr2 += 8;
																										goto IL_1ad4;
																										IL_0ee1:
																										array2[num6 - 1] = 3;
																										goto IL_0ef5;
																									}
																									break;
																								}
																								goto IL_155a;
																								IL_1ab1:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_155a:
																								if (33 <= b)
																								{
																									goto IL_1565;
																								}
																								goto IL_15cb;
																								IL_1565:
																								array2[num6 - 1] = 3;
																								goto IL_1579;
																								IL_1579:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_15b8;
																								IL_15b8:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_15cb:
																								if (27 >= b)
																								{
																									goto IL_15d9;
																								}
																								goto IL_1839;
																								IL_15d9:
																								if (27 <= b)
																								{
																									goto IL_15e4;
																								}
																								goto IL_1635;
																								IL_15e4:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																								goto IL_15fd;
																								IL_15fd:
																								array2[num6] = 3;
																								num = 20;
																								goto IL_1614;
																								IL_1614:
																								num6++;
																								goto IL_1622;
																								IL_1622:
																								ptr2 += 16;
																								goto IL_1ad4;
																								IL_1635:
																								if (24 < b)
																								{
																									goto IL_1643;
																								}
																								goto IL_174f;
																								IL_1643:
																								if (25 >= b)
																								{
																									num = 189;
																									goto IL_165a;
																								}
																								goto IL_16e9;
																								IL_1a6f:
																								if (32 > b)
																								{
																									break;
																								}
																								goto IL_1a7a;
																								IL_165a:
																								if (25 > b)
																								{
																									break;
																								}
																								goto IL_1668;
																								IL_1668:
																								array2[num6 - 2] = 5;
																								goto IL_167c;
																								IL_167c:
																								array3[num6 - 2] = ((delegate*<string, string, string>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																								goto IL_16c8;
																								IL_16c8:
																								num6--;
																								goto IL_16d6;
																								IL_16d6:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_16e9:
																								if (26 < b)
																								{
																									break;
																								}
																								goto IL_16f7;
																								IL_16f7:
																								if (26 > b)
																								{
																									break;
																								}
																								goto IL_1705;
																								IL_1705:
																								((delegate*<string, void>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																								goto IL_172e;
																								IL_172e:
																								num6--;
																								goto IL_173c;
																								IL_173c:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_174f:
																								if (24 <= b)
																								{
																									goto IL_175a;
																								}
																								goto IL_17b9;
																								IL_175a:
																								array3[num6 - 1] = ((delegate*<ThemeData, string>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((ThemeData)array3[num6 - 1]);
																								goto IL_1792;
																								IL_1792:
																								array2[num6 - 1] = 5;
																								goto IL_17a6;
																								IL_17a6:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_17b9:
																								if (23 < b)
																								{
																									break;
																								}
																								goto IL_17c7;
																								IL_17c7:
																								if (23 > b)
																								{
																									break;
																								}
																								goto IL_17d5;
																								IL_17d5:
																								array3[num6] = ((delegate*<ThemeData>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])();
																								num = 251;
																								goto IL_1801;
																								IL_1801:
																								array2[num6] = 4;
																								goto IL_180f;
																								IL_180f:
																								num6++;
																								num = 154;
																								goto IL_1826;
																								IL_1826:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_1839:
																								if (30 >= b)
																								{
																									goto IL_1847;
																								}
																								goto IL_19d8;
																								IL_1847:
																								if (30 <= b)
																								{
																									goto IL_1852;
																								}
																								goto IL_18c1;
																								IL_1852:
																								array2[num6 - 1] = 0;
																								goto IL_1866;
																								IL_1866:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_18a5;
																								IL_18a5:
																								ptr2 += 8;
																								num = 43;
																								goto IL_1ad4;
																								IL_18c1:
																								if (28 >= b)
																								{
																									num = 67;
																									goto IL_18d8;
																								}
																								goto IL_1955;
																								IL_1a7a:
																								((delegate*<Color, void>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																								goto IL_1aa3;
																								IL_18d8:
																								if (28 > b)
																								{
																									break;
																								}
																								goto IL_18e6;
																								IL_18e6:
																								array2[num6 - 1] = 3;
																								num = 268;
																								goto IL_1903;
																								IL_1903:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																								goto IL_1942;
																								IL_1942:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_1955:
																								if (29 < b)
																								{
																									break;
																								}
																								goto IL_1963;
																								IL_1963:
																								if (29 > b)
																								{
																									break;
																								}
																								goto IL_1971;
																								IL_1971:
																								*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																								goto IL_19b1;
																								IL_19b1:
																								array2[num6 - 2] = 3;
																								goto IL_19c5;
																								IL_19c5:
																								num6--;
																								goto IL_1ad4;
																								IL_19d8:
																								if (31 >= b)
																								{
																									num = 299;
																									goto IL_19ec;
																								}
																								goto IL_1a5b;
																								IL_1aa3:
																								num6--;
																								goto IL_1ab1;
																								IL_19ec:
																								if (31 > b)
																								{
																									break;
																								}
																								goto IL_19fa;
																								IL_19fa:
																								array3[num6 - 1] = ((delegate*<ThemeData, Color>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((ThemeData)array3[num6 - 1]);
																								goto IL_1a37;
																								IL_1a37:
																								array2[num6 - 1] = 4;
																								goto IL_1a4b;
																								IL_1a4b:
																								ptr2 += 8;
																								goto IL_1ad4;
																								IL_1a5b:
																								if (32 < b)
																								{
																									break;
																								}
																								num = 146;
																								goto IL_1a6f;
																							}
																							break;
																						}
																						goto IL_06e3;
																						IL_0886:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																						goto IL_089f;
																						IL_06e3:
																						if (22 > b)
																						{
																							goto IL_06ee;
																						}
																						goto IL_070c;
																						IL_06ee:
																						if (11 >= b)
																						{
																							goto IL_06f9;
																						}
																						goto IL_0760;
																						IL_06f9:
																						if (11 <= b)
																						{
																							goto IL_1ad4;
																						}
																						goto IL_09b9;
																						IL_09b9:
																						if (5 >= b)
																						{
																							goto IL_09c7;
																						}
																						goto IL_0be3;
																						IL_09c7:
																						if (5 > b)
																						{
																							goto IL_09d5;
																						}
																						goto IL_0b7c;
																						IL_09d5:
																						if (2 >= b)
																						{
																							goto IL_09e3;
																						}
																						goto IL_0ab9;
																						IL_09e3:
																						if (2 <= b)
																						{
																							goto IL_09ee;
																						}
																						goto IL_0a55;
																						IL_09ee:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0a2e;
																						IL_0a2e:
																						array2[num6 - 2] = 0;
																						goto IL_0a42;
																						IL_0a42:
																						num6--;
																						goto IL_1ad4;
																						IL_0a55:
																						if (1 < b)
																						{
																							break;
																						}
																						goto IL_0a63;
																						IL_0a63:
																						if (1 > b)
																						{
																							break;
																						}
																						goto IL_0a71;
																						IL_0a71:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																						goto IL_0a8a;
																						IL_0a8a:
																						array2[num6] = 0;
																						goto IL_0a98;
																						IL_0a98:
																						num6++;
																						goto IL_0aa6;
																						IL_0aa6:
																						ptr2 += 8;
																						goto IL_1ad4;
																						IL_0ab9:
																						if (3 < b)
																						{
																							goto IL_0ac4;
																						}
																						num = 48;
																						goto IL_0b32;
																						IL_0ac4:
																						if (4 < b)
																						{
																							break;
																						}
																						goto IL_0ad2;
																						IL_0ad2:
																						if (4 > b)
																						{
																							break;
																						}
																						goto IL_0ae0;
																						IL_0ae0:
																						array2[num6] = 0;
																						goto IL_0aee;
																						IL_0aee:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																						goto IL_0b11;
																						IL_0b11:
																						array3[num6] = null;
																						num = 339;
																						goto IL_0cbe;
																						IL_0cbe:
																						num6++;
																						goto IL_0ccc;
																						IL_0ccc:
																						ptr2 += 8;
																						goto IL_1ad4;
																						IL_089f:
																						array2[num6] = 1;
																						goto IL_08ad;
																						IL_0b32:
																						if (3 > b)
																						{
																							break;
																						}
																						goto IL_0b40;
																						IL_0b40:
																						reference = ref array5[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0b69;
																						IL_0b69:
																						ptr2 += 8;
																						goto IL_11e4;
																						IL_11e4:
																						num6--;
																						goto IL_1ad4;
																						IL_0b7c:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0bbc;
																						IL_0bbc:
																						array2[num6 - 2] = 0;
																						goto IL_0bd0;
																						IL_0bd0:
																						num6--;
																						goto IL_1ad4;
																						IL_0be3:
																						if (8 >= b)
																						{
																							goto IL_0bee;
																						}
																						goto IL_0c3b;
																						IL_0bee:
																						if (8 > b)
																						{
																							goto IL_0bfc;
																						}
																						goto IL_0dd7;
																						IL_0bfc:
																						if (6 >= b)
																						{
																							goto IL_0c07;
																						}
																						goto IL_0c1a;
																						IL_0c07:
																						if (6 > b)
																						{
																							break;
																						}
																						goto IL_0d70;
																						IL_0d70:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0db0;
																						IL_0db0:
																						array2[num6 - 2] = 0;
																						goto IL_0dc4;
																						IL_0dc4:
																						num6--;
																						goto IL_1ad4;
																						IL_0c1a:
																						if (7 < b)
																						{
																							break;
																						}
																						goto IL_0c28;
																						IL_0c28:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_11f7;
																						IL_11f7:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1237;
																						IL_1237:
																						array2[num6 - 2] = 0;
																						goto IL_124b;
																						IL_124b:
																						num6--;
																						goto IL_1ad4;
																						IL_0dd7:
																						num6--;
																						goto IL_1ad4;
																						IL_0c3b:
																						if (9 >= b)
																						{
																							goto IL_0c49;
																						}
																						goto IL_0cdf;
																						IL_0c49:
																						if (9 > b)
																						{
																							break;
																						}
																						goto IL_0c57;
																						IL_0c57:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_0c97;
																						IL_0c97:
																						array2[num6 - 2] = 0;
																						goto IL_0cab;
																						IL_0cab:
																						num6--;
																						goto IL_1ad4;
																						IL_0cdf:
																						if (10 < b)
																						{
																							break;
																						}
																						goto IL_0ced;
																						IL_0ced:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_0cfb;
																						IL_0cfb:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0d5d;
																						IL_0d5d:
																						num6 -= 2;
																						goto IL_1ad4;
																						IL_0760:
																						if (16 >= b)
																						{
																							goto IL_076b;
																						}
																						goto IL_0791;
																						IL_076b:
																						if (16 > b)
																						{
																							goto IL_0f47;
																						}
																						goto IL_119d;
																						IL_119d:
																						array2[num6] = 5;
																						goto IL_11ab;
																						IL_11ab:
																						array3[num6] = array7[*(int*)(ptr2 + num3)];
																						goto IL_11c3;
																						IL_11c3:
																						num6++;
																						goto IL_11d1;
																						IL_11d1:
																						ptr2 += 8;
																						goto IL_1ad4;
																						IL_0f47:
																						if (13 >= b)
																						{
																							goto IL_0f55;
																						}
																						goto IL_109c;
																						IL_0f55:
																						if (13 <= b)
																						{
																							goto IL_0f60;
																						}
																						goto IL_0f9f;
																						IL_0f60:
																						array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																						goto IL_0f7e;
																						IL_0f7e:
																						ptr2 += 8;
																						goto IL_0f8c;
																						IL_0f8c:
																						num6--;
																						goto IL_1ad4;
																						IL_0f9f:
																						if (12 < b)
																						{
																							break;
																						}
																						goto IL_0fad;
																						IL_0fad:
																						if (12 > b)
																						{
																							break;
																						}
																						goto IL_0fbb;
																						IL_0fbb:
																						array8 = array3;
																						num9 = num6;
																						if (array == null)
																						{
																							goto IL_0fca;
																						}
																						num10 = ptr2;
																						byte b2 = *num10;
																						ptr2 = num10 + 4;
																						int num11 = *(int*)(ptr2 + num3);
																						ptr2 += 8;
																						byte* ptr3 = ptr2 + num11;
																						byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																						while (ptr2 != ptr3)
																						{
																							*ptr4 = (byte)(*ptr2 ^ b2);
																							ptr2++;
																							ptr4++;
																						}
																						array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																						goto IL_1072;
																						IL_08ad:
																						num6++;
																						goto IL_08bb;
																						IL_08bb:
																						ptr2 += 16;
																						goto IL_1ad4;
																						IL_070c:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_077e;
																						IL_1072:
																						array2[num6] = 5;
																						num = 95;
																						goto IL_1089;
																						IL_1089:
																						num6++;
																						goto IL_1ad4;
																						IL_109c:
																						if (14 >= b)
																						{
																							goto IL_10a7;
																						}
																						goto IL_10ba;
																						IL_10a7:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_115b;
																						IL_115b:
																						array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																						goto IL_1184;
																						IL_1184:
																						array2[num6 - 1] = 5;
																						goto IL_1ad4;
																						IL_10ba:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_10c8;
																						IL_10c8:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_10d6;
																						IL_10d6:
																						array2[num6] = array2[num6 - 1];
																						goto IL_10ee;
																						IL_10ee:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_110c;
																						IL_110c:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_1130;
																						IL_1130:
																						array3[num6] = array3[num6 - 1];
																						goto IL_1148;
																						IL_1148:
																						num6++;
																						goto IL_1ad4;
																						IL_0791:
																						if (19 < b)
																						{
																							goto IL_079c;
																						}
																						goto IL_07db;
																						IL_079c:
																						if (20 >= b)
																						{
																							goto IL_07a7;
																						}
																						goto IL_07ba;
																						IL_07a7:
																						if (20 > b)
																						{
																							break;
																						}
																						goto IL_0dea;
																						IL_0dea:
																						ptr2 = ptr + *(int*)(ptr2 + num3);
																						goto IL_1ad4;
																						IL_07ba:
																						if (21 < b)
																						{
																							break;
																						}
																						goto IL_07c8;
																						IL_07c8:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_08ce;
																						IL_08ce:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																						num = 325;
																						goto IL_0989;
																						IL_0989:
																						array2[num6 - 2] = 0;
																						goto IL_099d;
																						IL_099d:
																						num6--;
																						num = 89;
																						goto IL_1ad4;
																						IL_07db:
																						if (19 > b)
																						{
																							goto IL_07e9;
																						}
																						num = 116;
																						goto IL_0886;
																						IL_07e9:
																						if (17 < b)
																						{
																							goto IL_07f4;
																						}
																						goto IL_0815;
																						IL_07f4:
																						if (18 < b)
																						{
																							break;
																						}
																						goto IL_0802;
																						IL_0802:
																						if (18 > b)
																						{
																							break;
																						}
																						goto IL_125e;
																						IL_125e:
																						array2[num6 - 1] = 5;
																						num = 144;
																						goto IL_127b;
																						IL_127b:
																						array3[num6 - 1] = ((delegate*<string[], string>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_12b3;
																						IL_12b3:
																						ptr2 += 8;
																						goto IL_1ad4;
																						IL_0815:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_0823;
																						IL_0823:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_0861;
																						IL_0861:
																						num6 -= 3;
																						num = 353;
																						goto IL_1ad4;
																						IL_077e:
																						num6--;
																						goto IL_1ad4;
																					}
																					break;
																					IL_06a8:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto IL_1ad4;
																			continue;
																			end_IL_06b8:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0fca:
			while (true)
			{
				IL_0fca_2:
				array = new byte[4];
				while (true)
				{
					IL_0fd8:
					num10 = ptr2;
					byte b2 = *num10;
					ptr2 = num10 + 4;
					int num11 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num11;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num9] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					while (true)
					{
						array2[num6] = 5;
						num = 95;
						while (true)
						{
							IL_1089_2:
							num6++;
							while (true)
							{
								IL_1ad4_2:
								if (num5 == 1)
								{
									return;
								}
								while (true)
								{
									byte b = *ptr2;
									while (true)
									{
										ptr2++;
										while (true)
										{
											IL_06b8_2:
											if (b >= 1)
											{
												while (b <= 44)
												{
													while (true)
													{
														IL_069b_2:
														if (22 < b)
														{
															while (true)
															{
																IL_068b_2:
																if (33 < b)
																{
																	while (true)
																	{
																		IL_067b_2:
																		if (39 >= b)
																		{
																			while (true)
																			{
																				IL_066b_2:
																				if (39 > b)
																				{
																					while (true)
																					{
																						IL_065b_2:
																						if (36 < b)
																						{
																							while (true)
																							{
																								IL_064b_2:
																								if (37 >= b)
																								{
																									while (37 <= b)
																									{
																										while (true)
																										{
																											IL_061b_2:
																											array3[num6] = ((delegate*<ThemeData[]>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])();
																											while (true)
																											{
																												IL_0602_2:
																												array2[num6] = 5;
																												num = 376;
																												while (true)
																												{
																													if (num != 376)
																													{
																														if (num != 1357)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 229:
																															goto IL_0602_2;
																														case 25:
																														case 176:
																															goto IL_061b_2;
																														case 61:
																															goto IL_063b_2;
																														case 194:
																															goto IL_064b_2;
																														case 28:
																															goto IL_065b_2;
																														case 166:
																															goto IL_066b_2;
																														case 351:
																															goto IL_067b_2;
																														case 115:
																															goto IL_068b_2;
																														case 62:
																															goto IL_069b_2;
																														case 252:
																															goto IL_06a8_2;
																														case 221:
																															goto IL_06b8_2;
																														case 359:
																															goto end_IL_06b8_2;
																														case 12:
																														case 65:
																															goto end_IL_06c8;
																														case 11:
																															goto IL_06e3_2;
																														case 136:
																															goto IL_06ee_2;
																														case 173:
																															goto end_IL_05ef_2;
																														case 96:
																														case 188:
																															goto IL_070c_2;
																														case 224:
																															goto IL_0760_2;
																														case 149:
																															goto IL_076b_2;
																														case 247:
																															goto IL_077e_2;
																														case 302:
																															goto IL_0791_2;
																														case 257:
																															goto IL_079c_2;
																														case 104:
																															goto IL_07a7_2;
																														case 273:
																															goto IL_07ba_2;
																														case 49:
																															goto IL_07c8_2;
																														case 271:
																															goto IL_07db_2;
																														case 280:
																															goto IL_07e9_2;
																														case 119:
																															goto IL_07f4_2;
																														case 45:
																															goto IL_0802_2;
																														case 200:
																															goto IL_0815_2;
																														case 83:
																														case 127:
																															goto IL_0823_2;
																														case 204:
																															goto IL_0861_2;
																														case 55:
																														case 116:
																															goto IL_0886_2;
																														case 249:
																															goto IL_089f_2;
																														case 298:
																															goto IL_08ad_2;
																														case 60:
																															goto IL_08bb_2;
																														case 291:
																														case 304:
																															goto IL_08ce_2;
																														case 314:
																															goto IL_091a_2;
																														case 15:
																															goto IL_0928_2;
																														case 54:
																															goto IL_0933_2;
																														case 264:
																															goto IL_0943_2;
																														case 100:
																															goto IL_0951_2;
																														case 26:
																														case 318:
																															goto IL_0964_2;
																														case 325:
																															goto IL_0989_2;
																														case 186:
																															goto IL_099d_2;
																														case 333:
																															goto IL_09b9_2;
																														case 117:
																															goto IL_09c7_2;
																														case 38:
																															goto IL_09d5_2;
																														case 164:
																															goto IL_09e3_2;
																														case 6:
																														case 222:
																															goto IL_09ee_2;
																														case 170:
																															goto IL_0a2e_2;
																														case 227:
																															goto IL_0a42_2;
																														case 147:
																															goto IL_0a55_2;
																														case 207:
																															goto IL_0a63_2;
																														case 23:
																														case 125:
																															goto IL_0a71_2;
																														case 27:
																															goto IL_0a8a_2;
																														case 202:
																															goto IL_0a98_2;
																														case 85:
																															goto IL_0aa6_2;
																														case 120:
																															goto IL_0ab9_2;
																														case 175:
																															goto IL_0ac4_2;
																														case 153:
																															goto IL_0ad2_2;
																														case 191:
																														case 283:
																															goto IL_0ae0_2;
																														case 51:
																															goto IL_0aee_2;
																														case 66:
																															goto IL_0b11_2;
																														case 48:
																															goto IL_0b32_2;
																														case 99:
																														case 156:
																															goto IL_0b40_2;
																														case 246:
																															goto IL_0b69_2;
																														case 256:
																														case 315:
																															goto IL_0b7c_2;
																														case 148:
																															goto IL_0bbc_2;
																														case 192:
																															goto IL_0bd0_2;
																														case 69:
																															goto IL_0be3_2;
																														case 190:
																															goto IL_0bee_2;
																														case 309:
																															goto IL_0bfc_2;
																														case 230:
																															goto IL_0c07_2;
																														case 196:
																															goto IL_0c1a_2;
																														case 199:
																															goto IL_0c28_2;
																														case 212:
																															goto IL_0c3b_2;
																														case 294:
																															goto IL_0c49_2;
																														case 4:
																														case 107:
																															goto IL_0c57_2;
																														case 22:
																															goto IL_0c97_2;
																														case 77:
																															goto IL_0cab_2;
																														case 339:
																															goto IL_0cbe_2;
																														case 91:
																															goto IL_0ccc_2;
																														case 340:
																															goto IL_0cdf_2;
																														case 303:
																															goto IL_0ced_2;
																														case 274:
																														case 285:
																															goto IL_0cfb_2;
																														case 163:
																															goto IL_0d5d_2;
																														case 112:
																														case 341:
																															goto IL_0d70_2;
																														case 193:
																															goto IL_0db0_2;
																														case 44:
																															goto IL_0dc4_2;
																														case 139:
																														case 342:
																															goto IL_0dd7_2;
																														case 275:
																														case 345:
																															goto IL_0dea_2;
																														case 346:
																															goto IL_0e02_2;
																														case 336:
																															goto IL_0e10_2;
																														case 57:
																															goto IL_0e1b_2;
																														case 201:
																														case 337:
																															goto IL_0e29_2;
																														case 141:
																															goto IL_0e42_2;
																														case 332:
																															goto IL_0e55_2;
																														case 239:
																															goto IL_0e63_2;
																														case 21:
																														case 53:
																															goto IL_0e71_2;
																														case 240:
																															goto IL_0eb1_2;
																														case 310:
																															goto IL_0ec5_2;
																														case 220:
																														case 270:
																															goto IL_0ee1_2;
																														case 145:
																															goto IL_0ef5_2;
																														case 121:
																															goto IL_0f34_2;
																														case 352:
																															goto IL_0f47_2;
																														case 250:
																															goto IL_0f55_2;
																														case 94:
																														case 185:
																															goto IL_0f60_2;
																														case 157:
																															goto IL_0f7e_2;
																														case 262:
																															goto IL_0f8c_2;
																														case 338:
																															goto IL_0f9f_2;
																														case 260:
																															goto IL_0fad_2;
																														case 82:
																														case 181:
																															goto IL_0fbb_2;
																														case 73:
																															goto end_IL_06d8;
																														case 95:
																															goto IL_1089_2;
																														case 312:
																															goto IL_109c_2;
																														case 184:
																															goto IL_10a7_2;
																														case 59:
																															goto IL_10ba_2;
																														case 347:
																															goto IL_10c8_2;
																														case 36:
																														case 289:
																															goto IL_10d6_2;
																														case 88:
																															goto IL_10ee_2;
																														case 137:
																															goto IL_110c_2;
																														case 281:
																															goto IL_1130_2;
																														case 319:
																															goto IL_1148_2;
																														case 276:
																														case 355:
																															goto IL_115b_2;
																														case 328:
																															goto IL_1184_2;
																														case 131:
																														case 358:
																															goto IL_119d_2;
																														case 140:
																															goto IL_11ab_2;
																														case 16:
																															goto IL_11c3_2;
																														case 292:
																															goto IL_11d1_2;
																														case 363:
																															goto IL_11e4_2;
																														case 128:
																														case 364:
																															goto IL_11f7_2;
																														case 135:
																															goto IL_1237_2;
																														case 167:
																															goto IL_124b_2;
																														case 311:
																														case 368:
																															goto IL_125e_2;
																														case 144:
																															goto IL_127b_2;
																														case 86:
																															goto IL_12b3_2;
																														case 290:
																															goto IL_12d4_2;
																														case 211:
																															goto IL_12e7_2;
																														case 8:
																															goto IL_12f5_2;
																														case 7:
																														case 286:
																															goto IL_130c_2;
																														case 14:
																															goto IL_1339_2;
																														case 172:
																															goto IL_1347_2;
																														case 106:
																															goto IL_1355_2;
																														case 253:
																															goto IL_1368_2;
																														case 231:
																														case 343:
																															goto IL_1373_2;
																														case 282:
																															goto IL_13b3_2;
																														case 108:
																															goto IL_13c7_2;
																														case 255:
																															goto IL_13da_2;
																														case 142:
																															goto IL_13e8_2;
																														case 159:
																														case 324:
																															goto IL_13f6_2;
																														case 2:
																															goto IL_1413_2;
																														case 349:
																															goto IL_1465_2;
																														case 152:
																															goto IL_1473_2;
																														case 237:
																															goto IL_1486_2;
																														case 63:
																															goto IL_1494_2;
																														case 98:
																														case 179:
																															goto IL_14a2_2;
																														case 226:
																															goto IL_14cc_2;
																														case 241:
																															goto IL_14da_2;
																														case 101:
																														case 182:
																															goto IL_14f6_2;
																														case 151:
																															goto IL_1533_2;
																														case 234:
																															goto IL_1547_2;
																														case 313:
																															goto IL_155a_2;
																														case 219:
																														case 279:
																															goto IL_1565_2;
																														case 33:
																															goto IL_1579_2;
																														case 150:
																															goto IL_15b8_2;
																														case 329:
																															goto IL_15cb_2;
																														case 34:
																															goto IL_15d9_2;
																														case 97:
																														case 265:
																															goto IL_15e4_2;
																														case 92:
																															goto IL_15fd_2;
																														case 20:
																															goto IL_1614_2;
																														case 46:
																															goto IL_1622_2;
																														case 109:
																															goto IL_1635_2;
																														case 75:
																															goto IL_1643_2;
																														case 189:
																															goto IL_165a_2;
																														case 79:
																														case 330:
																															goto IL_1668_2;
																														case 30:
																															goto IL_167c_2;
																														case 233:
																															goto IL_16c8_2;
																														case 197:
																															goto IL_16d6_2;
																														case 288:
																															goto IL_16e9_2;
																														case 225:
																															goto IL_16f7_2;
																														case 32:
																														case 171:
																															goto IL_1705_2;
																														case 40:
																															goto IL_172e_2;
																														case 350:
																															goto IL_173c_2;
																														case 316:
																															goto IL_174f_2;
																														case 64:
																														case 143:
																															goto IL_175a_2;
																														case 50:
																															goto IL_1792_2;
																														case 58:
																															goto IL_17a6_2;
																														case 47:
																															goto IL_17b9_2;
																														case 367:
																															goto IL_17c7_2;
																														case 76:
																														case 110:
																															goto IL_17d5_2;
																														case 251:
																															goto IL_1801_2;
																														case 214:
																															goto IL_180f_2;
																														case 154:
																															goto IL_1826_2;
																														case 0:
																															goto IL_1839_2;
																														case 205:
																															goto IL_1847_2;
																														case 39:
																														case 267:
																															goto IL_1852_2;
																														case 18:
																															goto IL_1866_2;
																														case 187:
																															goto IL_18a5_2;
																														case 1:
																															goto IL_18c1_2;
																														case 67:
																															goto IL_18d8_2;
																														case 308:
																														case 321:
																															goto IL_18e6_2;
																														case 268:
																															goto IL_1903_2;
																														case 263:
																															goto IL_1942_2;
																														case 130:
																															goto IL_1955_2;
																														case 113:
																															goto IL_1963_2;
																														case 215:
																														case 357:
																															goto IL_1971_2;
																														case 5:
																															goto IL_19b1_2;
																														case 361:
																															goto IL_19c5_2;
																														case 331:
																															goto IL_19d8_2;
																														case 299:
																															goto IL_19ec_2;
																														case 165:
																														case 354:
																															goto IL_19fa_2;
																														case 366:
																															goto IL_1a37_2;
																														case 162:
																															goto IL_1a4b_2;
																														case 206:
																															goto IL_1a5b_2;
																														case 146:
																															goto IL_1a6f_2;
																														case 203:
																														case 242:
																															goto IL_1a7a_2;
																														case 178:
																															goto IL_1aa3_2;
																														case 123:
																															goto IL_1ab1_2;
																														case 3:
																														case 9:
																														case 10:
																														case 17:
																														case 19:
																														case 24:
																														case 31:
																														case 37:
																														case 56:
																														case 71:
																														case 74:
																														case 81:
																														case 102:
																														case 103:
																														case 118:
																														case 124:
																														case 129:
																														case 132:
																														case 133:
																														case 134:
																														case 138:
																														case 158:
																														case 174:
																														case 177:
																														case 183:
																														case 195:
																														case 213:
																														case 232:
																														case 235:
																														case 238:
																														case 248:
																														case 254:
																														case 258:
																														case 272:
																														case 277:
																														case 284:
																														case 293:
																														case 295:
																														case 296:
																														case 297:
																														case 305:
																														case 317:
																														case 335:
																														case 348:
																														case 360:
																														case 362:
																														case 369:
																															goto end_IL_063b_2;
																														case 13:
																														case 29:
																														case 41:
																														case 43:
																														case 52:
																														case 68:
																														case 70:
																														case 72:
																														case 78:
																														case 80:
																														case 84:
																														case 87:
																														case 89:
																														case 90:
																														case 93:
																														case 105:
																														case 111:
																														case 114:
																														case 122:
																														case 126:
																														case 155:
																														case 160:
																														case 161:
																														case 168:
																														case 169:
																														case 210:
																														case 216:
																														case 217:
																														case 223:
																														case 228:
																														case 236:
																														case 244:
																														case 261:
																														case 266:
																														case 269:
																														case 278:
																														case 300:
																														case 307:
																														case 320:
																														case 322:
																														case 323:
																														case 326:
																														case 327:
																														case 334:
																														case 344:
																														case 353:
																														case 365:
																															goto IL_1ad4_2;
																														case 356:
																															ptr2 = ptr;
																															goto IL_1ad4_2;
																														case 42:
																															ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetIssuerNameManagedMask.DynamicSecurityMethodAttributeCreateCopy);
																															goto case 356;
																														case 245:
																															array7 = new object[15];
																															goto case 42;
																														case 306:
																															array6 = new long[4];
																															goto case 245;
																														case 180:
																															array5 = new int[7];
																															goto case 306;
																														case 218:
																															array4 = new int[4];
																															goto case 180;
																														case 301:
																															array3 = new object[4];
																															goto case 218;
																														case 35:
																															array2 = new byte[4];
																															goto case 301;
																														case 259:
																															num4 = num2 * 8;
																															goto case 35;
																														case 198:
																															num3 = num2 * 4;
																															goto case 259;
																														case 208:
																															num2 = 1;
																															goto case 198;
																														case 209:
																															goto end_IL_1072;
																														case 243:
																														case 287:
																															return;
																														}
																														continue;
																													}
																													num6++;
																													goto IL_12d4_2;
																													IL_12d4_2:
																													ptr2 += 8;
																													goto IL_1ad4_2;
																													continue;
																													end_IL_05ef_2:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_06f9_2;
																										continue;
																										end_IL_063b_2:
																										break;
																										IL_063b_2:;
																									}
																									break;
																								}
																								goto IL_12e7_2;
																								IL_1347_2:
																								num6++;
																								goto IL_1355_2;
																								IL_12e7_2:
																								if (38 < b)
																								{
																									break;
																								}
																								goto IL_12f5_2;
																								IL_12f5_2:
																								if (38 > b)
																								{
																									break;
																								}
																								num = 7;
																								goto IL_130c_2;
																								IL_1355_2:
																								ptr2 += 8;
																								goto IL_1ad4_2;
																								IL_130c_2:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])();
																								num = 14;
																								goto IL_1339_2;
																								IL_1339_2:
																								array2[num6] = 0;
																								goto IL_1347_2;
																							}
																							break;
																						}
																						goto IL_1368_2;
																						IL_14da_2:
																						ptr2 += 8;
																						goto IL_1ad4_2;
																						IL_1368_2:
																						if (36 <= b)
																						{
																							goto IL_1373_2;
																						}
																						goto IL_13da_2;
																						IL_1373_2:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) - *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																						goto IL_13b3_2;
																						IL_13b3_2:
																						array2[num6 - 2] = 3;
																						goto IL_13c7_2;
																						IL_13c7_2:
																						num6--;
																						goto IL_1ad4_2;
																						IL_13da_2:
																						if (34 >= b)
																						{
																							goto IL_13e8_2;
																						}
																						goto IL_1486_2;
																						IL_13e8_2:
																						if (34 > b)
																						{
																							break;
																						}
																						goto IL_13f6_2;
																						IL_13f6_2:
																						array2[num6 - 2] = 0;
																						num = 2;
																						goto IL_1413_2;
																						IL_1413_2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = (((delegate*<string, string, bool>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]) ? 1 : 0);
																						goto IL_1465_2;
																						IL_1465_2:
																						num6--;
																						goto IL_1473_2;
																						IL_1473_2:
																						ptr2 += 8;
																						goto IL_1ad4_2;
																						IL_1486_2:
																						if (35 < b)
																						{
																							break;
																						}
																						goto IL_1494_2;
																						IL_1494_2:
																						if (35 > b)
																						{
																							break;
																						}
																						goto IL_14a2_2;
																						IL_14a2_2:
																						((delegate*<bool, void>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((byte)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) != 0);
																						goto IL_14cc_2;
																						IL_14cc_2:
																						num6--;
																						goto IL_14da_2;
																					}
																					break;
																				}
																				num = 101;
																				goto IL_14f6_2;
																				IL_1533_2:
																				array2[num6 - 2] = 4;
																				goto IL_1547_2;
																				IL_1547_2:
																				num6--;
																				goto IL_1ad4_2;
																				IL_14f6_2:
																				array3[num6 - 2] = ((ThemeData[])array3[num6 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																				goto IL_1533_2;
																			}
																			break;
																		}
																		goto IL_091a_2;
																		IL_0ef5_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																		goto IL_0f34_2;
																		IL_091a_2:
																		if (42 < b)
																		{
																			goto IL_0928_2;
																		}
																		goto IL_0e02_2;
																		IL_0928_2:
																		if (43 >= b)
																		{
																			goto IL_0933_2;
																		}
																		goto IL_0943_2;
																		IL_0933_2:
																		if (43 > b)
																		{
																			break;
																		}
																		goto IL_0964_2;
																		IL_0964_2:
																		num7 = ptr2;
																		num8 = -200;
																		num5 = 1;
																		ptr2 = num7 + num8;
																		num = 278;
																		goto IL_1ad4_2;
																		IL_0943_2:
																		if (44 < b)
																		{
																			break;
																		}
																		goto IL_0951_2;
																		IL_0951_2:
																		if (44 > b)
																		{
																		}
																		break;
																		IL_0e02_2:
																		if (42 > b)
																		{
																			goto IL_0e10_2;
																		}
																		num = 220;
																		goto IL_0ee1_2;
																		IL_0e10_2:
																		if (40 >= b)
																		{
																			goto IL_0e1b_2;
																		}
																		goto IL_0e55_2;
																		IL_0e1b_2:
																		if (40 > b)
																		{
																			break;
																		}
																		goto IL_0e29_2;
																		IL_0e29_2:
																		global::_003CModule_003E.themeData_0 = (ThemeData)array3[num6 - 1];
																		goto IL_0e42_2;
																		IL_0e42_2:
																		num6--;
																		goto IL_1ad4_2;
																		IL_0e55_2:
																		if (41 < b)
																		{
																			break;
																		}
																		goto IL_0e63_2;
																		IL_0e63_2:
																		if (41 > b)
																		{
																			break;
																		}
																		goto IL_0e71_2;
																		IL_0e71_2:
																		*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																		goto IL_0eb1_2;
																		IL_0eb1_2:
																		array2[num6 - 2] = 3;
																		goto IL_0ec5_2;
																		IL_0ec5_2:
																		num6--;
																		goto IL_1ad4_2;
																		IL_0f34_2:
																		ptr2 += 8;
																		goto IL_1ad4_2;
																		IL_0ee1_2:
																		array2[num6 - 1] = 3;
																		goto IL_0ef5_2;
																	}
																	break;
																}
																goto IL_155a_2;
																IL_1ab1_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_155a_2:
																if (33 <= b)
																{
																	goto IL_1565_2;
																}
																goto IL_15cb_2;
																IL_1565_2:
																array2[num6 - 1] = 3;
																goto IL_1579_2;
																IL_1579_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_15b8_2;
																IL_15b8_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_15cb_2:
																if (27 >= b)
																{
																	goto IL_15d9_2;
																}
																goto IL_1839_2;
																IL_15d9_2:
																if (27 <= b)
																{
																	goto IL_15e4_2;
																}
																goto IL_1635_2;
																IL_15e4_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(double*)(ptr2 + num4);
																goto IL_15fd_2;
																IL_15fd_2:
																array2[num6] = 3;
																num = 20;
																goto IL_1614_2;
																IL_1614_2:
																num6++;
																goto IL_1622_2;
																IL_1622_2:
																ptr2 += 16;
																goto IL_1ad4_2;
																IL_1635_2:
																if (24 < b)
																{
																	goto IL_1643_2;
																}
																goto IL_174f_2;
																IL_1643_2:
																if (25 >= b)
																{
																	num = 189;
																	goto IL_165a_2;
																}
																goto IL_16e9_2;
																IL_1a6f_2:
																if (32 > b)
																{
																	break;
																}
																goto IL_1a7a_2;
																IL_165a_2:
																if (25 > b)
																{
																	break;
																}
																goto IL_1668_2;
																IL_1668_2:
																array2[num6 - 2] = 5;
																goto IL_167c_2;
																IL_167c_2:
																array3[num6 - 2] = ((delegate*<string, string, string>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																goto IL_16c8_2;
																IL_16c8_2:
																num6--;
																goto IL_16d6_2;
																IL_16d6_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_16e9_2:
																if (26 < b)
																{
																	break;
																}
																goto IL_16f7_2;
																IL_16f7_2:
																if (26 > b)
																{
																	break;
																}
																goto IL_1705_2;
																IL_1705_2:
																((delegate*<string, void>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string)array3[num6 - 1]);
																goto IL_172e_2;
																IL_172e_2:
																num6--;
																goto IL_173c_2;
																IL_173c_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_174f_2:
																if (24 <= b)
																{
																	goto IL_175a_2;
																}
																goto IL_17b9_2;
																IL_175a_2:
																array3[num6 - 1] = ((delegate*<ThemeData, string>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((ThemeData)array3[num6 - 1]);
																goto IL_1792_2;
																IL_1792_2:
																array2[num6 - 1] = 5;
																goto IL_17a6_2;
																IL_17a6_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_17b9_2:
																if (23 < b)
																{
																	break;
																}
																goto IL_17c7_2;
																IL_17c7_2:
																if (23 > b)
																{
																	break;
																}
																goto IL_17d5_2;
																IL_17d5_2:
																array3[num6] = ((delegate*<ThemeData>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])();
																num = 251;
																goto IL_1801_2;
																IL_1801_2:
																array2[num6] = 4;
																goto IL_180f_2;
																IL_180f_2:
																num6++;
																num = 154;
																goto IL_1826_2;
																IL_1826_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_1839_2:
																if (30 >= b)
																{
																	goto IL_1847_2;
																}
																goto IL_19d8_2;
																IL_1847_2:
																if (30 <= b)
																{
																	goto IL_1852_2;
																}
																goto IL_18c1_2;
																IL_1852_2:
																array2[num6 - 1] = 0;
																goto IL_1866_2;
																IL_1866_2:
																*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, int>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_18a5_2;
																IL_18a5_2:
																ptr2 += 8;
																num = 43;
																goto IL_1ad4_2;
																IL_18c1_2:
																if (28 >= b)
																{
																	num = 67;
																	goto IL_18d8_2;
																}
																goto IL_1955_2;
																IL_1a7a_2:
																((delegate*<Color, void>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((Color)array3[num6 - 1]);
																goto IL_1aa3_2;
																IL_18d8_2:
																if (28 > b)
																{
																	break;
																}
																goto IL_18e6_2;
																IL_18e6_2:
																array2[num6 - 1] = 3;
																num = 268;
																goto IL_1903_2;
																IL_1903_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) = ((delegate*<double, double>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																goto IL_1942_2;
																IL_1942_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_1955_2:
																if (29 < b)
																{
																	break;
																}
																goto IL_1963_2;
																IL_1963_2:
																if (29 > b)
																{
																	break;
																}
																goto IL_1971_2;
																IL_1971_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																goto IL_19b1_2;
																IL_19b1_2:
																array2[num6 - 2] = 3;
																goto IL_19c5_2;
																IL_19c5_2:
																num6--;
																goto IL_1ad4_2;
																IL_19d8_2:
																if (31 >= b)
																{
																	num = 299;
																	goto IL_19ec_2;
																}
																goto IL_1a5b_2;
																IL_1aa3_2:
																num6--;
																goto IL_1ab1_2;
																IL_19ec_2:
																if (31 > b)
																{
																	break;
																}
																goto IL_19fa_2;
																IL_19fa_2:
																array3[num6 - 1] = ((delegate*<ThemeData, Color>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((ThemeData)array3[num6 - 1]);
																goto IL_1a37_2;
																IL_1a37_2:
																array2[num6 - 1] = 4;
																goto IL_1a4b_2;
																IL_1a4b_2:
																ptr2 += 8;
																goto IL_1ad4_2;
																IL_1a5b_2:
																if (32 < b)
																{
																	break;
																}
																num = 146;
																goto IL_1a6f_2;
															}
															break;
														}
														goto IL_06e3_2;
														IL_08bb_2:
														ptr2 += 16;
														goto IL_1ad4_2;
														IL_06e3_2:
														if (22 > b)
														{
															goto IL_06ee_2;
														}
														goto IL_070c_2;
														IL_06ee_2:
														if (11 >= b)
														{
															goto IL_06f9_2;
														}
														goto IL_0760_2;
														IL_06f9_2:
														if (11 <= b)
														{
															goto IL_1ad4_2;
														}
														goto IL_09b9_2;
														IL_09b9_2:
														if (5 >= b)
														{
															goto IL_09c7_2;
														}
														goto IL_0be3_2;
														IL_09c7_2:
														if (5 > b)
														{
															goto IL_09d5_2;
														}
														goto IL_0b7c_2;
														IL_09d5_2:
														if (2 >= b)
														{
															goto IL_09e3_2;
														}
														goto IL_0ab9_2;
														IL_09e3_2:
														if (2 <= b)
														{
															goto IL_09ee_2;
														}
														goto IL_0a55_2;
														IL_09ee_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0a2e_2;
														IL_0a2e_2:
														array2[num6 - 2] = 0;
														goto IL_0a42_2;
														IL_0a42_2:
														num6--;
														goto IL_1ad4_2;
														IL_0a55_2:
														if (1 < b)
														{
															break;
														}
														goto IL_0a63_2;
														IL_0a63_2:
														if (1 > b)
														{
															break;
														}
														goto IL_0a71_2;
														IL_0a71_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
														goto IL_0a8a_2;
														IL_0a8a_2:
														array2[num6] = 0;
														goto IL_0a98_2;
														IL_0a98_2:
														num6++;
														goto IL_0aa6_2;
														IL_0aa6_2:
														ptr2 += 8;
														goto IL_1ad4_2;
														IL_0ab9_2:
														if (3 < b)
														{
															goto IL_0ac4_2;
														}
														num = 48;
														goto IL_0b32_2;
														IL_0ac4_2:
														if (4 < b)
														{
															break;
														}
														goto IL_0ad2_2;
														IL_0ad2_2:
														if (4 > b)
														{
															break;
														}
														goto IL_0ae0_2;
														IL_0ae0_2:
														array2[num6] = 0;
														goto IL_0aee_2;
														IL_0aee_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
														goto IL_0b11_2;
														IL_0b11_2:
														array3[num6] = null;
														num = 339;
														goto IL_0cbe_2;
														IL_0cbe_2:
														num6++;
														goto IL_0ccc_2;
														IL_0ccc_2:
														ptr2 += 8;
														goto IL_1ad4_2;
														IL_070c_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_077e_2;
														IL_0b32_2:
														if (3 > b)
														{
															break;
														}
														goto IL_0b40_2;
														IL_0b40_2:
														reference = ref array5[*(int*)(ptr2 + num3)];
														reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0b69_2;
														IL_0b69_2:
														ptr2 += 8;
														goto IL_11e4_2;
														IL_11e4_2:
														num6--;
														goto IL_1ad4_2;
														IL_0b7c_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0bbc_2;
														IL_0bbc_2:
														array2[num6 - 2] = 0;
														goto IL_0bd0_2;
														IL_0bd0_2:
														num6--;
														goto IL_1ad4_2;
														IL_0be3_2:
														if (8 >= b)
														{
															goto IL_0bee_2;
														}
														goto IL_0c3b_2;
														IL_0bee_2:
														if (8 > b)
														{
															goto IL_0bfc_2;
														}
														goto IL_0dd7_2;
														IL_0bfc_2:
														if (6 >= b)
														{
															goto IL_0c07_2;
														}
														goto IL_0c1a_2;
														IL_0c07_2:
														if (6 > b)
														{
															break;
														}
														goto IL_0d70_2;
														IL_0d70_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0db0_2;
														IL_0db0_2:
														array2[num6 - 2] = 0;
														goto IL_0dc4_2;
														IL_0dc4_2:
														num6--;
														goto IL_1ad4_2;
														IL_0c1a_2:
														if (7 < b)
														{
															break;
														}
														goto IL_0c28_2;
														IL_0c28_2:
														if (7 > b)
														{
															break;
														}
														goto IL_11f7_2;
														IL_11f7_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1237_2;
														IL_1237_2:
														array2[num6 - 2] = 0;
														goto IL_124b_2;
														IL_124b_2:
														num6--;
														goto IL_1ad4_2;
														IL_0dd7_2:
														num6--;
														goto IL_1ad4_2;
														IL_0c3b_2:
														if (9 >= b)
														{
															goto IL_0c49_2;
														}
														goto IL_0cdf_2;
														IL_0c49_2:
														if (9 > b)
														{
															break;
														}
														goto IL_0c57_2;
														IL_0c57_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_0c97_2;
														IL_0c97_2:
														array2[num6 - 2] = 0;
														goto IL_0cab_2;
														IL_0cab_2:
														num6--;
														goto IL_1ad4_2;
														IL_0cdf_2:
														if (10 < b)
														{
															break;
														}
														goto IL_0ced_2;
														IL_0ced_2:
														if (10 > b)
														{
															break;
														}
														goto IL_0cfb_2;
														IL_0cfb_2:
														ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
														goto IL_0d5d_2;
														IL_0d5d_2:
														num6 -= 2;
														goto IL_1ad4_2;
														IL_0760_2:
														if (16 >= b)
														{
															goto IL_076b_2;
														}
														goto IL_0791_2;
														IL_076b_2:
														if (16 > b)
														{
															goto IL_0f47_2;
														}
														goto IL_119d_2;
														IL_119d_2:
														array2[num6] = 5;
														goto IL_11ab_2;
														IL_11ab_2:
														array3[num6] = array7[*(int*)(ptr2 + num3)];
														goto IL_11c3_2;
														IL_11c3_2:
														num6++;
														goto IL_11d1_2;
														IL_11d1_2:
														ptr2 += 8;
														goto IL_1ad4_2;
														IL_0f47_2:
														if (13 >= b)
														{
															goto IL_0f55_2;
														}
														goto IL_109c_2;
														IL_0f55_2:
														if (13 <= b)
														{
															goto IL_0f60_2;
														}
														goto IL_0f9f_2;
														IL_0f60_2:
														array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
														goto IL_0f7e_2;
														IL_0f7e_2:
														ptr2 += 8;
														goto IL_0f8c_2;
														IL_0f8c_2:
														num6--;
														goto IL_1ad4_2;
														IL_0f9f_2:
														if (12 < b)
														{
															break;
														}
														goto IL_0fad_2;
														IL_0fad_2:
														if (12 > b)
														{
															break;
														}
														goto IL_0fbb_2;
														IL_0fbb_2:
														array8 = array3;
														num9 = num6;
														if (array == null)
														{
															goto IL_0fca_2;
														}
														goto IL_0fd8;
														IL_109c_2:
														if (14 >= b)
														{
															goto IL_10a7_2;
														}
														goto IL_10ba_2;
														IL_10a7_2:
														if (14 > b)
														{
															break;
														}
														goto IL_115b_2;
														IL_115b_2:
														array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
														goto IL_1184_2;
														IL_1184_2:
														array2[num6 - 1] = 5;
														goto IL_1ad4_2;
														IL_10ba_2:
														if (15 < b)
														{
															break;
														}
														goto IL_10c8_2;
														IL_10c8_2:
														if (15 > b)
														{
															break;
														}
														goto IL_10d6_2;
														IL_10d6_2:
														array2[num6] = array2[num6 - 1];
														goto IL_10ee_2;
														IL_10ee_2:
														array4[num6 - 0] = array4[num6 - 1];
														goto IL_110c_2;
														IL_110c_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
														goto IL_1130_2;
														IL_1130_2:
														array3[num6] = array3[num6 - 1];
														goto IL_1148_2;
														IL_1148_2:
														num6++;
														goto IL_1ad4_2;
														IL_0791_2:
														if (19 < b)
														{
															goto IL_079c_2;
														}
														goto IL_07db_2;
														IL_079c_2:
														if (20 >= b)
														{
															goto IL_07a7_2;
														}
														goto IL_07ba_2;
														IL_07a7_2:
														if (20 > b)
														{
															break;
														}
														goto IL_0dea_2;
														IL_0dea_2:
														ptr2 = ptr + *(int*)(ptr2 + num3);
														goto IL_1ad4_2;
														IL_07ba_2:
														if (21 < b)
														{
															break;
														}
														goto IL_07c8_2;
														IL_07c8_2:
														if (21 > b)
														{
															break;
														}
														goto IL_08ce_2;
														IL_08ce_2:
														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
														num = 325;
														goto IL_0989_2;
														IL_0989_2:
														array2[num6 - 2] = 0;
														goto IL_099d_2;
														IL_099d_2:
														num6--;
														num = 89;
														goto IL_1ad4_2;
														IL_07db_2:
														if (19 > b)
														{
															goto IL_07e9_2;
														}
														num = 116;
														goto IL_0886_2;
														IL_07e9_2:
														if (17 < b)
														{
															goto IL_07f4_2;
														}
														goto IL_0815_2;
														IL_07f4_2:
														if (18 < b)
														{
															break;
														}
														goto IL_0802_2;
														IL_0802_2:
														if (18 > b)
														{
															break;
														}
														goto IL_125e_2;
														IL_125e_2:
														array2[num6 - 1] = 5;
														num = 144;
														goto IL_127b_2;
														IL_127b_2:
														array3[num6 - 1] = ((delegate*<string[], string>)LimitCountControlEvidence[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
														goto IL_12b3_2;
														IL_12b3_2:
														ptr2 += 8;
														goto IL_1ad4_2;
														IL_0815_2:
														if (17 > b)
														{
															break;
														}
														goto IL_0823_2;
														IL_0823_2:
														((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
														goto IL_0861_2;
														IL_0861_2:
														num6 -= 3;
														num = 353;
														goto IL_1ad4_2;
														IL_077e_2:
														num6--;
														goto IL_1ad4_2;
														IL_0886_2:
														*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
														goto IL_089f_2;
														IL_089f_2:
														array2[num6] = 1;
														goto IL_08ad_2;
														IL_08ad_2:
														num6++;
														goto IL_08bb_2;
													}
													break;
													IL_06a8_2:;
												}
											}
											ptr2 = ptr + *(int*)(ptr2 + num3);
											goto IL_1ad4_2;
											continue;
											end_IL_06b8_2:
											break;
										}
										continue;
										end_IL_06c8:
										break;
									}
									continue;
									end_IL_06d8:
									break;
								}
								break;
							}
							break;
						}
						continue;
						end_IL_1072:
						break;
					}
					break;
				}
				break;
			}
		}
	}

	public unsafe static string smethod_0()
	{
		int num = 7;
		int num5 = default(int);
		int num6 = default(int);
		object[] array6 = default(object[]);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					int num4 = num2 * 8;
					while (true)
					{
						byte[] array = new byte[3];
						while (true)
						{
							object[] array2 = new object[3];
							while (true)
							{
								int[] array3 = new int[3];
								while (true)
								{
									int[] array4 = new int[7];
									while (true)
									{
										long[] array5 = new long[3];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getIdentityAuthorityIChannelInfo.CLRIReferenceImplGUID);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num5 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_048a:
																	if (b >= 1)
																	{
																		while (b <= 22)
																		{
																			while (true)
																			{
																				IL_046d:
																				if (11 >= b)
																				{
																					while (true)
																					{
																						IL_045d:
																						if (11 > b)
																						{
																							while (true)
																							{
																								IL_044d:
																								if (5 < b)
																								{
																									num = 29;
																									while (true)
																									{
																										IL_043d:
																										if (8 >= b)
																										{
																											while (true)
																											{
																												IL_042d:
																												if (8 > b)
																												{
																													while (true)
																													{
																														IL_041d:
																														if (6 >= b)
																														{
																															while (6 <= b)
																															{
																																while (true)
																																{
																																	IL_03cb:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																																	while (true)
																																	{
																																		IL_03ac:
																																		array[num6 - 2] = 0;
																																		num = 223;
																																		while (true)
																																		{
																																			if (num != 223)
																																			{
																																				if (num != 1204)
																																				{
																																					break;
																																				}
																																				switch (num)
																																				{
																																				case 94:
																																					goto IL_03ac;
																																				case 139:
																																				case 145:
																																					goto IL_03cb;
																																				case 147:
																																					goto IL_040d;
																																				case 5:
																																				case 31:
																																					goto IL_041d;
																																				case 25:
																																					goto IL_042d;
																																				case 29:
																																				case 62:
																																					goto IL_043d;
																																				case 182:
																																				case 195:
																																					goto IL_044d;
																																				case 179:
																																					goto IL_045d;
																																				case 170:
																																					goto IL_046d;
																																				case 196:
																																					goto IL_047a;
																																				case 39:
																																					goto IL_048a;
																																				case 99:
																																					goto end_IL_048a;
																																				case 132:
																																				case 180:
																																					goto end_IL_049a;
																																				case 26:
																																					goto IL_04b5;
																																				case 58:
																																					goto IL_04c8;
																																				case 51:
																																					goto IL_04d3;
																																				case 101:
																																					goto IL_04e6;
																																				case 15:
																																				case 63:
																																					goto IL_04f1;
																																				case 59:
																																					goto IL_04ff;
																																				case 24:
																																					goto IL_0512;
																																				case 68:
																																				case 97:
																																					goto IL_0520;
																																				case 67:
																																					goto IL_0593;
																																				case 55:
																																					goto IL_05b0;
																																				case 122:
																																				case 136:
																																					goto IL_05c3;
																																				case 53:
																																					goto IL_05d1;
																																				case 76:
																																				case 124:
																																					goto IL_05df;
																																				case 16:
																																					goto IL_061f;
																																				case 22:
																																					goto IL_0633;
																																				case 114:
																																				case 138:
																																					goto IL_0646;
																																				case 3:
																																				case 140:
																																					goto IL_0659;
																																				case 46:
																																				case 148:
																																					goto IL_066c;
																																				case 86:
																																				case 150:
																																					goto IL_0688;
																																				case 23:
																																				case 168:
																																					goto IL_06ab;
																																				case 35:
																																					goto IL_06eb;
																																				case 154:
																																					goto IL_06ff;
																																				case 169:
																																					goto IL_0712;
																																				case 177:
																																					goto IL_072e;
																																				case 146:
																																					goto IL_073c;
																																				case 163:
																																					goto IL_0753;
																																				case 185:
																																					goto IL_0766;
																																				case 75:
																																					goto IL_0771;
																																				case 34:
																																				case 171:
																																					goto IL_077c;
																																				case 142:
																																					goto IL_0787;
																																				case 9:
																																				case 151:
																																					goto IL_07a3;
																																				case 84:
																																				case 104:
																																					goto IL_07b6;
																																				case 199:
																																					goto IL_07ce;
																																				case 89:
																																					goto IL_07d9;
																																				case 130:
																																				case 161:
																																					goto IL_07e7;
																																				case 85:
																																					goto IL_0828;
																																				case 17:
																																					goto IL_0841;
																																				case 162:
																																					goto IL_084f;
																																				case 149:
																																				case 198:
																																					goto IL_085d;
																																				case 50:
																																					goto IL_08af;
																																				case 202:
																																					goto end_IL_0399;
																																				case 203:
																																					goto IL_08e8;
																																				case 40:
																																				case 43:
																																					goto IL_08ff;
																																				case 87:
																																					goto IL_0918;
																																				case 128:
																																					goto IL_0926;
																																				case 129:
																																					goto IL_0934;
																																				case 205:
																																					goto IL_0947;
																																				case 18:
																																					goto IL_0955;
																																				case 212:
																																					goto IL_0968;
																																				case 213:
																																					goto IL_097b;
																																				case 42:
																																					goto IL_0989;
																																				case 90:
																																				case 211:
																																					goto IL_0994;
																																				case 33:
																																					goto IL_09d4;
																																				case 98:
																																					goto IL_09f1;
																																				case 19:
																																				case 143:
																																					goto IL_0a16;
																																				case 174:
																																					goto IL_0a24;
																																				case 152:
																																				case 178:
																																					goto IL_0a32;
																																				case 107:
																																					goto IL_0a4b;
																																				case 200:
																																					goto IL_0a59;
																																				case 69:
																																					goto IL_0a67;
																																				case 71:
																																				case 83:
																																					goto IL_0a7a;
																																				case 125:
																																				case 201:
																																					goto IL_0a85;
																																				case 27:
																																					goto IL_0a93;
																																				case 52:
																																				case 157:
																																					goto IL_0aa1;
																																				case 153:
																																					goto IL_0ab8;
																																				case 118:
																																					goto IL_0ae4;
																																				case 133:
																																					goto IL_0aee;
																																				case 81:
																																					goto IL_0b01;
																																				case 65:
																																				case 74:
																																					goto IL_0b0f;
																																				case 11:
																																					goto IL_0b38;
																																				case 48:
																																					goto IL_0b46;
																																				case 96:
																																				case 214:
																																					goto IL_0b59;
																																				case 193:
																																					goto IL_0b64;
																																				case 44:
																																				case 95:
																																					goto IL_0b6f;
																																				case 100:
																																					goto IL_0b93;
																																				case 66:
																																					goto IL_0ba1;
																																				case 210:
																																					goto IL_0baf;
																																				case 176:
																																					goto IL_0bd0;
																																				case 159:
																																					goto IL_0bde;
																																				case 111:
																																				case 165:
																																					goto IL_0bec;
																																				case 32:
																																					goto IL_0c00;
																																				case 49:
																																					goto IL_0c1e;
																																				case 91:
																																					goto IL_0c48;
																																				case 135:
																																					goto IL_0c61;
																																				case 206:
																																					goto IL_0c6f;
																																				case 215:
																																					goto IL_0c82;
																																				case 126:
																																				case 216:
																																					goto IL_0c95;
																																				case 108:
																																					goto IL_0ca3;
																																				case 112:
																																				case 188:
																																					goto IL_0cb1;
																																				case 57:
																																					goto IL_0d13;
																																				case 13:
																																					goto IL_0d39;
																																				case 160:
																																					goto IL_0d44;
																																				case 113:
																																				case 134:
																																					goto IL_0d4f;
																																				case 137:
																																					goto IL_0d8f;
																																				case 120:
																																					goto IL_0da3;
																																				case 37:
																																				case 208:
																																					goto IL_0db3;
																																				case 1:
																																				case 8:
																																				case 10:
																																				case 12:
																																				case 14:
																																				case 20:
																																				case 21:
																																				case 28:
																																				case 30:
																																				case 38:
																																				case 60:
																																				case 73:
																																				case 77:
																																				case 78:
																																				case 82:
																																				case 92:
																																				case 93:
																																				case 105:
																																				case 109:
																																				case 110:
																																				case 115:
																																				case 121:
																																				case 127:
																																				case 144:
																																				case 155:
																																				case 156:
																																				case 158:
																																				case 164:
																																				case 172:
																																				case 173:
																																				case 184:
																																				case 187:
																																				case 189:
																																				case 191:
																																				case 192:
																																				case 194:
																																				case 209:
																																					goto end_IL_040d;
																																				case 2:
																																				case 4:
																																				case 36:
																																				case 45:
																																				case 56:
																																				case 61:
																																				case 70:
																																				case 72:
																																				case 88:
																																				case 102:
																																				case 103:
																																				case 106:
																																				case 116:
																																				case 117:
																																				case 119:
																																				case 123:
																																				case 131:
																																				case 166:
																																				case 167:
																																				case 183:
																																				case 186:
																																				case 190:
																																				case 197:
																																				case 204:
																																				case 207:
																																					goto end_IL_04aa;
																																				case 64:
																																					goto end_IL_0dd6;
																																				case 47:
																																					goto end_IL_0de9;
																																				case 80:
																																					goto end_IL_0df3;
																																				case 79:
																																					goto end_IL_0dfe;
																																				case 54:
																																					goto end_IL_0e0e;
																																				case 41:
																																					goto end_IL_0e1e;
																																				case 141:
																																					goto end_IL_0e2e;
																																				case 175:
																																					goto end_IL_0e3e;
																																				case 6:
																																					goto end_IL_0e4e;
																																				case 7:
																																					goto end_IL_0e5e;
																																				case 0:
																																				case 181:
																																					goto IL_0e79;
																																				}
																																				continue;
																																			}
																																			num6--;
																																			goto end_IL_04aa;
																																			continue;
																																			end_IL_0399:
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_08c2;
																																continue;
																																end_IL_040d:
																																break;
																																IL_040d:;
																															}
																															break;
																														}
																														goto IL_0d39;
																														IL_0da3:
																														num6--;
																														goto end_IL_04aa;
																														IL_0d39:
																														if (7 < b)
																														{
																															break;
																														}
																														goto IL_0d44;
																														IL_0d44:
																														if (7 > b)
																														{
																															break;
																														}
																														goto IL_0d4f;
																														IL_0d4f:
																														*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																														goto IL_0d8f;
																														IL_0d8f:
																														array[num6 - 2] = 0;
																														goto IL_0da3;
																													}
																													break;
																												}
																												goto IL_0db3;
																												IL_0db3:
																												num6--;
																												goto end_IL_04aa;
																											}
																											break;
																										}
																										goto IL_05c3;
																										IL_0d13:
																										num6 -= 2;
																										goto end_IL_04aa;
																										IL_05c3:
																										if (9 >= b)
																										{
																											goto IL_05d1;
																										}
																										goto IL_0c95;
																										IL_05d1:
																										if (9 > b)
																										{
																											break;
																										}
																										goto IL_05df;
																										IL_05df:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_061f;
																										IL_061f:
																										array[num6 - 2] = 0;
																										goto IL_0633;
																										IL_0633:
																										num6--;
																										goto end_IL_04aa;
																										IL_0c95:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_0ca3;
																										IL_0ca3:
																										if (10 > b)
																										{
																											break;
																										}
																										goto IL_0cb1;
																										IL_0cb1:
																										ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																										goto IL_0d13;
																									}
																									break;
																								}
																								goto IL_04b5;
																								IL_0b0f:
																								ref int reference = ref array4[*(int*)(ptr2 + num3)];
																								reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_0b38;
																								IL_0b38:
																								ptr2 += 8;
																								goto IL_0b46;
																								IL_04b5:
																								if (5 <= b)
																								{
																									goto IL_06ab;
																								}
																								goto IL_097b;
																								IL_06ab:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_06eb;
																								IL_06eb:
																								array[num6 - 2] = 0;
																								goto IL_06ff;
																								IL_06ff:
																								num6--;
																								goto end_IL_04aa;
																								IL_097b:
																								if (2 >= b)
																								{
																									goto IL_0989;
																								}
																								goto IL_0a7a;
																								IL_0989:
																								if (2 <= b)
																								{
																									goto IL_0994;
																								}
																								num = 143;
																								goto IL_0a16;
																								IL_0994:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																								goto IL_09d4;
																								IL_09d4:
																								array[num6 - 2] = 0;
																								num = 98;
																								goto IL_09f1;
																								IL_09f1:
																								num6--;
																								num = 183;
																								goto end_IL_04aa;
																								IL_0b46:
																								num6--;
																								goto end_IL_04aa;
																								IL_0a16:
																								if (1 < b)
																								{
																									break;
																								}
																								goto IL_0a24;
																								IL_0a24:
																								if (1 > b)
																								{
																									break;
																								}
																								goto IL_0a32;
																								IL_0a32:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																								goto IL_0a4b;
																								IL_0a4b:
																								array[num6] = 0;
																								goto IL_0a59;
																								IL_0a59:
																								num6++;
																								goto IL_0a67;
																								IL_0a67:
																								ptr2 += 8;
																								goto end_IL_04aa;
																								IL_0a7a:
																								if (3 < b)
																								{
																									goto IL_0a85;
																								}
																								goto IL_0b01;
																								IL_0a85:
																								if (4 < b)
																								{
																									break;
																								}
																								goto IL_0a93;
																								IL_0a93:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0aa1;
																								IL_0aa1:
																								array[num6] = 0;
																								num = 153;
																								goto IL_0ab8;
																								IL_0ab8:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = array4[*(int*)(ptr2 + num3)];
																								num = 118;
																								goto IL_0ae4;
																								IL_0ae4:
																								array2[num6] = null;
																								goto IL_0aee;
																								IL_0aee:
																								num6++;
																								goto IL_0c82;
																								IL_0c82:
																								ptr2 += 8;
																								goto end_IL_04aa;
																								IL_0b01:
																								if (3 > b)
																								{
																									break;
																								}
																								goto IL_0b0f;
																							}
																							break;
																						}
																						goto IL_0659;
																						IL_0955:
																						ptr2 += 8;
																						goto end_IL_04aa;
																						IL_0659:
																						array[num6] = 0;
																						goto IL_08c2;
																						IL_08c2:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<int>)CORESERVERIChannelSinkBase[*(int*)(ptr2 + num3)])();
																						goto IL_0947;
																						IL_0947:
																						num6++;
																						goto IL_0955;
																					}
																					break;
																				}
																				goto IL_04c8;
																				IL_0c00:
																				array2[num6 - 2] = array2[num6 - 2];
																				goto IL_0c1e;
																				IL_04c8:
																				if (17 >= b)
																				{
																					goto IL_04d3;
																				}
																				goto IL_04e6;
																				IL_04d3:
																				if (17 <= b)
																				{
																					goto IL_0688;
																				}
																				goto IL_0766;
																				IL_0688:
																				array2[num6] = ((delegate*<ThemeData[]>)CORESERVERIChannelSinkBase[*(int*)(ptr2 + num3)])();
																				goto IL_072e;
																				IL_072e:
																				array[num6] = 5;
																				goto IL_073c;
																				IL_073c:
																				num6++;
																				num = 163;
																				goto IL_0753;
																				IL_0753:
																				ptr2 += 8;
																				goto end_IL_04aa;
																				IL_0766:
																				if (14 >= b)
																				{
																					goto IL_0771;
																				}
																				goto IL_07ce;
																				IL_0771:
																				if (14 > b)
																				{
																					goto IL_077c;
																				}
																				goto IL_07b6;
																				IL_077c:
																				if (12 >= b)
																				{
																					goto IL_0787;
																				}
																				num = 9;
																				goto IL_07a3;
																				IL_0787:
																				if (12 > b)
																				{
																					break;
																				}
																				goto end_IL_04aa;
																				IL_0c1e:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																				goto IL_0c48;
																				IL_07a3:
																				if (13 < b)
																				{
																					break;
																				}
																				goto IL_08e8;
																				IL_08e8:
																				if (13 > b)
																				{
																					break;
																				}
																				num = 43;
																				goto IL_08ff;
																				IL_0c48:
																				array3[num6 - 2] = *(int*)(ptr2 + num3);
																				goto IL_0c61;
																				IL_08ff:
																				*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)(ptr2 + num4);
																				goto IL_0918;
																				IL_0918:
																				array[num6] = 1;
																				goto IL_0926;
																				IL_0926:
																				num6++;
																				goto IL_0934;
																				IL_0934:
																				ptr2 += 16;
																				goto end_IL_04aa;
																				IL_07b6:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_04aa;
																				IL_07ce:
																				if (15 >= b)
																				{
																					goto IL_07d9;
																				}
																				goto IL_0841;
																				IL_07d9:
																				if (15 > b)
																				{
																					break;
																				}
																				goto IL_07e7;
																				IL_07e7:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])) ? 1 : 0);
																				goto IL_0828;
																				IL_0828:
																				array[num6 - 2] = 0;
																				goto IL_0968;
																				IL_0968:
																				num6--;
																				goto end_IL_04aa;
																				IL_0841:
																				if (16 < b)
																				{
																					break;
																				}
																				goto IL_084f;
																				IL_084f:
																				if (16 > b)
																				{
																					break;
																				}
																				goto IL_085d;
																				IL_085d:
																				ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																				goto IL_08af;
																				IL_08af:
																				num6--;
																				goto end_IL_04aa;
																				IL_04e6:
																				if (20 < b)
																				{
																					goto IL_04f1;
																				}
																				goto IL_0512;
																				IL_04f1:
																				if (21 >= b)
																				{
																					goto IL_04ff;
																				}
																				goto IL_0646;
																				IL_04ff:
																				if (21 > b)
																				{
																					break;
																				}
																				goto IL_066c;
																				IL_066c:
																				byte* num7 = ptr2;
																				num5 = 1;
																				ptr2 = num7 + -200;
																				goto end_IL_04aa;
																				IL_0646:
																				if (22 < b)
																				{
																					break;
																				}
																				goto IL_0712;
																				IL_0712:
																				if (22 > b)
																				{
																					num = 60;
																				}
																				break;
																				IL_0c61:
																				ptr2 += 8;
																				goto IL_0c6f;
																				IL_0512:
																				if (20 <= b)
																				{
																					goto IL_0520;
																				}
																				goto IL_0b59;
																				IL_0520:
																				array2[num6 - 1] = ((delegate*<ref ThemeData, string>)CORESERVERIChannelSinkBase[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref ThemeData>)CORESERVERIChannelSinkBase[array3[num6 - 1]])(array2[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])), array6, array4));
																				num = 67;
																				goto IL_0593;
																				IL_0593:
																				array[num6 - 1] = 5;
																				num = 55;
																				goto IL_05b0;
																				IL_05b0:
																				ptr2 += 8;
																				goto end_IL_04aa;
																				IL_0b59:
																				if (18 >= b)
																				{
																					goto IL_0b64;
																				}
																				goto IL_0bd0;
																				IL_0b64:
																				if (18 > b)
																				{
																					num = 20;
																					break;
																				}
																				goto IL_0b6f;
																				IL_0b6f:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = ((delegate*<int>)CORESERVERIChannelSinkBase[*(int*)(ptr2 + num3)])();
																				goto IL_0b93;
																				IL_0b93:
																				array[num6] = 0;
																				goto IL_0ba1;
																				IL_0ba1:
																				num6++;
																				goto IL_0baf;
																				IL_0baf:
																				ptr2 += 8;
																				goto end_IL_04aa;
																				IL_0c6f:
																				num6--;
																				goto end_IL_04aa;
																				IL_0bd0:
																				if (19 < b)
																				{
																					break;
																				}
																				goto IL_0bde;
																				IL_0bde:
																				if (19 > b)
																				{
																					break;
																				}
																				goto IL_0bec;
																				IL_0bec:
																				array[num6 - 2] = 16;
																				goto IL_0c00;
																			}
																			break;
																			IL_047a:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	goto end_IL_04aa;
																	continue;
																	end_IL_048a:
																	break;
																}
																continue;
																end_IL_049a:
																break;
															}
															continue;
															end_IL_04aa:
															break;
														}
														continue;
													}
													goto IL_0e79;
													IL_0e79:
													return (string)array2[num6 - 1];
													continue;
													end_IL_0dd6:
													break;
												}
												continue;
												end_IL_0de9:
												break;
											}
											continue;
											end_IL_0df3:
											break;
										}
										continue;
										end_IL_0dfe:
										break;
									}
									continue;
									end_IL_0e0e:
									break;
								}
								continue;
								end_IL_0e1e:
								break;
							}
							continue;
							end_IL_0e2e:
							break;
						}
						continue;
						end_IL_0e3e:
						break;
					}
					continue;
					end_IL_0e4e:
					break;
				}
				continue;
				end_IL_0e5e:
				break;
			}
		}
	}

	public unsafe static string smethod_1()
	{
		//The blocks IL_000e, IL_001c, IL_002c, IL_04c1, IL_04d4, IL_04e7, IL_04f4, IL_0504, IL_0514, IL_0524, IL_0534, IL_0544, IL_0554, IL_055f, IL_056d, IL_0581, IL_05da, IL_05e8, IL_05f6, IL_0604, IL_0612, IL_0620, IL_0687, IL_0695, IL_06a3, IL_06b1, IL_06bf, IL_06ca, IL_06d5, IL_06e0, IL_06eb, IL_06fe, IL_070c, IL_0724, IL_0732, IL_0745, IL_0750, IL_0764, IL_07a1, IL_07af, IL_07ba, IL_07cd, IL_07db, IL_07e4, IL_07f2, IL_0813, IL_0836, IL_0844, IL_0896, IL_08a9, IL_08b7, IL_08c2, IL_08cd, IL_08db, IL_08e9, IL_090b, IL_0927, IL_093a, IL_0943, IL_0951, IL_095f, IL_096a, IL_0978, IL_0986, IL_09a4, IL_09b7, IL_09c0, IL_09e4, IL_09f2, IL_0a00, IL_0a13, IL_0a7d, IL_0a91, IL_0aa4, IL_0ab7, IL_0adb, IL_0af8, IL_0b0b, IL_0b19, IL_0b2c, IL_0b3a, IL_0b4d, IL_0b8e, IL_0ba2, IL_0bb5, IL_0bcd, IL_0bdb, IL_0bee, IL_0c07, IL_0c15, IL_0c2c, IL_0c3f, IL_0c4d, IL_0c69, IL_0c7c, IL_0cc8, IL_0cd6, IL_0ce9, IL_0cfc, IL_0d41, IL_0d4f, IL_0d5d, IL_0d71, IL_0d98, IL_0dc2, IL_0ddb, IL_0de9, IL_0dfc, IL_0e07, IL_0e15, IL_0e53, IL_0e6f, IL_0e7d, IL_0e91, IL_0ea4, IL_0eb2, IL_0ec0, IL_0ede, IL_0eec, IL_0eff, IL_0f0a, IL_0f13, IL_0f21, IL_0f34, IL_0f51, IL_0fa0, IL_0faa, IL_0fd7, IL_0ff4, IL_1002, IL_101e, IL_1029, IL_1069, IL_107d, IL_1090, IL_1099, IL_10a7, IL_10b2, IL_10db, IL_10e9, IL_10fc, IL_1107, IL_1115, IL_112e, IL_113c, IL_114a, IL_1166, IL_1174, IL_1182, IL_11cb, IL_11df, IL_11f2, IL_1200, IL_120b, IL_124b, IL_125f, IL_1272, IL_1280, IL_128e, IL_129c, IL_12bf, IL_12c9, IL_12d7, IL_12ea, IL_12f8, IL_1301, IL_130f, IL_134f, IL_136c, IL_137c, IL_13a5, IL_13bb, IL_13ce, IL_13e1, IL_13f4, IL_13ff, IL_140f, IL_141f, IL_142f, IL_143f, IL_144f, IL_1468, IL_1478, IL_1488, IL_14a3 are reachable both inside and outside the pinned region starting at IL_149d. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 177;
		int num5 = default(int);
		int num6 = default(int);
		while (true)
		{
			int num2;
			int num3;
			int num4;
			byte[] array2;
			object[] array3;
			int[] array4;
			int[] array5;
			long[] array6;
			object[] array7;
			byte* ptr;
			object[] array8;
			int num7;
			byte* num8;
			int __rxRef56 = default(int);
			ref int reference = ref __rxRef56;
			byte* num10;
			int num11;
			byte* ptr2;
			byte[] array = new byte[4];
			if (true)
			{
				while (true)
				{
					IL_1488:
					num2 = 1;
					while (true)
					{
						IL_1478:
						num3 = num2 * 4;
						while (true)
						{
							IL_1468:
							num4 = num2 * 8;
							while (true)
							{
								IL_144f:
								array2 = new byte[4];
								num = 94;
								while (true)
								{
									IL_143f:
									array3 = new object[4];
									while (true)
									{
										IL_142f:
										array4 = new int[4];
										while (true)
										{
											IL_141f:
											array5 = new int[7];
											while (true)
											{
												IL_140f:
												array6 = new long[4];
												while (true)
												{
													IL_13ff:
													array7 = new object[7];
													while (true)
													{
														IL_13f4:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClassesRootAllowParentheses.BuiltinSystemOperatorsSidEncoderExceptionFallback);
														while (true)
														{
															IL_13e1:
															ptr2 = ptr;
															num = 256;
															while (true)
															{
																IL_13ce:
																if (num5 != 1)
																{
																	while (true)
																	{
																		IL_0554:
																		byte b = *ptr2;
																		while (true)
																		{
																			IL_0544:
																			ptr2++;
																			while (true)
																			{
																				IL_0534:
																				if (b >= 1)
																				{
																					while (b <= 30)
																					{
																						while (true)
																						{
																							IL_0514:
																							if (15 >= b)
																							{
																								while (true)
																								{
																									IL_0504:
																									if (15 > b)
																									{
																										while (true)
																										{
																											IL_04f4:
																											if (7 < b)
																											{
																												while (true)
																												{
																													IL_04e7:
																													if (11 < b)
																													{
																														while (true)
																														{
																															IL_04d4:
																															if (13 < b)
																															{
																																num = 297;
																																while (true)
																																{
																																	if (num != 297)
																																	{
																																		if (num != 1278)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 177:
																																			break;
																																		default:
																																			continue;
																																		case 171:
																																			goto IL_04d4;
																																		case 62:
																																		case 250:
																																			goto IL_04e7;
																																		case 13:
																																			goto IL_04f4;
																																		case 47:
																																			goto IL_0504;
																																		case 255:
																																			goto IL_0514;
																																		case 169:
																																			goto IL_0524;
																																		case 168:
																																			goto IL_0534;
																																		case 33:
																																			goto IL_0544;
																																		case 276:
																																		case 290:
																																			goto IL_0554;
																																		case 45:
																																			goto IL_055f;
																																		case 125:
																																		case 143:
																																			goto IL_056d;
																																		case 35:
																																			goto IL_0581;
																																		case 132:
																																		case 170:
																																			goto IL_05da;
																																		case 252:
																																			goto IL_05f6;
																																		case 50:
																																		case 140:
																																			goto IL_0604;
																																		case 211:
																																			goto IL_0612;
																																		case 46:
																																		case 116:
																																			goto IL_0620;
																																		case 78:
																																			goto IL_0687;
																																		case 217:
																																			goto IL_0695;
																																		case 257:
																																			goto IL_06b1;
																																		case 102:
																																		case 167:
																																			goto IL_06bf;
																																		case 3:
																																		case 8:
																																			goto IL_06ca;
																																		case 41:
																																			goto IL_06d5;
																																		case 136:
																																		case 222:
																																			goto IL_06e0;
																																		case 148:
																																			goto IL_06eb;
																																		case 85:
																																		case 216:
																																			goto IL_070c;
																																		case 175:
																																			goto IL_0724;
																																		case 72:
																																			goto IL_0732;
																																		case 246:
																																			goto IL_0745;
																																		case 20:
																																		case 106:
																																			goto IL_0750;
																																		case 101:
																																			goto IL_0764;
																																		case 74:
																																			goto IL_07a1;
																																		case 10:
																																			goto IL_07af;
																																		case 61:
																																		case 192:
																																			goto IL_07ba;
																																		case 152:
																																			goto end_IL_04c1;
																																		case 56:
																																			goto IL_07e4;
																																		case 34:
																																		case 70:
																																			goto IL_07f2;
																																		case 188:
																																			goto IL_0813;
																																		case 73:
																																		case 233:
																																			goto IL_0844;
																																		case 237:
																																			goto IL_0896;
																																		case 22:
																																		case 258:
																																			goto IL_08a9;
																																		case 243:
																																			goto IL_08b7;
																																		case 146:
																																			goto IL_08c2;
																																		case 25:
																																		case 254:
																																			goto IL_08cd;
																																		case 196:
																																			goto IL_08db;
																																		case 97:
																																		case 202:
																																			goto IL_08e9;
																																		case 157:
																																		case 223:
																																			goto IL_090b;
																																		case 40:
																																			goto IL_0927;
																																		case 149:
																																			goto IL_0943;
																																		case 163:
																																		case 165:
																																			goto IL_0951;
																																		case 181:
																																			goto IL_095f;
																																		case 119:
																																			goto IL_096a;
																																		case 42:
																																			goto IL_0978;
																																		case 145:
																																		case 226:
																																			goto IL_0986;
																																		case 99:
																																			goto IL_09a4;
																																		case 28:
																																		case 29:
																																			goto IL_09c0;
																																		case 161:
																																			goto IL_09e4;
																																		case 240:
																																			goto IL_09f2;
																																		case 65:
																																			goto IL_0a00;
																																		case 96:
																																		case 232:
																																			goto IL_0a13;
																																		case 55:
																																			goto IL_0a7d;
																																		case 14:
																																			goto IL_0a91;
																																		case 259:
																																			goto IL_0aa4;
																																		case 260:
																																			goto IL_0ab7;
																																		case 227:
																																			goto IL_0adb;
																																		case 262:
																																			goto IL_0af8;
																																		case 267:
																																			goto IL_0b0b;
																																		case 109:
																																			goto IL_0b19;
																																		case 269:
																																			goto IL_0b2c;
																																		case 57:
																																		case 178:
																																			goto IL_0b3a;
																																		case 209:
																																		case 270:
																																			goto IL_0b4d;
																																		case 128:
																																			goto IL_0b8e;
																																		case 135:
																																			goto IL_0ba2;
																																		case 273:
																																			goto IL_0bb5;
																																		case 104:
																																			goto IL_0bcd;
																																		case 16:
																																			goto IL_0bdb;
																																		case 131:
																																		case 274:
																																			goto IL_0bee;
																																		case 82:
																																			goto IL_0c07;
																																		case 19:
																																			goto IL_0c15;
																																		case 185:
																																			goto IL_0c2c;
																																		case 277:
																																			goto IL_0c3f;
																																		case 53:
																																			goto IL_0c4d;
																																		case 278:
																																			goto IL_0c69;
																																		case 279:
																																			goto IL_0c7c;
																																		case 30:
																																			goto IL_0cc8;
																																		case 214:
																																			goto IL_0cd6;
																																		case 282:
																																			goto IL_0ce9;
																																		case 1:
																																		case 286:
																																			goto IL_0cfc;
																																		case 287:
																																			goto IL_0d41;
																																		case 75:
																																			goto IL_0d4f;
																																		case 2:
																																		case 147:
																																			goto IL_0d5d;
																																		case 166:
																																			goto IL_0d71;
																																		case 244:
																																			goto IL_0d98;
																																		case 118:
																																			goto IL_0dc2;
																																		case 126:
																																			goto IL_0ddb;
																																		case 83:
																																			goto IL_0de9;
																																		case 124:
																																		case 288:
																																			goto IL_0dfc;
																																		case 80:
																																			goto IL_0e07;
																																		case 77:
																																		case 115:
																																			goto IL_0e15;
																																		case 0:
																																			goto IL_0e53;
																																		case 289:
																																			goto IL_0e7d;
																																		case 162:
																																			goto IL_0e91;
																																		case 191:
																																			goto IL_0ea4;
																																		case 210:
																																			goto IL_0eb2;
																																		case 64:
																																		case 220:
																																			goto IL_0ec0;
																																		case 164:
																																			goto IL_0ede;
																																		case 228:
																																			goto IL_0eec;
																																		case 21:
																																			goto IL_0eff;
																																		case 44:
																																		case 144:
																																			goto IL_0f13;
																																		case 187:
																																			goto IL_0f21;
																																		case 203:
																																		case 215:
																																			goto IL_0f34;
																																		case 219:
																																			goto IL_0ff4;
																																		case 271:
																																			goto IL_1002;
																																		case 229:
																																			goto IL_101e;
																																		case 87:
																																		case 263:
																																			goto IL_1029;
																																		case 52:
																																			goto IL_1069;
																																		case 123:
																																			goto IL_107d;
																																		case 194:
																																		case 206:
																																			goto IL_1099;
																																		case 59:
																																			goto IL_10a7;
																																		case 81:
																																		case 213:
																																			goto IL_10b2;
																																		case 235:
																																			goto IL_10db;
																																		case 91:
																																			goto IL_10e9;
																																		case 17:
																																			goto IL_10fc;
																																		case 251:
																																			goto IL_1107;
																																		case 71:
																																		case 108:
																																			goto IL_1115;
																																		case 158:
																																			goto IL_112e;
																																		case 186:
																																			goto IL_113c;
																																		case 193:
																																			goto IL_114a;
																																		case 208:
																																			goto IL_1166;
																																		case 113:
																																			goto IL_1174;
																																		case 151:
																																		case 261:
																																			goto IL_1182;
																																		case 98:
																																			goto IL_11cb;
																																		case 241:
																																			goto IL_11df;
																																		case 79:
																																		case 225:
																																			goto IL_11f2;
																																		case 5:
																																			goto IL_1200;
																																		case 90:
																																		case 275:
																																			goto IL_120b;
																																		case 283:
																																			goto IL_124b;
																																		case 6:
																																			goto IL_125f;
																																		case 150:
																																			goto IL_1272;
																																		case 48:
																																			goto IL_1280;
																																		case 24:
																																		case 159:
																																			goto IL_128e;
																																		case 200:
																																			goto IL_129c;
																																		case 198:
																																			goto IL_12bf;
																																		case 155:
																																			goto IL_12c9;
																																		case 138:
																																			goto IL_12d7;
																																		case 69:
																																			goto IL_12ea;
																																		case 248:
																																			goto IL_1301;
																																		case 54:
																																		case 245:
																																			goto IL_130f;
																																		case 218:
																																			goto IL_134f;
																																		case 129:
																																			goto IL_136c;
																																		case 23:
																																		case 285:
																																			goto IL_137c;
																																		case 11:
																																			goto IL_13a5;
																																		case 4:
																																		case 15:
																																		case 26:
																																		case 27:
																																		case 36:
																																		case 37:
																																		case 39:
																																		case 43:
																																		case 51:
																																		case 58:
																																		case 63:
																																		case 66:
																																		case 67:
																																		case 76:
																																		case 88:
																																		case 93:
																																		case 100:
																																		case 103:
																																		case 105:
																																		case 107:
																																		case 114:
																																		case 121:
																																		case 137:
																																		case 139:
																																		case 141:
																																		case 156:
																																		case 160:
																																		case 172:
																																		case 174:
																																		case 179:
																																		case 180:
																																		case 183:
																																		case 195:
																																		case 197:
																																		case 199:
																																		case 207:
																																		case 212:
																																		case 221:
																																		case 224:
																																		case 231:
																																		case 238:
																																		case 239:
																																		case 242:
																																		case 247:
																																		case 253:
																																		case 264:
																																		case 266:
																																		case 272:
																																		case 280:
																																		case 281:
																																			goto end_IL_0524;
																																		case 9:
																																		case 12:
																																		case 18:
																																		case 31:
																																		case 38:
																																		case 49:
																																		case 60:
																																		case 68:
																																		case 84:
																																		case 86:
																																		case 89:
																																		case 92:
																																		case 95:
																																		case 110:
																																		case 111:
																																		case 120:
																																		case 122:
																																		case 127:
																																		case 130:
																																		case 134:
																																		case 153:
																																		case 154:
																																		case 173:
																																		case 182:
																																		case 184:
																																		case 190:
																																		case 201:
																																		case 204:
																																		case 205:
																																		case 236:
																																		case 256:
																																		case 265:
																																		case 284:
																																			goto IL_13ce;
																																		case 117:
																																			goto IL_13e1;
																																		case 7:
																																			goto IL_13f4;
																																		case 230:
																																			goto IL_13ff;
																																		case 133:
																																			goto IL_140f;
																																		case 112:
																																			goto IL_141f;
																																		case 249:
																																			goto IL_142f;
																																		case 94:
																																			goto IL_143f;
																																		case 142:
																																			goto IL_144f;
																																		case 189:
																																			goto IL_1468;
																																		case 268:
																																			goto IL_1478;
																																		case 176:
																																			goto IL_1488;
																																		case 32:
																																		case 234:
																																			goto IL_14a3;
																																		}
																																		goto end_IL_0514;
																																	}
																																	goto IL_0ea4;
																																	IL_0ede:
																																	ptr2 += 8;
																																	goto IL_0eec;
																																	IL_0eec:
																																	num6--;
																																	goto IL_13ce;
																																	IL_0ea4:
																																	if (14 < b)
																																	{
																																		goto end_IL_0524;
																																	}
																																	goto IL_0eb2;
																																	IL_0eb2:
																																	if (14 > b)
																																	{
																																		goto end_IL_0524;
																																	}
																																	goto IL_0ec0;
																																	IL_0ec0:
																																	array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																																	goto IL_0ede;
																																	continue;
																																	end_IL_04c1:
																																	break;
																																}
																																break;
																															}
																															goto IL_0eff;
																															IL_0f34:
																															array8 = array3;
																															num7 = num6;
																															if (array == null)
																															{
																																goto IL_0f43;
																															}
																															num8 = ptr2;
																															byte b2 = *num8;
																															ptr2 = num8 + 4;
																															int num9 = *(int*)(ptr2 + num3);
																															ptr2 += 8;
																															byte* ptr3 = ptr2 + num9;
																															byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																															while (ptr2 != ptr3)
																															{
																																*ptr4 = (byte)(*ptr2 ^ b2);
																																ptr2++;
																																ptr4++;
																															}
																															array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																															num = 219;
																															goto IL_0ff4;
																															IL_1002:
																															num6++;
																															num = 49;
																															goto IL_13ce;
																															IL_0eff:
																															if (13 > b)
																															{
																																num = 144;
																																goto IL_0f13;
																															}
																															goto IL_0f34;
																															IL_0ff4:
																															array2[num6] = 5;
																															goto IL_1002;
																															IL_0f13:
																															if (12 < b)
																															{
																																goto end_IL_0524;
																															}
																															goto IL_0f21;
																															IL_0f21:
																															if (12 > b)
																															{
																																goto end_IL_0524;
																															}
																															goto IL_13ce;
																														}
																														break;
																													}
																													goto IL_055f;
																													IL_0e7d:
																													array2[num6 - 2] = 0;
																													goto IL_0e91;
																													IL_055f:
																													if (11 <= b)
																													{
																														goto IL_056d;
																													}
																													goto IL_05f6;
																													IL_056d:
																													array2[num6 - 2] = 0;
																													goto IL_0581;
																													IL_0581:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																													goto IL_0b0b;
																													IL_0b0b:
																													num6--;
																													goto IL_0b19;
																													IL_0b19:
																													ptr2 += 8;
																													goto IL_13ce;
																													IL_05f6:
																													if (9 < b)
																													{
																														goto IL_0604;
																													}
																													goto IL_0687;
																													IL_0604:
																													if (10 < b)
																													{
																														goto end_IL_0524;
																													}
																													goto IL_0612;
																													IL_0612:
																													if (10 > b)
																													{
																														goto end_IL_0524;
																													}
																													goto IL_0620;
																													IL_0620:
																													ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																													goto IL_0aa4;
																													IL_0aa4:
																													num6 -= 2;
																													goto IL_13ce;
																													IL_0687:
																													if (9 > b)
																													{
																														goto IL_0695;
																													}
																													goto IL_0cfc;
																													IL_0695:
																													if (8 < b)
																													{
																														num = 93;
																														goto end_IL_0524;
																													}
																													goto IL_0b2c;
																													IL_0e91:
																													num6--;
																													goto IL_13ce;
																													IL_0b2c:
																													if (8 > b)
																													{
																														goto end_IL_0524;
																													}
																													goto IL_0b3a;
																													IL_0b3a:
																													num6--;
																													goto IL_13ce;
																													IL_0cfc:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																													goto IL_0e7d;
																												}
																												break;
																											}
																											goto IL_101e;
																											IL_130f:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_134f;
																											IL_101e:
																											if (7 <= b)
																											{
																												goto IL_1029;
																											}
																											num = 206;
																											goto IL_1099;
																											IL_1029:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_1069;
																											IL_1069:
																											array2[num6 - 2] = 0;
																											goto IL_107d;
																											IL_107d:
																											num6--;
																											goto IL_13ce;
																											IL_134f:
																											array2[num6 - 2] = 0;
																											num = 129;
																											goto IL_136c;
																											IL_1099:
																											if (3 >= b)
																											{
																												goto IL_10a7;
																											}
																											goto IL_11f2;
																											IL_10a7:
																											if (3 <= b)
																											{
																												goto IL_10b2;
																											}
																											goto IL_10fc;
																											IL_10b2:
																											reference = ref array5[*(int*)(ptr2 + num3)];
																											reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_10db;
																											IL_10db:
																											ptr2 += 8;
																											goto IL_10e9;
																											IL_10e9:
																											num6--;
																											goto IL_13ce;
																											IL_10fc:
																											if (1 >= b)
																											{
																												goto IL_1107;
																											}
																											goto IL_1166;
																											IL_1107:
																											if (1 > b)
																											{
																												goto end_IL_0524;
																											}
																											goto IL_1115;
																											IL_1115:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																											goto IL_112e;
																											IL_112e:
																											array2[num6] = 0;
																											goto IL_113c;
																											IL_113c:
																											num6++;
																											goto IL_114a;
																											IL_114a:
																											ptr2 += 8;
																											num = 265;
																											goto IL_13ce;
																											IL_1166:
																											if (2 < b)
																											{
																												goto end_IL_0524;
																											}
																											goto IL_1174;
																											IL_1174:
																											if (2 > b)
																											{
																												goto end_IL_0524;
																											}
																											goto IL_1182;
																											IL_1182:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											num = 98;
																											goto IL_11cb;
																											IL_11cb:
																											array2[num6 - 2] = 0;
																											goto IL_11df;
																											IL_11df:
																											num6--;
																											goto IL_13ce;
																											IL_11f2:
																											if (5 >= b)
																											{
																												goto IL_1200;
																											}
																											goto IL_12ea;
																											IL_1200:
																											if (5 <= b)
																											{
																												goto IL_120b;
																											}
																											goto IL_1272;
																											IL_120b:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																											goto IL_124b;
																											IL_124b:
																											array2[num6 - 2] = 0;
																											goto IL_125f;
																											IL_125f:
																											num6--;
																											goto IL_13ce;
																											IL_1272:
																											if (4 < b)
																											{
																												goto end_IL_0524;
																											}
																											goto IL_1280;
																											IL_1280:
																											if (4 > b)
																											{
																												goto end_IL_0524;
																											}
																											goto IL_128e;
																											IL_128e:
																											array2[num6] = 0;
																											goto IL_129c;
																											IL_129c:
																											*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																											goto IL_12bf;
																											IL_12bf:
																											array3[num6] = null;
																											goto IL_12c9;
																											IL_12c9:
																											num6++;
																											goto IL_12d7;
																											IL_12d7:
																											ptr2 += 8;
																											goto IL_13ce;
																											IL_12ea:
																											if (6 < b)
																											{
																												goto end_IL_0524;
																											}
																											num = 248;
																											goto IL_1301;
																											IL_136c:
																											num6--;
																											goto IL_13ce;
																											IL_1301:
																											if (6 > b)
																											{
																												goto end_IL_0524;
																											}
																											goto IL_130f;
																										}
																										break;
																									}
																									goto IL_137c;
																									IL_13a5:
																									array2[num6 - 1] = 5;
																									goto IL_13ce;
																									IL_137c:
																									array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																									goto IL_13a5;
																								}
																								goto IL_07cd;
																							}
																							goto IL_05da;
																							IL_0896:
																							num6--;
																							goto IL_13ce;
																							IL_05da:
																							if (23 >= b)
																							{
																								goto IL_06b1;
																							}
																							num = 22;
																							goto IL_08a9;
																							IL_0dfc:
																							if (18 < b)
																							{
																								num = 179;
																								goto end_IL_0524;
																							}
																							goto IL_0e07;
																							IL_08a9:
																							if (27 < b)
																							{
																								goto IL_08b7;
																							}
																							num = 149;
																							goto IL_0943;
																							IL_08b7:
																							if (29 >= b)
																							{
																								goto IL_08c2;
																							}
																							goto IL_0927;
																							IL_08c2:
																							if (29 > b)
																							{
																								goto IL_08cd;
																							}
																							goto IL_090b;
																							IL_08cd:
																							if (28 < b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_08db;
																							IL_08db:
																							if (28 > b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_08e9;
																							IL_08e9:
																							array2[num6 - 2] = 5;
																							num = 279;
																							goto IL_0c7c;
																							IL_0c7c:
																							array3[num6 - 2] = ((delegate*<string, string, string>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
																							goto IL_0cc8;
																							IL_0cc8:
																							num6--;
																							goto IL_0cd6;
																							IL_0cd6:
																							ptr2 += 8;
																							goto IL_13ce;
																							IL_090b:
																							num10 = ptr2;
																							num11 = -200;
																							num5 = 1;
																							ptr2 = num10 + num11;
																							goto IL_13ce;
																							IL_0927:
																							if (30 < b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0c69;
																							IL_0c69:
																							if (30 > b)
																							{
																							}
																							goto end_IL_0524;
																							IL_0e07:
																							if (18 > b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0e15;
																							IL_0943:
																							if (27 > b)
																							{
																								goto IL_0951;
																							}
																							goto IL_0a13;
																							IL_0951:
																							if (25 >= b)
																							{
																								goto IL_095f;
																							}
																							goto IL_0d41;
																							IL_095f:
																							if (25 > b)
																							{
																								goto IL_096a;
																							}
																							num = 29;
																							goto IL_09c0;
																							IL_096a:
																							if (24 < b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0978;
																							IL_0978:
																							if (24 > b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0986;
																							IL_0986:
																							array3[num6] = ((delegate*<ThemeData[]>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])();
																							goto IL_09a4;
																							IL_09a4:
																							array2[num6] = 5;
																							goto IL_0c3f;
																							IL_0c3f:
																							num6++;
																							goto IL_0c4d;
																							IL_0c4d:
																							ptr2 += 8;
																							num = 18;
																							goto IL_13ce;
																							IL_0e15:
																							((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
																							goto IL_0e53;
																							IL_09c0:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])();
																							goto IL_09e4;
																							IL_09e4:
																							array2[num6] = 0;
																							goto IL_09f2;
																							IL_09f2:
																							num6++;
																							goto IL_0a00;
																							IL_0a00:
																							ptr2 += 8;
																							goto IL_13ce;
																							IL_0d41:
																							if (26 < b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0d4f;
																							IL_0d4f:
																							if (26 > b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0d5d;
																							IL_0d5d:
																							array2[num6 - 2] = 16;
																							goto IL_0d71;
																							IL_0d71:
																							array3[num6 - 2] = array3[num6 - 2];
																							num = 244;
																							goto IL_0d98;
																							IL_0d98:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0dc2;
																							IL_0dc2:
																							array4[num6 - 2] = *(int*)(ptr2 + num3);
																							goto IL_0ddb;
																							IL_0ddb:
																							ptr2 += 8;
																							goto IL_0de9;
																							IL_0de9:
																							num6--;
																							goto IL_13ce;
																							IL_0a13:
																							array3[num6 - 1] = ((delegate*<ref ThemeData, string>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref ThemeData>)setAsCyWrappedObject[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
																							goto IL_0a7d;
																							IL_0a7d:
																							array2[num6 - 1] = 5;
																							goto IL_0a91;
																							IL_0a91:
																							ptr2 += 8;
																							goto IL_13ce;
																							IL_06b1:
																							if (23 > b)
																							{
																								goto IL_06bf;
																							}
																							goto IL_0844;
																							IL_06bf:
																							if (19 < b)
																							{
																								goto IL_06ca;
																							}
																							goto IL_0745;
																							IL_06ca:
																							if (21 >= b)
																							{
																								goto IL_06d5;
																							}
																							goto IL_0724;
																							IL_06d5:
																							if (21 > b)
																							{
																								goto IL_06e0;
																							}
																							goto IL_070c;
																							IL_06e0:
																							if (20 < b)
																							{
																								num = 212;
																								goto end_IL_0524;
																							}
																							goto IL_06eb;
																							IL_06eb:
																							if (20 > b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0bee;
																							IL_0bee:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
																							goto IL_0c07;
																							IL_0c07:
																							array2[num6] = 1;
																							goto IL_0c15;
																							IL_0c15:
																							num6++;
																							num = 185;
																							goto IL_0c2c;
																							IL_0c2c:
																							ptr2 += 16;
																							goto IL_13ce;
																							IL_0e53:
																							num6 -= 3;
																							num = 201;
																							goto IL_13ce;
																							IL_070c:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto IL_13ce;
																							IL_0724:
																							if (22 < b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0732;
																							IL_0732:
																							if (22 > b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_0b4d;
																							IL_0b4d:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
																							goto IL_0b8e;
																							IL_0b8e:
																							array2[num6 - 2] = 0;
																							goto IL_0ba2;
																							IL_0ba2:
																							num6--;
																							goto IL_13ce;
																							IL_0745:
																							if (19 <= b)
																							{
																								goto IL_0750;
																							}
																							goto IL_07a1;
																							IL_0750:
																							array2[num6 - 1] = 5;
																							goto IL_0764;
																							IL_0764:
																							array3[num6 - 1] = ((delegate*<string[], string>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																							goto IL_0af8;
																							IL_0af8:
																							ptr2 += 8;
																							goto IL_13ce;
																							IL_07a1:
																							if (17 >= b)
																							{
																								goto IL_07af;
																							}
																							num = 124;
																							goto IL_0dfc;
																							IL_07af:
																							if (17 <= b)
																							{
																								goto IL_07ba;
																							}
																							goto IL_07cd;
																							IL_07ba:
																							array2[num6] = 5;
																							goto IL_0bb5;
																							IL_0bb5:
																							array3[num6] = array7[*(int*)(ptr2 + num3)];
																							goto IL_0bcd;
																							IL_0bcd:
																							num6++;
																							goto IL_0bdb;
																							IL_0bdb:
																							ptr2 += 8;
																							goto IL_13ce;
																							IL_07cd:
																							if (16 < b)
																							{
																								goto end_IL_0524;
																							}
																							num = 56;
																							goto IL_07e4;
																							IL_0844:
																							ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																							goto IL_0896;
																							IL_07e4:
																							if (16 > b)
																							{
																								goto end_IL_0524;
																							}
																							goto IL_07f2;
																							IL_07f2:
																							array2[num6] = array2[num6 - 1];
																							num = 188;
																							goto IL_0813;
																							IL_0813:
																							array4[num6 - 0] = array4[num6 - 1];
																							goto IL_0ab7;
																							IL_0ab7:
																							*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																							goto IL_0adb;
																							IL_0adb:
																							array3[num6] = array3[num6 - 1];
																							goto IL_0ce9;
																							IL_0ce9:
																							num6++;
																							goto IL_13ce;
																							continue;
																							end_IL_0514:
																							break;
																						}
																						goto end_IL_0534;
																						continue;
																						end_IL_0524:
																						break;
																						IL_0524:;
																					}
																				}
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto IL_13ce;
																				continue;
																				end_IL_0534:
																				break;
																			}
																			break;
																		}
																		break;
																	}
																	break;
																}
																goto IL_14a3;
																IL_14a3:
																return (string)array3[num6 - 1];
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
						break;
					}
					break;
				}
			}
			continue;
			IL_0f43:
			while (true)
			{
				IL_0f43_2:
				array = new byte[4];
				while (true)
				{
					num8 = ptr2;
					byte b2 = *num8;
					ptr2 = num8 + 4;
					int num9 = *(int*)(ptr2 + num3);
					ptr2 += 8;
					byte* ptr3 = ptr2 + num9;
					byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
					while (ptr2 != ptr3)
					{
						*ptr4 = (byte)(*ptr2 ^ b2);
						ptr2++;
						ptr4++;
					}
					array8[num7] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
					num = 219;
					while (true)
					{
						IL_0ff4_2:
						array2[num6] = 5;
						while (true)
						{
							IL_1002_2:
							num6++;
							num = 49;
							while (true)
							{
								IL_13ce_2:
								if (num5 != 1)
								{
									while (true)
									{
										byte b = *ptr2;
										while (true)
										{
											ptr2++;
											while (true)
											{
												IL_0534_2:
												if (b >= 1)
												{
													while (b <= 30)
													{
														while (true)
														{
															IL_0514_2:
															if (15 >= b)
															{
																while (true)
																{
																	IL_0504_2:
																	if (15 > b)
																	{
																		while (true)
																		{
																			IL_04f4_2:
																			if (7 < b)
																			{
																				while (true)
																				{
																					IL_04e7_2:
																					if (11 < b)
																					{
																						while (true)
																						{
																							IL_04d4_2:
																							if (13 < b)
																							{
																								num = 297;
																								while (true)
																								{
																									if (num != 297)
																									{
																										if (num != 1278)
																										{
																											break;
																										}
																										switch (num)
																										{
																										case 171:
																											goto IL_04d4_2;
																										case 62:
																										case 250:
																											goto IL_04e7_2;
																										case 13:
																											goto IL_04f4_2;
																										case 47:
																											goto IL_0504_2;
																										case 255:
																											goto IL_0514_2;
																										case 169:
																											goto end_IL_0514_2;
																										case 168:
																											goto IL_0534_2;
																										case 33:
																											goto end_IL_0534_2;
																										case 276:
																										case 290:
																											goto end_IL_0544;
																										case 45:
																											goto IL_055f_2;
																										case 125:
																										case 143:
																											goto IL_056d_2;
																										case 35:
																											goto IL_0581_2;
																										case 132:
																										case 170:
																											goto IL_05da_2;
																										case 252:
																											goto IL_05f6_2;
																										case 50:
																										case 140:
																											goto IL_0604_2;
																										case 211:
																											goto IL_0612_2;
																										case 46:
																										case 116:
																											goto IL_0620_2;
																										case 78:
																											goto IL_0687_2;
																										case 217:
																											goto IL_0695_2;
																										case 257:
																											goto IL_06b1_2;
																										case 102:
																										case 167:
																											goto IL_06bf_2;
																										case 3:
																										case 8:
																											goto IL_06ca_2;
																										case 41:
																											goto IL_06d5_2;
																										case 136:
																										case 222:
																											goto IL_06e0_2;
																										case 148:
																											goto IL_06eb_2;
																										case 85:
																										case 216:
																											goto IL_070c_2;
																										case 175:
																											goto IL_0724_2;
																										case 72:
																											goto IL_0732_2;
																										case 246:
																											goto IL_0745_2;
																										case 20:
																										case 106:
																											goto IL_0750_2;
																										case 101:
																											goto IL_0764_2;
																										case 74:
																											goto IL_07a1_2;
																										case 10:
																											goto IL_07af_2;
																										case 61:
																										case 192:
																											goto IL_07ba_2;
																										case 152:
																											goto end_IL_04c1_2;
																										case 56:
																											goto IL_07e4_2;
																										case 34:
																										case 70:
																											goto IL_07f2_2;
																										case 188:
																											goto IL_0813_2;
																										case 73:
																										case 233:
																											goto IL_0844_2;
																										case 237:
																											goto IL_0896_2;
																										case 22:
																										case 258:
																											goto IL_08a9_2;
																										case 243:
																											goto IL_08b7_2;
																										case 146:
																											goto IL_08c2_2;
																										case 25:
																										case 254:
																											goto IL_08cd_2;
																										case 196:
																											goto IL_08db_2;
																										case 97:
																										case 202:
																											goto IL_08e9_2;
																										case 157:
																										case 223:
																											goto IL_090b_2;
																										case 40:
																											goto IL_0927_2;
																										case 149:
																											goto IL_0943_2;
																										case 163:
																										case 165:
																											goto IL_0951_2;
																										case 181:
																											goto IL_095f_2;
																										case 119:
																											goto IL_096a_2;
																										case 42:
																											goto IL_0978_2;
																										case 145:
																										case 226:
																											goto IL_0986_2;
																										case 99:
																											goto IL_09a4_2;
																										case 28:
																										case 29:
																											goto IL_09c0_2;
																										case 161:
																											goto IL_09e4_2;
																										case 240:
																											goto IL_09f2_2;
																										case 65:
																											goto IL_0a00_2;
																										case 96:
																										case 232:
																											goto IL_0a13_2;
																										case 55:
																											goto IL_0a7d_2;
																										case 14:
																											goto IL_0a91_2;
																										case 259:
																											goto IL_0aa4_2;
																										case 260:
																											goto IL_0ab7_2;
																										case 227:
																											goto IL_0adb_2;
																										case 262:
																											goto IL_0af8_2;
																										case 267:
																											goto IL_0b0b_2;
																										case 109:
																											goto IL_0b19_2;
																										case 269:
																											goto IL_0b2c_2;
																										case 57:
																										case 178:
																											goto IL_0b3a_2;
																										case 209:
																										case 270:
																											goto IL_0b4d_2;
																										case 128:
																											goto IL_0b8e_2;
																										case 135:
																											goto IL_0ba2_2;
																										case 273:
																											goto IL_0bb5_2;
																										case 104:
																											goto IL_0bcd_2;
																										case 16:
																											goto IL_0bdb_2;
																										case 131:
																										case 274:
																											goto IL_0bee_2;
																										case 82:
																											goto IL_0c07_2;
																										case 19:
																											goto IL_0c15_2;
																										case 185:
																											goto IL_0c2c_2;
																										case 277:
																											goto IL_0c3f_2;
																										case 53:
																											goto IL_0c4d_2;
																										case 278:
																											goto IL_0c69_2;
																										case 279:
																											goto IL_0c7c_2;
																										case 30:
																											goto IL_0cc8_2;
																										case 214:
																											goto IL_0cd6_2;
																										case 282:
																											goto IL_0ce9_2;
																										case 1:
																										case 286:
																											goto IL_0cfc_2;
																										case 287:
																											goto IL_0d41_2;
																										case 75:
																											goto IL_0d4f_2;
																										case 2:
																										case 147:
																											goto IL_0d5d_2;
																										case 166:
																											goto IL_0d71_2;
																										case 244:
																											goto IL_0d98_2;
																										case 118:
																											goto IL_0dc2_2;
																										case 126:
																											goto IL_0ddb_2;
																										case 83:
																											goto IL_0de9_2;
																										case 124:
																										case 288:
																											goto IL_0dfc_2;
																										case 80:
																											goto IL_0e07_2;
																										case 77:
																										case 115:
																											goto IL_0e15_2;
																										case 0:
																											goto IL_0e53_2;
																										case 289:
																											goto IL_0e7d_2;
																										case 162:
																											goto IL_0e91_2;
																										case 191:
																											goto IL_0ea4_2;
																										case 210:
																											goto IL_0eb2_2;
																										case 64:
																										case 220:
																											goto IL_0ec0_2;
																										case 164:
																											goto IL_0ede_2;
																										case 228:
																											goto IL_0eec_2;
																										case 21:
																											goto IL_0eff_2;
																										case 44:
																										case 144:
																											goto IL_0f13_2;
																										case 187:
																											goto IL_0f21_2;
																										case 203:
																										case 215:
																											goto end_IL_0554;
																										case 219:
																											goto IL_0ff4_2;
																										case 271:
																											goto IL_1002_2;
																										case 229:
																											goto IL_101e_2;
																										case 87:
																										case 263:
																											goto IL_1029_2;
																										case 52:
																											goto IL_1069_2;
																										case 123:
																											goto IL_107d_2;
																										case 194:
																										case 206:
																											goto IL_1099_2;
																										case 59:
																											goto IL_10a7_2;
																										case 81:
																										case 213:
																											goto IL_10b2_2;
																										case 235:
																											goto IL_10db_2;
																										case 91:
																											goto IL_10e9_2;
																										case 17:
																											goto IL_10fc_2;
																										case 251:
																											goto IL_1107_2;
																										case 71:
																										case 108:
																											goto IL_1115_2;
																										case 158:
																											goto IL_112e_2;
																										case 186:
																											goto IL_113c_2;
																										case 193:
																											goto IL_114a_2;
																										case 208:
																											goto IL_1166_2;
																										case 113:
																											goto IL_1174_2;
																										case 151:
																										case 261:
																											goto IL_1182_2;
																										case 98:
																											goto IL_11cb_2;
																										case 241:
																											goto IL_11df_2;
																										case 79:
																										case 225:
																											goto IL_11f2_2;
																										case 5:
																											goto IL_1200_2;
																										case 90:
																										case 275:
																											goto IL_120b_2;
																										case 283:
																											goto IL_124b_2;
																										case 6:
																											goto IL_125f_2;
																										case 150:
																											goto IL_1272_2;
																										case 48:
																											goto IL_1280_2;
																										case 24:
																										case 159:
																											goto IL_128e_2;
																										case 200:
																											goto IL_129c_2;
																										case 198:
																											goto IL_12bf_2;
																										case 155:
																											goto IL_12c9_2;
																										case 138:
																											goto IL_12d7_2;
																										case 69:
																											goto IL_12ea_2;
																										case 248:
																											goto IL_1301_2;
																										case 54:
																										case 245:
																											goto IL_130f_2;
																										case 218:
																											goto IL_134f_2;
																										case 129:
																											goto IL_136c_2;
																										case 23:
																										case 285:
																											goto IL_137c_2;
																										case 11:
																											goto IL_13a5_2;
																										case 4:
																										case 15:
																										case 26:
																										case 27:
																										case 36:
																										case 37:
																										case 39:
																										case 43:
																										case 51:
																										case 58:
																										case 63:
																										case 66:
																										case 67:
																										case 76:
																										case 88:
																										case 93:
																										case 100:
																										case 103:
																										case 105:
																										case 107:
																										case 114:
																										case 121:
																										case 137:
																										case 139:
																										case 141:
																										case 156:
																										case 160:
																										case 172:
																										case 174:
																										case 179:
																										case 180:
																										case 183:
																										case 195:
																										case 197:
																										case 199:
																										case 207:
																										case 212:
																										case 221:
																										case 224:
																										case 231:
																										case 238:
																										case 239:
																										case 242:
																										case 247:
																										case 253:
																										case 264:
																										case 266:
																										case 272:
																										case 280:
																										case 281:
																											goto end_IL_0524_2;
																										case 9:
																										case 12:
																										case 18:
																										case 31:
																										case 38:
																										case 49:
																										case 60:
																										case 68:
																										case 84:
																										case 86:
																										case 89:
																										case 92:
																										case 95:
																										case 110:
																										case 111:
																										case 120:
																										case 122:
																										case 127:
																										case 130:
																										case 134:
																										case 153:
																										case 154:
																										case 173:
																										case 182:
																										case 184:
																										case 190:
																										case 201:
																										case 204:
																										case 205:
																										case 236:
																										case 256:
																										case 265:
																										case 284:
																											goto IL_13ce_2;
																										case 117:
																											ptr2 = ptr;
																											num = 256;
																											goto IL_13ce_2;
																										case 7:
																											ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ClassesRootAllowParentheses.BuiltinSystemOperatorsSidEncoderExceptionFallback);
																											goto case 117;
																										case 230:
																											array7 = new object[7];
																											goto case 7;
																										case 133:
																											array6 = new long[4];
																											goto case 230;
																										case 112:
																											array5 = new int[7];
																											goto case 133;
																										case 249:
																											array4 = new int[4];
																											goto case 112;
																										case 94:
																											array3 = new object[4];
																											goto case 249;
																										case 142:
																											array2 = new byte[4];
																											num = 94;
																											goto case 94;
																										case 189:
																											num4 = num2 * 8;
																											goto case 142;
																										case 268:
																											num3 = num2 * 4;
																											goto case 189;
																										case 176:
																											num2 = 1;
																											goto case 268;
																										case 177:
																											goto end_IL_0f51;
																										case 32:
																										case 234:
																											goto IL_14a3_2;
																										}
																										continue;
																									}
																									goto IL_0ea4_2;
																									IL_0ede_2:
																									ptr2 += 8;
																									goto IL_0eec_2;
																									IL_0eec_2:
																									num6--;
																									goto IL_13ce_2;
																									IL_0ea4_2:
																									if (14 < b)
																									{
																										goto end_IL_0524_2;
																									}
																									goto IL_0eb2_2;
																									IL_0eb2_2:
																									if (14 > b)
																									{
																										goto end_IL_0524_2;
																									}
																									goto IL_0ec0_2;
																									IL_0ec0_2:
																									array7[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																									goto IL_0ede_2;
																									continue;
																									end_IL_04c1_2:
																									break;
																								}
																								break;
																							}
																							goto IL_0eff_2;
																							IL_0f21_2:
																							if (12 > b)
																							{
																								goto end_IL_0524_2;
																							}
																							goto IL_13ce_2;
																							IL_0f13_2:
																							if (12 < b)
																							{
																								goto end_IL_0524_2;
																							}
																							goto IL_0f21_2;
																							IL_0eff_2:
																							if (13 <= b)
																							{
																								goto end_IL_0554;
																							}
																							num = 144;
																							goto IL_0f13_2;
																						}
																						break;
																					}
																					goto IL_055f_2;
																					IL_0e7d_2:
																					array2[num6 - 2] = 0;
																					goto IL_0e91_2;
																					IL_055f_2:
																					if (11 <= b)
																					{
																						goto IL_056d_2;
																					}
																					goto IL_05f6_2;
																					IL_056d_2:
																					array2[num6 - 2] = 0;
																					goto IL_0581_2;
																					IL_0581_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((delegate*<int, int, int>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]), *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]));
																					goto IL_0b0b_2;
																					IL_0b0b_2:
																					num6--;
																					goto IL_0b19_2;
																					IL_0b19_2:
																					ptr2 += 8;
																					goto IL_13ce_2;
																					IL_05f6_2:
																					if (9 < b)
																					{
																						goto IL_0604_2;
																					}
																					goto IL_0687_2;
																					IL_0604_2:
																					if (10 < b)
																					{
																						goto end_IL_0524_2;
																					}
																					goto IL_0612_2;
																					IL_0612_2:
																					if (10 > b)
																					{
																						goto end_IL_0524_2;
																					}
																					goto IL_0620_2;
																					IL_0620_2:
																					ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																					goto IL_0aa4_2;
																					IL_0aa4_2:
																					num6 -= 2;
																					goto IL_13ce_2;
																					IL_0687_2:
																					if (9 > b)
																					{
																						goto IL_0695_2;
																					}
																					goto IL_0cfc_2;
																					IL_0695_2:
																					if (8 < b)
																					{
																						num = 93;
																						goto end_IL_0524_2;
																					}
																					goto IL_0b2c_2;
																					IL_0e91_2:
																					num6--;
																					goto IL_13ce_2;
																					IL_0b2c_2:
																					if (8 > b)
																					{
																						goto end_IL_0524_2;
																					}
																					goto IL_0b3a_2;
																					IL_0b3a_2:
																					num6--;
																					goto IL_13ce_2;
																					IL_0cfc_2:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																					goto IL_0e7d_2;
																				}
																				break;
																			}
																			goto IL_101e_2;
																			IL_130f_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) & *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_134f_2;
																			IL_101e_2:
																			if (7 <= b)
																			{
																				goto IL_1029_2;
																			}
																			num = 206;
																			goto IL_1099_2;
																			IL_1029_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_1069_2;
																			IL_1069_2:
																			array2[num6 - 2] = 0;
																			goto IL_107d_2;
																			IL_107d_2:
																			num6--;
																			goto IL_13ce_2;
																			IL_134f_2:
																			array2[num6 - 2] = 0;
																			num = 129;
																			goto IL_136c_2;
																			IL_1099_2:
																			if (3 >= b)
																			{
																				goto IL_10a7_2;
																			}
																			goto IL_11f2_2;
																			IL_10a7_2:
																			if (3 <= b)
																			{
																				goto IL_10b2_2;
																			}
																			goto IL_10fc_2;
																			IL_10b2_2:
																			reference = ref array5[*(int*)(ptr2 + num3)];
																			reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_10db_2;
																			IL_10db_2:
																			ptr2 += 8;
																			goto IL_10e9_2;
																			IL_10e9_2:
																			num6--;
																			goto IL_13ce_2;
																			IL_10fc_2:
																			if (1 >= b)
																			{
																				goto IL_1107_2;
																			}
																			goto IL_1166_2;
																			IL_1107_2:
																			if (1 > b)
																			{
																				goto end_IL_0524_2;
																			}
																			goto IL_1115_2;
																			IL_1115_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(int*)(ptr2 + num3);
																			goto IL_112e_2;
																			IL_112e_2:
																			array2[num6] = 0;
																			goto IL_113c_2;
																			IL_113c_2:
																			num6++;
																			goto IL_114a_2;
																			IL_114a_2:
																			ptr2 += 8;
																			num = 265;
																			goto IL_13ce_2;
																			IL_1166_2:
																			if (2 < b)
																			{
																				goto end_IL_0524_2;
																			}
																			goto IL_1174_2;
																			IL_1174_2:
																			if (2 > b)
																			{
																				goto end_IL_0524_2;
																			}
																			goto IL_1182_2;
																			IL_1182_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			num = 98;
																			goto IL_11cb_2;
																			IL_11cb_2:
																			array2[num6 - 2] = 0;
																			goto IL_11df_2;
																			IL_11df_2:
																			num6--;
																			goto IL_13ce_2;
																			IL_11f2_2:
																			if (5 >= b)
																			{
																				goto IL_1200_2;
																			}
																			goto IL_12ea_2;
																			IL_1200_2:
																			if (5 <= b)
																			{
																				goto IL_120b_2;
																			}
																			goto IL_1272_2;
																			IL_120b_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
																			goto IL_124b_2;
																			IL_124b_2:
																			array2[num6 - 2] = 0;
																			goto IL_125f_2;
																			IL_125f_2:
																			num6--;
																			goto IL_13ce_2;
																			IL_1272_2:
																			if (4 < b)
																			{
																				goto end_IL_0524_2;
																			}
																			goto IL_1280_2;
																			IL_1280_2:
																			if (4 > b)
																			{
																				goto end_IL_0524_2;
																			}
																			goto IL_128e_2;
																			IL_128e_2:
																			array2[num6] = 0;
																			goto IL_129c_2;
																			IL_129c_2:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = array5[*(int*)(ptr2 + num3)];
																			goto IL_12bf_2;
																			IL_12bf_2:
																			array3[num6] = null;
																			goto IL_12c9_2;
																			IL_12c9_2:
																			num6++;
																			goto IL_12d7_2;
																			IL_12d7_2:
																			ptr2 += 8;
																			goto IL_13ce_2;
																			IL_12ea_2:
																			if (6 < b)
																			{
																				goto end_IL_0524_2;
																			}
																			num = 248;
																			goto IL_1301_2;
																			IL_136c_2:
																			num6--;
																			goto IL_13ce_2;
																			IL_1301_2:
																			if (6 > b)
																			{
																				goto end_IL_0524_2;
																			}
																			goto IL_130f_2;
																		}
																		break;
																	}
																	goto IL_137c_2;
																	IL_13a5_2:
																	array2[num6 - 1] = 5;
																	goto IL_13ce_2;
																	IL_137c_2:
																	array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])];
																	goto IL_13a5_2;
																}
																goto IL_07cd_2;
															}
															goto IL_05da_2;
															IL_0896_2:
															num6--;
															goto IL_13ce_2;
															IL_05da_2:
															if (23 >= b)
															{
																goto IL_06b1_2;
															}
															num = 22;
															goto IL_08a9_2;
															IL_0dfc_2:
															if (18 < b)
															{
																num = 179;
																goto end_IL_0524_2;
															}
															goto IL_0e07_2;
															IL_08a9_2:
															if (27 < b)
															{
																goto IL_08b7_2;
															}
															num = 149;
															goto IL_0943_2;
															IL_08b7_2:
															if (29 >= b)
															{
																goto IL_08c2_2;
															}
															goto IL_0927_2;
															IL_08c2_2:
															if (29 > b)
															{
																goto IL_08cd_2;
															}
															goto IL_090b_2;
															IL_08cd_2:
															if (28 < b)
															{
																goto end_IL_0524_2;
															}
															goto IL_08db_2;
															IL_08db_2:
															if (28 > b)
															{
																goto end_IL_0524_2;
															}
															goto IL_08e9_2;
															IL_08e9_2:
															array2[num6 - 2] = 5;
															num = 279;
															goto IL_0c7c_2;
															IL_0c7c_2:
															array3[num6 - 2] = ((delegate*<string, string, string>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (string)array3[num6 - 1]);
															goto IL_0cc8_2;
															IL_0cc8_2:
															num6--;
															goto IL_0cd6_2;
															IL_0cd6_2:
															ptr2 += 8;
															goto IL_13ce_2;
															IL_090b_2:
															num10 = ptr2;
															num11 = -200;
															num5 = 1;
															ptr2 = num10 + num11;
															goto IL_13ce_2;
															IL_0927_2:
															if (30 < b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0c69_2;
															IL_0c69_2:
															if (30 > b)
															{
															}
															goto end_IL_0524_2;
															IL_0e07_2:
															if (18 > b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0e15_2;
															IL_0943_2:
															if (27 > b)
															{
																goto IL_0951_2;
															}
															goto IL_0a13_2;
															IL_0951_2:
															if (25 >= b)
															{
																goto IL_095f_2;
															}
															goto IL_0d41_2;
															IL_095f_2:
															if (25 > b)
															{
																goto IL_096a_2;
															}
															num = 29;
															goto IL_09c0_2;
															IL_096a_2:
															if (24 < b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0978_2;
															IL_0978_2:
															if (24 > b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0986_2;
															IL_0986_2:
															array3[num6] = ((delegate*<ThemeData[]>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])();
															goto IL_09a4_2;
															IL_09a4_2:
															array2[num6] = 5;
															goto IL_0c3f_2;
															IL_0c3f_2:
															num6++;
															goto IL_0c4d_2;
															IL_0c4d_2:
															ptr2 += 8;
															num = 18;
															goto IL_13ce_2;
															IL_0e15_2:
															((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2])] = (string)array3[num6 - 1];
															goto IL_0e53_2;
															IL_09c0_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = ((delegate*<int>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])();
															goto IL_09e4_2;
															IL_09e4_2:
															array2[num6] = 0;
															goto IL_09f2_2;
															IL_09f2_2:
															num6++;
															goto IL_0a00_2;
															IL_0a00_2:
															ptr2 += 8;
															goto IL_13ce_2;
															IL_0d41_2:
															if (26 < b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0d4f_2;
															IL_0d4f_2:
															if (26 > b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0d5d_2;
															IL_0d5d_2:
															array2[num6 - 2] = 16;
															goto IL_0d71_2;
															IL_0d71_2:
															array3[num6 - 2] = array3[num6 - 2];
															num = 244;
															goto IL_0d98_2;
															IL_0d98_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0dc2_2;
															IL_0dc2_2:
															array4[num6 - 2] = *(int*)(ptr2 + num3);
															goto IL_0ddb_2;
															IL_0ddb_2:
															ptr2 += 8;
															goto IL_0de9_2;
															IL_0de9_2:
															num6--;
															goto IL_13ce_2;
															IL_0a13_2:
															array3[num6 - 1] = ((delegate*<ref ThemeData, string>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])(ref ((delegate*<object, IntPtr, object[], int[], ref ThemeData>)setAsCyWrappedObject[array4[num6 - 1]])(array3[num6 - 1], (IntPtr)(*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])), array7, array5));
															goto IL_0a7d_2;
															IL_0a7d_2:
															array2[num6 - 1] = 5;
															goto IL_0a91_2;
															IL_0a91_2:
															ptr2 += 8;
															goto IL_13ce_2;
															IL_06b1_2:
															if (23 > b)
															{
																goto IL_06bf_2;
															}
															goto IL_0844_2;
															IL_06bf_2:
															if (19 < b)
															{
																goto IL_06ca_2;
															}
															goto IL_0745_2;
															IL_06ca_2:
															if (21 >= b)
															{
																goto IL_06d5_2;
															}
															goto IL_0724_2;
															IL_06d5_2:
															if (21 > b)
															{
																goto IL_06e0_2;
															}
															goto IL_070c_2;
															IL_06e0_2:
															if (20 < b)
															{
																num = 212;
																goto end_IL_0524_2;
															}
															goto IL_06eb_2;
															IL_06eb_2:
															if (20 > b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0bee_2;
															IL_0bee_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)(ptr2 + num4);
															goto IL_0c07_2;
															IL_0c07_2:
															array2[num6] = 1;
															goto IL_0c15_2;
															IL_0c15_2:
															num6++;
															num = 185;
															goto IL_0c2c_2;
															IL_0c2c_2:
															ptr2 += 16;
															goto IL_13ce_2;
															IL_0e53_2:
															num6 -= 3;
															num = 201;
															goto IL_13ce_2;
															IL_070c_2:
															ptr2 = ptr + *(int*)(ptr2 + num3);
															goto IL_13ce_2;
															IL_0724_2:
															if (22 < b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0732_2;
															IL_0732_2:
															if (22 > b)
															{
																goto end_IL_0524_2;
															}
															goto IL_0b4d_2;
															IL_0b4d_2:
															*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 2]) == *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1])) ? 1 : 0);
															goto IL_0b8e_2;
															IL_0b8e_2:
															array2[num6 - 2] = 0;
															goto IL_0ba2_2;
															IL_0ba2_2:
															num6--;
															goto IL_13ce_2;
															IL_0745_2:
															if (19 <= b)
															{
																goto IL_0750_2;
															}
															goto IL_07a1_2;
															IL_0750_2:
															array2[num6 - 1] = 5;
															goto IL_0764_2;
															IL_0764_2:
															array3[num6 - 1] = ((delegate*<string[], string>)setAsCyWrappedObject[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
															goto IL_0af8_2;
															IL_0af8_2:
															ptr2 += 8;
															goto IL_13ce_2;
															IL_07a1_2:
															if (17 >= b)
															{
																goto IL_07af_2;
															}
															num = 124;
															goto IL_0dfc_2;
															IL_07af_2:
															if (17 <= b)
															{
																goto IL_07ba_2;
															}
															goto IL_07cd_2;
															IL_07ba_2:
															array2[num6] = 5;
															goto IL_0bb5_2;
															IL_0bb5_2:
															array3[num6] = array7[*(int*)(ptr2 + num3)];
															goto IL_0bcd_2;
															IL_0bcd_2:
															num6++;
															goto IL_0bdb_2;
															IL_0bdb_2:
															ptr2 += 8;
															goto IL_13ce_2;
															IL_07cd_2:
															if (16 < b)
															{
																goto end_IL_0524_2;
															}
															num = 56;
															goto IL_07e4_2;
															IL_0844_2:
															ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]) == 0) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
															goto IL_0896_2;
															IL_07e4_2:
															if (16 > b)
															{
																goto end_IL_0524_2;
															}
															goto IL_07f2_2;
															IL_07f2_2:
															array2[num6] = array2[num6 - 1];
															num = 188;
															goto IL_0813_2;
															IL_0813_2:
															array4[num6 - 0] = array4[num6 - 1];
															goto IL_0ab7_2;
															IL_0ab7_2:
															*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array6[num6 - 1]);
															goto IL_0adb_2;
															IL_0adb_2:
															array3[num6] = array3[num6 - 1];
															goto IL_0ce9_2;
															IL_0ce9_2:
															num6++;
															goto IL_13ce_2;
															continue;
															end_IL_0514_2:
															break;
														}
														continue;
														end_IL_0524_2:
														break;
													}
												}
												ptr2 = ptr + *(int*)(ptr2 + num3);
												goto IL_13ce_2;
												continue;
												end_IL_0534_2:
												break;
											}
											continue;
											end_IL_0544:
											break;
										}
										continue;
										end_IL_0554:
										break;
									}
									break;
								}
								goto IL_14a3_2;
								IL_14a3_2:
								return (string)array3[num6 - 1];
							}
							break;
						}
						break;
					}
					array8 = array3;
					num7 = num6;
					if (array == null)
					{
						goto IL_0f43_2;
					}
					continue;
					end_IL_0f51:
					break;
				}
				break;
			}
		}
	}

	public static void smethod_2()
	{
		int num = 364;
		int num2 = 7;
		num = 52;
		num = 259;
		num2 = 7;
		num = 37;
		num = 52;
		num2 = 37;
		num = 17;
		num2 = 52;
		num2 = 36;
		num = 53;
		num = 53;
		num = 171;
		num2 = 3;
		num = 57;
		num = 156;
		num2 = 3;
		num = 52;
		num = 57;
		num2 = 52;
		num = 109;
		num2 = 57;
		num2 = 2964;
		num = 3065;
		num = 3065;
		num2 = 53;
		num = 3118;
		num = 564;
		num2 = 3;
		num = 188;
		num2 = 1820;
		num2 = 260;
		object obj = " ";
		object obj2 = obj;
		obj = "h";
		object obj3 = obj;
		obj = "e";
		object obj4 = obj;
		obj = "a";
		object obj5 = obj;
		obj = "o";
		object obj6 = obj;
		obj = ":";
		object obj7 = obj;
		obj = "w";
		object obj8 = obj;
		obj = "b";
		object obj9 = obj;
		obj = "i";
		object obj10 = obj;
		obj = "R";
		object obj11 = obj;
		obj = "n";
		object obj12 = obj;
		obj = "m";
		object obj13 = obj;
		obj = "T";
		object obj14 = obj;
		num = 35;
		num2 = 5;
		num = 7;
		obj = new string[7];
		object obj15 = obj;
		object obj16 = obj11;
		((string[])obj15)[0] = (string)obj16;
		obj15 = obj;
		obj16 = obj5;
		((string[])obj15)[1] = (string)obj16;
		obj15 = obj;
		obj16 = obj10;
		((string[])obj15)[2] = (string)obj16;
		obj15 = obj;
		obj16 = obj12;
		((string[])obj15)[3] = (string)obj16;
		obj15 = obj;
		obj16 = obj9;
		((string[])obj15)[4] = (string)obj16;
		obj15 = obj;
		obj16 = obj6;
		((string[])obj15)[5] = (string)obj16;
		obj15 = obj;
		obj16 = obj8;
		((string[])obj15)[6] = (string)obj16;
		string text = string.Concat((string[])obj);
		obj = text;
		object obj17 = obj;
		num = 28;
		num2 = 4;
		num = 7;
		obj = new string[7];
		obj15 = obj;
		obj16 = obj14;
		((string[])obj15)[0] = (string)obj16;
		obj15 = obj;
		obj16 = obj3;
		((string[])obj15)[1] = (string)obj16;
		obj15 = obj;
		obj16 = obj4;
		((string[])obj15)[2] = (string)obj16;
		obj15 = obj;
		obj16 = obj13;
		((string[])obj15)[3] = (string)obj16;
		obj15 = obj;
		obj16 = obj4;
		((string[])obj15)[4] = (string)obj16;
		obj15 = obj;
		obj16 = obj7;
		((string[])obj15)[5] = (string)obj16;
		obj15 = obj;
		obj16 = obj2;
		((string[])obj15)[6] = (string)obj16;
		string text2 = string.Concat((string[])obj);
		obj = text2;
		object obj18 = obj;
		num = 0;
		int num3 = 0;
		while (true)
		{
			num = num3;
			num2 = 49;
			num2 = 7;
			if (num == 7)
			{
				goto IL_0390;
			}
			goto IL_040d;
			IL_040d:
			num = num3;
			num2 = 10;
			num2 = 5;
			if (num == 5)
			{
				goto IL_0333;
			}
			goto IL_0376;
			IL_0376:
			num = num3;
			num2 = 8;
			num2 = 4;
			double d;
			double num4;
			if (num != 4)
			{
				num = num3;
				num2 = 8;
				num2 = 2;
				if (num == 2)
				{
					obj = global::_003CModule_003E.themeData_1;
					obj = ((ThemeData)obj).string_0;
					obj15 = obj17;
					if (!((string)obj == (string)obj15))
					{
						goto IL_0333;
					}
					num4 = 3.4054651081081646;
					d = 1.5;
					double num5 = Math.Log(d);
					d = num5;
					num4 -= d;
					int num6 = Convert.ToInt32(num4);
					num = num6;
					num3 = num;
				}
				num = num3;
				num2 = 1;
				if (num == 1)
				{
					obj = themeData_0;
					num2 = int_0;
					obj = ((ThemeData[])obj)[num2];
					global::_003CModule_003E.themeData_1 = (ThemeData)obj;
					num4 = 1.0;
					d = 1.0;
					num4 = 2.0;
					int num7 = Convert.ToInt32(num4);
					num = num7;
					num3 = num;
				}
				num = num3;
				num2 = 15;
				num2 = 3;
				if (num == 3)
				{
					num = 1;
					BundleManager.smethod_52(bool_8: true);
					num4 = 3.6989700043360187;
					d = 2.0;
					double num8 = Math.Log10(d);
					d = num8;
					num4 += d;
					int num9 = Convert.ToInt32(num4);
					num = num9;
					num3 = num;
				}
				num = num3;
				num2 = 18;
				num2 = 6;
				if (num == 6)
				{
					obj = global::_003CModule_003E.themeData_1;
					obj = ((ThemeData)obj).color_0;
					BundleManager.smethod_53((Color)obj);
					num4 = 6.455931955649724;
					d = 3.5;
					double num10 = Math.Log10(d);
					d = num10;
					num4 += d;
					int num11 = Convert.ToInt32(num4);
					num = num11;
					num3 = num;
				}
				num = num3;
				num2 = 0;
				if (num == 0)
				{
					num = 1;
					num3 = 1;
				}
				num = num3;
				num2 = 104;
				num2 = 8;
				if (num == 8)
				{
					break;
				}
				continue;
			}
			goto IL_0390;
			IL_0390:
			obj = obj18;
			obj15 = global::_003CModule_003E.themeData_1;
			obj15 = ((ThemeData)obj15).string_0;
			string text3 = (string)obj + (string)obj15;
			obj = text3;
			BundleManager.smethod_55((string)obj);
			num4 = 12.0;
			d = 4.0;
			double num12 = Math.Ceiling(d);
			d = num12;
			num4 -= d;
			int num13 = Convert.ToInt32(num4);
			num = num13;
			num3 = num;
			goto IL_040d;
			IL_0333:
			num = 0;
			BundleManager.smethod_52(bool_8: false);
			num4 = 5.010007503399555;
			d = 3.0;
			double num14 = Math.Cos(d);
			d = num14;
			num4 -= d;
			int num15 = Convert.ToInt32(num4);
			num = num15;
			num3 = num;
			goto IL_0376;
		}
	}

	public Class139()
	{
		Class296.Aw4EYyy3h();
		Class300.smethod_0();
	}

	unsafe static Class139()
	{
		//The blocks IL_000e, IL_001e, IL_03a3, IL_03b6, IL_03d6, IL_03e6, IL_03f6, IL_0406, IL_0416, IL_0426, IL_0433, IL_0443, IL_0453, IL_0463, IL_0473, IL_0483, IL_0493, IL_049e, IL_04b1, IL_04c6, IL_04d9, IL_04e7, IL_04f5, IL_0500, IL_050e, IL_0517, IL_052c, IL_053f, IL_054d, IL_055b, IL_0570, IL_0583, IL_058e, IL_059c, IL_05af, IL_05b8, IL_05c3, IL_05dc, IL_05ea, IL_05f8, IL_060b, IL_0619, IL_0627, IL_0630, IL_0657, IL_066e, IL_0681, IL_06c1, IL_06da, IL_06f7, IL_0746, IL_0750, IL_077d, IL_0791, IL_079f, IL_07b2, IL_07c5, IL_07da, IL_07ed, IL_0800, IL_080b, IL_0819, IL_082e, IL_0841, IL_084f, IL_085d, IL_0866, IL_087b, IL_088e, IL_08b7, IL_08d0, IL_08de, IL_08e9, IL_0903, IL_0911, IL_091f, IL_0932, IL_0940, IL_094e, IL_0959, IL_0973, IL_0986, IL_0994, IL_09a2, IL_09bf, IL_09f7, IL_0a0a, IL_0a18, IL_0a26, IL_0a4f, IL_0a71, IL_0a7a, IL_0a85, IL_0a8e, IL_0acc, IL_0adf, IL_0aed, IL_0afb, IL_0b13, IL_0b31, IL_0b55, IL_0b76, IL_0b89, IL_0b97, IL_0ba0, IL_0bae, IL_0bbc, IL_0bdd, IL_0beb, IL_0bfe, IL_0c0c, IL_0c1a, IL_0c25, IL_0c3e, IL_0c51, IL_0c5f, IL_0c6d, IL_0c7b, IL_0c9e, IL_0cac, IL_0cbf, IL_0ccd, IL_0cdb, IL_0cf7, IL_0d00, IL_0d0b, IL_0d4d, IL_0d60, IL_0d6e, IL_0d7c, IL_0d90, IL_0e08, IL_0e16, IL_0e32, IL_0e40, IL_0e4e, IL_0e62, IL_0eb7, IL_0ec5, IL_0ed5, IL_0eea, IL_0ef8, IL_0f0b, IL_0f15, IL_0f29, IL_0f39, IL_0f49, IL_0f59, IL_0f72, IL_0f82, IL_0f92, IL_0fb0, IL_0fb7 are reachable both inside and outside the pinned region starting at IL_0fa7. ILSpy has duplicated these blocks in order to place them both within and outside the `fixed` statement.
		int num = 30;
		int num4 = default(int);
		int num6 = default(int);
		while (true)
		{
			Class296.Aw4EYyy3h();
			while (true)
			{
				Class300.smethod_0();
				while (true)
				{
					int num2;
					int num3;
					byte[] array2;
					object[] array3;
					int[] array4;
					long[] array5;
					object[] array6;
					byte* ptr;
					object[] array7;
					int num5;
					byte* num7;
					byte* num9;
					int num10;
					byte* ptr2;
					byte[] array = new byte[4];
					if (true)
					{
						while (true)
						{
							IL_0f92:
							num2 = 1;
							while (true)
							{
								IL_0f82:
								num3 = num2 * 4;
								while (true)
								{
									IL_0f72:
									array2 = new byte[8];
									while (true)
									{
										IL_0f59:
										array3 = new object[8];
										num = 117;
										while (true)
										{
											IL_0f49:
											array4 = new int[8];
											while (true)
											{
												IL_0f39:
												array5 = new long[8];
												while (true)
												{
													IL_0f29:
													array6 = new object[37];
													while (true)
													{
														IL_0f15:
														ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetIUnknownForObjectgetControlEvidence.ActivatedClientTypeEntryNewGuid);
														num = 134;
														while (true)
														{
															IL_0f0b:
															ptr2 = ptr;
															while (true)
															{
																IL_0ef8:
																if (num4 == 1)
																{
																	return;
																}
																while (true)
																{
																	IL_0493:
																	byte b = *ptr2;
																	while (true)
																	{
																		IL_0483:
																		ptr2++;
																		while (true)
																		{
																			IL_0473:
																			if (b >= 1)
																			{
																				while (b <= 26)
																				{
																					while (true)
																					{
																						IL_0453:
																						if (13 >= b)
																						{
																							while (true)
																							{
																								IL_0443:
																								if (13 > b)
																								{
																									while (true)
																									{
																										IL_0433:
																										if (6 >= b)
																										{
																											while (true)
																											{
																												IL_0426:
																												if (6 > b)
																												{
																													while (true)
																													{
																														IL_0416:
																														if (3 >= b)
																														{
																															while (true)
																															{
																																IL_0406:
																																if (3 > b)
																																{
																																	while (true)
																																	{
																																		IL_03f6:
																																		if (1 < b)
																																		{
																																			while (2 >= b)
																																			{
																																				while (2 <= b)
																																				{
																																					while (true)
																																					{
																																						IL_03b6:
																																						((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																																						num = 229;
																																						while (true)
																																						{
																																							if (num != 229)
																																							{
																																								if (num != 1210)
																																								{
																																									break;
																																								}
																																								switch (num)
																																								{
																																								case 32:
																																									break;
																																								default:
																																									continue;
																																								case 82:
																																								case 183:
																																									goto IL_03b6;
																																								case 41:
																																									goto IL_03d6;
																																								case 207:
																																									goto IL_03e6;
																																								case 10:
																																									goto IL_03f6;
																																								case 106:
																																									goto IL_0406;
																																								case 105:
																																									goto IL_0416;
																																								case 163:
																																									goto IL_0426;
																																								case 146:
																																									goto IL_0433;
																																								case 129:
																																									goto IL_0443;
																																								case 49:
																																									goto IL_0453;
																																								case 137:
																																									goto IL_0463;
																																								case 59:
																																									goto IL_0473;
																																								case 140:
																																									goto IL_0483;
																																								case 185:
																																								case 189:
																																									goto IL_0493;
																																								case 4:
																																									goto IL_049e;
																																								case 71:
																																								case 128:
																																									goto IL_04b1;
																																								case 65:
																																									goto IL_04c6;
																																								case 168:
																																									goto IL_04d9;
																																								case 135:
																																									goto IL_04e7;
																																								case 0:
																																									goto IL_04f5;
																																								case 152:
																																									goto IL_0500;
																																								case 94:
																																								case 125:
																																									goto IL_0517;
																																								case 69:
																																									goto IL_052c;
																																								case 54:
																																									goto IL_053f;
																																								case 147:
																																									goto IL_054d;
																																								case 126:
																																								case 132:
																																									goto IL_055b;
																																								case 124:
																																									goto IL_0570;
																																								case 120:
																																									goto IL_0583;
																																								case 165:
																																									goto IL_058e;
																																								case 100:
																																									goto IL_059c;
																																								case 144:
																																									goto IL_05b8;
																																								case 136:
																																								case 160:
																																									goto IL_05c3;
																																								case 2:
																																									goto IL_05dc;
																																								case 83:
																																									goto IL_05ea;
																																								case 36:
																																									goto IL_05f8;
																																								case 130:
																																									goto IL_060b;
																																								case 101:
																																									goto IL_0619;
																																								case 38:
																																								case 50:
																																									goto end_IL_03a3;
																																								case 55:
																																									goto IL_0657;
																																								case 103:
																																									goto IL_066e;
																																								case 15:
																																								case 172:
																																									goto IL_0681;
																																								case 26:
																																									goto IL_06c1;
																																								case 97:
																																								case 176:
																																									goto IL_06da;
																																								case 167:
																																									goto IL_0791;
																																								case 112:
																																									goto IL_079f;
																																								case 208:
																																									goto IL_07b2;
																																								case 198:
																																								case 210:
																																									goto IL_07c5;
																																								case 48:
																																									goto IL_07da;
																																								case 56:
																																									goto IL_0800;
																																								case 35:
																																									goto IL_080b;
																																								case 87:
																																								case 93:
																																									goto IL_0819;
																																								case 46:
																																									goto IL_082e;
																																								case 200:
																																									goto IL_0841;
																																								case 196:
																																									goto IL_084f;
																																								case 96:
																																								case 222:
																																									goto IL_0866;
																																								case 139:
																																									goto IL_087b;
																																								case 73:
																																								case 86:
																																									goto IL_088e;
																																								case 220:
																																									goto IL_08b7;
																																								case 40:
																																									goto IL_08d0;
																																								case 58:
																																									goto IL_08de;
																																								case 181:
																																								case 190:
																																									goto IL_08e9;
																																								case 184:
																																									goto IL_0903;
																																								case 111:
																																									goto IL_0911;
																																								case 52:
																																									goto IL_091f;
																																								case 33:
																																									goto IL_0932;
																																								case 122:
																																									goto IL_0940;
																																								case 72:
																																									goto IL_094e;
																																								case 80:
																																								case 131:
																																									goto IL_0959;
																																								case 91:
																																									goto IL_0973;
																																								case 74:
																																									goto IL_0986;
																																								case 209:
																																									goto IL_0994;
																																								case 70:
																																								case 197:
																																									goto IL_09a2;
																																								case 92:
																																									goto IL_09bf;
																																								case 153:
																																									goto IL_09f7;
																																								case 162:
																																									goto IL_0a0a;
																																								case 157:
																																									goto IL_0a18;
																																								case 99:
																																								case 205:
																																									goto IL_0a26;
																																								case 219:
																																									goto IL_0a4f;
																																								case 64:
																																									goto IL_0a7a;
																																								case 154:
																																								case 182:
																																									goto IL_0a8e;
																																								case 166:
																																									goto IL_0acc;
																																								case 169:
																																									goto IL_0adf;
																																								case 19:
																																									goto IL_0aed;
																																								case 42:
																																								case 188:
																																									goto IL_0afb;
																																								case 77:
																																									goto IL_0b13;
																																								case 150:
																																									goto IL_0b31;
																																								case 37:
																																									goto IL_0b55;
																																								case 5:
																																									goto IL_0b76;
																																								case 61:
																																									goto IL_0b89;
																																								case 28:
																																									goto IL_0ba0;
																																								case 16:
																																								case 76:
																																									goto IL_0bae;
																																								case 75:
																																									goto IL_0bbc;
																																								case 218:
																																									goto IL_0bdd;
																																								case 145:
																																									goto IL_0beb;
																																								case 216:
																																									goto IL_0bfe;
																																								case 11:
																																									goto IL_0c0c;
																																								case 66:
																																									goto IL_0c1a;
																																								case 192:
																																								case 194:
																																									goto IL_0c25;
																																								case 53:
																																									goto IL_0c3e;
																																								case 51:
																																									goto IL_0c51;
																																								case 24:
																																									goto IL_0c5f;
																																								case 39:
																																								case 204:
																																									goto IL_0c6d;
																																								case 173:
																																									goto IL_0c7b;
																																								case 110:
																																									goto IL_0c9e;
																																								case 186:
																																									goto IL_0cac;
																																								case 81:
																																									goto IL_0cbf;
																																								case 25:
																																									goto IL_0ccd;
																																								case 47:
																																								case 62:
																																									goto IL_0cdb;
																																								case 31:
																																									goto IL_0d00;
																																								case 60:
																																								case 142:
																																									goto IL_0d0b;
																																								case 113:
																																									goto IL_0d4d;
																																								case 193:
																																									goto IL_0d60;
																																								case 79:
																																									goto IL_0d6e;
																																								case 114:
																																								case 116:
																																									goto IL_0d7c;
																																								case 63:
																																									goto IL_0d90;
																																								case 175:
																																									goto IL_0e08;
																																								case 161:
																																									goto IL_0e16;
																																								case 21:
																																									goto IL_0e32;
																																								case 177:
																																									goto IL_0e40;
																																								case 13:
																																								case 174:
																																									goto IL_0e4e;
																																								case 123:
																																									goto IL_0e62;
																																								case 109:
																																									goto IL_0eb7;
																																								case 141:
																																									goto IL_0ec5;
																																								case 1:
																																								case 3:
																																								case 6:
																																								case 8:
																																								case 9:
																																								case 14:
																																								case 18:
																																								case 20:
																																								case 23:
																																								case 44:
																																								case 57:
																																								case 67:
																																								case 78:
																																								case 84:
																																								case 88:
																																								case 89:
																																								case 95:
																																								case 115:
																																								case 119:
																																								case 127:
																																								case 170:
																																								case 171:
																																								case 178:
																																								case 180:
																																								case 187:
																																								case 202:
																																								case 203:
																																								case 215:
																																								case 217:
																																									goto end_IL_03d6;
																																								case 221:
																																									goto IL_0eea;
																																								case 7:
																																								case 12:
																																								case 17:
																																								case 22:
																																								case 27:
																																								case 34:
																																								case 45:
																																								case 85:
																																								case 104:
																																								case 108:
																																								case 121:
																																								case 133:
																																								case 143:
																																								case 148:
																																								case 149:
																																								case 155:
																																								case 156:
																																								case 159:
																																								case 164:
																																								case 179:
																																								case 191:
																																								case 195:
																																								case 199:
																																								case 201:
																																								case 206:
																																								case 211:
																																								case 213:
																																								case 214:
																																									goto IL_0ef8;
																																								case 134:
																																									goto IL_0f0b;
																																								case 158:
																																									goto IL_0f15;
																																								case 118:
																																									goto IL_0f29;
																																								case 68:
																																									goto IL_0f39;
																																								case 117:
																																									goto IL_0f49;
																																								case 212:
																																									goto IL_0f59;
																																								case 98:
																																								case 151:
																																									goto IL_0f72;
																																								case 102:
																																									goto IL_0f82;
																																								case 107:
																																									goto IL_0f92;
																																								case 90:
																																									break;
																																								case 29:
																																									Class300.smethod_0();
																																									break;
																																								case 30:
																																									Class296.Aw4EYyy3h();
																																									goto case 29;
																																								case 43:
																																								case 138:
																																									return;
																																								}
																																								goto end_IL_0473;
																																							}
																																							ptr2 += 8;
																																							goto IL_0ef8;
																																							continue;
																																							end_IL_03a3:
																																							break;
																																						}
																																						break;
																																					}
																																					goto IL_0630;
																																					continue;
																																					end_IL_03d6:
																																					break;
																																					IL_03d6:;
																																				}
																																				break;
																																				IL_03e6:;
																																			}
																																			break;
																																		}
																																		goto IL_049e;
																																		IL_049e:
																																		if (1 > b)
																																		{
																																		}
																																		break;
																																	}
																																	break;
																																}
																																goto IL_07c5;
																																IL_07da:
																																ptr2 += 8;
																																goto IL_0ef8;
																																IL_07c5:
																																((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																																goto IL_07da;
																															}
																															break;
																														}
																														goto IL_0800;
																														IL_0866:
																														((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																														goto IL_087b;
																														IL_0800:
																														if (4 >= b)
																														{
																															goto IL_080b;
																														}
																														goto IL_0841;
																														IL_080b:
																														if (4 > b)
																														{
																															break;
																														}
																														goto IL_0819;
																														IL_0819:
																														((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																														goto IL_082e;
																														IL_082e:
																														ptr2 += 8;
																														goto IL_0ef8;
																														IL_0841:
																														if (5 < b)
																														{
																															break;
																														}
																														goto IL_084f;
																														IL_084f:
																														if (5 > b)
																														{
																															break;
																														}
																														num = 222;
																														goto IL_0866;
																														IL_087b:
																														ptr2 += 8;
																														goto IL_0ef8;
																													}
																													break;
																												}
																												goto IL_04b1;
																												IL_04c6:
																												ptr2 += 8;
																												goto IL_0ef8;
																												IL_04b1:
																												((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																												goto IL_04c6;
																											}
																											break;
																										}
																										goto IL_04d9;
																										IL_05f8:
																										ptr2 += 8;
																										goto IL_0ef8;
																										IL_04d9:
																										if (9 >= b)
																										{
																											goto IL_04e7;
																										}
																										goto IL_0583;
																										IL_04e7:
																										if (9 > b)
																										{
																											goto IL_04f5;
																										}
																										goto IL_06da;
																										IL_04f5:
																										if (7 >= b)
																										{
																											goto IL_0500;
																										}
																										goto IL_053f;
																										IL_0500:
																										if (7 > b)
																										{
																											break;
																										}
																										num = 94;
																										goto IL_0517;
																										IL_060b:
																										if (10 < b)
																										{
																											break;
																										}
																										goto IL_0619;
																										IL_0517:
																										((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																										goto IL_052c;
																										IL_052c:
																										ptr2 += 8;
																										goto IL_0ef8;
																										IL_053f:
																										if (8 < b)
																										{
																											break;
																										}
																										goto IL_054d;
																										IL_054d:
																										if (8 > b)
																										{
																											break;
																										}
																										goto IL_055b;
																										IL_055b:
																										((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																										goto IL_0570;
																										IL_0570:
																										ptr2 += 8;
																										goto IL_0ef8;
																										IL_06da:
																										array7 = array3;
																										num5 = num6;
																										if (array == null)
																										{
																											goto IL_06e9;
																										}
																										num7 = ptr2;
																										byte b2 = *num7;
																										ptr2 = num7 + 4;
																										int num8 = *(int*)(ptr2 + num3);
																										ptr2 += 8;
																										byte* ptr3 = ptr2 + num8;
																										byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
																										while (ptr2 != ptr3)
																										{
																											*ptr4 = (byte)(*ptr2 ^ b2);
																											ptr2++;
																											ptr4++;
																										}
																										array7[num5] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
																										goto IL_0791;
																										IL_0619:
																										if (10 > b)
																										{
																											break;
																										}
																										num = 50;
																										goto IL_0630;
																										IL_066e:
																										num6--;
																										goto IL_0ef8;
																										IL_0630:
																										array6[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																										num = 55;
																										goto IL_0657;
																										IL_0791:
																										array2[num6] = 5;
																										goto IL_079f;
																										IL_079f:
																										num6++;
																										goto IL_0ef8;
																										IL_0583:
																										if (11 < b)
																										{
																											goto IL_058e;
																										}
																										num = 144;
																										goto IL_05b8;
																										IL_058e:
																										if (12 < b)
																										{
																											break;
																										}
																										goto IL_059c;
																										IL_059c:
																										if (12 > b)
																										{
																											break;
																										}
																										goto IL_0681;
																										IL_0681:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																										goto IL_06c1;
																										IL_06c1:
																										array2[num6 - 2] = 0;
																										goto IL_07b2;
																										IL_07b2:
																										num6--;
																										goto IL_0ef8;
																										IL_0657:
																										ptr2 += 8;
																										num = 103;
																										goto IL_066e;
																										IL_05b8:
																										if (11 <= b)
																										{
																											goto IL_05c3;
																										}
																										goto IL_060b;
																										IL_05c3:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																										goto IL_05dc;
																										IL_05dc:
																										array2[num6] = 0;
																										goto IL_05ea;
																										IL_05ea:
																										num6++;
																										goto IL_05f8;
																									}
																									break;
																								}
																								goto IL_088e;
																								IL_08b7:
																								array2[num6 - 1] = 5;
																								goto IL_0ef8;
																								IL_088e:
																								array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])];
																								goto IL_08b7;
																							}
																							break;
																						}
																						goto IL_08d0;
																						IL_0e40:
																						if (22 > b)
																						{
																							break;
																						}
																						goto IL_0e4e;
																						IL_08d0:
																						if (20 >= b)
																						{
																							goto IL_08de;
																						}
																						goto IL_0bfe;
																						IL_08de:
																						if (20 <= b)
																						{
																							goto IL_08e9;
																						}
																						goto IL_0932;
																						IL_08e9:
																						*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																						goto IL_0903;
																						IL_0903:
																						array2[num6] = 3;
																						goto IL_0911;
																						IL_0911:
																						num6++;
																						goto IL_091f;
																						IL_091f:
																						ptr2 += 8;
																						goto IL_0ef8;
																						IL_0932:
																						if (16 < b)
																						{
																							goto IL_0940;
																						}
																						num = 64;
																						goto IL_0a7a;
																						IL_0940:
																						if (18 >= b)
																						{
																							goto IL_094e;
																						}
																						goto IL_0a0a;
																						IL_094e:
																						if (18 <= b)
																						{
																							goto IL_0959;
																						}
																						goto IL_0986;
																						IL_0959:
																						int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_0973;
																						IL_0973:
																						num6--;
																						goto IL_0ef8;
																						IL_0986:
																						if (17 < b)
																						{
																							break;
																						}
																						goto IL_0994;
																						IL_0994:
																						if (17 > b)
																						{
																							break;
																						}
																						goto IL_09a2;
																						IL_09a2:
																						array2[num6 - 1] = 5;
																						num = 92;
																						goto IL_09bf;
																						IL_09bf:
																						array3[num6 - 1] = ((delegate*<string[], string>)WhenAnyEventToken[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																						goto IL_09f7;
																						IL_09f7:
																						ptr2 += 8;
																						goto IL_0ef8;
																						IL_0a0a:
																						if (19 < b)
																						{
																							break;
																						}
																						goto IL_0a18;
																						IL_0a18:
																						if (19 > b)
																						{
																							break;
																						}
																						goto IL_0a26;
																						IL_0a26:
																						array3[num6 - 1] = new ThemeData[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])];
																						goto IL_0a4f;
																						IL_0a4f:
																						array2[num6 - 1] = 5;
																						num = 164;
																						goto IL_0ef8;
																						IL_0e4e:
																						array2[num6 - 2] = 5;
																						goto IL_0e62;
																						IL_0a7a:
																						if (16 <= b)
																						{
																							num = 182;
																							goto IL_0a8e;
																						}
																						goto IL_0adf;
																						IL_0e62:
																						array3[num6 - 2] = ((delegate*<string, Color, object>)WhenAnyEventToken[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (Color)array3[num6 - 1]);
																						num = 109;
																						goto IL_0eb7;
																						IL_0a8e:
																						((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])] = (string)array3[num6 - 1];
																						goto IL_0acc;
																						IL_0acc:
																						num6 -= 3;
																						goto IL_0ef8;
																						IL_0adf:
																						if (14 >= b)
																						{
																							goto IL_0aed;
																						}
																						goto IL_0b89;
																						IL_0aed:
																						if (14 > b)
																						{
																							break;
																						}
																						goto IL_0afb;
																						IL_0afb:
																						array2[num6] = array2[num6 - 1];
																						goto IL_0b13;
																						IL_0b13:
																						array4[num6 - 0] = array4[num6 - 1];
																						goto IL_0b31;
																						IL_0b31:
																						*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																						goto IL_0b55;
																						IL_0b55:
																						array3[num6] = array3[num6 - 1];
																						num = 5;
																						goto IL_0b76;
																						IL_0b76:
																						num6++;
																						goto IL_0ef8;
																						IL_0b89:
																						if (15 < b)
																						{
																							break;
																						}
																						num = 28;
																						goto IL_0ba0;
																						IL_0eb7:
																						num6--;
																						goto IL_0ec5;
																						IL_0ba0:
																						if (15 > b)
																						{
																							break;
																						}
																						goto IL_0bae;
																						IL_0bae:
																						array2[num6] = 5;
																						goto IL_0bbc;
																						IL_0bbc:
																						array3[num6] = array6[*(int*)(ptr2 + num3)];
																						num = 218;
																						goto IL_0bdd;
																						IL_0bdd:
																						num6++;
																						goto IL_0beb;
																						IL_0beb:
																						ptr2 += 8;
																						goto IL_0ef8;
																						IL_0bfe:
																						if (23 < b)
																						{
																							goto IL_0c0c;
																						}
																						num = 31;
																						goto IL_0d00;
																						IL_0c0c:
																						if (25 >= b)
																						{
																							goto IL_0c1a;
																						}
																						goto IL_0cbf;
																						IL_0c1a:
																						if (25 <= b)
																						{
																							goto IL_0c25;
																						}
																						goto IL_0c51;
																						IL_0c25:
																						themeData_0 = (ThemeData[])array3[num6 - 1];
																						goto IL_0c3e;
																						IL_0c3e:
																						num6--;
																						goto IL_0ef8;
																						IL_0c51:
																						if (24 < b)
																						{
																							break;
																						}
																						goto IL_0c5f;
																						IL_0c5f:
																						if (24 > b)
																						{
																							break;
																						}
																						goto IL_0c6d;
																						IL_0c6d:
																						array2[num6] = 4;
																						goto IL_0c7b;
																						IL_0c7b:
																						array3[num6] = ((delegate*<Color>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																						goto IL_0c9e;
																						IL_0c9e:
																						num6++;
																						goto IL_0cac;
																						IL_0cac:
																						ptr2 += 8;
																						goto IL_0ef8;
																						IL_0cbf:
																						if (26 < b)
																						{
																							break;
																						}
																						goto IL_0ccd;
																						IL_0ccd:
																						if (26 > b)
																						{
																							break;
																						}
																						goto IL_0cdb;
																						IL_0cdb:
																						num9 = ptr2;
																						num10 = -200;
																						num4 = 1;
																						ptr2 = num9 + num10;
																						goto IL_0ef8;
																						IL_0ec5:
																						ptr2 += 8;
																						goto IL_0ef8;
																						IL_0d00:
																						if (23 <= b)
																						{
																							goto IL_0d0b;
																						}
																						goto IL_0d60;
																						IL_0d0b:
																						((ThemeData[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])] = (ThemeData)array3[num6 - 1];
																						goto IL_0d4d;
																						IL_0d4d:
																						num6 -= 3;
																						goto IL_0ef8;
																						IL_0d60:
																						if (21 >= b)
																						{
																							goto IL_0d6e;
																						}
																						goto IL_0e32;
																						IL_0d6e:
																						if (21 > b)
																						{
																							break;
																						}
																						goto IL_0d7c;
																						IL_0d7c:
																						array2[num6 - 4] = 5;
																						goto IL_0d90;
																						IL_0d90:
																						array3[num6 - 4] = ((delegate*<float, float, float, float, object>)WhenAnyEventToken[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																						goto IL_0e08;
																						IL_0e08:
																						num6 -= 3;
																						goto IL_0e16;
																						IL_0e16:
																						ptr2 += 8;
																						num = 155;
																						goto IL_0ef8;
																						IL_0e32:
																						if (22 < b)
																						{
																							break;
																						}
																						goto IL_0e40;
																					}
																					break;
																					IL_0463:;
																				}
																			}
																			((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																			goto IL_0eea;
																			IL_0eea:
																			ptr2 += 8;
																			goto IL_0ef8;
																			continue;
																			end_IL_0473:
																			break;
																		}
																		break;
																	}
																	break;
																}
																break;
															}
															break;
														}
														break;
													}
													break;
												}
												break;
											}
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							break;
						}
					}
					continue;
					IL_06e9:
					while (true)
					{
						IL_06e9_2:
						array = new byte[4];
						while (true)
						{
							num7 = ptr2;
							byte b2 = *num7;
							ptr2 = num7 + 4;
							int num8 = *(int*)(ptr2 + num3);
							ptr2 += 8;
							byte* ptr3 = ptr2 + num8;
							byte* ptr4 = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]);
							while (ptr2 != ptr3)
							{
								*ptr4 = (byte)(*ptr2 ^ b2);
								ptr2++;
								ptr4++;
							}
							array7[num5] = new string((char*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array[0]));
							while (true)
							{
								IL_0791_2:
								array2[num6] = 5;
								while (true)
								{
									IL_079f_2:
									num6++;
									while (true)
									{
										IL_0ef8_2:
										if (num4 == 1)
										{
											return;
										}
										while (true)
										{
											byte b = *ptr2;
											while (true)
											{
												ptr2++;
												while (true)
												{
													IL_0473_2:
													if (b >= 1)
													{
														while (b <= 26)
														{
															while (true)
															{
																IL_0453_2:
																if (13 >= b)
																{
																	while (true)
																	{
																		IL_0443_2:
																		if (13 > b)
																		{
																			while (true)
																			{
																				IL_0433_2:
																				if (6 >= b)
																				{
																					while (true)
																					{
																						IL_0426_2:
																						if (6 > b)
																						{
																							while (true)
																							{
																								IL_0416_2:
																								if (3 >= b)
																								{
																									while (true)
																									{
																										IL_0406_2:
																										if (3 > b)
																										{
																											while (true)
																											{
																												IL_03f6_2:
																												if (1 < b)
																												{
																													while (2 >= b)
																													{
																														while (2 <= b)
																														{
																															while (true)
																															{
																																IL_03b6_2:
																																((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																																num = 229;
																																while (true)
																																{
																																	if (num != 229)
																																	{
																																		if (num != 1210)
																																		{
																																			break;
																																		}
																																		switch (num)
																																		{
																																		case 82:
																																		case 183:
																																			goto IL_03b6_2;
																																		case 41:
																																			goto IL_03d6_2;
																																		case 207:
																																			goto IL_03e6_2;
																																		case 10:
																																			goto IL_03f6_2;
																																		case 106:
																																			goto IL_0406_2;
																																		case 105:
																																			goto IL_0416_2;
																																		case 163:
																																			goto IL_0426_2;
																																		case 146:
																																			goto IL_0433_2;
																																		case 129:
																																			goto IL_0443_2;
																																		case 49:
																																			goto IL_0453_2;
																																		case 137:
																																			goto IL_0463_2;
																																		case 59:
																																			goto IL_0473_2;
																																		case 140:
																																			goto end_IL_0473_2;
																																		case 185:
																																		case 189:
																																			goto end_IL_0483;
																																		case 4:
																																			goto IL_049e_2;
																																		case 71:
																																		case 128:
																																			goto IL_04b1_2;
																																		case 65:
																																			goto IL_04c6_2;
																																		case 168:
																																			goto IL_04d9_2;
																																		case 135:
																																			goto IL_04e7_2;
																																		case 0:
																																			goto IL_04f5_2;
																																		case 152:
																																			goto IL_0500_2;
																																		case 94:
																																		case 125:
																																			goto IL_0517_2;
																																		case 69:
																																			goto IL_052c_2;
																																		case 54:
																																			goto IL_053f_2;
																																		case 147:
																																			goto IL_054d_2;
																																		case 126:
																																		case 132:
																																			goto IL_055b_2;
																																		case 124:
																																			goto IL_0570_2;
																																		case 120:
																																			goto IL_0583_2;
																																		case 165:
																																			goto IL_058e_2;
																																		case 100:
																																			goto IL_059c_2;
																																		case 144:
																																			goto IL_05b8_2;
																																		case 136:
																																		case 160:
																																			goto IL_05c3_2;
																																		case 2:
																																			goto IL_05dc_2;
																																		case 83:
																																			goto IL_05ea_2;
																																		case 36:
																																			goto IL_05f8_2;
																																		case 130:
																																			goto IL_060b_2;
																																		case 101:
																																			goto IL_0619_2;
																																		case 38:
																																		case 50:
																																			goto end_IL_03a3_2;
																																		case 55:
																																			goto IL_0657_2;
																																		case 103:
																																			goto IL_066e_2;
																																		case 15:
																																		case 172:
																																			goto IL_0681_2;
																																		case 26:
																																			goto IL_06c1_2;
																																		case 97:
																																		case 176:
																																			goto end_IL_0493;
																																		case 167:
																																			goto IL_0791_2;
																																		case 112:
																																			goto IL_079f_2;
																																		case 208:
																																			goto IL_07b2_2;
																																		case 198:
																																		case 210:
																																			goto IL_07c5_2;
																																		case 48:
																																			goto IL_07da_2;
																																		case 56:
																																			goto IL_0800_2;
																																		case 35:
																																			goto IL_080b_2;
																																		case 87:
																																		case 93:
																																			goto IL_0819_2;
																																		case 46:
																																			goto IL_082e_2;
																																		case 200:
																																			goto IL_0841_2;
																																		case 196:
																																			goto IL_084f_2;
																																		case 96:
																																		case 222:
																																			goto IL_0866_2;
																																		case 139:
																																			goto IL_087b_2;
																																		case 73:
																																		case 86:
																																			goto IL_088e_2;
																																		case 220:
																																			goto IL_08b7_2;
																																		case 40:
																																			goto IL_08d0_2;
																																		case 58:
																																			goto IL_08de_2;
																																		case 181:
																																		case 190:
																																			goto IL_08e9_2;
																																		case 184:
																																			goto IL_0903_2;
																																		case 111:
																																			goto IL_0911_2;
																																		case 52:
																																			goto IL_091f_2;
																																		case 33:
																																			goto IL_0932_2;
																																		case 122:
																																			goto IL_0940_2;
																																		case 72:
																																			goto IL_094e_2;
																																		case 80:
																																		case 131:
																																			goto IL_0959_2;
																																		case 91:
																																			goto IL_0973_2;
																																		case 74:
																																			goto IL_0986_2;
																																		case 209:
																																			goto IL_0994_2;
																																		case 70:
																																		case 197:
																																			goto IL_09a2_2;
																																		case 92:
																																			goto IL_09bf_2;
																																		case 153:
																																			goto IL_09f7_2;
																																		case 162:
																																			goto IL_0a0a_2;
																																		case 157:
																																			goto IL_0a18_2;
																																		case 99:
																																		case 205:
																																			goto IL_0a26_2;
																																		case 219:
																																			goto IL_0a4f_2;
																																		case 64:
																																			goto IL_0a7a_2;
																																		case 154:
																																		case 182:
																																			goto IL_0a8e_2;
																																		case 166:
																																			goto IL_0acc_2;
																																		case 169:
																																			goto IL_0adf_2;
																																		case 19:
																																			goto IL_0aed_2;
																																		case 42:
																																		case 188:
																																			goto IL_0afb_2;
																																		case 77:
																																			goto IL_0b13_2;
																																		case 150:
																																			goto IL_0b31_2;
																																		case 37:
																																			goto IL_0b55_2;
																																		case 5:
																																			goto IL_0b76_2;
																																		case 61:
																																			goto IL_0b89_2;
																																		case 28:
																																			goto IL_0ba0_2;
																																		case 16:
																																		case 76:
																																			goto IL_0bae_2;
																																		case 75:
																																			goto IL_0bbc_2;
																																		case 218:
																																			goto IL_0bdd_2;
																																		case 145:
																																			goto IL_0beb_2;
																																		case 216:
																																			goto IL_0bfe_2;
																																		case 11:
																																			goto IL_0c0c_2;
																																		case 66:
																																			goto IL_0c1a_2;
																																		case 192:
																																		case 194:
																																			goto IL_0c25_2;
																																		case 53:
																																			goto IL_0c3e_2;
																																		case 51:
																																			goto IL_0c51_2;
																																		case 24:
																																			goto IL_0c5f_2;
																																		case 39:
																																		case 204:
																																			goto IL_0c6d_2;
																																		case 173:
																																			goto IL_0c7b_2;
																																		case 110:
																																			goto IL_0c9e_2;
																																		case 186:
																																			goto IL_0cac_2;
																																		case 81:
																																			goto IL_0cbf_2;
																																		case 25:
																																			goto IL_0ccd_2;
																																		case 47:
																																		case 62:
																																			goto IL_0cdb_2;
																																		case 31:
																																			goto IL_0d00_2;
																																		case 60:
																																		case 142:
																																			goto IL_0d0b_2;
																																		case 113:
																																			goto IL_0d4d_2;
																																		case 193:
																																			goto IL_0d60_2;
																																		case 79:
																																			goto IL_0d6e_2;
																																		case 114:
																																		case 116:
																																			goto IL_0d7c_2;
																																		case 63:
																																			goto IL_0d90_2;
																																		case 175:
																																			goto IL_0e08_2;
																																		case 161:
																																			goto IL_0e16_2;
																																		case 21:
																																			goto IL_0e32_2;
																																		case 177:
																																			goto IL_0e40_2;
																																		case 13:
																																		case 174:
																																			goto IL_0e4e_2;
																																		case 123:
																																			goto IL_0e62_2;
																																		case 109:
																																			goto IL_0eb7_2;
																																		case 141:
																																			goto IL_0ec5_2;
																																		case 1:
																																		case 3:
																																		case 6:
																																		case 8:
																																		case 9:
																																		case 14:
																																		case 18:
																																		case 20:
																																		case 23:
																																		case 44:
																																		case 57:
																																		case 67:
																																		case 78:
																																		case 84:
																																		case 88:
																																		case 89:
																																		case 95:
																																		case 115:
																																		case 119:
																																		case 127:
																																		case 170:
																																		case 171:
																																		case 178:
																																		case 180:
																																		case 187:
																																		case 202:
																																		case 203:
																																		case 215:
																																		case 217:
																																			goto end_IL_03d6_2;
																																		case 221:
																																			goto IL_0eea_2;
																																		case 7:
																																		case 12:
																																		case 17:
																																		case 22:
																																		case 27:
																																		case 34:
																																		case 45:
																																		case 85:
																																		case 104:
																																		case 108:
																																		case 121:
																																		case 133:
																																		case 143:
																																		case 148:
																																		case 149:
																																		case 155:
																																		case 156:
																																		case 159:
																																		case 164:
																																		case 179:
																																		case 191:
																																		case 195:
																																		case 199:
																																		case 201:
																																		case 206:
																																		case 211:
																																		case 213:
																																		case 214:
																																			goto IL_0ef8_2;
																																		case 134:
																																			ptr2 = ptr;
																																			goto IL_0ef8_2;
																																		case 158:
																																			ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref GetIUnknownForObjectgetControlEvidence.ActivatedClientTypeEntryNewGuid);
																																			num = 134;
																																			goto case 134;
																																		case 118:
																																			array6 = new object[37];
																																			goto case 158;
																																		case 68:
																																			array5 = new long[8];
																																			goto case 118;
																																		case 117:
																																			array4 = new int[8];
																																			goto case 68;
																																		case 212:
																																			array3 = new object[8];
																																			num = 117;
																																			goto case 117;
																																		case 98:
																																		case 151:
																																			array2 = new byte[8];
																																			goto case 212;
																																		case 102:
																																			num3 = num2 * 4;
																																			goto case 98;
																																		case 107:
																																			num2 = 1;
																																			goto case 102;
																																		case 32:
																																		case 90:
																																			goto end_IL_06f7;
																																		case 29:
																																			goto end_IL_0f9d;
																																		case 30:
																																			goto end_IL_0fb0;
																																		case 43:
																																		case 138:
																																			return;
																																		}
																																		continue;
																																	}
																																	ptr2 += 8;
																																	goto IL_0ef8_2;
																																	continue;
																																	end_IL_03a3_2:
																																	break;
																																}
																																break;
																															}
																															goto IL_0630_2;
																															continue;
																															end_IL_03d6_2:
																															break;
																															IL_03d6_2:;
																														}
																														break;
																														IL_03e6_2:;
																													}
																													break;
																												}
																												goto IL_049e_2;
																												IL_049e_2:
																												if (1 > b)
																												{
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_07c5_2;
																										IL_07da_2:
																										ptr2 += 8;
																										goto IL_0ef8_2;
																										IL_07c5_2:
																										((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																										goto IL_07da_2;
																									}
																									break;
																								}
																								goto IL_0800_2;
																								IL_0866_2:
																								((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																								goto IL_087b_2;
																								IL_0800_2:
																								if (4 >= b)
																								{
																									goto IL_080b_2;
																								}
																								goto IL_0841_2;
																								IL_080b_2:
																								if (4 > b)
																								{
																									break;
																								}
																								goto IL_0819_2;
																								IL_0819_2:
																								((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																								goto IL_082e_2;
																								IL_082e_2:
																								ptr2 += 8;
																								goto IL_0ef8_2;
																								IL_0841_2:
																								if (5 < b)
																								{
																									break;
																								}
																								goto IL_084f_2;
																								IL_084f_2:
																								if (5 > b)
																								{
																									break;
																								}
																								num = 222;
																								goto IL_0866_2;
																								IL_087b_2:
																								ptr2 += 8;
																								goto IL_0ef8_2;
																							}
																							break;
																						}
																						goto IL_04b1_2;
																						IL_04c6_2:
																						ptr2 += 8;
																						goto IL_0ef8_2;
																						IL_04b1_2:
																						((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																						goto IL_04c6_2;
																					}
																					break;
																				}
																				goto IL_04d9_2;
																				IL_066e_2:
																				num6--;
																				goto IL_0ef8_2;
																				IL_04d9_2:
																				if (9 >= b)
																				{
																					goto IL_04e7_2;
																				}
																				goto IL_0583_2;
																				IL_04e7_2:
																				if (9 <= b)
																				{
																					goto end_IL_0493;
																				}
																				goto IL_04f5_2;
																				IL_04f5_2:
																				if (7 >= b)
																				{
																					goto IL_0500_2;
																				}
																				goto IL_053f_2;
																				IL_0500_2:
																				if (7 > b)
																				{
																					break;
																				}
																				num = 94;
																				goto IL_0517_2;
																				IL_0630_2:
																				array6[*(int*)(ptr2 + num3)] = array3[num6 - 1];
																				num = 55;
																				goto IL_0657_2;
																				IL_0517_2:
																				((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																				goto IL_052c_2;
																				IL_052c_2:
																				ptr2 += 8;
																				goto IL_0ef8_2;
																				IL_053f_2:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_054d_2;
																				IL_054d_2:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_055b_2;
																				IL_055b_2:
																				((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																				goto IL_0570_2;
																				IL_0570_2:
																				ptr2 += 8;
																				goto IL_0ef8_2;
																				IL_0583_2:
																				if (11 < b)
																				{
																					goto IL_058e_2;
																				}
																				num = 144;
																				goto IL_05b8_2;
																				IL_058e_2:
																				if (12 < b)
																				{
																					break;
																				}
																				goto IL_059c_2;
																				IL_059c_2:
																				if (12 > b)
																				{
																					break;
																				}
																				goto IL_0681_2;
																				IL_0681_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																				goto IL_06c1_2;
																				IL_06c1_2:
																				array2[num6 - 2] = 0;
																				goto IL_07b2_2;
																				IL_07b2_2:
																				num6--;
																				goto IL_0ef8_2;
																				IL_0657_2:
																				ptr2 += 8;
																				num = 103;
																				goto IL_066e_2;
																				IL_05b8_2:
																				if (11 <= b)
																				{
																					goto IL_05c3_2;
																				}
																				goto IL_060b_2;
																				IL_05c3_2:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(int*)(ptr2 + num3);
																				goto IL_05dc_2;
																				IL_05dc_2:
																				array2[num6] = 0;
																				goto IL_05ea_2;
																				IL_05ea_2:
																				num6++;
																				goto IL_05f8_2;
																				IL_05f8_2:
																				ptr2 += 8;
																				goto IL_0ef8_2;
																				IL_060b_2:
																				if (10 < b)
																				{
																					break;
																				}
																				goto IL_0619_2;
																				IL_0619_2:
																				if (10 > b)
																				{
																					break;
																				}
																				num = 50;
																				goto IL_0630_2;
																			}
																			break;
																		}
																		goto IL_088e_2;
																		IL_08b7_2:
																		array2[num6 - 1] = 5;
																		goto IL_0ef8_2;
																		IL_088e_2:
																		array3[num6 - 1] = new string[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])];
																		goto IL_08b7_2;
																	}
																	break;
																}
																goto IL_08d0_2;
																IL_0e40_2:
																if (22 > b)
																{
																	break;
																}
																goto IL_0e4e_2;
																IL_08d0_2:
																if (20 >= b)
																{
																	goto IL_08de_2;
																}
																goto IL_0bfe_2;
																IL_08de_2:
																if (20 <= b)
																{
																	goto IL_08e9_2;
																}
																goto IL_0932_2;
																IL_08e9_2:
																*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(float*)(ptr2 + num3);
																goto IL_0903_2;
																IL_0903_2:
																array2[num6] = 3;
																goto IL_0911_2;
																IL_0911_2:
																num6++;
																goto IL_091f_2;
																IL_091f_2:
																ptr2 += 8;
																goto IL_0ef8_2;
																IL_0932_2:
																if (16 < b)
																{
																	goto IL_0940_2;
																}
																num = 64;
																goto IL_0a7a_2;
																IL_0940_2:
																if (18 >= b)
																{
																	goto IL_094e_2;
																}
																goto IL_0a0a_2;
																IL_094e_2:
																if (18 <= b)
																{
																	goto IL_0959_2;
																}
																goto IL_0986_2;
																IL_0959_2:
																int_0 = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																goto IL_0973_2;
																IL_0973_2:
																num6--;
																goto IL_0ef8_2;
																IL_0986_2:
																if (17 < b)
																{
																	break;
																}
																goto IL_0994_2;
																IL_0994_2:
																if (17 > b)
																{
																	break;
																}
																goto IL_09a2_2;
																IL_09a2_2:
																array2[num6 - 1] = 5;
																num = 92;
																goto IL_09bf_2;
																IL_09bf_2:
																array3[num6 - 1] = ((delegate*<string[], string>)WhenAnyEventToken[*(int*)(ptr2 + num3)])((string[])array3[num6 - 1]);
																goto IL_09f7_2;
																IL_09f7_2:
																ptr2 += 8;
																goto IL_0ef8_2;
																IL_0a0a_2:
																if (19 < b)
																{
																	break;
																}
																goto IL_0a18_2;
																IL_0a18_2:
																if (19 > b)
																{
																	break;
																}
																goto IL_0a26_2;
																IL_0a26_2:
																array3[num6 - 1] = new ThemeData[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])];
																goto IL_0a4f_2;
																IL_0a4f_2:
																array2[num6 - 1] = 5;
																num = 164;
																goto IL_0ef8_2;
																IL_0e4e_2:
																array2[num6 - 2] = 5;
																goto IL_0e62_2;
																IL_0a7a_2:
																if (16 <= b)
																{
																	num = 182;
																	goto IL_0a8e_2;
																}
																goto IL_0adf_2;
																IL_0e62_2:
																array3[num6 - 2] = ((delegate*<string, Color, object>)WhenAnyEventToken[*(int*)(ptr2 + num3)])((string)array3[num6 - 2], (Color)array3[num6 - 1]);
																num = 109;
																goto IL_0eb7_2;
																IL_0a8e_2:
																((string[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])] = (string)array3[num6 - 1];
																goto IL_0acc_2;
																IL_0acc_2:
																num6 -= 3;
																goto IL_0ef8_2;
																IL_0adf_2:
																if (14 >= b)
																{
																	goto IL_0aed_2;
																}
																goto IL_0b89_2;
																IL_0aed_2:
																if (14 > b)
																{
																	break;
																}
																goto IL_0afb_2;
																IL_0afb_2:
																array2[num6] = array2[num6 - 1];
																goto IL_0b13_2;
																IL_0b13_2:
																array4[num6 - 0] = array4[num6 - 1];
																goto IL_0b31_2;
																IL_0b31_2:
																*(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6]) = *(long*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1]);
																goto IL_0b55_2;
																IL_0b55_2:
																array3[num6] = array3[num6 - 1];
																num = 5;
																goto IL_0b76_2;
																IL_0b76_2:
																num6++;
																goto IL_0ef8_2;
																IL_0b89_2:
																if (15 < b)
																{
																	break;
																}
																num = 28;
																goto IL_0ba0_2;
																IL_0eb7_2:
																num6--;
																goto IL_0ec5_2;
																IL_0ba0_2:
																if (15 > b)
																{
																	break;
																}
																goto IL_0bae_2;
																IL_0bae_2:
																array2[num6] = 5;
																goto IL_0bbc_2;
																IL_0bbc_2:
																array3[num6] = array6[*(int*)(ptr2 + num3)];
																num = 218;
																goto IL_0bdd_2;
																IL_0bdd_2:
																num6++;
																goto IL_0beb_2;
																IL_0beb_2:
																ptr2 += 8;
																goto IL_0ef8_2;
																IL_0bfe_2:
																if (23 < b)
																{
																	goto IL_0c0c_2;
																}
																num = 31;
																goto IL_0d00_2;
																IL_0c0c_2:
																if (25 >= b)
																{
																	goto IL_0c1a_2;
																}
																goto IL_0cbf_2;
																IL_0c1a_2:
																if (25 <= b)
																{
																	goto IL_0c25_2;
																}
																goto IL_0c51_2;
																IL_0c25_2:
																themeData_0 = (ThemeData[])array3[num6 - 1];
																goto IL_0c3e_2;
																IL_0c3e_2:
																num6--;
																goto IL_0ef8_2;
																IL_0c51_2:
																if (24 < b)
																{
																	break;
																}
																goto IL_0c5f_2;
																IL_0c5f_2:
																if (24 > b)
																{
																	break;
																}
																goto IL_0c6d_2;
																IL_0c6d_2:
																array2[num6] = 4;
																goto IL_0c7b_2;
																IL_0c7b_2:
																array3[num6] = ((delegate*<Color>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
																goto IL_0c9e_2;
																IL_0c9e_2:
																num6++;
																goto IL_0cac_2;
																IL_0cac_2:
																ptr2 += 8;
																goto IL_0ef8_2;
																IL_0cbf_2:
																if (26 < b)
																{
																	break;
																}
																goto IL_0ccd_2;
																IL_0ccd_2:
																if (26 > b)
																{
																	break;
																}
																goto IL_0cdb_2;
																IL_0cdb_2:
																num9 = ptr2;
																num10 = -200;
																num4 = 1;
																ptr2 = num9 + num10;
																goto IL_0ef8_2;
																IL_0ec5_2:
																ptr2 += 8;
																goto IL_0ef8_2;
																IL_0d00_2:
																if (23 <= b)
																{
																	goto IL_0d0b_2;
																}
																goto IL_0d60_2;
																IL_0d0b_2:
																((ThemeData[])array3[num6 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])] = (ThemeData)array3[num6 - 1];
																goto IL_0d4d_2;
																IL_0d4d_2:
																num6 -= 3;
																goto IL_0ef8_2;
																IL_0d60_2:
																if (21 >= b)
																{
																	goto IL_0d6e_2;
																}
																goto IL_0e32_2;
																IL_0d6e_2:
																if (21 > b)
																{
																	break;
																}
																goto IL_0d7c_2;
																IL_0d7c_2:
																array2[num6 - 4] = 5;
																goto IL_0d90_2;
																IL_0d90_2:
																array3[num6 - 4] = ((delegate*<float, float, float, float, object>)WhenAnyEventToken[*(int*)(ptr2 + num3)])((float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 4])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 3])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 2])), (float)(*(double*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array5[num6 - 1])));
																goto IL_0e08_2;
																IL_0e08_2:
																num6 -= 3;
																goto IL_0e16_2;
																IL_0e16_2:
																ptr2 += 8;
																num = 155;
																goto IL_0ef8_2;
																IL_0e32_2:
																if (22 < b)
																{
																	break;
																}
																goto IL_0e40_2;
															}
															break;
															IL_0463_2:;
														}
													}
													((delegate*<void>)WhenAnyEventToken[*(int*)(ptr2 + num3)])();
													goto IL_0eea_2;
													IL_0eea_2:
													ptr2 += 8;
													goto IL_0ef8_2;
													continue;
													end_IL_0473_2:
													break;
												}
												continue;
												end_IL_0483:
												break;
											}
											continue;
											end_IL_0493:
											break;
										}
										break;
									}
									break;
								}
								break;
							}
							array7 = array3;
							num5 = num6;
							if (array == null)
							{
								goto IL_06e9_2;
							}
							continue;
							end_IL_06f7:
							break;
						}
						break;
					}
					continue;
					end_IL_0f9d:
					break;
				}
				continue;
				end_IL_0fb0:
				break;
			}
		}
	}

	private unsafe static int smethod_3(int int_2)
	{
		int num = 15;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							num = 54;
							while (true)
							{
								int[] array3 = new int[4];
								while (true)
								{
									long[] array4 = new long[3];
									while (true)
									{
										array3[0] = int_2;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref BinaryObjectsetChannelInfo.GetRandomFileNamesetTargetTypeName);
											num = 48;
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													num = 66;
													while (true)
													{
														if (num4 != 1)
														{
															while (true)
															{
																num = 43;
																while (true)
																{
																	byte b = *ptr2;
																	while (true)
																	{
																		ptr2++;
																		while (true)
																		{
																			IL_02e0:
																			if (b >= 1)
																			{
																				num = 79;
																				while (b <= 11)
																				{
																					while (true)
																					{
																						IL_02bd:
																						if (6 >= b)
																						{
																							num = 77;
																							while (true)
																							{
																								IL_02b0:
																								if (6 > b)
																								{
																									while (true)
																									{
																										IL_02a0:
																										if (3 < b)
																										{
																											while (true)
																											{
																												IL_0290:
																												if (4 < b)
																												{
																													while (5 >= b)
																													{
																														while (5 <= b)
																														{
																															while (true)
																															{
																																IL_0260:
																																array[num5] = 0;
																																while (true)
																																{
																																	IL_023b:
																																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																																	while (true)
																																	{
																																		IL_022f:
																																		array2[num5] = null;
																																		while (true)
																																		{
																																			IL_0216:
																																			num5++;
																																			num = 118;
																																			while (true)
																																			{
																																				if (num != 118)
																																				{
																																					if (num != 1099)
																																					{
																																						break;
																																					}
																																					switch (num)
																																					{
																																					case 12:
																																						goto IL_0216;
																																					case 104:
																																						goto IL_022f;
																																					case 4:
																																						goto IL_023b;
																																					case 82:
																																					case 99:
																																						goto IL_0260;
																																					case 37:
																																						goto IL_0270;
																																					case 103:
																																						goto IL_0280;
																																					case 108:
																																					case 111:
																																						goto IL_0290;
																																					case 70:
																																						goto IL_02a0;
																																					case 77:
																																						goto IL_02b0;
																																					case 87:
																																						goto IL_02bd;
																																					case 79:
																																						goto IL_02d0;
																																					case 85:
																																						goto IL_02e0;
																																					case 95:
																																						goto end_IL_02e0;
																																					case 43:
																																						goto end_IL_02f3;
																																					case 106:
																																						goto end_IL_0303;
																																					case 11:
																																					case 34:
																																						goto IL_0319;
																																					case 71:
																																						goto IL_035e;
																																					case 73:
																																						goto IL_0371;
																																					case 53:
																																						goto IL_037c;
																																					case 24:
																																						goto IL_038a;
																																					case 51:
																																						goto IL_0395;
																																					case 7:
																																					case 21:
																																						goto IL_03a3;
																																					case 58:
																																						goto IL_03e5;
																																					case 76:
																																						goto IL_03f8;
																																					case 0:
																																						goto IL_0403;
																																					case 64:
																																						goto IL_0411;
																																					case 90:
																																						goto IL_0424;
																																					case 45:
																																						goto IL_0438;
																																					case 92:
																																						goto IL_044b;
																																					case 88:
																																					case 93:
																																						goto IL_045e;
																																					case 1:
																																						goto IL_04c0;
																																					case 94:
																																						goto IL_04d3;
																																					case 97:
																																					case 98:
																																						goto IL_04e3;
																																					case 107:
																																						goto IL_04ff;
																																					case 89:
																																						goto IL_0513;
																																					case 86:
																																					case 110:
																																						goto IL_0526;
																																					case 25:
																																						goto IL_0549;
																																					case 83:
																																						goto IL_0557;
																																					case 13:
																																						goto IL_056e;
																																					case 78:
																																						goto IL_0594;
																																					case 23:
																																					case 40:
																																						goto IL_059f;
																																					case 81:
																																						goto IL_05b7;
																																					case 16:
																																					case 69:
																																						goto IL_05c2;
																																					case 39:
																																						goto IL_05d0;
																																					case 47:
																																					case 67:
																																						goto IL_05db;
																																					case 44:
																																						goto IL_0604;
																																					case 74:
																																						goto IL_0612;
																																					case 63:
																																						goto IL_062d;
																																					case 30:
																																					case 59:
																																						goto IL_0638;
																																					case 102:
																																						goto IL_0651;
																																					case 68:
																																						goto IL_065f;
																																					case 75:
																																						goto IL_066d;
																																					case 6:
																																					case 8:
																																					case 9:
																																					case 19:
																																					case 22:
																																					case 27:
																																					case 31:
																																					case 32:
																																					case 35:
																																					case 38:
																																					case 42:
																																					case 49:
																																					case 52:
																																					case 55:
																																					case 60:
																																					case 62:
																																					case 65:
																																					case 72:
																																					case 91:
																																					case 96:
																																					case 101:
																																					case 109:
																																						goto end_IL_0203;
																																					case 2:
																																					case 5:
																																					case 10:
																																					case 17:
																																					case 20:
																																					case 26:
																																					case 29:
																																					case 41:
																																					case 50:
																																					case 57:
																																					case 61:
																																					case 66:
																																					case 80:
																																						goto end_IL_030e;
																																					case 105:
																																						goto end_IL_0690;
																																					case 48:
																																						goto end_IL_06a3;
																																					case 33:
																																						goto end_IL_06ae;
																																					case 84:
																																						goto end_IL_06b8;
																																					case 18:
																																						goto end_IL_06cc;
																																					case 54:
																																						goto end_IL_06e1;
																																					case 56:
																																						goto end_IL_06f1;
																																					case 46:
																																						goto end_IL_0701;
																																					case 28:
																																					case 100:
																																						goto end_IL_070c;
																																					case 14:
																																						goto end_IL_071c;
																																					case 15:
																																						goto end_IL_072c;
																																					case 3:
																																					case 36:
																																						goto IL_0747;
																																					}
																																					continue;
																																				}
																																				ptr2 += 8;
																																				goto end_IL_030e;
																																				continue;
																																				end_IL_0203:
																																				break;
																																			}
																																			break;
																																		}
																																		break;
																																	}
																																	break;
																																}
																																break;
																															}
																															break;
																															IL_0270:;
																														}
																														break;
																														IL_0280:;
																													}
																													break;
																												}
																												goto IL_035e;
																												IL_035e:
																												if (4 > b)
																												{
																													break;
																												}
																												goto end_IL_030e;
																											}
																											break;
																										}
																										goto IL_0594;
																										IL_065f:
																										num5++;
																										goto IL_066d;
																										IL_0594:
																										if (3 <= b)
																										{
																											goto IL_059f;
																										}
																										goto IL_05b7;
																										IL_059f:
																										ptr2 = ptr + *(int*)(ptr2 + num3);
																										goto end_IL_030e;
																										IL_05b7:
																										if (1 < b)
																										{
																											goto IL_05c2;
																										}
																										goto IL_062d;
																										IL_05c2:
																										if (2 < b)
																										{
																											break;
																										}
																										goto IL_05d0;
																										IL_05d0:
																										if (2 > b)
																										{
																											num = 32;
																											break;
																										}
																										goto IL_05db;
																										IL_05db:
																										ref int reference = ref array3[*(int*)(ptr2 + num3)];
																										reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																										goto IL_0604;
																										IL_0604:
																										ptr2 += 8;
																										goto IL_0612;
																										IL_0612:
																										num5--;
																										goto end_IL_030e;
																										IL_066d:
																										ptr2 += 8;
																										goto end_IL_030e;
																										IL_062d:
																										if (1 > b)
																										{
																											break;
																										}
																										goto IL_0638;
																										IL_0638:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										goto IL_0651;
																										IL_0651:
																										array[num5] = 0;
																										goto IL_065f;
																									}
																									break;
																								}
																								goto IL_0319;
																								IL_0513:
																								num5--;
																								goto end_IL_030e;
																								IL_0319:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_04ff;
																								IL_04ff:
																								array[num5 - 2] = 0;
																								goto IL_0513;
																							}
																							break;
																						}
																						goto IL_0371;
																						IL_044b:
																						if (10 > b)
																						{
																							break;
																						}
																						goto IL_04e3;
																						IL_04e3:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_030e;
																						IL_0371:
																						if (9 >= b)
																						{
																							goto IL_037c;
																						}
																						goto IL_03f8;
																						IL_037c:
																						if (9 > b)
																						{
																							goto IL_038a;
																						}
																						goto IL_045e;
																						IL_038a:
																						if (7 >= b)
																						{
																							goto IL_0395;
																						}
																						goto IL_03e5;
																						IL_0395:
																						if (7 > b)
																						{
																							break;
																						}
																						goto IL_03a3;
																						IL_03a3:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0424;
																						IL_0424:
																						array[num5 - 2] = 0;
																						goto IL_0438;
																						IL_0438:
																						num5--;
																						goto end_IL_030e;
																						IL_03e5:
																						if (8 < b)
																						{
																							break;
																						}
																						goto IL_04d3;
																						IL_04d3:
																						if (8 > b)
																						{
																							break;
																						}
																						goto IL_0526;
																						IL_0526:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																						goto IL_0549;
																						IL_0549:
																						array[num5] = 0;
																						goto IL_0557;
																						IL_0557:
																						num5++;
																						num = 13;
																						goto IL_056e;
																						IL_056e:
																						ptr2 += 8;
																						goto end_IL_030e;
																						IL_045e:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_04c0;
																						IL_04c0:
																						num5 -= 2;
																						goto end_IL_030e;
																						IL_03f8:
																						if (10 < b)
																						{
																							goto IL_0403;
																						}
																						goto IL_044b;
																						IL_0403:
																						if (11 < b)
																						{
																							break;
																						}
																						goto IL_0411;
																						IL_0411:
																						if (11 <= b)
																						{
																						}
																						break;
																					}
																					break;
																					IL_02d0:;
																				}
																			}
																			ptr2 = ptr + *(int*)(ptr2 + num3);
																			goto end_IL_030e;
																			continue;
																			end_IL_02e0:
																			break;
																		}
																		continue;
																		end_IL_02f3:
																		break;
																	}
																	continue;
																	end_IL_0303:
																	break;
																}
																continue;
																end_IL_030e:
																break;
															}
															continue;
														}
														goto IL_0747;
														IL_0747:
														return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
														continue;
														end_IL_0690:
														break;
													}
													continue;
													end_IL_06a3:
													break;
												}
												continue;
												end_IL_06ae:
												break;
											}
											continue;
											end_IL_06b8:
											break;
										}
										continue;
										end_IL_06cc:
										break;
									}
									continue;
									end_IL_06e1:
									break;
								}
								continue;
								end_IL_06f1:
								break;
							}
							continue;
							end_IL_0701:
							break;
						}
						continue;
						end_IL_070c:
						break;
					}
					continue;
					end_IL_071c:
					break;
				}
				continue;
				end_IL_072c:
				break;
			}
		}
	}

	private unsafe static int smethod_4(int int_2, int int_3)
	{
		int num = 34;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref ReturnManifestHashSize.setAsBstrCMSSECTIONIDCOMPATIBLEFRAMEWORKSSECTION);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_029b:
															byte b = *ptr2;
															while (true)
															{
																IL_028b:
																ptr2++;
																while (true)
																{
																	IL_027b:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_025b:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_024b:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_023b:
																								if (2 >= b)
																								{
																									while (true)
																									{
																										IL_022e:
																										if (2 <= b)
																										{
																											while (true)
																											{
																												IL_01bb:
																												ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																												while (true)
																												{
																													IL_01a2:
																													num5 -= 2;
																													num = 96;
																													while (num != 96)
																													{
																														if (num != 1077)
																														{
																															goto IL_0417;
																														}
																														switch (num)
																														{
																														case 60:
																															goto IL_01a2;
																														case 3:
																														case 72:
																															goto IL_01bb;
																														case 42:
																															goto IL_022e;
																														case 32:
																														case 43:
																															goto IL_023b;
																														case 81:
																															goto IL_024b;
																														case 48:
																															goto IL_025b;
																														case 39:
																															goto IL_026b;
																														case 86:
																															goto IL_027b;
																														case 58:
																															goto IL_028b;
																														case 30:
																														case 57:
																															goto IL_029b;
																														case 12:
																														case 88:
																															goto IL_02a6;
																														case 10:
																															goto IL_02b4;
																														case 23:
																															goto IL_02d0;
																														case 20:
																															goto IL_02de;
																														case 29:
																														case 77:
																															goto IL_02e9;
																														case 21:
																															goto IL_0329;
																														case 83:
																															goto IL_033d;
																														case 1:
																														case 19:
																															goto IL_035e;
																														case 18:
																															goto IL_0387;
																														case 47:
																															goto IL_0395;
																														case 17:
																															goto IL_03a8;
																														case 54:
																															goto IL_03b3;
																														case 69:
																														case 89:
																															goto IL_03c1;
																														case 75:
																															goto IL_03cf;
																														case 9:
																														case 73:
																															goto IL_03dd;
																														case 40:
																															goto IL_03fe;
																														case 14:
																														case 65:
																															goto IL_0409;
																														case 27:
																															goto IL_0417;
																														case 35:
																														case 80:
																															goto IL_0425;
																														case 87:
																															goto IL_0441;
																														case 50:
																														case 61:
																															goto IL_044c;
																														case 15:
																															goto IL_045a;
																														case 76:
																															goto IL_047d;
																														case 25:
																															goto IL_0487;
																														case 7:
																															goto IL_049e;
																														case 0:
																														case 11:
																														case 13:
																														case 36:
																														case 37:
																														case 44:
																														case 46:
																														case 49:
																														case 52:
																														case 53:
																														case 62:
																														case 63:
																														case 66:
																														case 68:
																														case 71:
																														case 79:
																														case 82:
																															goto end_IL_026b;
																														case 26:
																															goto IL_04d1;
																														case 5:
																															goto IL_04df;
																														case 45:
																															goto IL_04ed;
																														case 6:
																														case 16:
																														case 28:
																														case 31:
																														case 41:
																														case 55:
																														case 59:
																														case 64:
																														case 67:
																														case 70:
																															goto end_IL_018f;
																														case 22:
																															goto end_IL_04fb;
																														case 56:
																															goto end_IL_050e;
																														case 85:
																															goto end_IL_0518;
																														case 74:
																															goto end_IL_0523;
																														case 51:
																															goto end_IL_0538;
																														case 24:
																														case 84:
																															goto end_IL_054d;
																														case 8:
																															goto end_IL_055d;
																														case 2:
																														case 78:
																															goto end_IL_056d;
																														case 33:
																															goto end_IL_057d;
																														case 34:
																															goto end_IL_058d;
																														case 4:
																														case 38:
																															goto IL_05b1;
																														}
																														continue;
																														end_IL_018f:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										goto IL_02a6;
																										IL_02b4:
																										if (1 <= b)
																										{
																											num = 82;
																										}
																										goto end_IL_026b;
																										IL_02a6:
																										if (1 < b)
																										{
																											goto end_IL_026b;
																										}
																										goto IL_02b4;
																									}
																									break;
																								}
																								goto IL_02d0;
																								IL_033d:
																								num5--;
																								break;
																								IL_02d0:
																								if (3 < b)
																								{
																									goto end_IL_026b;
																								}
																								goto IL_02de;
																								IL_02de:
																								if (3 > b)
																								{
																									num = 63;
																									goto end_IL_026b;
																								}
																								goto IL_02e9;
																								IL_02e9:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0329;
																								IL_0329:
																								array[num5 - 2] = 0;
																								goto IL_033d;
																							}
																							break;
																						}
																						goto IL_035e;
																						IL_0395:
																						num5--;
																						break;
																						IL_035e:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0387;
																						IL_0387:
																						ptr2 += 8;
																						goto IL_0395;
																					}
																					break;
																				}
																				goto IL_03a8;
																				IL_049e:
																				ptr2 += 8;
																				break;
																				IL_03a8:
																				if (6 >= b)
																				{
																					goto IL_03b3;
																				}
																				goto IL_03fe;
																				IL_03b3:
																				if (6 <= b)
																				{
																					break;
																				}
																				goto IL_03c1;
																				IL_03c1:
																				if (5 < b)
																				{
																					goto end_IL_026b;
																				}
																				goto IL_03cf;
																				IL_03cf:
																				if (5 > b)
																				{
																					goto end_IL_026b;
																				}
																				goto IL_03dd;
																				IL_03dd:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				num = 55;
																				break;
																				IL_03fe:
																				if (7 < b)
																				{
																					goto IL_0409;
																				}
																				goto IL_0441;
																				IL_0409:
																				if (8 < b)
																				{
																					goto end_IL_026b;
																				}
																				goto IL_0417;
																				IL_0417:
																				if (8 > b)
																				{
																					goto end_IL_026b;
																				}
																				goto IL_0425;
																				IL_0425:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				break;
																				IL_0441:
																				if (7 > b)
																				{
																					goto end_IL_026b;
																				}
																				goto IL_044c;
																				IL_044c:
																				array[num5] = 0;
																				goto IL_045a;
																				IL_045a:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_047d;
																				IL_047d:
																				array2[num5] = null;
																				goto IL_0487;
																				IL_0487:
																				num5++;
																				num = 7;
																				goto IL_049e;
																			}
																			goto end_IL_027b;
																			continue;
																			end_IL_026b:
																			break;
																			IL_026b:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04d1;
																	IL_04ed:
																	ptr2 += 8;
																	break;
																	IL_04df:
																	num5++;
																	goto IL_04ed;
																	IL_04d1:
																	array[num5] = 0;
																	goto IL_04df;
																	continue;
																	end_IL_027b:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													num = 38;
													goto IL_05b1;
													IL_05b1:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04fb:
													break;
												}
												continue;
												end_IL_050e:
												break;
											}
											continue;
											end_IL_0518:
											break;
										}
										continue;
										end_IL_0523:
										break;
									}
									continue;
									end_IL_0538:
									break;
								}
								continue;
								end_IL_054d:
								break;
							}
							continue;
							end_IL_055d:
							break;
						}
						continue;
						end_IL_056d:
						break;
					}
					continue;
					end_IL_057d:
					break;
				}
				continue;
				end_IL_058d:
				break;
			}
		}
	}

	private unsafe static int smethod_5(int int_2)
	{
		int num = 25;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref MdFieldInfogetExclude.InvocationListopDivision);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_021c:
																if (b >= 1)
																{
																	while (b <= 10)
																	{
																		while (true)
																		{
																			if (5 >= b)
																			{
																				while (true)
																				{
																					if (5 > b)
																					{
																						num = 111;
																						while (true)
																						{
																							if (num == 111)
																							{
																								goto IL_049f;
																							}
																							if (num != 1092)
																							{
																								goto IL_056e;
																							}
																							switch (num)
																							{
																							case 6:
																								goto end_IL_01d9;
																							case 46:
																								goto end_IL_01ec;
																							case 2:
																								goto end_IL_01ff;
																							case 90:
																								goto IL_021c;
																							case 29:
																								goto end_IL_021c;
																							case 14:
																							case 104:
																								goto end_IL_022c;
																							case 87:
																								goto IL_0247;
																							case 5:
																								goto IL_0252;
																							case 31:
																								goto IL_025d;
																							case 58:
																								goto IL_026b;
																							case 40:
																								goto IL_0290;
																							case 0:
																							case 54:
																								goto IL_02a7;
																							case 63:
																								goto IL_02c3;
																							case 22:
																							case 60:
																								goto IL_02ce;
																							case 3:
																								goto IL_0339;
																							case 50:
																							case 97:
																								goto IL_034c;
																							case 62:
																								goto IL_0357;
																							case 43:
																							case 53:
																								goto IL_0365;
																							case 12:
																								goto IL_03a5;
																							case 66:
																								goto IL_03b9;
																							case 39:
																								goto IL_03cc;
																							case 27:
																								goto IL_03da;
																							case 28:
																							case 71:
																								goto IL_03e8;
																							case 17:
																								goto IL_040b;
																							case 98:
																								goto IL_0419;
																							case 16:
																								goto IL_0427;
																							case 44:
																							case 100:
																								goto IL_043a;
																							case 41:
																								goto IL_0448;
																							case 72:
																								goto IL_046b;
																							case 85:
																								goto IL_0475;
																							case 48:
																								goto IL_0483;
																							case 75:
																								goto IL_049f;
																							case 64:
																								goto IL_04ad;
																							case 42:
																							case 73:
																								goto IL_04b8;
																							case 89:
																								goto IL_04c6;
																							case 9:
																							case 15:
																								goto IL_04d4;
																							case 7:
																								goto IL_04ed;
																							case 34:
																								goto IL_04fb;
																							case 59:
																								goto IL_0509;
																							case 33:
																							case 84:
																								goto IL_051c;
																							case 1:
																								goto IL_0545;
																							case 83:
																								goto IL_0553;
																							case 10:
																							case 81:
																								goto IL_0563;
																							case 13:
																								goto IL_056e;
																							case 38:
																							case 82:
																								goto IL_0579;
																							case 56:
																								goto IL_058e;
																							case 57:
																								goto IL_0599;
																							case 8:
																							case 11:
																							case 23:
																							case 26:
																							case 30:
																							case 32:
																							case 37:
																							case 52:
																							case 67:
																							case 68:
																							case 70:
																							case 77:
																							case 80:
																							case 86:
																							case 91:
																							case 94:
																							case 95:
																							case 99:
																							case 102:
																							case 103:
																								goto end_IL_020c;
																							case 19:
																							case 21:
																							case 35:
																							case 36:
																							case 47:
																							case 49:
																							case 51:
																							case 61:
																							case 65:
																							case 74:
																							case 76:
																							case 92:
																							case 93:
																								goto end_IL_023c;
																							case 55:
																								goto end_IL_05b7;
																							case 45:
																								goto end_IL_05ca;
																							case 88:
																								goto end_IL_05d4;
																							case 18:
																								goto end_IL_05df;
																							case 78:
																							case 79:
																								goto end_IL_05f4;
																							case 101:
																								goto end_IL_0604;
																							case 69:
																							case 96:
																								goto end_IL_0614;
																							case 24:
																								goto end_IL_0624;
																							case 25:
																								goto end_IL_0634;
																							case 4:
																							case 20:
																								goto IL_0658;
																							}
																							continue;
																							IL_058e:
																							if (4 < b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_0599;
																							IL_0599:
																							if (4 <= b)
																							{
																								goto end_IL_023c;
																							}
																							goto end_IL_020c;
																							IL_049f:
																							if (2 >= b)
																							{
																								goto IL_04ad;
																							}
																							goto IL_0563;
																							IL_04ad:
																							if (2 > b)
																							{
																								goto IL_04b8;
																							}
																							goto IL_051c;
																							IL_04b8:
																							if (1 < b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_04c6;
																							IL_04c6:
																							if (1 > b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_04d4;
																							IL_04d4:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_04ed;
																							IL_04ed:
																							array[num5] = 0;
																							goto IL_04fb;
																							IL_04fb:
																							num5++;
																							goto IL_0509;
																							IL_0509:
																							ptr2 += 8;
																							goto end_IL_023c;
																							IL_051c:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0545;
																							IL_0545:
																							ptr2 += 8;
																							goto IL_0553;
																							IL_0553:
																							num5--;
																							goto end_IL_023c;
																							IL_0563:
																							if (3 >= b)
																							{
																								goto IL_056e;
																							}
																							goto IL_058e;
																							IL_056e:
																							if (3 > b)
																							{
																								goto end_IL_020c;
																							}
																							goto IL_0579;
																							IL_0579:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_023c;
																							continue;
																							end_IL_01d9:
																							break;
																						}
																						continue;
																					}
																					goto IL_043a;
																					IL_0475:
																					num5++;
																					goto IL_0483;
																					IL_0483:
																					ptr2 += 8;
																					num = 21;
																					goto end_IL_023c;
																					IL_043a:
																					array[num5] = 0;
																					goto IL_0448;
																					IL_0448:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																					goto IL_046b;
																					IL_046b:
																					array2[num5] = null;
																					goto IL_0475;
																					continue;
																					end_IL_01ec:
																					break;
																				}
																				continue;
																			}
																			goto IL_0247;
																			IL_03e8:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_040b;
																			IL_0247:
																			if (8 < b)
																			{
																				goto IL_0252;
																			}
																			goto IL_02c3;
																			IL_0252:
																			if (9 < b)
																			{
																				goto IL_025d;
																			}
																			num = 40;
																			goto IL_0290;
																			IL_025d:
																			if (10 < b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_026b;
																			IL_026b:
																			if (10 <= b)
																			{
																				num = 70;
																			}
																			goto end_IL_020c;
																			IL_0419:
																			num5++;
																			goto IL_0427;
																			IL_040b:
																			array[num5] = 0;
																			goto IL_0419;
																			IL_0290:
																			if (9 > b)
																			{
																				goto end_IL_020c;
																			}
																			num = 54;
																			goto IL_02a7;
																			IL_0427:
																			ptr2 += 8;
																			goto end_IL_023c;
																			IL_02a7:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_023c;
																			IL_02c3:
																			if (8 <= b)
																			{
																				goto IL_02ce;
																			}
																			goto IL_034c;
																			IL_02ce:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			num = 3;
																			goto IL_0339;
																			IL_0339:
																			num5 -= 2;
																			goto end_IL_023c;
																			IL_034c:
																			if (6 >= b)
																			{
																				goto IL_0357;
																			}
																			goto IL_03cc;
																			IL_0357:
																			if (6 > b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_0365;
																			IL_0365:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03a5;
																			IL_03a5:
																			array[num5 - 2] = 0;
																			goto IL_03b9;
																			IL_03b9:
																			num5--;
																			goto end_IL_023c;
																			IL_03cc:
																			if (7 < b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_03da;
																			IL_03da:
																			if (7 > b)
																			{
																				goto end_IL_020c;
																			}
																			goto IL_03e8;
																			continue;
																			end_IL_01ff:
																			break;
																		}
																		continue;
																		end_IL_020c:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_023c;
																continue;
																end_IL_021c:
																break;
															}
															continue;
															end_IL_022c:
															break;
														}
														continue;
														end_IL_023c:
														break;
													}
													continue;
												}
												num = 4;
												goto IL_0658;
												IL_0658:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_05b7:
												break;
											}
											continue;
											end_IL_05ca:
											break;
										}
										continue;
										end_IL_05d4:
										break;
									}
									continue;
									end_IL_05df:
									break;
								}
								continue;
								end_IL_05f4:
								break;
							}
							continue;
							end_IL_0604:
							break;
						}
						continue;
						end_IL_0614:
						break;
					}
					continue;
					end_IL_0624:
					break;
				}
				continue;
				end_IL_0634:
				break;
			}
		}
	}

	private unsafe static int smethod_6()
	{
		int num = 21;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							num = 84;
							while (true)
							{
								int[] array3 = new int[2];
								while (true)
								{
									long[] array4 = new long[4];
									num = 141;
									while (true)
									{
										object[] array5 = new object[1];
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RegisterWithHostGetInArgName.setCancellationTokenNP);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															IL_0329:
															byte b = *ptr2;
															while (true)
															{
																IL_0319:
																ptr2++;
																while (true)
																{
																	IL_0309:
																	if (b >= 1)
																	{
																		while (b <= 15)
																		{
																			while (true)
																			{
																				IL_02ec:
																				if (8 < b)
																				{
																					while (true)
																					{
																						IL_02dc:
																						if (12 >= b)
																						{
																							while (true)
																							{
																								IL_02cc:
																								if (12 > b)
																								{
																									while (true)
																									{
																										IL_02bf:
																										if (10 >= b)
																										{
																											while (true)
																											{
																												IL_02af:
																												if (10 > b)
																												{
																													while (9 >= b)
																													{
																														while (9 > b)
																														{
																															num = 151;
																															while (num != 151 && num == 1132)
																															{
																																switch (num)
																																{
																																case 55:
																																	goto IL_028c;
																																case 27:
																																case 115:
																																	goto IL_029f;
																																case 144:
																																	goto IL_02af;
																																case 50:
																																	goto IL_02bf;
																																case 29:
																																	goto IL_02cc;
																																case 111:
																																	goto IL_02dc;
																																case 76:
																																	goto IL_02ec;
																																case 142:
																																	goto IL_02f9;
																																case 46:
																																	goto IL_0309;
																																case 49:
																																	goto IL_0319;
																																case 58:
																																case 139:
																																	goto IL_0329;
																																case 8:
																																	goto IL_0334;
																																case 13:
																																	goto IL_0344;
																																case 30:
																																case 61:
																																	goto IL_035d;
																																case 78:
																																case 89:
																																	goto IL_0375;
																																case 39:
																																	goto IL_03b5;
																																case 41:
																																	goto IL_03c9;
																																case 90:
																																	goto IL_03dc;
																																case 83:
																																case 120:
																																	goto IL_03ef;
																																case 119:
																																	goto IL_03fa;
																																case 33:
																																case 87:
																																	goto IL_0405;
																																case 32:
																																case 121:
																																	goto IL_042f;
																																case 125:
																																	goto IL_0442;
																																case 117:
																																	goto IL_0450;
																																case 124:
																																	goto IL_045b;
																																case 5:
																																case 19:
																																	goto IL_0466;
																																case 62:
																																	goto IL_04a5;
																																case 65:
																																	goto IL_04b8;
																																case 26:
																																	goto IL_04c6;
																																case 112:
																																	goto IL_04d9;
																																case 6:
																																	goto IL_04e7;
																																case 70:
																																case 113:
																																	goto IL_04fe;
																																case 4:
																																	goto IL_0527;
																																case 82:
																																	goto IL_0535;
																																case 130:
																																	goto IL_0548;
																																case 57:
																																case 131:
																																	goto IL_055b;
																																case 45:
																																	goto IL_059f;
																																case 3:
																																	goto IL_05b3;
																																case 133:
																																	goto IL_05c6;
																																case 99:
																																case 106:
																																	goto IL_05d4;
																																case 100:
																																	goto IL_05e2;
																																case 59:
																																case 104:
																																	goto IL_05ed;
																																case 95:
																																	goto IL_062d;
																																case 16:
																																	goto IL_0641;
																																case 54:
																																	goto IL_0654;
																																case 122:
																																	goto IL_0662;
																																case 44:
																																case 110:
																																	goto IL_0670;
																																case 11:
																																	goto IL_0689;
																																case 43:
																																	goto IL_0697;
																																case 37:
																																	goto IL_06a5;
																																case 53:
																																	goto IL_06b8;
																																case 47:
																																	goto IL_06c6;
																																case 108:
																																case 128:
																																	goto IL_06d4;
																																case 75:
																																	goto IL_06fd;
																																case 71:
																																case 134:
																																	goto IL_0716;
																																case 123:
																																	goto IL_0724;
																																case 0:
																																	goto IL_073c;
																																case 28:
																																	goto IL_074a;
																																case 92:
																																case 137:
																																	goto IL_075d;
																																case 56:
																																	goto IL_077b;
																																case 9:
																																	goto IL_0789;
																																case 2:
																																case 140:
																																	goto IL_079c;
																																case 93:
																																	goto IL_07aa;
																																case 79:
																																case 98:
																																	goto IL_07c3;
																																case 74:
																																	goto IL_0825;
																																case 101:
																																case 135:
																																	goto IL_083e;
																																case 51:
																																	goto IL_084c;
																																case 97:
																																	goto IL_086f;
																																case 81:
																																	goto IL_0879;
																																case 18:
																																	goto IL_0887;
																																case 12:
																																case 15:
																																case 17:
																																case 22:
																																case 23:
																																case 31:
																																case 34:
																																case 35:
																																case 36:
																																case 40:
																																case 48:
																																case 63:
																																case 64:
																																case 66:
																																case 67:
																																case 69:
																																case 77:
																																case 80:
																																case 103:
																																case 105:
																																case 107:
																																case 109:
																																case 114:
																																case 126:
																																case 127:
																																	goto end_IL_0279;
																																case 7:
																																case 10:
																																case 24:
																																case 38:
																																case 42:
																																case 52:
																																case 60:
																																case 68:
																																case 72:
																																case 73:
																																case 85:
																																case 86:
																																case 88:
																																case 91:
																																case 116:
																																case 129:
																																case 138:
																																case 143:
																																	goto end_IL_028c;
																																case 102:
																																	goto end_IL_08aa;
																																case 136:
																																	goto end_IL_08bd;
																																case 141:
																																	goto end_IL_08c7;
																																case 94:
																																	goto end_IL_08d2;
																																case 84:
																																	goto end_IL_08e2;
																																case 25:
																																	goto end_IL_08fb;
																																case 1:
																																	goto end_IL_090b;
																																case 96:
																																case 118:
																																	goto end_IL_0916;
																																case 20:
																																	goto end_IL_0926;
																																case 21:
																																	goto end_IL_0936;
																																case 14:
																																case 132:
																																	goto IL_0951;
																																}
																																continue;
																																end_IL_0279:
																																break;
																															}
																															goto end_IL_029f;
																															continue;
																															end_IL_028c:
																															break;
																															IL_028c:;
																														}
																														goto end_IL_0309;
																														continue;
																														end_IL_029f:
																														break;
																														IL_029f:;
																													}
																													break;
																												}
																												goto IL_083e;
																												IL_0887:
																												ptr2 += 8;
																												goto end_IL_0309;
																												IL_083e:
																												array[num5] = 0;
																												goto IL_084c;
																												IL_084c:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																												goto IL_086f;
																												IL_086f:
																												array2[num5] = null;
																												goto IL_0879;
																												IL_0879:
																												num5++;
																												goto IL_0887;
																											}
																											break;
																										}
																										goto IL_0344;
																										IL_059f:
																										array[num5 - 2] = 0;
																										goto IL_05b3;
																										IL_0344:
																										if (11 < b)
																										{
																											break;
																										}
																										num = 90;
																										goto IL_03dc;
																										IL_05b3:
																										num5--;
																										goto end_IL_0309;
																										IL_03dc:
																										if (11 > b)
																										{
																											break;
																										}
																										goto IL_055b;
																										IL_055b:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																										goto IL_059f;
																									}
																									break;
																								}
																								goto IL_0375;
																								IL_03c9:
																								num5--;
																								goto end_IL_0309;
																								IL_0375:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_03b5;
																								IL_03b5:
																								array[num5 - 2] = 0;
																								goto IL_03c9;
																							}
																							break;
																						}
																						goto IL_03ef;
																						IL_0825:
																						num5 -= 2;
																						num = 72;
																						goto end_IL_0309;
																						IL_03ef:
																						if (14 >= b)
																						{
																							goto IL_03fa;
																						}
																						goto IL_042f;
																						IL_03fa:
																						if (14 <= b)
																						{
																							goto IL_0405;
																						}
																						num = 140;
																						goto IL_079c;
																						IL_0405:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0309;
																						IL_042f:
																						if (15 < b)
																						{
																							break;
																						}
																						goto IL_0548;
																						IL_079c:
																						if (13 < b)
																						{
																							break;
																						}
																						goto IL_07aa;
																						IL_07aa:
																						if (13 > b)
																						{
																							num = 109;
																							break;
																						}
																						goto IL_07c3;
																						IL_0548:
																						if (15 <= b)
																						{
																						}
																						break;
																						IL_07c3:
																						ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																						goto IL_0825;
																					}
																					break;
																				}
																				goto IL_0334;
																				IL_077b:
																				ptr2 += 8;
																				goto IL_0789;
																				IL_0334:
																				if (8 <= b)
																				{
																					goto IL_035d;
																				}
																				goto IL_0442;
																				IL_035d:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0309;
																				IL_0442:
																				if (4 < b)
																				{
																					goto IL_0450;
																				}
																				goto IL_05c6;
																				IL_0450:
																				if (6 >= b)
																				{
																					goto IL_045b;
																				}
																				goto IL_04d9;
																				IL_045b:
																				if (6 <= b)
																				{
																					goto IL_0466;
																				}
																				goto IL_04b8;
																				IL_0466:
																				((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04a5;
																				IL_04a5:
																				num5 -= 3;
																				goto end_IL_0309;
																				IL_04b8:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_04c6;
																				IL_04c6:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_0716;
																				IL_0716:
																				array[num5] = 5;
																				goto IL_0724;
																				IL_0724:
																				array2[num5] = array5[*(int*)(ptr2 + num3)];
																				goto IL_073c;
																				IL_073c:
																				num5++;
																				goto IL_074a;
																				IL_074a:
																				ptr2 += 8;
																				goto end_IL_0309;
																				IL_04d9:
																				if (7 < b)
																				{
																					break;
																				}
																				goto IL_04e7;
																				IL_04e7:
																				if (7 > b)
																				{
																					break;
																				}
																				num = 70;
																				goto IL_04fe;
																				IL_0789:
																				num5--;
																				goto end_IL_0309;
																				IL_04fe:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0527;
																				IL_0527:
																				ptr2 += 8;
																				goto IL_0535;
																				IL_0535:
																				num5--;
																				goto end_IL_0309;
																				IL_05c6:
																				if (4 > b)
																				{
																					goto IL_05d4;
																				}
																				goto IL_075d;
																				IL_05d4:
																				if (2 >= b)
																				{
																					goto IL_05e2;
																				}
																				goto IL_06b8;
																				IL_05e2:
																				if (2 <= b)
																				{
																					goto IL_05ed;
																				}
																				goto IL_0654;
																				IL_05ed:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_062d;
																				IL_062d:
																				array[num5 - 2] = 0;
																				goto IL_0641;
																				IL_0641:
																				num5--;
																				goto end_IL_0309;
																				IL_0654:
																				if (1 < b)
																				{
																					break;
																				}
																				goto IL_0662;
																				IL_0662:
																				if (1 > b)
																				{
																					break;
																				}
																				goto IL_0670;
																				IL_0670:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																				goto IL_0689;
																				IL_0689:
																				array[num5] = 0;
																				goto IL_0697;
																				IL_0697:
																				num5++;
																				goto IL_06a5;
																				IL_06a5:
																				ptr2 += 8;
																				goto end_IL_0309;
																				IL_06b8:
																				if (3 < b)
																				{
																					break;
																				}
																				goto IL_06c6;
																				IL_06c6:
																				if (3 > b)
																				{
																					break;
																				}
																				goto IL_06d4;
																				IL_06d4:
																				array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																				goto IL_06fd;
																				IL_06fd:
																				array[num5 - 1] = 5;
																				goto end_IL_0309;
																				IL_075d:
																				array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																				goto IL_077b;
																			}
																			break;
																			IL_02f9:;
																		}
																	}
																	ptr2 = ptr + *(int*)(ptr2 + num3);
																	break;
																	continue;
																	end_IL_0309:
																	break;
																}
																break;
															}
															break;
														}
														continue;
													}
													goto IL_0951;
													IL_0951:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_08aa:
													break;
												}
												continue;
												end_IL_08bd:
												break;
											}
											continue;
											end_IL_08c7:
											break;
										}
										continue;
										end_IL_08d2:
										break;
									}
									continue;
									end_IL_08e2:
									break;
								}
								continue;
								end_IL_08fb:
								break;
							}
							continue;
							end_IL_090b:
							break;
						}
						continue;
						end_IL_0916:
						break;
					}
					continue;
					end_IL_0926:
					break;
				}
				continue;
				end_IL_0936:
				break;
			}
		}
	}

	private unsafe static int smethod_7()
	{
		int num = 33;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[4];
					while (true)
					{
						object[] array2 = new object[4];
						while (true)
						{
							int[] array3 = new int[2];
							while (true)
							{
								long[] array4 = new long[4];
								while (true)
								{
									object[] array5 = new object[1];
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref AsReadOnlyArgumentInvalidArgumentForComparison.ProcessorValidDESCKINDFUNCDESC);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_031f:
																if (b >= 1)
																{
																	while (b <= 15)
																	{
																		while (true)
																		{
																			if (8 >= b)
																			{
																				while (true)
																				{
																					if (8 > b)
																					{
																						while (true)
																						{
																							IL_02df:
																							if (4 < b)
																							{
																								goto IL_04a8;
																							}
																							while (true)
																							{
																								IL_02cf:
																								if (4 <= b)
																								{
																									while (true)
																									{
																										IL_02af:
																										array5[*(int*)(ptr2 + num3)] = array2[num5 - 1];
																										while (true)
																										{
																											IL_0296:
																											ptr2 += 8;
																											num = 157;
																											while (true)
																											{
																												if (num != 157)
																												{
																													if (num != 1138)
																													{
																														break;
																													}
																													switch (num)
																													{
																													case 4:
																														goto IL_0296;
																													case 66:
																													case 76:
																														goto IL_02af;
																													case 74:
																														goto IL_02cf;
																													case 25:
																													case 148:
																														goto IL_02df;
																													case 15:
																														goto end_IL_02df;
																													case 112:
																														goto end_IL_02ef;
																													case 104:
																														goto end_IL_02ff;
																													case 28:
																														goto IL_031f;
																													case 63:
																														goto end_IL_031f;
																													case 30:
																													case 134:
																														goto end_IL_032f;
																													case 48:
																														goto IL_035d;
																													case 129:
																														goto IL_036b;
																													case 97:
																													case 114:
																														goto IL_0376;
																													case 80:
																														goto IL_0384;
																													case 144:
																													case 145:
																														goto IL_039b;
																													case 131:
																														goto IL_03b4;
																													case 82:
																														goto IL_03c2;
																													case 132:
																														goto IL_03d0;
																													case 85:
																													case 93:
																														goto IL_03e3;
																													case 9:
																														goto IL_0423;
																													case 31:
																														goto IL_0437;
																													case 50:
																														goto IL_044a;
																													case 56:
																														goto IL_0458;
																													case 45:
																													case 78:
																														goto IL_0466;
																													case 5:
																														goto IL_048f;
																													case 142:
																														goto IL_04a8;
																													case 113:
																														goto end_IL_0283;
																													case 64:
																													case 117:
																														goto IL_04c1;
																													case 125:
																														goto IL_0509;
																													case 133:
																														goto IL_051c;
																													case 111:
																														goto IL_052a;
																													case 8:
																													case 23:
																														goto IL_0538;
																													case 21:
																														goto IL_0546;
																													case 46:
																														goto IL_055e;
																													case 128:
																														goto IL_056c;
																													case 27:
																														goto IL_0588;
																													case 121:
																														goto IL_0596;
																													case 39:
																													case 44:
																														goto IL_05a4;
																													case 55:
																														goto IL_05cd;
																													case 87:
																														goto IL_05db;
																													case 107:
																													case 146:
																														goto IL_05ee;
																													case 137:
																														goto IL_0606;
																													case 92:
																														goto IL_0614;
																													case 22:
																													case 69:
																														goto IL_061f;
																													case 12:
																														goto IL_065f;
																													case 110:
																														goto IL_0673;
																													case 40:
																														goto IL_0686;
																													case 7:
																													case 35:
																														goto IL_0694;
																													case 68:
																														goto IL_069f;
																													case 19:
																													case 135:
																														goto IL_06ad;
																													case 90:
																														goto IL_06f1;
																													case 123:
																														goto IL_0705;
																													case 84:
																														goto IL_0726;
																													case 88:
																													case 96:
																														goto IL_0731;
																													case 37:
																														goto IL_073f;
																													case 47:
																													case 94:
																														goto IL_0752;
																													case 71:
																														goto IL_0760;
																													case 103:
																														goto IL_0783;
																													case 79:
																														goto IL_078d;
																													case 75:
																														goto IL_07a4;
																													case 126:
																														goto IL_07b7;
																													case 65:
																														goto IL_07c5;
																													case 100:
																													case 101:
																														goto IL_07d3;
																													case 141:
																														goto IL_07e1;
																													case 120:
																													case 138:
																														goto IL_07ef;
																													case 119:
																														goto IL_0851;
																													case 11:
																													case 52:
																														goto IL_0861;
																													case 58:
																														goto IL_087a;
																													case 38:
																														goto IL_0885;
																													case 0:
																													case 1:
																													case 2:
																													case 3:
																													case 13:
																													case 14:
																													case 16:
																													case 20:
																													case 26:
																													case 29:
																													case 41:
																													case 42:
																													case 49:
																													case 53:
																													case 54:
																													case 59:
																													case 61:
																													case 72:
																													case 73:
																													case 83:
																													case 89:
																													case 95:
																													case 109:
																													case 115:
																													case 116:
																													case 118:
																													case 124:
																													case 127:
																													case 130:
																													case 139:
																													case 140:
																													case 150:
																														goto end_IL_030f;
																													case 10:
																													case 17:
																													case 24:
																													case 34:
																													case 36:
																													case 43:
																													case 57:
																													case 67:
																													case 70:
																													case 77:
																													case 86:
																													case 91:
																													case 98:
																													case 99:
																													case 102:
																													case 108:
																													case 136:
																													case 147:
																														goto end_IL_033f;
																													case 81:
																														goto end_IL_08a3;
																													case 51:
																														goto end_IL_08b6;
																													case 60:
																														goto end_IL_08c0;
																													case 6:
																														goto end_IL_08cb;
																													case 122:
																													case 143:
																														goto end_IL_08db;
																													case 149:
																														goto end_IL_08eb;
																													case 18:
																													case 106:
																														goto end_IL_08fb;
																													case 32:
																														goto end_IL_090b;
																													case 33:
																														goto end_IL_091b;
																													case 62:
																													case 105:
																														goto IL_0936;
																													}
																													continue;
																												}
																												num5--;
																												goto end_IL_033f;
																												continue;
																												end_IL_0283:
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_035d;
																								IL_0466:
																								array2[num5 - 1] = new int[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																								goto IL_048f;
																								IL_035d:
																								if (2 >= b)
																								{
																									goto IL_036b;
																								}
																								goto IL_044a;
																								IL_036b:
																								if (2 > b)
																								{
																									goto IL_0376;
																								}
																								goto IL_03e3;
																								IL_0376:
																								if (1 < b)
																								{
																									goto end_IL_030f;
																								}
																								goto IL_0384;
																								IL_0384:
																								if (1 > b)
																								{
																									goto end_IL_030f;
																								}
																								num = 144;
																								goto IL_039b;
																								IL_048f:
																								array[num5 - 1] = 5;
																								goto end_IL_033f;
																								IL_039b:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																								goto IL_03b4;
																								IL_03b4:
																								array[num5] = 0;
																								goto IL_03c2;
																								IL_03c2:
																								num5++;
																								goto IL_03d0;
																								IL_03d0:
																								ptr2 += 8;
																								goto end_IL_033f;
																								IL_03e3:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_0423;
																								IL_0423:
																								array[num5 - 2] = 0;
																								goto IL_0437;
																								IL_0437:
																								num5--;
																								goto end_IL_033f;
																								IL_044a:
																								if (3 < b)
																								{
																									goto end_IL_030f;
																								}
																								goto IL_0458;
																								IL_0458:
																								if (3 > b)
																								{
																									goto end_IL_030f;
																								}
																								goto IL_0466;
																							}
																							goto IL_04b6;
																							IL_05db:
																							num5--;
																							goto end_IL_033f;
																							IL_04a8:
																							if (6 >= b)
																							{
																								goto IL_04b6;
																							}
																							goto IL_0588;
																							IL_04b6:
																							if (6 <= b)
																							{
																								goto IL_04c1;
																							}
																							goto IL_051c;
																							IL_04c1:
																							((int[])array2[num5 - 3])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2])] = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							num = 125;
																							goto IL_0509;
																							IL_0509:
																							num5 -= 3;
																							goto end_IL_033f;
																							IL_051c:
																							if (5 < b)
																							{
																								goto end_IL_030f;
																							}
																							goto IL_052a;
																							IL_052a:
																							if (5 > b)
																							{
																								goto end_IL_030f;
																							}
																							goto IL_0538;
																							IL_0538:
																							array[num5] = 5;
																							goto IL_0546;
																							IL_0546:
																							array2[num5] = array5[*(int*)(ptr2 + num3)];
																							goto IL_055e;
																							IL_055e:
																							num5++;
																							goto IL_056c;
																							IL_056c:
																							ptr2 += 8;
																							num = 57;
																							goto end_IL_033f;
																							IL_0588:
																							if (7 < b)
																							{
																								goto end_IL_030f;
																							}
																							goto IL_0596;
																							IL_0596:
																							if (7 > b)
																							{
																								goto end_IL_030f;
																							}
																							goto IL_05a4;
																							IL_05a4:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_05cd;
																							IL_05cd:
																							ptr2 += 8;
																							goto IL_05db;
																							continue;
																							end_IL_02df:
																							break;
																						}
																						continue;
																					}
																					goto IL_05ee;
																					IL_05ee:
																					ptr2 = ptr + *(int*)(ptr2 + num3);
																					goto end_IL_033f;
																					continue;
																					end_IL_02ef:
																					break;
																				}
																				continue;
																			}
																			goto IL_0606;
																			IL_087a:
																			if (15 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_0885;
																			IL_0606:
																			if (12 >= b)
																			{
																				goto IL_0614;
																			}
																			goto IL_07b7;
																			IL_0614:
																			if (12 <= b)
																			{
																				goto IL_061f;
																			}
																			goto IL_0686;
																			IL_061f:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_065f;
																			IL_065f:
																			array[num5 - 2] = 0;
																			goto IL_0673;
																			IL_0673:
																			num5--;
																			goto end_IL_033f;
																			IL_0686:
																			if (10 < b)
																			{
																				goto IL_0694;
																			}
																			goto IL_0726;
																			IL_0694:
																			if (11 < b)
																			{
																				num = 3;
																				goto end_IL_030f;
																			}
																			goto IL_069f;
																			IL_069f:
																			if (11 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_06ad;
																			IL_06ad:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = ((int[])array2[num5 - 2])[*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])];
																			goto IL_06f1;
																			IL_06f1:
																			array[num5 - 2] = 0;
																			goto IL_0705;
																			IL_0705:
																			num5--;
																			goto end_IL_033f;
																			IL_0885:
																			if (15 > b)
																			{
																			}
																			goto end_IL_030f;
																			IL_0726:
																			if (10 > b)
																			{
																				goto IL_0731;
																			}
																			goto IL_0752;
																			IL_0731:
																			if (9 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_073f;
																			IL_073f:
																			if (9 <= b)
																			{
																				goto end_IL_033f;
																			}
																			goto end_IL_030f;
																			IL_0752:
																			array[num5] = 0;
																			goto IL_0760;
																			IL_0760:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_0783;
																			IL_0783:
																			array2[num5] = null;
																			goto IL_078d;
																			IL_078d:
																			num5++;
																			num = 75;
																			goto IL_07a4;
																			IL_07a4:
																			ptr2 += 8;
																			goto end_IL_033f;
																			IL_07b7:
																			if (14 >= b)
																			{
																				goto IL_07c5;
																			}
																			goto IL_087a;
																			IL_07c5:
																			if (14 > b)
																			{
																				goto IL_07d3;
																			}
																			goto IL_0861;
																			IL_07d3:
																			if (13 < b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_07e1;
																			IL_07e1:
																			if (13 > b)
																			{
																				goto end_IL_030f;
																			}
																			goto IL_07ef;
																			IL_07ef:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0851;
																			IL_0851:
																			num5 -= 2;
																			goto end_IL_033f;
																			IL_0861:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_033f;
																			continue;
																			end_IL_02ff:
																			break;
																		}
																		continue;
																		end_IL_030f:
																		break;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_033f;
																continue;
																end_IL_031f:
																break;
															}
															continue;
															end_IL_032f:
															break;
														}
														continue;
														end_IL_033f:
														break;
													}
													continue;
												}
												goto IL_0936;
												IL_0936:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_08a3:
												break;
											}
											continue;
											end_IL_08b6:
											break;
										}
										continue;
										end_IL_08c0:
										break;
									}
									continue;
									end_IL_08cb:
									break;
								}
								continue;
								end_IL_08db:
								break;
							}
							continue;
							end_IL_08eb:
							break;
						}
						continue;
						end_IL_08fb:
						break;
					}
					continue;
					end_IL_090b:
					break;
				}
				continue;
				end_IL_091b:
				break;
			}
		}
	}

	private unsafe static int smethod_8(int int_2, int int_3)
	{
		int num = 85;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[2];
					num = 37;
					while (true)
					{
						object[] array2 = new object[2];
						while (true)
						{
							int[] array3 = new int[3];
							while (true)
							{
								long[] array4 = new long[2];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										num = 13;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref getLatencyModegetGrantedSet.InternalOptionsMaskQuota);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															while (true)
															{
																ptr2++;
																while (true)
																{
																	IL_0254:
																	if (b >= 1)
																	{
																		while (b <= 8)
																		{
																			while (true)
																			{
																				IL_0234:
																				if (4 >= b)
																				{
																					while (true)
																					{
																						IL_0224:
																						if (4 > b)
																						{
																							while (true)
																							{
																								IL_0217:
																								if (2 < b)
																								{
																									while (3 >= b)
																									{
																										while (3 <= b)
																										{
																											while (true)
																											{
																												IL_01b5:
																												*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) - *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																												while (true)
																												{
																													IL_0196:
																													array[num5 - 2] = 0;
																													num = 93;
																													while (true)
																													{
																														if (num != 93)
																														{
																															if (num != 1074)
																															{
																																break;
																															}
																															switch (num)
																															{
																															case 73:
																																goto IL_0196;
																															case 12:
																															case 49:
																																goto IL_01b5;
																															case 8:
																																goto IL_01f7;
																															case 68:
																																goto IL_0207;
																															case 32:
																															case 72:
																																goto IL_0217;
																															case 48:
																																goto IL_0224;
																															case 79:
																																goto IL_0234;
																															case 56:
																																goto IL_0244;
																															case 14:
																																goto IL_0254;
																															case 70:
																																goto end_IL_0254;
																															case 19:
																															case 60:
																																goto end_IL_0264;
																															case 41:
																																goto IL_027f;
																															case 2:
																																goto IL_028a;
																															case 34:
																																goto IL_02a1;
																															case 6:
																															case 61:
																																goto IL_02b4;
																															case 63:
																																goto IL_0322;
																															case 21:
																															case 26:
																																goto IL_0348;
																															case 15:
																																goto IL_0371;
																															case 80:
																																goto IL_037f;
																															case 53:
																																goto IL_0392;
																															case 62:
																																goto IL_039d;
																															case 36:
																															case 54:
																																goto IL_03ab;
																															case 35:
																																goto IL_03b9;
																															case 7:
																															case 47:
																																goto IL_03c7;
																															case 11:
																																goto IL_03df;
																															case 18:
																																goto IL_03ea;
																															case 65:
																																goto IL_03f8;
																															case 20:
																															case 76:
																																goto IL_0406;
																															case 71:
																																goto IL_042b;
																															case 55:
																															case 74:
																																goto IL_0436;
																															case 40:
																																goto IL_0444;
																															case 4:
																																goto IL_0470;
																															case 83:
																																goto IL_047a;
																															case 69:
																																goto IL_0488;
																															case 0:
																															case 9:
																															case 10:
																															case 24:
																															case 28:
																															case 29:
																															case 30:
																															case 42:
																															case 43:
																															case 44:
																															case 51:
																															case 64:
																															case 66:
																															case 67:
																															case 75:
																															case 86:
																																goto end_IL_0183;
																															case 25:
																																goto IL_04c4;
																															case 82:
																																goto IL_04db;
																															case 23:
																																goto IL_04e9;
																															case 16:
																															case 17:
																															case 27:
																															case 33:
																															case 38:
																															case 39:
																															case 50:
																															case 52:
																															case 57:
																															case 58:
																															case 78:
																																goto end_IL_0274;
																															case 46:
																																goto end_IL_04f7;
																															case 13:
																																goto end_IL_050a;
																															case 3:
																																goto end_IL_0514;
																															case 77:
																																goto end_IL_051f;
																															case 5:
																																goto end_IL_053d;
																															case 1:
																															case 45:
																																goto end_IL_0552;
																															case 37:
																																goto end_IL_0562;
																															case 22:
																															case 31:
																																goto end_IL_0572;
																															case 84:
																																goto end_IL_0582;
																															case 85:
																																goto end_IL_059b;
																															case 59:
																															case 81:
																																goto IL_05b6;
																															}
																															continue;
																														}
																														num5--;
																														goto end_IL_0274;
																														continue;
																														end_IL_0183:
																														break;
																													}
																													break;
																												}
																												break;
																											}
																											break;
																											IL_01f7:;
																										}
																										break;
																										IL_0207:;
																									}
																									break;
																								}
																								goto IL_027f;
																								IL_02b4:
																								ptr2 = (((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) > *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) + -1) * -1 * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																								goto IL_0322;
																								IL_027f:
																								if (2 > b)
																								{
																									goto IL_028a;
																								}
																								goto IL_02b4;
																								IL_028a:
																								if (1 < b)
																								{
																									break;
																								}
																								num = 34;
																								goto IL_02a1;
																								IL_0322:
																								num5 -= 2;
																								goto end_IL_0274;
																								IL_02a1:
																								if (1 <= b)
																								{
																								}
																								break;
																							}
																							break;
																						}
																						goto IL_0348;
																						IL_037f:
																						num5--;
																						goto end_IL_0274;
																						IL_0348:
																						ref int reference = ref array3[*(int*)(ptr2 + num3)];
																						reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						goto IL_0371;
																						IL_0371:
																						ptr2 += 8;
																						goto IL_037f;
																					}
																					break;
																				}
																				goto IL_0392;
																				IL_047a:
																				num5++;
																				goto IL_0488;
																				IL_0392:
																				if (6 >= b)
																				{
																					goto IL_039d;
																				}
																				goto IL_03df;
																				IL_039d:
																				if (6 <= b)
																				{
																					goto end_IL_0274;
																				}
																				goto IL_03ab;
																				IL_03ab:
																				if (5 < b)
																				{
																					break;
																				}
																				goto IL_03b9;
																				IL_03b9:
																				if (5 > b)
																				{
																					break;
																				}
																				goto IL_03c7;
																				IL_03c7:
																				ptr2 = ptr + *(int*)(ptr2 + num3);
																				goto end_IL_0274;
																				IL_03df:
																				if (7 < b)
																				{
																					goto IL_03ea;
																				}
																				num = 71;
																				goto IL_042b;
																				IL_03ea:
																				if (8 < b)
																				{
																					break;
																				}
																				goto IL_03f8;
																				IL_03f8:
																				if (8 > b)
																				{
																					break;
																				}
																				goto IL_0406;
																				IL_0406:
																				byte* num6 = ptr2;
																				num4 = 1;
																				ptr2 = num6 + -200;
																				goto end_IL_0274;
																				IL_0488:
																				ptr2 += 8;
																				num = 52;
																				goto end_IL_0274;
																				IL_042b:
																				if (7 > b)
																				{
																					break;
																				}
																				goto IL_0436;
																				IL_0436:
																				array[num5] = 0;
																				goto IL_0444;
																				IL_0444:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				num = 4;
																				goto IL_0470;
																				IL_0470:
																				array2[num5] = null;
																				goto IL_047a;
																			}
																			break;
																			IL_0244:;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_04c4;
																	IL_04e9:
																	ptr2 += 8;
																	goto end_IL_0274;
																	IL_04db:
																	num5++;
																	goto IL_04e9;
																	IL_04c4:
																	array[num5] = 0;
																	num = 82;
																	goto IL_04db;
																	continue;
																	end_IL_0254:
																	break;
																}
																continue;
																end_IL_0264:
																break;
															}
															continue;
															end_IL_0274:
															break;
														}
														continue;
													}
													goto IL_05b6;
													IL_05b6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_04f7:
													break;
												}
												continue;
												end_IL_050a:
												break;
											}
											continue;
											end_IL_0514:
											break;
										}
										continue;
										end_IL_051f:
										break;
									}
									continue;
									end_IL_053d:
									break;
								}
								continue;
								end_IL_0552:
								break;
							}
							continue;
							end_IL_0562:
							break;
						}
						continue;
						end_IL_0572:
						break;
					}
					continue;
					end_IL_0582:
					break;
				}
				continue;
				end_IL_059b:
				break;
			}
		}
	}

	private unsafe static int smethod_9(int int_2, int int_3)
	{
		int num = 46;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[5];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										array3[1] = int_3;
										while (true)
										{
											byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref RegisterChannelGetDisplayName.SelfSidgetUseNetCoreTimer);
											while (true)
											{
												byte* ptr2 = ptr;
												while (true)
												{
													if (num4 != 1)
													{
														while (true)
														{
															byte b = *ptr2;
															num = 36;
															while (true)
															{
																ptr2++;
																num = 4;
																while (true)
																{
																	IL_0260:
																	if (b >= 1)
																	{
																		while (b <= 9)
																		{
																			while (true)
																			{
																				IL_0243:
																				if (5 < b)
																				{
																					while (true)
																					{
																						IL_0233:
																						if (7 >= b)
																						{
																							while (true)
																							{
																								IL_0223:
																								if (7 <= b)
																								{
																									while (true)
																									{
																										IL_01ff:
																										*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																										num = 74;
																										while (true)
																										{
																											IL_01ef:
																											array[num5] = 0;
																											while (true)
																											{
																												IL_01d6:
																												num5++;
																												num = 109;
																												while (true)
																												{
																													if (num != 109)
																													{
																														if (num != 1090)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 25:
																															goto IL_01d6;
																														case 74:
																															goto IL_01ef;
																														case 82:
																														case 101:
																															goto IL_01ff;
																														case 20:
																															goto IL_0223;
																														case 12:
																															goto IL_0233;
																														case 15:
																															goto IL_0243;
																														case 31:
																															goto end_IL_0243;
																														case 4:
																															goto IL_0260;
																														case 36:
																															goto end_IL_0260;
																														case 22:
																														case 28:
																															goto end_IL_0270;
																														case 30:
																															goto IL_029d;
																														case 58:
																															goto IL_02a8;
																														case 41:
																															goto IL_02b3;
																														case 47:
																														case 55:
																															goto IL_02c1;
																														case 61:
																															goto IL_02d4;
																														case 33:
																															goto IL_02df;
																														case 37:
																															goto IL_02f2;
																														case 9:
																															goto IL_0300;
																														case 42:
																														case 66:
																															goto IL_0313;
																														case 21:
																															goto IL_0321;
																														case 5:
																															goto IL_0344;
																														case 73:
																															goto IL_034e;
																														case 11:
																															goto IL_035c;
																														case 49:
																														case 83:
																															goto IL_036f;
																														case 77:
																															goto IL_037d;
																														case 81:
																														case 91:
																															goto IL_0390;
																														case 16:
																															goto IL_03b9;
																														case 19:
																															goto IL_03c7;
																														case 93:
																															goto IL_03da;
																														case 78:
																														case 94:
																															goto IL_03ed;
																														case 51:
																														case 96:
																															goto IL_042f;
																														case 98:
																															goto IL_046f;
																														case 70:
																															goto IL_0483;
																														case 99:
																															goto end_IL_01c3;
																														case 56:
																															goto IL_04aa;
																														case 68:
																														case 102:
																															goto IL_04bd;
																														case 0:
																															goto IL_04fd;
																														case 84:
																															goto IL_0511;
																														case 92:
																															goto IL_0537;
																														case 63:
																															goto IL_0542;
																														case 2:
																														case 64:
																															goto IL_0550;
																														case 97:
																															goto IL_0599;
																														case 34:
																															goto IL_05ad;
																														case 8:
																															goto IL_05bd;
																														case 38:
																															goto IL_05c8;
																														case 52:
																														case 88:
																															goto IL_05d3;
																														case 13:
																														case 18:
																														case 24:
																														case 26:
																														case 27:
																														case 29:
																														case 48:
																														case 50:
																														case 57:
																														case 60:
																														case 62:
																														case 71:
																														case 72:
																														case 75:
																														case 79:
																														case 80:
																														case 89:
																														case 90:
																															goto end_IL_0250;
																														case 54:
																															goto IL_060f;
																														case 14:
																															goto IL_061d;
																														case 10:
																															goto IL_062b;
																														case 6:
																														case 32:
																														case 35:
																														case 39:
																														case 40:
																														case 43:
																														case 44:
																														case 59:
																														case 69:
																														case 85:
																														case 87:
																															goto end_IL_0289;
																														case 3:
																															goto end_IL_0639;
																														case 76:
																															goto end_IL_064c;
																														case 86:
																															goto end_IL_0656;
																														case 65:
																															goto end_IL_0661;
																														case 1:
																															goto end_IL_0676;
																														case 17:
																														case 95:
																															goto end_IL_068b;
																														case 53:
																															goto end_IL_069b;
																														case 7:
																														case 23:
																															goto end_IL_06ab;
																														case 45:
																															goto end_IL_06bb;
																														case 46:
																															goto end_IL_06cb;
																														case 67:
																														case 100:
																															goto IL_06e6;
																														}
																														continue;
																													}
																													ptr2 += 8;
																													goto end_IL_0289;
																													continue;
																													end_IL_01c3:
																													break;
																												}
																												break;
																											}
																											break;
																										}
																										break;
																									}
																									break;
																								}
																								goto IL_036f;
																								IL_0483:
																								num5--;
																								goto end_IL_0289;
																								IL_036f:
																								if (6 < b)
																								{
																									goto end_IL_0250;
																								}
																								goto IL_037d;
																								IL_037d:
																								if (6 > b)
																								{
																									goto end_IL_0250;
																								}
																								goto IL_042f;
																								IL_042f:
																								*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) ^ *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																								goto IL_046f;
																								IL_046f:
																								array[num5 - 2] = 0;
																								goto IL_0483;
																							}
																							break;
																						}
																						goto IL_0537;
																						IL_05d3:
																						byte* num6 = ptr2;
																						num4 = 1;
																						ptr2 = num6 + -200;
																						goto end_IL_0289;
																						IL_0537:
																						if (8 >= b)
																						{
																							goto IL_0542;
																						}
																						goto IL_05bd;
																						IL_0542:
																						if (8 > b)
																						{
																							goto end_IL_0250;
																						}
																						goto IL_0550;
																						IL_0550:
																						*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) / *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																						num = 97;
																						goto IL_0599;
																						IL_0599:
																						array[num5 - 2] = 0;
																						goto IL_05ad;
																						IL_05ad:
																						num5--;
																						goto end_IL_0289;
																						IL_05bd:
																						if (9 < b)
																						{
																							goto end_IL_0250;
																						}
																						goto IL_05c8;
																						IL_05c8:
																						if (9 > b)
																						{
																							goto end_IL_0250;
																						}
																						goto IL_05d3;
																					}
																					goto IL_0496;
																				}
																				goto IL_029d;
																				IL_035c:
																				ptr2 += 8;
																				goto end_IL_0289;
																				IL_029d:
																				if (5 > b)
																				{
																					goto IL_02a8;
																				}
																				goto IL_0313;
																				IL_02a8:
																				if (2 >= b)
																				{
																					goto IL_02b3;
																				}
																				goto IL_02d4;
																				IL_02b3:
																				if (2 > b)
																				{
																					goto IL_02c1;
																				}
																				goto IL_03ed;
																				IL_02c1:
																				if (1 < b)
																				{
																					goto end_IL_0250;
																				}
																				goto IL_03da;
																				IL_03da:
																				if (1 > b)
																				{
																				}
																				goto end_IL_0250;
																				IL_03ed:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_0496;
																				IL_0496:
																				array[num5 - 2] = 0;
																				goto IL_04aa;
																				IL_04aa:
																				num5--;
																				goto end_IL_0289;
																				IL_02d4:
																				if (3 >= b)
																				{
																					goto IL_02df;
																				}
																				goto IL_02f2;
																				IL_02df:
																				if (3 > b)
																				{
																					goto end_IL_0250;
																				}
																				goto IL_0390;
																				IL_0390:
																				ref int reference = ref array3[*(int*)(ptr2 + num3)];
																				reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_03b9;
																				IL_03b9:
																				ptr2 += 8;
																				goto IL_03c7;
																				IL_03c7:
																				num5--;
																				goto end_IL_0289;
																				IL_02f2:
																				if (4 < b)
																				{
																					goto end_IL_0250;
																				}
																				goto IL_0300;
																				IL_0300:
																				if (4 > b)
																				{
																					goto end_IL_0250;
																				}
																				goto IL_04bd;
																				IL_04bd:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																				goto IL_04fd;
																				IL_04fd:
																				array[num5 - 2] = 0;
																				goto IL_0511;
																				IL_0511:
																				num5--;
																				goto end_IL_0289;
																				IL_0313:
																				array[num5] = 0;
																				goto IL_0321;
																				IL_0321:
																				*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																				goto IL_0344;
																				IL_0344:
																				array2[num5] = null;
																				goto IL_034e;
																				IL_034e:
																				num5++;
																				goto IL_035c;
																				continue;
																				end_IL_0243:
																				break;
																			}
																			continue;
																			end_IL_0250:
																			break;
																		}
																	}
																	*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																	goto IL_060f;
																	IL_062b:
																	ptr2 += 8;
																	goto end_IL_0289;
																	IL_061d:
																	num5++;
																	goto IL_062b;
																	IL_060f:
																	array[num5] = 0;
																	goto IL_061d;
																	continue;
																	end_IL_0260:
																	break;
																}
																continue;
																end_IL_0270:
																break;
															}
															continue;
															end_IL_0289:
															break;
														}
														continue;
													}
													goto IL_06e6;
													IL_06e6:
													return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
													continue;
													end_IL_0639:
													break;
												}
												continue;
												end_IL_064c:
												break;
											}
											continue;
											end_IL_0656:
											break;
										}
										continue;
										end_IL_0661:
										break;
									}
									continue;
									end_IL_0676:
									break;
								}
								continue;
								end_IL_068b:
								break;
							}
							continue;
							end_IL_069b:
							break;
						}
						continue;
						end_IL_06ab:
						break;
					}
					continue;
					end_IL_06bb:
					break;
				}
				continue;
				end_IL_06cb:
				break;
			}
		}
	}

	private unsafe static int smethod_10(int int_2)
	{
		int num = 26;
		int num4 = default(int);
		int num5 = default(int);
		while (true)
		{
			int num2 = 1;
			while (true)
			{
				int num3 = num2 * 4;
				while (true)
				{
					byte[] array = new byte[3];
					while (true)
					{
						object[] array2 = new object[3];
						while (true)
						{
							int[] array3 = new int[4];
							while (true)
							{
								long[] array4 = new long[3];
								while (true)
								{
									array3[0] = int_2;
									while (true)
									{
										byte* ptr = (byte*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref IIDGuidKerbSmartCardLogon.FullTrustListAssembliesInGacDynamicPartitionEnumeratorForIndexRangeAbstract);
										while (true)
										{
											byte* ptr2 = ptr;
											while (true)
											{
												if (num4 != 1)
												{
													while (true)
													{
														byte b = *ptr2;
														while (true)
														{
															ptr2++;
															while (true)
															{
																IL_0280:
																if (b >= 1)
																{
																	while (b <= 11)
																	{
																		while (true)
																		{
																			IL_0260:
																			if (6 >= b)
																			{
																				while (true)
																				{
																					IL_0250:
																					if (6 > b)
																					{
																						while (true)
																						{
																							IL_0243:
																							if (3 < b)
																							{
																								while (true)
																								{
																									IL_0233:
																									if (4 < b)
																									{
																										while (5 >= b)
																										{
																											while (5 <= b)
																											{
																												num = 120;
																												while (true)
																												{
																													if (num != 120)
																													{
																														if (num != 1101)
																														{
																															break;
																														}
																														switch (num)
																														{
																														case 7:
																															goto IL_0210;
																														case 0:
																															goto IL_0223;
																														case 102:
																															goto IL_0233;
																														case 89:
																															goto IL_0243;
																														case 47:
																															goto IL_0250;
																														case 96:
																															goto IL_0260;
																														case 21:
																															goto IL_0270;
																														case 19:
																															goto IL_0280;
																														case 20:
																															goto end_IL_0280;
																														case 53:
																														case 88:
																															goto end_IL_0290;
																														case 28:
																															goto IL_02ab;
																														case 2:
																														case 33:
																															goto IL_02b6;
																														case 35:
																															goto IL_02ce;
																														case 52:
																														case 70:
																															goto IL_02d9;
																														case 71:
																															goto IL_02ec;
																														case 16:
																														case 72:
																															goto IL_02ff;
																														case 48:
																															goto IL_030a;
																														case 74:
																															goto IL_031a;
																														case 34:
																														case 67:
																															goto IL_0328;
																														case 66:
																															goto IL_0341;
																														case 22:
																														case 97:
																															goto IL_0351;
																														case 98:
																															goto IL_0364;
																														case 49:
																															goto IL_0372;
																														case 1:
																														case 104:
																															goto IL_0385;
																														case 87:
																															goto IL_0390;
																														case 9:
																														case 65:
																															goto IL_039e;
																														case 80:
																															goto IL_03de;
																														case 31:
																															goto IL_03f2;
																														case 58:
																															goto IL_0405;
																														case 11:
																															goto IL_041c;
																														case 10:
																														case 56:
																															goto IL_042a;
																														case 68:
																															goto IL_044d;
																														case 8:
																															goto IL_045b;
																														case 62:
																															goto IL_0469;
																														case 105:
																															goto IL_047c;
																														case 82:
																														case 91:
																															goto IL_048a;
																														case 27:
																														case 109:
																															goto IL_04a6;
																														case 59:
																															goto IL_0508;
																														case 111:
																															goto IL_051b;
																														case 4:
																														case 17:
																															goto IL_0529;
																														case 103:
																															goto IL_0552;
																														case 90:
																															goto IL_0560;
																														case 75:
																														case 112:
																															goto end_IL_01fd;
																														case 40:
																															goto IL_0581;
																														case 81:
																															goto IL_0594;
																														case 110:
																															goto IL_05ab;
																														case 77:
																															goto IL_05ce;
																														case 38:
																															goto IL_05d8;
																														case 32:
																															goto IL_05e6;
																														case 57:
																														case 79:
																															goto IL_0602;
																														case 3:
																															goto IL_0642;
																														case 6:
																															goto IL_0656;
																														case 12:
																														case 13:
																														case 15:
																														case 18:
																														case 24:
																														case 41:
																														case 43:
																														case 54:
																														case 60:
																														case 61:
																														case 69:
																														case 73:
																														case 78:
																														case 83:
																														case 85:
																														case 86:
																														case 92:
																														case 94:
																														case 107:
																														case 108:
																														case 113:
																															goto end_IL_0210;
																														case 5:
																														case 30:
																														case 39:
																														case 45:
																														case 46:
																														case 51:
																														case 55:
																														case 63:
																														case 64:
																														case 76:
																														case 84:
																														case 93:
																														case 95:
																														case 99:
																															goto end_IL_02a0;
																														case 42:
																															goto end_IL_0679;
																														case 36:
																															goto end_IL_068c;
																														case 14:
																															goto end_IL_0696;
																														case 50:
																															goto end_IL_06a1;
																														case 44:
																														case 106:
																															goto end_IL_06b6;
																														case 23:
																															goto end_IL_06c6;
																														case 37:
																														case 100:
																															goto end_IL_06d6;
																														case 25:
																															goto end_IL_06e6;
																														case 26:
																															goto end_IL_06f6;
																														case 29:
																														case 101:
																															goto IL_0711;
																														}
																														continue;
																													}
																													goto IL_0594;
																													IL_05d8:
																													num5++;
																													goto IL_05e6;
																													IL_05e6:
																													ptr2 += 8;
																													goto end_IL_02a0;
																													IL_0594:
																													array[num5] = 0;
																													num = 110;
																													goto IL_05ab;
																													IL_05ab:
																													*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																													goto IL_05ce;
																													IL_05ce:
																													array2[num5] = null;
																													goto IL_05d8;
																													continue;
																													end_IL_01fd:
																													break;
																												}
																												goto IL_0573;
																												continue;
																												end_IL_0210:
																												break;
																												IL_0210:;
																											}
																											break;
																											IL_0223:;
																										}
																										break;
																									}
																									goto IL_02ec;
																									IL_02ec:
																									if (4 <= b)
																									{
																										goto end_IL_02a0;
																									}
																									break;
																								}
																								break;
																							}
																							goto IL_02ab;
																							IL_0372:
																							ptr2 += 8;
																							goto end_IL_02a0;
																							IL_02ab:
																							if (3 <= b)
																							{
																								goto IL_02b6;
																							}
																							goto IL_02ce;
																							IL_02b6:
																							ptr2 = ptr + *(int*)(ptr2 + num3);
																							goto end_IL_02a0;
																							IL_02ce:
																							if (1 < b)
																							{
																								goto IL_02d9;
																							}
																							goto IL_031a;
																							IL_02d9:
																							if (2 < b)
																							{
																								break;
																							}
																							goto IL_051b;
																							IL_051b:
																							if (2 > b)
																							{
																								break;
																							}
																							goto IL_0529;
																							IL_0529:
																							ref int reference = ref array3[*(int*)(ptr2 + num3)];
																							reference = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																							goto IL_0552;
																							IL_0552:
																							ptr2 += 8;
																							goto IL_0560;
																							IL_0560:
																							num5--;
																							goto end_IL_02a0;
																							IL_031a:
																							if (1 > b)
																							{
																								break;
																							}
																							goto IL_0328;
																							IL_0328:
																							*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = *(int*)(ptr2 + num3);
																							goto IL_0341;
																							IL_0341:
																							array[num5] = 0;
																							goto IL_0364;
																							IL_0364:
																							num5++;
																							goto IL_0372;
																						}
																						break;
																					}
																					num = 79;
																					goto IL_0602;
																					IL_0642:
																					array[num5 - 2] = 0;
																					goto IL_0656;
																					IL_0656:
																					num5--;
																					goto end_IL_02a0;
																					IL_0602:
																					*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) * *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																					goto IL_0642;
																				}
																				break;
																			}
																			goto IL_02ff;
																			IL_047c:
																			if (10 > b)
																			{
																				break;
																			}
																			goto IL_048a;
																			IL_02ff:
																			if (9 >= b)
																			{
																				goto IL_030a;
																			}
																			goto IL_0351;
																			IL_030a:
																			if (9 > b)
																			{
																				goto IL_0385;
																			}
																			goto IL_04a6;
																			IL_0385:
																			if (7 >= b)
																			{
																				goto IL_0390;
																			}
																			goto IL_0405;
																			IL_0390:
																			if (7 > b)
																			{
																				break;
																			}
																			goto IL_039e;
																			IL_039e:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) = *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) + *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
																			goto IL_03de;
																			IL_03de:
																			array[num5 - 2] = 0;
																			goto IL_03f2;
																			IL_03f2:
																			num5--;
																			goto end_IL_02a0;
																			IL_0405:
																			if (8 < b)
																			{
																				break;
																			}
																			num = 11;
																			goto IL_041c;
																			IL_048a:
																			byte* num6 = ptr2;
																			num4 = 1;
																			ptr2 = num6 + -200;
																			goto end_IL_02a0;
																			IL_041c:
																			if (8 > b)
																			{
																				break;
																			}
																			goto IL_042a;
																			IL_042a:
																			*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5]) = array3[*(int*)(ptr2 + num3)];
																			goto IL_044d;
																			IL_044d:
																			array[num5] = 0;
																			goto IL_045b;
																			IL_045b:
																			num5++;
																			goto IL_0469;
																			IL_0469:
																			ptr2 += 8;
																			goto end_IL_02a0;
																			IL_04a6:
																			ptr2 = ((*(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 2]) < *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1])) ? 1 : 0) * (*(int*)(ptr2 + num3) - *(int*)(ptr2 + 8 + num3)) + *(int*)(ptr2 + 8 + num3) + ptr;
																			goto IL_0508;
																			IL_0508:
																			num5 -= 2;
																			goto end_IL_02a0;
																			IL_0351:
																			if (10 >= b)
																			{
																				goto IL_047c;
																			}
																			goto IL_0573;
																			IL_0573:
																			if (11 < b)
																			{
																				break;
																			}
																			goto IL_0581;
																			IL_0581:
																			if (11 <= b)
																			{
																			}
																			break;
																		}
																		break;
																		IL_0270:;
																	}
																}
																ptr2 = ptr + *(int*)(ptr2 + num3);
																goto end_IL_02a0;
																continue;
																end_IL_0280:
																break;
															}
															continue;
															end_IL_0290:
															break;
														}
														continue;
														end_IL_02a0:
														break;
													}
													continue;
												}
												goto IL_0711;
												IL_0711:
												return *(int*)System.Runtime.CompilerServices.Unsafe.AsPointer(ref array4[num5 - 1]);
												continue;
												end_IL_0679:
												break;
											}
											continue;
											end_IL_068c:
											break;
										}
										continue;
										end_IL_0696:
										break;
									}
									continue;
									end_IL_06a1:
									break;
								}
								continue;
								end_IL_06b6:
								break;
							}
							continue;
							end_IL_06c6:
							break;
						}
						continue;
						end_IL_06d6:
						break;
					}
					continue;
					end_IL_06e6:
					break;
				}
				continue;
				end_IL_06f6:
				break;
			}
		}
	}
}
